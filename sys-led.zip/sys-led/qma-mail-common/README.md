# qma-mail-common base version  [![Quality Gate Status](https://sonarqube.dev.qwyn.deltacapita.net/api/project_badges/measure?project=qma-mail-common&metric=alert_status&token=sqb_37915c9c94d2b1d8642e83f20315b10f77356c04)](https://sonarqube.dev.qwyn.deltacapita.net/dashboard?id=qma-mail-common)


    mvn install -Dmaven.test.skip=true
    mvn install:install-file -Dfile=target/qma-mail-common-2024.03.1.0.1.jar -DgroupId=com.citi.170665 -DartifactId=qma-mail-common -Dversion=2024.03.1.0.1 -Dpackaging=jar
    
# UAT deployment on 4/10
