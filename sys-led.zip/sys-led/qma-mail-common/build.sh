
#set -vx
mvn clean
mvn install  "-Dmaven.test.skip=true"
