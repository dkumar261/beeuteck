declare -A BRANCH_DEPLOYMENT_MAPPING

# Define named indices
BRANCH_DEPLOYMENT_MAPPING["main"]=""
BRANCH_DEPLOYMENT_MAPPING["develop"]="-alpha"
BRANCH_DEPLOYMENT_MAPPING["feature"]="-beta"

# Export the associative array as an environment variable.
export BRANCH_DEPLOYMENT_MAPPING
