/**
 * 
 */
package com.citi.icg.qma.common.server.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketException;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.HttpsURLConnection;
import jakarta.xml.bind.DatatypeConverter;

import org.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 *
 */
public class ISGCloudRestServiceClient {

	private static final Logger logger = LoggerFactory.getLogger(ISGCloudRestServiceClient.class);
	private static final String AUTH_USER_NAME = "qmaUserName";
	private static final String AUTH_PASS = "qmaPassword";
	private static final String WS_TOKEN_URL = "accessTokenUrl";
	private static final String APP_ID = "cloud-api:";
	private static final String ACCESSTOKEN = "access_token";
	private static final String AUTHORIZATION = "Authorization";
	private static String authToken = null;
	private static final String ERRORCODE = "ERRORCODE:";
	private static final String CLOUDLOGMSG = "WS ResponseCode is ";
	private static final String PASSWRD = "password";
	private static final List<Integer> RESPONSEERRORCODES = Arrays.asList(new Integer[] { 400, 403, 404, 206 });

	ISGCloudRestServiceClient() {
	}

	public static synchronized String getAuthorizationToken(Map<String, Object> isgCloudHolidayConfigMap) throws IOException {
		if (authToken == null) {
			String accessTokenUrl = (String) isgCloudHolidayConfigMap.get(WS_TOKEN_URL);
			String qmaUserName = (String) isgCloudHolidayConfigMap.get(AUTH_USER_NAME);
			String qmaPassword = (String) isgCloudHolidayConfigMap.get(AUTH_PASS);
			String body = "%s=%s&%s=%s".formatted("username", qmaUserName, PASSWRD, qmaPassword);
			String authRespJson;
			try {
				authRespJson = doRequest(accessTokenUrl, "POST", body, getAuthHeader());
				JSONObject authJson = new JSONObject(authRespJson);
				if (!authJson.isNull(ACCESSTOKEN)) {
					authToken = authJson.getString(ACCESSTOKEN);
					logger.info("WebRestServiceClient authToken:: " + authToken);
				} else {
					return authRespJson;
				}
			} catch (SocketException e) {
				logger.error(" Rest web service call socket exception is thrown - ", e);
				throw e;
			} catch (IOException e) {
				logger.error("getAuthorizationToken - IOException is thrown while accessing  URL - " + accessTokenUrl, e);
				throw e;
			} catch (Exception e) {
				logger.error("getAuthorizationToken - Exception is thrown while accessing  URL - " + accessTokenUrl, e);
			}
		}
		return authToken;
	}

	/**
	 * @return
	 */
	public static Map<String, String> getAuthHeader() {
		Map<String, String> headers = new HashMap<>();
		String basicAuthHeader = "Basic " + DatatypeConverter.printBase64Binary(APP_ID.getBytes());
		headers.put(AUTHORIZATION, basicAuthHeader);
		headers.put("Accept", "application/json");
		headers.put("Content-Type", "application/x-www-form-urlencoded");
		return headers;
	}

	/**
	 * @param urlString
	 * @param method
	 * @param body
	 * @param headers
	 * @return
	 * @throws IOException
	 */
	public static String doRequest(String urlString, String method, String body, Map<String, String> headers) throws IOException {
		URL url = URI.create(urlString).toURL();
		HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
		conn.setRequestMethod(method);
		conn.setDoOutput(true);
		for (Entry<String, String> entry : headers.entrySet()) {
			conn.setRequestProperty(entry.getKey(), entry.getValue());
		}
		if (body != null) {
			conn.setDoOutput(true);
			DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
			wr.writeBytes(body);
			wr.flush();
			wr.close();
		}
		Integer responseCode = conn.getResponseCode();
		if (responseCode == 200) {
			BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), Charset.forName("UTF-8")));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			return response.toString();
		} else if (RESPONSEERRORCODES.contains(responseCode)) {
			logger.info(CLOUDLOGMSG + responseCode + " is thrown by  CLOUD server and responseMsg is -"	+ conn.getResponseMessage());
			logger.info(CLOUDLOGMSG + responseCode + " is thrown, for URL -" + urlString.replace("%22", "\""));
			return null;
		} else { 
			logger.info(CLOUDLOGMSG + responseCode + " is thrown by  CLOUD server and responseMsg is -"	+ conn.getResponseMessage());
			return "{" + ERRORCODE + responseCode + "}";
		}
	}
	
	public static AmcResponse doRequestWithStatusCode(String urlString, String method, String body, Map<String, String> headers) throws IOException {
		URL url = URI.create(urlString).toURL();
		HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
		conn.setRequestMethod(method);
		conn.setDoOutput(true);
		for (Entry<String, String> entry : headers.entrySet()) {
			conn.setRequestProperty(entry.getKey(), entry.getValue());
		}
		if (body != null) {
			conn.setDoOutput(true);
			DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
			wr.writeBytes(body);
			wr.flush();
			wr.close();
		}
		Integer responseCode = conn.getResponseCode();
		AmcResponse amcResponse = new AmcResponse(responseCode);
		String responseData = "";
		if (responseCode == 200) {
			BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), Charset.forName("UTF-8")));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			responseData = response.toString();
		} else { 
			logger.info(CLOUDLOGMSG + responseCode + " is thrown by  CLOUD server and responseMsg is -"	+ conn.getResponseMessage());
			responseData = conn.getResponseMessage();
		}
		amcResponse.setResponseData(responseData);
		return amcResponse;
	}

	/**
	 * @return the authToken
	 */
	public static String getAuthToken() {
		return authToken;
	}

	/**
	 * @param authToken the authToken to set
	 */
	public static void setAuthToken(String authToken) {
		ISGCloudRestServiceClient.authToken = authToken;
	}

}
