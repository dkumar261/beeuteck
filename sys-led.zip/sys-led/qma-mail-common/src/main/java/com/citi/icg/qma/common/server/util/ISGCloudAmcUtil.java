package com.citi.icg.qma.common.server.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;

public class ISGCloudAmcUtil {

	private static final Logger logger = LoggerFactory.getLogger(ISGCloudAmcUtil.class);

	public static final String ISG_CLOUD_AMC_CONFIG = "isgCloudAmcConfig";
	// private static final Object SEARCH_PARAM = "searchParam";
	private static final String UTF_8_CHARACTERSET = "UTF-8";
	private static final String ERRORCODE = "ERRORCODE";
	private static final String BEARER = "Bearer ";
	private static final String AUTHORIZATION = "Authorization";
	private static final String GET = "GET";
	private static final Object API_URL = "apiUrl";
	private static final String PROJECTION = "projection";
	private static final String ROW_LIMIT = "rowLimit";
	public static final String TYPE = "type";
	public static final String ID = "_id";
	public static Integer PAGE_SIZE = 1;
	private static String responseToken = null;
	private static Config configData = null;

	private ISGCloudAmcUtil() {
	}

	/**
	 * Method to get the AMC details (GFCName corresponds to GFCID).
	 * 
	 * @param gfcId
	 * @return
	 * @throws IOException
	 */
	public static String getISGCloudAmcResults(String gfcId) throws IOException {
		String apiResponse = null;
		if (null == configData) {
			configData = QMACacheFactory.getCache().getConfigById(ISG_CLOUD_AMC_CONFIG);
			Map<String, Object> isgCloudAmcConfigMap = configData.getIsgCloudAmcConfig();
			responseToken = ISGCloudRestServiceClient.getAuthorizationToken(isgCloudAmcConfigMap);
		}
		String apiUrl = buildUrl(configData, gfcId);
		Map<String, String> authorizationHeader = new HashMap<>();
		if (null != responseToken && !responseToken.contains(ERRORCODE)) {
			authorizationHeader.put(AUTHORIZATION, BEARER + responseToken);
			apiResponse = ISGCloudRestServiceClient.doRequest(apiUrl, GET, null, authorizationHeader);
		}
		return apiResponse;
	}
	
	public static AmcResponse getISGCloudAmcResultsWithStatusCode(String gfcId) throws IOException {
		AmcResponse apiResponse = null;
		if (null == configData) {
			configData = QMACacheFactory.getCache().getConfigById(ISG_CLOUD_AMC_CONFIG);
			Map<String, Object> isgCloudAmcConfigMap = configData.getIsgCloudAmcConfig();
			responseToken = ISGCloudRestServiceClient.getAuthorizationToken(isgCloudAmcConfigMap);
		}
		String apiUrl = buildUrl(configData, gfcId);
		Map<String, String> authorizationHeader = new HashMap<>();
		String logLevel = (String) configData.getIsgCloudAmcConfig().get("logLevel");
		if("debug".equals(logLevel)){
			logger.info("Calling getISGCloudAmcResultsWithStatusCode with "+AUTHORIZATION+" = "+BEARER + responseToken+" Url = "+apiUrl );
		} 
		if (null != responseToken && !responseToken.contains(ERRORCODE)) {
			authorizationHeader.put(AUTHORIZATION, BEARER + responseToken);
			apiResponse = ISGCloudRestServiceClient.doRequestWithStatusCode(apiUrl, GET, null, authorizationHeader);
		}
		if("debug".equals(logLevel)){
			logger.info("Got result for getISGCloudAmcResultsWithStatusCode {} for GFCID = {} , Authorization = {}",( null == apiResponse ? apiResponse : apiResponse.getResponseCode()),gfcId,BEARER + responseToken );
		} 
		return apiResponse;
	}

	/**
	 * Method used to build URL for the given configuration
	 * 
	 * @param configData
	 * @param gfcId
	 * @return
	 */
	private static String buildUrl(Config configData, String gfcId) {
		Map<String, Object> isgCloudAmcConfigMap = configData.getIsgCloudAmcConfig();
		String apiUrl = (String) isgCloudAmcConfigMap.get(API_URL);

		@SuppressWarnings("unchecked")
		List<BasicDBList> projection = (List<BasicDBList>) isgCloudAmcConfigMap.get(PROJECTION);

		String rowLimit = (String) isgCloudAmcConfigMap.get(ROW_LIMIT);
		PAGE_SIZE = Integer.parseInt(rowLimit);

		StringBuilder searchJson = new StringBuilder();
		searchJson.append("{\"GFCID\":\"" + gfcId + "\"}");
		StringBuilder finalProjection = new StringBuilder();
		finalProjection.append("&projection={");
		for (int i = 0; i < projection.size(); i++) {
			String lastProjection;
			if (i == projection.size() - 1) {
				lastProjection = "\":1";
			} else {
				lastProjection = "\":1,";
			}
			finalProjection.append("\"" + projection.get(i) + lastProjection);
		}

		//logger.debug("ISG CLOUD URL:" + apiUrl + searchJson + finalProjection + "}&limit=" + rowLimit);
		String encodedQuery = apiUrl + getUrlEncodedString(searchJson.append(finalProjection) + "}&limit=" + rowLimit);
		apiUrl = encodedQuery.replace("%24", "$").replace("%3A", ":").replace("%2C", ",").replace("%26", "&").replace("%3D", "=").replace("+", "");
		return apiUrl;
	}

	/**
	 * Method to get the EncodedUrl of input string.
	 * 
	 * @param inputString
	 * @param logger
	 * @return
	 */
	public static String getUrlEncodedString(String inputString) {
		String outputString = "";
		try {
			outputString = URLEncoder.encode(inputString, UTF_8_CHARACTERSET);
		} catch (UnsupportedEncodingException e) {
			logger.error("Unable to encode provided String :" + e);
			outputString = inputString;
		}
		return outputString;
	}
}
