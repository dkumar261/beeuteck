package com.citi.icg.qma.exception;

public class NonRecoverableDBException extends Exception {

	private static final long serialVersionUID = -4444891656281334028L;

	public NonRecoverableDBException(String message, Throwable e) {
		super(message, e);
	}

	public NonRecoverableDBException(Throwable e) {
		super(e);
	}

	public NonRecoverableDBException(String message) {
		super(message);
	}	
}