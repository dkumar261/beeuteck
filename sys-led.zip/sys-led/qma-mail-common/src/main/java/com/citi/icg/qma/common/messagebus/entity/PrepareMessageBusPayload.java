package com.citi.icg.qma.common.messagebus.entity;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.Attachment;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.persistence.InquiryDAO;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

public class PrepareMessageBusPayload {
	
	private static final Logger logger = LoggerFactory.getLogger(PrepareMessageBusPayload.class);
	private static final String CONFIG_CLIENT_ID_TO_CLIENT_NAME_MAP = "clientIdToClientNameMap";
	static InquiryDAO inquiryDao = new InquiryDAO();
	public static final String QMA_NEW_MESSAGE = "QMA.Inquiry.NewMsg";
	public static final String QMA_REPLY_MESSAGE = "QMA.Inquiry.ReplyMsg";
	public static final String LINK_ENTITY_KEY = "QMA.Inquiry.LinkMsg";
	public static final String DELINK_ENTITY_KEY = "QMA.Inquiry.DeLinkMsg";
	public static final String DEAL_ENTITY_TYPE = "Deal";
	public static final String EMAIL_KEY = "Email";

	public Data prepareDataToPublish(Inquiry inquiry, Conversation conversation,String eventName, String eventType, String eventId) {
		
		Instant currentTime = Instant.now();
		Data data = new Data();
		data.setEventName(eventName);
		data.setEventTimestampMs(currentTime.toEpochMilli());
		data.setEventType(eventType);
		data.setEventId(eventId);
		return data;
	}
	
	public Data prepareDataToPublish(Inquiry inquiry, Conversation conversation, String eventType, String eventId, List<String> entityIdsList, String clientId, String entityType) {
		
		Instant currentTime = Instant.now();
		Data data = new Data();
		data.setEventName(EMAIL_KEY);
		data.setEventTimestampMs(currentTime.toEpochMilli());
		data.setEventType(eventType);
		data.setPayload(getPayload(inquiry,currentTime,conversation,entityIdsList,clientId,entityType));
		data.setEventId(eventId);
		return data;
	}
	
	private Payload getPayload(Inquiry inquiry,Instant currentTime,Conversation conversation,List<String> entityIdsList, String clientId,String entityType) {
		Payload payload= new Payload();
		payload.setAction(conversation.getAction());
		payload.setConversationId(conversation.getId());
		payload.setInquiryId(conversation.getInquiryId());
		DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS");
		payload.setCrtDate(formatter.format(Date.from(currentTime)));
		payload.setStatus(inquiry.getStatus());
		payload.setSubject(conversation.getSubject());
		payload.setClientId(clientId);
		
		payload.setEntityType(entityType);
		payload.setEntityIds(entityIdsList.toArray(new String[entityIdsList.size()]));
		
		Map<String, String> clientIdToClientNameMap = getSenderDomainToClientIdMap();
		String clientName = StringUtils.isBlank(clientIdToClientNameMap.get(inquiry.getGfcid())) ? "" : clientIdToClientNameMap.get(inquiry.getGfcid());
		payload.setClientName(clientName);
		
		List<Attachments>  attachmentList = getAttachmentsList(conversation);
		payload.setAttachments(attachmentList.toArray(new Attachments[attachmentList.size()]));
		
		List<Recepients> recepientsList = getRecepientList(conversation);
		payload.setRecipients(recepientsList.toArray(new Recepients[recepientsList.size()]));
		return payload;
	}
	
	public List<Attachments> getAttachmentsList(Conversation conversation) {
		logger.debug("In PreparePayload.getAttachmentsList");
		List<Attachments> attachmentList = new ArrayList<>();
		List<Attachment> convAttachmentList = conversation.getAttachments();
		if(!CollectionUtils.isEmpty(convAttachmentList)) {
			for(Attachment attachment : convAttachmentList) {
				attachmentList.add(new Attachments(attachment.getId(),attachment.getName(),""));
			}
		}
		return attachmentList;
	}

	public List<Recepients> getRecepientList(Conversation conversation) {
		logger.debug("In PreparePayload.getRecepientList");
		List<Recepients> recepientsList = new ArrayList<>();
		List<ConversationRecipient> convRecipients = conversation.getRecipients();
		if(!CollectionUtils.isEmpty(convRecipients)) {
			for(ConversationRecipient recepient : convRecipients) {
				recepientsList.add(new Recepients(recepient.getToFrom(), recepient.getDisplayName(),recepient.getEmailAddr()));
			}
		}
		return recepientsList;
	}
	
	public Map<String, String> getSenderDomainToClientIdMap(){
		Map<String, String> clientIdToClientNameMap = new HashMap<>();
		try {
			if (null != QMACacheFactory.getCache().getConfigById(CONFIG_CLIENT_ID_TO_CLIENT_NAME_MAP)) {
				Config configData = QMACacheFactory.getCache().getConfigById(CONFIG_CLIENT_ID_TO_CLIENT_NAME_MAP);
				if (null != configData) {
					clientIdToClientNameMap = configData.getClientIdToClientNameMap();
				}
			}
		} catch (Exception e) {
			logger.warn("rror while populating {} : {}", CONFIG_CLIENT_ID_TO_CLIENT_NAME_MAP,e);
		}
		return clientIdToClientNameMap;
	}
}