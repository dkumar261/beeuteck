package com.citi.icg.qma.common.core.config;

import java.util.ArrayList;
import java.util.List;

/**
 * Utilities to convert database Names into Java, English, etc. <br>
 * ex: COLUMN_Name => columnName (Java) <br>
 * ex: COLUMN_Name => Column name (English)
 */
public final class NamesUtil
{
	private static final char SPACE = ' '; // Display name
	private static final char UNDERSCORE = '_'; // DB name
	private static final char DASH = '-'; // Xml name

	private NamesUtil()
	{
	}

	public static String toClassDisplayName(String name)
	{
		String name1 = lastToken(name, '.');
		return toDisplayName(name1);
	}

	public static String lastToken(String name, char delim)
	{
		String name1 = name;
		int idx = name.lastIndexOf(delim);
		if (idx >= 0)
		{
			name1 = name1.substring(idx + 1);
		}
		return name1;
	}

	public static String toDisplayName(String name)
	{
		List<String> words = splitName(name);
		List<String> wordsCapitalized = new ArrayList<>();
		
		for (int i = 0; i < words.size(); i++)
		{
			wordsCapitalized.add(Character.toUpperCase(words.get(i).charAt(0)) + words.get(i).substring(1).toLowerCase());			
		}
		
		return join(wordsCapitalized, String.valueOf(SPACE));
	}

	public static String join(List<String> words, String delimeter)
	{
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < words.size(); i++)
		{
			if (i > 0)
			{
				builder.append(delimeter);
			}
			builder.append(words.get(i));
		}
		return builder.toString();
	}

	public static String toDbName(String name)
	{
		return toConstName(name);
	}

	public static String toXmlName(String name)
	{
		List<String> words = splitName(name);
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < words.size(); i++)
		{
			if (i > 0)
			{
				builder.append(DASH);
			}
			builder.append(words.get(i).toLowerCase());
		}
		return builder.toString();
	}

	public static String toConstName(String name)
	{
		List<String> words = splitName(name);
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < words.size(); i++)
		{
			if (i > 0)
			{
				builder.append(UNDERSCORE);
			}
			builder.append(words.get(i).toUpperCase());
		}
		return builder.toString();
	}

	public static String toCamelCase(String name)
	{
		return join(splitName(name), "");

	}

	public static String dbNametoDisplayName(String name)
	{
		return join(splitDbName(name), String.valueOf(SPACE));
	}

	public static String dbNametoJavaPropertyName(String name)
	{
		return joinToJavaPropertyName(splitDbName(name));
	}

	public static String xmlNametoJavaPropertyName(String name)
	{
		return joinToJavaPropertyName(splitXmlName(name));
	}

	public static String joinToJavaPropertyName(List<String> words)
	{
		String first = words.get(0);
		if (!isAllUpper(first))
		{
			words.set(0, Character.toLowerCase(first.charAt(0)) + first.substring(1));
		}
		return join(words, "");
	}

	public static String toJavaPropertyName(String name)
	{
		return joinToJavaPropertyName(splitName(name));
	}

	public static List<String> sliptDisplayName(String name)
	{
		return splitOnDelimeter(name, SPACE);
	}

	public static List<String> splitName(String name)
	{
		List<String> nameList = splitCamelCase(name);

		if (name.indexOf(UNDERSCORE) >= 0)
		{
			nameList = splitDbName(nameList);
		}

		if (name.indexOf(DASH) >= 0)
		{
			nameList = splitXmlName(nameList);
		}

		if (name.indexOf(SPACE) >= 0)
		{
			nameList = splitDisplayName(nameList);
		}

		return nameList;
	}

	public static boolean isAllLower(String str)
	{
		for (int i = 0; i < str.length(); i++)
		{
			if (Character.isUpperCase(str.charAt(i)))
			{
				return false;
			}
		}
		return true;
	}

	public static boolean isAllUpper(String str)
	{
		for (int i = 0; i < str.length(); i++)
		{
			if (Character.isLowerCase(str.charAt(i)))
			{
				return false;
			}
		}
		return true;
	}

	public static List<String> splitOnDelimeter(String name, char delemiter)
	{
		List<String> words = new ArrayList<>();
		int length = name.length();
		int start = 0;
		for (int i = 0; i < length; i++)
		{
			if (i > start && name.charAt(i) == delemiter)
			{
				words.add(name.substring(start, i));
				//i++;//Sonar Fix-Refactor the code in order to not assign to this loop counter from within the loop body
				start = i+1;
			}
		}
		if (start < length)
		{
			words.add(name.substring(start));
		}
		return words;
	}

	private static String camleCaseWord(String word, boolean force)
	{
		if (!force && isAllUpper(word))
		{
			return word;
		}
		return Character.toUpperCase(word.charAt(0)) + word.substring(1).toLowerCase();
	}
	
	private static List<String> splitCamelCase(String name)
	{
		List<String> words = new ArrayList<>();
		StringBuilder builder = new StringBuilder();
		boolean prevUpper = false;
		int length = name.length();
		for (int i = 0; i < length; i++)
		{
			char ch = name.charAt(i);
			boolean upperCase = Character.isUpperCase(ch) || Character.isDigit(ch);
			boolean flag = false;
			if(i > 0 && upperCase)
				flag = true;
			if (flag && !prevUpper || (i + 1 < length && Character.isLowerCase(name.charAt(i + 1))))//sonar fix reduce no of condition less then 4 it shall be
			{
				words.add(builder.toString());
				builder = new StringBuilder();
				
			}
			builder.append(ch);
			prevUpper = upperCase;
		}
		words.add(builder.toString());
		return words;
	}
	
	private static List<String> splitXmlName(String name)
	{
		boolean allLower = isAllLower(name);
		List<String> words = splitOnDelimeter(name, DASH);
		for (int i = 0; i < words.size(); i++)
		{
			String word = words.get(i);
			words.set(i, camleCaseWord(word, allLower));
		}
		return words;
	}

	private static List<String> splitDbName(String name)
	{
		boolean allUpper = isAllUpper(name);
		List<String> words = splitOnDelimeter(name, UNDERSCORE);
		for (int i = 0; i < words.size(); i++)
		{
			String word = words.get(i);
			words.set(i, camleCaseWord(word, allUpper));
		}
		return words;
	}
	
	private static List<String> splitDbName(List<String> nameList)
	{
		List<String> list = new ArrayList<>();
		for (String name : nameList)
		{
			List<String> l = splitDbName(name);
			list.addAll(l);
		}
		return list;
	}
	
	private static List<String> splitXmlName(List<String> nameList)
	{
		List<String> list = new ArrayList<>();
		for (String name : nameList)
		{
			List<String> l = splitXmlName(name);
			list.addAll(l);
		}
		return list;
	}
	
	private static List<String> splitDisplayName(List<String> nameList)
	{
		List<String> list = new ArrayList<>();
		for (String name : nameList)
		{
			List<String> l = splitOnDelimeter(name, SPACE);
			list.addAll(l);
		}
		return list;
	}
}
