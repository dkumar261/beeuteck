/**
 * 
 */
package com.citi.icg.qma.common.server.dao;


import java.util.Date;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

/**
 * 
 *
 */
@Entity(value = "ObjectStoreContentAudit", noClassnameStored = true)
public class ObjectStoreContentAudit {
	@Id
	private String objectId;
	private Long convId;
	private Long inquiryId;
	private Date uploadedOn;
	private String bucketName;
	private String bucketRegion;
	public String getObjectId() {
		return objectId;
	}
	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}
	public Long getConvId() {
		return convId;
	}
	public void setConvId(Long convId) {
		this.convId = convId;
	}
	public Long getInquiryId() {
		return inquiryId;
	}
	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}
	public Date getUploadedOn() {
		return uploadedOn;
	}
	public void setUploadedOn(Date uploadedOn) {
		this.uploadedOn = uploadedOn;
	}
	public String getBucketName() {
		return bucketName;
	}
	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}
	public String getBucketRegion() {
		return bucketRegion;
	}
	public void setBucketRegion(String bucketRegion) {
		this.bucketRegion = bucketRegion;
	}
	
	
}
