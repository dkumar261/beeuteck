package com.citi.icg.qma.common.core.exception;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetAddress;

import org.apache.commons.lang.StringUtils;

import com.citi.icg.qma.common.core.util.EmailUtil;

/**
 * This is the base class for all exceptions in the Communicator Application.
 */
public class CommunicatorException extends Exception
{
	private static String env = System.getProperty("icg.env");
	private static String sendEmail =  System.getProperty("sendemail");
	private static boolean shouldSendEmail =  false;
	// --- Constructor(s) ---
	static
	{
		if ("Y".equalsIgnoreCase(sendEmail))
		{
			shouldSendEmail = true;
		}
				
	}

	/**
	 * Constructs an CommunicatorException with a detail message.
	 * 
	 * @param message the detail message.
	 */
	public CommunicatorException(String message)
	{
		super(message);
	}

	/**
	 * Constructs an CommunicatorException with a root cause of the error.
	 * 
	 * @param message the detail message.
	 * @param cause the root cause of the error.
	 */
	public CommunicatorException(String message, Throwable cause)
	{
		super(message, cause);
		
		String subjectMessage ="";
		String messageWithHost = message;
		try
		{
			if (StringUtils.isNotBlank(message))
			{
				subjectMessage= subjectMessage.length() > 200 ? subjectMessage.substring(0, 199) : message; //<- sonar fix
				
			}
			
			InetAddress hostNameAdd = InetAddress.getLocalHost();
			String currentHost = null != hostNameAdd ? hostNameAdd.toString() : "";
			
			messageWithHost = currentHost + " :::::-----> " + message;
		}
		catch (Exception e)
		{
			// TODO: handle exception
		}
		
		if (shouldSendEmail)
		{
			EmailUtil.sendEmailToSupport(null, "INFO," + env + ": "+  subjectMessage,  messageWithHost, "XXXX", cause);
		}
	}

	// --- Static Methods ---

	/**
	 * Retrieves a string representation of the exception.
	 */
	public static String asString(Throwable throwable)
	{
		if (throwable == null)
			return null;

		StringWriter buffer = new StringWriter();
		PrintWriter writer = new PrintWriter(buffer);
		throwable.printStackTrace(writer);
		writer.flush();

		return buffer.toString();

	}

}
