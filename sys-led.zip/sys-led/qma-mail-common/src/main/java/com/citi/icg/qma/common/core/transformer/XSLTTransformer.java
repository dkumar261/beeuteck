package com.citi.icg.qma.common.core.transformer;

import org.apache.commons.collections4.Transformer;

public class XSLTTransformer implements Transformer
{
    public Object transform(Object object) throws TransformationExcept
    {
        return null;
    }
}
