package com.citi.icg.qma.common.core.util.encrypt;

public class DataEncrpyptDecryptException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4337893042069166871L;
	
	public DataEncrpyptDecryptException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public DataEncrpyptDecryptException(String message) {
		super(message);
	}

}
