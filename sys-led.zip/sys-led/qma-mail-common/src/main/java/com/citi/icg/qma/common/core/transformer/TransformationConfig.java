package com.citi.icg.qma.common.core.transformer;

import java.util.HashMap;
import java.util.Map;

public class TransformationConfig
{
	private Map<String, TransformationConfigEntry> configMap;//sonar fix return type and defined type should be interface
	private Map<String, TransformationConfigEntry> transformerNameMap;
	
	public TransformationConfig()
	{
		configMap = new HashMap<>();
		transformerNameMap = new HashMap<>();
	}
	
	public void addTransformationConfigEntry(TransformationConfigEntry entry)
	{
		if (entry.getName() != null)
		{
			transformerNameMap.put(entry.getName(), entry);
		}
		
		if(entry.getSourceClassName() != null)
		{
			configMap.put(entry.getSourceClassName() + entry.getDestinationClassName(), entry);
		}
	}

	public TransformationConfigEntry getTransformationConfigEntry(String transformerName)
	{
		return transformerNameMap.get(transformerName);
	}

	public TransformationConfigEntry getTransformationConfigEntry(String sourceType, String destinationType)
	{
		return configMap.get(sourceType + destinationType);
	}

	public Map<String, TransformationConfigEntry> getConfigMap()
	{
		return configMap;
	}

	public void setConfigMap(Map<String, TransformationConfigEntry> configMap)
	{
		this.configMap = configMap;
	}

	public Map<String, TransformationConfigEntry> getTransformerNameMap()
	{
		return transformerNameMap;
	}

	public void setTransformerNameMap(
			Map<String, TransformationConfigEntry> transformerNameMap)
	{
		this.transformerNameMap = transformerNameMap;
	}
	
	
}
