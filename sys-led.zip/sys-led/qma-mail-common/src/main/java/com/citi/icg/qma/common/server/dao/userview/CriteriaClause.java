package com.citi.icg.qma.common.server.dao.userview;

public class CriteriaClause
{

	//private CompareOperator operator;
	private String propertyName;
	private String value;

	public CriteriaClause(CompareOperator operator, String propertyName,
			String value)
	{
		super();
		//this.operator = operator;
		this.setPropertyName(propertyName);
		this.setValue(value);
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
