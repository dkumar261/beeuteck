package com.citi.icg.qma.common.core.transformer;

import org.apache.commons.collections4.Transformer;

public class ObjectToXMLTransformer implements Transformer
{
    private DefaultMarshaller defMrshaller;
    public ObjectToXMLTransformer(Class<?> classType)
    {
        this.defMrshaller = new DefaultMarshaller(classType);
    }
    
    public Object transform(Object object) throws TransformationExcept
    {
        String xml = null;
        
        xml = defMrshaller.marshal(object, false);
        
        return xml;
    }
}
