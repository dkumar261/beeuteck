package com.citi.icg.qma.common.core.util;

/**
 *Declares Character constants.
 */
public final class CharConstants
{
	private CharConstants()
	{

	}

	public static final Character COMMA = ',';
	public static final Character DOT = '.';
	public static final Character SEMICOLON = ';';
	public static final Character COLON = ':';
	public static final Character QUESTIONMARK = '?';
	public static final Character LBRACE = '{';
	public static final Character RBRACE = '}';
	public static final Character LPAREN = '(';
	public static final Character RPAREN = ')';
	public static final Character LSQBRACKET = '[';
	public static final Character RSQBRACKET = ']';
	public static final Character BITOR = '|';
	public static final Character BITXOR = '^';
	public static final Character BITAND = '&';
	public static final Character EQ = '=';
	public static final Character GT = '>';
	public static final Character LT = '<';
	public static final Character SQUOTE = '\'';
	public static final Character DQUOTE = '"';
	public static final Character ASTERISK = '*';
	public static final Character NEW_LINE = '\n';
	public static final Character CARRIAGE_RETURN = '\r';
	public static final Character SPACE = ' ';
	public static final Character HYPHEN = '-';
	public static final Character UNDERSCORE = '_';
	public static final Character PERCENTRAGE = '%';
	public static final Character FORWARDSLASH = '/';
	public static final Character BACKWARDWARDSLASH = '\\';
	public static final Character SINGLE_QUOTE = '\'';

	// Strings
	public static final String ASTERISK_STRING = "*";
	public static final String CARRIAGE_RETURN_STRING = "\r";
	public static final String AND = "AND";
	public static final String FALSE = "FALSE";
	public static final String NEWLINE_STRING = "\n";
	public static final String TAB_STRING = "\t";
	public static final String SPACE_STRING = " ";
	public static final String NUMBER_SIGN = "#";
	public static final String EMPTY_STRING = "";
	public static final String NEWLINE_TAB = "\n\t";
	public static final String TILDA = "~";
	public static final String N = "N";
	public static final String EQUAL = "=";
	public static final String QUESTION_MARK = "?";
	public static final String DOT_STRING = ".";
	public static final String UNDERSCORE_STRING = "_";
	public static final String COMMA_STRING = ",";
	public static final String DOUBLE_QUOTE = "\"";
	public static final String LPAREN_STRING = "(";
	public static final String RPAREN_STRING = ")";
	public static final String QUESTIONMARK_STRING = "?";
	public static final String AT_RATE = "@";
	public static final String HYPHEN_STRING = "-";
	public static final String EXCLAMATION_STRING = "!";
	public static final String FORWARDSLASH_STRING = "/";
	public static final String COLON_STRING = ":";
	public static final String AND_STRING = "&";
	
}
