package com.citi.icg.qma.common.core.transformer;

public interface TransformerNames
{
	public static final String JAVA2XML = "JavaObjectToXMLTransformer";
	public static final String XML2JAVA = "XMLToJavaObjectTransformer";
}
