package com.citi.icg.qma.common.core.subscriber.mails;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.MailServiceGenericUtil;
import com.citi.icg.qma.common.core.util.MsgSourceType;
import com.citi.icg.qma.common.server.dao.*;
import com.citi.icg.qma.common.server.dao.persistence.MongoMorphiaDAO;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.ReadPreference;
import com.mongodb.WriteResult;
import dev.morphia.Key;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;


public class MongoExtInquiryDAO extends MongoMorphiaDAO
{

	private static Logger logger = LoggerFactory.getLogger(MongoExtInquiryDAO.class);
		
	private static final String INQUIRY_DIRECTION_IN = "IN";
	private static final String STATUS_OPEN = "Open";
	private static final String TO_CATEGORY = "TO";
	private static final String CC_CATEGORY = "CC";
	private static final String BCC_PROCESSING_LOG_PREFIX = "### BCC PROCESSING : ";
	public static final String SENDER_DOMAIN_CITI = "(CITI)";
	public static final String RECIPIENT_FROM = "FROM";
	public static final String MSG_SOURCE_TYPE_KEY = "msgSourceType";
	public static final String INQUIRY_ID_KEY = "inquiryId";
	
	private static MongoExtInquiryDAO instance = null;
	
	
	public static synchronized MongoExtInquiryDAO getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used

		if (instance == null) {
			instance = new MongoExtInquiryDAO();
		}

		return instance;
	}
	
	public Long getInquiryIdForInqMessageRefId(Long inquiryMessageRefId){
		
		if(inquiryMessageRefId==null){
			throw new IllegalArgumentException("inquiryMessageRefId is null");
		}
		
		InquiryMessageRef ref=mongoDatastore.find(InquiryMessageRef.class)
				.field("_id").equal(inquiryMessageRefId)
				.retrievedFields(true, INQUIRY_ID_KEY)
				.get();
		
		Long inquiryId=ref.getInquiryId();
		
		logger.debug("Found inquiryid {}, for inquiryMessageRefId {} ",inquiryId,inquiryMessageRefId);
		
		return inquiryId;
	}
	
	public Map<String, String> getInquiryDetailsForReferences(String references, MsgSourceType msgSourceType) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		HashMap<String, String> map = new HashMap<String, String>();
		//Sonar Fix -- Remove useless assignments
		InquiryMessageRef inquiryMessageRef = null;
		//Code Refactor for reuse
		String[] referencesArray = MailServiceGenericUtil.extractMailReferencesToRefArray(references);
		
		Query<InquiryMessageRef> query = mongoDatastore.createQuery(InquiryMessageRef.class).filter("messageId in", referencesArray);
		if (MsgSourceType.personal.equals(msgSourceType)) {
			query.and(query.criteria(MSG_SOURCE_TYPE_KEY).equal(MsgSourceType.personal));
		} else {
			query.and(query.criteria(MSG_SOURCE_TYPE_KEY).notEqual(MsgSourceType.personal));
		}
		query.order("-_id");
		query.limit(1);
		List<InquiryMessageRef> inquiryMessageRefList = query.asList();
		

		
		if (inquiryMessageRefList != null && !inquiryMessageRefList.isEmpty())//Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
		{
			inquiryMessageRef = inquiryMessageRefList.get(0);
			logger.info("Reference matched successful with messageId: {}, RefId: {}" , inquiryMessageRef.getMessageId(),inquiryMessageRef.getId());
		}
		else
		{
			//do not use same query variables in mongodb morphia..
			logger.info("Inside LatestMessageId check..");			
			Query<InquiryMessageRef> query1 = mongoDatastore.createQuery(InquiryMessageRef.class).filter("latestMessageId in", referencesArray);
			if (MsgSourceType.personal.equals(msgSourceType)) {
				query1.and(query1.criteria(MSG_SOURCE_TYPE_KEY).equal(MsgSourceType.personal));
			} else {
				query1.and(query1.criteria(MSG_SOURCE_TYPE_KEY).notEqual(MsgSourceType.personal));
			}
			query1.order("-_id");
			query1.limit(1);
			
			inquiryMessageRefList = query1.asList();
		
			if (inquiryMessageRefList != null && !inquiryMessageRefList.isEmpty())//Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
			{
				inquiryMessageRef = inquiryMessageRefList.get(0);
				logger.info("Inside LatestMessageId check, Got match RefId: {}",inquiryMessageRef.getId());
			}
			else{
				//C153176-402-Different Inquiry ID created for the same query
				//Final match with All reference audit list
				inquiryMessageRef = matchMailReferenceWithRefAudit(referencesArray, msgSourceType);
					
			}
		}

		if (inquiryMessageRef != null)
		{	
			getInquiryRefMapForRecord(map, inquiryMessageRef);
		}

		return map;
	}

	private void getInquiryRefMapForRecord(Map<String, String> map, InquiryMessageRef inquiryMessageRef) {
		if( null != map && null != inquiryMessageRef ) {
			map.put("referenceGroupId", inquiryMessageRef.getId().toString());
			map.put("messageId", inquiryMessageRef.getMessageId());
			map.put("threadTopic", inquiryMessageRef.getThreadTopic());
			map.put("lob", inquiryMessageRef.getLob());
			if (inquiryMessageRef.getInquiryId() != null ) {
				Long inquiryId = Long.valueOf(inquiryMessageRef.getInquiryId());
				map.put(INQUIRY_ID_KEY, inquiryId.toString());
			}
		}
	}

	//C153176-402-Different Inquiry ID created for the same query
	private InquiryMessageRef matchMailReferenceWithRefAudit(String[] incomingMailReferenceArray, MsgSourceType msgSourceType)
	{
		logger.info("Inside matchMailReferenceWithRefAudit ");
		InquiryMessageRef matchedInqMessageRefRecord = null;
		Query<InquiryMessageRef> query = mongoDatastore.createQuery(InquiryMessageRef.class).filter("referencesAudit in", incomingMailReferenceArray);
		if (MsgSourceType.personal.equals(msgSourceType)) {
			query.and(query.criteria(MSG_SOURCE_TYPE_KEY).equal(MsgSourceType.personal));
		} else {
			query.and(query.criteria(MSG_SOURCE_TYPE_KEY).notEqual(MsgSourceType.personal));
		}
		query.order("-crtDate");
		List<InquiryMessageRef> inquiryMessageRefList = query.asList();
		if (inquiryMessageRefList != null && !inquiryMessageRefList.isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
		{
			matchedInqMessageRefRecord = inquiryMessageRefList.get(0);
			logger.info("Inside matchMailReferenceWithRefAudit- Got match.{}, list has {} records ",matchedInqMessageRefRecord.getInquiryId() ,inquiryMessageRefList.size());
			return matchedInqMessageRefRecord;
		}
		return matchedInqMessageRefRecord;
	}

	public void updateExtInquiryMessageRefGrpId(Long refGroupId, String latestMessageId, String references, String threadTopic)
	{

			Set<String> refAuditList = new HashSet<>();
			refAuditList.add(latestMessageId);

			if (null != references)
			{
				refAuditList.addAll(Arrays.stream(MailServiceGenericUtil.extractMailReferencesToRefArray(references)).collect(Collectors.toSet()));
			}
			
			DBObject updateReferenceAudField = new BasicDBObject();
			BasicDBObject updateReferenceObj = new BasicDBObject();
			updateReferenceAudField.put("$addToSet", new BasicDBObject("referencesAudit", new BasicDBObject("$each", refAuditList)));
			updateReferenceObj.put("latestMessageId", latestMessageId); 
			updateReferenceObj.put("modDate",new Date());
            if(null != references) {
            	updateReferenceObj.put("references", references);
            }
            if(StringUtils.isNotBlank(threadTopic)) {
            	updateReferenceObj.put("threadTopic", threadTopic);
            }
            updateReferenceAudField.put("$set", updateReferenceObj);
			DBObject updateQuery = new BasicDBObject();
			updateQuery.put("_id", refGroupId);
			mongoDatastore.getCollection(InquiryMessageRef.class).update(updateQuery, updateReferenceAudField,false, true);
			
	}
	
	public void updateExtInquiryMessageRefGrpId(Long refGroupId, String latestMessageId, String references)
	{
		updateExtInquiryMessageRefGrpId(refGroupId, latestMessageId, references, null);
	}
	
	public Long insertDBAuditRecords(InquiryAudit inquiryAudit) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one//Sonar fix remove useless parameter
	{
		Long auditId = null;
		try
		{
			Key<InquiryAudit> key = mongoDatastore.save(inquiryAudit);

			auditId = (Long) key.getId();
		}
		catch (Exception e)
		{
			throw new CommunicatorException("Error in insertDBRecords", e);
		}

		return auditId;
	}

	//Data input should be in CAPS letter, as Cache is all in CAPS to make it case insensitive.
	public static Long getInternalGroupIdForReceivedGroupAlias(String groupName, QMACache cache) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
	    
		Long groupId = null;
		try
		{
			if (groupName != null)
			{
				groupId = cache.getGroupCodeToIdMap().get(groupName.toUpperCase()); // <<-- sonar fix Change this condition so that it does not always evaluate to "false"
				
				if (groupId == null)
				{
					logger.info("No Matching alias for group Name in method getInternalGroupIdForReceivedGroupAlias : {}", groupName);
				}
				else
				{
					logger.info("groupId for groupAlias: {} in getInternalGroupIdForReceivedGroupAlias : {}",groupName, groupId);
				}
			}

		}
		catch (Exception e)
		{
			throw new CommunicatorException(MongoExtInquiryDAO.class + " Issue happened in method getInternalGroupIdForReceivedGroupAlias ", e);
		}
		return groupId;
	}

	//Data input should be in CAPS letter, as Cache is all in CAPS to make it case insensitive.
	public static Long getInternalGroupIdForReceivedGroupEmail(String groupEmail, QMACache cache) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Long groupId = null;
		try
		{
			if (groupEmail != null)
			{
				groupId = cache.getGroupEmailToIdMap().get(groupEmail); //<<-- sonar fix Change this condition so that it does not always evaluate to "false

				if (groupId == null)
				{
					logger.info("No Matching alias for group Email in method getInternalGroupIdForReceivedGroupEmail : {}", groupEmail);
				}
				else
				{
					logger.info("groupId for email address: {} in GroupEmailToIdMap cache found is : {}",groupEmail, groupId);
				}
					
			}

		}
		catch (Exception e)
		{
			throw new CommunicatorException(MongoExtInquiryDAO.class + " Issue happened in method getInternalGroupIdForReceivedGroupEmail ", e);
		}
		return groupId;
	}

	public List<Long> getGrpIdsNeedNewVersion(Inquiry inquiry, List<Long> toCcGroupIdList)
	{
		if (toCcGroupIdList.isEmpty())//Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
			return toCcGroupIdList;
		List<Workflow> dbWorkflows = inquiry.getWorkflows();

		List<Long> recordsFound = new ArrayList<>();
		if(dbWorkflows != null)
		{
			for (Workflow obj : dbWorkflows)
			{
				if (obj.getDirection().equals(INQUIRY_DIRECTION_IN) && toCcGroupIdList.contains(obj.getAssignedGroupId()))
				{
					recordsFound.add(obj.getAssignedGroupId());
				}
			}
		}
		toCcGroupIdList.removeAll(recordsFound);
		return toCcGroupIdList;
	}

	public boolean isWorkflowCreatedForCurrentIndividualMailbox(Inquiry inquiry, long userGroupId) {
		boolean workFlowCreatedForMailbox = false;
		if (null != inquiry && null != inquiry.getWorkflows()) {
			for (Workflow workflow : inquiry.getWorkflows()) {
				if (workflow.getDirection().equals(INQUIRY_DIRECTION_IN) && workflow.getAssignedGroupId() == userGroupId) {
					workFlowCreatedForMailbox = true;
				}
			}
		}
		return workFlowCreatedForMailbox;
	}


	public Inquiry updateOpenVersionGrpStr(Inquiry dbInquiryInfo , Conversation convLatest, QMACache cache) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
	    Map<Long, String> groupIdToNameMap = cache.getGroupIdToNameMap();
		StringBuilder latestToCCGroups = new StringBuilder();
		if (dbInquiryInfo == null)
		{
			return null;
		}
		Inquiry dbInqInfo = dbInquiryInfo;// Sonar Fix -- Method parameters, caught exceptions and foreach variables should not be reassigned  

		List<ConversationRecipient> recipientList = convLatest.getRecipients();

		for (ConversationRecipient recp : recipientList)
		{
			if (recp.getGroupId() != null && (TO_CATEGORY.equals(recp.getToFrom()) || CC_CATEGORY.equals(recp.getToFrom()))) // Atleast one email addr, mark it as external
			{
				latestToCCGroups.append(recp.getDisplayName() + ";");
			}
		}

		String allToCCGroups = getAllToCCgroups(dbInqInfo.getWorkflows(), dbInqInfo.getAllToCCGrps(), groupIdToNameMap);
		
		Set<String> latestToCCUserList = getRecipientToCcUserNames(recipientList);
		String latestToCCUser = convertSetToString(latestToCCUserList);

		List<Workflow> openVersionList = getOpenInquiryVersionDOList(dbInqInfo);
		String openGroups = "";
		String openUsers = "";
		if (openVersionList != null && !openVersionList.isEmpty())//Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
		{
			Set<Long> groupIdsWithVersion = new HashSet<>();
			Set<String> usrStrWithVersion = new HashSet<>();

			for (Workflow version : openVersionList)
			{

				groupIdsWithVersion.add(version.getAssignedGroupId());
			
				if (null != version.getAssignedUserName() && null != version.getAssignedUserId() && !version.getAssignedUserId().contains("@") && version.getAssignedGroupId() != -1L)
				{
					usrStrWithVersion.add(version.getAssignedUserName());
				}

			}
			Set<String> latestGroupsWithVersions = getLatestGroupsWithVersions(groupIdsWithVersion, groupIdToNameMap);
			openGroups = convertSetToString(latestGroupsWithVersions);
			openUsers = convertSetToString(usrStrWithVersion);
		}
		dbInqInfo = updateInquiryInfo(openGroups, openUsers, latestToCCUser, latestToCCGroups.toString(),allToCCGroups.toString(), dbInqInfo);
		logger.info("Returning from updateOpenVersionGrpStr() for - {}", dbInqInfo.getAction());

		return dbInqInfo;

	}

	private static Set<String> getRecipientToCcUserNames(List<ConversationRecipient> recipientList)
	{
		Set<String> userNamesList = new HashSet<>();
		if (recipientList != null)
		{
			for (ConversationRecipient inqRecp : recipientList)
			{
				if ((TO_CATEGORY.equals(inqRecp.getToFrom()) || CC_CATEGORY.equals(inqRecp.getToFrom())) && inqRecp.getGroupId() == null && inqRecp.getDisplayName() != null)
				{
					userNamesList.add(inqRecp.getDisplayName());
				}
			}
		}
		return userNamesList;
	}

	private static Set<String> getLatestGroupsWithVersions(Set<Long> groupIdsWithVersion, Map<Long, String> groupIdToNameMap )
	{
		Set<String> latestToCcGroupCodes = new HashSet<>();
		Set<Long> groupsWithoutGroupCode = new HashSet<>();
		for (Long groupId : groupIdsWithVersion)
		{
			String groupCode = groupId==null ?null:groupIdToNameMap.get(groupId);
			if (groupCode != null)
			{
				latestToCcGroupCodes.add(groupCode);
			}
			else
			{
				groupsWithoutGroupCode.add(groupId);
			}
		}
		
		return latestToCcGroupCodes;
	}

	private static String convertSetToString(Set<String> toCcGroupCodes)
	{
		StringBuilder sb = new StringBuilder();
		for (String s : toCcGroupCodes)
		{
			sb.append(s + ";");
		}
		if (sb.length() > 1)
		{
			sb.deleteCharAt(sb.length() - 1);
		}
		return sb.toString();
	}

	public List<Conversation> getInquiryConversationList(Long inquiryId)
	{
		Query<Conversation> query = mongoDatastore.find(Conversation.class, INQUIRY_ID_KEY, inquiryId).order("-modDate").limit(1);
		List<Conversation> convList = query.asList();
		if(null != convList && !convList.isEmpty()) {
			logger.info("conv list size::: {} ::id: {}", convList.size(), convList.get(0).id);
		} 
		return convList;
	}

	private static List<Workflow> getOpenInquiryVersionDOList(Inquiry inquiry)
	{
		List<Workflow> workflowList = inquiry.getWorkflows();
		List<Workflow> finalWorkflowList = new ArrayList<>();
		if (workflowList != null)
		{
			for (Workflow workflow : workflowList)
			{
				if (workflow.getStatus().equals(STATUS_OPEN) && workflow.getDirection().equals(INQUIRY_DIRECTION_IN))
				{
					finalWorkflowList.add(workflow);
				}

			}
		}
		return finalWorkflowList;
	}

	public Inquiry  updateInquiryInfo(String openGroups, String openUsers, String latestToCCUser, String latestToCCGroups, String allToCCGroups, Inquiry inquiry)
	{
		// Sonar Fix -- Method parameters, caught exceptions and foreach variables should not be reassigned  
		
		try
		{
			if (openGroups != null && null !=  getSubString(openGroups))
			{
				inquiry.setOpenGroups(openGroups);
			}
			if (openUsers != null && null != getSubString(openUsers))
			{
				inquiry.setOpenUsers(openUsers);
			}
			if (latestToCCUser != null && null != getSubString(latestToCCUser))
			{
				inquiry.setLatestToCCUser(latestToCCUser);
			}
			if (latestToCCGroups != null && null !=  getSubString(latestToCCGroups))
			{
				inquiry.setLatestToCCGroups(latestToCCGroups);
			}
			if (allToCCGroups != null && null != getSubString(allToCCGroups))
			{
				inquiry.setAllToCCGrps(allToCCGroups);
			}
		}
		catch (Exception e)
		{
			logger.error(MongoExtInquiryDAO.class + " Issue happened in updateInquirySummaryInfo for inquiryId:  " + inquiry.getAction(), e);
		}
		return inquiry;
	}

	private static String getSubString(String str)
	{
		String st = str;// Sonar Fix -- Method parameters, caught exceptions and foreach variables should not be reassigned   
		
		if (st.length() > 4000)
		{
			st = st.substring(0, 3990);
			st = st.substring(0, st.lastIndexOf(";"));

		}
		st = st.replace("'", "");
		return st;
	}
	
	public List<OutBoundEmails> getAllExternalAuditEmailsToSend(Long minUnprocessId) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		List<OutBoundEmails> inquiryAuditList = new ArrayList<>();

		try
		{
			Query<OutBoundEmails> query = mongoDatastore.createQuery(OutBoundEmails.class);
			query.and(query.criteria("_id").greaterThanOrEq(minUnprocessId), 
					query.criteria("processFlag").equal("N"));
			
			query.order("id");
			query.limit(100);
			
						inquiryAuditList = query.asList();
			
		}
		catch (Exception e)
		{
			throw new CommunicatorException("Issue in getting all email message for method getAllEmailMessage:  ", e);
		}

		return inquiryAuditList;
	}
	
	
	
	public  Map<Long, HashMap<String, String>>  getReferencesAndLatestMsgIdForInquiry(Long[] inquiryIdArray) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		HashMap<Long, HashMap<String, String>> referencesAndLatestMsgIdForInquiryMap = new HashMap<Long, HashMap<String, String>>();
		
		
		try
		{
			Query<InquiryMessageRef> query = mongoDatastore.createQuery(InquiryMessageRef.class);
			query.filter("inquiryId in", inquiryIdArray);
			List<InquiryMessageRef> inquiryMessageRefList = query.asList();

			if ( inquiryMessageRefList != null && !inquiryMessageRefList.isEmpty() )//Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
			{
				for (InquiryMessageRef inquiryMessageRef : inquiryMessageRefList)
				{
					HashMap<String, String>  refMsgMap = new HashMap<>();
					
					String references = inquiryMessageRef.getReferences();
					String latestMessageId = inquiryMessageRef.getLatestMessageId();		
					
					refMsgMap.put("references", references);
					refMsgMap.put("latestMessageId", latestMessageId);
					
					referencesAndLatestMsgIdForInquiryMap.put(inquiryMessageRef.getInquiryId(),refMsgMap);

				}
			}

		}
		catch (Exception e)
		{
			throw new CommunicatorException(MongoExtInquiryDAO.class + " Issue happened in method getReferencesForInquiry ", e);
		}

		return referencesAndLatestMsgIdForInquiryMap;
	}
	
	public void setMessageProcessed(Long extAuditRawId) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{

		try
		{
			Query<OutBoundEmails> query = mongoDatastore.createQuery(OutBoundEmails.class);
			query.criteria("id").equal(extAuditRawId);
			UpdateOperations<OutBoundEmails> ops = mongoDatastore.createUpdateOperations(OutBoundEmails.class).set("processFlag","Y");
			mongoDatastore.update(query, ops);
		}
		catch (Exception e)
		{
			throw new CommunicatorException(MongoExtInquiryDAO.class + " Issue in setting message processed for id :  " + extAuditRawId, e);
		}
	}
	
	public  String getDefaultExternalEmailForSenderGroup(Long groupId, QMACache cache) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		String extEmailId = null;
		try
		{
			extEmailId = groupId==null ?null:cache.getGroupIdToEmailMap().get(groupId);

			if (extEmailId == null)
			{
				logger.error("{} No default email  for group id in method getDefaultExternalEmailForGroupId : {}" ,MongoExtInquiryDAO.class, groupId);
			}

		}
		catch (Exception e)
		{
			throw new CommunicatorException(MongoExtInquiryDAO.class + " Issue happened in method getDefaultExternalEmailForGroup ", e);
		}
		return extEmailId;
	}
	
	public Inquiry getInquiry(Long inquiryId, Logger logger)
	{
		logger.info("Inquiry id in getInquiry() :: {}", inquiryId);
		Inquiry inquiry = mongoDatastore.get(Inquiry.class, inquiryId);
		return inquiry;
	}

	public Inquiry getInquirySubjectInfo(Long inquiryId, Logger logger)
	{
		logger.info("Inquiry id in getInquirySubjectInfo() :: {}", inquiryId);
		Inquiry inquiry=mongoDatastore.find(Inquiry.class)
				.field("_id").equal(inquiryId)
				.retrievedFields(true, "_id","origSubject","subject","status","modDate")
				.useReadPreference(ReadPreference.secondary())
				.get();
		return inquiry;
	}
	
	public Conversation getConversation(Long conversationId)
	{
		logger.info("Conversation id in getConversation() :: {}",conversationId);
		Conversation conversation = mongoDatastore.get(Conversation.class, conversationId);
		return conversation;
	}
	public List<Conversation> getConversation(Long[] conversationIdArray, Logger logger)
	{
		logger.debug("Conversation id in getConversation() :: {}", (null != conversationIdArray ? Arrays.toString(conversationIdArray):conversationIdArray));
		Query<Conversation> query = mongoDatastore.createQuery(Conversation.class).filter("id in", conversationIdArray);
		return query.asList();
	}
	
	private String getAllToCCgroups(List<Workflow> workFlowList, String dbAllToCCGroups, Map<Long, String> groupIdToNameMap)
	{
		StringBuilder allToCCGroup = new StringBuilder();
		
		allToCCGroup.append(dbAllToCCGroups != null ? dbAllToCCGroups : "");

		for (Workflow workflow : workFlowList)
		{
			String groupCode = workflow.getAssignedGroupId()==null ?null:groupIdToNameMap.get(workflow.getAssignedGroupId());
			if (!StringUtils.isEmpty(groupCode) && workflow.getDirection().equals("IN") && allToCCGroup.indexOf(groupCode) == -1)
			{
				allToCCGroup.append(groupCode + ";");
			}
		}

		return allToCCGroup.toString();
	}
	
	//Method to get BccGroup data from StaticData collection entry 
	public List<Group> getBccGroupFromStaticData(QMACache cache) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		List<Group> bccGroupList = null;
		StaticData staticData = null;
		Query<StaticData> query = null;
		
		try
		{
			query = mongoDatastore.createQuery(StaticData.class);
			staticData = query.get();
			bccGroupList = new ArrayList<>();
			
			if(staticData!=null && staticData.getBccGroupIdList()!=null)
			{
				List<Long> bccGroupIdList = staticData.getBccGroupIdList();
				
				if(bccGroupIdList!=null && !bccGroupIdList.isEmpty())
				{
					for(Long bccGroupId:bccGroupIdList)
					{
						Map<Long, String> groupIdToNameMap = cache.getGroupIdToNameMap();
						Map<Long, String> groupIdToMailMap = cache.getGroupIdToEmailMap();
						Group bccGroup = new Group();
						
						bccGroup.id = bccGroupId;
						if(bccGroupId!=null && groupIdToNameMap != null && groupIdToNameMap.containsKey(bccGroupId))//nullchk
						{
							bccGroup.setGroupName(groupIdToNameMap.get(bccGroupId));
						}
						
						if(bccGroupId!=null && groupIdToMailMap != null && groupIdToMailMap.containsKey(bccGroupId))//nullchk
						{
							bccGroup.setGroupEmail(groupIdToMailMap.get(bccGroupId));
						}
						
						//Add to group list only if the data is not null or blank
						if(!StringUtils.isBlank(bccGroup.getGroupName()) && !StringUtils.isBlank(bccGroup.getGroupEmail()))
							bccGroupList.add(bccGroup);
					
						logger.info("Inside the getBccGroupFromStaticData method after populating the following bccGroup Details: ID: {},groupName: {},groupmail: {}",bccGroup.id,bccGroup.getGroupName(),bccGroup.getGroupEmail());
					}
				}
			}
			else
			{
				logger.error("{} Static Data Collection needs to have bccGroupIds configured. Please configure to redirect bcc mails.",MongoExtInquiryDAO.class);
			}
			
		}
		catch(Exception e)
		{
			throw new CommunicatorException(MongoExtInquiryDAO.class + " Issue happened in method getBccGroupFromStaticData ", e);
		}
		
		return bccGroupList;
	}
	
	public void updateExtInquiryMessageRefInquiryId(Long inquiryId, Long inquiryMessageRefId){
		 updateExtInquiryMessageRefInquiryId(inquiryId,inquiryMessageRefId, null );
	}
	
	public void updateExtInquiryMessageRefInquiryId(Long inquiryId, Long inquiryMessageRefId,String lobInfo)
	{
		try
		{
			DBObject updateReferenceAudField = new BasicDBObject();

			BasicDBObject setObj=new BasicDBObject(INQUIRY_ID_KEY, inquiryId);
			if(StringUtils.isNotBlank(lobInfo)){
				setObj.put("lob", lobInfo);
			}
			updateReferenceAudField.put("$set", setObj);

			
			DBObject updateQuery = new BasicDBObject();
			updateQuery.put("_id", inquiryMessageRefId);
			WriteResult writeResult = mongoDatastore.getCollection(InquiryMessageRef.class).update(updateQuery, updateReferenceAudField,false, true);
		
			logger.debug("inquiryId field is update successfully in InquiryMessageRef {}",writeResult);
		}
		catch (Exception e)
		{
			logger.error("Error updating inquiryId in InquiryMessageRef)", e);

		}
	}

	public void saveInquiriesToPublish(Long inquiryId, String action, String userId) throws CommunicatorException {
		UINotifications inquiryWebsocketData = null;
		try
		{
			inquiryWebsocketData = new UINotifications();

			inquiryWebsocketData.setInquiryId(inquiryId);
			inquiryWebsocketData.setAction(action);
			inquiryWebsocketData.setProcessFlag("N");
			inquiryWebsocketData.setCrtBy(userId);
			inquiryWebsocketData.setModBy(userId);
			inquiryWebsocketData.setModDate(new Date());
		}
		catch (Exception e)
		{
			throw new CommunicatorException("Exception in getInquiriesToPublish " + e.getMessage());
		}
		mongoDatastore.save(inquiryWebsocketData);
		
		logger.info("Inserted Inquiry to publish [{}]",inquiryId);
		
	}
	/**
	 * Update the cache for User
	 * [C153176-2142] -	Enhance OOO functionality to check all open inquiries for a user and mark as 'unassigned'
	 * @return 
	 */
	public Map<String, Boolean> getUserDetailsFromDB() 
	{
		Query<User> query = mongoDatastore.createQuery(User.class);// ADD PROJECTION FOR 2 FIELDS ID, OUTOFOFFICE ONLY
		query.retrievedFields(true, "_id", "outOfOffice");
		List<User> UserListTemp = query.asList();
		Map<String, Boolean> userIDtoOOOStatusMap = new HashMap<>();
		for (User user: UserListTemp)
		{
			if (null !=  user.getOutOfOffice()) {
				userIDtoOOOStatusMap.put(user.getId().toLowerCase(), user.getOutOfOffice());
			}
		}
		return userIDtoOOOStatusMap;
	}

	/**
	 * This method identifies InquiryMessageRef record for provided messageId
	 * @param messageId
	 * @return Map<String, String>
	 */
	public Map<String, String> getInquiryRefRecordByMessageId(String messageId) {
		Map<String, String> inquiryMap  = new HashMap<>();
		if(StringUtils.isNotEmpty(messageId)) {
			Query<InquiryMessageRef> query = mongoDatastore.createQuery(InquiryMessageRef.class).filter("messageId", messageId);
			InquiryMessageRef refRecord = query.first();
			if(null != refRecord) {
				getInquiryRefMapForRecord(inquiryMap, refRecord);
				logger.info(BCC_PROCESSING_LOG_PREFIX+"Existing InquiryMessageRef record found for messageId : {}", messageId);
			}
		} else {
			logger.info(BCC_PROCESSING_LOG_PREFIX+"No InquiryMessageRef record found for messageId : {}", messageId);
		}
		return inquiryMap;
	}
	
	public static Long getIndividualGroupIdForReceivedGroupAlias(String groupName, QMACache cache) throws CommunicatorException
	{
		Long groupId = null;
		try {
			if (groupName != null) {
				groupId = cache.getPersonalCodeToIdMap().get(groupName.toUpperCase()); //<<-- sonar fix Change this condition so that it does not always evaluate to "false"
				if (groupId == null) {
					logger.info("No Matching alias for Individual Name in method getIndividualGroupIdForReceivedAlias : {}", groupName);
				} else {
					logger.info("groupId for groupAlias: {} in getIndividualGroupIdForReceivedAlias : {}",groupName, groupId);
				}
			}
		} catch (Exception e) {
			throw new CommunicatorException(
					MongoExtInquiryDAO.class + " Issue happened in method getIndividualGroupIdForReceivedAlias ", e);
		}
		return groupId;
	} 
	// Data input should be in CAPS letter, as Cache is all in CAPS to make it case insensitive.
	public static Long getIndividualGroupIdForReceivedEmail(String groupEmail, QMACache cache) throws CommunicatorException
	{
		Long groupId = null;
		try {
			if (groupEmail != null) {
				groupId =  cache.getPersonalEmailToIdMap().get(groupEmail); //<<-- sonar fix Change this condition so that it does not always evaluate to "false"
				if (groupId == null) {
					logger.info("No Matching alias for Email in method getIndividualGroupIdForReceivedEmail : {}",groupEmail);
				} else {
					logger.info("groupId for email address: {}in PersonalEmailToIdMap cache found is : {}",groupEmail, groupId);
				}
			}
		} catch (Exception e) {
			throw new CommunicatorException(
					MongoExtInquiryDAO.class + " Issue happened in method getIndividualGroupIdForReceivedEmail ", e);
		}
		return groupId;
	}

	/**
	 * This method will get sender domain in the workflow
	 * @param conversation
	 * @return String
	 */
	public String updateSenderDomain(Conversation conversation) {
		String senderDomain = "";
		try {
			if(null!=conversation && null != conversation.getRecipients()){
				List<ConversationRecipient> recipients = conversation.getRecipients();
				if(null!= recipients && !recipients.isEmpty()) {
					for(ConversationRecipient recipient : recipients) {
						if(Objects.nonNull(recipient.getToFrom()) && recipient.getToFrom().equalsIgnoreCase(RECIPIENT_FROM) &&  StringUtils.isNotEmpty(recipient.getEmailAddr())){
							String senderEmail = recipient.getEmailAddr();
							if(GenericUtility.isCitiDomainEmail(senderEmail)) {
								senderDomain = SENDER_DOMAIN_CITI;
							} else {
								senderDomain = senderEmail.substring(senderEmail.indexOf('@')+1, senderEmail.length());
								senderDomain = senderDomain.substring(0, senderDomain.indexOf('.'));
								if(StringUtils.isNotEmpty(senderDomain)) {
									senderDomain = "(" + senderDomain.toUpperCase() + ")";
								}
							}
							break;
						}
					}
				}
			} else {
				logger.warn("Either conversation recipients or workflow is not available to stamp latest sender domain.");
			}
		} catch (Exception e){
			logger.warn("Exception while stamping latest sender domain : ", e);
		}
		return senderDomain;
	}
}
