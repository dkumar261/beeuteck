package com.citi.icg.qma.common.core.subscriber.mails.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Envelope
{
	private String fromName;
	private String fromAddress;
	private String replyToAddress;

	private String replyToPersonal;

	private List<String> toRecipients;
	private List<String> ccRecipients;
	private List<String> toRecipientsAddresses;
	private List<String> ccRecipientsAddresses;

	private Date sentDate;
	private Date receiptDate;

	private Subject subject;

	private String messageId;
	private List<String> referenceIds;

	private String importance;
	private String threadIndex;

	private ArrayList<NVPair> headers = null;

	private String references;
	private String inquiryId;
	private String mailSubject;
	private String resentFrom;

	public Envelope()
	{
		toRecipients = new ArrayList<>();
		ccRecipients = new ArrayList<>();
		referenceIds = new ArrayList<>();
		toRecipientsAddresses = new ArrayList<>();
		ccRecipientsAddresses = new ArrayList<>();
		headers = new ArrayList<>();
	}

	public String getMessageId()
	{
		return messageId;
	}

	public void setMessageId(String messageId)
	{
		this.messageId = messageId;
	}

	public List<String> getReferenceIds()
	{
		return referenceIds;
	}

	public void addReferenceId(String referenceId)
	{
		referenceIds.add(referenceId);
	}

	public void addToReceipent(String receipent)
	{
		toRecipients.add(receipent);
	}

	public List<String> getToReceipents()
	{
		return toRecipients;
	}

	public void addCcReceipent(String receipent)
	{
		ccRecipients.add(receipent);
	}

	public List<String> getCcReceipents()
	{
		return ccRecipients;
	}

	public String getFromName()
	{
		return fromName;
	}

	public void setFromName(String fromName)
	{
		this.fromName = fromName;
	}

	public String getFromAddress()
	{
		return fromAddress;
	}

	public void setFromAddress(String fromAddress)
	{
		this.fromAddress = fromAddress;
	}

	public Date getReceiptDate()
	{
		return receiptDate;
	}

	public void setReceiptDate(Date receiptDate)
	{
		this.receiptDate = receiptDate;
	}

	public Date getSentDate()
	{
		return sentDate;
	}

	public void setSentDate(Date sentDate)
	{
		this.sentDate = sentDate;
	}

	public void setSubject(Subject subject)
	{
		this.subject = subject;
	}

	public Subject getSubject()
	{
		return this.subject;
	}

	// external email - for capturing the importance
	public String getImportance()
	{
		return importance;
	}

	public void setImportance(String importance)
	{
		this.importance = importance;
	}

	public String getThreadIndex()
	{
		return threadIndex;
	}

	public void setThreadIndex(String threadIndex)
	{
		this.threadIndex = threadIndex;
	}

	public void addHeader(NVPair nvPair)
	{
		headers.add(nvPair);
	}

	public List<NVPair> getHeaders()
	{
		return headers;
	}

	public void addCcReceipentAddresses(String ccReceipentAddress)
	{
		ccRecipientsAddresses.add(ccReceipentAddress);
	}

	public List<String> getCcReceipentsAddresses()
	{
		return ccRecipientsAddresses;
	}

	public void addToReceipentAddresses(String toReceipentAddress)
	{
		toRecipientsAddresses.add(toReceipentAddress);
	}

	public List<String> getToReceipentsAddresses()
	{
		return toRecipientsAddresses;
	}

	public String getReferences()
	{
		return references;
	}

	public void setReference(String references)
	{
		this.references = references;
	}

	public String getInquiryId()
	{
		return inquiryId;
	}

	public void setInquiryId(String inquiryId)
	{
		this.inquiryId = inquiryId;
	}

	public String getMailSubject()
	{
		return mailSubject;
	}

	public void setMailSubject(String mailSubject)
	{
		this.mailSubject = mailSubject;
	}
	
	public String getReplyToAddress()
	{
		return replyToAddress;
	}

	public void setReplyToAddress(String replyToAddress)
	{
		this.replyToAddress = replyToAddress;
	}

	public String getReplyToPersonal()
	{
		return replyToPersonal;
	}

	public void setReplyToPersonal(String replyToPersonal)
	{
		this.replyToPersonal = replyToPersonal;
	}
	

	public String getResentFrom()
	{
		return resentFrom;
	}

	public void setResentFrom(String resentFrom)
	{
		this.resentFrom = resentFrom;
	}
	
}
