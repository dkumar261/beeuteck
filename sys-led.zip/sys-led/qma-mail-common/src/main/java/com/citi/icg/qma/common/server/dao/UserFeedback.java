/**
 * 
 */
package com.citi.icg.qma.common.server.dao;

import java.util.Date;

import org.bson.types.ObjectId;

import dev.morphia.annotations.CappedAt;
import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

/**
 * 
 *
 */
@Entity(value = "UserFeedback", noClassnameStored = true, cap = @CappedAt(count = 50000, value = 2000000000))
public class UserFeedback {
	
	
	@Id
	private ObjectId id;
	private String correctionDataItem;
	private Long inquiryId;
	private Long convId;
	private String userId;
	private Date crtDate;
	private boolean processingFlag;
	
	public UserFeedback(){
		//default constructor
	}
	
	public UserFeedback(String userId, String correctionDataItem, Long inquiryId, Long convId){
		this.userId = userId;
		this.correctionDataItem = correctionDataItem;
		this.inquiryId=inquiryId;
		this.convId =convId;
		this.crtDate= new Date();
		this.processingFlag=false;
	}
	
	/**
	 * @return the id
	 */
	public ObjectId getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(ObjectId id) {
		this.id = id;
	}
	/**
	 * @return the correctionDataItem
	 */
	public String getCorrectionDataItem() {
		return correctionDataItem;
	}
	/**
	 * @param correctionDataItem the correctionDataItem to set
	 */
	public void setCorrectionDataItem(String correctionDataItem) {
		this.correctionDataItem = correctionDataItem;
	}
	/**
	 * @return the inquiryId
	 */
	public Long getInquiryId() {
		return inquiryId;
	}
	/**
	 * @param inquiryId the inquiryId to set
	 */
	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}
	/**
	 * @return the convId
	 */
	public Long getConvId() {
		return convId;
	}
	/**
	 * @param convId the convId to set
	 */
	public void setConvId(Long convId) {
		this.convId = convId;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the crtDate
	 */
	public Date getCrtDate() {
		return crtDate;
	}
	/**
	 * @param crtDate the crtDate to set
	 */
	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}
	/**
	 * @return the processingFlag
	 */
	public boolean isProcessingFlag() {
		return processingFlag;
	}
	/**
	 * @param processingFlag the processingFlag to set
	 */
	public void setProcessingFlag(boolean processingFlag) {
		this.processingFlag = processingFlag;
	}
	
}
