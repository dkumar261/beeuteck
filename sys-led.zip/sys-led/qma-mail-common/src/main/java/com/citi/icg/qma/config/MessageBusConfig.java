package com.citi.icg.qma.config;

public class MessageBusConfig {

	private String brokerCluster;
	private String eventPublisherTopic;
	private String eventConsumerTopic;
	private String sslKeyStoreLocation;
	private String sslKeyStorePassword;
	private String sslTrustStoreLocation;
	private String sslTrustStorePassword;
	private String kafkaProtocol;
	private boolean sslEnabled;
	private String sslEndpointIdentificationAlgorithm;
	
	public String getBrokerCluster() {
		return brokerCluster;
	}
	public void setBrokerCluster(String brokerCluster) {
		this.brokerCluster = brokerCluster;
	}
	public String getEventPublisherTopic() {
		return eventPublisherTopic;
	}
	public void setEventPublisherTopic(String eventPublisherTopic) {
		this.eventPublisherTopic = eventPublisherTopic;
	}
	public String getEventConsumerTopic() {
		return eventConsumerTopic;
	}
	public void setEventConsumerTopic(String eventConsumerTopic) {
		this.eventConsumerTopic = eventConsumerTopic;
	}
	public String getSslKeyStoreLocation() {
		return sslKeyStoreLocation;
	}
	public void setSslKeyStoreLocation(String sslKeyStoreLocation) {
		this.sslKeyStoreLocation = sslKeyStoreLocation;
	}
	public String getSslKeyStorePassword() {
		return sslKeyStorePassword;
	}
	public void setSslKeyStorePassword(String sslKeyStorePassword) {
		this.sslKeyStorePassword = sslKeyStorePassword;
	}
	public String getSslTrustStoreLocation() {
		return sslTrustStoreLocation;
	}
	public void setSslTrustStoreLocation(String sslTrustStoreLocation) {
		this.sslTrustStoreLocation = sslTrustStoreLocation;
	}
	public String getSslTrustStorePassword() {
		return sslTrustStorePassword;
	}
	public void setSslTrustStorePassword(String sslTrustStorePassword) {
		this.sslTrustStorePassword = sslTrustStorePassword;
	}
	public String getKafkaProtocol() {
		return kafkaProtocol;
	}
	public void setKafkaProtocol(String kafkaProtocol) {
		this.kafkaProtocol = kafkaProtocol;
	}
	public boolean isSslEnabled() {
		return sslEnabled;
	}
	public void setSslEnabled(boolean sslEnabled) {
		this.sslEnabled = sslEnabled;
	}
	public String getSslEndpointIdentificationAlgorithm() {
		return sslEndpointIdentificationAlgorithm;
	}
	public void setSslEndpointIdentificationAlgorithm(String sslEndpointIdentificationAlgorithm) {
		this.sslEndpointIdentificationAlgorithm = sslEndpointIdentificationAlgorithm;
	}
	
	
}
