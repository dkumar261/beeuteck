package com.citi.icg.qma.common.server.aws.util;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.persistence.GenericDAO;
import com.citi.icg.qma.common.server.dao.persistence.MongoDB;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.ReadPreference;


public class MongoToS3Writer
{

	private static final Logger logger = LoggerFactory.getLogger(MongoToS3Writer.class);
	// private static final Datastore mongoDatastore = MongoDB.instance().getDataStore();
	private static final DB database = MongoDB.instance().getDB();
	// private final static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
	private static DateFormat inputdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	static Long totalDocumentCount = (long) 0;
	static Long totalInquiresFetched = (long) 0;
	static Set<Long> totalInquiryIds = new HashSet<Long>();

	static int S3ThreadCount = 10;
	static int S3InquiryBatchlimit = 1000;

	MongoToS3Writer()
	{
	}

	public static void run(String startDateStr, String endDateStr)
	{
		
		try
		{
			
			logger.info("START TIME :" + new Date());
			loadThreadCountAndInquiryLimitFromDB();
			MongoToS3Writer s3writer = new MongoToS3Writer();

			// "12/03/2017 20:00:00" "12/04/2017 20:00:00"
			if (StringUtils.isNotBlank(startDateStr) && StringUtils.isNotBlank(endDateStr))
			{
				logger.info("input dates :" + startDateStr + "--" + endDateStr);
				s3writer.startJob(startDateStr, endDateStr);
			}
			else
			{
				s3writer.startJob("", "");
			}

			logger.info("TOTAL Number Of INQUIRIES :" + totalInquiresFetched);
			logger.info("END TIME :" + new Date());

		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
			
		}

	}

	private static void loadThreadCountAndInquiryLimitFromDB()
	{

		GenericDAO genricDAO = new GenericDAO();

		Config configData = genricDAO.getConfigDetailsForId("S3Migration");
		if (configData != null)
		{
			S3ThreadCount = configData.getS3ThreadCount();
			S3InquiryBatchlimit = configData.getS3InquiryBatchlimit();
		}

		logger.info(" loadThreadCountAndInquiryLimitFromDB from config threadCount :" + S3ThreadCount + " , inquirylimit :" + S3InquiryBatchlimit);

	}

	/**
	 * runs reports one by one migrate data older than 6 months. For easiness alwasy read data which is in between from 7 months to 6 months , however actual process will hapeen for 1 week as it will
	 * be weekly process
	 */
	public void startJob(String startDateStr, String endDateStr)
	{
		try
		{
			Date startDate = null;
			Date endDate = null;

			// input date format is MM/dd/yyyy
			if (StringUtils.isNotBlank(startDateStr) && StringUtils.isNotBlank(endDateStr))
			{
				startDate = inputdf.parse(startDateStr);
				endDate = inputdf.parse(endDateStr);
			}
			else
			{

				Calendar cal = Calendar.getInstance();
				cal.add(Calendar.MONTH, -7);
				startDate = cal.getTime();

				cal = Calendar.getInstance();
				cal.add(Calendar.MONTH, -6);
				endDate = cal.getTime();

			}

			logger.info("in MongoToS3Writer startJob - startDate:" + startDate + ", endDate:" + endDate);
			fetchInquiryIdsforNonS3MigratedData(startDate, endDate);

			createExecutorServiceTofetchDocId(new ArrayList<Long>(totalInquiryIds));
			logger.info("MongoToS3Writer is completed successfully");

		}
		catch (Exception e)
		{
			logger.error("Error in MongoToS3Writer, will shutdown now : ", e);
		}
	}

	/**
	 * @param inactiveGroupIds
	 * @throws ParseException
	 * 
	 *             //weekly process, today run , if date range is given use it , startdate and enddate== u migrated for all older than 6 months. //mm/dd/yyyy startdate = currentdate - 7 months,
	 *             enddate = curremtdate- 6 months reading 1 month on safer side but processing mostly one weekly Do not read of inqiry/conv to be heavy in prod.
	 */

	public static void fetchInquiryIdsforNonS3MigratedData(Date startDate, Date endDate) throws ParseException
	{

		// fetch 60 days older and resolved inquiries.
		// DB Query - db.Inquiry.find({ "status" : "Resolved" , "modDate": { $lte: ISODate("2018-02-09T18:23:30.867Z") }});

		String projectionQuery = "{ _id : 1, status : 1, modDate :1}";
		DBObject projection = BasicDBObject.parse(projectionQuery);
		// BasicDBObject query = new BasicDBObject("status", "Resolved").append("modDate", new BasicDBObject("$gte", startDate).append("$lt", endDate));
		BasicDBObject query = new BasicDBObject("modDate", new BasicDBObject("$gte", startDate).append("$lt", endDate));
		DBCursor cursorDoc = database.getCollection("Inquiry").find(query, projection).setReadPreference(ReadPreference.secondary());

		logger.info("fetchInquiryIdsforInactiveGroups query: " + query);
		logger.info("fetchInquiryIdsforInactiveGroups cursor size: " + cursorDoc.size());

		while (cursorDoc.hasNext())
		{
			DBObject inqObject = cursorDoc.next();

			if (inqObject != null)
			{
				long inquiryId = (long) inqObject.get("_id");
				totalInquiryIds.add(inquiryId);
			}

			totalInquiresFetched++;
		}

		logger.info("TOTAL Number of Inquiries  :" + totalInquiryIds.size());
	}

	private static void createExecutorServiceTofetchDocId(List<Long> totalInquiryIds2)
	{

		logger.info("inside createExecutorServiceTofetchDocId.......... inquirylimit :" + S3InquiryBatchlimit + ", threadCount:" + S3ThreadCount);
		ExecutorService service = Executors.newFixedThreadPool(S3ThreadCount);
		List<List<Long>> chunkList = getChunkList(totalInquiryIds2, S3InquiryBatchlimit);

		logger.info("inside createExecutorServiceTofetchDocId numberOf Chunks :" + chunkList.size());

		for (List<Long> inqIdsChunkList : chunkList)
		{
			try
			{
				service.execute(new MongoToS3WriterHelper(inqIdsChunkList));
			}
			catch (IOException e)
			{
				logger.error("inside createExecutorServiceTofetchDocId:" + e);
				
			}
		}

		service.shutdown();

		logger.info(" End of createExecutorServiceTofetchDocId..........");
	}

	/**
	 * Returns List of the List argument passed to this function with size = chunkSize
	 * 
	 * @param largeList
	 *            input list to be portioned
	 * @param chunkSize
	 *            maximum size of each partition
	 * @param <T>
	 *            Generic type of the List
	 * @return A list of Lists which is portioned from the original list
	 */
	private static <T> List<List<T>> getChunkList(List<T> largeList, int chunkSize)
	{
		List<List<T>> chunkList = new ArrayList<>();
		for (int i = 0; i < largeList.size(); i += chunkSize)
		{
			chunkList.add(largeList.subList(i, i + chunkSize >= largeList.size() ? largeList.size() : i + chunkSize));
		}
		return chunkList;
	}

}
