package com.citi.icg.qma.common.server.dao.persistence.oasys.payments;

import java.util.List;

public class ClcRequestPayload {
	private String clientId;
	private String clientName;
	private String sender;
	private String emailSubject;
	private String citiEmailSerial;
	private List<OasysPaymentLine> paymentData;

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getEmailSubject() {
		return emailSubject;
	}

	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}
	
	public String getCitiEmailSerial() {
		return citiEmailSerial;
	}

	public void setCitiEmailSerial(String citiEmailSerial) {
		this.citiEmailSerial = citiEmailSerial;
	}

	public List<OasysPaymentLine> getPaymentData() {
		return paymentData;
	}

	public void setPaymentData(List<OasysPaymentLine> paymentData) {
		this.paymentData = paymentData;
	}

}
