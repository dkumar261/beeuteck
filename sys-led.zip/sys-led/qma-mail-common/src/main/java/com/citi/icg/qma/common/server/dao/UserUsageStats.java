package com.citi.icg.qma.common.server.dao;

import java.util.Date;

import org.bson.types.ObjectId;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "UserUsageStats", noClassnameStored = true)
public class UserUsageStats {
	@Id
	private ObjectId id;
	private String userId;
	private String module;
	private String function;
	private Long timeSpentInSec;
	private Date loginTime;
	private Date logoutTime;
	
	
	
	public ObjectId getId() {
		return id;
	}
	public void setId(ObjectId id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getFunction() {
		return function;
	}
	public void setFunction(String function) {
		this.function = function;
	}
	public Long getTimeSpentInSec() {
		return timeSpentInSec;
	}
	public void setTimeSpentInSec(Long timeSpentInSec) {
		this.timeSpentInSec = timeSpentInSec;
	}
	public Date getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}
	public Date getLogoutTime() {
		return logoutTime;
	}
	public void setLogoutTime(Date logoutTime) {
		this.logoutTime = logoutTime;
	}
}
