package com.citi.icg.qma.common.server.dao.persistence;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.XmException;
import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.MailCommonUtil;
import com.citi.icg.qma.common.server.aws.util.AWSUtility;
import com.citi.icg.qma.common.server.aws.util.S3MigratedDocsFsFiles;
import com.citi.icg.qma.common.server.dao.Attachment;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;

import dev.morphia.Datastore;

/**
 * This class is used to save the attachments and retrieve them back. It provides various options to save and get file.
 */
public class AttachmentDAO extends MongoMorphiaDAO
{
	
	private Logger logger = LoggerFactory.getLogger(AttachmentDAO.class);
	private static DB mongodb = MongoDB.instance().getDB();
	private static final int BYTES_IN_ONE_MB = 1024 * 1024;
	private static final Datastore dataStore = MongoDB.instance().getDataStore(); //sonar fix renamed for Child class fields should not shadow parent class fields
	
	public static String INVALID_DOC_ID ="[^\\w]";

	/**
	 * This method is used to save the attachment files into the MongoDb using gridfs api 
	 * @param fileName
	 * @param file
	 * @return Attachment
	 * @throws IOException
	 */
	public Attachment saveFile(String fileName, File file) throws Exception
	{
		FileInputStream in = new FileInputStream(file);
		return saveFile(fileName, in);
	}

	/**
	 * This method is used to save the attachment files into the MongoDb using gridfs api
	 * @param fileName
	 * @param in
	 * @return
	 * @throws IOException
	 */
	public Attachment saveFile(String fileName, InputStream in) throws Exception
	{
		try
		{
			GridFS fs = new GridFS(mongodb);
			GridFSInputFile gridFile = fs.createFile(in, true);
			gridFile.setFilename(fileName);
			gridFile.setContentType(FilenameUtils.getExtension(fileName));

			long chunkSize = getCheckSumSize(in);

			gridFile.save(chunkSize);

			return new Attachment(gridFile.getFilename(), gridFile.getId().toString());
		}
		finally
		{
			IOUtils.closeQuietly(in);
		}
	}

	private long getCheckSumSize(InputStream in) throws IOException
	{
		long chunkSize = GridFS.DEFAULT_CHUNKSIZE;
		if (in.available() > 2 * BYTES_IN_ONE_MB)
		{
			chunkSize = in.available() / 4L;
		}
		return chunkSize;
	}
	
	/* This method is used to save the attachment files into the MongoDb using gridfs api
	 * 
	 * @param fileName
	 * @param file
	 * @return Attachment
	 * @throws IOException
	 */
	public Attachment saveFile(String docId, String fileName, File file) throws Exception
	{
		long startTime = System.currentTimeMillis();
		//[C170665-1723] - SBT Path Traversal Issue Fixing
		fileName = GenericUtility.sanitizeFileName(fileName);
		if(!GenericUtility.isValidFileName(fileName) || !GenericUtility.isValidAlphaNumericValue(docId)) {
			logger.error("Invalid filename {} or docId {} while while saving file " ,fileName , docId);
			return new Attachment();
		}
		FileInputStream in = new FileInputStream(file);
		Attachment savedAttachment=saveFile(docId, fileName, in);
		logger.debug("Inside AttachmentDAO.saveFile for fileName = {} ,docId = {} Time Diff-{} in Milli Seconds",fileName,docId
				, (System.currentTimeMillis() - startTime));
		return savedAttachment;
	}
	
	/**
	 * This method is used to save the attachment files into the MongoDb using gridfs api
	 * 
	 * @param docId
	 * @param fileName
	 * @param in
	 * @return
	 * @throws IOException
	 */
	public Attachment saveFile(String docId, String fileName, InputStream in) throws CommunicatorException
	{

		try
		{
			logger.debug("AttachDao saveFile docId= {} ,fileName = {}", docId,fileName);
			ObjectId fileObjectId=getObjectId(docId);
			Attachment savedAttachment=null;
			if (null != fileObjectId)
			{
				//Get File using ObjectID
				GridFSDBFile queryFile = getGridFSFile(fileObjectId);
				if (queryFile != null)
				{
					logger.debug("AttachDao saveFile, File exists in DB for docId= {} ,fileName ={}",docId,fileName);
					savedAttachment=new Attachment(queryFile.getFilename(), queryFile.getId().toString());
				}
			}
			
			if(savedAttachment == null )
			{
				//Create a new document in MongoSTore
				savedAttachment = uploadNewDocumentToMongoStore(fileName, in, fileObjectId);
				
			}
			logger.debug("Input doc id= {}, file name= {}, Mongo store object id= {}", docId, fileName, savedAttachment.getId());
			
			if(!StringUtils.isBlank(docId)){
				//Retain original docId for Document inline or external Case
				savedAttachment.setId(docId);
			}
			return savedAttachment;
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
			throw new CommunicatorException(e.getMessage(), e);
		}
		finally
		{
			IOUtils.closeQuietly(in);
		}

	}

	private Attachment uploadNewDocumentToMongoStore(String fileName, InputStream in, ObjectId fileObjectId) throws IOException
	{
		Attachment savedAttachment = null;
		GridFS fs = new GridFS(mongodb);
		GridFSInputFile gridFile = fs.createFile(in, true);

		if (null != fileObjectId)
		{
			gridFile.put("_id", fileObjectId);
		}

		gridFile.setFilename(fileName);
		gridFile.setContentType(FilenameUtils.getExtension(fileName));

		long chunkSize = getCheckSumSize(in);

		gridFile.save(chunkSize);
		savedAttachment = new Attachment();
		savedAttachment.setName(fileName);
		savedAttachment.setId(gridFile.getId().toString());
		//QMA-977 To display file size along with attachment name
		if (gridFile.getLength() >= 0) {
			long sizeInBytes = gridFile.getLength();
			double sizeInMB = Math.round((double) sizeInBytes / (1024 * 1024) * 100.0) / 100.0;
			savedAttachment.setFileSize(sizeInMB);
		}
		return savedAttachment;
	}

	/**
	 * This method is used to get the attachment files from the MongoDb using gridfs api
	 * @param mongoId
	 * @return
	 * @throws XmException
	 */
	public Map<String, Object> getFile(String mongoId) throws CommunicatorException
	{
		return getFile(mongoId, false);
	}
	public Map<String, Object> getFile(String mongoId, boolean notificationCall) throws CommunicatorException
	{
		GridFS fs = new GridFS(mongodb);
		return getFile(mongoId, notificationCall, logger,fs);
	}
	/**
	 * This method is used to get the attachment files from the MongoDb using gridfs api
	 * @param mongoId
	 * @return
	 * @throws XmException
	 */
	public Map<String, Object> getFile(String mongoId, boolean notificationCall, Logger logger,GridFS fileStore) throws CommunicatorException
	{
		HashMap<String, Object> downloadedFileMap = new HashMap<>();
		GridFSDBFile queryFile = null;

		try
		{
			queryFile = getGridFSFile(mongoId,fileStore);
		}
		catch (Exception e)
		{
			logger.error("queryFile had issues= ", e);
		}

		// Could not find in Mongodb, now try finding in S3 storage.
		if (queryFile == null)
		{

			try
			{

				logger.debug("looking into  S3 Store for mongoId= {}", mongoId);
				// getFileNameForS3(fileId);// TODO Sunil

				S3MigratedDocsFsFiles s3MigratedDocs = dataStore.createQuery(S3MigratedDocsFsFiles.class).filter("mongoId", mongoId).limit(1).get();

				if (s3MigratedDocs == null)
				{
					//this call required of old 16 digit data which exists in conversation table for old data. 
					ObjectId fileObjId=getObjectId(mongoId);
					
					
					mongoId = ""+ fileObjId;
					
					s3MigratedDocs = dataStore.createQuery(S3MigratedDocsFsFiles.class).filter("mongoId", mongoId).limit(1).get();
					
					if (s3MigratedDocs == null)
					{
						logger.error("Issue downloading file from S3, Plz look into it, fileObjId is :{} mongoId is: {}", fileObjId, mongoId );
						
						throw new CommunicatorException("Issue downloading file from S3, Plz look into it, fileObjId id :" + fileObjId + "mongoId is:" + mongoId );
					}
										
				}

				AWSUtility awsUtility = new AWSUtility();

				File file = awsUtility.readObject(awsUtility.getConnection(), mongoId, s3MigratedDocs.getFileName());
				if(notificationCall)
				{
					// find name from new collection MongoToS3MigratedDocumentDetails
					downloadedFileMap.put("fileName", s3MigratedDocs.getFileName());
				}
				else
				{
					// find name from new collection MongoToS3MigratedDocumentDetails
					downloadedFileMap.put("fileName", mongoId + "_" + s3MigratedDocs.getFileName());
				}
				downloadedFileMap.put("fileObject", file);
				downloadedFileMap.put("size", s3MigratedDocs.getSize());
				downloadedFileMap.put("type", s3MigratedDocs.getType());
				downloadedFileMap.put("uploadOn", s3MigratedDocs.getUploadOn());
				downloadedFileMap.put("md5", s3MigratedDocs.getMd5());
				downloadedFileMap.put("name", s3MigratedDocs.getFileName());

				logger.debug("Got File from S3 Store for mongoId= {}", mongoId);
			}
			catch (Exception e)
			{
				logger.error("Issue downloading file from S3, Plz look into it", e);

				throw new CommunicatorException("Issue downloading file from S3, Plz look into it", e);
			}

		}
		else
		{
			try
			{

				logger.debug("looking into  mongodb for mongoId= {}", mongoId);
				File file = createFile(queryFile, mongoId);
				if(notificationCall)
				{
					// find name from new collection MongoToS3MigratedDocumentDetails
					downloadedFileMap.put("fileName", queryFile.getFilename());
				}
				else
				{
					// find name from new collection MongoToS3MigratedDocumentDetails
					downloadedFileMap.put("fileName", mongoId + "_" + queryFile.getFilename());
				}
				downloadedFileMap.put("fileObject", file);
				downloadedFileMap.put("size", queryFile.getLength());
				downloadedFileMap.put("type", queryFile.getContentType());
				downloadedFileMap.put("uploadOn", queryFile.getUploadDate());
				downloadedFileMap.put("name", queryFile.getFilename());
				logger.debug("Got File from Mongo Store for mongoId= {}", mongoId);
			}
			catch (Exception e)
			{
				logger.error("Issue downloading file from Mongo, Plz look into it", e);

				throw new CommunicatorException("Issue downloading file from Mongo, Plz look into it", e);
			}

		}

		return downloadedFileMap;
	}


	public File createFile(GridFSDBFile queryFile, String fileId) throws CommunicatorException
	{
		FileOutputStream fout = null;
		File file = null;
		try
		{
			if (null == queryFile)
			{
				logger.debug("No file found for docId=" + fileId);
				throw new CommunicatorException("No file found for docId=" + fileId);
			}

			//String localFileName = fileId + "_" + queryFile.getMD5();
			String localFileName = GenericUtility.sanitizeFileName(fileId + "_" + queryFile.getId());
			file = MailCommonUtil.createFile(localFileName);
			byte[] document = getFile(queryFile);
			fout = new FileOutputStream(file);
			fout.write(document);
			fout.flush();
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
			throw new CommunicatorException(e.getMessage(), e);
		}
		finally
		{
			if (fout != null)
			{
				try
				{

					fout.close();
				}
				catch (Exception e)
				{
					logger.error("Issue in close in file out stream.", e);
				}
			}
		}

		return file;
	}
	private GridFSDBFile getGridFSFile(ObjectId fileObjectId) throws CommunicatorException
	{
		if(null == fileObjectId)
		{
			return null;
		}
		GridFS fs = new GridFS(mongodb);
		GridFSDBFile queryFile = fs.find(fileObjectId);
		return queryFile;
	}
	private GridFSDBFile getGridFSFile(ObjectId fileObjectId,GridFS fileStore) throws CommunicatorException
	{
		if(null == fileObjectId)
		{
			return null;
		}
		GridFSDBFile queryFile = fileStore.find(fileObjectId);
		return queryFile;
	}
	
	public File getGridFSFileByName(String fileName) throws CommunicatorException
	{
		if (null == fileName)
		{
			return null;
		}
		GridFS fs = new GridFS(mongodb);
		GridFSDBFile queryFile = fs.findOne(fileName);
		return createFile(queryFile, fileName);
	}
	private GridFSDBFile getGridFSFile(String fileId) throws CommunicatorException
	{
		ObjectId fileObjId=getObjectId(fileId);
		return getGridFSFile(fileObjId);
	}
	private GridFSDBFile getGridFSFile(String fileId,GridFS fileStore) throws CommunicatorException
	{
		ObjectId fileObjId=getObjectId(fileId);
		return getGridFSFile(fileObjId,fileStore);
	}

	private byte[] getFile(GridFSDBFile queryFile) throws CommunicatorException
	{
		byte[] file = null;
		if (queryFile != null)
		{
			try (ByteArrayOutputStream  bao = new ByteArrayOutputStream())
			{
				
				queryFile.writeTo(bao);
				file = bao.toByteArray();
			}
			catch (Exception e)
			{
				logger.error(e.getMessage(), e);
				throw new CommunicatorException(e.getMessage(), e);
			}
		}
		return file;
	}

	/**
	 * This method is used to delete the attachment file by given fileid from the MongoDb using gridfs api
	 * @param fileId
	 */
	public void deleteFile(String fileId)
	{
		GridFS fs = new GridFS(mongodb);
		fs.remove(getObjectId(fileId));
	}
	
	public void deleteFile(String fileId,GridFS  fileStore)
	{
		fileStore.remove(getObjectId(fileId));
	}
	
	/*
	 * This method converts a Hexa Decimal String document Id to Object Id
	 * If the string is not a valid hexa decimal string required for Object ID, It Converts string to valid hexa decimalfirst
	 * 
	 */
	public ObjectId getObjectId(String docId)
	{
		logger.debug("GetObjectId method input docId = {}", docId);
		ObjectId objId =null;
		if(StringUtils.isBlank(docId))
		{
			return objId;
		}
		//docId string can be a valid hexdecimal object id or plain string

		try
		{
			docId = docId.replaceAll(INVALID_DOC_ID, "");
		}
		catch (Exception e)
		{
			logger.error("Issue in docId replace method, docId is: " + docId, e);
		}
		
		if ( docId.trim().length() <= 16)
		{
			logger.debug("InValid Hexa String Received for ObjectId Conversion id = {}, converting it to Hexadecimal String.", docId);
			byte[] docHex = MailCommonUtil.convertStringToHex(docId);
			logger.debug("encodedHex = {}", docHex);
			objId = new ObjectId(docHex);
		}
		else
		{
			objId  = new ObjectId(docId);
		}
		logger.debug("Generated Obj id = {}",objId);
		return objId;
	}
	
	/**
	 * This method is used to get the attachment files from the MongoDb using gridfs api
	 * @param fileName 
	 * @param MD5 checksum
	 * @return GridFS
	 * @throws XmException
	 */
	private GridFSDBFile getGridFSFilesByMD5(String fileName, String checkSumMD5) throws CommunicatorException
	{
		GridFS fs = new GridFS(mongodb);
		BasicDBObject selectQuery = new BasicDBObject();
		selectQuery.put("filename", fileName);
		selectQuery.put("md5", checkSumMD5);
		GridFSDBFile file = fs.findOne(selectQuery);
		logger.debug("Query for searching attachment in mongo file store= {}", selectQuery);
		return file;
	}
	
	/**
	 * This method is used to get the attachment files from the MongoDb using gridfs api
	 * @param fileName 
	 * @param MD5 checksumMD5
	 * @return Attachment
	 * @throws XmException
	 */
	public Attachment getFileByMD5Hash(String fileName, String checksumMD5) throws CommunicatorException
	{
		Attachment attach = null;
		try
		{
			
			GridFSDBFile queryFile = getGridFSFilesByMD5(fileName, checksumMD5);
			
			if(null == queryFile )
			{
				logger.debug("No file found for checksumMD5= {}", checksumMD5);
				return attach;
			}
			logger.debug("file found in mongo data store for checksumMD5= {} File name= {} File id= {}",checksumMD5, queryFile.getFilename(), queryFile.getId());
			attach= new Attachment();
			attach.setId(queryFile.getId().toString());
			attach.setName(queryFile.getFilename());
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
		}

		return attach;
	}
	
	/**
	 * This method is used to get the attachment from the MongoDb using gridfs api
	 * @param fileName 
	 * @param InputStream
	 * @param Logger
	 * @return Attachment
	 * @throws XmException
	 */
	public Attachment getExistingAttachmentByMD5(String fileName, InputStream in) 
	{
		Attachment savedAttachment = null;
		try
		{
			logger.debug("Calculating checksum for file name= {}", fileName);

			String checksumMD5 = MailCommonUtil.calculateChecksum(in);
			if (!StringUtils.isBlank(checksumMD5))
			{
				savedAttachment = getFileByMD5Hash(fileName, checksumMD5);
			}
		}
		catch (Exception e)
		{
			logger.error("Issues while getting the attachment form mongo store for name= {}", fileName);
		}

		return savedAttachment;
	}

}