package com.citi.icg.qma.common.contact.tcl.entity;

public class TCLAssociatedFamilies {

	private TCLFamilyDetail familyDetail;

	public TCLAssociatedFamilies() {
		super();
		// Auto-generated constructor stub
	}

	public TCLFamilyDetail getFamilyDetail() {
		return familyDetail;
	}

	public void setFamilyDetail(TCLFamilyDetail familyDetail) {
		this.familyDetail = familyDetail;
	}

	
}
