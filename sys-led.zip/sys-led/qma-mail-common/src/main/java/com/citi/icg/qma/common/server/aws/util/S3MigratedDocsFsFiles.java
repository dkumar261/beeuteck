package com.citi.icg.qma.common.server.aws.util;

import java.util.Date;

import com.citi.icg.qma.common.server.dao.BaseEntity;

import dev.morphia.annotations.Entity;

@Entity(value = "S3MigratedDocsFsFiles", noClassnameStored = true)
public class S3MigratedDocsFsFiles extends BaseEntity
{

	private String fileName;
	private String mongoId; // This is the key to fetch mongodb documents.
	private Date uploadOn;
	private String md5;
	private String type;
	private Long size;

	public S3MigratedDocsFsFiles()
	{
		
	}
	public S3MigratedDocsFsFiles( String fileName,
			String mongoId, Date uploadOn, String md5,
			String type, Long size)
	{
		super();
		this.fileName = fileName;

		this.mongoId = mongoId;
		this.uploadOn = uploadOn;
		this.md5 = md5;
		this.type = type;
		this.size = size;
	}

	
	public String getFileName()
	{
		return fileName;
	}

	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	public String getMongoId()
	{
		return mongoId;
	}

	public void setMongoId(String mongoId)
	{
		this.mongoId = mongoId;
	}

	public Date getUploadOn()
	{
		return uploadOn;
	}

	public void setUploadOn(Date uploadOn)
	{
		this.uploadOn = uploadOn;
	}

	public String getMd5()
	{
		return md5;
	}

	public void setMd5(String md5)
	{
		this.md5 = md5;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public Long getSize()
	{
		return size;
	}

	public void setSize(Long size)
	{
		this.size = size;
	}

}
