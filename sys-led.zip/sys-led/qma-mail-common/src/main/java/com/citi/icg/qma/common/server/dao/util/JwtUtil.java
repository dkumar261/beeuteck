package com.citi.icg.qma.common.server.dao.util;

import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPrivateCrtKeySpec;
import java.util.Base64;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.asn1.pkcs.RSAPrivateKey;
import org.bouncycastle.asn1.ASN1Primitive;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.io.StringReader;

public class JwtUtil {
	private static volatile JwtUtil jwtInstance = null;
	private static final Logger SYMPHONY_JWT__LOGGER = LoggerFactory.getLogger(JwtUtil.class);

	// PKCS#8 format
	private static final String PEM_PRIVATE_START = "-----BEGIN PRIVATE KEY-----";
	private static final String PEM_PRIVATE_END = "-----END PRIVATE KEY-----";

	// PKCS#1 format
	private static final String PEM_RSA_PRIVATE_START = "-----BEGIN RSA PRIVATE KEY-----";
	private static final String PEM_RSA_PRIVATE_END = "-----END RSA PRIVATE KEY-----";

	private static final String PRIVATE_KEY = "-----CERTIFICATE_TEXT---";

	private String jwt = null;
	PrivateKey privateKeyParsed = null;
	private static final int EXPIRATION = 5 * 60 * 1000;

	private JwtUtil() {
		this.privateKeyParsed = parseRSAPrivateKey(PRIVATE_KEY);
	}

	public static JwtUtil getInstance() {
		if (jwtInstance == null) {
			synchronized (JwtUtil.class) {
				if (jwtInstance == null) {
					jwtInstance = new JwtUtil();
				}
			}
		}
		return jwtInstance;
	}

	public String getJwt(String botName) {
		this.jwt = createSignedJwt(botName, EXPIRATION, privateKeyParsed);
		return this.jwt;
	}

	private String createSignedJwt(String botName, long expiration, Key privateKey) {
		return Jwts.builder()
				.setSubject(botName)
				.setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + expiration))
				.signWith(SignatureAlgorithm.RS512, privateKey).compact();
	}

	private PrivateKey parseRSAPrivateKey(final String pemPrivateKey) {
		try {
			if (pemPrivateKey.contains(PEM_PRIVATE_START)) { // PKCS#8 format
				String privateKeyString = pemPrivateKey.replace(PEM_PRIVATE_START, "")
						.replace(PEM_PRIVATE_END, "")
						.replaceAll("\\s", "");
				byte[] keyBytes = Base64.getDecoder().decode(privateKeyString);
				PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
				KeyFactory fact = KeyFactory.getInstance("RSA");
				return fact.generatePrivate(keySpec);

			} else if (pemPrivateKey.contains(PEM_RSA_PRIVATE_START)) { // PKCS#1 format
				PemReader pemReader = new PemReader(new StringReader(pemPrivateKey));
				PemObject pemObject = pemReader.readPemObject();
				byte[] keyBytes = pemObject.getContent();

				ASN1Primitive asn1Primitive = ASN1Primitive.fromByteArray(keyBytes);
				RSAPrivateKey rsaPrivateKey = RSAPrivateKey.getInstance(asn1Primitive);

				RSAPrivateCrtKeySpec keySpec = new RSAPrivateCrtKeySpec(
						rsaPrivateKey.getModulus(),
						rsaPrivateKey.getPublicExponent(),
						rsaPrivateKey.getPrivateExponent(),
						rsaPrivateKey.getPrime1(),
						rsaPrivateKey.getPrime2(),
						rsaPrivateKey.getExponent1(),
						rsaPrivateKey.getExponent2(),
						rsaPrivateKey.getCoefficient()
				);

				KeyFactory factory = KeyFactory.getInstance("RSA");
				return factory.generatePrivate(keySpec);
			}

		} catch (Exception e) {
			SYMPHONY_JWT__LOGGER.error("Exception in parseRSAPrivateKey", e);
		}
		return null;
	}
}
