package com.citi.icg.qma.personal.exchange;

public class ExchangeOperationException extends Exception {

	private static final long serialVersionUID = -1049851796650440076L;

	/**
	 * @param message
	 * @param cause
	 */
	public ExchangeOperationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public ExchangeOperationException(String message) {
		super(message);
	}

}
