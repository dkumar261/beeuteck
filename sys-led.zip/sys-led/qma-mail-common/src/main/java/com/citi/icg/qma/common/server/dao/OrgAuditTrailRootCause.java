package com.citi.icg.qma.common.server.dao;

public class OrgAuditTrailRootCause {
	private String rootCause;
	private String statusIndicator;

	public OrgAuditTrailRootCause() {
		super();
	}

	public OrgAuditTrailRootCause(String rootCause, String statusIndicator) {
		super();
		this.rootCause = rootCause;
		this.statusIndicator = statusIndicator;
	}

	public String getRootCause() {
		return rootCause;
	}

	public void setRootCause(String rootCause) {
		this.rootCause = rootCause;
	}

	public String getStatusIndicator() {
		return statusIndicator;
	}

	public void setStatusIndicator(String statusIndicator) {
		this.statusIndicator = statusIndicator;
	}

}
