package com.citi.icg.qma.common.contact.tcl.entity;

public class TCLFamilyDetail {

	private String familyName;
	private int familyNumber;
	public TCLFamilyDetail() {
		super();
		// Auto-generated constructor stub
	}
	public String getFamilyName() {
		return familyName;
	}
	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}
	public int getFamilyNumber() {
		return familyNumber;
	}
	public void setFamilyNumber(int familyNumber) {
		this.familyNumber = familyNumber;
	}
	
	
}
