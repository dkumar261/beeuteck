package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import dev.morphia.annotations.Entity;

@Entity(value = "Organization", noClassnameStored = true)
public class Organization extends BaseEntity implements Serializable {
	private static final long serialVersionUID = -4334891718736542853L;
	private String orgName;
	private String orgManager;
	private List<OrgMetaDataAdminDetail> superAdmins;
	private List<String> requestTypes;
	private List<HighlevelRequestType> highLevelRequestTypeMapping;
	private List<String> processingRegion;
	private List<String> rootCause;
	private Map<String, List<String>> requestTypeRootCauseMapping;
	private List<String> inquirySource;
	private OrgPreferences orgPreferences;
	private String workflowStatus;
	private String maker;
	private String workflowRemarks;
    private boolean enableOrgLevelMetaData;
	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOrgManager() {
		return orgManager;
	}

	public void setOrgManager(String orgManager) {
		this.orgManager = orgManager;
	}
	
	public List<String> getRequestTypes() {
		return requestTypes;
	}

	public void setRequestTypes(List<String> requestTypes) {
		this.requestTypes = requestTypes;
	}

	public List<HighlevelRequestType> getHighLevelRequestTypeMapping() {
		return highLevelRequestTypeMapping;
	}

	public void setHighLevelRequestTypeMapping(List<HighlevelRequestType> highLevelRequestTypeMapping) {
		this.highLevelRequestTypeMapping = highLevelRequestTypeMapping;
	}

	public List<String> getProcessingRegion() {
		return processingRegion;
	}

	public void setProcessingRegion(List<String> processingRegion) {
		this.processingRegion = processingRegion;
	}

	public List<String> getRootCause() {
		return rootCause;
	}

	public void setRootCause(List<String> rootCause) {
		this.rootCause = rootCause;
	}

	public Map<String, List<String>> getRequestTypeRootCauseMapping() {
		return requestTypeRootCauseMapping;
	}

	public void setRequestTypeRootCauseMapping(Map<String, List<String>> requestTypeRootCauseMapping) {
		this.requestTypeRootCauseMapping = requestTypeRootCauseMapping;
	}

	public List<String> getInquirySource() {
		return inquirySource;
	}

	public void setInquirySource(List<String> inquirySource) {
		this.inquirySource = inquirySource;
	}

	public OrgPreferences getOrgPreferences() {
		return orgPreferences;
	}

	public void setOrgPreferences(OrgPreferences orgPreferences) {
		this.orgPreferences = orgPreferences;
	}

	public String getWorkflowStatus() {
		return workflowStatus;
	}

	public void setWorkflowStatus(String workflowStatus) {
		this.workflowStatus = workflowStatus;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public String getWorkflowRemarks() {
		return workflowRemarks;
	}

	public void setWorkflowRemarks(String workflowRemarks) {
		this.workflowRemarks = workflowRemarks;
	}

	public List<OrgMetaDataAdminDetail> getSuperAdmins() {
		return superAdmins;
	}

	public void setSuperAdmins(List<OrgMetaDataAdminDetail> superAdmins) {
		this.superAdmins = superAdmins;
	}

	public boolean isEnableOrgLevelMetaData() {
		return enableOrgLevelMetaData;
	}

	public void setEnableOrgLevelMetaData(boolean enableOrgLevelMetaData) {
		this.enableOrgLevelMetaData = enableOrgLevelMetaData;
	}
}
