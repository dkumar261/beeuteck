package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

import dev.morphia.annotations.Embedded;

@Embedded
public class FavoriteContact implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8364974679227850228L;
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private String name;
	private String email;
	//mapToGroupsName groupnames is a comma separated list of groups map to a user .this list can be shared to other groups using below variable sharedToGroupsName
	//when user select from in the message check happen here and top contact display accordingly .
	private String mapToGroupsName;
	private String sharedToGroupsName;
	private Date crtDate;
	private Date modDate;
    private String createdBy;
    ///[C153176-410] top contacts change to pop up window with additional information
    private String contactAddress;
    private String contactNote;
    private String contactPhNumber;
	
   
	public FavoriteContact()
	{

	}

	public FavoriteContact(Date crtDate, String email, Date modDate, String name,String mapToGroupsName,String sharedToGroupsName,String userId,
			String contactAddress,String contactNote,String contactPhNumber )
	{
		this.crtDate = crtDate;
		this.email = email;
		this.modDate = modDate;
		this.name = name;
		this.mapToGroupsName = mapToGroupsName;
		this.sharedToGroupsName=sharedToGroupsName;
		this.createdBy=userId;
		this.contactAddress=contactAddress;
		this.contactNote=contactNote;
		this.contactPhNumber=contactPhNumber;
		
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getCrtDate() {
		return crtDate;
	}

	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}

	public Date getModDate() {
		return modDate;
	}

	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}

	public String getMapToGroupsName() {
		return mapToGroupsName;
	}

	public void setMapToGroupsName(String mapToGroupsName) {
		this.mapToGroupsName = mapToGroupsName;
	}

	public String getSharedToGroupsName() {
		return sharedToGroupsName;
	}

	public void setSharedToGroupsName(String sharedToGroupsName) {
		this.sharedToGroupsName = sharedToGroupsName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
   
	 public String getContactAddress()
	{
		return contactAddress;
	}

	public void setContactAddress(String contactAddress)
	{
		this.contactAddress = contactAddress;
	}

	public String getContactNote()
	{
		return contactNote;
	}

	public void setContactNote(String contactNote)
	{
		this.contactNote = contactNote;
	}

	public String getContactPhNumber()
	{
		return contactPhNumber;
	}

	public void setContactPhNumber(String contactPhNumber)
	{
		this.contactPhNumber = contactPhNumber;
	}

	@Override
		public boolean equals(Object object) 
	    {
	    	if(object==null)
	    	{
	    		return false;
	    	}
	    	FavoriteContact favCts=(FavoriteContact)object;
	    	if(this.name==null)
	    	{
	    		this.name="";
	    	}
	    	if(this.email==null)
	    	{
	    		this.email="";
	    	}
	    	if(this.sharedToGroupsName==null)
	    	{
	    		this.sharedToGroupsName="";
	    	}
	    	if(this.mapToGroupsName==null)
	    	{
	    		this.mapToGroupsName="";
	    	}
	    	if(this.createdBy==null)
	    	{
	    		this.createdBy="";
	    	}
	        if(this.name.equals(favCts.getName()) && this.email.equals(favCts.getEmail()) && this.sharedToGroupsName.equals(favCts.getSharedToGroupsName())
	        		&& this.mapToGroupsName.equals(favCts.getMapToGroupsName()) && this.createdBy.equals(favCts.getCreatedBy()))
	        {
	        	return true;
	        }
	        else
	        {
	        	return false;
	        }
	    }
	    @Override
	   	public  int hashCode() 
	    {
	       	 return Integer.parseInt(String.valueOf((this.name+this.email+this.mapToGroupsName+this.sharedToGroupsName).hashCode()));
	    }

}
