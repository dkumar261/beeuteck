package com.citi.icg.qma.dao;

public enum ProcessingStatus {
	
	OPEN, IN_PROGRESS, PROCESSED, WARNING, FAILED
}
