package com.citi.icg.qma.common.server.util;



import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.BasicConfigurator;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.util.ContextInitializer;

public class LoggerUtil {

	private static final Logger log = (Logger) LoggerFactory.getLogger(LoggerUtil.class);
	public static void basicConfigure() {
		log.info("Setting up basic configuration for jUnit");
		BasicConfigurator basicConfig = new BasicConfigurator();
		basicConfig.configure(log.getLoggerContext());
		log.setLevel(Level.DEBUG);
	}
	public static void setLogFileName(String logFileName) {
		log.info("Log file name:"+logFileName);
		System.setProperty("log.name", logFileName);
		LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();
		ContextInitializer ci = new ContextInitializer(lc);
		lc.reset();
		try{
		ci.autoConfig();
		}catch(Exception ex){
			log.info("error");
		}
		/*LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();

	    FileAppender fileAppender = new FileAppender();
	    fileAppender.setContext(loggerContext);
	    fileAppender.setName(logFileName);
	    // set the file name
	    fileAppender.setFile("logs/" + logFileName+".log");

	    PatternLayoutEncoder encoder = new PatternLayoutEncoder();
	    encoder.setContext(loggerContext);
	    encoder.setPattern("[%d{MM/dd HH:mm:ss,SSS}] %-5level [%thread] %logger{35} - %msg%n");
	    encoder.start();

	    fileAppender.setEncoder(encoder);
	    fileAppender.start();

	    // attach the rolling file appender to the logger of your choice
	    Logger logbackLogger = loggerContext.getLogger(logger.getName());
	    logbackLogger.addAppender(fileAppender);
	    return logbackLogger;
*/	}
}
