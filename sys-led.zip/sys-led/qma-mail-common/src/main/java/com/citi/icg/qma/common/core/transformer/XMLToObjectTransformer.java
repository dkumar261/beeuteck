package com.citi.icg.qma.common.core.transformer;

import org.apache.commons.collections4.Transformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class XMLToObjectTransformer implements Transformer
{
    private DefaultMarshaller defMrshaller;
    private boolean validate;
    private Logger log;
    
    public XMLToObjectTransformer(Class classType, boolean validate)
    {
        this.defMrshaller = new DefaultMarshaller(classType);
        this.validate = validate;
        
    	log = LoggerFactory.getLogger(getClass());
    	log.debug("XMLToObjectTransformer created for class : {}" ,classType.getName());
    }

    public XMLToObjectTransformer(Class<?> classType)
    {
    	this(classType, false);
    }

    public Object transform(Object object) throws TransformationExcept
    {
        Object javaObject = null;
        String xml = (String) object;

        javaObject = defMrshaller.unmarshal(xml, validate);

        return javaObject;
    }
}
