package com.citi.icg.qma.common.core.util;

public enum MsgSourceType {
	shared, personal; 
		
}