package com.citi.icg.qma.common.server.dao.persistence;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.server.dao.ClientMapping;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.Country;
import com.citi.icg.qma.common.server.dao.CustomClientCriteriaRuleBean;
import com.citi.icg.qma.common.server.dao.EmailAlias;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.GroupRole;
import com.citi.icg.qma.common.server.dao.HierarchyOrgDetails;
import com.citi.icg.qma.common.server.dao.HierarchyUserDetail;
import com.citi.icg.qma.common.server.dao.HolidayMaster;
import com.citi.icg.qma.common.server.dao.ManagementHeirarchy;
import com.citi.icg.qma.common.server.dao.OrganizationAuditTrail;
import com.citi.icg.qma.common.server.dao.StaticData;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.ViewConfig;
import com.citi.icg.qma.common.server.util.AgeAndTimeUtils.GroupShiftConfig;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.common.transferobject.SymphonyUserMapTO;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

import dev.morphia.query.Query;

public class CacheDAO extends MongoMorphiaDAO
{
	private static CacheDAO instance = null;
	private static final Logger subLogger = LoggerFactory.getLogger(CacheDAO.class);
	private static GenericDAO genericDAO = new GenericDAO();
	private static final String ERROR_MESSAGE="Error loading CacheDAO clientMappingMap";
	public static synchronized CacheDAO getInstance()//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
	{
		if (instance == null) {
			instance = new CacheDAO();
		}
		return instance;
	}
	
	/**
	 * return a new instance with all maps reloaded
	 * used to populate hazelcast
	 */
	public synchronized static CacheDAO getFreshInstance(){
		instance=new CacheDAO();
		return instance;
	}
	
	//[C15176-347]- All inactive and active groups should be part of TO/CC recipients
	private Map<String, Long> groupCodeToIdMapBothActiveInactive;
	private Map<String, String> groupIdToCodeMapBothActiveInactive;
	private Map<String, String> groupIdToEmailMapBothActiveInactive;
	private Map<String, User> userDetailsMapInactiveActive;

	private Map<String, String> groupIdToCodeMap;
	private Map<String, Long> groupCodeToIdMap;
	private Map<Long, List<String>> groupIdToReqTypesMap;
	private Map<String, User> userDetailsMap;
	private Map<String, ViewConfig> defaultViewMap;
	private List<String> defaultViewNameList;
	private String defaultInboxName;
	private StaticData defaultStaticData;
	private Map<String, String> groupIdToDBCodeMap;
	//group email to name cache will be used to replace group email with name when directly come from UI 
	private Map<String, String> groupEmailToCodeMap;
	private Map<String, String> groupIdToEmailMap;
	private Map<Long, List<String>> groupIdToUserListMap;
	private Map<Long, Group> allGroupsMap;
	private Map<String, Config> configIdMap;
	private Map<String, Group> emailWithDomaintoGroupMap;
	
	//[C153176-1273]- Child group does not receive the mail in QMA for Mail sent from QMA to Parent
	private Map<String, List<String>> parentToChildDLsListMap; 
	private LinkedHashMap<String,String> msExchangeServerMap ;
	private Map<String,List<HolidayMaster>> holidayMaster;
	private Map<Long,GroupShiftConfig> groupAgeConfigMap;
	private Map<String, ClientMapping> clientMappingMap;
	private Map<String, SymphonyUserMapTO> userSymphonyIdToUserMap;
	
	private Map<Long, List<CustomClientCriteriaRuleBean>> dbCustomClientCriteriaList;
	
	private List<Long> personalGroupIdList = new ArrayList<Long>(); 
	private Map<String, Long> personalMailboxIdToGroupIdMap = new HashMap<String, Long>();
	private Map<Long, String> autoAssignmentEnabledGroupMap;
	private List<String> autoReplySuggestionEnabledGroupList;
	private List<String> custodySuggestionEnabledGroupList;
	private Map<String,List<Group>>orgGroupMap;
	private List<OrganizationAuditTrail>orgRequests;
	private List<String> intentSuggestionEnabledGroupList;
	
	public CacheDAO()
	{
		try
		{
			getGrpIdToCodeMapFromDB();
			getGrpIdToCodeMapFromDBActiveInactive();
			getUserIdToGroupsMapFromDB();
			getDefaultViewMapFromDB();
			//[C15176-347]- All inactive and active groups should be part of TO/CC recipients
			getUserIdToGroupsMapFromDBActiveInactive();
			loadHolidayMaster();
			getAllGroupsData();
			loadConfigData();
			populateParentToChildDLsList();
			loadMSExchangeSeverDetails();
			loadClientMappings();
			//C170665-185 for hard code data point
		}
		catch (Exception e)
		{
			subLogger.error("Error Server cache init . Exiting from system", e);
			System.exit(1);

		}
	}

	private void loadMSExchangeSeverDetails() throws CommunicatorException {
		msExchangeServerMap = (LinkedHashMap<String, String>) genericDAO.fetchMSExchangeServerConfigFromDB(configIdMap);
		if(msExchangeServerMap.isEmpty())
		{
			throw new CommunicatorException("Error loading CacheDAO loadMSExchangeSeverDetails");
		}
	}

	private void getAllGroupsData()
	{
		allGroupsMap = new HashMap<Long, Group>();
		groupAgeConfigMap = new HashMap<>();
		Query<Group> query = mongoDatastore.createQuery(Group.class);
		List<Group> groupList = query.asList();
		HashMap<Long, List<CustomClientCriteriaRuleBean>> customClientCategoryCriteriasMapTemp = new HashMap<Long, List<CustomClientCriteriaRuleBean>>();
		for (Group group: groupList) {

			allGroupsMap.put(group.id, group);
			populateGroupCustomClientCategoryCache(customClientCategoryCriteriasMapTemp, group);

			try {
				if(null != group.id && null != group.getHolidayAndShiftDetails()
						&& group.getHolidayAndShiftDetails().isHolidayBasedAgeCalculation()) {
					groupAgeConfigMap.put(group.id, getGroupConfig(group));
				}
			} catch (Exception e) {
				subLogger.error("Exception while collection group age data :" ,e);
			}
		}
		dbCustomClientCriteriaList  = customClientCategoryCriteriasMapTemp;
	}
	
	private Map<Long, List<CustomClientCriteriaRuleBean>> populateGroupCustomClientCategoryCache(HashMap<Long, List<CustomClientCriteriaRuleBean>> customClientCategoryCriteriasMapTemp, com.citi.icg.qma.common.server.dao.Group group)
	{
		try {
			List<CustomClientCriteriaRuleBean> customClientCategoryCriteriaList;
			
			if (group.getCustomClientCategory() != null ){
				for (com.citi.icg.qma.common.server.dao.CustomClientCriteria customClientCategoryCriteria : group.getCustomClientCategory()){
					if (customClientCategoryCriteriasMapTemp.keySet().contains(group.getId()))
					{
						customClientCategoryCriteriaList = customClientCategoryCriteriasMapTemp.get(group.getId());
					}
					else
					{
						customClientCategoryCriteriaList = new ArrayList<>();
					}
					// copy routingCriteria mongo object data into the routing criteria bean.
					customClientCategoryCriteriaList.add(copyCustomClientCriteriaEntityToRoutingCriteriaBean(group, customClientCategoryCriteria));
					customClientCategoryCriteriasMapTemp.put(group.getId(), customClientCategoryCriteriaList);
					
				}
			}	
		} catch (Exception e) {
			subLogger.error("Exception in populateGroupCustomClientCategoryCache with exception =", e);
		}
		return customClientCategoryCriteriasMapTemp;
	}
	
	public CustomClientCriteriaRuleBean copyCustomClientCriteriaEntityToRoutingCriteriaBean(Group gEntity, com.citi.icg.qma.common.server.dao.CustomClientCriteria customClientCriteria)
	{
		CustomClientCriteriaRuleBean routingCriteriaBean = new CustomClientCriteriaRuleBean();
		try {
			routingCriteriaBean.setGroupId(gEntity.getId());
			routingCriteriaBean.setGroupEmail(gEntity.getGroupEmail());
			routingCriteriaBean.setGroupName(gEntity.getGroupName());
			if(customClientCriteria != null && customClientCriteria.getRules() != null){
				if("SUBJECT".equalsIgnoreCase(customClientCriteria.getRules().getField().trim())){
					routingCriteriaBean.setSubjectOperator(customClientCriteria.getRules().getOperators());
					routingCriteriaBean.setSubject(customClientCriteria.getRules().getValue());
				}
				else if("FROM".equalsIgnoreCase(customClientCriteria.getRules().getField().trim())){
					routingCriteriaBean.setFromOperator(customClientCriteria.getRules().getOperators());
					routingCriteriaBean.setFrom(customClientCriteria.getRules().getValue());
				}
				else if("TO".equalsIgnoreCase(customClientCriteria.getRules().getField().trim())){
					routingCriteriaBean.setToOperator(customClientCriteria.getRules().getOperators());
					routingCriteriaBean.setTo(customClientCriteria.getRules().getValue());
				}
				routingCriteriaBean.setCategoryName(customClientCriteria.getCategoryName());
				routingCriteriaBean.setColorCode(customClientCriteria.getColorCode());
			}
		} catch (Exception e) {
			subLogger.error("Exception in copyCustomClientCriteriaEntityToRoutingCriteriaBean with exception ",e);
		}
		return routingCriteriaBean;
	}
	
	

	private GroupShiftConfig getGroupConfig(Group group) {
		GroupShiftConfig groupConfig = new GroupShiftConfig();
		getGroupShiftConfig(groupConfig, group);
		getGroupHolidays(groupConfig, group);
		return groupConfig;
		
	}
	
	private void getGroupShiftConfig(GroupShiftConfig groupConfig, Group group) {
		if (null != group.getTimeZone()) {
			Config timeZonesConfig = loadConfigData().get("timeZones");
			List<com.citi.icg.qma.common.server.dao.TimeZone> timeZones = timeZonesConfig.getTimeZones();
			for (com.citi.icg.qma.common.server.dao.TimeZone ctz : timeZones) {
				if (ctz.getTimeZoneCode().equalsIgnoreCase(group.getTimeZone())
						&& null != group.getHolidayAndShiftDetails()) {
					groupConfig.setTimeZone(ctz.getTimeZone());
					groupConfig.setShiftStartTime(group.getHolidayAndShiftDetails().getShiftStartTime());
					groupConfig.setShiftEndTime(group.getHolidayAndShiftDetails().getShiftEndTime());
					groupConfig.setWeeklyOffs(group.getHolidayAndShiftDetails().getWeeklyOffDays());
					groupConfig.setShiftHoursInMins(
							getShiftHourseInMins(group.getHolidayAndShiftDetails().getShiftStartTime(),
									group.getHolidayAndShiftDetails().getShiftEndTime()));
					groupConfig.setHolidayBasedCalculation(group.getHolidayAndShiftDetails().isHolidayBasedAgeCalculation());
					break;
				}
			}
		}
	}
	
	int getShiftHourseInMins(String shiftStartTime, String shiftEndTime) {
		int nofOfMins = 0;
		try {
			if(StringUtils.isNotEmpty(shiftStartTime) && StringUtils.isNotEmpty(shiftEndTime)) {
				String[] shiftStart= shiftStartTime.split(":");
				int sHour = Integer.parseInt(shiftStart[0]);
				int sMins = Integer.parseInt(shiftStart[1]);
				
				String[] shiftEnd = shiftEndTime.split(":");
				int eHour = Integer.parseInt(shiftEnd[0]);
				int eMins = Integer.parseInt(shiftEnd[1]);
				
				Calendar end = new GregorianCalendar();
				end.set(Calendar.HOUR_OF_DAY,eHour);
				end.set(Calendar.MINUTE,eMins);
				Calendar start = new GregorianCalendar();
				start.set(Calendar.HOUR_OF_DAY,sHour);
				start.set(Calendar.MINUTE,sMins);
				
				long shiftDiff = end.getTimeInMillis() - start.getTimeInMillis();
				shiftDiff = shiftDiff/(1000*60);
				nofOfMins = (int) shiftDiff;
			}
		} catch (Exception e) {
			subLogger.error("Exception while generating shift hours in mins :",e);
		}
		return nofOfMins;
	}

	/**
	 * This method provides group level holidays
	 * @param groupConfig
	 * @param group
	 * @param logger
	 */
	private void getGroupHolidays(GroupShiftConfig groupConfig, Group group) {
		try {
			if( groupConfig != null && group != null && group.getCountry()!=null){
				String groupCountryCode = group.getCountry();
				List<HolidayMaster> groupHolidays = getHolidayMasterForCountryCode(groupCountryCode);
				getGroupHolidays(groupConfig, groupHolidays);
			}
		} catch (ParseException e) {
			subLogger.error("Exception : ",e);
		}
	}

	/**
	 * This method provides group level holidays
	 * @param groupConfig
	 * @param logger
	 * @param groupHolidays
	 * @throws ParseException
	 */
	private void getGroupHolidays(GroupShiftConfig groupConfig, List<HolidayMaster> groupHolidays)
			throws ParseException {
		if(groupHolidays != null && !groupHolidays.isEmpty()) {
			List<String> grpHolidayList = new ArrayList<>();
			for(HolidayMaster holiday : groupHolidays){
				Date holidayDate = holiday.getHolidayDate();
				Calendar cal = Calendar.getInstance();
				cal.setTimeZone(TimeZone.getTimeZone("GMT"));
				cal.setTime(holidayDate);
				String formattedDateString = cal.get(Calendar.DAY_OF_MONTH) + "-"  + (cal.get(Calendar.MONTH)+1)  + "-" + cal.get(Calendar.YEAR);
				grpHolidayList.add(formattedDateString);
			}
			groupConfig.setHolidays(grpHolidayList);
		}
	}

	private void getUserIdToGroupsMapFromDB() throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			HashMap<Long, List<String>> groupIdToUserListMap1 = new HashMap<Long, List<String>>();
			HashMap<String, User> userDetailsMap1 = new HashMap<String, User>();
			List<GroupRole> groupRoleList;
			Map<Long, String> groupList;
			Query<User> query = mongoDatastore.createQuery(User.class);
			List<User> userList = query.asList();

			for (User user : userList)
			{
				if (user.getName() != null)
				{
					userDetailsMap1.put(user.getId().toUpperCase(), user);
				}
				groupRoleList = new ArrayList<GroupRole>();
				if (user.getGroupRoles() != null)
				{
					groupRoleList = user.getGroupRoles();

					groupList = new HashMap<Long, String>();

					for (GroupRole grpRole : groupRoleList)
					{
						if(grpRole.getGroupId() != null && groupIdToCodeMap.get(grpRole.getGroupId().toString()) != null)
						{
							groupList.put(grpRole.getGroupId(), groupIdToCodeMap.get(""+grpRole.getGroupId()));  //<<-- sonar fix A "Map<String, String>" cannot contain a "Long" in a "String" type.
							if(groupIdToUserListMap1.get(grpRole.getGroupId())== null)
							{
								List<String> usrList = new ArrayList<String>();
								usrList.add(user.getId());
								groupIdToUserListMap1.put(grpRole.getGroupId(), usrList);

							}else
							{
								List<String> usrList = groupIdToUserListMap1.get(grpRole.getGroupId());
								if(!usrList.contains(user.getId()))
								{
									groupIdToUserListMap1.get(grpRole.getGroupId()).add(user.getId());
								}
							}
							
						}
					}
				}

			}
			
			//Keep temp cache ready and then assign to  main cache..Optimal solution for UI for time being.
			userDetailsMap = userDetailsMap1;
			groupIdToUserListMap= groupIdToUserListMap1;
			
		}
		catch (Exception e)
		{
			subLogger.error("Exception in CacheDao.getUserIdToGroupsMapFromDB", e);
			
			throw new CommunicatorException("Exception in CacheDao.getUserIdToGroupsMapFromDB", e);
		}
	}
	
	//[C15176-347]- All inactive and active groups should be part of TO/CC recipients
	private void getUserIdToGroupsMapFromDBActiveInactive() throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			HashMap<String, Map<Long, String>> userIdToGroupsMap1 = new HashMap<String, Map<Long, String>>();
			HashMap<String, User> userDetailsMap1 = new HashMap<String, User>();
			List<GroupRole> groupRoleList;
			Map<Long, String> groupList;
			Query<User> query = mongoDatastore.createQuery(User.class);
			List<User> userList = query.asList();

			for (User user : userList)
			{
				if (user.getName() != null)
				{
					userDetailsMap1.put(user.getId().toUpperCase(), user);
				}
				groupRoleList = new ArrayList<GroupRole>();
				if (user.getGroupRoles() != null)
				{
					groupRoleList = user.getGroupRoles();

					groupList = new HashMap<Long, String>();

					for (GroupRole grpRole : groupRoleList)
					{
						if(groupIdToCodeMapBothActiveInactive.get(""+grpRole.getGroupId()) != null) //<<-- sonar fix A "Map<String, String>" cannot contain a "Long" in a "String" type.
						{
							groupList.put(grpRole.getGroupId(), groupIdToCodeMapBothActiveInactive.get(""+grpRole.getGroupId())); //<<-- sonar fix A "Map<String, String>" cannot contain a "Long" in a "String" type.
						}
					}
					userIdToGroupsMap1.put(user.getId(), groupList);
				}

			}
			
			//Keep temp cache ready and then assign to  main cache..Optimal solution for UI for time being.
			userDetailsMapInactiveActive = userDetailsMap1;
			
		}
		catch (Exception e)
		{
			subLogger.error("Exception in CacheDao.getUserIdToGroupsMapFromDBActiveInactive", e);
			
			throw new CommunicatorException("Exception in CacheDao.getUserIdToGroupsMapFromDBActiveInactive", e);
		}
	}

	private void getGrpIdToCodeMapFromDB() throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			HashMap<String, String> groupIdToCodeMap1 = new HashMap<String, String>();
			HashMap<String, Long> groupCodeToIdMap1 = new HashMap<String, Long>();
			HashMap<Long, List<String>> groupIdToReqTypesMap1 = new HashMap<Long, List<String>>();
			HashMap<String, String> groupIdToDBCodeMap1 = new HashMap<String, String>();
			groupEmailToCodeMap = new HashMap<String, String>();
			groupIdToEmailMap = new HashMap<String, String>();
			HashMap<String, Group> emailWithDomaintoGroupMapTemp = new HashMap();
			orgGroupMap=new HashMap<String,List<Group>>();
			Map<String,List<Group>>orgGroupMapTemp=new HashMap<String,List<Group>>();
			String secondLevelHierarchyUserName = "";
			String orgHierarchyOrgName = "";
			String orgName = "";
			Query<Group> query = mongoDatastore.createQuery(Group.class);
			List<Group> groupList = query.asList();
			for (Group group : groupList)
			{
				if(group != null && group.getActive() != null && group.getActive().booleanValue())
				{
					groupIdToCodeMap1.put(group.id.toString(), group.getGroupName());
					groupCodeToIdMap1.put(group.getGroupName().toUpperCase(), group.id);
					groupIdToReqTypesMap1.put(group.id, group.getRequestTypes());
					groupIdToDBCodeMap1.put(group.id.toString(), group.getGroupName());
					if (null != group.getGroupEmail()){
						emailWithDomaintoGroupMapTemp.put(group.getGroupEmail().toUpperCase(), group);
					}
					// Extract only group email till @ symbol so that it will not be domain specific 
					if (group.getGroupEmail() != null && group.getGroupEmail().indexOf('@') > -1)
					{
						groupIdToEmailMap.put(group.id.toString(), group.getGroupEmail());
						groupEmailToCodeMap.put(group.getGroupEmail().substring(0, group.getGroupEmail().indexOf('@')).toUpperCase(), group.getGroupName().toUpperCase());
					}
					
					// Populate the map user SOEID to Group Id.
					if(!Objects.isNull(group.getGroupType()) && group.getGroupType().equalsIgnoreCase("personal")) {
						personalGroupIdList.add(group.getId());
						// personalMailboxId is corresponds to SOEID in CITI.
						personalMailboxIdToGroupIdMap.put(group.getPersonalMailboxId(), group.getId());
					}	
				}
				// populate org group for hard code data point C170665-185
				ManagementHeirarchy heirarchy = null == group ? null : group.getHeirarchyData(); //<-- sonar fix A "NullPointerException" could be thrown; "group" is nullable here.
				if (heirarchy != null && heirarchy.getSecondLevelHeirarchy() != null
						&& heirarchy.getOrgHierarchy() != null) {
					List<HierarchyUserDetail> secondLevelHeirarchy = heirarchy.getSecondLevelHeirarchy();
					List<HierarchyOrgDetails> orgHierarchy = heirarchy.getOrgHierarchy();
					if (null != orgHierarchy && orgHierarchy.size() > 0 && null != secondLevelHeirarchy
							&& secondLevelHeirarchy.size() > 0) {
						for (HierarchyOrgDetails hierarchyOrgDetails : orgHierarchy) {// for org name
							if (hierarchyOrgDetails.getLevel().equalsIgnoreCase("L3")) {
								orgHierarchyOrgName = hierarchyOrgDetails.getOrgName();
								break;
							}
						}
						for (HierarchyUserDetail secondLevelData : secondLevelHeirarchy) {
							secondLevelHierarchyUserName = secondLevelData.getUserName();
						}
						orgName = orgHierarchyOrgName + "(" + secondLevelHierarchyUserName + ")";
						if (null != orgName) {
							List<Group> grpList = new ArrayList<>();
							if (orgGroupMapTemp.containsKey(orgName)) {
								grpList = orgGroupMapTemp.get(orgName);
								grpList.add(group);
								orgGroupMapTemp.put(orgName, grpList);
							} else {
								grpList.add(group);
								orgGroupMapTemp.put(orgName, grpList);
							}
						}
					}
				}
			}
			
			//Keep temp cache ready and then assign to  main cache..Optimal solution for UI for time being.
			groupIdToCodeMap = groupIdToCodeMap1;
			groupCodeToIdMap = groupCodeToIdMap1;
			groupIdToReqTypesMap = groupIdToReqTypesMap1;
			groupIdToDBCodeMap = groupIdToDBCodeMap1;
			emailWithDomaintoGroupMap = emailWithDomaintoGroupMapTemp;
			orgGroupMap=orgGroupMapTemp; //populate org group for hard code data point C170665-185

		}
		catch (Exception e)
		{
			subLogger.error("Exception in CacheDao.getGrpIdToCodeMapFromDB", e);
			throw new CommunicatorException("Exception in CacheDao.getGrpIdToCodeMapFromDB", e);
		}
	}

	//[C15176-347]- All inactive and active groups should be part of TO/CC recipients. start
	private void getGrpIdToCodeMapFromDBActiveInactive() throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			HashMap<String, String> groupIdToCodeMap2 = new HashMap<String, String>();
			HashMap<String, Long> groupCodeToIdMap2 = new HashMap<String, Long>();
			HashMap<String, String> groupIdToIdEmailMap = new HashMap<String, String>();
			HashMap<Long, String> autoAssignmentEnabledGroupMapLocal = new HashMap<>();
			List<String> autoReplySuggestionEnabledTempList = new ArrayList<>();
			List<String> custodySuggestionEnabledListTemp = new ArrayList<>();
			List<String> intentSuggestionEnabledListTemp = new ArrayList<>();
			Query<Group> query = mongoDatastore.createQuery(Group.class);
			List<Group> groupList = query.asList();
			for (Group group : groupList)
			{
				//[C15176-347]- All inactive and active groups should be part of TO/CC recipients. start
				if(group != null && group.getActive() != null)
				{
					groupIdToCodeMap2.put(group.id.toString(), group.getGroupName());
					groupCodeToIdMap2.put(group.getGroupName().toUpperCase(), group.id);
					if (null!=group.getGroupEmail() && group.getGroupEmail().indexOf('@') > -1) //<-- sonar fix Correct one of the identical sub-expressions on both sides of operator "&&"
					{
						groupIdToIdEmailMap.put(group.id.toString(), group.getGroupEmail());
					}
				}
				//[C15176-347]- All inactive and active groups should be part of TO/CC recipients. end
				
				if(group != null && group.isEnableAutoAssignment() ) {
					autoAssignmentEnabledGroupMapLocal.put(group.id, group.getGroupName().toUpperCase());
				}
				if(group != null && group.isEnableAutoReplySuggestion() ) {
					autoReplySuggestionEnabledTempList.add(group.getGroupName().toUpperCase());
				}
				if(group != null && group.isEnableCustodySuggestion()) {
					custodySuggestionEnabledListTemp.add(group.getGroupName().toUpperCase());
				}
				if(group != null && group.isEnableIntentSuggestion()){
					intentSuggestionEnabledListTemp.add(group.getGroupName().toUpperCase());
				}

			}
			//Keep temp cache ready and then assign to  main cache..Optimal solution for UI for time being 
			//[C15176-347]- All inactive and active groups should be part of TO/CC recipients. start
			groupIdToCodeMapBothActiveInactive=groupIdToCodeMap2;
			groupCodeToIdMapBothActiveInactive = groupCodeToIdMap2;	
			groupIdToEmailMapBothActiveInactive=groupIdToIdEmailMap;
			autoAssignmentEnabledGroupMap = autoAssignmentEnabledGroupMapLocal;
			autoReplySuggestionEnabledGroupList = autoReplySuggestionEnabledTempList;
			custodySuggestionEnabledGroupList = custodySuggestionEnabledListTemp;
			intentSuggestionEnabledGroupList = intentSuggestionEnabledListTemp;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in CacheDao.getGrpIdToCodeMapFromDBAvtiveInactive", e);
			throw new CommunicatorException("Exception in CacheDao.getGrpIdToCodeMapFromDBAvtiveInactive", e);
		}
	}
	
	
	public void reloadCacheOnRequest()
	{
		subLogger.info("reloadCache init");
		try
		{
			getGrpIdToCodeMapFromDB();
			getGrpIdToCodeMapFromDBActiveInactive();
			getUserIdToGroupsMapFromDB();
			//[C15176-347]- All inactive and active groups should be part of TO/CC recipients. start
			getUserIdToGroupsMapFromDBActiveInactive();
			getAllGroupsData();
			loadConfigData();
			loadHolidayMaster();
			//C170665-185 for hard code data point
		}
		catch (Exception e)
		{
			subLogger.error("Error Server cache init.", e);

		}
		subLogger.info("reloadCache done.");
	}
	
	/**
	 * Reloading the reloadUserDetailsMap.
	 */
	public void reloadUserDetailsMapOnRequest(){
		subLogger.info("reloadCache for reloadUserDetailsMap init");
		try {
			getUserIdToGroupsMapFromDB();
		} catch (CommunicatorException e) {
			subLogger.error("Error Server cache init.", e);
		}
		subLogger.info("reloadCache for reloadUserDetailsMap done.");
	}
	
	public Map<String, Config> loadConfigData()
	{
		configIdMap = genericDAO.loadConfigDataFromDB();
		return configIdMap;
	}
	
	public Map<String, Config> updateNLPConfiguration() {
		subLogger.info("Updating NLP Configuration started.");
		try {
			//TODO : Extract only NLP records and update in existing Config data in cache
			configIdMap = genericDAO.loadConfigDataFromDB();
		} catch (Exception e) {
			subLogger.error("Updating NLP Configuration Failed.", e);
		}
		subLogger.info("Updating NLP Configuration finished.");
		return configIdMap;
	}
	
	private void getDefaultViewMapFromDB() throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			defaultViewMap = new HashMap<String, ViewConfig>();
			defaultViewNameList = new ArrayList<String>();
			Query<StaticData> query = mongoDatastore.createQuery(StaticData.class);
			defaultStaticData = query.limit(1).get();


			List<ViewConfig> defaultViews = defaultStaticData.getDefaultViews();
			if (defaultViews != null && !defaultViews.isEmpty())
			{
				int i = 0;
				for (ViewConfig defaultViewConfig : defaultViews)
				{
					String viewName = defaultViewConfig.getViewName();
					if (!StringUtils.isEmpty(viewName))
					{
						defaultViewMap.put(viewName, defaultViewConfig);
						defaultViewNameList.add(viewName);
						// First default view will be always inbox.
						if (i == 0)
						{
							defaultInboxName = defaultViewConfig.getViewName();

						}
						i++;
					}
				}
			}

		}
		catch (Exception e)
		{
			subLogger.error("Exception in CacheDao.getDefaultViewMapFromDB", e);
			throw new CommunicatorException("Exception in CacheDao.getDefaultViewMapFromDB", e);
		}
	}
	
	
	/**
	 * @param group
	 * We are create a ParentToChildDLsList. This method will iterate through all the Group 
	 * If the Parent Alias present then it iterates through all the group to find the corresponding Child group
	 * Creates a map where Parent DL is the key and List of child group is the value. 
	 * [C153176-1273]- Child group does not receive the mail in QMA for Mail sent from QMA to Parent
	 */
	private void populateParentToChildDLsList() {
		subLogger.info("Inside populateParentToChildDLsList() to Create parentToChildDLsListMap ");
		HashMap<String, List<String>> parentToChildDLsListMapTemp = new HashMap<String, List<String>>();
		Query<Group> query = mongoDatastore.createQuery(Group.class);
		List<Group> groupList = query.asList();
		List<String> parentDlList;

		for (Group group : groupList)
		{
			if (null != group.getParentDLAliases() && !group.getParentDLAliases().isEmpty() && group.getActive() != null && group.getActive().booleanValue()) {
				for (EmailAlias parentEmailAlias : group.getParentDLAliases())
				{
					if (null != parentEmailAlias.getEmails())
					{
						parentDlList = parentEmailAlias.getEmails();
						
						for (String parentDLEmail : parentDlList)
						{
							String parentDLEmailUpper = parentDLEmail.toUpperCase();
							String  parentDLEmailUpperaddressWithoutDomain = GenericUtility.getValidEmailWithoutDomain(parentDLEmailUpper);

							if (null != parentToChildDLsListMapTemp	&& parentToChildDLsListMapTemp.containsKey(parentDLEmailUpper)) 
							{
								if (!parentToChildDLsListMapTemp.get(parentDLEmailUpper).contains(group.getGroupEmail().toUpperCase()))
								{
								
									parentToChildDLsListMapTemp.get(parentDLEmailUpper).add(group.getGroupEmail().toUpperCase());
								}
								
							} 
							else
							{
								List<String> childDLList = new ArrayList<String>();
								
								
								childDLList.add(group.getGroupEmail().toUpperCase());
								
								parentToChildDLsListMapTemp.put(parentDLEmail.toUpperCase(), childDLList);
							}
							
							if (null != parentToChildDLsListMapTemp	&& parentToChildDLsListMapTemp.containsKey(parentDLEmailUpperaddressWithoutDomain)) 
							{
								if (!parentToChildDLsListMapTemp.get(parentDLEmailUpperaddressWithoutDomain).contains(group.getGroupEmail().toUpperCase()))
								{
								
									parentToChildDLsListMapTemp.get(parentDLEmailUpperaddressWithoutDomain).add(group.getGroupEmail().toUpperCase());
								}
								
							} 
							else
							{
								List<String> childDLList = new ArrayList<String>();
								
								
								childDLList.add(group.getGroupEmail().toUpperCase());
								if (parentDLEmailUpperaddressWithoutDomain != null) {
									parentToChildDLsListMapTemp.put(parentDLEmailUpperaddressWithoutDomain.toUpperCase(), childDLList);
								}
								
							}
							
							
						}
					}
				}
			}
		}
		
		//set it once cache is ready
		this.parentToChildDLsListMap = parentToChildDLsListMapTemp;
		subLogger.info("Finished populateParentToChildDLsList() to Create parentToChildDLsListMap ");
	}
	
	private void loadHolidayMaster() throws Exception {
		try {
			Config countryListConfig = loadConfigData().get("countryList");
			if (countryListConfig.getCountryList() != null) { //<<-- sonar fix Correct one of the identical sub-expressions on both sides of operator "&&"
				List<Country> countryList = countryListConfig.getCountryList();
				if (countryList != null && !countryList.isEmpty()) {
					
					Set<String> countryCodes = countryList.stream()
			                .map(Country::getCountryCode)
			                .collect(Collectors.toSet());
					
					List<HolidayMaster> holidayList = genericDAO.loadHolidayMasterFromDB();
					
					Map<String, List<HolidayMaster>> groupedHolidays = holidayList.stream()
			                .filter(h -> countryCodes.contains(h.getCountryCode())) // Filter holidays by country code
			                .collect(Collectors.groupingBy(HolidayMaster::getCountryCode));
					
					holidayMaster = groupedHolidays;
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception : ", e);
		}
	}
	
	//[C15176-347]- All inactive and active groups should be part of TO/CC recipients. start
	public Map<String, User> getUserDetailsMapInactiveActive() {
		return userDetailsMapInactiveActive;
	}

	public void setUserDetailsMapInactiveActive(Map<String, User> userDetailsMapInactiveActive) {
		this.userDetailsMapInactiveActive = userDetailsMapInactiveActive;
	}

	public Map<String, Long> getGroupCodeToIdMapBothActiveInactive() {
		return groupCodeToIdMapBothActiveInactive;
	}

	public void setGroupCodeToIdMapBothActiveInactive(Map<String, Long> groupCodeToIdMapBothActiveInactive) {
		this.groupCodeToIdMapBothActiveInactive = groupCodeToIdMapBothActiveInactive;
	}
	public Map<String, String> getGroupIdToCodeMapBothActiveInactive() {
		return groupIdToCodeMapBothActiveInactive;
	}

	public void setGroupIdToCodeMapBothActiveInactive(Map<String, String> groupIdToCodeMapBothActiveInactive) {
		this.groupIdToCodeMapBothActiveInactive = groupIdToCodeMapBothActiveInactive;
	}
	
	
	public Map<String, String> getGroupIdToEmailMapBothActiveInactive()
	{
		return groupIdToEmailMapBothActiveInactive;
	}

	public void setGroupIdToEmailMapBothActiveInactive(Map<String, String> groupIdToEmailMapBothActiveInactive)
	{
		this.groupIdToEmailMapBothActiveInactive = groupIdToEmailMapBothActiveInactive;
	}

	public Map<String, String> getGroupIdToCodeMap()
	{
		return groupIdToCodeMap;
	}

	public void setGroupIdToCodeMap(Map<String, String> groupIdToCodeMap)
	{
		this.groupIdToCodeMap = groupIdToCodeMap;
	}

	public Map<String, Long> getGroupCodeToIdMap()
	{
		return groupCodeToIdMap;
	}

	public void setGroupCodeToIdMap(Map<String, Long> groupCodeToIdMap)
	{
		this.groupCodeToIdMap = groupCodeToIdMap;
	}


	public Map<Long, List<String>> getGroupIdToReqTypesMap()
	{
		return groupIdToReqTypesMap;
	}

	public void setGroupIdToReqTypesMap(Map<Long, List<String>> groupIdToReqTypesMap)
	{
		this.groupIdToReqTypesMap = groupIdToReqTypesMap;
	}

	public Map<String, User> getUserDetailsMap()
	{
		return userDetailsMap;
	}

	public void setUserDetailsMap(Map<String, User> userDetailsMap)
	{
		this.userDetailsMap = userDetailsMap;
	}

	public Map<String, ViewConfig> getDefaultViewMap()
	{
		return defaultViewMap;
	}

	public void setDefaultViewMap(Map<String, ViewConfig> defaultViewMap)
	{
		this.defaultViewMap = defaultViewMap;
	}

	public List<String> getDefaultViewNameList()
	{
		return defaultViewNameList;
	}

	public void setDefaultViewNameList(List<String> defaultViewNameList)
	{
		this.defaultViewNameList = defaultViewNameList;
	}

	public StaticData getDefaultStaticData()
	{
		return defaultStaticData;
	}

	public void setDefaultStaticData(StaticData defaultStaticData)
	{
		this.defaultStaticData = defaultStaticData;
	}

	public String getDefaultInboxName()
	{
		return defaultInboxName;
	}

	public void setDefaultInboxName(String defaultInboxName)
	{
		this.defaultInboxName = defaultInboxName;
	}

	public Map<String, String> getGroupIdToDBCodeMap()
	{
		return groupIdToDBCodeMap;
	}

	public Map<String, String> getGroupEmailToCodeMap()
	{
		return groupEmailToCodeMap;
	}

	public void setGroupEmailToCodeMap(Map<String, String> groupEmailToCodeMap)
	{
		this.groupEmailToCodeMap = groupEmailToCodeMap;
	}

	public Map<String, String> getGroupIdToEmailMap()
	{
		return groupIdToEmailMap;
	}

	public void setGroupIdToEmailMap(Map<String, String> groupIdToEmailMap)
	{
		this.groupIdToEmailMap = groupIdToEmailMap;
	}

	


	
	public StaticData reloadStaticDataOnRequest()
	{
		subLogger.info("reloadStaticData init");
		Query<StaticData> query = mongoDatastore.createQuery(StaticData.class);
		defaultStaticData = query.limit(1).get();
		subLogger.info("reloadStaticData done.");
		return defaultStaticData;
	}

	public Map<Long, List<String>> getGroupIdToUserListMap()
	{
		return groupIdToUserListMap;
	}

	public void setGroupIdToUserListMap(Map<Long, List<String>> groupIdToUserListMap)
	{
		this.groupIdToUserListMap = groupIdToUserListMap;
	}

	public Map<Long, Group> getAllGroupsMap()
	{
		return allGroupsMap;
	}

	public void setAllGroupsMap(Map<Long, Group> allGroupsMap)
	{
		this.allGroupsMap = allGroupsMap;
	}

	public Map<String, Config> getConfigIdMap()
	{
		return configIdMap;
	}

	public void setConfigIdMap(Map<String, Config> configIdMap)
	{
		this.configIdMap = configIdMap;
	}

	
	public Map<String, List<String>> getParentToChildDLsListMap() {
		return parentToChildDLsListMap;
	}

	public void setParentToChildDLsListMap(Map<String, List<String>> parentToChildDLsListMap) {
		this.parentToChildDLsListMap = parentToChildDLsListMap;
	}
	public Map<String, Group> getEmailWithDomaintoGroupMap() {
		return emailWithDomaintoGroupMap;
	}


	public void setEmailWithDomaintoGroupMap(Map<String, Group> emailWithDomaintoGroupMap) {
		this.emailWithDomaintoGroupMap = emailWithDomaintoGroupMap;
	}

	public LinkedHashMap<String, String> getMsExchangeServerMap() {
		return msExchangeServerMap;
	}

	public void setMsExchangeServerMap(LinkedHashMap<String, String> msExchangeServerMap) {
		this.msExchangeServerMap = msExchangeServerMap;
	}

	
	public Map<String, List<HolidayMaster>> getHolidayMaster() {
		return holidayMaster;
	}
	
	public List<HolidayMaster> getHolidayMasterForCountryCode( String countrCode) {
		List<HolidayMaster> holidays = null;
		if(this.holidayMaster!=null && StringUtils.isNotBlank(countrCode)){
			holidays = this.holidayMaster.get(countrCode);
		}
		return holidays;
	}

	public void setHolidayMaster(Map<String, List<HolidayMaster>> holidayMaster) {
		this.holidayMaster = holidayMaster;
	}

	public Map<Long, GroupShiftConfig> getGroupAgeConfigMap() {
		return groupAgeConfigMap;
	}

	public void setGroupAgeConfigMap(Map<Long, GroupShiftConfig> groupAgeConfigMap) {
		this.groupAgeConfigMap = groupAgeConfigMap;
	}
    
	
	public Map<String, List<Group>> getOrgGroupMap() {
		return orgGroupMap;
	}

	public void setOrgGroupMap(Map<String, List<Group>> orgGroupMap) {
		this.orgGroupMap = orgGroupMap;
	}
    
	public List<OrganizationAuditTrail> getOrgRequests() {
		return orgRequests;
	}

	public void setOrgRequests(List<OrganizationAuditTrail> orgRequests) {
		this.orgRequests = orgRequests;
	}

	public static void main (String args[])
	{
		//CacheDAO cacheDao = CacheDAO.getInstance();
		
		//System.out.println(cacheDao.getParentToChildDLsListMap());
		//System.out.println(cacheDao.getOrgGroupMap());
		//System.out.println("org requests");
		//System.out.println(cacheDao.getOrgRequests());
		//subLogger.info(cacheDao.getParentToChildDLsListMap());
	}	
		
	/**
	 * This method refresh cache bases on Collection name from each node
	 * @param collectionName
	 * @throws IOException
	 */
	public String reloadDbCollectionFromServer(String collectionName){
		subLogger.info("CacheDAO#reloadDbCollectionFromServer init");
		
		List<String> serverList = this.defaultStaticData.getQmaMailServers();
		BasicDBObject responseResult = new BasicDBObject();
		BasicDBList content = new BasicDBList ();	
		String hostName = "";
		try {
			if(!serverList.isEmpty()){
				for(int i=0; i<serverList.size();i++){
					hostName = serverList.get(i);
					content = makeHttpRequest(hostName, collectionName, content);				
				}
			}
							
		} catch (Exception e) {
			subLogger.error("Error while refreshing cache in CacheDAO#reloadDbCollectionFromServer() :", e);
			responseResult.put(AppserverConstants.MESSAGE_KEY, hostName);
			responseResult.put(AppserverConstants.SUCCESS_KEY, "FAIL");
			content.add(responseResult);
			
		}
		subLogger.info("CacheDAO#reloadDbCollectionFromServer done.");
		return content.toString();	
		
	}
	
	/**
	 * This method gets URL based on server name
	 * @param hostName
	 * @param collectionName
	 * @return String
	 * @throws IOException
	 */
	private String getUrlByHostName(String hostName, String collectionName){
		String httpType = "http://";
		if(!("dev").equalsIgnoreCase(System.getProperty("icg.env"))){
			httpType = "https://";
		}
		String serviceName = ":20000/QMA/rest/generic/reload?r="+collectionName;
		return httpType + hostName + serviceName ;
	}
	
	/**
	 * This method makes server request to refresh cache
	 * @param hostName
	 * @param collectionName
	 * @return StringBuilder
	 * @throws IOException
	 */
	private BasicDBList makeHttpRequest(String hostName, String collectionName, BasicDBList content){
		HttpClient httpClient = HttpClientBuilder.create().build();
		BasicDBObject responseResult = new BasicDBObject();
		String url = "";
		try{
			if( httpClient != null ) {							
				url = getUrlByHostName(hostName, collectionName) ;
				HttpGet getRequest = new HttpGet(url);																
				HttpResponse response = httpClient.execute(getRequest);
				if (response.getStatusLine().getStatusCode() != 200) {
					responseResult.put(AppserverConstants.MESSAGE_KEY, url);
					responseResult.put(AppserverConstants.SUCCESS_KEY, "FAIL");
					content.add(responseResult);
				} else {
					responseResult.put(AppserverConstants.MESSAGE_KEY, url);
					responseResult.put(AppserverConstants.SUCCESS_KEY, "SUCCESS");
					content.add(responseResult);
					subLogger.info("Cache Refreshed for url: {} Response: {}", url, content);
				}
			} else {
				responseResult.put(AppserverConstants.MESSAGE_KEY, url);
				responseResult.put(AppserverConstants.SUCCESS_KEY, "FAIL");
				content.add(responseResult);
			}
		} catch (Exception e) {
			subLogger.error("Error while refreshing cache for server"+url+" in CacheDAO#reloadDbCollectionFromServer() :", e);
			responseResult.put(AppserverConstants.MESSAGE_KEY, url);
			responseResult.put(AppserverConstants.SUCCESS_KEY, "FAIL");
			content.add(responseResult);
		}
		return content;
	}	
	public Map<String, ClientMapping> getClientMappingMap() {
		return clientMappingMap;
	}

	public void setClientMappingMap(Map<String, ClientMapping> clientMappingMap) {
		this.clientMappingMap = clientMappingMap;
	}

	private void loadClientMappings() throws CommunicatorException {
		try {
			clientMappingMap = getClientMappingMapFromDB();
			if (clientMappingMap.isEmpty()) {
				throw new CommunicatorException(ERROR_MESSAGE);
			}
		} catch (Exception ex) {
			subLogger.error(ERROR_MESSAGE);
			throw new CommunicatorException(ERROR_MESSAGE, ex);
		}

	}
	private Map<String, ClientMapping> getClientMappingMapFromDB()
	{
		Map<String, ClientMapping> cmMap = new HashMap<>();

		Query<ClientMapping> query = mongoDatastore.createQuery(ClientMapping.class);

		List<ClientMapping> cmList = query.asList();

		for (ClientMapping cm : cmList)
		{
			cmMap.put(cm.getId().toUpperCase(), cm);
		}
		subLogger.info("ClientMapping DB resultList size : {}  and ClientMapping map side : {}", cmList.size(), cmMap.size());
		return cmMap;
	}

	public Map<Long, List<CustomClientCriteriaRuleBean>> getDbCustomClientCriteriaList() {
		return dbCustomClientCriteriaList;
	}

	public void setDbCustomClientCriteriaList(Map<Long, List<CustomClientCriteriaRuleBean>> dbCustomClientCriteriaList) {
		this.dbCustomClientCriteriaList = dbCustomClientCriteriaList;
	}
	
	public Map<String, SymphonyUserMapTO> getUserSymphonyIdToUserMap() {
		return userSymphonyIdToUserMap;
	}

	public void setUserSymphonyIdToUserMap(Map<String, SymphonyUserMapTO> userSymphonyIdToUserMap) {
		this.userSymphonyIdToUserMap = userSymphonyIdToUserMap;
	}

	public void loadUserSymphonyIdToSoeIdMap()
	{
		try
		{
			userSymphonyIdToUserMap = new HashMap<String, SymphonyUserMapTO>();
			Query<User> query = mongoDatastore.createQuery(User.class).retrievedFields(true, "_id").retrievedFields(true, "symphonyEmailId")
					.retrievedFields(true, "symphonyId");
			List<User> userList = query.asList();

			for (User user : userList)
			{
				if(null != user && null != user.getSymphonyId() && null != user.getId()) {
					SymphonyUserMapTO symphonyUserMapTO = new SymphonyUserMapTO();
					symphonyUserMapTO.setSoeId(user.getId());
					symphonyUserMapTO.setSymphonyEmailId(user.getSymphonyEmailId());
					symphonyUserMapTO.setSymphonyId(user.getSymphonyId());
					userSymphonyIdToUserMap.put(user.getSymphonyId(), symphonyUserMapTO);
				}
			}
			
		}
		catch (Exception e)
		{
			subLogger.error("Exception in CacheDao.loadUserSymphonyIdToSoeIdMap", e);
			
		}
	}

	public List<Long> getPersonalGroupIdList() {
		return personalGroupIdList;
	}

	public void setPersonalGroupIdList(List<Long> personalGroupIdList) {
		this.personalGroupIdList = personalGroupIdList;
	}

	public Map<String, Long> getPersonalMailboxIdToGroupIdMap() {
		return personalMailboxIdToGroupIdMap;
	}

	public void setPersonalMailboxIdToGroupIdMap(Map<String, Long> personalMailboxIdToGroupIdMap) {
		this.personalMailboxIdToGroupIdMap = personalMailboxIdToGroupIdMap;
	}

	/**
	 * Method to reload the server cache after the personal mail box group is created.
	 */
	public void reloadCachePersonalMailGroup() {
		subLogger.info("reloadCachePersonalMailGroup init");
		try {
			getGrpIdToCodeMapFromDB();
		} catch (Exception e) {
			subLogger.error("Error while relaod cache for personal mail group CacheDAO#reloadCachePersonalMailGroup init.", e);

		}
		subLogger.info("reloadCachePersonalMailGroup done.");
	}

	public Map<Long, String> getAutoAssignmentEnabledGroupMap() {
		return autoAssignmentEnabledGroupMap;
	}

	public void setAutoAssignmentEnabledGroupMap(Map<Long, String> autoAssignmentEnabledGroupMap) {
		this.autoAssignmentEnabledGroupMap = autoAssignmentEnabledGroupMap;
	}

	public void getOrgRequestsCache() {
		orgRequests = new ArrayList<>();
		try {
			Query<OrganizationAuditTrail> query = mongoDatastore.createQuery(OrganizationAuditTrail.class);
			orgRequests = query.asList();
		} catch (Exception e) {
			subLogger.error("Error while relaod cache for organization in cacheDAO.getOrgRequestsCache ", e);
		}
	}

	public List<String> getAutoReplySuggestionEnabledGroupList() {
		return autoReplySuggestionEnabledGroupList;
	}

	public void setAutoReplySuggestionEnabledGroupList(List<String> autoReplySuggestionEnabledGroupList) {
		this.autoReplySuggestionEnabledGroupList = autoReplySuggestionEnabledGroupList;
	}

	public List<String> getCustodySuggestionEnabledGroupList() {
		return custodySuggestionEnabledGroupList;
	}

	public void setCustodySuggestionEnabledGroupList(List<String> custodySuggestionEnabledGroupList) {
		this.custodySuggestionEnabledGroupList = custodySuggestionEnabledGroupList;
	}

	public List<String> getIntentSuggestionEnabledGroupList() {
		return intentSuggestionEnabledGroupList;
	}

	public void setIntentSuggestionEnabledGroupList(List<String> intentSuggestionEnabledGroupList) {
		this.intentSuggestionEnabledGroupList = intentSuggestionEnabledGroupList;
	}
	
}
