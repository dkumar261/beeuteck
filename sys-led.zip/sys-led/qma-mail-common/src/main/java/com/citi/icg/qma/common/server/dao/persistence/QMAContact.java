package com.citi.icg.qma.common.server.dao.persistence;

public class QMAContact
{

	private String email;
	private String firstName;
	private String lastName;
	private String srcSysId;
	private String clientID;
	private String clientName;
	private String clientIdType;
	private String jobTitle;
	private String phone;
	private String managementId;
	private String type;
	private String mnemonic;
	private String taxId;
	private String familyName;

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public String getClientID()
	{
		return clientID;
	}

	public void setClientID(String clientID)
	{
		this.clientID = clientID;
	}

	public String getClientName()
	{
		return clientName;
	}

	public void setClientName(String clientName)
	{
		this.clientName = clientName;
	}

	public String getJobTitle()
	{
		return jobTitle;
	}

	public void setJobTitle(String jobTitle)
	{
		this.jobTitle = jobTitle;
	}

	public String getPhone()
	{
		return phone;
	}

	public void setPhone(String phone)
	{
		this.phone = phone;
	}

	public String getManagementId()
	{
		return managementId;
	}

	public void setManagementId(String managementId)
	{
		this.managementId = managementId;
	}

	public String getSrcSysId()
	{
		return srcSysId;
	}

	public void setSrcSysId(String srcSysId)
	{
		this.srcSysId = srcSysId;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getMnemonic()
	{
		return mnemonic;
	}

	public void setMnemonic(String mnemonic)
	{
		this.mnemonic = mnemonic;
	}

	public String getClientIdType() {
		return clientIdType;
	}

	public void setClientIdType(String clientIdType) {
		this.clientIdType = clientIdType;
	}

	public String getTaxId() {
		return taxId;
	}

	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}
	
	

}
