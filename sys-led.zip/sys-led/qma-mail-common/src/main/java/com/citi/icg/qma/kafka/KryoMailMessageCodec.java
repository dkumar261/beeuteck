package com.citi.icg.qma.kafka;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.Session;
import jakarta.mail.internet.MimeMessage;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;


/*
 * Serializes and Deserializes Message using kryo
 */

public class KryoMailMessageCodec implements Serializer<Message>,Deserializer<Message>{
	
	private static final Logger log = LoggerFactory.getLogger(KryoMailMessageCodec.class);
	
	private ThreadLocal<Kryo> kryos = new ThreadLocal<Kryo>() {
		protected Kryo initialValue() {
			Kryo kryo = new Kryo();
			// TODO: why register so many ? 
			kryo.addDefaultSerializer(Message.class, new KryoInternalSerializer());
			kryo.addDefaultSerializer(MimeMessage.class, new KryoInternalSerializer());
			kryo.addDefaultSerializer(Message.class, new KryoInternalSerializer());
			kryo.register(Message.class,new KryoInternalSerializer());
			kryo.register(MimeMessage.class, new KryoInternalSerializer());
			kryo.register(Message.class, new KryoInternalSerializer());
			return kryo;
		};
	};

	@Override
	public void close() {

	}

	@Override
	public void configure(Map arg0, boolean arg1) {

	}

	@Override
	public byte[] serialize(String arg0, Message message) {

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		// TODO Increase max size of Output
		Output output = new Output(4096, 4096);
		output.setOutputStream(out);

		kryos.get().writeObject(output, message);

		return out.toByteArray();
	}


	@Override
	public Message deserialize(String arg0, byte[] bytes) {

		Message message=kryos.get().readObject(new Input(bytes), Message.class);
		return message;
	}

	private static class KryoInternalSerializer extends com.esotericsoftware.kryo.Serializer<Message> {

		@Override
		public void write(Kryo kryo, Output output, Message message) {

			try {
				message.writeTo(output);

			} catch (IOException e) {
				log.error("Error while Serializing ", e);

			} catch (MessagingException e) {
				log.error("Error while Serializing ", e);
			}

		}

		@Override
		public Message read(Kryo kryo, Input input, Class<? extends Message> arg2) {
			MimeMessage message = null;
			try {
				Properties props = new Properties();
				props.setProperty("mail.mime.address.strict", "false");
				props.setProperty("mail.mime.decodetext.strict", "false");
				Session session = Session.getDefaultInstance(props);
				message = new MimeMessage(session, input);
			} catch (Exception e) {
				log.error("Error while Serializing ", e);
			}
			return message;
		}

	}




}
