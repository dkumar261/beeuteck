package com.citi.icg.qma.common.server.dao.persistence.oasys.payments;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.persistence.MongoMorphiaDAO;
import com.mongodb.BasicDBObject;

import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

public class OasysPaymentRecordDao extends MongoMorphiaDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(OasysPaymentRecordDao.class);
	
	
	public void updateClcResponseForOasysPaymentProcessing(String clcCallbackRequestJson) {
		
		try {
			Date clcResponseReceivedDate = new Date();
			BasicDBObject reqObj = BasicDBObject.parse(clcCallbackRequestJson);
			String qmaRequestId = reqObj.getString("qmaUniqueId");
			
			Query<OasysPaymentRecord> findQuery = mongoDatastore.createQuery(OasysPaymentRecord.class).field("qmaRequestId").equal(qmaRequestId);
			UpdateOperations<OasysPaymentRecord> operations = mongoDatastore.createUpdateOperations(OasysPaymentRecord.class)
					.set("modDate", new Date());
			if (StringUtils.isNotEmpty(clcCallbackRequestJson)) { 
				operations.set("clcResponse", clcCallbackRequestJson);
			}			
			operations.set("clcResponseReceivedDate", clcResponseReceivedDate);
			mongoDatastore.update(findQuery, operations, false);
			logger.info("Updated clc response for qmaRequestId[" +qmaRequestId+ "]");
		} catch (Exception e) {
			logger.error("Failure in processing CLC response for oasys payment processing. ", e);
		}
		
	}

	
	
}
