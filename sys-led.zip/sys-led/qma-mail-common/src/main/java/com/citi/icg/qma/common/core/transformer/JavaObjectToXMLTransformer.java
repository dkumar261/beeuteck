package com.citi.icg.qma.common.core.transformer;

import java.beans.XMLEncoder;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.collections4.Transformer;

import com.citi.icg.qma.common.core.config.ConfigManager;

public class JavaObjectToXMLTransformer implements Transformer
{
	private static String xmlEncoder_enum_class = "JavaObjectToXMLTransformer.XMLEncoder.enum.class";
	
	public Object transform(Object object) throws TransformationExcept
	{
		String xml = null;
		
		try
		{
			ByteArrayOutputStream bao = new ByteArrayOutputStream();
			XMLEncoder xmlEncoder = new XMLEncoder(bao);
			if (object != null)
			{
				if (object.getClass().isEnum())
				{
					xmlEncoder.setPersistenceDelegate(object.getClass(), new EnumPersistenceDelegate() );
				}
				Field[] fields = object.getClass().getFields();
				for (Field field : fields)
				{
					if (field.isEnumConstant())
					{
						xmlEncoder.setPersistenceDelegate(field.getClass(), new EnumPersistenceDelegate() );
					}
				}
				
				for (String className : getEnumNames()) {
					xmlEncoder.setPersistenceDelegate(Class.forName(className), new EnumPersistenceDelegate());
				}
			}
			xmlEncoder.writeObject(object);
			xmlEncoder.close();
	    	xml = bao.toString();
		}
		catch(Exception e)
		{
			throw new TransformationExcept(e.getMessage(), e);
		}
    	
		return xml;
	}
	
	private static List<String> getEnumNames(){
		
		List<String> enumNames = new ArrayList<>();
		Properties props = ConfigManager.getInstance().getProperties();

		int i  = 0;
		String enumName = null;
		do {
			enumName = props.getProperty(xmlEncoder_enum_class + i);
			if(enumName != null) {
				enumNames.add(enumName);	
			}
			i++;
			
		} while (enumName != null);
		
		return enumNames;
	}
}
