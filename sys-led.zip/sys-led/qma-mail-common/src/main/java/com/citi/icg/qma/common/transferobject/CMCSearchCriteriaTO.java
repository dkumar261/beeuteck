package com.citi.icg.qma.common.transferobject;

public class CMCSearchCriteriaTO
{
	String firstName;
	String lastName;
	String contactEmail;
	String jobTitle;
	String clientIdentifierOption;
	String clientIdentifierValue;
	String toCcBcc;

	public CMCSearchCriteriaTO(String firstName, String lastName, String contactEmail, String jobTitle, String clientIdentifierOption, String clientIdentifierValue, String toCcBcc)
	{
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.contactEmail = contactEmail;
		this.jobTitle = jobTitle;
		this.clientIdentifierOption = clientIdentifierOption;
		this.clientIdentifierValue = clientIdentifierValue;
		this.toCcBcc = toCcBcc;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public String getContactEmail()
	{
		return contactEmail;
	}

	public void setContactEmail(String contactEmail)
	{
		this.contactEmail = contactEmail;
	}

	public String getJobTitle()
	{
		return jobTitle;
	}

	public void setJobTitle(String jobTitle)
	{
		this.jobTitle = jobTitle;
	}

	public String getClientIdentifierOption()
	{
		return clientIdentifierOption;
	}

	public void setClientIdentifierOption(String clientIdentifierOption)
	{
		this.clientIdentifierOption = clientIdentifierOption;
	}

	public String getClientIdentifierValue()
	{
		return clientIdentifierValue;
	}

	public void setClientIdentifierValue(String clientIdentifierValue)
	{
		this.clientIdentifierValue = clientIdentifierValue;
	}

	public String getToCcBcc()
	{
		return toCcBcc;
	}

	public void setToCcBcc(String toCcBcc)
	{
		this.toCcBcc = toCcBcc;
	}
}
