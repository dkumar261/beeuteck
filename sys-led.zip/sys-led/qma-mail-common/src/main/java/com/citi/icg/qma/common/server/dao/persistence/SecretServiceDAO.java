package com.citi.icg.qma.common.server.dao.persistence;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.naming.CommunicationException;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.DecryptionUtil;
import com.citi.icg.qma.common.core.util.MailUtil;
import com.citi.icg.qma.common.core.util.QmaMailConstants;
import com.citi.icg.qma.config.MongoDBConfig;
import com.mongodb.BasicDBObject;


/**
 * 
 * 
 *
 */

public class SecretServiceDAO {
	
	
	private static final Logger logger = LoggerFactory.getLogger(SecretServiceDAO.class);
	private static SecretServiceDAO instance = null;
	
	public static final String PASSWORD_KEY = "password";
	public static final String USER_NAME_KEY = "userName";
	public static final String CA_PASSWORD_KEY = "caPassword";
	public static final String CA_USER_NAME_KEY = "caUserName";
	public static final String LIVE_DB_KEY = "live";
	public static final String ARCHIVAL_DB_KEY = "archival";
	public static final String CA_LOG_PREFIX_KEY = "CYBERARK :: ";
	public static final String CA_ERROR_LOG_PREFIX_KEY = "CYBERARK_SECRET_SERVICE_ERROR :: ";
	public static final String SUPPORT_EMAIL_SUBJECT = "URGENT : CYBERARK SECRET SERVICE FAILURE";
	public static final String SUPPORT_TEAM_EMAIL = "XXXX";
	public static final String TECH_TEAM_EMAIL = "XXXX";
	public static final String LOGGING_DL_EMAIL = "XXXX";
	public static final String CONTENT_PREFIX = "CYBERARK FAILURE FOR SERVICE : ";
	private static final String CYBERARK_APP_USER = "qma";
	private static final String AUTH_HEADER_USER_NAME_KEY = "user";
	private static final String CYBERARK_APP_USER_SECRET = "QMAAPP@$123";
	private static final String AUTH_HEADER_SECRET_KEY = "secret";
	
	
	private static final String DB_TYPE_MONGODB = "mongodb";
	private static final String SECRET_IN_RESPONSE_KEY = "Content";
	private static final String ENCRYPTED_STR_IN_RESPONSE_KEY = "encryptedStr";
	private static final String ENCRYPTED_STR_IV_IN_RESPONSE_KEY = "encryptedStrIV";
	
	
	
	
	
	public static synchronized SecretServiceDAO getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		if (instance == null) {
			instance = new SecretServiceDAO();
		}
		return instance;
	}
	
	
	
	/**
	 * This function sends an email to support on CyberArk failure.
	 * @param message
	 * @param mongoDBConfig
	 */
	public void sendEmailToSupport(String message,MongoDBConfig mongoDBConfig){
		try {
			String env = System.getProperty("icg.env");
			if( StringUtils.isNotEmpty(env) && !env.contains("dev") && !env.contains("uat") && !env.contains("local")) {
				String [] emailToRecipients= new String[2];
				emailToRecipients[0] = SUPPORT_TEAM_EMAIL;
				emailToRecipients[1] = TECH_TEAM_EMAIL;
				String from = LOGGING_DL_EMAIL;
				String subject = "ERROR : " + env.toUpperCase() + " : " + SUPPORT_EMAIL_SUBJECT;
				logger.warn("SENDING EMAIL TO SUPPORT : {} ;  WITH subject: {} ;", emailToRecipients, subject);
				String emailContent = CONTENT_PREFIX + mongoDBConfig.getServiceName() + " and failure is : " + message;
				MailUtil.sendMail(from, subject, emailContent, true, null, emailToRecipients);
			} else if( StringUtils.isNotEmpty(env) && (env.contains("uat") || env.contains("dev")) ) {
				String [] emailToRecipients= new String[1];
				emailToRecipients[0] = LOGGING_DL_EMAIL;
				String from = LOGGING_DL_EMAIL;
				String subject = "ERROR : " + env.toUpperCase() + " : " + SUPPORT_EMAIL_SUBJECT;
				logger.warn("SENDING EMAIL TO LOGGING DL : {} ;  WITH subject: {} ;", emailToRecipients, subject);
				String emailContent = CONTENT_PREFIX + mongoDBConfig.getServiceName() + " and failure is : " + message;
				//TODO FT: Configure sendMail for non prod env
				//MailUtil.sendMail(emailToRecipients, from, subject, emailContent, true, null);
			}
		} catch (Exception e) {
			logger.warn("Exception while sending email to support on CyberArk failure :" + e);
		}
	}
	
	
	/**
	 * This method will provide a static as well as CyberArk credentials to caller
	 * @param  
	 * @param MongoDBConfig mongoDBConfig
	 * @param String dbInstance
	 * @return Map<String, String>
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 */
	public Map<String, String> getUserNamePasswordMap(MongoDBConfig mongoDBConfig, String dbInstanceTypeName, boolean isFromSecondaryDb ) throws CommunicatorException {
		Map<String, String> userNamePasswordMap = new HashMap<>();
		//TODO : Below line is to be removed post CyberArk integration
		getNonCyberArkCredentials(mongoDBConfig, dbInstanceTypeName, userNamePasswordMap);
		if(mongoDBConfig.isCyberArkEnabled()) {
			String caSecret = getSecretFromCyberArk(mongoDBConfig,dbInstanceTypeName, isFromSecondaryDb);
			if( !StringUtils.isEmpty(caSecret) ) {
				if(StringUtils.isNotEmpty(dbInstanceTypeName) && LIVE_DB_KEY.equalsIgnoreCase(dbInstanceTypeName)) {			
					userNamePasswordMap.put(CA_USER_NAME_KEY, mongoDBConfig.getDbFidUserName());
					if(isFromSecondaryDb) {
						userNamePasswordMap.put(CA_USER_NAME_KEY, mongoDBConfig.getDbFidSecondaryUserName());
					}
					logger.info(CA_LOG_PREFIX_KEY+"CYBERARK SECRET EXTRACTION FOR FID : {} SUCCESS !!", !isFromSecondaryDb? mongoDBConfig.getDbFidUserName(): mongoDBConfig.getDbFidSecondaryUserName());
				} else if(StringUtils.isNotEmpty(dbInstanceTypeName) && ARCHIVAL_DB_KEY.equalsIgnoreCase(dbInstanceTypeName)) {
					userNamePasswordMap.put(CA_USER_NAME_KEY, mongoDBConfig.getArchivalDbFidUserName());
					logger.info(CA_LOG_PREFIX_KEY+"CYBERARK SECRET EXTRACTION FOR FID : {} SUCCESS !!", mongoDBConfig.getArchivalDbFidUserName());
				}
				userNamePasswordMap.put(CA_PASSWORD_KEY, caSecret);
			} else {
				//TODO : This else part must be removed once we have all environment FID on-boarded to CyberArk and will throw exception from here
				logger.warn(CA_LOG_PREFIX_KEY+"CYBERARK SECRET EXTRACTION FOR FID : {} FAILED !!",!isFromSecondaryDb? mongoDBConfig.getDbFidUserName(): mongoDBConfig.getDbFidSecondaryUserName());
				getNonCyberArkCredentials(mongoDBConfig, dbInstanceTypeName, userNamePasswordMap);
			}
		} else {
			//TODO : This else part must be removed once we have all environment FID on-boarded to CyberArk and will throw exception from here
			logger.warn(CA_LOG_PREFIX_KEY+"CYBERARK CRENDETIALS ARE CURRENTLY DISABLED FOR THIS SERVICE IN CURRENT ENVIRONMENT");
			
			getNonCyberArkCredentials(mongoDBConfig, dbInstanceTypeName, userNamePasswordMap);
			
		}
		return userNamePasswordMap;
	}


	/**
	 * This method gets the non-CyberArk credentials from database
	 * @param mongoDBConfig
	 * @param dbInstance
	 * @param userNamePasswordMap
	 */
	private void getNonCyberArkCredentials(MongoDBConfig mongoDBConfig, String dbInstance,
			Map<String, String> userNamePasswordMap) throws CommunicatorException {
		if(StringUtils.isNotEmpty(dbInstance) && LIVE_DB_KEY.equalsIgnoreCase(dbInstance) && null!=mongoDBConfig.getUserName() && null!=mongoDBConfig.getPassword() && null!=mongoDBConfig.getPasswordIV()) {
			userNamePasswordMap.put(USER_NAME_KEY, mongoDBConfig.getUserName());
			String currentSecret = DecryptionUtil.decrypt(mongoDBConfig.getPassword(),
					mongoDBConfig.getPasswordIV(),QmaMailConstants.APPLICATION_ENCRYPTION_KEY);
			userNamePasswordMap.put(PASSWORD_KEY, currentSecret);
			logger.info(CA_LOG_PREFIX_KEY+"NON CYBERATK CREDENTIALS ARE ADDED FOR LIVE DB");
		} else if(StringUtils.isNotEmpty(dbInstance) && ARCHIVAL_DB_KEY.equalsIgnoreCase(dbInstance)) {
			userNamePasswordMap.put(USER_NAME_KEY, mongoDBConfig.getArchivalUserName());
			String currentArchSecret = DecryptionUtil.decrypt(mongoDBConfig.getArchivalPassword(),
					mongoDBConfig.getArchivalPasswordIV(),QmaMailConstants.APPLICATION_ENCRYPTION_KEY);
			userNamePasswordMap.put(PASSWORD_KEY, currentArchSecret);
			logger.info(CA_LOG_PREFIX_KEY+"NON CYBERARK CREDENTIALS ARE ADDED ARCHIVAL DB");
		}
	}
	

	/**
	 * This method gets the secret from CyberArk
	 * @param mongoDBConfig
	 * @param isFromSecondaryDb 
	 * @return String
	 * @throws CommunicatorException 
	 */
	private String getSecretFromCyberArk(MongoDBConfig mongoDBConfig, String dbInstanceTypeName, boolean isFromSecondaryDb) throws CommunicatorException {
		String secret = null;
		
		String secretEndPoint = mongoDBConfig.getSecretRetrivalEndpoint();
		String hostEnv = System.getProperty("host.env");
		String env = System.getProperty("icg.env");
		if(null == env) {
			env = System.getProperty("spring.profiles.active");
		}
		if(("uat".equalsIgnoreCase(env) && isFromSecondaryDb && null != mongoDBConfig.getSecretRetrivalEndpointEcs())
				|| (hostEnv != null && (hostEnv.equalsIgnoreCase("container")) && StringUtils.isNotEmpty(mongoDBConfig.getSecretRetrivalEndpointEcs()))) {
			secretEndPoint = mongoDBConfig.getSecretRetrivalEndpointEcs();
		}
		String dbFidUserName =  mongoDBConfig.getDbFidUserName();
		if(isFromSecondaryDb && null != mongoDBConfig.getDbFidSecondaryUserName()) {
			dbFidUserName =  mongoDBConfig.getDbFidSecondaryUserName();
		}
		if(StringUtils.isNotEmpty(dbInstanceTypeName) && ARCHIVAL_DB_KEY.equalsIgnoreCase(dbInstanceTypeName)) {
			dbFidUserName = mongoDBConfig.getArchivalDbFidUserName();
			logger.info(CA_LOG_PREFIX_KEY+"SECRET TO BE EXTRACED IS FOR ARCHIVAL DB FID : {} ",dbFidUserName);
		} else if(StringUtils.isNotEmpty(dbInstanceTypeName) && LIVE_DB_KEY.equalsIgnoreCase(dbInstanceTypeName)) {
			logger.info(CA_LOG_PREFIX_KEY+"SECRET TO BE EXTRACED IS FOR LIVE DB FID : {} ",dbFidUserName);
		} else {
			throw new CommunicatorException("Invalid value provided for attribute 'dbInstanceTypeName':" + dbFidUserName);
		}
		
		if(StringUtils.isNotEmpty(secretEndPoint) && StringUtils.isNotEmpty(dbFidUserName)) {
			secret = getSecretFromService(secretEndPoint, DB_TYPE_MONGODB, dbFidUserName);
			if(!StringUtils.isEmpty(secret)){
				logger.info(CA_LOG_PREFIX_KEY+"SECRET EXTRACTED FROM CYBERARK");
			} else {
				logger.error(CA_LOG_PREFIX_KEY+"SECRET EXTRACTED FROM CYBERARK IS EITHER 'null' OR 'empty' ");
			}
		} else {
			logger.warn("Check 'secretEndPoint' and 'dbFidUserName' are configured correctly for current environment YAML file.");
			throw new CommunicatorException("Check 'secretEndPoint' and 'dbFidUserName' are configured correctly for current environment YAML file.");
		}
		return secret;
	}
	
	
	
	/**
	 * This method fetches secret from qma-secret-service
	 * @param secretEndPoint
	 * @param fidType
	 * @param fid
	 * @return String
	 * @throws CommunicationException 
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 * @throws Exception 
	 */
	public String getSecretFromService(String secretEndPoint, String fidType, String fid) throws CommunicatorException {
		String secret = null;		
		logger.info(CA_LOG_PREFIX_KEY+"Fetching secret with secretEndPoint:'{}', fidType:'{}', fid:'{}'", 
				secretEndPoint,fidType, fid);
		HttpClient httpClient = HttpClientBuilder.create().build();
		if( httpClient != null ) {
			String secretServiceEndPoint = getSecretServiceURLForGivenParams(secretEndPoint, fidType, fid);
			if(StringUtils.isNotEmpty(secretServiceEndPoint)) {
				logger.info(CA_LOG_PREFIX_KEY+"URL to fetch the secret is : {}", secretServiceEndPoint);
				HttpGet getRequest = new HttpGet(secretServiceEndPoint);
				addAuthenticationHeaders(getRequest);
				HttpResponse response = null;
				try {
					response = httpClient.execute(getRequest);
				} catch (IOException  e) {
					logger.warn(CA_LOG_PREFIX_KEY+"Request is not successful, status code :{}", (null != response && null != response.getStatusLine() ) ?
							response.getStatusLine().getStatusCode() : "N/A");
					HttpEntity entity = (null != response && null != response.getEntity()) ? response.getEntity() : null;
					throw new CommunicatorException(CA_LOG_PREFIX_KEY+extractResponse(entity));
				} 
				if (null != response && null != response.getStatusLine() && response.getStatusLine().getStatusCode() != 200) {
					logger.warn("Request is not successful, status code :{}", response.getStatusLine().getStatusCode());
					throw new CommunicatorException(CA_LOG_PREFIX_KEY+extractResponse(response.getEntity()));
				} else {
					secret = getSecret(response);
				}
			} else {
				logger.warn("Secret service end point is either null or empty.");
				throw new CommunicatorException(CA_LOG_PREFIX_KEY+"Secret service end point is either null or empty.");
			}
		} else {
			logger.warn(CA_LOG_PREFIX_KEY+"Unable to build HttpClient before making call to CyberArk Service.");
			throw new CommunicatorException(CA_LOG_PREFIX_KEY+"Unable to build HttpClient before making call to CyberArk Service.");
		}
		return secret;
	}
	
	
	private void addAuthenticationHeaders(HttpGet getRequest) throws CommunicatorException {
		if(null!= getRequest) {
			getRequest.addHeader(AUTH_HEADER_USER_NAME_KEY, CYBERARK_APP_USER);
			getRequest.addHeader(AUTH_HEADER_SECRET_KEY, CYBERARK_APP_USER_SECRET);
		}
	}


	private String getSecret(HttpResponse response) throws CommunicatorException {
		String secret = null;
		if(null != response && null != response.getEntity()) {
			HttpEntity entity = response.getEntity();
			String content = extractResponse(entity);
			
			try {
				BasicDBObject result = BasicDBObject.parse(content);
				if(result.containsField(ENCRYPTED_STR_IN_RESPONSE_KEY) && StringUtils.isNotEmpty(result.getString(ENCRYPTED_STR_IN_RESPONSE_KEY)) 
						&& result.containsField(ENCRYPTED_STR_IV_IN_RESPONSE_KEY) && StringUtils.isNotEmpty(result.getString(ENCRYPTED_STR_IV_IN_RESPONSE_KEY)) ) {
					secret = DecryptionUtil.decrypt(result.getString(ENCRYPTED_STR_IN_RESPONSE_KEY), 
							result.getString(ENCRYPTED_STR_IV_IN_RESPONSE_KEY),QmaMailConstants.APPLICATION_ENCRYPTION_KEY);
					
				} else if(result.containsField(SECRET_IN_RESPONSE_KEY) && StringUtils.isNotEmpty(result.getString(SECRET_IN_RESPONSE_KEY))){
					secret = result.getString(SECRET_IN_RESPONSE_KEY);
				}
			} catch (Exception e) {
				logger.error("Exception while parsing CyberArk Response, as qma-secret-service failed to extract secret : ", e.getMessage());
				throw new CommunicatorException("Secret not availale in the response. Please check qma-secret-service logs. Response is :" + content);
			}
		} else {
			logger.warn("Received 'null' or 'invalid' response for fetching secret. Please check qma-secret-service logs.");
			throw new CommunicatorException("Received 'null' or 'invalid' response for fetching secret. Please check qma-secret-service logs.");
		}
		return secret;
	}

	private String getSecretServiceURLForGivenParams(String secretEndPoint, String fidType, String fid) throws CommunicatorException {
		String endpointUrl="";
		if(StringUtils.isNotEmpty(secretEndPoint) && StringUtils.isNotEmpty(fidType) && StringUtils.isNotEmpty(fid)){
			endpointUrl = secretEndPoint+"?fidType="+fidType+"&fid="+fid;
			logger.info(CA_LOG_PREFIX_KEY+"Secret Endpoint URL: '{}'",endpointUrl);
		} else {
			logger.warn(CA_LOG_PREFIX_KEY+"Please validate the input parameters required for generating secret service end point.");
			throw new CommunicatorException(CA_LOG_PREFIX_KEY+"Please validate the input parameters required for generating secret service end point.");
		}
		return endpointUrl;
	}
	
	/**
	 * This method extract the response received from the CLC search service
	 * @param content
	 * @param entity
	 * @throws IOException
	 */
	private String extractResponse( HttpEntity entity) throws CommunicatorException {
		StringBuilder content = new StringBuilder();
		if (entity != null) {
			byte[] buffer = new byte[1024];
			InputStream inputStream = null;
			try {
				inputStream = entity.getContent();
			} catch (UnsupportedOperationException | IOException e) {
				logger.error("Exception while extracting response",e);
				throw new CommunicatorException(CA_LOG_PREFIX_KEY+e.getCause());
			}
			try(BufferedInputStream bis = new BufferedInputStream(inputStream)){
				int bytesRead = 0;
				while ((bytesRead = bis.read(buffer)) != -1) {
					String chunk = new String(buffer, 0, bytesRead);
					content.append(chunk);
				}
			} catch (Exception e) {
				logger.error(" Error in SecretServiceDAO#extractSecretFromResponse() :", e);
				throw new CommunicatorException(CA_LOG_PREFIX_KEY+e.getCause());
			}
		} else {
			logger.warn("Received either 'null' or 'empty' resposne from qma-secret-service. Please validate qma-secret-service logs.");
			throw new CommunicatorException ("Received either 'null' or 'empty' resposne from qma-secret-service.  Please validate qma-secret-service logs.");
		}
		return content.toString();
	}
}
