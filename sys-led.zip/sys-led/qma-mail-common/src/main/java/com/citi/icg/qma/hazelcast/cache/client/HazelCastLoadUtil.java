package com.citi.icg.qma.hazelcast.cache.client;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.CustomClientCriteria;
import com.citi.icg.qma.common.server.dao.CustomClientCriteriaRuleBean;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.HierarchyOrgDetails;
import com.citi.icg.qma.common.server.dao.HierarchyUserDetail;
import com.citi.icg.qma.common.server.dao.HolidayMaster;
import com.citi.icg.qma.common.server.dao.ManagementHeirarchy;
import com.citi.icg.qma.common.server.dao.persistence.GenericDAO;
import com.citi.icg.qma.common.server.util.AgeAndTimeUtils.GroupShiftConfig;

public class HazelCastLoadUtil {
	
	private static final Logger logger = LoggerFactory.getLogger(HazelCastCacheIncrementalLoad.class);
	private static GenericDAO genericDAO = new GenericDAO();
	
	/**
	 * @param group
	 */
	public static Map<String, List<Group>> getOrgFromGroupMap(Group group) {
		Map<String, List<Group>> orgGroupMap = new HashMap<String, List<Group>>();
		String secondLevelHierarchyUserName = "";
		String orgHierarchyOrgName = "";
		ManagementHeirarchy heirarchy = group.getHeirarchyData();
		if (heirarchy != null && heirarchy.getSecondLevelHeirarchy() != null && heirarchy.getOrgHierarchy() != null) {
			List<HierarchyUserDetail> secondLevelHeirarchy = heirarchy.getSecondLevelHeirarchy();
			List<HierarchyOrgDetails> orgHierarchy = heirarchy.getOrgHierarchy();
			if (null != orgHierarchy && orgHierarchy.size() > 0 && null != secondLevelHeirarchy	&& secondLevelHeirarchy.size() > 0) {
				for (HierarchyOrgDetails hierarchyOrgDetails : orgHierarchy) {
					if (hierarchyOrgDetails.getLevel().equalsIgnoreCase("L3")) {
						orgHierarchyOrgName = hierarchyOrgDetails.getOrgName();
						break;
					}
				}
				updateOrgMap(group, orgGroupMap, secondLevelHierarchyUserName, orgHierarchyOrgName,
						secondLevelHeirarchy);
			}
		}
	
		 return orgGroupMap;
		
	}


	/**
	 * @param group
	 * @param orgGroupMap
	 * @param secondLevelHierarchyUserName
	 * @param orgHierarchyOrgName
	 * @param secondLevelHeirarchy
	 */
	private static void updateOrgMap(Group group, Map<String, List<Group>> orgGroupMap,
			String secondLevelHierarchyUserName, String orgHierarchyOrgName,
			List<HierarchyUserDetail> secondLevelHeirarchy) {
		String orgName="";
		for (HierarchyUserDetail secondLevelData : secondLevelHeirarchy) {
			secondLevelHierarchyUserName = secondLevelData.getUserName();
		}
		orgName = orgHierarchyOrgName + "(" + secondLevelHierarchyUserName + ")";
		if (null != orgName) {
			List<Group> grpList = new ArrayList<>();
			if (orgGroupMap.containsKey(orgName)) {
				grpList = orgGroupMap.get(orgName);
				grpList.add(group);
				orgGroupMap.put(orgName, grpList);
			} else {
				grpList.add(group);
				orgGroupMap.put(orgName, grpList);
			}
		}
	}

	
	public static GroupShiftConfig getGroupConfig(Group group) {
		QMACache qmaCacheInstance = QMACacheFactory.getCache();
		GroupShiftConfig groupConfig = new GroupShiftConfig();
		getGroupShiftConfig(groupConfig, group);
		getGroupHolidays(groupConfig, group, qmaCacheInstance);
		return groupConfig;
		
	}

	private static void getGroupShiftConfig(GroupShiftConfig groupConfig, Group group) {
		if (null != group.getTimeZone()) {
			Config timeZonesConfig = loadConfigData().get("timeZones");
			List<com.citi.icg.qma.common.server.dao.TimeZone> timeZones = timeZonesConfig.getTimeZones();
			for (com.citi.icg.qma.common.server.dao.TimeZone ctz : timeZones) {
				if (ctz.getTimeZoneCode().equalsIgnoreCase(group.getTimeZone())
						&& null != group.getHolidayAndShiftDetails()) {
					groupConfig.setTimeZone(ctz.getTimeZone());
					groupConfig.setShiftStartTime(group.getHolidayAndShiftDetails().getShiftStartTime());
					groupConfig.setShiftEndTime(group.getHolidayAndShiftDetails().getShiftEndTime());
					groupConfig.setWeeklyOffs(group.getHolidayAndShiftDetails().getWeeklyOffDays());
					groupConfig.setShiftHoursInMins(
							getShiftHourseInMins(group.getHolidayAndShiftDetails().getShiftStartTime(),
									group.getHolidayAndShiftDetails().getShiftEndTime()));
					groupConfig.setHolidayBasedCalculation(group.getHolidayAndShiftDetails().isHolidayBasedAgeCalculation());
					break;
				}
			}
		}
	}
	private static Map<String, Config> loadConfigData()
	{
		return genericDAO.loadConfigDataFromDB();
	}
	private static int getShiftHourseInMins(String shiftStartTime, String shiftEndTime) {
		int nofOfMins = 0;
		try {
			if(StringUtils.isNotEmpty(shiftStartTime) && StringUtils.isNotEmpty(shiftEndTime)) {
				String[] shiftStart= shiftStartTime.split(":");
				int sHour = Integer.parseInt(shiftStart[0]);
				int sMins = Integer.parseInt(shiftStart[1]);
				
				String[] shiftEnd = shiftEndTime.split(":");
				int eHour = Integer.parseInt(shiftEnd[0]);
				int eMins = Integer.parseInt(shiftEnd[1]);
				
				Calendar end = new GregorianCalendar();
				end.set(Calendar.HOUR_OF_DAY,eHour);
				end.set(Calendar.MINUTE,eMins);
				Calendar start = new GregorianCalendar();
				start.set(Calendar.HOUR_OF_DAY,sHour);
				start.set(Calendar.MINUTE,sMins);
				
				long shiftDiff = end.getTimeInMillis() - start.getTimeInMillis();
				shiftDiff = shiftDiff/(1000*60);
				nofOfMins = (int) shiftDiff;
			}
		} catch (Exception e) {
			logger.error("Exception while generating shift hours in mins :",e);
		}
		return nofOfMins;
	}
	/**
	 * @param group
	 * @param qmaCacheInstance 
	 */
	public static void updateCustomClientCategory(Group group, QMACache qmaCacheInstance) {
		if(null != group.getCustomClientCategory()) {
			List<CustomClientCriteriaRuleBean> customClientCategoryCriteriaList;
			List<CustomClientCriteria> customClientCategory = group.getCustomClientCategory();
			for (CustomClientCriteria customClientCategoryCriteria : customClientCategory){
				if (qmaCacheInstance.getDbCustomClientCriteriaList().keySet().contains(group.getId()))
				{
					customClientCategoryCriteriaList = qmaCacheInstance.getDbCustomClientCriteriaList().get(group.getId());
				}
				else
				{
					customClientCategoryCriteriaList = new ArrayList<>();
				}
				customClientCategoryCriteriaList.add(copyCustomClientCriteriaEntityToRoutingCriteriaBean(group, customClientCategoryCriteria));
				qmaCacheInstance.getDbCustomClientCriteriaList().put(group.getId(), customClientCategoryCriteriaList);
				
			}
			
		}
	}

	private static CustomClientCriteriaRuleBean copyCustomClientCriteriaEntityToRoutingCriteriaBean(Group gEntity, CustomClientCriteria customClientCriteria)
	{
		CustomClientCriteriaRuleBean routingCriteriaBean = new CustomClientCriteriaRuleBean();
		try {
			routingCriteriaBean.setGroupId(gEntity.getId());
			routingCriteriaBean.setGroupEmail(gEntity.getGroupEmail());
			routingCriteriaBean.setGroupName(gEntity.getGroupName());
			if(customClientCriteria != null && customClientCriteria.getRules() != null){
				if("SUBJECT".equalsIgnoreCase(customClientCriteria.getRules().getField().trim())){
					routingCriteriaBean.setSubjectOperator(customClientCriteria.getRules().getOperators());
					routingCriteriaBean.setSubject(customClientCriteria.getRules().getValue());
				}
				else if("FROM".equalsIgnoreCase(customClientCriteria.getRules().getField().trim())){
					routingCriteriaBean.setFromOperator(customClientCriteria.getRules().getOperators());
					routingCriteriaBean.setFrom(customClientCriteria.getRules().getValue());
				}
				else if("TO".equalsIgnoreCase(customClientCriteria.getRules().getField().trim())){
					routingCriteriaBean.setToOperator(customClientCriteria.getRules().getOperators());
					routingCriteriaBean.setTo(customClientCriteria.getRules().getValue());
				}
				routingCriteriaBean.setCategoryName(customClientCriteria.getCategoryName());
				routingCriteriaBean.setColorCode(customClientCriteria.getColorCode());
			}
		} catch (Exception e) {
			logger.error("Exception in copyCustomClientCriteriaEntityToRoutingCriteriaBean with exception "+e);
		}
		return routingCriteriaBean;
	}
	/**
	 * This method provides group level holidays
	 * @param groupConfig
	 * @param group
	 * @param qmaCacheInstance
	 */
	private static void getGroupHolidays(GroupShiftConfig groupConfig, Group group, QMACache qmaCacheInstance) {
		try {
			if( groupConfig != null && group != null && group.getCountry()!=null){
				String groupCountryCode = group.getCountry();
				List<HolidayMaster> groupHolidays = getHolidayMasterForCountryCode(groupCountryCode, qmaCacheInstance);
				getGroupHolidays(groupConfig, groupHolidays);
			}
		} catch (ParseException e) {
			logger.error("Exception : ",e);
		}
	}
	private static List<HolidayMaster> getHolidayMasterForCountryCode(String countrCode, QMACache qmaCacheInstance) {
		List<HolidayMaster> holidays = null;
		if(qmaCacheInstance.getHolidayMasterMap()!=null && StringUtils.isNotBlank(countrCode)){
			holidays = qmaCacheInstance.getHolidayMasterMap().get(countrCode);
		}
		return holidays;
	}
		
	/**
	 * This method provides group level holidays
	 * @param groupConfig
	 * @param groupHolidays
	 * @throws ParseException
	 */
	private static void getGroupHolidays(GroupShiftConfig groupConfig, List<HolidayMaster> groupHolidays)
			throws ParseException {
		if(groupHolidays != null && !groupHolidays.isEmpty()) {
			List<String> grpHolidayList = new ArrayList<>();
			for(HolidayMaster holiday : groupHolidays){
				Date holidayDate = holiday.getHolidayDate();
				Calendar cal = Calendar.getInstance();
				cal.setTimeZone(TimeZone.getTimeZone("GMT"));
				cal.setTime(holidayDate);
				String formattedDateString = cal.get(Calendar.DAY_OF_MONTH) + "-"  + (cal.get(Calendar.MONTH)+1)  + "-" + cal.get(Calendar.YEAR);
				grpHolidayList.add(formattedDateString);
			}
			groupConfig.setHolidays(grpHolidayList);
		}
	}
	
}
