package com.citi.icg.qma.common.messagebus.entity;


public class Data {
	
	private String eventId;
	private String eventName;
	private String eventType;
	private Long eventTimestampMs;
	private Payload payload;
	
	public Data() {
		super();
		// Auto-generated constructor stub
	}
	
	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	
	public Long getEventTimestampMs() {
		return eventTimestampMs;
	}

	public void setEventTimestampMs(Long eventTimestampMs) {
		this.eventTimestampMs = eventTimestampMs;
	}

	public Payload getPayload() {
		return payload;
	}
	public void setPayload(Payload payload) {
		this.payload = payload;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	
}
