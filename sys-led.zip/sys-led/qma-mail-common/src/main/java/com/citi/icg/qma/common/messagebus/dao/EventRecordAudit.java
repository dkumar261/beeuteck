package com.citi.icg.qma.common.messagebus.dao;

import com.citi.icg.qma.common.messagebus.entity.Data;
import com.citi.icg.qma.common.server.dao.BaseEntity;
import dev.morphia.annotations.Entity;

@Entity(value = "EventRecordAudit", noClassnameStored = true)
public class EventRecordAudit extends BaseEntity {

	private String eventId;
    private String eventName;
    private Long inquiryId;
    private Long conversationId;
    private String eventType;
    private Data data;
    private String status;
    private String eventDescription;
    private com.citi.icg.qma.common.messagebus.resolveinquiry.entity.Data consumedData;
    private String eventCategory;
    private int replayCount;
   
	public EventRecordAudit() {
		super();
		// Auto-generated constructor stub
	}
	
	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public Long getInquiryId() {
		return inquiryId;
	}
	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}
	public Long getConversationId() {
		return conversationId;
	}
	public void setConversationId(Long conversationId) {
		this.conversationId = conversationId;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEventDescription() {
		return eventDescription;
	}
	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public com.citi.icg.qma.common.messagebus.resolveinquiry.entity.Data getConsumedData() {
		return consumedData;
	}

	public void setConsumedData(com.citi.icg.qma.common.messagebus.resolveinquiry.entity.Data consumedData) {
		this.consumedData = consumedData;
	}

	public String getEventCategory() {
		return eventCategory;
	}

	public void setEventCategory(String eventCategory) {
		this.eventCategory = eventCategory;
	}

	public int getReplayCount() {
		return replayCount;
	}

	public void setReplayCount(int replayCount) {
		this.replayCount = replayCount;
	}
	
}
