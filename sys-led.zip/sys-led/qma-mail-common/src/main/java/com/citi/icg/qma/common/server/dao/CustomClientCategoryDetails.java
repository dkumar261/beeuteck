package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

import dev.morphia.annotations.Embedded;

@Embedded
public class CustomClientCategoryDetails implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4698046569425653148L;
	private String categoryName;
	private String colorCode;
	public CustomClientCategoryDetails() {
		super();
	}
	public CustomClientCategoryDetails(String categoryName, String colorCode) {
		super();
		this.categoryName = categoryName;
		this.colorCode = colorCode;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getColorCode() {
		return colorCode;
	}
	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}
	
	
}
