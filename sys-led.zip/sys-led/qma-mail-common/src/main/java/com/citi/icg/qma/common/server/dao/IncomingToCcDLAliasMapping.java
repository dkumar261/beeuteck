package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

public class IncomingToCcDLAliasMapping implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7401479754482332690L;
	private String name;
	private String email;
	private String xscDLEmail;
	private String xscDlName;
	private Date crtDate;
	private Date modDate;
	
	public IncomingToCcDLAliasMapping()
	{
		
	}
	public IncomingToCcDLAliasMapping(String name, String email, String xscDLEmail,	String xscDlName, Date crtDate, Date modDate)
	{
		super();
		this.name = name;
		this.email = email;
		this.xscDLEmail = xscDLEmail;
		this.xscDlName = xscDlName;
		this.crtDate = crtDate;
		this.modDate = modDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}	
	public String getXscDlName() {
		return xscDlName;
	}
	public void setXscDlName(String xscDlName) {
		this.xscDlName = xscDlName;
	}
	public Date getCrtDate() {
		return crtDate;
	}
	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}
	public Date getModDate() {
		return modDate;
	}
	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}
	public String getXscDLEmail() {
		return xscDLEmail;
	}
	public void setXscDLEmail(String xscDLEmail) {
		this.xscDLEmail = xscDLEmail;
	}
	
}
