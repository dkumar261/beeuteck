package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

public class NLPTags implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4950506865500320024L;
	private String category;
	private String type;
	private double score;
	private String confidence;
	private Long groupId;
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public String getConfidence() {
		return confidence;
	}
	public void setConfidence(String confidence) {
		this.confidence = confidence;
	}
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	
}
