package com.citi.icg.qma.common.core.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.util.GenericUtility;

public final class PropertiesLoader {

	private static final Logger LOGGER = LoggerFactory.getLogger(PropertiesLoader.class);//Sonar Fix -- Standard outputs should not be used directly to log anything
	
	static final String INCLUDE_PREFIX = "include.";
	private static final Pattern VARIABLE_EXPANSION_PATTERN = Pattern.compile("\\$\\{([^\\{\\}]+)\\}");
	
	private PropertiesLoader(){
		//As this class is Util, so added making private constructor.
		//Sonar Fix -- Utility classes should not have public constructors 
	}
	
	/**
	 * Will load all properties and any declared includes properties.  To
	 * include another property file, define <tt>include.</tt><i>n</i> where
	 * <i>n</i> is a zero-indexed counter.  The value should be a URL, a
	 * relative path, or an absolute path.
	 * @param inputStream
	 * @return
     * @exception  IOException  if an error occurred when reading from the
     *               input stream.
	 * @throws IllegalArgumentException if the input stream contains a
     * 		   malformed Unicode escape sequence.
	 */
	private static Properties loadProperties(File dir, InputStream inputStream) throws IOException {
		Properties props = new Properties();
		props.load(inputStream);
		inputStream.close();
		
		int index = 0;
		String include = null;
		
		
		while ((include = props.getProperty(INCLUDE_PREFIX + index)) != null) {
			include = substituteSystemProperty(include);
			if (dir != null && !include.contains(":")) {
				dir = new File(GenericUtility.sanitizeFileNameForPathTraversal(dir.toString()));
				include = new File(dir, include).getAbsolutePath();
				include = GenericUtility.sanitizeFileNameForPathTraversal(include);
			}
			
			LOGGER.info("Including : {}" , include);
			Properties includeProps = null;
			try
			{
				includeProps = PropertiesLoader.loadOurProperties(include);
			}
			catch(Exception expt)
			{
				LOGGER.info("Exception while loading properties : " + include, expt);
				includeProps = loadFromURL(Thread.currentThread().getContextClassLoader().getResource(include));
			}
			includeProps.putAll(props);
			props = includeProps;
			index++;
		}
		
		return props;
	}
	
	private static String substituteSystemProperty(String value) {
		
		String valueToSubstitute = value;// Sonar Fix -- Method parameters, caught exceptions and foreach variables should not be reassigned
		
		Matcher matcher = VARIABLE_EXPANSION_PATTERN.matcher(valueToSubstitute);

		if(!matcher.find(0))
		{
			return valueToSubstitute;
		}

		String key = matcher.group(1);
		String replaceValue = System.getProperty(key);
		if(replaceValue == null) {
			throw new ConfigurationException("Cannot substitute value for key:"+key);
		}
		valueToSubstitute = matcher.replaceFirst(replaceValue);
		
		return valueToSubstitute;
	}

	/**
	 * Attempts to load properties from URL or file.
	 * Will load all properties and any declared includes properties.  To
	 * include another property file, define <tt>include.</tt><i>n</i> where
	 * <i>n</i> is a zero-indexed counter.  The value should be a URL, a
	 * relative path, or an absolute path.
	 * @param location
	 * @return
	 */
	public static Properties loadProperties(String location) {
		Properties props = null;
		location = GenericUtility.sanitizeFileNameForPathTraversal(location);
		// Try treating the argument as a URL first
		try {
			props = loadFromURL(URI.create(location).toURL());
		} catch (MalformedURLException ex) // It's not a URL, treat as a file
		{
			props = loadFromFile(location);
		}

		return props;
	}

	public static Properties loadOurProperties(String location) 
	{
		Properties props = null;
		String atapsHome = System.getProperty(ConfigManager.ATAPS_HOME);
		
		String loc = location;// Sonar Fix -- Method parameters, caught exceptions and foreach variables should not be reassigned
		
		if (!loc.contains("etc"))
		{
			if (atapsHome != null)
			{
				loc = atapsHome + "/etc/"  + loc;
			}
			else
			{
				loc = "/etc/"  + loc;
			}
		}
		try
		{
			props = PropertiesLoader.loadProperties(loc);
			
		}
		catch(Exception expt)
		{
			LOGGER.error("Error loading properties  ", expt);
			URL locationURL = null;
			locationURL = Thread.currentThread().getContextClassLoader().getResource(loc);//Sonar Fix - remove useless parenthesis
			if (locationURL != null)
			{
				props = PropertiesLoader.loadFromURL(locationURL);
			}
			else
			{
				try {
					InputStream inputStream = ConfigManager.class.getResourceAsStream(loc);
					if (inputStream == null)
					{	
						throw new IOException("Cannot obtain a input stream for : " + loc);
					}	
					props = loadProperties(null, inputStream);
				} catch (IOException e) {
					throw new ConfigurationException(e);
				}	
			}
		}
		return props;
	}
	public static Properties loadFromURL(URL a) {
		try {
			LOGGER.info("Load from URL : {}" , a.getFile());
			return loadProperties(null, a.openStream());
		} catch (IOException e) {
			throw new ConfigurationException(e);
		}		
	}

	private static Properties loadFromFile(String location) {
		try {
			File file = new File(location);
			return loadProperties(file.getParentFile(), new FileInputStream(file));
		} catch (IOException e) {
			throw new ConfigurationException(e);
		}		
	}
}
