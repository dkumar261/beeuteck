package com.citi.icg.qma.common.server.dao.persistence;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.plaf.synth.SynthTextAreaUI;

import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.HierarchyOrgDetails;
import com.citi.icg.qma.common.server.dao.HierarchyUserDetail;
import com.citi.icg.qma.common.server.dao.HighlevelRequestType;
import com.citi.icg.qma.common.server.dao.ManagementHeirarchy;
import com.citi.icg.qma.common.server.dao.OrgAuditTrailHighLevelRequestTypeMapping;
import com.citi.icg.qma.common.server.dao.OrgAuditTrailRequestType;
import com.citi.icg.qma.common.server.dao.OrgAuditTrailRequestTypeRootCauseMapping;
import com.citi.icg.qma.common.server.dao.OrgAuditTrailRootCause;
import com.citi.icg.qma.common.server.dao.OrgMetaDataAdminRole;
import com.citi.icg.qma.common.server.dao.OrgPreferences;
import com.citi.icg.qma.common.server.dao.Organization;
import com.citi.icg.qma.common.server.dao.OrgMetaDataAdminDetail;
import com.citi.icg.qma.common.server.dao.OrganizationAuditTrail;
import com.citi.icg.qma.common.server.dao.Preference;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

import dev.morphia.query.Query;

public class OrganizationDAO extends MongoMorphiaDAO {
	private static final Logger subLogger = LoggerFactory.getLogger(OrganizationDAO.class);
	public static final String GROUP_NAME = "groupName";
	public static final String ORG_NAME = "orgName";
	public static final String ORG_MANAGER = "orgManager";
	public static final String MAKER = "maker";
	public static final String METADATA = "metaData";
	public static final String WORKFLOWSTATUS = "workflowStatus";
	public static final String CRTDATE = "crtDate";
	public static final String COMMENT = "comment";
	public static final String REQUESTTYPE = "requestTypes";
	public static final String HIGHLEVELREQUESTTYPEMAPPING = "highLevelRequestTypeMapping";
	public static final String PROCESSINGREGION = "processingRegion";
	public static final String ROOTCAUSE = "rootCause";
	public static final String REQUESTTTYPEROOTCAUSEMAPPING = "requestTypeRootCauseMapping";
	public static final String INQUIRYSOURCE = "inquirySource";
	public static final String SUPERADMINS = "superAdmins";
	public static final String ORGPREFERENCES = "orgPreferences";
	public static final String WORKFLOWREMARK = "workflowRemarks";
	public static final String MODBY = "modBy";
	public static final String MODDATE = "modDate";
	public static final String CRTBY = "crtBy";
	public static final String CHECKER = "checker";
	public static final String ENABLEGROUPLEVELOERRIDE = "enableGroupLevelOverride";
	public static final String ORGLEVELINQUIRYSUBSTATUSENABLED = "orgLevelInquirySubStatusEnabled";
	public static final String ID = "_id";
	public static final String MY_REQUEST = "my request";
	public static final String REQUEST_FOR_APPROVAL = "request for approval";
	public static final String APPROVED = "Approved";
	public static final String PENDING_FOR_APPROVAL = "Pending for approval";
	// D for deleted metadata(request type, root cause,request type root cause mapping)
	public static final String STATUSINDICATOR = "D";
	public static final String ENABELORGLEVELMETADATA="enableOrgLevelMetaData";
	public List<Group> getOrgGroup(String organizationName) {
		List<Group> orgGroupList = new ArrayList<>();
		try {
			// getting org group from cache
			Map<String, List<Group>> orgGroupMap = QMACacheFactory.getCache().getOrgGroupMap();
			orgGroupList = orgGroupMap.get(organizationName);
		} catch (Exception e) {
			subLogger.error("Exception in OrganizationDAO.getOrgGroup", e);
		}
		return orgGroupList;
	}

	public boolean saveOrgUnApprovedRequest(BasicDBObject inputJsonObjList) {
		boolean status = true;
		String enableGroupLevelOverride = "";
		String enableInquirySubStatus = "";
		List<OrgAuditTrailRequestType> requestTypeList = new ArrayList<>();
		List<OrgAuditTrailHighLevelRequestTypeMapping> highLevelRequestTypeMapping = new ArrayList<>();
		List<OrgAuditTrailRootCause> rootCauseList = new ArrayList<>();
		List<OrgAuditTrailRequestTypeRootCauseMapping> requestTypeRootCauseMapping = new ArrayList<>();
		try {
			String orgName = "";
			if (inputJsonObjList.containsField(ORG_NAME)) {
				orgName = (String) inputJsonObjList.getString(ORG_NAME);
			}
			if (inputJsonObjList.get(REQUESTTYPE) != null) {
				BasicDBList requestDbList = (BasicDBList) inputJsonObjList.get(REQUESTTYPE);
				for (Object obj : requestDbList) {
					BasicDBObject dbObj = (BasicDBObject) obj;
					String requestType = dbObj.getString("requestType");
					String statusIndicator = dbObj.getString("statusIndicator");
					OrgAuditTrailRequestType auditTrailRequest = new OrgAuditTrailRequestType();
					auditTrailRequest.setRequestType(requestType);
					auditTrailRequest.setStatusIndicator(statusIndicator);
					requestTypeList.add(auditTrailRequest);
				}

			}
			if (inputJsonObjList.get(HIGHLEVELREQUESTTYPEMAPPING) != null) {
				BasicDBList highLevelRequestDBList = (BasicDBList) inputJsonObjList.get(HIGHLEVELREQUESTTYPEMAPPING);
				for (Object obj : highLevelRequestDBList) {
					BasicDBObject dbObj = (BasicDBObject) obj;
					String reqeustType = dbObj.getString("requestType");
					String highLevelRequestType = dbObj.getString("highlevelRequestType");
					String statusIndicator = dbObj.getString("statusIndicator");
					OrgAuditTrailHighLevelRequestTypeMapping highLevelRequest = new OrgAuditTrailHighLevelRequestTypeMapping();
					highLevelRequest.setRequestType(reqeustType);
					highLevelRequest.setHighlevelRequestType(highLevelRequestType);
					highLevelRequest.setStatusIndicator(statusIndicator);
					highLevelRequestTypeMapping.add(highLevelRequest);
				}
			}
			if (inputJsonObjList.get(ROOTCAUSE) != null) {
				BasicDBList rootCauseDBList = (BasicDBList) inputJsonObjList.get(ROOTCAUSE);
				for (Object obj : rootCauseDBList) {
					BasicDBObject dbObj = (BasicDBObject) obj;
					String rootCause = dbObj.getString("rootCause");
					String statusIndicator = dbObj.getString("statusIndicator");
					OrgAuditTrailRootCause objRootCause = new OrgAuditTrailRootCause();
					objRootCause.setRootCause(rootCause);
					objRootCause.setStatusIndicator(statusIndicator);
					rootCauseList.add(objRootCause);
				}
			}
			if (inputJsonObjList.get("requestTypeRootCauseMapping") != null) {
				BasicDBList requestTypeRootCauseDbObj = (BasicDBList) inputJsonObjList.get("requestTypeRootCauseMapping");
				for (Object obj : requestTypeRootCauseDbObj) {
					BasicDBObject dbObj = (BasicDBObject) obj;
					String requestType = dbObj.getString("requestType");
					List<String> rootCause = (List<String>) dbObj.get("rootCause");
					String statusIndicator = dbObj.getString("statusIndicator");
					OrgAuditTrailRequestTypeRootCauseMapping requestTypeRootCause = new OrgAuditTrailRequestTypeRootCauseMapping();
					requestTypeRootCause.setRequestType(requestType);
					requestTypeRootCause.setRootCause(rootCause);
					requestTypeRootCause.setStatusIndicator(statusIndicator);
					requestTypeRootCauseMapping.add(requestTypeRootCause);
				}
			}
			String maker = inputJsonObjList.getString(MAKER);
			String workflowStatus = inputJsonObjList.getString(WORKFLOWSTATUS);
			String crtDate = (String) inputJsonObjList.getString(CRTDATE);
			String comment = (String) inputJsonObjList.getString(COMMENT);
			List<String> checker = (List<String>) inputJsonObjList.get(CHECKER);
			if (inputJsonObjList.getString("id") != null) {// for update request for approval
				long id = (long) inputJsonObjList.getLong("id");
				Query<OrganizationAuditTrail> query = mongoDatastore.createQuery(OrganizationAuditTrail.class)
						.filter("_id", id);
				OrganizationAuditTrail orgAuditTrail = query.get();
				orgAuditTrail.setOrgName(orgName);
				orgAuditTrail.setRequestTypes(requestTypeList);
				orgAuditTrail.setHighLevelRequestTypeMapping(highLevelRequestTypeMapping);
				orgAuditTrail.setRootCause(rootCauseList);
				orgAuditTrail.setRequestTypeRootCauseMapping(requestTypeRootCauseMapping);
				orgAuditTrail.setChecker(checker);
				OrgPreferences preference = new OrgPreferences();
				if (inputJsonObjList.get(ENABLEGROUPLEVELOERRIDE) != null) {
					enableGroupLevelOverride = (String) inputJsonObjList.getString(ENABLEGROUPLEVELOERRIDE);
					preference.setEnableGroupLevelOverride(enableGroupLevelOverride);
					orgAuditTrail.setPreferences(preference);
				}
				//[C170665-1719] DCC Requirement: Add Case status field
				if(inputJsonObjList.get(ORGLEVELINQUIRYSUBSTATUSENABLED) != null) {
					enableInquirySubStatus = (String) inputJsonObjList.getString(ORGLEVELINQUIRYSUBSTATUSENABLED);
					preference.setEnableInquirySubStatus(enableInquirySubStatus);
					orgAuditTrail.setPreferences(preference);
				}
				if(inputJsonObjList.get(ENABELORGLEVELMETADATA)!=null) {
					String enableOrgLevelMetaData=(String)inputJsonObjList.getString(ENABELORGLEVELMETADATA);
					orgAuditTrail.setEnableOrgLevelMetaData(enableOrgLevelMetaData);
				}
				orgAuditTrail.setWorkflowStatus(workflowStatus);
				orgAuditTrail.setMaker(maker);
				orgAuditTrail.setComment(comment);
				status = mongoDatastore.save(orgAuditTrail) != null ? true : false;
				// for notification sent to other org metadata admin
				
			} else {
				OrganizationAuditTrail orgAuditTrail = new OrganizationAuditTrail();
				orgAuditTrail.setOrgName(orgName);
				orgAuditTrail.setRequestTypes(requestTypeList);
				orgAuditTrail.setHighLevelRequestTypeMapping(highLevelRequestTypeMapping);
				orgAuditTrail.setRootCause(rootCauseList);
				orgAuditTrail.setRequestTypeRootCauseMapping(requestTypeRootCauseMapping);
				orgAuditTrail.setChecker(checker);
				OrgPreferences preference = new OrgPreferences();
				if (inputJsonObjList.get(ENABLEGROUPLEVELOERRIDE) != null) {
					enableGroupLevelOverride = (String) inputJsonObjList.getString(ENABLEGROUPLEVELOERRIDE);
					preference.setEnableGroupLevelOverride(enableGroupLevelOverride);
					orgAuditTrail.setPreferences(preference);
				}
				//[C170665-1719] DCC Requirement: Add Case status field
				if(inputJsonObjList.get(ORGLEVELINQUIRYSUBSTATUSENABLED) != null) {
					enableInquirySubStatus = (String) inputJsonObjList.getString(ORGLEVELINQUIRYSUBSTATUSENABLED);
					preference.setEnableInquirySubStatus(enableInquirySubStatus);
					orgAuditTrail.setPreferences(preference);
				}
				if(inputJsonObjList.get(ENABELORGLEVELMETADATA)!=null) {
					String enableOrgLevelMetaData=(String)inputJsonObjList.getString(ENABELORGLEVELMETADATA);
					orgAuditTrail.setEnableOrgLevelMetaData(enableOrgLevelMetaData);
				}
				orgAuditTrail.setWorkflowStatus(workflowStatus);
				orgAuditTrail.setMaker(maker);
				orgAuditTrail.setComment(comment);
				List<OrganizationAuditTrail> orgAuditTrailList = getAllPendingRequests(orgName);
				Organization organization = getOrgData(orgName);
				Map<String, Boolean> alreadyRaisedRequestMap = checkAlreadyRaisedRequests(organization,orgAuditTrailList);
				List<OrganizationAuditTrail> orgList = new ArrayList<>();
				orgList.add(orgAuditTrail);
				Map<String, Boolean> newRequestMap = checkAlreadyRaisedRequests(organization, orgList);
				if (checkRequests(newRequestMap, alreadyRaisedRequestMap)) {
					status = mongoDatastore.save(orgAuditTrail) != null ? true : false;
				} else {
					status = false;
				}
			  return status;
			}
		} catch (Exception e) {
			subLogger.error("Exception in OrganizationDAO.saveOrgUnApprovedRequest", e);
		}
		return status;
	}

	public boolean saveOrgData(BasicDBObject inputJsonObjList) throws CommunicatorException {
		boolean status = false;
		try {
			List<String> requestTypeList = new ArrayList<>();
			String enableGroupLevelOverride = "";
			String enableInquirySubStatus = "";
			List<String> rootCauseList = new ArrayList<>();
			Map<String, List<String>> requestTypeRootCauseMapping = new HashMap<String, List<String>>();
			Date createdDate = new Date();
			List<HighlevelRequestType> highLevelRequestTypeList = new ArrayList<>();
			List<OrgMetaDataAdminDetail> superAdmins = new ArrayList<>();
			String orgName = "";
			String orgManager = "";
			if (inputJsonObjList.containsField(ORG_NAME)) {
				orgName = (String) inputJsonObjList.getString(ORG_NAME);
			}
			if (inputJsonObjList.containsField(ORG_MANAGER)) {
				orgManager = (String) inputJsonObjList.getString(ORG_MANAGER);
			}
			if (inputJsonObjList.get(SUPERADMINS) != null) {
				superAdmins = (List<OrgMetaDataAdminDetail>) inputJsonObjList.get(SUPERADMINS);
			}
			if (inputJsonObjList.get(REQUESTTYPE) != null) {
				BasicDBList requestDbList = (BasicDBList) inputJsonObjList.get(REQUESTTYPE);
				requestTypeList = getRequestsType(requestDbList);
			}
			if (inputJsonObjList.get(HIGHLEVELREQUESTTYPEMAPPING) != null) {
				BasicDBList highLevelReqeustTypeDbList = (BasicDBList) inputJsonObjList
						.get(HIGHLEVELREQUESTTYPEMAPPING);
				highLevelRequestTypeList = getHighLevelRequestsType(highLevelReqeustTypeDbList);
			}
			if (inputJsonObjList.get(ROOTCAUSE) != null) {
				BasicDBList	rootCauseDbObject = (BasicDBList) inputJsonObjList.get(ROOTCAUSE);
				rootCauseList=getRootCasue(rootCauseDbObject);
			}
			if (inputJsonObjList.get("requestTypeRootCauseMapping") != null) {
				BasicDBList	requestTypeRootCauseDbObject = (BasicDBList) inputJsonObjList.get("requestTypeRootCauseMapping");
				requestTypeRootCauseMapping=getReqeustTypeRootCauseMapping(requestTypeRootCauseDbObject);
			}
			String maker = inputJsonObjList.getString(MAKER);
			String workflowStatus = inputJsonObjList.getString(WORKFLOWSTATUS);
			String crtDate = (String) inputJsonObjList.getString(CRTDATE);
			String modBy = (String) inputJsonObjList.getString(MODBY);
			String modDate = (String) inputJsonObjList.getString(MODDATE);
			String workflowRemark = (String) inputJsonObjList.getString(WORKFLOWREMARK);
			String crtBy = (String) inputJsonObjList.getString(CRTBY);
			Query<Organization> query = mongoDatastore.createQuery(Organization.class).filter(ORG_NAME, orgName);
			List<Organization> orgList = query.asList();
			if (orgList.size() >= 1) {
				Organization org = orgList.get(0);// for get org details
				org.setOrgManager(orgManager);
				org.setSuperAdmins(superAdmins);
				if (requestTypeList.size() > 0 && highLevelRequestTypeList.size() > 0) {
					org.setRequestTypes(requestTypeList);
					org.setHighLevelRequestTypeMapping(highLevelRequestTypeList);
				}
				if (rootCauseList.size() > 0) {
					org.setRootCause(rootCauseList);
				}
				if (requestTypeRootCauseMapping.size() > 0) {
					org.setRequestTypeRootCauseMapping(requestTypeRootCauseMapping);
				}
				OrgPreferences preference = new OrgPreferences();
				if (inputJsonObjList.get(ENABLEGROUPLEVELOERRIDE) != null) {
					enableGroupLevelOverride = (String) inputJsonObjList.getString(ENABLEGROUPLEVELOERRIDE);
					preference.setEnableGroupLevelOverride(enableGroupLevelOverride);
					org.setOrgPreferences(preference);
				}
				//[C170665-1719] DCC Requirement: Add Case status field
				if(inputJsonObjList.get(ORGLEVELINQUIRYSUBSTATUSENABLED) != null) {
					enableInquirySubStatus = (String) inputJsonObjList.getString(ORGLEVELINQUIRYSUBSTATUSENABLED);
					preference.setEnableInquirySubStatus(enableInquirySubStatus);
					org.setOrgPreferences(preference);
				}
				if(inputJsonObjList.get(ENABELORGLEVELMETADATA)!=null) {
					String enableOrgMetaData=(String)inputJsonObjList.getString(ENABELORGLEVELMETADATA);
					org.setEnableOrgLevelMetaData(Boolean.parseBoolean(enableOrgMetaData));
				}
				org.setWorkflowStatus(workflowStatus);
				org.setWorkflowRemarks(workflowRemark);
				org.setMaker(maker);
				org.setCrtBy(crtBy);
				org.setModBy(modBy);
				org.setModDate(createdDate);
				status = mongoDatastore.save(org) != null ? true : false;
			} else {
				Organization organization = new Organization();
				organization.setOrgName(orgName);
				organization.setOrgManager(orgManager);
				organization.setSuperAdmins(superAdmins);
				organization.setRequestTypes(requestTypeList);
				organization.setHighLevelRequestTypeMapping(highLevelRequestTypeList);
				organization.setRootCause(rootCauseList);
				organization.setRequestTypeRootCauseMapping(requestTypeRootCauseMapping);
				OrgPreferences preference = new OrgPreferences();
				if (inputJsonObjList.get(ENABLEGROUPLEVELOERRIDE) != null) {
					enableGroupLevelOverride = (String) inputJsonObjList.getString(ENABLEGROUPLEVELOERRIDE);
					preference.setEnableGroupLevelOverride(enableGroupLevelOverride);
					organization.setOrgPreferences(preference);
				}
				//[C170665-1719] DCC Requirement: Add Case status field
				if(inputJsonObjList.get(ORGLEVELINQUIRYSUBSTATUSENABLED) != null) {
					enableInquirySubStatus = (String) inputJsonObjList.getString(ORGLEVELINQUIRYSUBSTATUSENABLED);
					preference.setEnableInquirySubStatus(enableInquirySubStatus);
					organization.setOrgPreferences(preference);
				}
				if(inputJsonObjList.get(ENABELORGLEVELMETADATA)!=null) {
					String enableOrgMetaData=(String)inputJsonObjList.getString(ENABELORGLEVELMETADATA);
					organization.setEnableOrgLevelMetaData(Boolean.parseBoolean(enableOrgMetaData));
				}
				organization.setWorkflowStatus(workflowStatus);
				organization.setWorkflowRemarks(workflowRemark);
				organization.setCrtBy(crtBy);
				organization.setCrtDate(createdDate);
				organization.setModBy(modBy);
				organization.setModDate(createdDate);
				organization.setMaker(maker);
				status = mongoDatastore.save(organization) != null ? true : false;
			}
		} catch (Exception e) {
			subLogger.error("Exception in OrganizationDAO.saveOrgData", e);
			throw new CommunicatorException("Exception in OrganizationDAO.saveOrgData");

		}
		return status;
	}

	public Organization getOrgData(String orgName) throws CommunicatorException {
		Query<Organization> query = null;
		try {
			query = mongoDatastore.createQuery(Organization.class).filter(ORG_NAME, orgName);
		} catch (Exception e) {
			subLogger.error("Exception in OrganizationDAO.saveOrgData", e);
			throw new CommunicatorException("Exception in OrganizationDAO.getOrgData");
		}
		return query.first();
	}

	public List<OrganizationAuditTrail> getRequests(String soeid, String requestType, String orgName)
			throws CommunicatorException {
		Query<OrganizationAuditTrail> query = null;
		List<OrganizationAuditTrail> requestsList = new ArrayList<>();
		try {
			if (MY_REQUEST.equalsIgnoreCase(requestType)) { // request that sent for approval
				query = mongoDatastore.createQuery(OrganizationAuditTrail.class).filter(ORG_NAME, orgName).filter(MAKER,
						soeid);
			} else if (REQUEST_FOR_APPROVAL.equalsIgnoreCase(requestType)) { // for request that i need to approve
				query = mongoDatastore.createQuery(OrganizationAuditTrail.class).filter(ORG_NAME, orgName)
						.filter(WORKFLOWSTATUS, PENDING_FOR_APPROVAL);
				query.criteria(MAKER).notEqual(soeid);
			} else if (APPROVED.equalsIgnoreCase(requestType)) { // request for get all approved request
				query = mongoDatastore.createQuery(OrganizationAuditTrail.class).filter(ORG_NAME, orgName)
						.filter(WORKFLOWSTATUS, APPROVED).filter(MAKER, soeid);
			} else {
				query = mongoDatastore.createQuery(OrganizationAuditTrail.class).filter(ORG_NAME, orgName);
			}
			requestsList = query.asList(); // for sort the request by date in decending order
			Collections.sort(requestsList, new Comparator<OrganizationAuditTrail>() {
				@Override
				public int compare(OrganizationAuditTrail o1, OrganizationAuditTrail o2) {
					return o2.getCrtDate().compareTo(o1.getCrtDate());
				}
			});
		} catch (Exception e) {
			subLogger.error("Exception in OrganizationDAO.getRequests", e);
			throw new CommunicatorException("Exception in OrganizationDAO.getRequests");
		}
		return requestsList;
	}

	public OrganizationAuditTrail getRequestByID(long id, String orgName) throws CommunicatorException {
		Query<OrganizationAuditTrail> query = null;
		try {
			if (null != orgName) {
				query = mongoDatastore.createQuery(OrganizationAuditTrail.class).filter(ID, id).filter(ORG_NAME,
						orgName);
			}
		} catch (Exception e) {
			subLogger.error("Exception in OrganizationDAO.getRequests", e);
			throw new CommunicatorException("Exception in OrganizationDAO.getRequests");
		}
		return query.first();
	}

	public List<OrganizationAuditTrail> getAllPendingRequests(String orgName) throws CommunicatorException {
		Query<OrganizationAuditTrail> query = null;
		try {
			if (orgName != null) {
				query = mongoDatastore.createQuery(OrganizationAuditTrail.class).filter(ORG_NAME, orgName)
						.filter("workflowStatus", "Pending for approval");
			}
		} catch (Exception e) {
			subLogger.error("Exception in OrganizationDAO.getAllPendingRequests", e);
			throw new CommunicatorException("Exception in OrganizationDAO.getAllPendingRequests");
		}
		return query.asList();
	}
  
	/**
	 * method for check requests (request type, root cause, request type root cause mapping) already raised or not .
	 * 
	 * @param org
	 * @param auditTrailList
	 */
	public Map<String, Boolean> checkAlreadyRaisedRequests(Organization org,
			List<OrganizationAuditTrail> auditTrailList) throws CommunicatorException {
		Map<String, Boolean> alreadyRaisedRequestMap = new HashMap<String, Boolean>();
		try {
			if (org != null && !auditTrailList.isEmpty()) {
				List<String> orgRequestType = org.getRequestTypes();
				List<String> orgRootCasue = org.getRootCause();
				List<HighlevelRequestType> orgHighLevelRequestType = org.getHighLevelRequestTypeMapping();
				Map<String, List<String>> orgRootCauseRequestTypeMapping = org.getRequestTypeRootCauseMapping();
				auditTrailList.forEach(orgAuditTrail -> {
					if (null != orgAuditTrail.getHighLevelRequestTypeMapping()
							&& null != org.getHighLevelRequestTypeMapping()
							&& orgAuditTrail.getHighLevelRequestTypeMapping().size() > 0
							&& org.getHighLevelRequestTypeMapping().size() > 0) {
						boolean requestTypeStatus = orgRequestType.equals(getAuditTrailRequestType(orgAuditTrail.getRequestTypes()));
						boolean highLevelRequestTypeMappingStatus = orgHighLevelRequestType
								.equals(getAuditTrailHighLevelRequest(orgAuditTrail.getHighLevelRequestTypeMapping()));
						if (!requestTypeStatus || !highLevelRequestTypeMappingStatus) {
							alreadyRaisedRequestMap.put(REQUESTTYPE, true);
							alreadyRaisedRequestMap.put(HIGHLEVELREQUESTTYPEMAPPING, true);
							alreadyRaisedRequestMap.put(REQUESTTTYPEROOTCAUSEMAPPING, true);
						}
					} else if (org.getHighLevelRequestTypeMapping() == null
							&& null != orgAuditTrail.getHighLevelRequestTypeMapping()
							&& orgAuditTrail.getHighLevelRequestTypeMapping().size() > 0) {
						alreadyRaisedRequestMap.put(REQUESTTYPE, true);
						alreadyRaisedRequestMap.put(HIGHLEVELREQUESTTYPEMAPPING, true);
						alreadyRaisedRequestMap.put(REQUESTTTYPEROOTCAUSEMAPPING, true);
					}
					if (null != orgAuditTrail.getRequestTypeRootCauseMapping()
							&& null != org.getRequestTypeRootCauseMapping()
							&& orgAuditTrail.getRequestTypeRootCauseMapping().size() > 0
							&& org.getRequestTypeRootCauseMapping().size() > 0) {
						boolean requestTypeRootCauseMappingStatus = orgRootCauseRequestTypeMapping
								.equals(getAuditRequestTypeRootCause(orgAuditTrail.getRequestTypeRootCauseMapping()));
						if (!requestTypeRootCauseMappingStatus) {
							alreadyRaisedRequestMap.put(REQUESTTTYPEROOTCAUSEMAPPING, true);
						}
					} else if (org.getRequestTypeRootCauseMapping() == null
							&& null != orgAuditTrail.getRequestTypeRootCauseMapping()
							&& orgAuditTrail.getRequestTypeRootCauseMapping().size() > 0) {// for the case if org
																							// request type root cause
																							// is null
						alreadyRaisedRequestMap.put(REQUESTTTYPEROOTCAUSEMAPPING, true);
					}

					if (null != orgAuditTrail.getRootCause() && null != org.getRootCause()
							&& orgAuditTrail.getRootCause().size() > 0 && org.getRootCause().size() > 0) {
						boolean rootCauseStatus = orgRootCasue.equals(getAuditRootCause(orgAuditTrail.getRootCause()));
						if (!rootCauseStatus) {
							alreadyRaisedRequestMap.put(ROOTCAUSE, true);
						}
					} else if (org.getRootCause() == null && null != orgAuditTrail.getRootCause()
							&& orgAuditTrail.getRootCause().size() > 0) {
						alreadyRaisedRequestMap.put(ROOTCAUSE, true);
					}
				});
			}
			if (alreadyRaisedRequestMap.get(REQUESTTYPE) == null) {
				alreadyRaisedRequestMap.put(REQUESTTYPE, false);
				alreadyRaisedRequestMap.put(HIGHLEVELREQUESTTYPEMAPPING, false);
			}
			if (alreadyRaisedRequestMap.get(REQUESTTTYPEROOTCAUSEMAPPING) == null) {
				alreadyRaisedRequestMap.put(REQUESTTTYPEROOTCAUSEMAPPING, false);
			}
			if (alreadyRaisedRequestMap.get(ROOTCAUSE) == null) {
				alreadyRaisedRequestMap.put(ROOTCAUSE, false);
			}
		} catch (Exception e) {
			subLogger.error("Exception in OrganizationDAO.getAllPendingRequests", e);
			throw new CommunicatorException("Exception in OrganizationDAO.getAllPendingRequests");
		}
		return alreadyRaisedRequestMap;
	}
	
	/**
	 * method for check which request can raise from current and previous request.
	 * 
	 * @param currentRequest
	 * @param alreadyRaisedRequest
	 */
	public boolean checkRequests(Map<String, Boolean> currentRequest, Map<String, Boolean> alreadyRaisedRequest)
			throws CommunicatorException {
		boolean status = false;
		try {
			for (Entry<String, Boolean> map : currentRequest.entrySet()) {
				String requestMetaData = map.getKey();
				boolean currentRequestStatus = map.getValue();
				boolean alreadyRaisedRequestStatus = alreadyRaisedRequest.get(requestMetaData);
				if (currentRequestStatus && alreadyRaisedRequestStatus) {
					status = false;
					break;
				} else {
					status = true;
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in OrganizationDAO.checkRequests", e);
			throw new CommunicatorException("Exception in OrganizationDAO.checkRequests");
		}
		return status;
	}

	/**
	 * method for get already raised request in a particular org.
	 * 
	 * @param orgName
	 */
	public Map<String, Boolean> getAlreadyRaisedRequest(String orgName) {
		OrganizationDAO orgDao = new OrganizationDAO();
		Map<String, Boolean> alreadyRaisedRequestMap = new HashMap<>();
		try {
			if (orgName != null) {
				List<OrganizationAuditTrail> orgAuditTrailList = orgDao.getAllPendingRequests(orgName);
				Organization organization = orgDao.getOrgData(orgName);
				alreadyRaisedRequestMap = orgDao.checkAlreadyRaisedRequests(organization, orgAuditTrailList);
			}
		} catch (Exception e) {
			subLogger.error("Exception in GroupDAO.getAlreadyRaisedRequest", e);
		}
		return alreadyRaisedRequestMap;
	}
	
	/**
	 * method for get all the request type except which is deleted.
	 * 
	 * @param orgAuditRequestTypeList
	 */
	private List<String> getRequestsType(BasicDBList orgAuditRequestTypeList) {
		List<String> requestTypeList = new ArrayList<>();
		for (Object obj : orgAuditRequestTypeList) {
			BasicDBObject dbObj = (BasicDBObject) obj;
			String requestType = dbObj.getString("requestType");
			String statusIndicator = dbObj.getString("statusIndicator");
			if (!STATUSINDICATOR.equalsIgnoreCase(statusIndicator)) {
				requestTypeList.add(requestType);
			}
		}

		return requestTypeList;
	}

	/**
	 * method for get all the high level request type except which is deleted.
	 * 
	 * @param highLevelRequestTYpeList
	 */
	private List<HighlevelRequestType> getHighLevelRequestsType(BasicDBList highLevelRequestTYpeList) {
		List<HighlevelRequestType> highLevelRequestList = new ArrayList<>();
		for (Object obj : highLevelRequestTYpeList) {
			BasicDBObject dbObj = (BasicDBObject) obj;
			String reqeustType = dbObj.getString("requestType");
			String highLevelRequestType = dbObj.getString("highlevelRequestType");
			String statusIndicator = dbObj.getString("statusIndicator");
			if (!STATUSINDICATOR.equalsIgnoreCase(statusIndicator)) {
				HighlevelRequestType highLevelRequest = new HighlevelRequestType();
				highLevelRequest.setRequestType(reqeustType);
				highLevelRequest.setHighlevelRequestType(highLevelRequestType);
				highLevelRequestList.add(highLevelRequest);
			}
		}
		return highLevelRequestList;
	}

	/**
	 * method for get all the root cause except which is deleted.
	 * 
	 * @param orgAuditTrailRootCause
	 */
	private List<String> getRootCasue(BasicDBList orgAuditTrailRootCause) {
		List<String> rootCauseList = new ArrayList<>();
		for (Object obj : orgAuditTrailRootCause) {
			BasicDBObject dbObj = (BasicDBObject) obj;
			String rootCause = dbObj.getString("rootCause");
			String statusIndicator = dbObj.getString("statusIndicator");
			if (!STATUSINDICATOR.equalsIgnoreCase(statusIndicator)) {
				rootCauseList.add(rootCause);
			}
		}
		return rootCauseList;
	}
	
	/**
	 * method for get all the root cause except which is deleted.
	 * 
	 * @param orgAuditRequestTypeList
	 */
	private Map<String, List<String>> getReqeustTypeRootCauseMapping(BasicDBList orgRequestTypeRootCauseMapping) {
		Map<String,List<String>>reqeustTypeRootCauseMapping=new HashMap<String, List<String>>();
		for(Object obj:orgRequestTypeRootCauseMapping) {
			BasicDBObject dbObj=(BasicDBObject)obj;
			String requestType=dbObj.getString("requestType");
			List<String>rootCauseList=(List<String>)dbObj.get("rootCause");
			String statusIndicator = dbObj.getString("statusIndicator");
			if(!STATUSINDICATOR.equalsIgnoreCase(statusIndicator)) {
				reqeustTypeRootCauseMapping.put(requestType, rootCauseList);
			}
		}	
		return reqeustTypeRootCauseMapping;
	}
	
	/**
	 * method for get all the request type except which is deleted.
	 * 
	 * @param reqeustType
	 */
	private List<String>getAuditTrailRequestType(List<OrgAuditTrailRequestType>reqeustType){
		List<String> requestList = new ArrayList<>();
		if (reqeustType != null && reqeustType.size() > 0) {
			reqeustType.forEach(req -> {
				String status = req.getStatusIndicator();
				if (!STATUSINDICATOR.equalsIgnoreCase(status)) {
					requestList.add(req.getRequestType());
				}
			});
		}
		return requestList;
	}
	
	/**
	 * method for get all the high level request type except which is deleted.
	 * 
	 * @param highLevelRequestType
	 */
	private List<HighlevelRequestType>getAuditTrailHighLevelRequest(List<OrgAuditTrailHighLevelRequestTypeMapping>highLevelRequestType){
	   List<HighlevelRequestType>highLevelRequestTypeList=new ArrayList<>();
	   if(highLevelRequestType!=null && highLevelRequestType.size()>0) {
		   highLevelRequestType.forEach(req->{
			   String status=req.getStatusIndicator();
			   if(!STATUSINDICATOR.equalsIgnoreCase(status)) {
				  HighlevelRequestType highLevelRequest=new HighlevelRequestType();
				  highLevelRequest.setRequestType(req.getRequestType());
				  highLevelRequest.setHighlevelRequestType(req.getHighlevelRequestType());
				  highLevelRequestTypeList.add(highLevelRequest);
			   }
		   });   
	   }
		return highLevelRequestTypeList;	
	}
	
	/**
	 * method for get all the high level root cause except which is deleted.
	 * 
	 * @param rootCause
	 */
	private List<String>getAuditRootCause(List<OrgAuditTrailRootCause>rootCause){
		List<String>rootCauseList=new ArrayList<>();
		if(rootCause!=null && rootCause.size()>0)
		{
			rootCause.forEach(req->{
				String status=req.getStatusIndicator();
				if(!STATUSINDICATOR.equalsIgnoreCase(status)) {
					rootCauseList.add(req.getRootCause());
				}
			});
		}
		return rootCauseList;
	}
	
	/**
	 * method for get all the request type root cause except which is deleted.
	 * 
	 * @param requestTypeRootCause
	 */
	private Map<String,List<String>>getAuditRequestTypeRootCause(List<OrgAuditTrailRequestTypeRootCauseMapping>requestTypeRootCause){
	   Map<String,List<String>>requestTypeRootCauseMapping=new HashMap<>();
	   if(requestTypeRootCause!=null && requestTypeRootCause.size()>0) {
		   requestTypeRootCause.forEach(req->{
			   String status=req.getStatusIndicator();
			    if(!STATUSINDICATOR.equals(status)) {
			    	requestTypeRootCauseMapping.put(req.getRequestType(), req.getRootCause());
			    }
		   });   
	   }
		return requestTypeRootCauseMapping;	
	}
	
}
