
package com.citi.icg.qma.common.core.util;


import java.io.IOException;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jakarta.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.bson.BsonArray;
import org.bson.BsonValue;
import org.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.reflect.TypeToken;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class DataConversionUtil
{
	private static final String MONGO_UTC_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	private static final Logger subLogger = LoggerFactory.getLogger(DataConversionUtil.class);
	private static final String PIPELINES_KEY = "pipelines";

	private DataConversionUtil(){
		//As this class is Util, so added making private constructor.
		//Sonar Fix -- Utility classes should not have public constructors 
	}
	
	private static JsonSerializer<Date> ser = new JsonSerializer<Date>()
	{
		@Override
		public JsonElement serialize(Date src, Type typeOfSrc, JsonSerializationContext
				context)
		{
			if (src == null)
			{
				return null;
			}
			else
			{
				SimpleDateFormat format = new SimpleDateFormat(MONGO_UTC_FORMAT);
				JsonObject jo = new JsonObject();
				jo.addProperty("$date", format.format(src));
				return jo;
			}
		}
	};

	private static JsonDeserializer<Date> deser = new JsonDeserializer<Date>()
	{
		@Override
		public Date deserialize(JsonElement json, Type typeOfT,
				JsonDeserializationContext context) throws JsonParseException
		{
			Date date = null;
			SimpleDateFormat format = new SimpleDateFormat(MONGO_UTC_FORMAT);
			try
			{
				date = format.parse(json.getAsJsonObject().get("$date").getAsString());
			}
			catch (ParseException e)
			{
				subLogger.error("Issue in date parsing", e);

			}
			return date;
		}
	};

	private static Gson gson = new GsonBuilder()
			.registerTypeAdapter(Date.class, ser)
			.registerTypeAdapter(Date.class, deser).create();

	public static String convertJavaObjectToJson(Object obj) throws JsonGenerationException, JsonMappingException, IOException
	{
		String json = new ObjectMapper().writeValueAsString(obj);

		return json;

	}

	public static <T> Object convertJSONToJava(String json, Class<T> clazz) throws JsonGenerationException, JsonMappingException, IOException
	{
		return new ObjectMapper().readValue(json, clazz);
	}

	public static <T> List<T> convertDBObjectToJava(List<DBObject> dbObjectList) throws JsonGenerationException, JsonMappingException, IOException
	{
		@SuppressWarnings("unchecked")
		ArrayList<T> pojoList = (ArrayList<T>) gson.fromJson(dbObjectList.toString(), new TypeToken<ArrayList<T>>()
		{
		}.getType());

		return pojoList;

	}

	public static Response sendJsonResponseForString(String json)
	{
		 return Response.status(200).entity(json).build();

	}

	public static Response sendJsonResponseForBoolean(boolean success)
	{
		String json = null;
		if (success)
		{
			json = "{\"processingstatus\":\"" + true + "\"}";
		}
		else
		{
			json = "{\"processingstatus\":\"" + false + "\"}";
		}
		return sendJsonResponseForString(json);
	}

	public static Response sendJsonResponseForBean(Object bean) throws IOException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		String output = convertJavaObjectToJson(bean);
		return sendJsonResponseForString(output);
	}

	//Use this method to avoid JSON Parse encoding issues for Special chars like %,& etc
	public static String removeJsonRequestCharEncoding(String request)
	{
		String req = request;// Sonar Fix -- Method parameters, caught exceptions and foreach variables should not be reassigned
		if (!StringUtils.isBlank(req))
		{
			req = req.replace("%", "%25").replace("&", "%26");
		}
		return req;
	}
	public static List<BasicDBObject> createAggregatePipelines(String queryStr) {
		List<BasicDBObject> list = new ArrayList<>();
		if (StringUtils.isNotBlank(queryStr) && queryStr.contains(PIPELINES_KEY)) {
			BasicDBObject json = BasicDBObject.parse(queryStr);
			Object pipelineList = json.get(PIPELINES_KEY) != null ? json.get(PIPELINES_KEY) : null;
			if (pipelineList != null && pipelineList instanceof BasicDBList bList) {
				bList.forEach(b -> list.add((BasicDBObject) b));
			}else if (pipelineList != null && pipelineList instanceof JSONArray pipelineStageObj) {
				for (int i = 0; i < pipelineStageObj.length(); i++) {
					BasicDBObject document = BasicDBObject.parse(pipelineStageObj.get(i).toString());
					list.add(document);
				}

			}
		}
		return list;
	}
	/*
	 * The Query should have existing aggregate pipeline query with [{pipeline1},{pipeline2}] intact
	 * This method will only add parsing complaint strings for intermediate parsing and translating to list of pipelines
	 * <{pipelines:>+AGGR_EXISTING_QUERY+<}>
	 * */
	public static String prepareAggregatePipelineStrQuery(String queryStr) {
		return new StringBuilder("{ pipelines : ").append(queryStr).append(" } ").toString();
	}
	public static <T> Object convertJSONToJavaSilently(String json, Class<T> clazz)
	{

		Object obj = null;
		try {
			obj = new ObjectMapper().readValue(json, clazz);
		} catch (IOException e) {
			subLogger.warn("Exception occurred while json to Object conversion: ", e);
		}

		return obj;

	}

	public static List<DBObject> convertJsonToDBObjectList(String inputString) {
		List<DBObject> resultList = new ArrayList<>();
		try {
			BsonArray array = BsonArray.parse(inputString);
			for(BsonValue value :array.getValues()) {
				BasicDBObject obj = BasicDBObject.parse(value.toString());
				resultList.add(obj);
			}
		} catch (Exception e) {
			subLogger.warn("Exception while conversion JSON string to DBObject list: ", e);
		}
		return resultList;
	}
	
	public static List<BasicDBObject> convertJsonToBasicDBObjectList(String inputString) {
		List<BasicDBObject> resultList = new ArrayList<>();
		try {
			BsonArray array = BsonArray.parse(inputString);
			for(BsonValue value :array.getValues()) {
				BasicDBObject obj = BasicDBObject.parse(value.toString());
				resultList.add(obj);
			}
		} catch (Exception e) {
			subLogger.warn("Exception while conversion JSON string to BasicDBObject list: ", e);
		}
		return resultList;
	}
	
	public static BasicDBList convertJsonToBasicDBList(String inputString) {
		BasicDBList resultList = new BasicDBList();
		try {
			BsonArray array = BsonArray.parse(inputString);
			for(BsonValue value :array.getValues()) {
				BasicDBObject obj = BasicDBObject.parse(value.toString());
				resultList.add(obj);
			}
		} catch (Exception e) {
			subLogger.warn("Exception while conversion JSON string to DBObject list: ", e);
		}
		return resultList;
	}
	
	public static Response sendJsonLinkResponseForBoolean(boolean success)
	{
		String json = null;
		if (success)
		{
			json = "{\"success\":\"" + true + "\"}";
		}
		else
		{
			json = "{\"failure\":\"" + false + "\"}";
		}
		return sendJsonResponseForString(json);
	}
}
