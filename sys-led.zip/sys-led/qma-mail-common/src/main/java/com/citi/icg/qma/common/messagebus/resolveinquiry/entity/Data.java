package com.citi.icg.qma.common.messagebus.resolveinquiry.entity;

import java.io.Serializable;

public class Data implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String eventId;
	private String eventType;
	private String eventTime;
	private String eventSrcSys;
	private Payload[] payload;
	public Data() {
		super();
		// Auto-generated constructor stub
	}
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getEventTime() {
		return eventTime;
	}
	public void setEventTime(String eventTime) {
		this.eventTime = eventTime;
	}
	public String getEventSrcSys() {
		return eventSrcSys;
	}
	public void setEventSrcSys(String eventSrcSys) {
		this.eventSrcSys = eventSrcSys;
	}
	public Payload[] getPayload() {
		return payload;
	}
	public void setPayload(Payload[] payload) {
		this.payload = payload;
	}
	
	
}
