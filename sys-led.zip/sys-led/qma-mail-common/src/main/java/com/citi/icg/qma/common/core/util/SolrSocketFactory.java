package com.citi.icg.qma.common.core.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

public final class SolrSocketFactory {

	private static final String CERT_PASS = "certPass";
	private static final String CERT_NAME = "certName";
	private static final String CERT_LOCATION = "certLocation";
	private static final String SOLR_CERT_CONFIG = "solrCertConfig";
	private static final String CERT_PASS_IV = "certPassIV";
	private static SSLConnectionSocketFactory socketFactory = null;
	private static final Logger logger = LoggerFactory.getLogger(SolrSocketFactory.class);

	private static final String KEYSTORE_JKS = "JKS";
	private static final String SOLR_SSL_ENABLED = "solrSSLEnabled";

	private SolrSocketFactory() {
	}

	/**
	 * Provides a singleton instance of SSLConnectionSocketFactory for Solr.
	 *
	 * @return SSLConnectionSocketFactory
	 */
	public static synchronized SSLConnectionSocketFactory getInstance() {
		if (socketFactory == null) {
			try {
				String xmcEnvironment = System.getProperty(AppserverConstants.ENV_PARAM_KEY);
				String certFileName = getCertFileNameWithPath();
				String certPassword = getPassword();

				if (StringUtils.isNotEmpty(certFileName) && StringUtils.isNotEmpty(certPassword)) {
					logger.info("ENV : " + xmcEnvironment + ", SOLR CERT FILE : " + certFileName);

					// Load the trust store explicitly
					KeyStore trustStore = KeyStore.getInstance(KEYSTORE_JKS);
					try (InputStream trustStoreStream = new FileInputStream(certFileName)) {
						trustStore.load(trustStoreStream, certPassword.toCharArray());
					}

					SSLContextBuilder sslContextBuilder = SSLContextBuilder.create()
							.loadTrustMaterial(trustStore, null);

					socketFactory = new SSLConnectionSocketFactory(sslContextBuilder.build());
					logger.info("SOLR :: Environment is :" + xmcEnvironment + " using SSL enabled HttpClient.");
				}
			} catch (Exception e) {
				logger.error("SOLR :: Error while creating SSL connection socket factory: ", e);
			}
		}
		return socketFactory;
	}

	public static HttpClient getHttpClientSSLEnabled()
			throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
		HttpClient httpClient = null;
		try {
			String xmcEnvironment = System.getProperty(AppserverConstants.ENV_PARAM_KEY);
			SSLConnectionSocketFactory socketFactory = SolrSocketFactory.getInstance();
			if (socketFactory != null) {
				httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).disableCookieManagement().build();
				logger.info("SOLR :: Environment is :" + xmcEnvironment + " using two-way SSL enabled HttpClient.");
			}
		} catch (Exception e) {
			logger.error("Error while creating HTTP client in getHttpClientSSLEnabled(): ", e);
			httpClient = HttpClientBuilder.create().build();
		}
		return httpClient;
	}

	private static String getPassword() {
		String certPass = null;
		try {
			Map<String, Object> solrCertConfig = QMACacheFactory.getCache().getConfigById(SOLR_CERT_CONFIG).getSolrCertConfig();
			certPass = DecryptionUtil.decrypt((String) solrCertConfig.get(CERT_PASS),  (String) solrCertConfig.get(CERT_PASS_IV),
					ApplicationConstants.APPLICATION_ENCRYPTION_KEY);
		} catch (Exception ex) {
			logger.error("Error retrieving certificate password: ", ex);
		}
		return certPass;
	}

	private static String getCertFileNameWithPath() {
		String fileNameWithPath = null;
		try {
			Map<String, Object> solrCertConfig = QMACacheFactory.getCache().getConfigById(SOLR_CERT_CONFIG).getSolrCertConfig();
			String certPath = (String) solrCertConfig.get(CERT_LOCATION);
			String certName = (String) solrCertConfig.get(CERT_NAME);
			fileNameWithPath = certPath + certName;
		} catch (Exception ex) {
			logger.error("Error retrieving certificate file name with path: ", ex);
		}
		return fileNameWithPath;
	}

	public static boolean isSolrSSLEnabled() {
		boolean solrSSLEnabled = false;
		try {
			Map<String, Object> solrCertConfig = QMACacheFactory.getCache().getConfigById(SOLR_CERT_CONFIG).getSolrCertConfig();
			if(null != solrCertConfig.get(SOLR_SSL_ENABLED)) {
				solrSSLEnabled = (Boolean) solrCertConfig.get(SOLR_SSL_ENABLED);
			}
		} catch (Exception e) {
			logger.warn("Solr SSL config not found");
		}
		return solrSSLEnabled;
	}
}
