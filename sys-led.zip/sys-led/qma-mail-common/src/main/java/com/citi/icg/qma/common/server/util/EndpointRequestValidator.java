/**
 * 
 */
package com.citi.icg.qma.common.server.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

import jakarta.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;

import org.slf4j.Logger;

/**
 * 
 *
 */
public class EndpointRequestValidator {

	private static final Logger logger = LoggerFactory.getLogger(EndpointRequestValidator.class);
	private static String[] inquiryActionArray = {"New Inquiry", "Reply", "ReplyAll"};
	private static final HashMap<String, String> userLatestTokenHolder = new HashMap<>();
	private static final String MESSAGE_OK = "Ok";
	private static final String REQUEST_TYPE = "requestType";
	private static final String FROM = "from";
	private static final String INQUIRY_ACTION = "inquiryAction";
	private static final String TOKEN = "token";
	private static final String TEXT = "text";
	private static final String NEW_INQUIRY = "New Inquiry";
	private static final String INQUIRY_ID = "inquiryId";
	private static final String PREVIOUS_MAIL_TRAIL_REQ = "mailTrailReq";
	private static final String CONVERSATION_ID = "conversationId";
	private EndpointRequestValidator()
	{
		
	}
	public static Response validateCreateInquiryRequest(String request, String soeId)
	{
		BasicDBObject requestObj;
		Response response = null;
		try {
			if (request != null && !request.isEmpty()) {
				requestObj = BasicDBObject.parse(request);
				response = validateRequest(requestObj, soeId);
			} else {
				return Response.status(200).entity("Request body missing").build();
			}
		} catch (Exception ex) {
			logger.error("Invalid JSON " + ex);
			return Response.status(400).entity("Invalid JSON").build();
		}
		return response;
	}
	
	private static Response validateRequest(BasicDBObject requestObj, String soeId) {
		Response response;
		//Duplicate Request with same token
		response = isDuplicateRequest(soeId, requestObj);
		//Mandatory Fields - request Type, From group, To Recipients, Action
		// One of Listed Actions -- New Inquiry etc
		if (response.getStatus() == 200)
			response = validateRequiredFields(requestObj);
		//Validate From Group
		if (response.getStatus() == 200)
			response = validateFromParam(requestObj);
		//Validate TO, CC, BCC
		if (response.getStatus() == 200)
			response = validateToCcBccParam(requestObj, EndpointRequestUtil.RECIPIENT_TO);
		if (response.getStatus() == 200)
			response = validateToCcBccParam(requestObj, EndpointRequestUtil.RECIPIENT_CC);
		if (response.getStatus() == 200)
			response = validateToCcBccParam(requestObj, EndpointRequestUtil.RECIPIENT_BCC);
		//validate action
		if (response.getStatus() == 200)
			response = validateInquiryAction(requestObj);
		//validate request type
		if (response.getStatus() == 200)
			response = validateRequestType(requestObj);
		//attach variable should be present and can be empty
		// email body should be present and can be empty
		//From Group Mandatory checks 
		
		//Processing Region, Tags ect based on group not supported for Day 1
		//Maker check flag for Day 1 is not supported for API access
		
		
		return response;
	}
	/**
	 * This method validate parameter for email trail
	 * @param requestObj
	 * @return
	 */
	public static Response validateEmailBodyTarilReq(BasicDBObject requestObj) {
		String inquiryAction = requestObj.getString(INQUIRY_ACTION);
		String mailTrailReq = requestObj.getString(PREVIOUS_MAIL_TRAIL_REQ);
		String convId = requestObj.getString(CONVERSATION_ID);
		boolean mailTrailRequested = mailTrailReq != null && "Y".equalsIgnoreCase(mailTrailReq);
		boolean convIdAvailbale = null != convId;
		boolean inquiryActionReply = Arrays.asList(inquiryActionArray).contains(inquiryAction) && !inquiryAction.equals(NEW_INQUIRY);
		if(mailTrailRequested && !convIdAvailbale){
			String msg = "Conversation id missing.";
			return Response.status(400).entity(msg).build();
		}else if(convIdAvailbale && !inquiryActionReply && mailTrailRequested)
		{
			String msg = "Inquiry action should be reply / reply all.";
			return Response.status(400).entity(msg).build();
		}
		return Response.status(200).entity(MESSAGE_OK).build();
	}
	private static Response validateRequestType(BasicDBObject requestObj) {
		String requestType = requestObj.getString(REQUEST_TYPE);
		if(null != requestType)
		{
			Long fromGroup = QMACacheFactory.getCache().getGroupCodeToIdMap().get(requestObj.getString(FROM).toUpperCase());
			List<String> requestTypeList = QMACacheFactory.getCache().getGroupIdToRequestTypeMap().get(fromGroup);
			if(null != requestTypeList && requestTypeList.contains(requestType))
			{
				return Response.status(200).entity(MESSAGE_OK).build();
			}else{
				String message = "Invalid request type.";
				return Response.status(400).entity(message).build();
			}
		}
		return Response.status(200).entity(MESSAGE_OK).build();
	}
	private static Response validateInquiryAction(BasicDBObject requestObj) {
		String inquiryAction = requestObj.getString(INQUIRY_ACTION);
		if (null != inquiryAction && Arrays.asList(inquiryActionArray).contains(inquiryAction)) {
			String inquiryId = requestObj.getString(INQUIRY_ID);
			if (null != inquiryId && inquiryAction.equals(NEW_INQUIRY)) {
				String msg = "Inquiry action cannot be '" + NEW_INQUIRY + "' if inquiry id present";
				return Response.status(400).entity(msg).build();
			} else if (null == inquiryId && !inquiryAction.equals(NEW_INQUIRY)) {
				String msg = "Inquiry action shuold be '" + NEW_INQUIRY + "' if inquiry id null";
				return Response.status(400).entity(msg).build();
			} else {
				return Response.status(200).entity(MESSAGE_OK).build();
			}
		} else {
			String msg = "Invalid inquiry action. It should be from" + Arrays.asList(inquiryActionArray).toString();
			return Response.status(400).entity(msg).build();
		}
		
	}
	private static Response validateFromParam(BasicDBObject requestObj) {
		Long fromGroup = QMACacheFactory.getCache().getGroupCodeToIdMap().get(requestObj.getString(FROM).toUpperCase());
		if (fromGroup != null) {
			return Response.status(200).entity(MESSAGE_OK).build();
		}else if (GenericUtility.isValidEmailAddress(requestObj.getString(FROM))) {
			String groupEmail = requestObj.getString(FROM);
			String[] emailSplit = groupEmail.split("@");
			String groupName = QMACacheFactory.getCache().getGroupEmailToCodeMap().get(emailSplit[0].toUpperCase());
			if (null != groupName) {
				requestObj.put(FROM, groupName);
				return Response.status(200).entity(MESSAGE_OK).build();
			}else{
				String msg = "Invalid from group";
				return Response.status(400).entity(msg).build();
			}
		}else {			
			String msg = "Invalid from group";
			return Response.status(400).entity(msg).build();
		}
	}
	static Response validateToCcBccParam(BasicDBObject requestObj, String toCCBcc) {
		Response response = Response.status(200).entity(MESSAGE_OK).build();
		if(requestObj.getString(toCCBcc) != null)
		{
			JSONArray jsArray = new JSONArray(requestObj.getString(toCCBcc));
			for (int i = 0; i < jsArray.length(); i++)
			{
				JSONObject jsonObj = jsArray.getJSONObject(i);
				if(null != jsonObj.getString(TEXT)){
					response = validateGroup(jsonObj, toCCBcc);
				}else{
					String message = "Missing '"+toCCBcc+"' recipient";
					return Response.status(400).entity(message).build();
				}
			}
		}
		return response;
	}
	private static Response validateGroup(JSONObject jsonObj, String toCCBcc) {
		Long toGroup = QMACacheFactory.getCache().getGroupCodeToIdMap().get(jsonObj.getString(TEXT).toUpperCase());
		if(toGroup != null || GenericUtility.isValidEmailAddress(jsonObj.getString(TEXT)))
		{
			return Response.status(200).entity(MESSAGE_OK).build();
		}else{
			String message = "Invalid '"+toCCBcc+"' recipient";
			return Response.status(400).entity(message).build();
		}
	}
	private static Response validateRequiredFields(BasicDBObject requestObj) {
		String to = requestObj.getString(EndpointRequestUtil.RECIPIENT_TO);
		String from = requestObj.getString(FROM);
		boolean requiredRecipients  = to != null && from != null;
		boolean requiredRequestType = requestObj.getString(REQUEST_TYPE) != null;
		boolean requiredInqAction = requestObj.getString(INQUIRY_ACTION) != null;
		if(requiredRecipients && requiredRequestType && requiredInqAction)
		{
			return Response.status(200).entity(MESSAGE_OK).build();
		}else{
			String message = "Required paramter missing, to , from, inquiryAction, requestType and token are mandetory.";
			return Response.status(400).entity(message).build();
		}		
	}
	private static Response isDuplicateRequest(String soeId, BasicDBObject inputJsonObj)
	{
		String uiToken = inputJsonObj.getString(TOKEN);
		String holderToken = userLatestTokenHolder.get(soeId);
		if(uiToken != null)
		{
			if (!uiToken.equals(holderToken)) {
				userLatestTokenHolder.put(soeId, uiToken);
				return Response.status(200).entity(MESSAGE_OK).build();
			} else {
				String message = "Duplicate Request ---> " + uiToken;
				return Response.status(400).entity(message).build();
			}
		}else{
			String message = "Token missing";
			return Response.status(400).entity(message).build();
		}
		
	}
	
	/**
	 * @description: method validate all input parameters 
	 * @param request
	 * @return
	 */
	public static Response validateRequestConversation(String request){
		try {
			BasicDBObject requestObj = BasicDBObject.parse(request);
			// Fetch all request params
			Long inquiryId = GenericUtility.getIdFromRequest(requestObj, AppserverConstants.INQUIRY_ID_KEY);
			if (null != inquiryId) {
				if (requestObj.getString(AppserverConstants.CREATED_DATE) != null) {
					String crtDateStr = requestObj.getString(AppserverConstants.CREATED_DATE);
					SimpleDateFormat sDateFormat = new SimpleDateFormat(AppserverConstants.MONGO_UTC_FORMAT);
					sDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
					sDateFormat.parse(crtDateStr);
				}
				if(null != GenericUtility.getIdFromRequest(requestObj, CONVERSATION_ID)){
					Long conversationId = GenericUtility.getIdFromRequest(requestObj, CONVERSATION_ID);
					logger.info("Conversation id:"+conversationId);
				}
			} else {
				String message = "Required input parameters (InquiryId).";
				return Response.status(400).entity(message).build();
			}
		} catch (NumberFormatException e) {
			String message = "Invalid input parameters: (InquiryId should be number).";
			return Response.status(400).entity(message).build();
		} catch (ParseException e) {
			String message = "Invalid date/ date format. Valid date format is "+AppserverConstants.MONGO_UTC_FORMAT
					+" ["+AppserverConstants.VALIDATE_DATE_EXMPL+"]";
			return Response.status(400).entity(message).build();

		} catch (Exception e) {
			String message = "Bad request";
			logger.error("Bad request" + e);
			return Response.status(400).entity(message).build();
		}
		return Response.status(200).entity("OK").build();
	}
}
