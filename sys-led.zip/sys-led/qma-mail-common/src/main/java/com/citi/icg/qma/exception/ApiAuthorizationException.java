package com.citi.icg.qma.exception;

public class ApiAuthorizationException extends Exception{

	private static final long serialVersionUID = -7841074181434629643L;

	public ApiAuthorizationException(String message) {
		super(message);
	}
}
