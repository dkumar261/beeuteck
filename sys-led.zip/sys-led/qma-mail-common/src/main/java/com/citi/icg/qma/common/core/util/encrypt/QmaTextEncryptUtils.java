package com.citi.icg.qma.common.core.util.encrypt;

import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class QmaTextEncryptUtils {
	 private static final Logger logger = LoggerFactory.getLogger(QmaTextEncryptUtils.class);

	    public static void encryptKey(final String plainKey) {
	        final SimpleStringPBEConfig pbeConfig = QMAJasyptConfiguration.getSimpleStringPBEConfig();
	        final PooledPBEStringEncryptor pbeStringEncryptor = new PooledPBEStringEncryptor();
	        pbeStringEncryptor.setConfig(pbeConfig);
	        String encryptedStr = pbeStringEncryptor.encrypt(plainKey);
	        logger.info("Encrypted key = {}", encryptedStr);
	    }

	    public static String decryptKey(final String encryptedKey) throws DataEncrpyptDecryptException {
	        try {
				final SimpleStringPBEConfig pbeConfig = QMAJasyptConfiguration.getSimpleStringPBEConfig();
				final PooledPBEStringEncryptor pbeStringEncryptor = new PooledPBEStringEncryptor();
				pbeStringEncryptor.setConfig(pbeConfig);
				String decryptedStr = pbeStringEncryptor.decrypt(encryptedKey);
				logger.info("Decrypted key = {}", decryptedStr);
				return decryptedStr;
			} catch (Exception e) {
				logger.error("Exception while decryption of password", e);
				throw new DataEncrpyptDecryptException("Exception while decryption of password", e);
			}
	    }

	    public static void main(String[] args) throws DataEncrpyptDecryptException {
	        QmaTextEncryptUtils.encryptKey("textToBeEncrypted");
	        QmaTextEncryptUtils.decryptKey("dVlhTPYMgomGpsFwSSlIscqwnwl1oOy6ElPa8q9pIpI=");
	    }
}
