package com.citi.icg.qma.common.messagebus.dao;

import java.time.Instant;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.messagebus.entity.Data;
import com.citi.icg.qma.common.server.dao.persistence.MongoMorphiaDAO;
import dev.morphia.Key;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

public class MessagePublisherDao extends MongoMorphiaDAO  {
	private static final Logger logger = LoggerFactory.getLogger(MessagePublisherDao.class);
	
	public Object saveEventAudit(Data data,Instant currentTime, String eventId) {
		try {
			EventRecordAudit auditRecord = new EventRecordAudit();
			auditRecord.setEventName(data.getEventName());
			auditRecord.setEventType(data.getEventType());
			auditRecord.setInquiryId(data.getPayload().getInquiryId());
			auditRecord.setConversationId(data.getPayload().getConversationId());
			auditRecord.setData(data);
			auditRecord.setCrtDate(Date.from(currentTime));
			auditRecord.setStatus("UNPUBLISHED");
			auditRecord.setEventCategory("PUBLISH");
			auditRecord.setEventId(eventId);
			Key<EventRecordAudit> key = mongoDatastore.save(auditRecord);
			return key.getId();
		} catch (Exception e) { 
			logger.warn("Exception in MessagePublisherDao.saveEventAudit for eventName: {}, InquiryId: {}, ConversationId: {}, {}"
					,data.getEventName(),data.getPayload().getInquiryId(),data.getPayload().getConversationId(), e);
		}
		return null;
	}
	
	public Object saveConsumedEventAudit(com.citi.icg.qma.common.messagebus.resolveinquiry.entity.Data data,Instant currentTime, String consumedStatus) {
		try {
			EventRecordAudit auditRecord = new EventRecordAudit();
			auditRecord.setEventType(data.getEventType());
			auditRecord.setConsumedData(data);
			auditRecord.setCrtDate(Date.from(currentTime));
			auditRecord.setStatus(consumedStatus);
			auditRecord.setEventCategory("CONSUME");
			auditRecord.setEventId(data.getEventId());
			Key<EventRecordAudit> key = mongoDatastore.save(auditRecord);
			return key.getId();
		} catch (Exception e) { 
			logger.warn("Exception in MessagePublisherDao.saveConsumedEventAudit for eventId: {}, event type, {}"
					,data.getEventId(),data.getEventType(), e);
		}
		return null;
	}

	public void updateEventAudit(Object key, String status, String description){
		try {
			Query<EventRecordAudit> findQuery=mongoDatastore.createQuery(EventRecordAudit.class).field("_id").equal((long) key);
			UpdateOperations<EventRecordAudit> operations = mongoDatastore.createUpdateOperations(EventRecordAudit.class)
					.set("modDate", new Date())
					.set("status", status)
					.set("eventDescription", description);
			updateWithRetry(mongoDatastore, findQuery, operations, false);
		}catch(Exception e) {
			logger.warn("Exception in MessagePublisherDao.updateEventAudit for EventRecordAudit key: {}, {}",key,e);
		}
	}
	
	public void updateReplayCount(Object key){
		try {
			Query<EventRecordAudit> findQuery=mongoDatastore.createQuery(EventRecordAudit.class).field("_id").equal((long) key);
			UpdateOperations<EventRecordAudit> operations = mongoDatastore.createUpdateOperations(EventRecordAudit.class)
					.set("modDate", new Date())
					.inc("replayCount");
			updateWithRetry(mongoDatastore, findQuery, operations, false);
		}catch(Exception e) {
			logger.warn("Exception in MessagePublisherDao.updateEventAudit for EventRecordAudit key: {}, {}",key,e);
		}
	}
}
