/**
 * 
 */
package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

/**
 * DBConnectionAudit entity to log connection details.
 * 
 *
 */
@Entity(value = "CyberArkConnectionActivityLog", noClassnameStored = true)
public class CyberArkConnectionActivityLog implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3103767830463816414L;
	@Id
	private String id;
	private String service;
	private ConnectionType type;
	private String connectingHost;
	private Date crtDate;
	
	public CyberArkConnectionActivityLog() {}
	
	public CyberArkConnectionActivityLog(String service,ConnectionType type, String connectingHost, Date crtDate) {
		this.service=service;
		this.type=type;
		this.connectingHost = connectingHost;
		this.crtDate=crtDate;
	}
	
	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}



	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public ConnectionType getType() {
		return type;
	}


	public void setType(ConnectionType type) {
		this.type = type;
	}


	public String getConnectingHost() {
		return connectingHost;
	}

	public void setConnectingHost(String connectingHost) {
		this.connectingHost = connectingHost;
	}

	public Date getCrtDate() {
		return crtDate;
	}


	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}


	public enum ConnectionType {
		CYBERARK, NON_CYBERARK
	}
}
