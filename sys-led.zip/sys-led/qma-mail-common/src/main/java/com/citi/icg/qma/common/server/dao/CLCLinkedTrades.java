/**
 * 
 */
package com.citi.icg.qma.common.server.dao;

import java.util.Date;
import java.util.List;

import dev.morphia.annotations.Entity;

/**
 * 
 *
 */
@Entity(value = "CLCLinkedTrades", noClassnameStored = true)
public class CLCLinkedTrades extends BaseEntity {
	private Long inquiryId;
	private List<CLCGroupData> groupData;
	

	/**
	 * @return the inquiryId
	 */
	public Long getInquiryId() {
		return inquiryId;
	}


	/**
	 * @param inquiryId the inquiryId to set
	 */
	public void setInquiryId(Long inquiryid) {
		this.inquiryId = inquiryid;
	}


	/**
	 * @return the groupData
	 */
	public List<CLCGroupData> getGroupData() {
		return groupData;
	}


	/**
	 * @param groupData the groupData to set
	 */
	public void setGroupData(List<CLCGroupData> groupData) {
		this.groupData = groupData;
	}


	public static class CLCGroupData {
		private Long groupId;
		private List<QMATradeRecord> tradeRefs;
		private String suggestedResponse;
		private String createdBy;
		private String modifiedBy;
		private Date crtDate;
		private Date modDate;
		/**
		 * @return the groupId
		 */
		public Long getGroupId() {
			return groupId;
		}
		/**
		 * @param groupId the groupId to set
		 */
		public void setGroupId(Long groupId) {
			this.groupId = groupId;
		}
		/**
		 * @return the tradeRefs
		 */
		public List<QMATradeRecord> getTradeRefs() {
			return tradeRefs;
		}
		/**
		 * @param tradeRefs the tradeRefs to set
		 */
		public void setTradeRefs(List<QMATradeRecord> tradeRefs) {
			this.tradeRefs = tradeRefs;
		}
		/**
		 * @return the suggestedResponse
		 */
		public String getSuggestedResponse() {
			return suggestedResponse;
		}
		/**
		 * @param suggestedResponse the suggestedResponse to set
		 */
		public void setSuggestedResponse(String suggestedResponse) {
			this.suggestedResponse = suggestedResponse;
		}
		/**
		 * @return the createdBy
		 */
		public String getCreatedBy() {
			return createdBy;
		}
		/**
		 * @param createdBy the createdBy to set
		 */
		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}
		/**
		 * @return the modifiedBy
		 */
		public String getModifiedBy() {
			return modifiedBy;
		}
		/**
		 * @param modifiedBy the modifiedBy to set
		 */
		public void setModifiedBy(String modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		/**
		 * @return the crtDate
		 */
		public Date getCrtDate() {
			return crtDate;
		}
		/**
		 * @param crtDate the crtDate to set
		 */
		public void setCrtDate(Date crtDate) {
			this.crtDate = crtDate;
		}
		/**
		 * @return the modDate
		 */
		public Date getModDate() {
			return modDate;
		}
		/**
		 * @param modDate the modDate to set
		 */
		public void setModDate(Date modDate) {
			this.modDate = modDate;
		}
	}
	
	public static class QMATradeRecord {
		private String tradeRef;
		private String client;
		private String security;
		private String cusip;
		/**
		 * @return the tradeRef
		 */
		public String getTradeRef() {
			return tradeRef;
		}
		/**
		 * @param tradeRef the tradeRef to set
		 */
		public void setTradeRef(String tradeRef) {
			this.tradeRef = tradeRef;
		}
		/**
		 * @return the client
		 */
		public String getClient() {
			return client;
		}
		/**
		 * @param client the client to set
		 */
		public void setClient(String client) {
			this.client = client;
		}
		/**
		 * @return the security
		 */
		public String getSecurity() {
			return security;
		}
		/**
		 * @param security the security to set
		 */
		public void setSecurity(String security) {
			this.security = security;
		}
		/**
		 * @return the cusip
		 */
		public String getCusip() {
			return cusip;
		}
		/**
		 * @param cusip the cusip to set
		 */
		public void setCusip(String cusip) {
			this.cusip = cusip;
		}
	}

}
