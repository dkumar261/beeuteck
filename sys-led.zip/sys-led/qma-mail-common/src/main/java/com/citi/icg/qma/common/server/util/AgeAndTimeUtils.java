package com.citi.icg.qma.common.server.util;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.QmaMailConstants;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.HolidayMaster;
import com.citi.icg.qma.common.server.dao.persistence.CacheDAO;
import com.citi.icg.qma.common.server.dao.persistence.InquiryDAO;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public final class AgeAndTimeUtils {
	
	private static final Logger logger = LoggerFactory.getLogger(AgeAndTimeUtils.class);
	private static final String STATUS_KEY = "status";
	private static final String END_DATE_KEY = "endDate";
	private static final String START_DATE_KEY = "startDate";
	private static final String REOPEN_DATE_KEY = "reOpenDate";
	private static final String STATUS_OPEN = "OPEN";
	private static final String STATUS_RESOLVED = "RESOLVED";
	private static final String MONGO_DATE_FORMAT = "EEE MMM dd HH:mm:ss z yyyy";
	private static final String SIMPLE_DATE_FORMAT = "d-M-yyyy";
	private static final int ONE_HOUR_MATRIX = 1000*60*60;
	private static final String AGE_IN_HRS_KEY = "ageInHrs";
	private static final String AGE_IN_DAYS_KEY = "ageInDays";
	private static final String REOPEN_AGE_IN_HRS_KEY = "reOpenAgeInHrs";
	private static final String REOPEN_AGE_IN_DAYS_KEY = "reOpenAgeInDays";
	private static final String RE_AGE_DATE_KEY = "reAgeDate";
	private static final String RE_OPEN_DATE_KEY = "reOpenDate";
	private static final String MOD_DATE_KEY = "modDate";
	private static final String CRT_DATE_KEY = "crtDate";
	private static final String RE_AGE_DATE_ZONED_KEY = "reAgeDateZoned";
	private static final String RE_OPEN_DATE_ZONED_KEY = "reOpenDateZoned";
	private static final String MOD_DATE_ZONED_KEY = "modDateZoned";
	private static final String CRT_DATE_ZONED_KEY = "crtDateZoned";
	private static final long ONE_DAY_MATRIX = 1000 * 60 * 60 * 24;
	private static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
	
	//private static CacheDAO cacheDAO = CacheDAO.getInstance();

	//C170665-118 time in queue
	private static final int HOUR=60;
	private static final int DAY=24*60;

	private AgeAndTimeUtils(){
		
	}
	
	/**
	 * This method calculates and updates inquiry and workflow object with new age calculation
	 * @param grpId
	 * @param inquiry
	 * @param workflow
	 * @param logger
	 */
	public static synchronized void updateDataForTimeBasedcalculation(Object grpId, BasicDBObject inquiry, BasicDBObject workflow) {
		try {
			long start = System.currentTimeMillis();
			Long id = inquiry.getLong("_id");
			if( grpId != null &&  workflow != null ) {
				Long groupId = (Long) grpId;
				GroupShiftConfig groupConfig = getGroupDetails(groupId);
				if( null != groupConfig && null!= groupConfig.getShiftEndTime() && null!= groupConfig.getShiftStartTime()) {
					String crtDateStr = workflow.getString(CRT_DATE_KEY);
					String modDateStr = workflow.getString(MOD_DATE_KEY);
					String reOpenDateStr = workflow.getString(RE_OPEN_DATE_KEY);
					String reAgeDateStr = workflow.getString(RE_AGE_DATE_KEY);
					String crtDateZoned =  converDateToGroupTimeZone(crtDateStr,groupConfig.getTimeZone());
					String modDateZoned = converDateToGroupTimeZone(modDateStr,groupConfig.getTimeZone());
					String reOpenDateZoned =  converDateToGroupTimeZone(reOpenDateStr,groupConfig.getTimeZone());
					String reAgeDateZoned = converDateToGroupTimeZone(reAgeDateStr,groupConfig.getTimeZone());
					workflow.put(CRT_DATE_ZONED_KEY, crtDateZoned);
					workflow.put(MOD_DATE_ZONED_KEY, modDateZoned);
					workflow.put(RE_OPEN_DATE_ZONED_KEY, reOpenDateZoned);
					workflow.put(RE_AGE_DATE_ZONED_KEY,reAgeDateZoned);
					String ageInHrs = calculateAge(workflow,groupConfig);
					String reOpenAgeInHrs = calculateReOpenAge(workflow,groupConfig);
					inquiry.put(AGE_IN_HRS_KEY, ageInHrs);
					inquiry.put(REOPEN_AGE_IN_HRS_KEY, reOpenAgeInHrs);
				}
			}
			logger.info(" {} | {} | {} | {} | {} | {} | {}"
					,id,grpId,(null == workflow ? workflow :workflow.get(AGE_IN_HRS_KEY))
					,(null == workflow ? workflow : workflow.get(AGE_IN_DAYS_KEY))
					,(null == workflow ? workflow : workflow.get(REOPEN_AGE_IN_HRS_KEY))
					,(null == workflow ? workflow : workflow.get(REOPEN_AGE_IN_DAYS_KEY))
					, (System.currentTimeMillis()-start));
			
		} catch (Exception e) {
			logger.warn("Error in AgeAndTimeUtils#updateDataForTimeBasedcalculation() :", e);
		}
	}

	/**
	 * This method calculates and sets age of an inquiry in days and hours
	 * @param workflow
	 * @param groupConfig
	 * @param logger
	 * @return String
	 */
	private static String calculateAge(BasicDBObject workflow, GroupShiftConfig groupConfig) {
		String ageInHrs = "";
		try {
			Date startDate = getDateForCalculation(workflow, START_DATE_KEY, groupConfig.getTimeZone());
			Date endDate = getDateForCalculation(workflow, END_DATE_KEY, groupConfig.getTimeZone());
			if( startDate !=null && endDate!=null ) {
				startDate = updateDateBasedOnHolidayConfig(startDate, endDate, groupConfig);
				endDate = updateEndDateBasedOnEndTime(groupConfig,endDate);
				float[] timeDiff =  findDateDifferenceInNoOfHoursAndDays(startDate, endDate, groupConfig);
				int timeDiffInHrs =(int) timeDiff[0];
				int timeDiffInDays =(int) timeDiff[1];
				ageInHrs = String.valueOf(timeDiffInHrs);
				workflow.put(AGE_IN_HRS_KEY, ageInHrs);
				workflow.put(AGE_IN_DAYS_KEY, timeDiffInDays);
			}
		} catch (Exception e) {
			logger.warn("Exception in AgeAndTimeUtils#calculateAgeInHrs() for inquiry({}): ",(null == workflow ? workflow : workflow.getString("_id")), e);
		}
		return ageInHrs;
	}
	
	
	
	/**
	 * This method calculates and sets re-open age of an inquiry in days and hours
	 * @param workflow
	 * @param groupConfig
	 * @param logger
	 * @return String
	 */
	private static String calculateReOpenAge(BasicDBObject workflow, GroupShiftConfig groupConfig) {
		String reOpenAgeInHrs = "";
		try {
			Date startDate = getDateForCalculation(workflow, REOPEN_DATE_KEY, groupConfig.getTimeZone());
			Date endDate = getDateForCalculation(workflow, END_DATE_KEY, groupConfig.getTimeZone());
			if( startDate !=null && endDate!=null ) {
				startDate = updateDateBasedOnHolidayConfig(startDate, endDate, groupConfig);
				endDate = updateEndDateBasedOnEndTime(groupConfig,endDate);
				float[] timeDiff =  findDateDifferenceInNoOfHoursAndDays(startDate, endDate, groupConfig);
				int timeDiffInHrs =(int) timeDiff[0];
				int timeDiffInDays =(int) timeDiff[1];
				reOpenAgeInHrs = String.valueOf(timeDiffInHrs);
				workflow.put(REOPEN_AGE_IN_HRS_KEY, reOpenAgeInHrs);
				workflow.put(REOPEN_AGE_IN_DAYS_KEY, timeDiffInDays);
			}
		} catch (Exception e) {
			logger.warn("Exception in  calculateReOpenAgeInHrs for inquiry({}): ",(null == workflow ? workflow : workflow.getString("_id")), e);
		}
		return reOpenAgeInHrs;
	}

	/**
	 * This method calculates age in no of days for charts and graphs considering shift and holidays of a group
	 * @param createdDate
	 * @param currentDate
	 * @param groupConfig
	 * @param logger
	 * @return double
	 */
	public static double calculateAgeForChartAndGraphs(Date createdDate, Date currentDate, GroupShiftConfig groupConfig) {
		double ageInDays = 0;
		try {
			DateFormat df  = new SimpleDateFormat(MONGO_DATE_FORMAT);
			Date startDate = getDateInGroupTimeZone(groupConfig.getTimeZone(), df.format(createdDate));
			Date endDate = getDateInGroupTimeZone(groupConfig.getTimeZone(), df.format(currentDate));
			if( startDate !=null && endDate!=null ) {
				startDate = updateDateBasedOnHolidayConfig(startDate, endDate, groupConfig);
				endDate = updateEndDateBasedOnEndTime(groupConfig,endDate);
				float[] timeDiff =  findDateDifferenceInNoOfHoursAndDays(startDate, endDate, groupConfig);
				ageInDays = timeDiff[1];
			}
		} catch (Exception e) {
			logger.warn("Exception in AgeAndTimeUtils#calculateAgeForChartAndGraphs() : ",e);
		}
		return ageInDays;
	}
	
	
	/**
	 * This method updates the date to provided group end time
	 * @param groupConfig
	 * @param date
	 * @return Date
	 */
	private static Date updateEndDateBasedOnEndTime(GroupShiftConfig groupConfig, Date date) {
		Date finalDate = date;
		Calendar endDate = new GregorianCalendar();
		endDate.setTime(date);
		Calendar todayShiftEnd = Calendar.getInstance();
		String[] shiftStartAndEnd = groupConfig.getShiftEndTime().split(":");
		int hour = Integer.parseInt(shiftStartAndEnd[0]);
		int mins = Integer.parseInt(shiftStartAndEnd[1]);
		todayShiftEnd.set(Calendar.HOUR_OF_DAY, hour);
		todayShiftEnd.set(Calendar.MINUTE, mins);
		if(endDate.get(Calendar.HOUR_OF_DAY) < todayShiftEnd.get(Calendar.HOUR_OF_DAY)) {
			finalDate = endDate.getTime();
		}
		return finalDate;
	}

	/**
	 * This method finds date difference in no of hours and days considering time shift of a group
	 * This calculation happens for each day within inquiry life cycle
	 * @param startDate
	 * @param endDate
	 * @param groupConfig
	 * @param logger
	 * @return float[]
	 */
	private static float[] findDateDifferenceInNoOfHoursAndDays(Date startDate, Date endDate, GroupShiftConfig groupConfig) {
		float[] timeDifference={0,0};
		if(startDate!=null && endDate!=null && groupConfig !=null){
			//Get start time based on group's shift start time
			Date shiftStartDate = getShiftTimedDate(groupConfig.getShiftStartTime(),startDate);
			//Get end time based on group's shift end time
			Date shiftEndDate = getShiftTimedDate(groupConfig.getShiftEndTime(),endDate);
			shiftEndDate = updateShiftEndDate(shiftEndDate, endDate);
			long differenceInHours = 0;
			long differenceInDays = 0;
			Date currentTime = new Date();
			try {
				DateFormat df  = new SimpleDateFormat(MONGO_DATE_FORMAT);
				//Get current time in the group's timezone
				currentTime = getDateInGroupTimeZone(groupConfig.getTimeZone(), df.format(currentTime));
			} catch (ParseException e) {
				logger.warn("Exception while parsing current date");
			}
			while(shiftStartDate.getTime() <= shiftEndDate.getTime()) {
				//get shift start date based on holiday and shift schedule
				shiftStartDate = updateDateBasedOnHolidayConfig(shiftStartDate, shiftEndDate, groupConfig);
				//This is used when inquiry created on the evaluation day
				if(startDate.getTime() > shiftStartDate.getTime() && differenceInHours == 0) {
					shiftStartDate = updateShiftStartDateForFirstDay(startDate, shiftStartDate);
				}
				//This is used when evaluation happened before shift start time and it's on the first day of inquiry
				if(startDate.getTime() < shiftStartDate.getTime() && currentTime.getTime() < shiftStartDate.getTime()){
					break;
				}
				
				//Do the above processing for end date
				Date sameDayShiftEnd = getShiftTimedDate(groupConfig.getShiftEndTime(),shiftStartDate);
				if(sameDayShiftEnd.getTime() > endDate.getTime()){
					differenceInDays--;
				}
				sameDayShiftEnd = updateShiftEndDate(sameDayShiftEnd, endDate);
				
				differenceInHours += (sameDayShiftEnd.getTime() - shiftStartDate.getTime());
				// Update shift start date to next day and proceed with calculations
				shiftStartDate = updateDateToNextDay(groupConfig, shiftStartDate);
				differenceInDays++;
				if(shiftStartDate.getTime() > currentTime.getTime() || shiftStartDate.getTime() > endDate.getTime()){
					break;
				}
			}
			if(differenceInHours > 0){
				timeDifference[0] = (float)differenceInHours/ONE_HOUR_MATRIX;
				timeDifference[1] = differenceInDays;
			}
		}
		return timeDifference;
	}

	/**
	 * This method updates shift end time to actual end date.
	 * @param shiftEndDate
	 * @param actualEndDate
	 * @return Date
	 */
	private static Date updateShiftEndDate(Date shiftEndDate, Date actualEndDate) {
		Date localShiftEndDate = shiftEndDate;
		Calendar todayEndDate = new GregorianCalendar();
		todayEndDate.setTime(localShiftEndDate);
		if(actualEndDate.getTime() < todayEndDate.getTimeInMillis()){
			localShiftEndDate = actualEndDate;
		}
		return localShiftEndDate;
	}

	/**
	 * This method updates start date to next day
	 * @param groupConfig
	 * @param date
	 * @return
	 */
	private static Date updateDateToNextDay(GroupShiftConfig groupConfig, Date date) {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		String[] shift = groupConfig.getShiftStartTime().split(":");
		int hour = Integer.parseInt(shift[0]);
		int mins = Integer.parseInt(shift[1]); 
		calendar.set(Calendar.DAY_OF_MONTH, day+1);
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, mins);
		return calendar.getTime();
	}

	/**
	 * This method sets shift start date for first day calculation
	 * @param startDate
	 * @param shiftStartDate
	 * @return Date
	 */
	private static Date updateShiftStartDateForFirstDay(Date startDate, Date shiftStartDate) {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(startDate);
		int hour = calendar.get(Calendar.HOUR_OF_DAY);
		int min = calendar.get(Calendar.MINUTE);
		
		Calendar calendar1 = new GregorianCalendar();
		calendar1.setTime(shiftStartDate);
		calendar1.set(Calendar.HOUR_OF_DAY, hour);
		calendar1.set(Calendar.MINUTE, min);
		return calendar1.getTime();
	}

	/**
	 * This method updates shift start for calculation based on holidays and weekly off
	 * @param startDate
	 * @param endDate
	 * @param groupConfig
	 * @param logger
	 * @return Date
	 */
	private static Date updateDateBasedOnHolidayConfig(Date startDate, Date endDate, GroupShiftConfig groupConfig) {
		Date localStartDate = startDate;
		Date dlEndTime  = getShiftTimedDate(groupConfig.getShiftEndTime(), localStartDate);
		if(localStartDate.getTime() > dlEndTime.getTime()) {
			localStartDate = updateDateToNextDayShiftStartTime(localStartDate,groupConfig.getShiftStartTime());
		}
		while(localStartDate.getTime() < endDate.getTime()) { 
			if(isDateFallsOnHolidaysOrWeeklyOff(localStartDate, groupConfig)){
				localStartDate = updateDateToNextDayShiftStartTime(localStartDate,groupConfig.getShiftStartTime());
			} else {
				break;
			}
		}
		return localStartDate;
	}
	
	/**
	 * This function updates date to next day shift start time
	 * @param startDate
	 * @param shift
	 * @return Date
	 */
	private static Date updateDateToNextDayShiftStartTime(Date startDate, String shift) {
		Date d = new Date(startDate.getTime());
		String[] shiftStartAndEnd = shift.split(":");
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(d);
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int day = calendar.get(Calendar.DAY_OF_MONTH) + 1;
		int hour = Integer.parseInt(shiftStartAndEnd[0]);
		int mins = Integer.parseInt(shiftStartAndEnd[1]);
		Calendar calendar1 = new GregorianCalendar(year, month, day, hour, mins, 0);
		return calendar1.getTime();
	}

	/**
	 * This method checks whether provided date falls on holiday of non working day
	 * @param date
	 * @param groupConfig
	 * @param logger
	 * @return boolean
	 */
	private static boolean isDateFallsOnHolidaysOrWeeklyOff(Date date, GroupShiftConfig groupConfig) {
		return dateFallsOnHoliday(date,groupConfig) || dateFallsOnWeeklyOff(date,groupConfig);
	}

	/**
	 * This method checks whether date falls on weekly off or not
	 * @param date
	 * @param groupConfig
	 * @param logger
	 * @return boolean
	 */
	private static boolean dateFallsOnWeeklyOff(Date date, GroupShiftConfig groupConfig) {
		boolean dateOnWeeklyOff = false;
		SimpleDateFormat sdf = new SimpleDateFormat(MONGO_DATE_FORMAT, Locale.ENGLISH);
		String inputDateStr = sdf.format(date);
		String dateStr = converDateToGroupTimeZone(inputDateStr,groupConfig.getTimeZone());
		String dayOfAWeek = dateStr.substring(0,dateStr.indexOf(' '));
		dayOfAWeek = getDayOfAWeek(dayOfAWeek.toLowerCase());
		if(null!= groupConfig.getWeeklyOffs() && null!= dayOfAWeek&&  groupConfig.getWeeklyOffs().contains(dayOfAWeek)){
			dateOnWeeklyOff = true;
		}
		return dateOnWeeklyOff;
	}
	
	
	/**
	 * This method checks whether date falls on holiday or not
	 * @param date
	 * @param groupConfig
	 * @param logger
	 * @return boolean
	 */
	private static boolean dateFallsOnHoliday(Date date, GroupShiftConfig groupConfig) {
		boolean dateOnHoliday = false;
		if(null != groupConfig.getHolidays()) {
			SimpleDateFormat sdf = new SimpleDateFormat(SIMPLE_DATE_FORMAT, Locale.ENGLISH);
			String formattedDateString = sdf.format(date);
			if(groupConfig.getHolidays().contains(formattedDateString)) {
				dateOnHoliday = true;
			}
		}
		return dateOnHoliday;
	}

	/**
	 * This method provide day of a week as string
	 * @param dayOfAWeek
	 * @return String
	 */
	private static String getDayOfAWeek(String dayOfAWeek) {
		String day = null;
		if(null!= dayOfAWeek){
			switch (dayOfAWeek) {
				case "sun": day="0"; 
				break;
				case "mon": day="1"; 
				break;
				case "tue": day="2";
				break;
				case "wed": day="3"; 
				break;
				case "thu": day="4"; 
				break;
				case "fri": day="5"; 
				break;
				case "sat": day="6"; 
				break;
				default: break;
			}
		}
		return day;
	}

	/**
	 * This method provides date for shift end time-- same day with time set to shift end time
	 * @param shift
	 * @param date
	 * @return Date
	 */
	private static Date getShiftTimedDate(String shift, Date date) {
		Date d = new Date(date.getTime());
		String[] shiftStartAndEnd = shift.split(":");
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(d);
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int hour = Integer.parseInt(shiftStartAndEnd[0]);
		int mins = Integer.parseInt(shiftStartAndEnd[1]);
		Calendar calendar1 = new GregorianCalendar(year, month, day, hour, mins, 0);
		return  calendar1.getTime();
	}

	
	/**
	 *  This method identifies dates for age or reopen age calculations
	 * @param workflow
	 * @param type
	 * @param groupTimeZone
	 * @param logger
	 * @return Date
	 */
	private static Date getDateForCalculation(BasicDBObject workflow, String type, String groupTimeZone) {
		Date date = null;
		try {
			String inquiryStatus =  getInquiryStatus(workflow);
			String dateStr = "";
			if(inquiryStatus!=null && START_DATE_KEY.equalsIgnoreCase(type) ){
				dateStr = getStartDateForCalculation(workflow);
			} else if(inquiryStatus!=null && REOPEN_DATE_KEY.equalsIgnoreCase(type) ){
				dateStr = getReOpenDateForCalculation(workflow);
			} else if(inquiryStatus!=null && END_DATE_KEY.equalsIgnoreCase(type) ){
				dateStr = getEndDateForCalculation(workflow, groupTimeZone, inquiryStatus);
			}
			if(dateStr!=null) {
				date = getDateInGroupTimeZone(groupTimeZone, dateStr);
			}
		} catch (ParseException e) {
			logger.warn("Exception :", e);
		}
		return date;
	}

	/**
	 * This method returns a date in provided timezone 
	 * @param groupTimeZone
	 * @param dateStr
	 * @return Date
	 * @throws ParseException
	 */
	private static Date getDateInGroupTimeZone(String groupTimeZone, String dateStr) throws ParseException {
	    
		Date d = null;
		Date temp = null;
		if(groupTimeZone!=null && StringUtils.isNotEmpty(dateStr)) {
		    try {
			SimpleDateFormat sdf = new SimpleDateFormat(MONGO_DATE_FORMAT, Locale.ENGLISH);
			sdf.setTimeZone(TimeZone.getTimeZone(ZoneId.of(groupTimeZone)));
			temp = sdf.parse(dateStr);
		    } 
		    catch (Exception e) { 
			logger.info("{} recieved is not in {} format. Retrying with {} format", dateStr, MONGO_DATE_FORMAT, DATE_TIME_FORMAT );
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_TIME_FORMAT, Locale.ENGLISH);
			sdf.setTimeZone(TimeZone.getTimeZone(ZoneId.of(groupTimeZone)));
			temp = sdf.parse(dateStr);
		    }
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-M-yyyy-HH-mm-ss-EEE-z", Locale.ENGLISH);
			sdf1.setTimeZone(TimeZone.getTimeZone(ZoneId.of(groupTimeZone)));
			String formattedDateString = sdf1.format(temp);
			String[] strings = formattedDateString.split("-");
			Calendar cal = new GregorianCalendar(Integer.parseInt(strings[2]), Integer.parseInt(strings[1])-1, Integer.parseInt(strings[0]), Integer.parseInt(strings[3]),
					Integer.parseInt(strings[4]), Integer.parseInt(strings[5]));
			d = cal.getTime();
		}
		return d;
	}

	/**
	 * This method provides end date for calculation of age 
	 * @param workflow
	 * @param groupTimeZone
	 * @param logger
	 * @param inquiryStatus
	 * @return String
	 */
	static String getEndDateForCalculation(BasicDBObject workflow, String groupTimeZone,
			String inquiryStatus) {
		String dateStr = "";
		if(STATUS_RESOLVED.equalsIgnoreCase(inquiryStatus)) {
			if(null != workflow && null!=workflow.getString(MOD_DATE_KEY)) { //sonar fix null pointer
				dateStr = workflow.getString(MOD_DATE_KEY);
			}
		} else if(STATUS_OPEN.equalsIgnoreCase(inquiryStatus)) {
			dateStr = new Date().toString();
		}
		return dateStr;
	}

	/**
	 * This method provides a start date for age calculation
	 * @param workflow
	 * @return String
	 */
	static String getStartDateForCalculation(BasicDBObject workflow) {
		String dateStr = "";
		if(null != workflow && null!=workflow.getString(CRT_DATE_KEY)) { //sonar fix null pointer
		  
			dateStr = workflow.getString(CRT_DATE_KEY);
		}
		if(null != workflow &&  null!=workflow.getString(RE_AGE_DATE_KEY)) { //sonar fix null pointer
			dateStr = workflow.getString(RE_AGE_DATE_KEY);
		}
		return dateStr;
	}
	
	/**
	 * This method provide re open date for calculation
	 * @param workflow
	 * @return String
	 */
	static String getReOpenDateForCalculation(BasicDBObject workflow) {
		String dateStr = "";
		if(null != workflow && null!=workflow.getString(RE_OPEN_DATE_KEY)) {//sonar fix null pointer
			dateStr = workflow.getString(RE_OPEN_DATE_KEY);
		}
		return dateStr;
	}

	/**
	 * This method provides inquiry status
	 * @param workflow
	 * @return String
	 */
	private static String getInquiryStatus(BasicDBObject workflow) {
		String status = "";
		if(null != workflow && null!= workflow.getString(STATUS_KEY) ) {
			status = workflow.getString(STATUS_KEY);
		}
		return status;
	}

	/**
	 * This method provides group configurations for age calculation
	 * @param groupId
	 * @return
	 */
	public static GroupShiftConfig getGroupDetails(Object groupId) {
		GroupShiftConfig groupConfig = new GroupShiftConfig();
		if( groupId != null ) {
			Map<Long, Group> groups = QMACacheFactory.getCache().getAllGroupsMap();
			if(groups.containsKey(groupId)) {
				Group group = groups.get(groupId);
				getGroupShiftConfig(groupConfig, group);
				getGroupHolidays(groupConfig, group);
			}
		}
		return groupConfig;
	}

	/**
	 * This method provides group level holidays
	 * @param groupConfig
	 * @param group
	 * @param logger
	 */
	private static void getGroupHolidays(GroupShiftConfig groupConfig, Group group) {
		try {
			if( groupConfig != null && group != null && group.getCountry()!=null){
				String groupCountryCode = group.getCountry();
				List<HolidayMaster> groupHolidays = getHolidayMasterForCountryCode(groupCountryCode);
				getGroupHolidays(groupConfig, groupHolidays);
			}
		} catch (ParseException e) {
			logger.warn("Exception : ",e);
		}
	}
	
	public static List<HolidayMaster> getHolidayMasterForCountryCode( String countrCode) {
		List<HolidayMaster> holidays = null;
		if(QMACacheFactory.getCache().getHolidayMasterMap()!=null && StringUtils.isNotBlank(countrCode)){
			holidays = QMACacheFactory.getCache().getHolidayMasterMap().get(countrCode);
		}
		return holidays;
	}

	/**
	 * This method provides group level holidays
	 * @param groupConfig
	 * @param logger
	 * @param groupHolidays
	 * @throws ParseException
	 */
	private static void getGroupHolidays(GroupShiftConfig groupConfig, List<HolidayMaster> groupHolidays)
			throws ParseException {
		if(groupHolidays != null && !groupHolidays.isEmpty()) {
			List<String> grpHolidayList = new ArrayList<>();
			for(HolidayMaster holiday : groupHolidays){
				Date holidayDate = holiday.getHolidayDate();
				Calendar cal = Calendar.getInstance();
				cal.setTimeZone(TimeZone.getTimeZone("GMT"));
				cal.setTime(holidayDate);
				String formattedDateString = cal.get(Calendar.DAY_OF_MONTH) + "-"  + (cal.get(Calendar.MONTH)+1)  + "-" + cal.get(Calendar.YEAR);
				grpHolidayList.add(formattedDateString);
			}
			groupConfig.setHolidays(grpHolidayList);
		}
	}

	/**
	 * This method provides group shift configurations
	 * @param groupConfig
	 * @param group
	 */
	private static void getGroupShiftConfig(GroupShiftConfig groupConfig, Group group) {
		if (null != group.getHolidayAndShiftDetails()
				&& group.getHolidayAndShiftDetails().isHolidayBasedAgeCalculation()) {
			String timeZoneCode = group.getTimeZone();
			List<com.citi.icg.qma.common.server.dao.TimeZone> timeZones = QMACacheFactory.getCache().getTimeZonesConfig();
			for (com.citi.icg.qma.common.server.dao.TimeZone ctz : timeZones) {
				if (ctz.getTimeZoneCode().equalsIgnoreCase(timeZoneCode)) {
					groupConfig.setTimeZone(ctz.getTimeZone());
					groupConfig.setShiftStartTime(group.getHolidayAndShiftDetails().getShiftStartTime());
					groupConfig.setShiftEndTime(group.getHolidayAndShiftDetails().getShiftEndTime());
					groupConfig.setWeeklyOffs(group.getHolidayAndShiftDetails().getWeeklyOffDays());
					groupConfig.setHolidayBasedCalculation(group.getHolidayAndShiftDetails().isHolidayBasedAgeCalculation());
					break;
				}
			}
		}
	}
	
	/**
	 * This method converts given date to group timezone
	 * @param inputDate
	 * @param groupTimeZone
	 * @return
	 */
	private static String converDateToGroupTimeZone(String inputDate, String groupTimeZone) {
		String result = null;
		try {
			if( null != inputDate && null != groupTimeZone){
				String targetDateFormat = MONGO_DATE_FORMAT;
				SimpleDateFormat sdf = new SimpleDateFormat(MONGO_DATE_FORMAT, Locale.ENGLISH);
				SimpleDateFormat sdfTarget = new SimpleDateFormat(targetDateFormat);
				Date d = sdf.parse(inputDate);
				LocalDateTime ldt = LocalDateTime.parse(sdfTarget.format(d), DateTimeFormatter.ofPattern(targetDateFormat));
				String serverTimeZone = TimeZone.getDefault().getID();
				ZoneId serverZoneId = ZoneId.of(serverTimeZone);
				ZonedDateTime serverTime = ldt.atZone(serverZoneId);
				ZoneId groupZoneId = ZoneId.of(groupTimeZone);
				ZonedDateTime serverTimeInGrpZone = serverTime.withZoneSameInstant(groupZoneId);
				DateTimeFormatter format = DateTimeFormatter.ofPattern(targetDateFormat);
				result =  format.format(serverTimeInGrpZone);
			}
		} catch (Exception e) {
			logger.warn("Error in AgeAndTimeUtils#converDateToGroupTimeZone() : ",e);
		}
		return result;
	}
	
	/**
	 * Group configuration class used in age calculation
	 * 
	 *
	 */
	public static class GroupShiftConfig implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = -2100924638578327494L;
		private String timeZone;
		private String shiftStartTime;
		private String shiftEndTime;
		private List<String> weeklyOffs;
		private List<String> holidays;
		private int shiftHoursInMins;
		private boolean isHolidayBasedCalculation;
		
		public String getTimeZone() {
			return timeZone;
		}
		public void setTimeZone(String timeZone) {
			this.timeZone = timeZone;
		}
		public String getShiftStartTime() {
			return shiftStartTime;
		}
		public void setShiftStartTime(String shiftStartTime) {
			this.shiftStartTime = shiftStartTime;
		}
		public String getShiftEndTime() {
			return shiftEndTime;
		}
		public void setShiftEndTime(String shiftEndTime) {
			this.shiftEndTime = shiftEndTime;
		}
		public List<String> getWeeklyOffs() {
			return weeklyOffs;
		}
		public void setWeeklyOffs(List<String> weeklyOffs) {
			this.weeklyOffs = weeklyOffs;
		}
		public List<String> getHolidays() {
			return holidays;
		}
		public void setHolidays(List<String> holidays) {
			this.holidays = holidays;
		}
		public int getShiftHoursInMins() {
			return shiftHoursInMins;
		}
		public void setShiftHoursInMins(int shiftHoursInMins) {
			this.shiftHoursInMins = shiftHoursInMins;
		}
		public boolean isHolidayBasedCalculation() {
			return isHolidayBasedCalculation;
		}
		public void setHolidayBasedCalculation(boolean isHolidayBasedCalculation) {
			this.isHolidayBasedCalculation = isHolidayBasedCalculation;
		}
	}
	
	
	/**
	 * This function calculates and sets inquiry age and re-open age in workflow object
	 * @param grpId
	 * @param workflow
	 * @param logger
	 */
	public static void updateAgeData(Object grpId, BasicDBObject workflow) {
		try {
			Long groupId = (Long) grpId;
			if( grpId != null &&  workflow != null && null != QMACacheFactory.getCache().getGroupAgeConfigMap()
					&& QMACacheFactory.getCache().getGroupAgeConfigMap().containsKey(grpId) ) {
				GroupShiftConfig groupConfig = QMACacheFactory.getCache().getGroupAgeConfigMap().get(groupId);
				if( null != groupConfig && null!= groupConfig.getShiftEndTime() && null!= groupConfig.getShiftStartTime()) {
					calculateAndSetAge(workflow,groupConfig);
					calculateAndSetReOpenAge(workflow,groupConfig);
				}
			}
		} catch (Exception e) {
			logger.warn("Error in AgeAndTimeUtils#updateAgeData() :", e);
		}
	}
	
	/**
	 * This function calculates and sets inquiry age in workflow object
	 * @param workflow
	 * @param groupConfig
	 * @param logger
	 */
	private static void calculateAndSetAge(BasicDBObject workflow, GroupShiftConfig groupConfig) {
		try {
			Date startDate = getDateForCalculation(workflow, START_DATE_KEY, groupConfig.getTimeZone());
			Date endDate = getDateForCalculation(workflow, END_DATE_KEY, groupConfig.getTimeZone());
			if( startDate !=null && endDate!=null ) {
				int[] timeDiff =  findAgeDiff(startDate, endDate, groupConfig);
				int timeDiffInHrs = timeDiff[0];
				int timeDiffInDays = timeDiff[1];
				workflow.put(AGE_IN_HRS_KEY, timeDiffInHrs);
				workflow.put(AGE_IN_DAYS_KEY, timeDiffInDays);
			}
		} catch (Exception e) {
			logger.warn("Exception in AgeAndTimeUtils#calculateAndSetAge() for inquiry({}): ",(null == workflow ? workflow : workflow.getString("_id")),e);
		}
	}
	
	/**
	 * This method will calculate and provide age of open inquiries for provided workflow
	 * @param workflow
	 * @param groupConfig
	 * @param logger
	 * @return int
	 */
	public static int getOpenInquiryAge(BasicDBObject workflow, GroupShiftConfig groupConfig) {
		int ageDiffInDays = 0;
		try {
			calculateAndSetAge(workflow, groupConfig);
			ageDiffInDays = workflow.getInt(AGE_IN_DAYS_KEY);
		} catch (Exception e) {
			logger.warn("Exception in AgeAndTimeUtils#getOpenInquiryAge() : ",e);
		}
		return ageDiffInDays;
	}
	
	
	/**
	 * This function calculates and sets inquiry re-open age in workflow object
	 * @param workflow
	 * @param groupConfig
	 * @param logger
	 */
	private static void calculateAndSetReOpenAge(BasicDBObject workflow, GroupShiftConfig groupConfig) {
		try {
			Date startDate = getDateForCalculation(workflow, REOPEN_DATE_KEY, groupConfig.getTimeZone());
			Date endDate = getDateForCalculation(workflow, END_DATE_KEY, groupConfig.getTimeZone());
			if( startDate !=null && endDate!=null ) {
				int[] timeDiff =  findAgeDiff(startDate, endDate, groupConfig);
				int timeDiffInHrs = timeDiff[0];
				int timeDiffInDays = timeDiff[1];
				workflow.put(REOPEN_AGE_IN_HRS_KEY, timeDiffInHrs);
				workflow.put(REOPEN_AGE_IN_DAYS_KEY, timeDiffInDays);
			}
		} catch (Exception e) {
			logger.warn("Exception in AgeAndTimeUtils#calculateAndSetReOpenAge for inquiry({}): ",(null == workflow ? workflow : workflow.getString("_id")),e);
		}
	}
	
	private static int[] findAgeDiff(Date startDate, Date endDate, GroupShiftConfig groupConfig){
		int[] output = { 0 , 0 };
		try {
			long daysExceptFirstAndLast = 0;
			int[] startDayHours = {0,0};
			int[] endDayHours = {0,0};
			int[] weeklyOffAndHolidays = {0,0};
			//Check if inquiry is started and ended on same day
			if(!DateUtils.isSameDay(startDate, endDate)) {
				int dateDiff = getDateDifference(startDate, endDate);
				dateDiff++; // incremented as above function excludes boundary values for difference
				Calendar dayNextToStartDate;
				Calendar dayPreviousToEndDate;
				// If the date difference > 3 ,then calculate date difference between two date range (excluding boundaries)
				// and calculate start and end date hours separately
				if(dateDiff > 3) {
					// get date next to the start date.
					dayNextToStartDate = updateDateToNextOrPreviousDay(startDate,1);
					// get date previous to the end date
					dayPreviousToEndDate = updateDateToNextOrPreviousDay(endDate,-1);
					// get date difference
					double dateDiffInMilli = dayPreviousToEndDate.getTimeInMillis() - dayNextToStartDate.getTimeInMillis();
					//convert above difference into no of days
					daysExceptFirstAndLast = (long) Math.ceil(dateDiffInMilli/(1000*60*60*24)); 
					// User Math.ceil above in case if the timezone is US and there is day light saving enable. No of hours of day gets reduced
					
					daysExceptFirstAndLast = daysExceptFirstAndLast + 1; // incremented as difference above excludes boundary dates
					//calculate weekly offs and holidays between above date range
					weeklyOffAndHolidays = getHolidayAndWeeklyOff(groupConfig, dayNextToStartDate, dayPreviousToEndDate);
					//calculate hours and day for the start date
					startDayHours = getDayHours(startDate, null, groupConfig, false);
					//calculate hours and day for the end date 
					endDayHours = getDayHours(endDate, endDate, groupConfig, false);
					
				} else if(dateDiff == 3 ) {
					//get start day hours and days
					startDayHours = getDayHours(startDate, null, groupConfig, false);
					// get mid day hours and days
					int[] midDayHrs = getMidDayHours(startDate, groupConfig);
					// add mid day hours and days to start day
					startDayHours[0] = startDayHours[0] + midDayHrs[0];
					startDayHours[1] = startDayHours[1] + midDayHrs[1];
					//get end day hours and days
					endDayHours = getDayHours(endDate, endDate, groupConfig, false);
					
				} else if(dateDiff == 2 ) {
					//get start day hours and days
					startDayHours = getDayHours(startDate, null, groupConfig, false);
					//get end day hours and days
					endDayHours = getDayHours(endDate, endDate, groupConfig, false);
				}
				
			} else {
				//get hours and days of same day inquiry
				startDayHours = getDayHours(startDate, endDate, groupConfig, true);
			}
			
			//get group shift time in minutes
			int minsOfADay = groupConfig.getShiftHoursInMins();
			
			//get no of days except first and last day and substract no of holidays and weekly off
			daysExceptFirstAndLast = daysExceptFirstAndLast - weeklyOffAndHolidays[0] - weeklyOffAndHolidays[1];
			
			//calculate no of hours above days
			int finalHrs = (int) ((daysExceptFirstAndLast * minsOfADay)/60);
			// 0th index will have total no of hours
			output[0] = finalHrs + startDayHours[0] + endDayHours[0];
			//1st index will have total no of days
			output[1] = (int)daysExceptFirstAndLast + startDayHours[1] + endDayHours[1];
			
		} catch (Exception e) {
			logger.warn("Exception while calculating age in AgeAndTimeUtils#findAgeDiff:", e );
		}
		
		return output;
	}
	
	/**
	 * This function calculates inquiry age
	 * @param startDate
	 * @param endDate
	 * @param groupConfig
	 * @param logger
	 * @return int[]
	 */
	private static int[] findDateDiffForTimeToVD(Date startDate, Date endDate, GroupShiftConfig groupConfig){
		int[] output = { 0 , 0 };
		try {
			long daysExceptFirstAndLast = 0;
			int[] startDayHours = {0,0};
			int[] endDayHours = {0,0};
			int[] weeklyOffAndHolidays = {0,0};
			//Check if inquiry is started and ended on same day
			if(!DateUtils.isSameDay(startDate, endDate)) {
				Calendar dayNextToStartDate;
				Calendar dayPreviousToEndDate;

				int dateDiff = getDateDifference(startDate, endDate);
				if(dateDiff < 0) {
					// get date next to the start date.
					dayNextToStartDate = updateDateToNextOrPreviousDay(startDate,0);
					// get date previous to the end date
					dayPreviousToEndDate = updateDateToNextOrPreviousDay(endDate,0);
					// get date difference
					double dateDiffInMilli = dayPreviousToEndDate.getTimeInMillis() - dayNextToStartDate.getTimeInMillis();
					//convert above difference into no of days
					daysExceptFirstAndLast = (long) Math.ceil(dateDiffInMilli/(1000*60*60*24)); 
					// User Math.ceil above in case if the timezone is US and there is day light saving enable. No of hours of day gets reduced
					
					//calculate weekly offs and holidays between above date range
					weeklyOffAndHolidays = getHolidayAndWeeklyOffForFutureDate(groupConfig, dayNextToStartDate, dayPreviousToEndDate);
					
				}
				dateDiff++; // incremented as above function excludes boundary values for difference
								// If the date difference > 3 ,then calculate date difference between two date range (excluding boundaries)
				// and calculate start and end date hours separately
				if(dateDiff > 3) {
					// get date next to the start date.
					dayNextToStartDate = updateDateToNextOrPreviousDay(startDate,1);
					// get date previous to the end date
					dayPreviousToEndDate = updateDateToNextOrPreviousDay(endDate,-1);
					// get date difference
					double dateDiffInMilli = dayPreviousToEndDate.getTimeInMillis() - dayNextToStartDate.getTimeInMillis();
					//convert above difference into no of days
					daysExceptFirstAndLast = (long) Math.ceil(dateDiffInMilli/(1000*60*60*24)); 
					// User Math.ceil above in case if the timezone is US and there is day light saving enable. No of hours of day gets reduced
					
					daysExceptFirstAndLast = daysExceptFirstAndLast + 1; // incremented as difference above excludes boundary dates
					//calculate weekly offs and holidays between above date range
					weeklyOffAndHolidays = getHolidayAndWeeklyOff(groupConfig, dayNextToStartDate, dayPreviousToEndDate);
					//calculate hours and day for the start date
					startDayHours = getDayHours(startDate, null, groupConfig, false);
					//calculate hours and day for the end date 
					endDayHours = getDayHours(endDate, endDate, groupConfig, false);
					
				} else if(dateDiff == 3 ) {
					//get start day hours and days
					startDayHours = getDayHours(startDate, null, groupConfig, false);
					// get mid day hours and days
					int[] midDayHrs = getMidDayHours(startDate, groupConfig);
					// add mid day hours and days to start day
					startDayHours[0] = startDayHours[0] + midDayHrs[0];
					startDayHours[1] = startDayHours[1] + midDayHrs[1];
					//get end day hours and days
					endDayHours = getDayHours(endDate, endDate, groupConfig, false);
					
				} else if(dateDiff == 2 ) {
					//get start day hours and days
					startDayHours = getDayHours(startDate, null, groupConfig, false);
					//get end day hours and days
					endDayHours = getDayHours(endDate, endDate, groupConfig, false);
				}
				
			} else {
				//get hours and days of same day inquiry
				startDayHours = getDayHours(startDate, endDate, groupConfig, true);
			}
			
			//get group shift time in minutes
			int minsOfADay = groupConfig.getShiftHoursInMins();
			
			if(daysExceptFirstAndLast < 0)
				daysExceptFirstAndLast = daysExceptFirstAndLast + weeklyOffAndHolidays[0] + weeklyOffAndHolidays[1];
			else {
				//get no of days except first and last day and substract no of holidays and weekly off
				daysExceptFirstAndLast = daysExceptFirstAndLast - weeklyOffAndHolidays[0] - weeklyOffAndHolidays[1];
			}
			
			//calculate no of hours above days
			int finalHrs = (int) ((daysExceptFirstAndLast * minsOfADay)/60);
			// 0th index will have total no of hours
			output[0] = finalHrs + startDayHours[0] + endDayHours[0];
			//1st index will have total no of days
			output[1] = (int)daysExceptFirstAndLast + startDayHours[1] + endDayHours[1];
			
		} catch (Exception e) {
			logger.warn("Exception while calculating age in AgeAndTimeUtils#findAgeDiff:", e );
		}
		
		return output;
	}

	/**
	 * This function gets the mid day hours as :  [noOfHrs, noOfDays]
	 * @param date
	 * @param groupConfig
	 * @return int[]
	 */
	private static int[] getMidDayHours(Date date, GroupShiftConfig groupConfig) {
		
		Calendar midDate = new GregorianCalendar();
		midDate.setTime(date);
		midDate.set(Calendar.DAY_OF_MONTH, midDate.get(Calendar.DAY_OF_MONTH) + 1);
		midDate.set(Calendar.HOUR_OF_DAY, 0);
		midDate.set(Calendar.MINUTE, 0);
		
		int[] isHolidayOrWeeklyOff = getHolidayAndWeeklyOff(groupConfig, midDate,null);
		int[] midDayHrs = { 0 , 0 };

		if( isHolidayOrWeeklyOff[0] == 0 && isHolidayOrWeeklyOff[1] == 0 ) {
			midDayHrs[0] = (groupConfig.getShiftHoursInMins())/60;
			midDayHrs[1] = 1;
		}
		return midDayHrs;
	}
	

	/**
	 * This function provides date difference in no of days
	 * @param startDate
	 * @param endDate
	 * @return int
	 */
	private static int getDateDifference(Date startDate, Date endDate) {
		Calendar start = GregorianCalendar.getInstance();
		Calendar end = GregorianCalendar.getInstance();
		start.setTime(startDate);
		start.set(Calendar.HOUR_OF_DAY, 0);
		start.set(Calendar.MINUTE, 0);
		start.set(Calendar.SECOND, 0);
		start.set(Calendar.MILLISECOND, 0);
		end.setTime(endDate);
		end.set(Calendar.HOUR_OF_DAY, 0);
		end.set(Calendar.MINUTE, 0);
		end.set(Calendar.SECOND, 0);
		end.set(Calendar.MILLISECOND, 0);
		return (int) ((end.getTimeInMillis() - start.getTimeInMillis())/(1000*60*60*24));
	}

	/**
	 * This function identifies holidays and weekly off in given date range as : [noOfHolidays, noOfWeeklyOff]
	 * @param groupConfig
	 * @param startDate
	 * @param endDate
	 * @return int[]
	 */
	private static int[] getHolidayAndWeeklyOff(GroupShiftConfig groupConfig, Calendar startDate, Calendar endDate){
		int[] weeklyOffAndHolidays = { 0 , 0 };
		
		List<String> weeklyOffs = groupConfig.getWeeklyOffs();
		
		if( endDate != null) {
			while (startDate.getTimeInMillis() <= endDate.getTimeInMillis() ) {
			    isHolidayOrWeeklyOff(groupConfig, startDate, weeklyOffAndHolidays, weeklyOffs);
			    startDate.add(Calendar.DATE,1);
			}
		} else {
			isHolidayOrWeeklyOff(groupConfig, startDate, weeklyOffAndHolidays, weeklyOffs);
		}
		
		return weeklyOffAndHolidays;
	}
	
	private static int[] getHolidayAndWeeklyOffForFutureDate(GroupShiftConfig groupConfig, Calendar startDate, Calendar endDate){
		int[] weeklyOffAndHolidays = { 0 , 0 };
		
		List<String> weeklyOffs = groupConfig.getWeeklyOffs();
		
		if( endDate != null) {
			while (endDate.getTimeInMillis() <= startDate.getTimeInMillis()) {
			    isHolidayOrWeeklyOff(groupConfig, endDate, weeklyOffAndHolidays, weeklyOffs);
			    endDate.add(Calendar.DATE,1);
			}
		} else {
			isHolidayOrWeeklyOff(groupConfig, endDate, weeklyOffAndHolidays, weeklyOffs);
		}
		
		return weeklyOffAndHolidays;
	}

	/**
	 * This function updates whether give date is holiday or weekly off.
	 * @param groupConfig
	 * @param startDate
	 * @param weeklyOffAndHolidays
	 * @param weeklyOffs
	 */
	private static void isHolidayOrWeeklyOff(GroupShiftConfig groupConfig, Calendar startDate,
			int[] weeklyOffAndHolidays, List<String> weeklyOffs) {
		boolean isWeeklyOff = false;
		if( null != weeklyOffs && weeklyOffs.contains(String.valueOf(startDate.get(Calendar.DAY_OF_WEEK) - 1))) {
			weeklyOffAndHolidays[0]++;
			isWeeklyOff = true;
		}
		if(!isWeeklyOff){
			String formattedDateString = startDate.get(Calendar.DAY_OF_MONTH) + "-"  + (startDate.get(Calendar.MONTH)+1)  + "-" + startDate.get(Calendar.YEAR);
			if(null!= groupConfig.getHolidays() && groupConfig.getHolidays().contains(formattedDateString)){
				weeklyOffAndHolidays[1]++;
			}
		}
	}
	
	/**
	 * This function returns a date either next/previous of provided date
	 * Only date will be incremented/decremented. hours, mins and secs will be reset to zero
	 * @param date
	 * @param operation
	 * @return Calendar
	 */
	private static Calendar updateDateToNextOrPreviousDay(Date date, int operation) {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int day = calendar.get(Calendar.DAY_OF_MONTH) + operation;
		return  new GregorianCalendar(year, month, day, 0, 0, 0);
	}
	
	
	/**
	 * This function calculates hours of a day as : [noOfHrs, noOfDays]
	 * @param startDate
	 * @param endDate
	 * @param config
	 * @param isSameStartAndEndDay
	 * @return int[]
	 */
	private static int[] getDayHours(Date startDate, Date endDate, GroupShiftConfig config, boolean isSameStartAndEndDay) {
		
		int[] dayHours = { 0 , 0 };
		
		Calendar date = new GregorianCalendar();
		date.setTime(startDate);

		int[] isHolidayOrWeeklyOff = getHolidayAndWeeklyOff(config, date,null);
		
		if( isHolidayOrWeeklyOff[0] == 0 && isHolidayOrWeeklyOff[1] == 0 ) {
			
			String[] shiftStartConfig= config.getShiftStartTime().split(":");
			int startHour = Integer.parseInt(shiftStartConfig[0]);
			int startMins = Integer.parseInt(shiftStartConfig[1]);
			
			String[] shiftEndConfig = config.getShiftEndTime().split(":");
			int endHour = Integer.parseInt(shiftEndConfig[0]);
			int endMins = Integer.parseInt(shiftEndConfig[1]);
			
			Calendar shiftStartTime = new GregorianCalendar();
			shiftStartTime.setTime(startDate);
			shiftStartTime.set(Calendar.HOUR_OF_DAY, startHour);
			shiftStartTime.set(Calendar.MINUTE, startMins);
			
			Calendar shiftEndTime = new GregorianCalendar();
			shiftEndTime.setTime(startDate);
			shiftEndTime.set(Calendar.HOUR_OF_DAY, endHour);
			shiftEndTime.set(Calendar.MINUTE, endMins);
			
			if(isSameStartAndEndDay) {
				dayHours = getSameDayWorkingHours(startDate, endDate, shiftStartTime, shiftEndTime);
			} else {
				if( endDate == null ) {
					dayHours = getHoursOfAStartDay(startDate, shiftStartTime, shiftEndTime);
				} else {
					dayHours = getHoursOfAEndDay(endDate, shiftStartTime, shiftEndTime);
				}
			}
			
		}
		
		return dayHours;
	}
	
	
	/**
	 * This function calculates and returns age of an inquiry if it's start and end is on same day as  [noOfHrs, noOfDays]
	 * @param startDate
	 * @param endDate
	 * @param shiftStart
	 * @param shiftEnd
	 * @return
	 */
	static int[] getSameDayWorkingHours(Date startDate, Date endDate, Calendar shiftStart, Calendar shiftEnd) {
		
		int[] hrsDay = { 0 , 0 };

		long startTime = startDate.getTime();
		long endTime = endDate.getTime();
		long shiftStartTime = shiftStart.getTimeInMillis();
		long shiftEndTime = shiftEnd.getTimeInMillis();
		
		
		if( startTime >= shiftEndTime || endTime <= shiftStartTime ) {
			return hrsDay;
		}
		
		if(startTime < shiftStartTime) {
			startTime = shiftStartTime;
		}
		
		if(endTime > shiftEndTime) {
			endTime = shiftEndTime;
		}
		
		long dayTimeDiffInMili = endTime - startTime;
		
		boolean sameDayShiftComplete = false;
		
		if((shiftEndTime-shiftStartTime) == dayTimeDiffInMili) {
			sameDayShiftComplete = true;
		}
		
		int dayTimeDiffInHrs = (int)(dayTimeDiffInMili/(1000*60*60));
		int dayTimeDiffInDays = sameDayShiftComplete ? 1 : 0 ;
		
		hrsDay[0] = dayTimeDiffInHrs;
		hrsDay[1] = dayTimeDiffInDays;
		
		return hrsDay;
	}

	/**
	 * This function calculates age of an inquiry for the starting day as :  [noOfHrs, noOfDays]
	 * @param startDay
	 * @param shiftStart
	 * @param shiftEnd
	 * @return int[]
	 */
	private static int[] getHoursOfAStartDay(Date startDay, Calendar shiftStart, Calendar shiftEnd) {
		
		int[] hrsDay = { 0 , 0 } ;
		
		long startTime = startDay.getTime();
		long shiftEndTime = shiftEnd.getTimeInMillis();
		
		if(startTime > shiftEndTime) {
			return hrsDay;
		}
		
		long shiftStartTime = shiftStart.getTimeInMillis();
		
		if(startTime < shiftStartTime){
			startTime = shiftStartTime;
		}
		
		if(startTime > shiftEndTime) {
			startTime = shiftEndTime;
		}
		
		long dayTimeDiffInMili = shiftEndTime - startTime;
		
		int dayTimeDiffInHrs = (int)(dayTimeDiffInMili/(1000*60*60));
		int dayTimeDiffInDays = dayTimeDiffInMili > 0 ? 1 : 0 ;
		
		hrsDay[0] = dayTimeDiffInHrs;
		hrsDay[1] = dayTimeDiffInDays;
		
		return hrsDay;
	}
	
	
	/**
	 * This function calculates age of an inquiry on end day as :  [noOfHrs, noOfDays]
	 * @param endDay
	 * @param shiftStart
	 * @param shiftEnd
	 * @return int[]
	 */
	private static int[] getHoursOfAEndDay(Date endDay, Calendar shiftStart, Calendar shiftEnd) {
		
		int[] hrsDay = { 0 , 0 } ;
		
		long endTime = endDay.getTime();
		long shiftStartTime = shiftStart.getTimeInMillis();
		
		
		if(endTime < shiftStartTime) {
			return hrsDay;
		}
		
		long shiftEndTime = shiftEnd.getTimeInMillis();
		
		if(endTime > shiftEndTime){
			endTime = shiftEndTime;
		}
		
		long dayTimeDiffInMili = endTime - shiftStartTime;
		

		int dayTimeDiffInHrs = (int)(dayTimeDiffInMili/(1000*60*60));
		int dayTimeDiffInDays;

		if(endTime < shiftEndTime){
			dayTimeDiffInDays = 0;
		} else {
			dayTimeDiffInDays = dayTimeDiffInMili > 0 ? 1 : 0 ;
		}
		
		hrsDay[0] = dayTimeDiffInHrs;
		hrsDay[1] = dayTimeDiffInDays;
		
		return hrsDay;
	}
	
	/**
	 * This method get the age of an inquiry without age config
	 * @param workflow
	 * @param logger
	 * @return long
	 */
	public static long getAgeForNonHolidayConfig(DBObject workflow, String type) {
		long inquiryAge = 0;
		try
		{
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.SSS");
			String status = (String) workflow.get(STATUS_KEY);
			String startDateStr = null;
			
			if("age".equalsIgnoreCase(type)){
				startDateStr = GenericUtility.formatDate((Date) checkIfNull(workflow, "reAgeDate"));
			} else if("reOpenAge".equalsIgnoreCase(type)){
				startDateStr = GenericUtility.formatDate((Date) checkIfNull(workflow, "reOpenAge"));
			}
			
			String modDateStr = GenericUtility.formatDate((Date) checkIfNull(workflow, "modDate"));
			String crtDateStr = GenericUtility.formatDate((Date) checkIfNull(workflow, "crtDate"));
			Date startDate = null;
			if (!StringUtils.isEmpty(startDateStr))
			{
				startDate = sdf.parse(startDateStr);
			}
			Date modDate = null;
			if (!StringUtils.isEmpty(modDateStr))
			{
				modDate = sdf.parse(modDateStr);
			}
			Date crtDate = null;
			if (!StringUtils.isEmpty(crtDateStr))
			{
				crtDate = sdf.parse(crtDateStr);
			}

			Date currentDate = new Date();
			long diff = getDifferenceInMilli(status, startDate, modDate, crtDate, currentDate);
			inquiryAge = diff / ONE_DAY_MATRIX;
		}
		catch (Exception e) {
			logger.warn("Exception while calculating age of non holiday config group :", e);
		}
		return inquiryAge;
	}

	
	/**
	 * This function gets time difference in milis
	 * @param status
	 * @param startDate
	 * @param modDate
	 * @param crtDate
	 * @param currentDate
	 * @return long
	 */
	private static long getDifferenceInMilli(String status, Date startDate, Date modDate, Date crtDate, Date currentDate)
	{
		long diff = 0;
		if (!StringUtils.isEmpty(status) && STATUS_OPEN.equalsIgnoreCase(status)) {
			if (startDate != null) {
				diff = currentDate.getTime() - startDate.getTime();
			} else if (crtDate != null) {
				diff = currentDate.getTime() - crtDate.getTime();
			}
		} else if (!StringUtils.isEmpty(status) && "resolved".equalsIgnoreCase(status)) {
			if (startDate != null && modDate != null) {
				diff = modDate.getTime() - startDate.getTime();
			} else if (crtDate != null && modDate != null) {
				diff = modDate.getTime() - crtDate.getTime();
			}
		}
		return diff;
	}
	
	
	/**
	 * This method checks null values
	 * @param workflow
	 * @param value
	 * @return Object
	 */
	private static Object checkIfNull(DBObject workflow, String value) {
		if (null != workflow.get(value)) {
			return workflow.get(value);
		} else {
			return null;
		}
	}
	
	// Panorama Feed changes
	
	/**
	 * Method to get the time difference based on age calculation configuration.
	 * 
	 * @param resultObj
	 * @param grpId
	 * @param startDate
	 * @param endDate
	 * @param timeUnit
	 * @param logger
	 */
	public static void getTimeDiffBasedOnAgeConfig(BasicDBObject resultObj, Object grpId, Date startDate, Date endDate, String timeUnit) {
		try {
			Long groupId = (Long) grpId;
			if (grpId != null && null != QMACacheFactory.getCache().getGroupAgeConfigMap() && QMACacheFactory.getCache().getGroupAgeConfigMap().containsKey(grpId)) {
				GroupShiftConfig groupConfig = QMACacheFactory.getCache().getGroupAgeConfigMap().get(groupId);
				if (null != groupConfig && null != groupConfig.getShiftEndTime() && null != groupConfig.getShiftStartTime()) {
					
					// C153176-5354 | Convert Start and End Date time according to group time zone.
					Date _startDate = getDateInGroupTimeZone(groupConfig, startDate);
					Date _endDate = getDateInGroupTimeZone(groupConfig, endDate);
					calculateTimeDifference(resultObj, _startDate, _endDate, groupConfig, timeUnit);
				}
			}
		} catch (Exception e) {
			logger.warn("Error in AgeAndTimeUtils#getTimeDiffBasedOnAgeConfig() :", e);
		}
	}
	
	/**
	 * Method to convert the date time according to group specific time zone
	 * @param groupConfig
	 * @param date
	 * @return 
	 */
	private static Date getDateInGroupTimeZone(GroupShiftConfig groupConfig, Date date) {
		Date groupTimeZoneSpecificDate = null;
		try {
			DateFormat df = new SimpleDateFormat(MONGO_DATE_FORMAT);
			if (null != date) {
				groupTimeZoneSpecificDate = getDateInGroupTimeZone(groupConfig.getTimeZone(), df.format(date));
			}
		} catch (ParseException e) {
			logger.warn("Error in AgeAndTimeUtils#getDateInGroupTimeZone() :", e);
		}
		return groupTimeZoneSpecificDate;
	}
	

	/**
	 * Method to calculate the time difference based on timeUnit.
	 * 
	 * @param resultObj
	 * @param startDate
	 * @param endDate
	 * @param groupConfig
	 * @param timeUnit
	 * @param logger
	 */
	private static void calculateTimeDifference(BasicDBObject resultObj, Date startDate, Date endDate, GroupShiftConfig groupConfig, String timeUnit) {
		try {
			if (startDate != null && endDate != null) {
				long timeDiff = findTimeDiff(startDate, endDate, groupConfig, timeUnit);
				resultObj.put(QmaMailConstants.TIME_DIFF, timeDiff);
			}
		} catch (Exception e) {
			logger.warn("Exception in AgeAndTimeUtils#calculateTimeDifference()", e);
		}
	}

	
	/**
	 * This function calculates time difference in minutes, hours and days based on timeUnit.
	 * 
	 * @param startDate
	 * @param endDate
	 * @param groupConfig
	 * @param timeUnit
	 * @param logger
	 * @return
	 */
	private static int findTimeDiff(Date startDate, Date endDate, GroupShiftConfig groupConfig, String timeUnit) {
		int[] output = { 0, 0, 0 };
		int timeDiff = 0;
		try {
			long daysExceptFirstAndLast = 0;
			int[] startDayHoursMins = { 0, 0, 0 };
			int[] endDayHoursMins = { 0, 0, 0 };
			int[] weeklyOffAndHolidays = { 0, 0, 0 };
			// Check if inquiry is started and ended on same day
			if (!DateUtils.isSameDay(startDate, endDate)) {
				int dateDiff = getDateDifference(startDate, endDate);
				dateDiff++; // incremented as above function excludes boundary values for difference
				Calendar dayNextToStartDate;
				Calendar dayPreviousToEndDate;
				// If the date difference > 3 ,then calculate date difference between two date
				// range (excluding boundaries)
				// and calculate start and end date hours separately
				if (dateDiff > 3) {
					// get date next to the start date.
					dayNextToStartDate = updateDateToNextOrPreviousDay(startDate, 1);
					// get date previous to the end date
					dayPreviousToEndDate = updateDateToNextOrPreviousDay(endDate, -1);
					// get date difference
					double dateDiffInMilli = dayPreviousToEndDate.getTimeInMillis() - dayNextToStartDate.getTimeInMillis();
					// convert above difference into no of days
					daysExceptFirstAndLast = (long) Math.ceil(dateDiffInMilli / (1000 * 60 * 60 * 24));
					// User Math.ceil above in case if the timezone is US and there is day light
					// saving enable. No of hours of day gets reduced

					daysExceptFirstAndLast = daysExceptFirstAndLast + 1; // incremented as difference above excludes boundary dates
					// calculate weekly offs and holidays between above date range
					weeklyOffAndHolidays = getHolidayAndWeeklyOff(groupConfig, dayNextToStartDate, dayPreviousToEndDate);
					// calculate minutes, hours and day for the start date
					startDayHoursMins = getDayHoursMins(startDate, null, groupConfig, false);
					// calculate minutes, hours and day for the end date
					endDayHoursMins = getDayHoursMins(endDate, endDate, groupConfig, false);

				} else if (dateDiff == 3) {
					// get start day in minutes, hours and days
					startDayHoursMins = getDayHoursMins(startDate, null, groupConfig, false);
					// get mid day in minutes, hours and days
					int[] midDayHrsMins = getMidDayHoursMins(startDate, groupConfig);
					// add mid day in minutes, hours and days to start day
					startDayHoursMins[0] = startDayHoursMins[0] + midDayHrsMins[0];
					startDayHoursMins[1] = startDayHoursMins[1] + midDayHrsMins[1];
					startDayHoursMins[2] = startDayHoursMins[2] + midDayHrsMins[2];
					// get end day in minutes, hours and days
					endDayHoursMins = getDayHoursMins(endDate, endDate, groupConfig, false);

				} else if (dateDiff == 2) {
					// get start day in minutes, hours and days
					startDayHoursMins = getDayHoursMins(startDate, null, groupConfig, false);
					// get end day in minutes, hours and days
					endDayHoursMins = getDayHoursMins(endDate, endDate, groupConfig, false);
				}

			} else {
				// get hours and days of same day inquiry
				startDayHoursMins = getDayHoursMins(startDate, endDate, groupConfig, true);
			}

			// get group shift time in minutes
			int minsOfADay = groupConfig.getShiftHoursInMins();

			// get no of days except first and last day and subtract no of holidays and
			// weekly off
			daysExceptFirstAndLast = daysExceptFirstAndLast - weeklyOffAndHolidays[0] - weeklyOffAndHolidays[1];

			// calculate no of minutes above days
			int finalMins = (int) (daysExceptFirstAndLast * minsOfADay);

			// calculate no of hours above days
			int finalHrs = (int) ((daysExceptFirstAndLast * minsOfADay) / 60);

			// 0th index will have total no of minutes
			output[0] = finalMins + startDayHoursMins[0] + endDayHoursMins[0];

			// 1st index will have total no of hours
			output[1] = finalHrs + startDayHoursMins[1] + endDayHoursMins[1];

			// 2nd index will have total no of days
			output[2] = (int) daysExceptFirstAndLast + startDayHoursMins[2] + endDayHoursMins[2];
			
			switch (timeUnit) {
			case QmaMailConstants.TIME_UNIT_MINS:
				timeDiff = output[0];
				break;
			case QmaMailConstants.TIME_UNIT_HRS:
				timeDiff = output[1];
				break;
			case QmaMailConstants.TIME_UNIT_DAYS:
				timeDiff = output[2];
				break;
			default:
			}

		} catch (Exception e) {
			logger.warn("Exception while calculating age in AgeAndTimeUtils#findTimeDiff:", e);
		}

		return timeDiff;
	}
	
	/**
	 * This function calculates minutes, hours of a day as : [noOfMins, noOfHrs, noOfDays]
	 * @param startDate
	 * @param endDate
	 * @param config
	 * @param isSameStartAndEndDay
	 * @return int[]
	 */
	private static int[] getDayHoursMins(Date startDate, Date endDate, GroupShiftConfig config, boolean isSameStartAndEndDay) {

		int[] minHrsDay = { 0, 0, 0 };

		Calendar date = new GregorianCalendar();
		date.setTime(startDate);

		int[] isHolidayOrWeeklyOff = getHolidayAndWeeklyOff(config, date, null);

		if (isHolidayOrWeeklyOff[0] == 0 && isHolidayOrWeeklyOff[1] == 0) {

			String[] shiftStartConfig = config.getShiftStartTime().split(":");
			int startHour = Integer.parseInt(shiftStartConfig[0]);
			int startMins = Integer.parseInt(shiftStartConfig[1]);

			String[] shiftEndConfig = config.getShiftEndTime().split(":");
			int endHour = Integer.parseInt(shiftEndConfig[0]);
			int endMins = Integer.parseInt(shiftEndConfig[1]);

			Calendar shiftStartTime = new GregorianCalendar();
			shiftStartTime.setTime(startDate);
			shiftStartTime.set(Calendar.HOUR_OF_DAY, startHour);
			shiftStartTime.set(Calendar.MINUTE, startMins);

			Calendar shiftEndTime = new GregorianCalendar();
			shiftEndTime.setTime(startDate);
			shiftEndTime.set(Calendar.HOUR_OF_DAY, endHour);
			shiftEndTime.set(Calendar.MINUTE, endMins);

			if (isSameStartAndEndDay) {
				minHrsDay = getSameDayWorkingHoursMins(startDate, endDate, shiftStartTime, shiftEndTime);
			} else {
				if (endDate == null) {
					minHrsDay = getMinHoursOfAStartDay(startDate, shiftStartTime, shiftEndTime);
				} else {
					minHrsDay = getMinsHoursOfAEndDay(endDate, shiftStartTime, shiftEndTime);
				}
			}
		}
		return minHrsDay;
	}
	
	/**
	 * This function calculates difference for the starting day as :  [noOfMins, noOfHrs, noOfDays]
	 * @param startDay
	 * @param shiftStart
	 * @param shiftEnd
	 * @return int[]
	 */
	private static int[] getMinHoursOfAStartDay(Date startDay, Calendar shiftStart, Calendar shiftEnd) {
		
		int[] minHrsDay =  { 0, 0, 0 };
		
		long startTime = startDay.getTime();
		long shiftEndTime = shiftEnd.getTimeInMillis();
		
		if(startTime > shiftEndTime) {
			return minHrsDay;
		}
		
		long shiftStartTime = shiftStart.getTimeInMillis();
		
		if(startTime < shiftStartTime){
			startTime = shiftStartTime;
		}
		
		if(startTime > shiftEndTime) {
			startTime = shiftEndTime;
		}
		
		long dayTimeDiffInMili = shiftEndTime - startTime;
		
		int dayTimeDiffInMins = (int) (dayTimeDiffInMili / (1000 * 60));
		int dayTimeDiffInHrs = (int) (dayTimeDiffInMili / (1000 * 60 * 60));
		int dayTimeDiffInDays = dayTimeDiffInMili > 0 ? 1 : 0;
		
		minHrsDay[0] = dayTimeDiffInMins;
		minHrsDay[1] = dayTimeDiffInHrs;
		minHrsDay[2] = dayTimeDiffInDays;
		
		return minHrsDay;
	}
	
	/**
	 * This function calculates time difference on end day as :  [noOfMins, noOfHrs, noOfDays]
	 * @param endDay
	 * @param shiftStart
	 * @param shiftEnd
	 * @return int[]
	 */
	private static int[] getMinsHoursOfAEndDay(Date endDay, Calendar shiftStart, Calendar shiftEnd) {

		int[] minHrsDay = { 0, 0, 0 };

		long endTime = endDay.getTime();
		long shiftStartTime = shiftStart.getTimeInMillis();

		if (endTime < shiftStartTime) {
			return minHrsDay;
		}

		long shiftEndTime = shiftEnd.getTimeInMillis();

		if (endTime > shiftEndTime) {
			endTime = shiftEndTime;
		}

		long dayTimeDiffInMili = endTime - shiftStartTime;

		int dayTimeDiffInMins = (int) (dayTimeDiffInMili / (1000 * 60));
		int dayTimeDiffInHrs = (int) (dayTimeDiffInMili / (1000 * 60 * 60));
		int dayTimeDiffInDays;

		if (endTime < shiftEndTime) {
			dayTimeDiffInDays = 0;
		} else {
			dayTimeDiffInDays = dayTimeDiffInMili > 0 ? 1 : 0;
		}

		minHrsDay[0] = dayTimeDiffInMins;
		minHrsDay[1] = dayTimeDiffInHrs;
		minHrsDay[2] = dayTimeDiffInDays;

		return minHrsDay;
	}
	
	
	/**
	 * This function calculates and returns time difference if it's start and end is on same day as  [noOfMins, noOfHrs, noOfDays]
	 * @param startDate
	 * @param endDate
	 * @param shiftStart
	 * @param shiftEnd
	 * @return
	 */
	static int[] getSameDayWorkingHoursMins(Date startDate, Date endDate, Calendar shiftStart, Calendar shiftEnd) {

		int[] minHrsDay = { 0, 0, 0 };

		long startTime = startDate.getTime();
		long endTime = endDate.getTime();
		long shiftStartTime = shiftStart.getTimeInMillis();
		long shiftEndTime = shiftEnd.getTimeInMillis();

		if (startTime >= shiftEndTime || endTime <= shiftStartTime) {
			return minHrsDay;
		}

		if (startTime < shiftStartTime) {
			startTime = shiftStartTime;
		}

		if (endTime > shiftEndTime) {
			endTime = shiftEndTime;
		}

		long dayTimeDiffInMili = endTime - startTime;

		boolean sameDayShiftComplete = false;
		if ((shiftEndTime - shiftStartTime) == dayTimeDiffInMili) {
			sameDayShiftComplete = true;
		}

		int dayTimeDiffInMins = (int) (dayTimeDiffInMili / (1000 * 60));
		int dayTimeDiffInHrs = (int) (dayTimeDiffInMili / (1000 * 60 * 60));
		int dayTimeDiffInDays = sameDayShiftComplete ? 1 : 0;

		minHrsDay[0] = dayTimeDiffInMins;
		minHrsDay[1] = dayTimeDiffInHrs;
		minHrsDay[2] = dayTimeDiffInDays;

		return minHrsDay;
	}
	
	/**
	 * This function gets the mid day hours as :  [noOfMins, noOfHrs, noOfDays]
	 * @param date
	 * @param groupConfig
	 * @return int[]
	 */
	private static int[] getMidDayHoursMins(Date date, GroupShiftConfig groupConfig) {

		Calendar midDate = new GregorianCalendar();
		midDate.setTime(date);
		midDate.set(Calendar.DAY_OF_MONTH, midDate.get(Calendar.DAY_OF_MONTH) + 1);
		midDate.set(Calendar.HOUR_OF_DAY, 0);
		midDate.set(Calendar.MINUTE, 0);

		int[] isHolidayOrWeeklyOff = getHolidayAndWeeklyOff(groupConfig, midDate, null);
		int[] midDayHrs = { 0, 0, 0 };

		if (isHolidayOrWeeklyOff[0] == 0 && isHolidayOrWeeklyOff[1] == 0) {
			midDayHrs[0] = groupConfig.getShiftHoursInMins();
			midDayHrs[1] = (groupConfig.getShiftHoursInMins()) / 60;
			midDayHrs[2] = 1;
		}
		return midDayHrs;
	}
	
	/**
	 * Method to calculate the time considering work shift timing of a group.
	 * 
	 * @param currentTime - Current Time.
	 * @param startDate - Start Date
	 * @param groupId - Group id
	 * 
	 * @return response time {@link long}
	 */
	public static long calculateResponseTimeWrkShiftBased(Date currentTime, Date startDate, Long groupId) {
		long newResponseTimeInMins = 0;
		try {
			BasicDBObject resultObj = new BasicDBObject();
			AgeAndTimeUtils.getTimeDiffBasedOnAgeConfig(resultObj, groupId,	startDate, currentTime, QmaMailConstants.TIME_UNIT_MINS);	
			if (null != resultObj.get(QmaMailConstants.TIME_DIFF)) {
				newResponseTimeInMins = resultObj.getLong(QmaMailConstants.TIME_DIFF);
				//logger.debug("Response time in minutes considering working hours logic : " + newResponseTimeInMins);
			} 
			else if (null != startDate) {
				newResponseTimeInMins = ((currentTime.getTime() - startDate.getTime()) / 60000);
				//logger.debug("Response time in minutes : " + newResponseTimeInMins);
			}
		} catch (Exception e) {
			logger.warn("error calculating response time in minutes"+e);
		}
		return newResponseTimeInMins;
		}
	public static Object nullCheck(DBObject workflow, String value)
	{
		if (null != workflow.get(value))
		{
			return workflow.get(value);
		}
		else
		{
			return null;
		}
	}
	/**
	 * This method used to calculate time in queue 
	 * @param workflowBuilder
	 * @param workflow
	 * @return
	 */
	public static String calculateTimeInQueue(Object assignedGroupId,BasicDBObject workflow,boolean isWebSocketUpdate) {
		String direction = (String) nullCheck(workflow, "direction");
		String isLatestReplyFromCurrentWorkflowGrp = (String) workflow.get("isLatestReplyFromCurrentWorkflowGrp");
		Date firstNonChaserResponseTimeFromExternal = (Date) nullCheck(workflow,"firstNonChaserResponseTimeByExternal");
		Date currentTime = new Date();
		Date modDate = (Date) nullCheck(workflow, "modDate");
		Date resolveTime = (Date) nullCheck(workflow, "resolveTime");
		Date crtDate = (Date) nullCheck(workflow, "crtDate");
		Long assignedGrpId = (Long) assignedGroupId;
		String status = (String) nullCheck(workflow, "status");
		String isLatestResponseFromNonQMA = (String) nullCheck(workflow, "isLatestResponseFromNonQMA");
		long citiResonseTime =0;
	    if(nullCheck(workflow, "citiResponseTime")!= null) { // for web socket update
	    	citiResonseTime=isWebSocketUpdate? ((Number)workflow.get("citiResponseTime")).longValue():(Long) workflow.get("citiResponseTime");
	    }
		String action = (String) nullCheck(workflow, "action");
		String timeInqueue = "";
		if (direction != null && direction.equalsIgnoreCase(InquiryDAO.INQUIRY_DIRECTION_IN) && null != assignedGrpId) {
			if (null != status && (status.equalsIgnoreCase(InquiryDAO.STATUS_RESOLVE))) {
				if (null != nullCheck(workflow, "citiResponseTime")) {// for resolve/reply resolve/reply all resolve																									
					timeInqueue = AgeAndTimeUtils.convertMinsIntoHrAndDays(citiResonseTime);
				} else { // for ResolveNOAction and resolve Allocation without any prior reply
					Date toDate = resolveTime != null ? resolveTime : modDate;
					long timeInQueueInMins = AgeAndTimeUtils.calculateResponseTimeWrkShiftBased(toDate, crtDate,
							assignedGrpId);
					timeInqueue = AgeAndTimeUtils.convertMinsIntoHrAndDays(timeInQueueInMins);
				}
				 // for reply all resolve and reply all, while updating web socket action was getting change so took isLatestReplyFromCurrentWorkflowGrp
			}else if (isLatestResponseFromNonQMA!=null && isLatestResponseFromNonQMA.equalsIgnoreCase("N") && isLatestReplyFromCurrentWorkflowGrp != null
					&& isLatestReplyFromCurrentWorkflowGrp.equalsIgnoreCase("Y")) {
				timeInqueue = "NotInQ";
			} else if (null != status && status.equalsIgnoreCase(InquiryDAO.STATUS_OPEN)
					&& (isLatestReplyFromCurrentWorkflowGrp == null
							|| isLatestReplyFromCurrentWorkflowGrp.equalsIgnoreCase("N"))) {
				if (null != firstNonChaserResponseTimeFromExternal && null != isLatestResponseFromNonQMA
						&& isLatestResponseFromNonQMA.equalsIgnoreCase("Y")) { // for external to qma and forward scenario
					timeInqueue = calcuateTimeInQueueForExternal(currentTime, firstNonChaserResponseTimeFromExternal,
							assignedGrpId);
				} else { // calculate time in queue for qma to qma inquiry
					long timeInQueueInMins = AgeAndTimeUtils.calculateResponseTimeWrkShiftBased(currentTime, modDate,
							assignedGrpId);
					timeInqueue = AgeAndTimeUtils.convertMinsIntoHrAndDays(timeInQueueInMins);
				}
			}else { 
				timeInqueue = calcuateTimeInQueueForExternal(currentTime, firstNonChaserResponseTimeFromExternal,
						assignedGrpId);
			}
		} else if (null != direction && direction.equalsIgnoreCase(InquiryDAO.INQUIRY_DIRECTION_OUT) 
				&& (isLatestReplyFromCurrentWorkflowGrp == null || isLatestReplyFromCurrentWorkflowGrp.equals("Y"))) {
			// Forward prior any reply.
			timeInqueue = AgeAndTimeUtils.convertMinsIntoHrAndDays(citiResonseTime);
		} else if (null != direction && (direction.equalsIgnoreCase("PENDINGAPPROVAL") // pending approval
				|| direction.equalsIgnoreCase("PND_REAGE") || direction.equalsIgnoreCase("NOMINATE_OWNERSHIP"))) {
			timeInqueue = calcuateTimeInQueueForExternal(currentTime, firstNonChaserResponseTimeFromExternal,
					assignedGrpId);
		} 
		return timeInqueue;
	}
	
	/**
	 * This method calculate time in queue for external inquiry 
	 * @param currentTime
	 * @param firstNonChaserResponseTimeFromExternal
	 * @return
	 */
	public static String calcuateTimeInQueueForExternal(Date currentTime,Date firstNonChaserResponseTimeFromExternal,long assignedGrpId)
	{
		String timeInQueue="0";
		if (null != firstNonChaserResponseTimeFromExternal) {
			long timeInQueueInMins = AgeAndTimeUtils.calculateResponseTimeWrkShiftBased(currentTime,
					firstNonChaserResponseTimeFromExternal, assignedGrpId);
			timeInQueue = AgeAndTimeUtils.convertMinsIntoHrAndDays(timeInQueueInMins);
		}
		return timeInQueue;
	}
	/**
	 * This method use to convert minutes into hours and days 
	 * @param minutes
	 * @return
	 */

	public static String convertMinsIntoHrAndDays(long timeInqueueInMins)
	{     
		  String timeInQueue="";
	      timeInqueueInMins=timeInqueueInMins<0?Math.abs(timeInqueueInMins):timeInqueueInMins;
	      if(timeInqueueInMins>0) {
		  long days=timeInqueueInMins/1440;
		  long rem=timeInqueueInMins%1440;
		  long hour=rem/60;
		  long mins=rem%60;
		  String timeInQueueInDays=days>0?days==1?"%d day".formatted(days):"%d days".formatted(days):"";
		  String timeInQueueInHour=hour>0?hour==1?"%d hour".formatted(hour):"%d hours".formatted(hour):"";
		  String min=mins>0?mins==1?"%d min".formatted(mins):"%d mins".formatted(mins):"";
		  timeInQueue= "%s %s %s".formatted(timeInQueueInDays, timeInQueueInHour, min).trim();
	      }else {
	    	  timeInQueue=String.valueOf(timeInqueueInMins);
	      }
	      return timeInQueue;
	}
	
	public static String getTimeToVD(String valueTime,Long grpId) {
		String timeToVD = "";
		try {
        if(StringUtils.isBlank(valueTime)){
            return timeToVD;
        }
		GroupShiftConfig groupConfig =  CacheDAO.getInstance().getGroupAgeConfigMap().get(grpId);
		SimpleDateFormat format1 = new SimpleDateFormat("MM-dd-yyyy");
		SimpleDateFormat format2 = new SimpleDateFormat(MONGO_DATE_FORMAT);
		Date date = format1.parse(valueTime);
		Date date2 = format1.parse(format1.format(new Date()));
		Date startDate = getDateInGroupTimeZone(groupConfig.getTimeZone(),format2.format(date));
		Date endDate = getDateInGroupTimeZone(groupConfig.getTimeZone(),format2.format(date2));
		int[] timeDiff =  AgeAndTimeUtils.findDateDiffForTimeToVD(startDate, endDate, groupConfig);
		timeToVD = String.valueOf(timeDiff[1]);
		if(StringUtils.isNotBlank(timeToVD)&&("0".equals(timeToVD)||timeToVD.contains("-"))) {
			timeToVD = timeToVD.replace("-", "");
		}else {
			timeToVD = "-".concat(timeToVD);
		}
		}catch(Exception e) {  
			logger.warn("Exception while calulating TIme to VD: ",e);
		}
		
		return timeToVD;
	}
}