package com.citi.icg.qma.common.transferobject;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.citi.icg.qma.common.server.dao.ClientCategory;
import com.citi.icg.qma.common.server.dao.ColumnDef;
import com.citi.icg.qma.common.server.dao.Country;
import com.citi.icg.qma.common.server.dao.FavoriteContact;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.HolidayMaster;
import com.citi.icg.qma.common.server.dao.KeyValue;
import com.citi.icg.qma.common.server.dao.OrgMetaDataAdminRole;
import com.citi.icg.qma.common.server.dao.Preference;
import com.citi.icg.qma.common.server.dao.Signature;
import com.citi.icg.qma.common.server.dao.TimeZone;
import com.citi.icg.qma.common.server.dao.ViewConfig;
import com.citi.icg.qma.common.server.dao.ViewFilters;

public class UserTO
{
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private String userId;
	private String userName;
	private List<ViewTO> userViews;
	private List<FavoriteContact> myFavoriteContacts;
	private List<Signature> userSignatures;
	private List<Group> myGroups;
	private List<String> userFolders;
	private List<UserGroupTO> allToCcDBUsers; // it will be combination of qs_user + qs_group...
	private String wsHost;
	private List<String> defaultViews;
	private String email;
	private List<Preference> preferences;
	private List<GroupRoleTO> groupRoles;
	private List<String> adminRoles;
	private Boolean active;
	//Added to create Inquiry templates for users. Made private & provided get/set methods as per best practices. 
	private List<Template> userTemplateList;
	//Added to get the bccgroup set in DB in staticdata table
	private List<Long> bccGroupIdList;
	//Added to get the bccRoutingGroup in staticdata table
	private Long bccGroupRoutingId;
	//User level Customized View Column Definitions for Default Views-April 15 release
	private List<ViewConfig> viewColumnDefs;
	private List<ColumnDef> defaultColumnDefs;
	//private String enableDrafts;
	//private String enableGrpBasedTopContact;
	private String enableCustomStyleInConversation;
	private List<Integer> errorCodeForWebSocketRestartList;
	private List<String> customStyleOverrideList;//List of Styles needs to be customized for the conversation details
	//Collecting editor default  font style ,  font size  and list of font size and font style from static collection from static table C153176-142
	private List<String> editorFontStyle;
	private List<String> editorFontSize;
	private String defaultAppFontSize;
	private String defaultAppFontStyle;
	private String clipboardPaste; // To enable and disable the HTML conversion for Copy Paste.
	//[C153176-168] Changes for user preference date format
	private String defaultDateFormate;
	private List<String> dateFormatterSelectItemList;
	//[	C153176-289] Flag to enable disable advanced solr search pop up screen.
	private String enableAdvancedSolrSearch;
	private List<UserContextTO> context;
	//[C153176-283] - Link collaborate urls
	private List<KeyValue> collaborateUrls;
	//[C153176-352] - MIS Report request screen
	private List<KeyValue> reportList;
	//[C153176-553]-Ability to set OOO status and notifications
	private boolean outOfOffice;
	private Map<String, Object> outOfOfficeSettings;
	//[C153176-1013] Ability to systemically add 'Secure' in email subject
	private Boolean sendSecureEmail;
	//[C153176-725] - Admin Menu Enhancements for config role and other role reviews
	private List<String> configDefaultAdminRoleList; //Default admin roles available to be displayed on UI
	private List<String> configUserAdminRoles; //Admin roles set for user in Config Collection
	private String autoResponseTemplate; //[C153176-544] - AutoResponse template details saved in Config
	private List<String> inquirySourceList; //[C153176-854] - Add new drop-down: Inquiry Source
	private List<String> inquirySubStatusList; //C170665-1719 DCC Requirement: Add Case status field
	private Boolean isInquirySubStatusEnabledAtOrg;//C170665-1719 DCC Requirement: Add Case status field
	private Boolean enableInquirySubStatusFlag;
	private List<ColumnDefUI> viewWorkFlowColumn; //[C153176-854] - Add new drop-down: Inquiry Source
	//[C153176-1032]-Make maker-checker mandatory
	private List<String> makerCheckerMandatoryOrgs;
	private List<String> makerCheckerExclusionGroups;
	private List<String> attachmentVerificationMandatoryOrgs; //[C153176-1026]
	private String enableHighcharts; //[C153176-999] - Convert Kendo-Charts into Highcharts
	private Integer highchartsReqTypeMaxLength;
	private Integer highchartsAssignedOwnerMaxLength;
	private List<UserGroupTO> allActiveGroups; //  It will contain all active groups.
	
	private boolean showReleaseDocument;
	private String currentReleaseDocumentName;
	//[C153176-1278]-Add scroll bar to QMA screen
	private Boolean fitToMyResolution;
	private List<String> blackListDomains;
	private Boolean disableAutoComplete;
	private String enableMakerCheckerForUnapprovedDomains;
	private List<String> CitiDomainList;
	private List<String> highlevelRequestTypeList;
	private Boolean highlevelRequestTypeFlag;
	private Boolean attachmentPwdProtectionFlag;
	private Boolean inquiryResponstTimeChartFlag;
	private List<Country> countryList;
	private List<TimeZone> timeZones;
	private Map<String,List<HolidayMaster>> holidays;
	private boolean isAgeBasedCalculation;
	private List<String> misExclusionReportNameList;
	private List<String> misExclusionReasonList;
	
	private List<String> myCoverage;
	
	private byte[] profilePic;
	private Map<String, Boolean> notificationSettings;
	
	private List<ViewFilters> viewFilters;
	private Integer webSocketUpdateRows;
	private List<String> defaultClientCategories;
	private String previousDayBoxCount;
	private List<String> defaultViewsInQMA;
	private String tinyMCEUrl;
	private List<ClientCategory> clientCategories;
	
	private Map<String, Object> cvWebsocketConfig;
	
	private String userAuthKey;
	private Map<String, Object> globalDirectoryConfig;
	private Long dashboardCountRefreshIntervalInMs;
	private Map<String, Object> qmaUI2Config;
	private String longDesc;
	private Map<String, Object> symphonyConfig;
	private String symphonyId;
	private String symphonyEmailId;
	private Map<String, SymphonyUserMapTO> userSymphonyIdToUserMap;
	private String isSymphonyEnabledForUser;
	private String isTaskizeEnabledForUser;
	private Boolean calendarSubscribed;
	private Long personalMailboxGrpId; // Which group is assigned as personal mailbox.
	
	//Personal Folder - Section
	private Boolean personalEmailSubscribed;
	private String exchUrl;
	private String exchDomain;
	private List<String> subjectFlagwords;
	private List<String> exchangeAccountHosts;
	private List<String> restrictedFileExtensions;
  	private List<String> allowedFileExtensions;
	private List<String> blockedFileNameCharacters;
	private Map<String, Object> sessionConfig;
	private List<String> custodyAccounts;
	private Map<String, Object> qma2RedirectPopupConfig;
	private Boolean enableAmcarIntegration;
	// C170665-185	for adding org admin role in hard code data point
	private List<OrgMetaDataAdminRole>orgAdminRole;
	private List<String> autoAssignmentRollOutOrgsList;
	private Map<String, Object> uiConsoleLogConfig;
	private List<Map<String, Object>> viewDateRangeConfig;
	private boolean pivotProConfigEnabled;
	private boolean isAuthenticationExpired;
	private boolean isPersonalAccountActive;
	private String psL5;
	private String psL6;
	private String psL7;
	private String msL6;
  	private boolean gdActive;
	private Map<String, String> msExchangeServerConfigMap;
	private List<String> productFamily;
	
	private Map<String,Long> productFamilyGroupIdMap;
	
	private String enableManualDeLinkEntity;
	
	private String enableManualLinkEntity;
	
	private String enableBrazilFxIntegration;
	
	private Integer searchInDays;
	
	//sbt:[C170665-1723] High CheckMark Findings
	private String fileNameRegex;
	
	private List<Character> invalidChars;
	
	private Map<String, Object> ideationConfig;
	
	private Map<String, Object> taskizeConfig;

	private String bussinessStartDate;
	
	private List<String> intentList;  
	
	private Map<String, Object> defaultViewPerformanceConfig;
	
	public Map<String, Object> getTaskizeConfig() {
		return taskizeConfig;
	}

	public void setTaskizeConfig(Map<String, Object> taskizeConfig) {
		this.taskizeConfig = taskizeConfig;
	}

	public String getFileNameRegex() {
		return fileNameRegex;
	}

	public void setFileNameRegex(String fileNameRegex) {
		this.fileNameRegex = fileNameRegex;
	}

	public List<Character> getInvalidChars() {
		return invalidChars;
	}

	public void setInvalidChars(List<Character> invalidChars) {
		this.invalidChars = invalidChars;
	}

	public Map<String, Object> getUiConsoleLogConfig() {
		return uiConsoleLogConfig;
	}

	public void setUiConsoleLogConfig(Map<String, Object> uiConsoleLogConfig) {
		this.uiConsoleLogConfig = uiConsoleLogConfig;
	}

	public UserTO()
	{

	}

	public UserTO(String userId, String userName, List<ViewTO> userViews)
	{
		super();
		this.userId = userId;
		this.userName = userName;
		this.userViews = userViews;
	}

	
	public List<Template> getUserTemplateList()
	{
		return userTemplateList;
	}

	public void setUserTemplateList(List<Template> userTemplateList)
	{
		this.userTemplateList = userTemplateList;
	}

	public List<Preference> getPreferences() {
		return preferences;
	}

	public void setPreferences(List<Preference> preferences) {
		this.preferences = preferences;
	}

	public List<ViewConfig> getViewColumnDefs()
	{
		return viewColumnDefs;
	}

	public void setViewColumnDefs(List<ViewConfig> viewColumnDefs)
	{
		this.viewColumnDefs = viewColumnDefs;
	}

	public List<ColumnDef> getDefaultColumnDefs()
	{
		return defaultColumnDefs;
	}

	public void setDefaultColumnDefs(List<ColumnDef> defaultColumnDefs)
	{
		this.defaultColumnDefs = defaultColumnDefs;
	}

	/*public String getEnableDrafts()
	{
		return enableDrafts;
	}

	public void setEnableDrafts(String enableDrafts)
	{
		this.enableDrafts = enableDrafts;
	}*/

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<ViewTO> getUserViews() {
		return userViews;
	}

	public void setUserViews(List<ViewTO> userViews) {
		this.userViews = userViews;
	}

	public List<FavoriteContact> getMyFavoriteContacts() {
		return myFavoriteContacts;
	}

	public void setMyFavoriteContacts(List<FavoriteContact> myFavoriteContacts) {
		this.myFavoriteContacts = myFavoriteContacts;
	}

	public List<Signature> getUserSignatures() {
		return userSignatures;
	}

	public void setUserSignatures(List<Signature> userSignatures) {
		this.userSignatures = userSignatures;
	}

	public List<Group> getMyGroups() {
		return myGroups;
	}

	public void setMyGroups(List<Group> myGroups) {
		this.myGroups = myGroups;
	}

	public List<String> getUserFolders() {
		return userFolders;
	}

	public void setUserFolders(List<String> userFolders) {
		this.userFolders = userFolders;
	}

	public List<UserGroupTO> getAllToCcDBUsers()
	{
		return allToCcDBUsers;
	}

	public void setAllToCcDBUsers(List<UserGroupTO> allToCcDBUsers)
	{
		this.allToCcDBUsers = allToCcDBUsers;
	}

	public String getWsHost() {
		return wsHost;
	}

	public void setWsHost(String wsHost) {
		this.wsHost = wsHost;
	}

	public List<String> getDefaultViews() {
		return defaultViews;
	}

	public void setDefaultViews(List<String> defaultViews) {
		this.defaultViews = defaultViews;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<GroupRoleTO> getGroupRoles() {
		return groupRoles;
	}

	public void setGroupRoles(List<GroupRoleTO> groupRoles) {
		this.groupRoles = groupRoles;
	}

	public List<String> getAdminRoles() {
		return adminRoles;
	}

	public void setAdminRoles(List<String> adminRoles) {
		this.adminRoles = adminRoles;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	/*public String getEnableGrpBasedTopContact() {
		return enableGrpBasedTopContact;
	}

	public void setEnableGrpBasedTopContact(String enableGrpBasedTopContact) {
		this.enableGrpBasedTopContact = enableGrpBasedTopContact;
	}*/

	public String getEnableCustomStyleInConversation()
	{
		return enableCustomStyleInConversation;
	}

	public void setEnableCustomStyleInConversation(String enableCustomStyleInConversation)
	{
		this.enableCustomStyleInConversation = enableCustomStyleInConversation;
	}

	public List<Integer> getErrorCodeForWebSocketRestartList()
	{
		return errorCodeForWebSocketRestartList;
	}

	public void setErrorCodeForWebSocketRestartList(List<Integer> errorCodeForWebSocketRestartList)
	{
		this.errorCodeForWebSocketRestartList = errorCodeForWebSocketRestartList;
	}

	public List<String> getCustomStyleOverrideList()
	{
		return customStyleOverrideList;
	}

	public void setCustomStyleOverrideList(List<String> customStyleOverrideList)
	{
		this.customStyleOverrideList = customStyleOverrideList;
	}

	public List<String> getEditorFontStyle()
	{
		return editorFontStyle;
	}

	public void setEditorFontStyle(List<String> editorFontStyle)
	{
		this.editorFontStyle = editorFontStyle;
	}

	public List<String> getEditorFontSize()
	{
		return editorFontSize;
	}

	public void setEditorFontSize(List<String> editorFontSize)
	{
		this.editorFontSize = editorFontSize;
	}

	public String getDefaultAppFontSize()
	{
		return defaultAppFontSize;
	}

	public void setDefaultAppFontSize(String defaultAppFontSize)
	{
		this.defaultAppFontSize = defaultAppFontSize;
	}

	public String getDefaultAppFontStyle()
	{
		return defaultAppFontStyle;
	}

	public void setDefaultAppFontStyle(String defaultAppFontStyle)
	{
		this.defaultAppFontStyle = defaultAppFontStyle;
	}


	public String getClipboardPaste() {
		return clipboardPaste;
	}

	public void setClipboardPaste(String clipboardPaste) {
		this.clipboardPaste = clipboardPaste;
	}
	

	public String getDefaultDateFormate()
	{
		return defaultDateFormate;
	}

	public void setDefaultDateFormate(String defaultDateFormate)
	{
		this.defaultDateFormate = defaultDateFormate;
	}

	public List<String> getDateFormatterSelectItemList()
	{
		return dateFormatterSelectItemList;
	}

	public void setDateFormatterSelectItemList(List<String> dateFormatterSelectItemList)
	{
		this.dateFormatterSelectItemList = dateFormatterSelectItemList;
	}

	public String getEnableAdvancedSolrSearch()
	{
		return enableAdvancedSolrSearch;
	}

	public void setEnableAdvancedSolrSearch(String enableAdvancedSolrSearch)
	{
		this.enableAdvancedSolrSearch = enableAdvancedSolrSearch;
	}

	public List<UserContextTO> getContext() {
		return context;
	}

	public void setContext(List<UserContextTO> context) {
		this.context = context;
	}

	public List<Long> getBccGroupIdList()
	{
		return bccGroupIdList;
	}

	public void setBccGroupIdList(List<Long> bccGroupIdList)
	{
		this.bccGroupIdList = bccGroupIdList;
	}

	public Long getBccGroupRoutingId()
	{
		return bccGroupRoutingId;
	}

	public void setBccGroupRoutingId(Long bccGroupRoutingId)
	{
		this.bccGroupRoutingId = bccGroupRoutingId;
	}
	
	//[C153176-283] - Link collaborate urls
	public List<KeyValue> getCollaborateUrls()
	{
		return collaborateUrls;
	}

	public void setCollaborateUrls(List<KeyValue> collaborateUrls)
	{
		this.collaborateUrls = collaborateUrls;
	}

	public List<KeyValue> getReportList()
	{
		return reportList;
	}

	public void setReportList(List<KeyValue> reportList)
	{
		this.reportList = reportList;
	}

	public boolean isOutOfOffice()
	{
		return outOfOffice;
	}

	public void setOutOfOffice(boolean outOfOffice)
	{
		this.outOfOffice = outOfOffice;
	}
	
	public Boolean getSendSecureEmail()
	{
		return sendSecureEmail;
	}

	public void setSendSecureEmail(Boolean sendSecureEmail)
	{
		this.sendSecureEmail = sendSecureEmail;
	}

	public List<String> getConfigDefaultAdminRoleList()
	{
		return configDefaultAdminRoleList;
	}

	public void setConfigDefaultAdminRoleList(List<String> configDefaultAdminRoleList)
	{
		this.configDefaultAdminRoleList = configDefaultAdminRoleList;
	}

	public List<String> getConfigUserAdminRoles()
	{
		return configUserAdminRoles;
	}

	public void setConfigUserAdminRoles(List<String> configUserAdminRoles)
	{
		this.configUserAdminRoles = configUserAdminRoles;
	}

	public String getAutoResponseTemplate()
	{
		return autoResponseTemplate;
	}

	public void setAutoResponseTemplate(String autoResponseTemplate)
	{
		this.autoResponseTemplate = autoResponseTemplate;
	}

	public List<String> getInquirySourceList()
	{
		return inquirySourceList;
	}

	public void setInquirySourceList(List<String> inquirySourceList)
	{
		this.inquirySourceList = inquirySourceList;
	}

	public List<ColumnDefUI> getViewWorkFlowColumn()
	{
		return viewWorkFlowColumn;
	}

	public void setViewWorkFlowColumn(List<ColumnDefUI> viewWorkFlowColumn)
	{
		this.viewWorkFlowColumn = viewWorkFlowColumn;
	}

	public List<String> getMakerCheckerMandatoryOrgs()
	{
		return makerCheckerMandatoryOrgs;
	}

	public void setMakerCheckerMandatoryOrgs(List<String> makerCheckerMandatoryOrgs)
	{
		this.makerCheckerMandatoryOrgs = makerCheckerMandatoryOrgs;
	}

	public List<String> getMakerCheckerExclusionGroups()
	{
		return makerCheckerExclusionGroups;
	}

	public void setMakerCheckerExclusionGroups(List<String> makerCheckerExclusionGroups)
	{
		this.makerCheckerExclusionGroups = makerCheckerExclusionGroups;
	}

	public List<String> getAttachmentVerificationMandatoryOrgs()
	{
		return attachmentVerificationMandatoryOrgs;
	}

	public void setAttachmentVerificationMandatoryOrgs(List<String> attachmentVerificationMandatoryOrgs)
	{
		this.attachmentVerificationMandatoryOrgs = attachmentVerificationMandatoryOrgs;
	}

	public String getEnableHighcharts()
	{
		return enableHighcharts;
	}

	public void setEnableHighcharts(String enableHighcharts)
	{
		this.enableHighcharts = enableHighcharts;
	}
	
	public Integer getHighchartsReqTypeMaxLength()
	{
		return highchartsReqTypeMaxLength;
	}



	public void setHighchartsReqTypeMaxLength(Integer highchartsReqTypeMaxLength)
	{
		this.highchartsReqTypeMaxLength = highchartsReqTypeMaxLength;
	}



	public Integer getHighchartsAssignedOwnerMaxLength()
	{
		return highchartsAssignedOwnerMaxLength;
	}



	public void setHighchartsAssignedOwnerMaxLength(Integer highchartsAssignedOwnerMaxLength)
	{
		this.highchartsAssignedOwnerMaxLength = highchartsAssignedOwnerMaxLength;
	}

	public List<UserGroupTO> getAllActiveGroups()
	{
		return allActiveGroups;
	}

	public void setAllActiveGroups(List<UserGroupTO> allActiveGroups)
	{
		this.allActiveGroups = allActiveGroups;
	}

	public boolean isShowReleaseDocument() {
		return showReleaseDocument;
	}

	public void setShowReleaseDocument(boolean showReleaseDocument) {
		this.showReleaseDocument = showReleaseDocument;
	}

	public String getCurrentReleaseDocumentName() {
		return currentReleaseDocumentName;
	}

	public void setCurrentReleaseDocumentName(String currentReleaseDocumentName) {
		this.currentReleaseDocumentName = currentReleaseDocumentName;
	}

	public Boolean getFitToMyResolution()
	{
		return fitToMyResolution;
	}

	public void setFitToMyResolution(Boolean fitToMyResolution)
	{
		this.fitToMyResolution = fitToMyResolution;
	}

	/**
	 * @return the profilePic
	 */
	public byte[] getProfilePic() {
		return profilePic;
	}

	/**
	 * @param profilePic the profilePic to set
	 */
	public void setProfilePic(byte[] profilePic) {
		this.profilePic = profilePic;
	}
	
	public List<String> getBlackListDomains()
	{
		return blackListDomains;
	}

	public void setBlackListDomains(List<String> blackListDomains)
	{
		this.blackListDomains = blackListDomains;
	}

	public Boolean getDisableAutoComplete()
	{
		return disableAutoComplete;
	}

	public void setDisableAutoComplete(Boolean disableAutoComplete)
	{
		this.disableAutoComplete = disableAutoComplete;
	}

	
	public String getEnableMakerCheckerForUnapprovedDomains() {
		return enableMakerCheckerForUnapprovedDomains;
	}

	
	public void setEnableMakerCheckerForUnapprovedDomains(String enableMakerCheckerForUnapprovedDomains) {
		this.enableMakerCheckerForUnapprovedDomains = enableMakerCheckerForUnapprovedDomains;
	}

	public List<String> getCitiDomainList() {
		return CitiDomainList;
	}

	public void setCitiDomainList(List<String> citiDomainList) {
		CitiDomainList = citiDomainList;
	}

	/**
	 * @return the highlevelRequestTypeList
	 */
	public List<String> getHighlevelRequestTypeList() {
		return highlevelRequestTypeList;
	}

	/**
	 * @param highlevelRequestTypeList the highlevelRequestTypeList to set
	 */
	public void setHighlevelRequestTypeList(List<String> highlevelRequestTypeList) {
		this.highlevelRequestTypeList = highlevelRequestTypeList;
	}

	/**
	 * @return the highlevelRequestTypeFlag
	 */
	public Boolean getHighlevelRequestTypeFlag() {
		return highlevelRequestTypeFlag;
	}

	/**
	 * @param highlevelRequestTypeFlag the highlevelRequestTypeFlag to set
	 */
	public void setHighlevelRequestTypeFlag(Boolean highlevelRequestTypeFlag) {
		this.highlevelRequestTypeFlag = highlevelRequestTypeFlag;
	}

	public Boolean getAttachmentPwdProtectionFlag()
	{
		return attachmentPwdProtectionFlag;
	}

	public void setAttachmentPwdProtectionFlag(Boolean attachmentPwdProtectionFlag)
	{
		this.attachmentPwdProtectionFlag = attachmentPwdProtectionFlag;
	}

	public Boolean getInquiryResponstTimeChartFlag() {
		return inquiryResponstTimeChartFlag;
	}

	public void setInquiryResponstTimeChartFlag(Boolean inquiryResponstTimeChartFlag) {
		this.inquiryResponstTimeChartFlag = inquiryResponstTimeChartFlag;
	}

	/**
	 * @return the countryList
	 */
	public List<Country> getCountryList() {
		return countryList;
	}

	/**
	 * @param countryList the countryList to set
	 */
	public void setCountryList(List<Country> countryList) {
		this.countryList = countryList;
	}

	/**
	 * @return the timeZones
	 */
	public List<TimeZone> getTimeZones() {
		return timeZones;
	}

	/**
	 * @param timeZones the timeZones to set
	 */
	public void setTimeZones(List<TimeZone> timeZones) {
		this.timeZones = timeZones;
	}

	public Map<String, List<HolidayMaster>> getHolidays() {
		return holidays;
	}

	public void setHolidays(Map<String, List<HolidayMaster>> holidays) {
		this.holidays = holidays;
	}

	public boolean isAgeBasedCalculation() {
		return isAgeBasedCalculation;
	}

	public void setAgeBasedCalculation(boolean isAgeBasedCalculation) {
		this.isAgeBasedCalculation = isAgeBasedCalculation;
	}

	public List<String> getMisExclusionReportNameList() {
		return misExclusionReportNameList;
	}

	public void setMisExclusionReportNameList(List<String> misExclusionReportNameList) {
		this.misExclusionReportNameList = misExclusionReportNameList;
	}

	public List<String> getMisExclusionReasonList() {
		return misExclusionReasonList;
	}

	public void setMisExclusionReasonList(List<String> misExclusionReasonList) {
		this.misExclusionReasonList = misExclusionReasonList;
	}

	public List<String> getMyCoverage() {
		return myCoverage;
	}

	public void setMyCoverage(List<String> myCoverage) {
		this.myCoverage = myCoverage;
	}

	public Map<String, Boolean> getNotificationSettings() {
		return notificationSettings;
	}

	public void setNotificationSettings(Map<String, Boolean> notificationSettings) {
		this.notificationSettings = notificationSettings;
	}

	public Map<String, Object> getOutOfOfficeSettings() {
		return outOfOfficeSettings;
	}

	public void setOutOfOfficeSettings(Map<String, Object> outOfOfficeSettings) {
		this.outOfOfficeSettings = outOfOfficeSettings;
	}
	
	public List<ViewFilters> getViewFilters() {
		return viewFilters;
	}

	public void setViewFilters(List<ViewFilters> viewFilters) {
		this.viewFilters = viewFilters;
	}
	
	public Integer getWebSocketUpdateRows() {
		return webSocketUpdateRows;
	}

	public void setWebSocketUpdateRows(Integer webSocketUpdateRows) {
		this.webSocketUpdateRows = webSocketUpdateRows;
	}

	public List<String> getDefaultClientCategories() {
		return defaultClientCategories;
	}

	public void setDefaultClientCategories(List<String> defaultClientCategories) {
		this.defaultClientCategories = defaultClientCategories;
	}

	public String getPreviousDayBoxCount() {
		return previousDayBoxCount;
	}

	public void setPreviousDayBoxCount(String previousDayBoxCount) {
		this.previousDayBoxCount = previousDayBoxCount;
	}

	public List<String> getDefaultViewsInQMA() {
		return defaultViewsInQMA;
	}

	public void setDefaultViewsInQMA(List<String> defaultViewsInQMA) {
		this.defaultViewsInQMA = defaultViewsInQMA;
	}

	public String getTinyMCEUrl() {
		return tinyMCEUrl;
	}

	public void setTinyMCEUrl(String tinyMCEUrl) {
		this.tinyMCEUrl = tinyMCEUrl;
	}

	public List<ClientCategory> getClientCategories() {
		return clientCategories;
	}

	public void setClientCategories(List<ClientCategory> clientCategories) {
		this.clientCategories = clientCategories;
	}

	public Map<String, Object> getCvWebsocketConfig() {
		return cvWebsocketConfig;
	}

	public void setCvWebsocketConfig(Map<String, Object> cvWebsocketConfig) {
		this.cvWebsocketConfig = cvWebsocketConfig;
	}

	public String getUserAuthKey() {
		return userAuthKey;
	}

	public void setUserAuthKey(String userAuthKey) {
		this.userAuthKey = userAuthKey;
	}

	/**
	 * @return the dashboardCountRefreshIntervalInMs
	 */
	public Long getDashboardCountRefreshIntervalInMs() {
		return dashboardCountRefreshIntervalInMs;
	}

	/**
	 * @param dashboardCountRefreshIntervalInMs the dashboardCountRefreshIntervalInMs to set
	 */
	public void setDashboardCountRefreshIntervalInMs(Long dashboardCountRefreshIntervalInMs) {
		this.dashboardCountRefreshIntervalInMs = dashboardCountRefreshIntervalInMs;
	}

	public Map<String, Object> getQmaUI2Config() {
		return qmaUI2Config;
	}

	public void setQmaUI2Config(Map<String, Object> qmaUI2Config) {
		this.qmaUI2Config = qmaUI2Config;
	}

	public String getLongDesc() {
		return longDesc;
	}

	public void setLongDesc(String longDesc) {
		this.longDesc = longDesc;
	}

	public Map<String, Object> getGlobalDirectoryConfig() {
		return globalDirectoryConfig;
	}

	public void setGlobalDirectoryConfig(Map<String, Object> globalDirectoryConfig) {
		this.globalDirectoryConfig = globalDirectoryConfig;
	}

	public Map<String, Object> getSymphonyConfig() {
		return symphonyConfig;
	}

	public void setSymphonyConfig(Map<String, Object> symphonyConfig) {
		this.symphonyConfig = symphonyConfig;
	}

	public String getSymphonyId() {
		return symphonyId;
	}

	public void setSymphonyId(String symphonyId) {
		this.symphonyId = symphonyId;
	}

	public String getSymphonyEmailId() {
		return symphonyEmailId;
	}

	public void setSymphonyEmailId(String symphonyEmailId) {
		this.symphonyEmailId = symphonyEmailId;
	}

	public Map<String, SymphonyUserMapTO> getUserSymphonyIdToUserMap() {
		return userSymphonyIdToUserMap;
	}

	public void setUserSymphonyIdToUserMap(Map<String, SymphonyUserMapTO> userSymphonyIdToUserMap) {
		this.userSymphonyIdToUserMap = userSymphonyIdToUserMap;
	}

	public void setIsSymphonyEnabledForUser(String isSymphonyEnabledForUser) {
		this.isSymphonyEnabledForUser = isSymphonyEnabledForUser;
	}

	public String getIsSymphonyEnabledForUser() {
		return isSymphonyEnabledForUser;
	}

	public void setPersonalMailboxGrpId(Long personalMailboxGrpId) {
		this.personalMailboxGrpId = personalMailboxGrpId;
	}

	public Long getPersonalMailboxGrpId() {
		return personalMailboxGrpId;
	}

	public Boolean getCalendarSubscribed() {
		return calendarSubscribed;
	}

	public void setCalendarSubscribed(Boolean calendarSubscribed) {
		this.calendarSubscribed = calendarSubscribed;
	}

	public Boolean getPersonalEmailSubscribed() {
		return personalEmailSubscribed;
	}

	public void setPersonalEmailSubscribed(Boolean personalEmailSubscribed) {
		this.personalEmailSubscribed = personalEmailSubscribed;
	}

	public String getExchUrl() {
		return exchUrl;
	}

	public void setExchUrl(String exchUrl) {
		this.exchUrl = exchUrl;
	}

	public String getExchDomain() {
		return exchDomain;
	}

	public void setExchDomain(String exchDomain) {
		this.exchDomain = exchDomain;
	}

	public List<String> getSubjectFlagwords() {
		return subjectFlagwords;
	}

	public void setSubjectFlagwords(List<String> subjectFlagwords) {
		this.subjectFlagwords = subjectFlagwords;
	}

	public List<String> getExchangeAccountHosts() {
		return exchangeAccountHosts;
	}

	public void setExchangeAccountHosts(List<String> exchangeAccountHosts) {
		this.exchangeAccountHosts = exchangeAccountHosts;
	}

	public List<String> getRestrictedFileExtensions() {
		return restrictedFileExtensions;
	}

	public void setRestrictedFileExtensions(List<String> restrictedFileExtensions) {
		this.restrictedFileExtensions = restrictedFileExtensions;
	}
  
 	public List<String> getAllowedFileExtensions() {
		return allowedFileExtensions;
	}

	public void setAllowedFileExtensions(List<String> allowedFileExtensions) {
		this.allowedFileExtensions = allowedFileExtensions;
	}

	public List<String> getBlockedFileNameCharacters() {
		return blockedFileNameCharacters;
	}

	public void setBlockedFileNameCharacters(List<String> blockedFileNameCharacters) {
		this.blockedFileNameCharacters = blockedFileNameCharacters;
	}
	public Map<String, Object> getSessionConfig() {
		return sessionConfig;
	}

	public void setSessionConfig(Map<String, Object> sessionConfig) {
		this.sessionConfig = sessionConfig;
	}

	/**
	 * @return the custodyAccounts
	 */
	public List<String> getCustodyAccounts() {
		return custodyAccounts;
	}

	/**
	 * @param custodyAccounts the custodyAccounts to set
	 */
	public void setCustodyAccounts(List<String> custodyAccounts) {
		this.custodyAccounts = custodyAccounts;
	}
	
	public Map<String, Object> getQma2RedirectPopupConfig() {
		return qma2RedirectPopupConfig;
	}

	public void setQma2RedirectPopupConfig(Map<String, Object> qma2RedirectPopupConfig) {
		this.qma2RedirectPopupConfig = qma2RedirectPopupConfig;
	}

	/**
	 * @return the enableAmcarIntegration
	 */
	public Boolean getEnableAmcarIntegration() {
		return enableAmcarIntegration;
	}

	/**
	 * @param enableAmcarIntegration the enableAmcarIntegration to set
	 */
	public void setEnableAmcarIntegration(Boolean enableAmcarIntegration) {
		this.enableAmcarIntegration = enableAmcarIntegration;
	}

	public List<OrgMetaDataAdminRole> getOrgAdminRole() {
		return orgAdminRole;
	}

	public void setOrgAdminRole(List<OrgMetaDataAdminRole> orgAdminRole) {
		this.orgAdminRole = orgAdminRole;
	}

	public List<String> getAutoAssignmentRollOutOrgsList() {
		return autoAssignmentRollOutOrgsList;
	}

	public void setAutoAssignmentRollOutOrgsList(List<String> autoAssignmentRollOutOrgsList) {
		this.autoAssignmentRollOutOrgsList = autoAssignmentRollOutOrgsList;
	}
	public List<Map<String, Object>> getViewDateRangeConfig() {
		return viewDateRangeConfig;
	}

	public void setViewDateRangeConfig(List<Map<String, Object>> viewDateRangeConfig) {
		this.viewDateRangeConfig = viewDateRangeConfig;
	}

	public boolean isPivotProConfigEnabled() {
		return pivotProConfigEnabled;
	}

	public void setPivotProConfigEnabled(boolean pivotProConfigEnabled) {
		this.pivotProConfigEnabled = pivotProConfigEnabled;
	}

	public boolean getAuthenticationExpired() {
		return isAuthenticationExpired;
	}

	public void setAuthenticationExpired(boolean authenticationExpired) {
		isAuthenticationExpired = authenticationExpired;
	}

	public boolean isPersonalAccountActive() {
		return isPersonalAccountActive;
	}

	public void setPersonalAccountActive(boolean personalAccountActive) {
		isPersonalAccountActive = personalAccountActive;
	}

	public List<String> getInquirySubStatusList() {
		return inquirySubStatusList;
	}

	public void setInquirySubStatusList(List<String> inquirySubStatusList) {
		this.inquirySubStatusList = inquirySubStatusList;
	}

	public Boolean getIsInquirySubStatusEnabledAtOrg() {
		return isInquirySubStatusEnabledAtOrg;
	}

	public void setIsInquirySubStatusEnabledAtOrg(Boolean isInquirySubStatusEnabledAtOrg) {
		this.isInquirySubStatusEnabledAtOrg = isInquirySubStatusEnabledAtOrg;
	}

	public Boolean getEnableInquirySubStatusFlag() {
		return enableInquirySubStatusFlag;
	}

	public void setEnableInquirySubStatusFlag(Boolean enableInquirySubStatusFlag) {
		this.enableInquirySubStatusFlag = enableInquirySubStatusFlag;
	}

	public String getPsL5() {
		return psL5;
	}

	public void setPsL5(String psL5) {
		this.psL5 = psL5;
	}

	public String getPsL6() {
		return psL6;
	}

	public void setPsL6(String psL6) {
		this.psL6 = psL6;
	}

	public String getPsL7() {
		return psL7;
	}

	public void setPsL7(String psL7) {
		this.psL7 = psL7;
	}

	public String getMsL6() {
		return msL6;
	}

	public void setMsL6(String msL6) {
		this.msL6 = msL6;
	}
  
  	public boolean isGdActive() {
		return gdActive;
	}

	public void setGdActive(boolean gdActive) {
		this.gdActive = gdActive;
	}

	public List<String> getProductFamily() {
		return productFamily;
	}

	public void setProductFamily(List<String> productFamily) {
		this.productFamily = productFamily;
	}

	public Map<String, Long> getProductFamilyGroupIdMap() {
		return productFamilyGroupIdMap;
	}

	public void setProductFamilyGroupIdMap(Map<String, Long> productFamilyGroupIdMap) {
		this.productFamilyGroupIdMap = productFamilyGroupIdMap;
	}

	public String getEnableBrazilFxIntegration() {
		return enableBrazilFxIntegration;
	}

	public void setEnableBrazilFxIntegration(String enableBrazilFxIntegration) {
		this.enableBrazilFxIntegration = enableBrazilFxIntegration;
	}

	public String getEnableManualDeLinkEntity() {
		return enableManualDeLinkEntity;
	}

	public void setEnableManualDeLinkEntity(String enableManualDeLinkEntity) {
		this.enableManualDeLinkEntity = enableManualDeLinkEntity;
	}

	public String getEnableManualLinkEntity() {
		return enableManualLinkEntity;
	}

	public void setEnableManualLinkEntity(String enableManualLinkEntity) {
		this.enableManualLinkEntity = enableManualLinkEntity;
	}

	public Integer getSearchInDays() {
		return searchInDays;
	}

	public void setSearchInDays(Integer searchInDays) {
		this.searchInDays = searchInDays;
	}
	public Map<String, Object> getideationConfig() {
		return ideationConfig;
	}
	public void setideationConfig(Map<String, Object> ideationConfig) {
		this.ideationConfig = ideationConfig;
	}

	public String getBussinessStartDate() {
		return bussinessStartDate;
	}

	public void setBussinessStartDate(String bussinessStartDate) {
		this.bussinessStartDate = bussinessStartDate;
	}


	public String getIsTaskizeEnabledForUser() {
		return isTaskizeEnabledForUser;
	}

	public void setIsTaskizeEnabledForUser(String isTaskizeEnabledForUser) {
		this.isTaskizeEnabledForUser = isTaskizeEnabledForUser;
	}
	
	public List<String> getIntentList() {
		return intentList;
	}

	public void setIntentList(List<String> intentList) {
		this.intentList = intentList;
	}

	public Map<String, Object> getDefaultViewPerformanceConfig() {
		return defaultViewPerformanceConfig;
	}

	public void setDefaultViewPerformanceConfig(Map<String, Object> defaultViewPerformanceConfig) {
		this.defaultViewPerformanceConfig = defaultViewPerformanceConfig;
	}
	public Map<String, String> getMsExchangeServerConfigMap() {
		return msExchangeServerConfigMap;
	}

	public void setMsExchangeServerConfigMap(Map<String, String> msExchangeServerConfigMap) {
		this.msExchangeServerConfigMap = msExchangeServerConfigMap;
	}

}
