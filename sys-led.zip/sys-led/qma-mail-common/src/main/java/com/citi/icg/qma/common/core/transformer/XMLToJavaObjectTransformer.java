package com.citi.icg.qma.common.core.transformer;

import java.beans.XMLDecoder;
import java.io.ByteArrayInputStream;

import org.apache.commons.collections4.Transformer;

public class XMLToJavaObjectTransformer implements Transformer
{
	public Object transform(Object object) throws TransformationExcept
	{
		Object javaObject = null;
		try
		{
			XMLDecoder decoder = new XMLDecoder(new ByteArrayInputStream(object.toString().getBytes()));
        	javaObject = decoder.readObject();
		}
		catch(Exception e)
		{
			throw new TransformationExcept(e.getMessage(), e);
		}
		
		return javaObject;
	}
}
