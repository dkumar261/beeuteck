package com.citi.icg.qma.common.server.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.*;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import jakarta.mail.internet.MimeUtility;
import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.bson.json.JsonMode;
import org.bson.json.JsonWriterSettings;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.core.util.QmaMailConstants;
import com.citi.icg.qma.common.server.aws.util.AWSUtility;
import com.citi.icg.qma.common.server.dao.Attachment;
import com.citi.icg.qma.common.server.dao.ClientAuthorization;
import com.citi.icg.qma.common.server.dao.ColumnDef;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.SequenceId;
import com.citi.icg.qma.common.server.dao.StaticData;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.persistence.AttachmentDAO;
import com.citi.icg.qma.common.server.dao.persistence.GenericDAO;
import com.citi.icg.qma.common.server.dao.persistence.MongoDB;
import com.citi.icg.qma.common.server.dao.persistence.UserDAO;
import com.citi.icg.qma.common.transferobject.ColumnDefUI;
import com.citi.icg.qma.common.transferobject.ConversationTO;
import com.citi.icg.qma.exception.ApiAuthenticationException;
import com.citi.icg.qma.exception.ApiAuthorizationException;
import com.citi.icg.qma.exception.ApiBadRequestException;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

import dev.morphia.Datastore;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

public class GenericUtility
{
	
	private static final char CHAR_TO_BE_REPLACED_FOR_BLOCKED_CHARACTER = '_';
	private static final String AGE_BAND = "ageBand";
	private static final AttachmentDAO aDao = new AttachmentDAO();
	public static final String HEADER_PORTAL_LOGIN = "XXXXX";	
	public static final String HEADER_ALT_PORTAL_LOGIN = "XXXXX";
	public static final String HEADER_QMA_LOGIN_SOEID = "qmaLoginUserId";
	public static final String HEADER_QMA_LOGIN_GEID = "XXXXX";
	public static final String CLIENT_ID = "clientId";
	public static final String CLIENT_KEY = "clientKey";
	private static final String APP_API_SUBSCRIPTION_MAPPING = "applicationAPISubscription";
	public static final String USER_ID = "userId";
	//protected static Logger logger = null;//Sonar Fix -- Make logger a static final constant or non-public and provide accessors if needed..
	/*Sonar scan fix : renamed LOGGER to _LOGGER to avoid name conflict between following variable and variable declared above*/
	//private static final Logger UTILITY_LOGGER = Logger.getLogger(GenericUtility.class);//Sonar Fix -- Standard outputs should not be used directly to log anything
//	private static Logger UTILITY_LOGGER = Logger.getLogger("XStreamCommunicator");
	private static final Logger logger = LoggerFactory.getLogger(GenericUtility.class);
	public static final String INVALID_EMAIL_PATTERN_BEFORE_DOMAIN = "[^a-zA-Z0-9!#$%&'*+-/=?^_`{|}~.]+";
	public static final String INVALID_EMAIL_PATTERN_AFTER_DOMAIN = "[^\\w\\.\\-]";
	public static final String OPERATOR_EQUALS ="equal";
	public static final String SENDER_COMPONENT_ID = "QMA";
	private static final String[] secureFileExtensions = new String[]{"PDF","ZIP","XLS","XLSX","DOC","DOCX","PPT","PPTX"};
	private static final List secureFileExtensionList=Arrays.asList(secureFileExtensions);
	private static final Pattern EMAIL_REGEX_PATTERN = Pattern.compile(
	            "^([\\w!#$%&'*+\\-\\/=?^`{|}~]+(\\.[\\w!#$%&'*+\\-\\/=?^`{|}~]+)*)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([\\w]+(\\-[\\w]+)*\\.)+[a-zA-Z]{2,}))$",
	            Pattern.CASE_INSENSITIVE);
	private static final String INLINE_IMAGE_PATTERN = "<img.*?>";
	private static final String IMAGE_FILEID_PATTERN = "path=.*?>";
	public  static final GenericDAO genericDAO = new GenericDAO();
	private static final String ASSIGNED_GROUP_ID_KEY = "assignedGroupId";
	private static final String AGE_IN_DAYS_KEY = "ageInDays";
	
	public static final String ALPHA_NUMERIC_REGEX = "^[a-zA-Z0-9]*$";
	public static final String NUMERIC_REGEX = "^[0-9]*$";
	public static final String FILE_NAME_INVALID_CHAR_1= "/";
	public static final String FILE_NAME_INVALID_CHAR_2= "\\\\";
	public static final String VALID_FILENAME_REGEX = "^[\\sa-zA-Z0-9._()-]*$";
	public static AWSUtility awsUtility = null;
	public static final char INVALID_CHARS[] = { '*', '?', '"', ';', ','};
    private static final char SANITIZED_CHAR = '_';
	private static final String BOOLEAN_STRING_FALSE = "false";
	private static final String BOOLEAN_STRING_TRUE = "true";
 	public static final String FOREIGN_FILENAME_REGEX = "[^a-zA-Z0-9-,._=@ ]+";
	private static final String ESCAPE_CHARS = "[\n\r\t]";
	private static final UserDAO userDao = new UserDAO();
	
	public static final String IS_QMA_CITI_CONTACT = "isQmaCitiContact";
	public static final String TASKIZE_FUNCTION = "taskizeFunction";
	public static final String TASKIZE_BUSINESS_UNIT = "taskizeBusinessUnit";
	public static final String TASKIZE_ORG_NAME = "taskizeOrgName";
	public static final String IS_DISPLAY_GROUP_MAPPING = "isDisplayGroupMapping";
	public static final String TASKIZE_CONFIG = "taskizeConfig";
	
	// Adding private constructor as this is an utility class and all methods are static
	// Sonar Fix for Utility classes should not have public constructors
	private GenericUtility()
	{
		
	}
	
	public static List<ColumnDefUI> modifyCriteriaForUIDisplay(List<ColumnDef> coldefs, boolean isQMA2Filters)
	{
		List<ColumnDefUI> dest = new ArrayList<ColumnDefUI>();
		if (coldefs != null)
		{
			for (ColumnDef columnDef : coldefs)
			{

				ColumnDefUI coldefUI = new ColumnDefUI();

				if ("id".equals(columnDef.getAttributeName()))
				{
					coldefUI.setId("_id");
				}
				else if ("folderName".equals(columnDef.getAttributeName()))
				{
					coldefUI.setId("userFolders.folderName");
				}
				else
				{
					coldefUI.setId(columnDef.getAttributeName());
				}

				coldefUI.setLabel(columnDef.getDisplayName());
				coldefUI.setDisableFilter(columnDef.getDisableFilter());
				coldefUI.setDisplayType(columnDef.getDisplayType());
				String type = columnDef.getDataType();

				if ("Number".equalsIgnoreCase(type))
				{
					coldefUI.setType("integer");
					String[] operators = { OPERATOR_EQUALS, "greater", "less" };
					coldefUI.setOperators(operators);
				}
				else if ("String".equalsIgnoreCase(type))
				{
					coldefUI.setType("string");
					String[] operators = { OPERATOR_EQUALS, "not_equal", "begins_with", "contains" };
					coldefUI.setOperators(operators);
				}
				else if ("Date".equalsIgnoreCase(type))
				{

					coldefUI.setType("date");
					coldefUI.setPlugin("datepicker");

					coldefUI.setPlugin_config(new HashMap());
					coldefUI.getPlugin_config().put("format", "yyyy/mm/dd");
					coldefUI.getPlugin_config().put("todayBtn", "linked");
					coldefUI.getPlugin_config().put("todayBtn", "linked");
					coldefUI.getPlugin_config().put("todayHighlight", true);
					coldefUI.getPlugin_config().put("autoclose", true);

					String[] operators = { "greater", "less", OPERATOR_EQUALS, "between" };
					coldefUI.setOperators(operators);

				}
				/*Ignoring 'memo' column for QMA2*/
				if ( ( "memo".equalsIgnoreCase(columnDef.getAttributeName()) || "age".equalsIgnoreCase(columnDef.getAttributeName()) ||
						"ageInHrs".equalsIgnoreCase(columnDef.getAttributeName()) || "reOpenAgeInHrs".equalsIgnoreCase(columnDef.getAttributeName()) ||
						"reOpenAge".equalsIgnoreCase(columnDef.getAttributeName()))
						&& isQMA2Filters) {
					continue;
				}
				
				if ("origUserName".equalsIgnoreCase(columnDef.getAttributeName()) && isQMA2Filters) {
					coldefUI.setLabel("Assigned From");
				}
				
				if ("openUsers".equalsIgnoreCase(columnDef.getAttributeName()) && isQMA2Filters) {
					coldefUI.setLabel("Assigned To");
				}

				dest.add(coldefUI);
			}
		}

		return dest;
	}

	/**
	 * This function will filter age columns from criteria for QMA2
	 * @param workFlowColumns
	 * @return
	 */
	public static List<ColumnDefUI> modifyWorkFlowColumns(List<ColumnDefUI> workFlowColumns,boolean isQMA2Filters) {
		List<ColumnDefUI> dest = new ArrayList<>();
		try {
			for(ColumnDefUI currentCol : workFlowColumns){
				if( "age".equalsIgnoreCase(currentCol.getLabel()) && isQMA2Filters ){
					continue;
				} else {
					dest.add(currentCol);
				}
			}
		} catch (Exception e) {
			logger.error("Exception while filtering workflow columns for QMA 2 :" ,e);
		}
		return dest;
	}

	public static List<ColumnDef> modifyCriteriaForDBSave(BasicDBList coldefsUI)
	{
		List<ColumnDef> dest = new ArrayList<ColumnDef>();
		if (coldefsUI != null)
		{
			int i = 0;
			for (Object coldefUI : coldefsUI)
			{

				BasicDBObject obj = (BasicDBObject) coldefUI;
				// Null check for non-matching fields
				if (obj != null)
				{
					ColumnDef coldef = new ColumnDef();
					coldef.setAttributeName(obj.getString("id"));
					coldef.setDisplayName(obj.getString("label"));
					coldef.setDisplayOrder(i++);
					coldef.setDisableFilter(obj.getString("disableFilter"));
					coldef.setDisplayType(obj.getString("displayType"));

					String type = obj.getString("type");
					if ("integer".equalsIgnoreCase(type))
					{
						coldef.setDataType("Number");
					}
					else if ("string".equalsIgnoreCase(type))
					{
						coldef.setDataType("String");
					}
					else if ("date".equalsIgnoreCase(type))
					{

						coldef.setDataType("Date");
					}

					dest.add(coldef);
				}
			}
		}

		return dest;
	}
	
	//It will Used for Custom Column Def WIndow for Default Boxes
	// It won't need any Data Type Conversion as it won't have ant Criteria and JQuery Tool For Generation of Criteria
	// Below method will Convert List of BasicDBObject to List of ColumnDef
	public static List<ColumnDef> modifyCriteriaForDefaultBoxDBSave(BasicDBList coldefs)
	{
		List<ColumnDef> dest = new ArrayList<ColumnDef>();
		if (coldefs != null)
		{
			int i = 0;
			for (Object inputObj : coldefs)
			{
				BasicDBObject columnDefObj = (BasicDBObject) inputObj;
				// Null check for non-matching fields
				if (columnDefObj != null)
				{
					ColumnDef coldef = new ColumnDef();
					coldef.setAttributeName(columnDefObj.getString("attributeName"));
					coldef.setDisplayName(columnDefObj.getString("displayName"));
					coldef.setDataType(columnDefObj.getString("dataType"));
					//Add width to customisation as well.
					coldef.setWidth(columnDefObj.get("width")!=null?columnDefObj.getLong("width"):150);
					coldef.setDisplayOrder(i++);
					coldef.setDisableFilter(columnDefObj.getString("disableFilter"));
					coldef.setDisplayType(columnDefObj.getString("displayType"));
					dest.add(coldef);
				}
			}
		}
		return dest;
	}

	/*
	 * Method Comment
	 * Exception handling
	 */
	public static void getPortalUserSoeidForApiAccess(HttpHeaders headers, String apiName) throws ApiAuthorizationException, ApiAuthenticationException, ApiBadRequestException {
		if (headers != null && headers.getRequestHeader(CLIENT_ID) != null && headers.getRequestHeader(CLIENT_KEY) != null) {
			String clientId = headers.getRequestHeader(CLIENT_ID).get(0);
			String clientKey = headers.getRequestHeader(CLIENT_KEY).get(0);
			logger.info("Request processing for client id:" + clientId);
			getClientAppIdAfterAuthentication(clientId, clientKey, apiName);
		} else {
			logger.error("Bad request: "+CLIENT_ID+" or "+CLIENT_KEY +" missing.");
			throw new ApiBadRequestException("Bad request: "+CLIENT_ID+" or "+CLIENT_KEY +" missing.");
		}
	}
	
	public static void validateAPIAccessForFID(String fid, BasicDBObject jsonRequest, String apiName)
			throws ApiAuthorizationException, ApiAuthenticationException, ApiBadRequestException {
		
		if (jsonRequest != null
				&& StringUtils.isNotBlank(fid)
				&& StringUtils.isNotBlank(jsonRequest.getString(CLIENT_KEY))) {
			String clientKey = jsonRequest.getString(CLIENT_KEY);
			logger.info("Request processing for client id: {}", fid);
			getClientAppIdAfterAuthentication(fid, clientKey, apiName);
		} else if (jsonRequest != null && StringUtils.isBlank(jsonRequest.getString("qma_fid"))) {
			String clientKey = getclientKeyForFid(fid);
			logger.info("Request processing for client id: {}", fid);
			getClientAppIdAfterAuthentication(fid, clientKey, apiName);
		} else {
			logger.error("Bad request: " + CLIENT_ID + " or " + CLIENT_KEY + " missing.");
			throw new ApiBadRequestException("Bad request: " + CLIENT_ID + " or " + CLIENT_KEY + " missing.");
		}
	}

	private static String getclientKeyForFid(String clientId) {
		String clientKey = "";
		QMACache qmaCache = QMACacheFactory.getCache();
		if (null != qmaCache.getConfigById(APP_API_SUBSCRIPTION_MAPPING) && null != qmaCache.getConfigById(APP_API_SUBSCRIPTION_MAPPING).getAppConfig()) {
			// Get QMA Config for Application API Subscription
			List<ClientAuthorization> appConfig = qmaCache.getConfigById(APP_API_SUBSCRIPTION_MAPPING).getAppConfig();
			Optional<ClientAuthorization> optionalConfig = appConfig.stream().filter(config -> config.getClientId().equalsIgnoreCase(clientId)).findAny();
			if(optionalConfig.isPresent()) {
				ClientAuthorization cientConfig = optionalConfig.get();
				clientKey = cientConfig.getClientSecretKey();
			}
		}
		return clientKey;
	}

	public static String getUserOrSystemName(String soeId, Map<String, User> userInfoMap) {
		logger.info("soeId: {}", soeId);
		String userName = "";
		if(null == soeId) {
			logger.info("soeId is: {}", soeId);
			return userName;
		}
		User user = userInfoMap.get(soeId.toUpperCase());
		
		if(null == user) {
			userName = getClientKey(soeId);
			
		}else {
			userName = user.getName();
		}
		return userName;
	}
	
	private static String getClientKey(String clientName) {
		boolean isClientPresent = false;
		if(StringUtils.isNotBlank(clientName) ) {
			QMACache qmaCache = QMACacheFactory.getCache();
			if (null != qmaCache.getConfigById(APP_API_SUBSCRIPTION_MAPPING) && null != qmaCache.getConfigById(APP_API_SUBSCRIPTION_MAPPING).getAppConfig()) {
				// Get QMA Config for Application API Subscription
				List<ClientAuthorization> appConfig = qmaCache.getConfigById(APP_API_SUBSCRIPTION_MAPPING).getAppConfig();
				for (ClientAuthorization clientAuthorization : appConfig) {
					if(clientName.equalsIgnoreCase(clientAuthorization.getClientId())) {
						isClientPresent = true;
						}
					}
				}
		}
		if(isClientPresent) 
			return clientName;
		return "";
	}

	
	/*
	 * Method Comment
	 * Exception handling
	 */
	public static String getClientDetailsForApiAccess(HttpHeaders headers, String apiName) throws ApiAuthenticationException, ApiAuthorizationException, ApiBadRequestException {
		String clientId = null;
		// Override with client/app login and secret key if available in the request
		if (headers != null && headers.getRequestHeader(CLIENT_ID) != null
				&& headers.getRequestHeader(CLIENT_KEY) != null) {
			clientId = headers.getRequestHeader(CLIENT_ID).get(0);
			String clientKey = headers.getRequestHeader(CLIENT_KEY).get(0);
			logger.info("Request processing for client id:" + clientId);
			boolean isAuthorized = getClientAppIdAfterAuthentication(clientId, clientKey, apiName);
			if (!isAuthorized) {
				clientId = null;
				logger.info("Unauthorized API");
			}
		}
		return clientId;
	}
	public static String validateSoeId(HttpHeaders headers) throws ApiAuthenticationException, ApiBadRequestException {
		String soeId = null;
		if (headers != null && headers.getRequestHeader(USER_ID) != null) {
			String soeIdFromHeader = headers.getRequestHeader(USER_ID).get(0);
			Map<String, User> userMap = QMACacheFactory.getCache().getUserInfoMap();
			User user = userMap.get(soeIdFromHeader.toUpperCase());
			if (null == user) {
				logger.info("Invalid soeid {}", soeIdFromHeader);
				throw new ApiAuthenticationException("Invalid soeid: " + soeIdFromHeader);
			} else if (user != null && !user.getActive()) {
				logger.info("Inactive soeId {}", soeIdFromHeader);
				throw new ApiAuthenticationException("Inactive soeid: " + soeIdFromHeader);
			} else {
				soeId = soeIdFromHeader;
			}
		} else {
			logger.info("Bad request: userId missing");
			throw new ApiBadRequestException("Bad request: userId missing");
		}
		return soeId;
	}
	
	public static String validateFID(String fidFromRequest) throws ApiAuthenticationException, ApiBadRequestException {
		String fid = null;
		if (StringUtils.isNotBlank(fidFromRequest)) {
			Map<String, User> userMap = QMACacheFactory.getCache().getUserInfoMap();
			User user = userMap.get(fidFromRequest.toUpperCase());
			if (null == user) {
				logger.info("Invalid fid {}", fidFromRequest);
				throw new ApiAuthenticationException("Invalid fid: " + fidFromRequest);
			} else if (user != null && !user.getActive()) {
				logger.info("Inactive fid {}", fidFromRequest);
				throw new ApiAuthenticationException("Inactive fid: " + fidFromRequest);
			} else {
				fid = fidFromRequest;
			}
		} else {
			logger.info("Bad request: userId missing");
			throw new ApiBadRequestException("Bad request: userId missing");
		}
		return fid;
	}
	
	public static String getClientId(HttpHeaders headers) {
		String clientId = "";
		if(null != headers.getRequestHeader("clientId")) {
			clientId = headers.getRequestHeader("clientId").get(0);
		}
		return clientId;
	}
	public static String getPortalUserSoeid(HttpHeaders headers)
	{
		String soeid = null;
		if(null != headers && null != headers.getRequestHeader(HEADER_PORTAL_LOGIN)) {
			logger.info("headers.getRequestHeader(HEADER_PORTAL_LOGIN).get(0) : "+headers.getRequestHeader(HEADER_PORTAL_LOGIN).get(0));
		}
		if(null != headers && null != headers.getRequestHeader(HEADER_QMA_LOGIN_SOEID)) {
			logger.info("headers.getRequestHeader(HEADER_QMA_LOGIN_SOEID).get(0) : "+headers.getRequestHeader(HEADER_QMA_LOGIN_SOEID).get(0));
		}
		if(null != headers && null != headers.getRequestHeader(HEADER_ALT_PORTAL_LOGIN)) {
			logger.info("headers.getRequestHeader(HEADER_ALT_PORTAL_LOGIN).get(0) : "+headers.getRequestHeader(HEADER_ALT_PORTAL_LOGIN).get(0));
		}
		
		if (headers != null && headers.getRequestHeader(HEADER_PORTAL_LOGIN) != null)
		{
			soeid = headers.getRequestHeader(HEADER_PORTAL_LOGIN).get(0);
		}
		if (headers != null && headers.getRequestHeader(HEADER_ALT_PORTAL_LOGIN) != null)
		{
			soeid = headers.getRequestHeader(HEADER_ALT_PORTAL_LOGIN).get(0);
		}
		
		// Override with  qma login userId if available in the request
		String currentEnv = System.getProperty("icg.env");
		if (StringUtils.isNotEmpty(currentEnv)) {
			currentEnv = currentEnv.toLowerCase();
			if (currentEnv.contains("dev") && headers != null && headers.getRequestHeader(HEADER_QMA_LOGIN_SOEID) != null) {
			soeid = headers.getRequestHeader(HEADER_QMA_LOGIN_SOEID).get(0);
		}

			if (StringUtils.isEmpty(soeid)) {
				if (currentEnv.contains("dev") || currentEnv.contains("uat")) {
					String OS = System.getProperty("os.name");
					if (StringUtils.isNotEmpty(OS)) {
						OS = OS.toLowerCase();
						if (OS.contains("windows") || OS.contains("mac") || OS.contains("linux")) {
							soeid = System.getProperty("user.name");
						}
					}				
				}			
			}
		}
		
		if(!("prod").equalsIgnoreCase(System.getProperty("icg.env")) && headers!=null){
			logger.info("Env->" + System.getProperty("icg.env")+" , Soeid is:" + soeid 
					+"  CV Header "+ HEADER_PORTAL_LOGIN+" =" +headers.getRequestHeader(HEADER_PORTAL_LOGIN)
					+"  CV Header ALT "+ HEADER_ALT_PORTAL_LOGIN+" =" +headers.getRequestHeader(HEADER_ALT_PORTAL_LOGIN));
		}
	
		if (StringUtils.isNotEmpty(soeid)) {
			logger.info("identified user : {}", soeid);
		} else {
			logger.warn("identified user : No user ID found");
		}

		return soeid;
	}
	
	public static String getGeidFromHeader(HttpHeaders headers)
	{
		String geid = null;
		
		if (headers != null && headers.getRequestHeader(HEADER_QMA_LOGIN_GEID) != null)
		{
			geid = headers.getRequestHeader(HEADER_QMA_LOGIN_GEID).get(0);
			logger.info("geid from cv portal is : "+ geid);
		}
		if (geid == null && ("dev").equalsIgnoreCase(System.getProperty("icg.env")))
		{
			logger.info("geid from cv portal not found and seting up as local for dev env : "+ geid); 
			geid = "1010723852";
		}
		
		return geid;

	}

	

	private static boolean getClientAppIdAfterAuthentication(String clientId, String clientKey,String apiName) throws ApiAuthorizationException, ApiAuthenticationException {
		return genericDAO.getClientAppIdAfterAuthentication(clientId, clientKey,apiName);
	}
	/*
	//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one.
	private static void loadLog4j() throws CommunicatorException
	{
		InputStream inputStream = null;
		Properties props = new Properties();
		
		try	
		{
			inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("log4j.properties");
			props.load(inputStream);
			PropertyConfigurator.configure(props);
		}
		catch (IOException e) 
		{
			//Sonar Fix -- Either log or rethrow this exception
			throw new CommunicatorException("IOException in Loading Log4J file...." ,e);
		}
		finally
		{
			if (inputStream != null)
			{
				try
				{
					inputStream.close();
				} 
				catch (IOException e)
				{
					logger.error("Error in loadLog4j" , e);
				}

			}
		}

	}

	
	public static Logger getLogger()
	{
		if (logger == null)
		{
			try
			{
				loadLog4j();
			}
			catch (Exception e)
			{
				//Sonar Fix -- Either log or rethrow this exception
				logger.error("Error in loading Logback Property file...." + e);
			}
			//logger = LoggerFactory.getLogger(GenericUtility.class);
			logger.info("Logback Startted");

		}

		return logger;

	}
*/
	public static List<Long> getIdListFromRequest(BasicDBObject inputJsonObj, String inputFieldName) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{

		List<Long> valueList = new ArrayList<Long>();
		Object list = inputJsonObj.get(inputFieldName);
		if (list instanceof List<?> inputList)
		{
			for (Object inputObj : inputList)
			{
				Long id = convertIdFromRequest(inputObj);
				valueList.add(id);
			}
		}

		return valueList;
	}

	public static Long getIdFromRequest(BasicDBObject inputJsonObj,
			String inputFieldName) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{

		Object objId = inputJsonObj.get(inputFieldName);
		return convertIdFromRequest(objId);
	}

	public static Long convertIdFromRequest(Object objId)
	{

		Long id = null;
		if (objId == null)
		{
			return null;
		}
		else if (objId instanceof Integer integer)
		{
			id = integer.longValue();
		}
		else if (objId instanceof String string)
		{
			id = Long.valueOf(string);
		}
		else
		{
			id = (Long) objId;
		}
		return id;
	}
	public static Integer convertLongToIntFromBSON(Object objId)
	{

		Integer id = null;
		try{
		if (objId == null)
		{
			return null;
		}
		else if (objId instanceof Integer integer)
		{
			id = integer;
		}
		else if (objId instanceof Long long1)
		{
			id = long1.intValue();
		}
		else if (objId instanceof String string)
		{
			id = Integer.parseInt(string);
		}
		}catch(Exception e){
			logger.info("Exception in Convert to Int" + e);
		}
		return id;
	}

	public static void pause(long millis)

	{
		// give pause for some time and read message again.
		try
		{
			Thread.sleep(millis);
		}
		catch (InterruptedException iex2)
		{
			logger.info("Thread Interrupted " + iex2);
		}
	}
	
	public static List<String> getCaseInsensitiveSortedList(List<String> stringList)// Sonar Fix - reduce the no of line of anonymous class max to 20
	{
		if(stringList==null || stringList.isEmpty()){
			return stringList;
		}
		Collections.sort(stringList, new Comparator<String>() 
		{
			@Override//Sonar fix -- Add the "@Override" annotation above this method signature
			public int compare(final String o1, final String o2)
			{
				if (o1 == null)
					return -1;
				if (o2 == null)
					return 1;
				final String obj1 = o1.toUpperCase();
				final String obj2 = o2.toUpperCase();
				if (obj1 == obj2)
				{
					return 0;
				}
				return obj1.compareTo(obj2);
			}
		});
		return stringList;
	}
	
	/**
	 * @param emailAddress
	 * @return
	 * Get the list of citidomains form config collection and returns true if the requested 
	 * email is part of citi domain. 
	 */
	public static boolean  isCitiDomainEmail(String emailAddress)
	{
		boolean isCitiDomain = false;

		List <String> citiDomainEmailList  = genericDAO.getListOfCitiDomain();
		if (StringUtils.isNotBlank(emailAddress) && emailAddress.indexOf('@') > -1 )
		{
			for (String citiDomain: citiDomainEmailList)
			{
				if(emailAddress.toUpperCase().endsWith(citiDomain)){
					isCitiDomain = true;
					break;
				}
			}
		}
		return isCitiDomain;
	}
	
	
	public static boolean isEmailRoutedFromInternal(List<String> toCCGroupCodes)
	{
		//boolean routingGrpFlag=QmaMailConstants.STRING_YES.equalsIgnoreCase(CacheDAO.getInstance().getDefaultStaticData().getEnableInternalGroupEmailRouting());
		boolean routingGrpFlag=QmaMailConstants.STRING_YES.equalsIgnoreCase(QMACacheFactory.getCache().getEnableInternalGroupEmailRouting());
		
		//Inclusion Filter is null or empty- no need to match-default match as true- set routing for all
		//Else atleast one TO/CC Grp should match filter grps configured in static data
		//List<String> grpRoutingInclusionList = CacheDAO.getInstance().getDefaultStaticData().getInternalGrpRoutingInclusionList();
		List<String> grpRoutingInclusionList = QMACacheFactory.getCache().getInternalGrpRoutingInclusionList();
		boolean routingGrpFilterMatch=matchRoutingGrpFilter(toCCGroupCodes, grpRoutingInclusionList);
		
		//Routing is enabled based on Routing flag && groupFilter Match
		boolean routingEnabled=routingGrpFlag && routingGrpFilterMatch;
		
		logger.info("Routing Grp Flag = " + routingGrpFlag + " ,grpRoutingInclusionList = " + grpRoutingInclusionList + " , toCCGroupCodes received = " + toCCGroupCodes
				+ " , Routing Enabled for this conversation email = " + routingEnabled);
		
		return routingEnabled;
	}

	private static boolean matchRoutingGrpFilter(List<String> toCCGroupCodes, List<String> routedGroupCodesFilterList)
	{
		boolean routingGrpFilterMatched = true;
		
		//Inclusion Filter is null or empty- no need to match-default match as true- set routing for all
		//Else atleast one TO/CC Grp should match filter grps configured in static data
		if (null != routedGroupCodesFilterList && !routedGroupCodesFilterList.isEmpty() &&  ! containsOne(routedGroupCodesFilterList, toCCGroupCodes))
		{
			routingGrpFilterMatched=false;
		}
		return routingGrpFilterMatched;
	}

	public static boolean containsOne(Collection<?> collectionSrc, Collection<?> collectionDest)
	{
		if (null != collectionSrc && null != collectionDest)
		{
			Iterator localIterator = collectionDest.iterator();
			while (localIterator.hasNext())
			{
				Object localObject = localIterator.next();
				if (collectionSrc.contains(localObject))
				{
					return true;
				}
			}
		}
		return false;
	}

	public static SequenceId generateSequenceId(String sequenceName)
	{
		Datastore mongoDatastore = MongoDB.instance().getDataStore();
		final Query<SequenceId> q = mongoDatastore.find(SequenceId.class, "_id", sequenceName);
		final UpdateOperations<SequenceId> uOps = mongoDatastore.createUpdateOperations(SequenceId.class).inc("value");
		SequenceId seq=mongoDatastore.findAndModify(q, uOps,true);
		if(seq==null)
		{
			 mongoDatastore.update(q, uOps,true);
			 seq=mongoDatastore.findAndModify(q, uOps,true);
		}
		return seq;
	}
	
	public static List<BasicDBObject> getJsonObjFromRequest(BasicDBObject inputJsonObj, String inputFieldName) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception
	{

		List<BasicDBObject> valueList = new ArrayList<BasicDBObject>();
		Object list = inputJsonObj.get(inputFieldName);
		if (list instanceof List<?> inputList)
		{
			for (Object inputObj : inputList)
			{
				try
				{
					valueList.add((BasicDBObject) inputObj);
				}
				catch (Exception e)
				{
					// Try next object in the list
				}
			}
		}

		return valueList;
	}

	
	public static byte[] convertStringToHex(String str){

		byte[] encodedHexB64 =null;
		try
		{
			byte[] decodedHex = Hex.decodeHex(str.toCharArray());
			encodedHexB64= Base64.encodeBase64(decodedHex);
			
		}
		catch (Exception e)
		{
			logger.error("Error happened in Convert String to Hex Value ",e);
		}
		
		return encodedHexB64;
	  }
	public static void main (String args[])
	{
		byte[] encodedHexB64 = convertStringToHex("09021b5e8074e446");
		

		ObjectId objId = new ObjectId(encodedHexB64);
		
	}
	
	public static void closeInputStream(InputStream inputStream)
	{
		try
		{
			if(inputStream != null)
			{
				inputStream.close();
			}
		}
		catch (IOException e)
		{
			logger.error("Issue while closing input stream " , e);
		}
	}
	
	/*
	 * FileNameWithFullPath must be passed, below is the example
	 * fileNameWithFullPath=/export/vol01/enterprise-docs/XMWorkstation/XMWORKSTATION_APP/ravitest.pdf
	 */
	public void writeFileInUnix(File file, String fileNameWithFullPath)
	{
		logger.info("Read file started !! for " + fileNameWithFullPath);
		File outFile = new File("/export/vol01/enterprise-docs/XMWorkstation/XMWORKSTATION_APP/ravitest.pdf");

		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try
		{
			fis = new FileInputStream(file);
			bis = new BufferedInputStream(fis);
			fos = new FileOutputStream(outFile);
			bos = new BufferedOutputStream(fos);

			byte[] buf = new byte[1024];

			while (true)
			{
				int len = bis.read(buf);
				if (len == -1)
					break;
				bos.write(buf, 0, len);
			}
			bos.flush();
		}
		catch (Exception e)
		{
			logger.error("Exception : MongoMailSenderThread writeFileInUnix() : " + e);// Sonar Fix -- Throwable.printStackTrace(...) should not be called
		} finally {
			/*Sonar scan fix : closing all the streams used for IO operations */
			try {
				if(fos!=null)
				fos.close();
			} catch (IOException ex) {
				logger.error("Exception : MongoMailSenderThread writeFileInUnix() : " + ex);
			}
			try {
				if(fis!=null)
				fis.close();
			} catch (IOException ex) {
				logger.error("Exception : MongoMailSenderThread writeFileInUnix() : " + ex);
			}
			try {
				if(bos!=null)
				bos.close();
			} catch (IOException ex) {
				logger.error("Exception : MongoMailSenderThread writeFileInUnix() : " + ex);
			}
			try {
				if(bis!=null)
				bis.close();
			} catch (IOException ex) {
				logger.error("Exception : MongoMailSenderThread writeFileInUnix() : " + ex);
			}
		}
	}
	
	public static MessageDigest getMessageDigest()
	{
		// Use MD5 algorithm
		MessageDigest md5Digest=null;
		try
		{
			md5Digest = MessageDigest.getInstance("MD5");
		}
		catch (NoSuchAlgorithmException nsae)
		{
			// TODO Auto-generated catch block
			logger.error("Error while loading the MD5 message digest "+nsae);
		}
		
		return md5Digest;
	}
	
	public static String calculateChecksum(InputStream in) throws IOException
	{
		String checkSum = null;
		if (in.markSupported())
		{
			in.mark(Integer.MAX_VALUE);
			MessageDigest digest = getMessageDigest();
			if(null == digest) { // <-- sonar fix null pointer
				return checkSum;
			}
			// Create byte array to read data in chunks
			byte[] byteArray = new byte[1024];
			int bytesCount = 0;
			// Read file data and update in message digest
			while ((bytesCount = in.read(byteArray)) != -1)
			{
				digest.update(byteArray, 0, bytesCount);
			}
			// Get the hash's bytes
			byte[] bytes = digest.digest();
			// This bytes[] has bytes in decimal format;
			// Convert it to hexadecimal format
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < bytes.length; i++)
			{
				sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
			}
			in.reset();
			checkSum = sb.toString();
		}
		logger.info("MD5 file checksum= " + checkSum);

		return checkSum;
	}
	
	public static String calculateChecksum(File file)
	{
		String checksum=null;
		try
		{
			//Get file input stream for reading the file content
		    FileInputStream fis = new FileInputStream(file);
		    checksum = calculateChecksum(fis);
		}
		catch(IOException ioe)
		{
			logger.info("Error while calculating the checksum of file= " + file);
		}
	    return checksum;
	}
	
	/*public static void main(String []args)
	{
		File file = new File("C:/Users/XXXXXX/Desktop/Test attachments/05MarchSavedSearch_ViewDetails.xlsx");
		String checksum1 = calculateChecksum(file, LOGGER);
		String checksum2= null;
		try
		{
			checksum2 = calculateChecksum(new FileInputStream(file), LOGGER);
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("checksum1= "+checksum1);
		System.out.println("checksum2= "+checksum2);
	}*/
	
	public static String getValidEmail(String email)
	{
		String returnEmail = null;
		
		if (StringUtils.isNotBlank(email) && email.indexOf('@') != -1)
		{

			String emailTrimed=email.trim();
			if(emailTrimed.startsWith("'") && emailTrimed.endsWith("'")){
				emailTrimed=emailTrimed.substring(1,emailTrimed.length()-1);
			}
			int lastIndexOfAtSymbol = emailTrimed.lastIndexOf('@');

			String subStrNoDomain = emailTrimed.substring(0, lastIndexOfAtSymbol).replaceAll(INVALID_EMAIL_PATTERN_BEFORE_DOMAIN, "");

			String subStrOnlyDomain = emailTrimed.substring(lastIndexOfAtSymbol + 1, emailTrimed.length()).replaceAll(INVALID_EMAIL_PATTERN_AFTER_DOMAIN, "");

			returnEmail = subStrNoDomain + "@" + subStrOnlyDomain;

		}

		return returnEmail;
		
	}
	
	public static String getValidEmailWithoutDomain(String email)
	{
		String returnEmail = null;
		try
		{
			if (StringUtils.isNotBlank(email))
			{
				String emailTrimed = email.trim();
				if (emailTrimed.startsWith("'") && emailTrimed.endsWith("'"))
				{
					emailTrimed = emailTrimed.substring(1, emailTrimed.length() - 1);
				}
				int lastIndexOfAtSymbol = emailTrimed.lastIndexOf('@');
				if (lastIndexOfAtSymbol > -1)
				{
					returnEmail = emailTrimed.substring(0, lastIndexOfAtSymbol).replaceAll(INVALID_EMAIL_PATTERN_BEFORE_DOMAIN, "");
				}
			}
		}
		catch (Exception ex)
		{
			logger.warn("Error in getValidEmailWithoutDomain email address has issues. " + ex);
		}
		return returnEmail;
	}
	
	//Function to do a case insenitive check of whether List<String> contains a particular string
	public static boolean containsCaseInsensitive(String value, List<String> stringList)
	{
		boolean isContains = false;
		
		if(stringList != null && !stringList.isEmpty() && !StringUtils.isEmpty(value))
		{
			for (String string : stringList)
			{
				if(!StringUtils.isEmpty(string) && string.equalsIgnoreCase(value))
				{
					isContains = true;
					break;
				}
			}
		}
		
		return isContains;
	}
	
	public static File createFile(String fileName) {
		File file = null;
		fileName = GenericUtility.sanitizeFileName(fileName);
		String fileNameWithPath = fileName;
		String defaultFileCreationFolder = System.getProperty("defaultfilepath");

		if (StringUtils.isNotBlank(defaultFileCreationFolder)) {
			fileNameWithPath = defaultFileCreationFolder + fileName;
		}
		// [C170665-1723] - SBT Path Traversal Issue Fixing
		if (!GenericUtility.isValidFileName(fileName) || !GenericUtility.isValidPath(fileNameWithPath)) {
			logger.error("Error validating fileName or Full Path, FileName: {}, FullPath: {} ", fileName,
					fileNameWithPath);
			return file;
		}
		file = new File(fileNameWithPath);

		return file;
	}

	public static File createFile(String fileName, String action) {
		File file = null;
		fileName = GenericUtility.sanitizeFileName(fileName);
		String fileNameWithPath = fileName;
		String defaultFileCreationFolder = System.getProperty("defaultfilepath");

		if (StringUtils.isNotBlank(defaultFileCreationFolder)) {
			fileNameWithPath = defaultFileCreationFolder + fileName;
		}
		// [C170665-1723] - SBT Path Traversal Issue Fixing
		if (!GenericUtility.isValidFileName(fileName,action) || !GenericUtility.isValidPath(fileNameWithPath,action)) {
			logger.error("Error validating fileName or Full Path, FileName: {}, FullPath: {} ", fileName,
					fileNameWithPath);
			return file;
		}
		file = new File(fileNameWithPath);

		return file;
	}

	public static boolean isValidFileName(String inputFileName,String action) {
		boolean isValidFileName = false;
		String validFileNameRegex ="";
		if (null != QMACacheFactory.getCache().getConfigById("FileNameAndPathValidation")) {
			Config validationConfig = QMACacheFactory.getCache().getConfigById("FileNameAndPathValidation");
			if (validationConfig.getFileNameRegex() != null) {
				validFileNameRegex = validationConfig.getFileNameRegex();
			}
		}

		if(validFileNameRegex == null || validFileNameRegex.isEmpty()) {
			validFileNameRegex = VALID_FILENAME_REGEX;
		}
		if(null != inputFileName) {//sonar fix -null pointer
			inputFileName = inputFileName.replaceAll(ESCAPE_CHARS, "_");
			logger.info("SBT: validating input file name: {} with regex: {}", inputFileName,validFileNameRegex );
		}
		
		if(validFileNameRegex == null || validFileNameRegex.isEmpty()) {
			logger.info("SBT: Regex for validating input file name is empty or null: {}",validFileNameRegex);
			isValidFileName = true;
		} else {
			try {
				isValidFileName = (StringUtils.isNotEmpty(inputFileName) && inputFileName.matches(validFileNameRegex));
				if(!isValidFileName){
					isValidFileName = !containsBlockedCharacter(inputFileName);
				}
			} catch (Exception e) {
				logger.error("Exception while validating input file name : " + inputFileName , e);
			}
		}
		return isValidFileName;
	}

	public static boolean isValidPath(String fullPath,String action) {
		boolean isValidPath = false;
		logger.info("SBT: FullPath: {}", fullPath);
		try {
			if(fullPath != null && !fullPath.isEmpty())
			{
				File file = new File(fullPath);
				String canonicalPath = file.getCanonicalPath();
				String absolutePath = file.getAbsolutePath();
				String finalPath = sanitizeFileNameForPathTraversal(canonicalPath);
				if(!canonicalPath.equals(finalPath) || !absolutePath.equals(finalPath)) {
					logger.error("Exception while validating full path : {}", fullPath);
					isValidPath = false;
				}else {
					isValidPath = true;
				}
				String fileName = fullPath.substring(fullPath.lastIndexOf('/')+1, fullPath.length());
				logger.info("FileName: {}",fileName);
			}else {
				logger.error("Specified Path is Empty " + fullPath);
			}
		}catch(InvalidPathException e) {
			logger.error("Exception while validating full path : " + fullPath, e);
		} catch (IOException e) {
			logger.error("Exception while validating full path : " + fullPath, e);
		}
		return isValidPath;
	}
	
	/**
	 * @returns default directory where temporary files can be created
	 */
	public static String getDefaultFileCreationDirectory()
	{
		return  System.getProperty("defaultfilepath");
	}
	
	public static Properties readProperties(String filePath)
	{
		Properties prop = new Properties();
		InputStream input = null;
		try
		{
			input = new FileInputStream(filePath);

			// load a properties file
			prop.load(input);
		}
		catch (IOException ex)
		{
		    logger.warn("Exception in readProperites:", ex);
		}
		finally
		{
			if (input != null)
			{
				try
				{
					input.close();
				}
				catch (IOException e)
				{
				    logger.warn("Exception in readProperites:", e);
				}
			}
		}
		return prop;
	}

	public static void postInquiryDetailsToCSL(Inquiry dbInquiry, Conversation conversation, String xstreamReqId) throws CommunicatorException 
	{
		long startTime = System.currentTimeMillis();
		logger.info("Inside postInquiryDetailsToCSL exceptionId: " +dbInquiry.getExceptionId()+" X-StreamreqId:"+xstreamReqId+" inquiryId: "+dbInquiry.getId()+" soeid :"+dbInquiry.getLatestUserId());
//		boolean isXstreamIntegrationEnabled = false;
		BasicDBObject finalMsg = new BasicDBObject();
		//isXstreamIntegrationEnabled= 
		prepareMessage(dbInquiry, conversation, finalMsg,xstreamReqId);
//		if (isXstreamIntegrationEnabled)
//		{
			//String uri = CacheDAO.getInstance().getDefaultStaticData().getCslRestServerUrl() + "/saveInquiryDetails";
		String uri = QMACacheFactory.getCache().getCslRestServerUrl() + "/saveInquiryDetails";
			URL url = null;
			try
			{
				url = URI.create(uri).toURL();
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setDoOutput(true);
				conn.setDoInput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
				conn.setRequestProperty("Accept", "application/json");
				conn.connect();
				OutputStream os = conn.getOutputStream();
				os.write(finalMsg.toString().getBytes("UTF-8"));
				os.flush();
				int HttpResult = conn.getResponseCode();
				if (HttpResult == HttpURLConnection.HTTP_OK)
				{
					logger.debug(" Inquiry posted successfully to CSL: exceptionId: " +dbInquiry.getExceptionId()+" inquiryId: "+dbInquiry.getId());
				}
				conn.disconnect();
				//logger.debug("Message posted successfully to CSL : " + finalMsg.toString());
			}
			catch (MalformedURLException e)
			{
				logger.error("Error while opening the CSL connection url malformed: exceptionId:  "  +dbInquiry.getExceptionId()+" inquiryId: "+dbInquiry.getId() + e);
			}
			catch (IOException e)
			{
				logger.error("Error while writing data to CSL server output stream: exceptionId:  " +dbInquiry.getExceptionId()+" inquiryId: "+dbInquiry.getId()  + e);
			}
			catch (Exception e)
			{
				logger.error("Error while posting data to CSL:= exceptionId:  " +dbInquiry.getExceptionId()+" inquiryId: "+dbInquiry.getId()+ " error:" + e);
			}
			
			logger.info("Time took in postInquiryDetailsToCSL is: " + (System.currentTimeMillis() - startTime));
//		}
//		else
//		{
//			logger.debug("No from to cc grop has xstreamIntegrationEnabled flag true, hence ignoring posting message to CSL");
//		}

	}

	private static boolean prepareToCc(List<ConversationRecipient> recipients, StringBuilder fromRecipient, StringBuilder toRecipients, StringBuilder ccRecipients)
	{
		// Will use this flag in next release.
		boolean isXstreamIntegrationEnabled = true;
		for (ConversationRecipient recipient : recipients)
		{
			if (null != recipient)
			{
				// if(!isXstreamIntegrationEnabled && null != recipient.getGroupId())
				// {
				// Group group= CacheDAO.getInstance().getAllGroupsMap().get(recipient.getGroupId());
				// isXstreamIntegrationEnabled = (null == group || null == group.getEnableXstreamIntegration()) ? false: group.getEnableXstreamIntegration();
				// }

				if ("FROM".equals(recipient.getToFrom()))
				{
					fromRecipient.append(concatDisplayNameEmail(recipient));
				}
				else if ("CC".equals(recipient.getToFrom()))
				{
					if (ccRecipients.length() > 0)
					{
						ccRecipients.append(";");
					}
					ccRecipients.append(concatDisplayNameEmail(recipient));
				}
				else
				{
					if (toRecipients.length() > 0)
					{
						toRecipients.append(";");
					}
					toRecipients.append(concatDisplayNameEmail(recipient));
				}
			}
		}
		return isXstreamIntegrationEnabled;
	}

	private static boolean prepareMessage(Inquiry dbInquiry,Conversation conversation, BasicDBObject finalMsg,String requestId) throws CommunicatorException
	{
		if (null == dbInquiry)
		{
			logger.error("Invalid input to CSL rest service inquiry can't be null");
			throw new CommunicatorException("Invalid input to CSL rest service inquiry conversation can't be null/blank ");
		}
		BasicDBObject message = new BasicDBObject();
		boolean isXstreamIntegrationEnabled = true;
		if(null != conversation && null != conversation.getRecipients())
		{
			StringBuilder fromRecipient = new StringBuilder();
			StringBuilder toRecipients = new StringBuilder();
			StringBuilder ccRecipients = new StringBuilder();
			List<ConversationRecipient> recipients = conversation.getRecipients();
			prepareToCc(recipients, fromRecipient, toRecipients, ccRecipients);
			// if (isXstreamIntegrationEnabled)
			// {
			if (null != fromRecipient && !"".equals(fromRecipient))
			{
				message.put("fromRecipient", fromRecipient.toString());
			}
			if (null != toRecipients && !"".equals(toRecipients.toString()))
			{
				message.put("toRecipients", toRecipients.toString());
			}
			if (null != ccRecipients && !"".equals(ccRecipients.toString()))
			{
				message.put("ccRecipients", ccRecipients.toString());
			}
		}
		message.put("id", dbInquiry.getId());
		message.put("mtpLinkId", dbInquiry.getExceptionId());
		message.put("senderCompId", SENDER_COMPONENT_ID);
		if(!StringUtils.isBlank(requestId))
		{
			message.put("requestId", requestId);
		}
		if(!StringUtils.isBlank(dbInquiry.getSubject()))
		{
			message.put("subject", dbInquiry.getSubject());
		}
		if(!StringUtils.isBlank(dbInquiry.getStatus()))
		{
			message.put("inquiryStatus", dbInquiry.getStatus());
		}
		message.put("requestType", dbInquiry.getRequestTypeStr());
		message.put("assignedUserName", dbInquiry.getOpenUsers());
		message.put("assignedGroupName", dbInquiry.getOpenGroups());
		message.put("inquiryType", dbInquiry.getOrigType());
		message.put("created", dbInquiry.getCrtDate().getTime());
		message.put("createdBy", dbInquiry.getOrigUserName());
		message.put("modified", dbInquiry.getModDate().getTime());
		message.put("modifiedBy", dbInquiry.getModBy());
		if(!StringUtils.isBlank(dbInquiry.getGfcid()))
		{
			message.put("inquiryGfcid", dbInquiry.getGfcid());
		}
		if(!StringUtils.isBlank(dbInquiry.getGfcName()))
		{
			message.put("inquiryGfcName", dbInquiry.getGfcName());
		}
		if(!StringUtils.isBlank(dbInquiry.getGpName()))
		{
			message.put("inquiryGfpName", dbInquiry.getGpName());
		}
		if(!StringUtils.isBlank(dbInquiry.getGpNum()))
		{
			message.put("inquiryGfpid", dbInquiry.getGpNum());
		}
		message.put("inquiryAction", dbInquiry.getAction());
		message.put("inquiryModBy", dbInquiry.getModBy());
		finalMsg.put("inquiry", message);
		// }
		return isXstreamIntegrationEnabled;
	}
	
	private static String concatDisplayNameEmail(ConversationRecipient recipient)
	{
		String nameEmail = "";
		if (null != recipient && null != recipient.getEmailAddr() && null != recipient.getDisplayName())
		{
			StringBuilder tempBuilder = new StringBuilder();
			tempBuilder.append(recipient.getDisplayName()).append("<").append(recipient.getEmailAddr()).append(">");
			nameEmail = tempBuilder.toString();
		}
		else if (null == recipient.getEmailAddr() && null != recipient.getDisplayName())
		{
			nameEmail = recipient.getDisplayName();
		}
		else if (null == recipient.getDisplayName() && null != recipient.getEmailAddr())
		{
			nameEmail = recipient.getEmailAddr();
		}
		return nameEmail;
	}

	// function to check if file is encrypted if it is part of required secure file extension
	// listed in secureFileExtensionList
	public static boolean isFileSecure(String fileName, InputStream inputStream, String soeId)
	{
		boolean isSecure = false;
		logger.info("Checking file security for file: "+ fileName + ", for user: " + soeId);
		if(StringUtils.isNotBlank(fileName))
		{
			String fileExtension = FilenameUtils.getExtension(fileName);
			if(StringUtils.isNotBlank(fileExtension) && secureFileExtensionList.contains(fileExtension.toUpperCase()))
			{
					return EncryptionUtility.isFileEncrypted(fileExtension, inputStream);
			}
		}
		return isSecure;
	}
	public static String convertSecsToDayHourMin(long timeInSeconds)
	{
		String timeDisplay = "";
		if (timeInSeconds > 0)
		{
			Double days = Math.floor(timeInSeconds / (3600 * 24));
			Double hrs = Math.floor((timeInSeconds / 3600) - (days * 24));
			Double mnts = Math.floor((timeInSeconds - (days * 24 * 3600) - (hrs * 3600)) / 60);
			String minutes = "";
			if (null != mnts)
			{
				if (mnts < 10)
				{
					minutes = "0" + mnts.intValue();
				}
				else
				{
					minutes = minutes + mnts.intValue();
				}
			}

			String hours = "";
			if (null != hrs)
			{
				if (hrs < 10)
				{
					hours = "0" + hrs.intValue();
				}
				else
				{
					hours = hours + hrs.intValue();
				}
			}
			String daysStr = "";
			if (null != days)
			{
				if (days < 10)
				{
					daysStr = "0" + days.intValue();
				}
				else
				{
					daysStr = daysStr + days.intValue();
				}
			}
			daysStr = daysStr + 'd' + ":";
			String hhMMSSDisplay = hours + ':' + minutes;
			timeDisplay = daysStr + hhMMSSDisplay;
		}
		return timeDisplay;
	}
	
	/**
	 * This method validates email address
	 * @param email
	 * @return boolean
	 */
	public static boolean isValidEmailAddress(String email)
    {
        Matcher matcher = EMAIL_REGEX_PATTERN.matcher(email);
        return matcher.find();

    }
	
	public static File createFileOnWebDirectory(String path, String currentDocumentName)
	{
		
		String fileNameWithPath = path + "/" + currentDocumentName;
		File file = null;
		
		logger.info("createFileOnWebDirectory...." + fileNameWithPath);

		boolean check = Path.of(fileNameWithPath).toFile().exists();
	
		if(!check)
		{
			Arrays.stream(new File(path).listFiles()).forEach(File::delete);
			file = new File(fileNameWithPath);
		}
		
		return file;
		
	}

	/**
	 * This method gets list of all inline attachments for a given conversation
	 * @param conv
	 * @return List<Map<String, Object>>
	 */
	public static List<Map<String, Object>> getAllInlineAttachments(Conversation conv) {
		List<Map<String, Object>> attachments = null;
		if(conv != null && StringUtils.isNotEmpty(checkAndFetchConvContent(conv))) {
			logger.info("getAllInlineAttachments() called for convId :" + conv.getId() + ", inquiryId : " + conv.getInquiryId());
			attachments = extractInlineAttachmentFromContents(checkAndFetchConvContent(conv));
		}
		return attachments;
	}

	/**
	 * This method gets list of all inline attached files map for given contents
	 * @param currentContent
	 * @return List<Map<String, Object>>
	 */
	public static List<Map<String, Object>> extractInlineAttachmentFromContents(String currentContent) {
		List<Map<String, Object>> attachmentFiles = new ArrayList<>();
		if( null != currentContent && StringUtils.isNotBlank(currentContent) ) {
			List<String> fileIds = parseContentForInlineAttachment(currentContent);
			logger.info("FileIds extracted from contents : " + fileIds);
			if(fileIds!=null && !fileIds.isEmpty()){
				attachmentFiles = getFiles(fileIds);
			}
		}
		return attachmentFiles;
	}

	/**
	 * This method extracts all the fileId associated with passed contents
	 * @param currentContent
	 * @return List<String>
	 */
	private static List<String> parseContentForInlineAttachment(String currentContent) {
		List<String> fileIds = new ArrayList<>();
		if(currentContent!=null && StringUtils.isNotBlank(currentContent)){
			Pattern pattern = Pattern.compile(INLINE_IMAGE_PATTERN);
			Matcher matcher = pattern.matcher(currentContent);
			List<String> imageTags = new ArrayList<>();
			while (matcher.find()) {
				imageTags.add(matcher.group());
			}
			if(!imageTags.isEmpty()){
				fileIds = getFileIds(imageTags);
			} else {
				logger.info("No inline images found for given contents");
			}
		}
		return fileIds;
	}
	
	/**
	 * This method extract fileIds from provided image tags
	 * @param imageTags
	 * @return List<String>
	 */
	private static List<String> getFileIds(List<String> imageTags) {
		List<String> fileIds = new ArrayList<>();
		if(imageTags!=null && !imageTags.isEmpty()){
			for(String image : imageTags){
				Pattern pattern = Pattern.compile(IMAGE_FILEID_PATTERN);
				Matcher matcher = pattern.matcher(image);
				String fid = "";
				while (matcher.find()) {
					fid =  matcher.group();
					fid = fid.substring(fid.indexOf('=')+1, fid.indexOf("\">"));
				}
				if(StringUtils.isNotEmpty(fid)) {
					fileIds.add(fid);
				}
			}
		}
		return fileIds;
	}

	/**
	 * This function provides list of file maps for all provied fileIDs
	 * @param fileIds
	 * @return List<Map<String, Object>>
	 */
	public static List<Map<String, Object>> getFiles(List<String> fileIds) {
		List<Map<String, Object>> files = new ArrayList<>();
		if(fileIds!=null && !fileIds.isEmpty()){
			for(String fileId : fileIds){
				Map<String, Object> fileMap = getFile(fileId);
				if(fileMap!=null && !fileMap.isEmpty()){
					files.add(fileMap);
				}
			}
		}
		return files;
	}


	/**
	 * This file returns a file map object for given file mongo id
	 * @param id
	 * @return Map<String, Object>
	 */
	public static Map<String, Object> getFile(String id) {
		Map<String, Object> fileMap = null;
		try {
			if(!StringUtils.isEmpty(id)){
				fileMap = aDao.getFile(id);
				if( null != fileMap && !fileMap.isEmpty() ) {
					logger.info("File extracted for file id : " + id);
				}
			}
		} catch (CommunicatorException e) {
			logger.error(" Exception while retrieving file with id :" + id , e);
		}
		return fileMap;
	}
	
	public static String updateContentWithImages(String content, String soeId) throws CommunicatorException
	{
      // C170665-4198 - inline images from Taskize not working in QMA
	    content = decodeHtmlDecimalCharaters(content);
      
		String token = "<img src=\"data:image/png;base64,";
		int tokenIndex = 0;
		int fromIndex = 0;
		int endIndex = 0;
		int i = 0;
		String data = null;
		byte[] bytes = null;
		String cntn = content;// Sonar Fix -- Introduce a new variable instead of reusing the parameter
		try
		{

			while (cntn.contains(token))
			{
				String docId = null;
				tokenIndex = cntn.indexOf(token, fromIndex);
				endIndex = cntn.indexOf("\" />", tokenIndex);
				boolean isNewImgformat = false;
				// for tinymce upgrade change in closing tag of image its self closing now
				if (endIndex == -1 && tokenIndex > -1) {
					endIndex = cntn.indexOf(">", tokenIndex);
					if (endIndex > -1) {
						isNewImgformat = true;
					}
				} else {
					isNewImgformat = false;
				}
				data = cntn.substring(tokenIndex + token.length(), endIndex);
				data = data.replaceAll("\\s", "+");

				bytes = Base64.decodeBase64(data.getBytes());

				long fileUniqId = new Date().getTime();
				String fileName = soeId + "_" + fileUniqId + "_" + i + ".png";
				InputStream inputStream = new ByteArrayInputStream(bytes);

				logger.info(" Writing to Mongo ");
				Attachment savedAttachment = aDao.saveFile(docId, fileName, inputStream);
				docId = savedAttachment.getId();
				if (!StringUtils.isBlank(docId))
				{
					// cntn = cntn.substring(0, tokenIndex) + "<img src=\"" +
					// GenericUtility.getAppServerContextFromDB() + "/rest/imageBrowser/image?path="
					// + docId + "\"/>" + cntn.substring(endIndex + 4);
					if (isNewImgformat) {
						cntn = cntn.substring(0, tokenIndex) + "<img src=\""
								+ GenericUtility.getAppServerContextFromDB() + "/QMA2/inquiry/image?fileName=" + docId
								+ "\"/>" + cntn.substring(endIndex + 1);
					} else {

						cntn = cntn.substring(0, tokenIndex) + "<img src=\""
								+ GenericUtility.getAppServerContextFromDB() + "/QMA2/inquiry/image?fileName=" + docId
								+ "\"/>" + cntn.substring(endIndex + 4);
					}
					fromIndex = cntn.indexOf(docId);
				}

				i++;

				if (i > 20) // exit loop in case of any issue and infinite iteration
				{
					break;
				}

				logger.info("Uploaded File successfully to MongoDB with fileName: " + fileName);
			}
		}
		catch (Exception e)
		{
			logger.error("Issue in method updateContentWithImages():: " + e);
			throw new CommunicatorException("Issue in method updateContentWithImages():: ", e);
		}
		return cntn;
	}

	private static String decodeHtmlDecimalCharaters(String data) {
		logger.info("Start Method decodeHtmlDecimalCharaters");
		try {
			Pattern pattern = Pattern.compile("&#(\\d+);");
			Matcher matcher = pattern.matcher(data);
			StringBuffer buffer = new StringBuffer();
			
			while(matcher.find()) {
				int codePoint = Integer.parseInt(matcher.group(1));
				matcher.appendReplacement(buffer, "");
				buffer.append(Character.toChars(codePoint));
			}
			matcher.appendTail(buffer);
			
			data = buffer.toString();
		} catch (Exception e) {
			logger.error("Exception in decodeHtmlDecimalCharaters :: ",e);
		}
		logger.info("End Method decodeHtmlDecimalCharaters");
		return data;
	}

	/**
	 * @param file
	*/
	public static void deleteFile(File file)
	{
		logger.info("Deleting temporary file : "+ file);
		if (null != file)
		{
			try
			{
				file.delete();
			}
			catch (Exception e)
			{
				// Sonar Fix -- Either log or rethrow this exception
				logger.error("Error happened during deletion of file", e);
			}
		}
	}
	


	public static void deleteDirectory(String directory)
	{
		logger.debug("Deleting temporary directory : "+ directory);
		if(null!=directory)
		{
			try
			{
				FileUtils.deleteDirectory(new File (directory));
			}
			catch (IOException e)
			{
				logger.error("Error happened during deleting directory -" + directory, e);
			}
		}
	}

	/**
	 * @param allToCCIncomingRecipientList
	 * @param groupName
	 * @param toFrom
	 * @return
	 */
	public static boolean checkDuplicates(Set<ConversationRecipient> allToCCIncomingRecipientList, String groupName,
			String toFrom) {
		boolean isConatins = false;
		for(ConversationRecipient conversationRecipient : allToCCIncomingRecipientList)
		{
			if(conversationRecipient.getDisplayName() != null && conversationRecipient.getDisplayName().trim().equals(groupName.trim())
					&& conversationRecipient.getToFrom().equals(toFrom))
			{
				isConatins= true;
				break;
			}
			
		}
		
		return isConatins;
		
	}
	
	
	/**
	 * @param listString
	 * @return Create a String from the list
	 */
	public static String createStringFromListofString(List<String> listString)
	{
		return listString.stream().collect(Collectors.joining(","));
		
	}
	
	/**
	 * @param listString
	 * @return Create a String from basicDBlist
	 */
	public static String creatStringFromBasicDBList(BasicDBList listString)
	{
		return listString.stream().map(str->str.toString()).collect(Collectors.joining(","));
		
	}
	
	public static String encodeFileName(String fileName)
	{
		String encodeFileName = null;
		if (StringUtils.isNotEmpty(fileName))
		{
			try
			{
				encodeFileName = MimeUtility.encodeText(fileName,"UTF-8",null);
			}
			catch (UnsupportedEncodingException e)
			{
				encodeFileName = fileName;
				logger.error("Error while decoding the file name: " + fileName, e);
			}
		}

		return encodeFileName;
	}
	
	public static String encodeFileForForeignCharacter(String input) {
    	String encodedFileName = null;
    	try {
			String regEx = "[^a-zA-Z0-9,._=@ ]+";
			Pattern pattern = Pattern.compile(regEx);
			Matcher matcher = pattern.matcher(input);
			boolean flag = matcher.find();
			if(flag){
				encodedFileName = encodeFileName(input);
			}
		} catch (Exception e) {
			encodedFileName = null;
			logger.error("Error while pattern match for the file name: " + input, e);
			}
		return encodedFileName;
		}
	
	public static String parseJsonInRelaxedMode(DBObject dbObject)
		{
		String output = null;
		try {
			BasicDBObject bdo = (BasicDBObject) dbObject;
			JsonWriterSettings.Builder writerSettings = JsonWriterSettings.builder().outputMode(JsonMode.RELAXED);
			output = bdo.toJson(writerSettings.build());
		} catch (Exception e) {
			logger.error("Error while parsing DB Object in relaxed json mode: " + dbObject, e);
		}
		return output;
	}
	/**
	 * This method is used for logging IMPL calls
	 * @param logger
	 * @param method
	 * @param soeId
	 * @param request
	 */
	public static void logRequestDetails(Logger logger, String method, String soeId, String request){
		logger.info("Method call : " + method + " by user : " + soeId + " and the request is : " + request);
	}
	
	/**
	 * This method is used for logging time taken by method
	 * @param logger
	 * @param method
	 * @param soeId
	 * @param startTime
	 */
	public static void logTimeTakenDetails(Logger logger, String method, String soeId, Long startTime){
		logger.info("Method call : " + method + " by user : " + soeId + " took : " + (System.currentTimeMillis()-startTime) + " ms");
	}

	/**
	 * This method logs exception
	 * @param logger
	 * @param method
	 * @param e
	 */
	public static void logMethodGenericException(Logger logger, String method, Exception e){
		logger.error("Exception in " + method + " : ", e);
	}
	
	
	public static String formatDate(Date date) {
		String formattedvalueGMT = null;
		SimpleDateFormat sDate = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.SSS");
		// this converts to GMT date
		sDate.setTimeZone(TimeZone.getTimeZone("GMT"));
		if (null != date) {
			formattedvalueGMT = sDate.format(date);
		}
		return formattedvalueGMT;
	}

	/**
	 * This method gets age of an inquiry
	 * @param workflow
	 * @return long
	 */
	public static long getAgeOfAnInquiry(BasicDBObject workflow) {
		long age = 0;
		
		if(null != workflow.get(ASSIGNED_GROUP_ID_KEY)){
			Object groupID = workflow.get(ASSIGNED_GROUP_ID_KEY);
			if( groupID != null && null != QMACacheFactory.getCache().getGroupAgeConfigMap()
					&& QMACacheFactory.getCache().getGroupAgeConfigMap().containsKey(groupID) ) {
				AgeAndTimeUtils.updateAgeData(groupID, workflow);
				if(null != workflow.get(AGE_IN_DAYS_KEY)) {
				age = workflow.getInt(AGE_IN_DAYS_KEY);
				}
				
			} else {
				age = AgeAndTimeUtils.getAgeForNonHolidayConfig(workflow, "age");
			}
		}
		
		return age;
	}
	/*
	public static String getRequestOrigin(HttpServletRequest request) {
		String origin = "";
		try {
			if(request!=null && null != request.getHeader("request_origin")) {
				origin = request.getHeader("request_origin");
		}
		} catch (Exception e) {
			logger.error("Exception while retrieving origin from request : ",e);
		}
		return origin;
	}
	
		
	/**
	 * @param request
	 * @return
	 */
	/*
	public static boolean isMobileView(HttpServletRequest request) {
		boolean isMobile = false;
		try {
			if(null == request){
				return isMobile;
			}
			AuditTrailDAO auditTrailDao = new AuditTrailDAO();
			String userOs = auditTrailDao.getRequestChannelProperty(request, "OS");
			
			if(!"Windows".equalsIgnoreCase(userOs) && !"Mac".equalsIgnoreCase(userOs) && !"Unix".equalsIgnoreCase(userOs) && !"Linux".equalsIgnoreCase(userOs)){
				isMobile = true;
			}
			logger.info("OS is : "+ userOs + " and isMobile :"+isMobile);
		} catch (Exception e) {
			logger.error("Exception while getting isMobileView", e);
		}
		return isMobile;
	}
	
	public static boolean isQMA2Request(HttpServletRequest request, String soeId){
		logger.info("Inside UserDao.isQMA2Request to get userAuthKey for userId= " + soeId);
		boolean flag = false;
		try {
			String requestOrigin = request.getHeader("origin");
			AuditTrailDAO auditTrailDao = new AuditTrailDAO();
			flag = auditTrailDao.checkIfQMA2Origin(request,requestOrigin);
			logger.info("Inside UserDao.isQMA2Request to get userAuthKey for userId= " + soeId + " QMA2 origin : "+flag);
		} catch (Exception e) {
			logger.error("Exception occurred in isQMA2Request for soeId :"+ soeId,e);
		}
		return flag;
	}
	*/
	/**
	 * This method is used to get appServerContext from config.
	 * @return
	 */
	public static String getAppServerContextFromDB() {
		String appServerBaseUrl = "/QMA";
		try {
			if (null != QMACacheFactory.getCache().getConfigById("appServerContext") 
					&& StringUtils.isNotEmpty(QMACacheFactory.getCache().getConfigById("appServerContext").getAppServerContext())) {
				appServerBaseUrl = QMACacheFactory.getCache().getConfigById("appServerContext").getAppServerContext();
			}
		} catch (Exception ex) {
			logger.error("Error while fetching appServerBaseUrl from DB ",ex);
		}
		return appServerBaseUrl;
	}
	
	/**
	 * This method is used to convert source bean to destination bean.
	 * @return
	 */
	public static com.citi.icg.qma.common.transferobject.ConversationTO convertBean(ConversationTO conversationTO) {
		com.citi.icg.qma.common.transferobject.ConversationTO conversationTOCommon = null;
		try {
			String jsoNObject = DataConversionUtil.convertJavaObjectToJson(conversationTO);
			conversationTOCommon = new com.citi.icg.qma.common.transferobject.ConversationTO();
			conversationTOCommon = (com.citi.icg.qma.common.transferobject.ConversationTO) DataConversionUtil.convertJSONToJava(jsoNObject, conversationTOCommon.getClass());
		} catch(Exception e) {
			logger.error("Exception while converting Java Object To Json request : ", e);
		}
		return conversationTOCommon;
	}
	
	/**
	 * This method parses input string to BasicDBObject
	 * @param inputStr
	 * @return BasicDBObject
	 */
	public static BasicDBObject parseRequestToObject(String inputStr) {
		BasicDBObject resultObj = null;
		try {
			resultObj = BasicDBObject.parse(inputStr);
		} catch (Exception e) {
			logger.error("Exception while parsing request : ", e);
		}
		return resultObj;
	}
	/**
	 * @param input
	 * @return
	 */
	public static String decodeFileForForeignCharacter(String input)
	{
		String decodedFileName = null;
		try
		{
			Pattern pattern = Pattern.compile(FOREIGN_FILENAME_REGEX);
			Matcher matcher = pattern.matcher(input);
			boolean flag = matcher.find();
			if (flag)
			{
				decodedFileName = decodeFileName(input);
			}
		}
		catch (Exception e)
		{
			decodedFileName = null;
			logger.error("Error while pattern match for the file name: " + input, e);
		}
		return decodedFileName;
	}
	/**
	 * Decodes the encoded file name .
	 * 
	 * @param fileName
	 * @return decodedFileName
	 * 
	 */
	public static String decodeFileName(String fileName)
	{
		String decodeFileName = null;
		if (StringUtils.isNotEmpty(fileName))
		{
			try
			{
				decodeFileName = MimeUtility.decodeText(fileName);
			}
			catch (UnsupportedEncodingException e)
			{
				decodeFileName = fileName;
				logger.error("Error while decoding the file name: " + fileName, e);
			}
		}

		return decodeFileName;
	}
	
	/**
	 * THis method provides NLPRequestType of provided group ID
	 * @param inputGroupId
	 * @return NLPRequestType
	 */
	public static NLPRequestType getNlpRequestTypebyGroupId(String inputGroupId) {
		//List<String> nlpCustodyGrps = QMACacheFactory.getCache().getNlpSubsciptionGroups("nlpSuggestionMandatoryGroups");
		List<String> nlpCustodyGrps = QMACacheFactory.getCache().getCustodySuggestionEnabledGroupList();
		//List<String> nlpSettsGrps = QMACacheFactory.getCache().getNlpSubsciptionGroups("nlpSettsMandatoryGroups");
		List<String> nlpSettsGrps = QMACacheFactory.getCache().getAutoReplySuggestionEnabledGroupList();
		String groupCode = QMACacheFactory.getCache().getGroupIdToCodeMap().get(Long.parseLong(inputGroupId));
		//TODO : Need to validate below default assignment to type A
		List<String> intentSuggestionGrps = QMACacheFactory.getCache().getIntentSuggestionEnabledGroupList();
		NLPRequestType reqType=NLPRequestType.A;
		if (nlpCustodyGrps.contains(groupCode)) {
			reqType= NLPRequestType.C;
		} else if (nlpSettsGrps.contains(groupCode)) {
			reqType= NLPRequestType.S;
		} else if(null != intentSuggestionGrps && !intentSuggestionGrps.isEmpty() && intentSuggestionGrps.contains(groupCode)) {
			reqType= NLPRequestType.I;
		}
		return reqType;
	}
	/**
	 * @param inputJsonObj
	 * @return
	 */
	public static Map<String, Long> getDateByAgeBand(BasicDBObject inputJsonObj) {
		int ageBandFromDate = 0;
		int ageBandToDate = 0;
		Map<String, Long> datesAsPerAgeBand = new HashMap<>();
		if(null != inputJsonObj.get(AGE_BAND)) {
			String ageBand = inputJsonObj.getString(AGE_BAND);
			switch (ageBand) {
			case "0-1 days":
				ageBandFromDate = 1;
				ageBandToDate = 0;
				break;
			case "2 days":
				ageBandFromDate = 2;
				ageBandToDate = 1;
				break;
			case "3-5 days":
				ageBandFromDate = 3;
				ageBandToDate = 5;
				break;
			case "6-10 days":
				ageBandFromDate = 6;
				ageBandToDate = 10;
				break;
			case "11-30 days":
				ageBandFromDate = 11;
				ageBandToDate = 30;
				break;
			case "30+ days":
				ageBandFromDate=30;
				break;
			default:
				break;
			}
		}	
		datesAsPerAgeBand.put("ageBandFromDate",getDateAsPerAgeBand(ageBandFromDate));
		if(ageBandToDate != 0)
		datesAsPerAgeBand.put("ageBandToDate",getDateAsPerAgeBand(ageBandToDate));
		return datesAsPerAgeBand;
	}

	private static long getDateAsPerAgeBand(int ageBandDate) {
		Date calculatedTime = null;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE,-ageBandDate);
		calculatedTime = cal.getTime();
		return calculatedTime.getTime();
	}
	
	/**
	 * This function gets the todays date for sent and resolved boxes
	 * @return
	 */
	public static Date getTodaysDate() {
		Date date = null;
		try {
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.HOUR, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			date = cal.getTime();
		} catch (Exception e) {
			logger.warn("Issue while getting todays date :", e.getMessage());
		}
		return date;
	}

	/**
	 * This function validates if the provided value is alphanumeric or not
	 * @param inputValue
	 * @return boolean
	 */
	public static boolean isValidAlphaNumericValue(String inputValue) {
		boolean isValidDocId = false;
		try {
			return (StringUtils.isNotEmpty(inputValue) && inputValue.matches(ALPHA_NUMERIC_REGEX));
		} catch (Exception e) {
			logger.warn("Exception while validating inputValue as alpha-numeric : ", e);
		}
		return isValidDocId;
	}

	/**
	 * This method will validates input whether numeric or not
	 * @param inputValue
	 * @return boolean
	 */
	public static boolean isValidNumericValue(String inputValue) {
		try {
			return (StringUtils.isNotEmpty(inputValue) && inputValue.matches(NUMERIC_REGEX));
		} catch (Exception e) {
			logger.warn("Exception while validating inputValue as numeric : ", e);
		}
		return false;
	}

	/**
	 * This method validates the boolean value against provided string
	 * @param inputValue
	 * @return boolean
	 */
	public static boolean isValidBooleanValue(String inputValue) {
		try {
			return (StringUtils.isNotEmpty(inputValue) && (BOOLEAN_STRING_TRUE.equalsIgnoreCase(inputValue) || BOOLEAN_STRING_FALSE.equalsIgnoreCase(inputValue)) );
		} catch (Exception e) {
			logger.warn("Exception while validating inputValue as boolean string : ", e);
		}
		return false;
	}

	/**
	 * This function sanitizes input file-name before storing it in database.
	 * @param fileName
	 * @return String
	 */
	public static String sanitizeFileName(String fileName) {
		String sanitizedName = fileName;
		if(null != fileName) {
			fileName = fileName.replaceAll(ESCAPE_CHARS, "_");
			logger.info("Sanitizing input file name : {}", fileName);
		}
		try {
			if( !StringUtils.isEmpty(sanitizedName) ) {
				logger.info("Sanitizing filename for path traversal");		
				sanitizedName = sanitizeFileNameForPathTraversal(sanitizedName);
				sanitizedName = replaceBlockedCharacters(sanitizedName);
				sanitizedName = replaceDoubleExtensions(sanitizedName);
			}
			logger.info("After Sanitizing input file name is : {}", fileName);
		} catch (Exception e) {
			logger.warn("Exception while sanitizing fileName : ", e);
		}
		return sanitizedName;
	}

	/**
	 * This function validates if the file_name provided is valid or not
	 * @param fileName
	 * @return Boolean
	 */
	public static Boolean isValidFileExtension(String fileName) {
		if(StringUtils.isNotEmpty(fileName) && (fileName.indexOf(".") == fileName.lastIndexOf("."))){
			String fileExtension = FilenameUtils.getExtension(fileName);
			QMACache qmaCache = QMACacheFactory.getCache();
			StaticData staticData = qmaCache.getDefaultStaticData();
			List <String> allowedFileExtensions = staticData.getAllowedFileExtensions();
			if(StringUtils.isEmpty(fileExtension) || Objects.isNull(allowedFileExtensions) || allowedFileExtensions.isEmpty() || !allowedFileExtensions.contains(fileExtension.toLowerCase())) {
				logger.error("File with extension {} is restricted, allowed list of extensions are : {}", fileExtension,allowedFileExtensions);
				return false;
			}
		} else {
			logger.error("Either fileName is empty or contains double extension.");
			return false;
		}
		return true;
	}

	
	private static String replaceDoubleExtensions(String fileName) {
		String updatedFileName = fileName;
		if (!StringUtils.isEmpty(fileName)) {
			if ((fileName.indexOf(".") == fileName.lastIndexOf("."))) {
				logger.warn("Filename does not contains double extension.");
			} else {
				logger.warn("fileName contains double extension, replacing other ");
				int lastIndexOfDot = fileName.lastIndexOf(".");
				String fileNameBeforeDot = fileName.substring(0,lastIndexOfDot);
				String fileExtension = fileName.substring(lastIndexOfDot);
				fileNameBeforeDot = fileNameBeforeDot.replaceAll("\\.","_");
				updatedFileName = fileNameBeforeDot+fileExtension;
				logger.warn("Updated Filename : {}", updatedFileName);
			}
		}
		return updatedFileName;
	}

	/**
	 * This is created to support download of already uploaded or attached file and inline images
	 * @param fileName
	 * @return
	 */
	public static Boolean isValidFileExtensionForFileDownload(String fileName) {
		logger.info("File name for validating extension while download : {}", fileName);
		if(StringUtils.isNotEmpty(fileName)) {
			/*String fileExtension = FilenameUtils.getExtension(fileName);
			logger.info("File extension identified for validation is : '{}'", fileExtension);
			if(StringUtils.isEmpty(fileExtension)){
				logger.info("File getting downloaded does not contains any extension.");
				return true;
			}
			QMACache qmaCache = QMACacheFactory.getCache();
			StaticData staticData = qmaCache.getDefaultStaticData();
			List <String> allowedFileExtensions = staticData.getAllowedFileExtensions();
			if(StringUtils.isEmpty(fileExtension) || Objects.isNull(allowedFileExtensions) || allowedFileExtensions.isEmpty() || !allowedFileExtensions.contains(fileExtension.toLowerCase())) {
				logger.error("File with extension {} is restricted, allowed list of extensions are : {}", fileExtension,allowedFileExtensions);
				return false;
			}*/
			//While downloading already uploaded files we are not checking extensions
			//extensions are already validated while uploading
			return true;
		} else {
			logger.warn("File name is empty.");
			return false;
		}
	}


	public static Boolean isValidCertificateFileExtension(String fileName) {
		if(StringUtils.isNotEmpty(fileName) && (fileName.indexOf(".") == fileName.lastIndexOf("."))){
			String fileExtension = FilenameUtils.getExtension(fileName);
			QMACache qmaCache = QMACacheFactory.getCache();
			StaticData staticData = qmaCache.getDefaultStaticData();
			List <String> allowedCertificateFileExtensions = staticData.getAllowedCertificateFileExtensions();
			if(StringUtils.isEmpty(fileExtension) || Objects.isNull(allowedCertificateFileExtensions) || allowedCertificateFileExtensions.isEmpty() || !allowedCertificateFileExtensions.contains(fileExtension.toLowerCase())) {
				logger.error("Certificate File with extension {} is restricted, allowed list of extensions are : {}", fileExtension,allowedCertificateFileExtensions);
				return false;
			}
		} else {
			logger.error("Either fileName is empty or contains double extension.");
			return false;
		}
		return true;
	}
	public static boolean isValidFileName(String inputFileName) {
		boolean isValidFileName = false;
		if(null != inputFileName) {
			inputFileName = inputFileName.replaceAll(ESCAPE_CHARS, "_");
		}else {
			return isValidFileName;
		}
		String validFileNameRegex = VALID_FILENAME_REGEX ;
		logger.info("SBT: validating input file name: {} with regex: {}", inputFileName,validFileNameRegex );
		if(validFileNameRegex == null || validFileNameRegex.isEmpty()) {
			logger.info("SBT: Regex for validating input file name is empty or null: {}",validFileNameRegex);
			//isValidFileName = true; // it has to be mandatory, let's not make this check as optional.
		} else {
			try {
			isValidFileName = (StringUtils.isNotEmpty(inputFileName) && inputFileName.matches(validFileNameRegex));
			if(!isValidFileName){
				isValidFileName = !containsBlockedCharacter(inputFileName);
			}
			isValidFileName = isValidFileName  && isValidFileExtension(inputFileName);
			} catch (Exception e) {
				logger.error("Exception while validating input file name : " + inputFileName , e);
			}
		}
		return isValidFileName; 
	}

	private static boolean containsBlockedCharacter(String inputFileName) {
		boolean containsBlockedCharacter = false;
		logger.info("Validating if the input fileName contains blocked characters");
		if (!StringUtils.isEmpty(inputFileName)) {
			QMACache qmaCache = QMACacheFactory.getCache();
			StaticData staticData = qmaCache.getDefaultStaticData();
			List<String> blockedFileNameCharacters = staticData.getBlockedFileNameCharacters();
			for (int i = 0; i < inputFileName.length(); i++) {
				if (isBlockedCharacter(inputFileName.charAt(i),blockedFileNameCharacters)) {
					containsBlockedCharacter = true;
					logger.info("input filename contains blocked character : {}",inputFileName.charAt(i));
					break;
				}
			}
		} else {
			logger.info("File name is either null or empty.");
		}
		return containsBlockedCharacter;
	}

	public static boolean isValidFileNameForIncomingEmails() {
		boolean isValidFileName = false;
		String validFileNameRegex = "";
		if (null != QMACacheFactory.getCache().getConfigById("FileNameAndPathValidation")) {
			Config validationConfig = QMACacheFactory.getCache().getConfigById("FileNameAndPathValidation");
			if (validationConfig.getFileNameRegex() != null) {
				validFileNameRegex = validationConfig.getFileNameRegex();
			}
		}
		if(validFileNameRegex == null || validFileNameRegex.isEmpty()) {
			logger.info("SBT: Regex for validating input file name is empty or null: {}",validFileNameRegex);
			isValidFileName = true;
		}
		return isValidFileName;
	}


	private static String replaceBlockedCharacters(String inputFileName) {
		String updatedName = inputFileName;
		logger.info("Replacing blocked characters from input file name if any {}",inputFileName);
		if (!StringUtils.isEmpty(inputFileName)) {
			QMACache qmaCache = QMACacheFactory.getCache();
			StaticData staticData = qmaCache.getDefaultStaticData();
			List<String> blockedFileNameCharacters = staticData.getBlockedFileNameCharacters();
			logger.error("Blocked list of characters are : {}", blockedFileNameCharacters);
			for (int i = 0; i < inputFileName.length(); i++) {
				if ( isBlockedCharacter(inputFileName.charAt(i),blockedFileNameCharacters)) {
					updatedName = updatedName.replace(updatedName.charAt(i), CHAR_TO_BE_REPLACED_FOR_BLOCKED_CHARACTER);
				}
			}
		} else {
			logger.info("File name is either null or empty.");
		}
		return updatedName;
	}

	private static boolean isBlockedCharacter(char c,List<String> blockedFileNameCharacters) {
		boolean isBlockedCharacter = false;
		try {
			String character = String.valueOf(c);
			if (Objects.isNull(blockedFileNameCharacters) || blockedFileNameCharacters.isEmpty() || blockedFileNameCharacters.contains(character)) {
				logger.error("Filename contains character {} which is not valid", c);
				isBlockedCharacter = true;
			}
		} catch (Exception e){
			logger.warn("Exception while validating if input filename contains blocked character : ",e);
		}
		return isBlockedCharacter;
	}


	//[C170665-1723] - SBT Path Traversal Issue Fixing
	public static boolean isValidPath(String fullPath) {
		boolean isValidPath = false;
		logger.info("SBT: FullPath: {}", fullPath);
		try {
			if(fullPath != null && !fullPath.isEmpty())
			{
				File file = new File(fullPath);
				String canonicalPath = file.getCanonicalPath();
				String absolutePath = file.getAbsolutePath();
				String finalPath = sanitizeFileNameForPathTraversal(canonicalPath);
				if(!canonicalPath.equals(finalPath) || !absolutePath.equals(finalPath)) {
					logger.error("Exception while validating full path : {}", fullPath);
					isValidPath = false;
				}else {
					isValidPath = true;
				}
				String fileName = fullPath.substring(fullPath.lastIndexOf('/')+1, fullPath.length());
				logger.info("FileName: {}",fileName);
				if(!isValidFileExtension(fileName)) {
					logger.error("Exception while validating file Extension : {}", fileName);
					isValidPath = false;
				}
			}else {
				logger.error("Specified Path is Empty " + fullPath);
			}	
		}catch(InvalidPathException e) {
			logger.error("Exception while validating full path : " + fullPath, e);
		} catch (IOException e) {
			logger.error("Exception while validating full path : " + fullPath, e);
		}
		return isValidPath;
	}


	/**
	 * This is created to support download of already existing and uploaded files
	 * @param fullPath
	 * @return
	 */
	public static boolean isValidPathForFileRead(String fullPath) {
		boolean isValidPath = false;
		logger.info("SBT: FullPath: {}", fullPath);
		try {
			if(fullPath != null && !fullPath.isEmpty())
			{
				File file = new File(fullPath);
				String canonicalPath = file.getCanonicalPath();
				String absolutePath = file.getAbsolutePath();
				String finalPath = sanitizeFileNameForPathTraversal(canonicalPath);
				if(!canonicalPath.equals(finalPath) || !absolutePath.equals(finalPath)) {
					logger.error("Exception while validating full path : {}", fullPath);
					isValidPath = false;
				}else {
					isValidPath = true;
				}
				String fileName = fullPath.substring(fullPath.lastIndexOf('/')+1, fullPath.length());
				logger.info("FileName: {}",fileName);
				// While downloading a file from S3 or any inline images there is no standard format followed for generating a file name
				// It is difficult to apply check for all kind of file name getting generated from multiple locations
				// Hence disabling file extension check for all those file getting downloaded(already uploaded in system)
				/*if(!isValidFileExtensionForFileDownload(fileName)) {
					logger.error("Exception while validating file Extension : {}", fileName);
					isValidPath = false;
				}*/
			}else {
				logger.error("Specified Path is Empty " + fullPath);
			}
			logger.info("'isValidPath' : {} for filename getting downloaded : {}",isValidPath,fullPath);
		}catch(InvalidPathException e) {
			logger.error("Exception while validating full path : " + fullPath, e);
		} catch (IOException e) {
			logger.error("Exception while validating full path : " + fullPath, e);
		}
		return isValidPath;
	}


	public static boolean isValidCertificatePath(String fullPath) {
		boolean isValidPath = false;
		logger.info("SBT: FullPath: {}", fullPath);
		try {
			if(fullPath != null && !fullPath.isEmpty())
			{
				File file = new File(fullPath);
				String canonicalPath = file.getCanonicalPath();
				String absolutePath = file.getAbsolutePath();
				String finalPath = sanitizeFileNameForPathTraversal(canonicalPath);
				if(!canonicalPath.equals(finalPath) || !absolutePath.equals(finalPath)) {
					logger.error("Exception while validating full path : {}", fullPath);
					isValidPath = false;
				}else {
					isValidPath = true;
				}
				String fileName = fullPath.substring(fullPath.lastIndexOf('/')+1, fullPath.length());
				logger.info("FileName: {}",fileName);
				if(!isValidCertificateFileExtension(fileName)) {
					logger.error("Exception while validating file Extension : {}", fileName);
					isValidPath = false;
				}
			}else {
				logger.error("Specified Path is Empty " + fullPath);
			}
		}catch(InvalidPathException e) {
			logger.error("Exception while validating full path : " + fullPath, e);
		} catch (IOException e) {
			logger.error("Exception while validating full path : " + fullPath, e);
		}
		return isValidPath;
	}

	public static String sanitizeFileNameForPathTraversal(String finalPath) {

		List<Character> invalidChars = null;
		if (null != QMACacheFactory.getCache().getConfigById("FileNameAndPathValidation")) {
			Config validationConfig = QMACacheFactory.getCache().getConfigById("FileNameAndPathValidation");
			if (validationConfig.getInvalidChars() != null) {
				invalidChars = validationConfig.getInvalidChars();
			}
		}
    	if(invalidChars != null && !invalidChars.isEmpty()) {
    		 for(Character invalidChar:invalidChars) {
    	        	if (-1 != finalPath.indexOf(invalidChar)) {
    	            	finalPath = finalPath.replace(invalidChar, SANITIZED_CHAR);
    	            	logger.info("Sanitized invalid character {} in path: {} ",invalidChar, finalPath);
    	            }
    	        }
    	}
		finalPath = finalPath.replaceAll("%00","");
		finalPath = finalPath.replaceAll(",","");
		finalPath = finalPath.replaceAll("\\\\\\\\","");
		finalPath = finalPath.replaceAll("//","_");
		logger.info("Sanitized file path: {} ", finalPath);
        return finalPath;
	}

	public static boolean isValidFilePath(String fullPath) {
		boolean isValidPath = false;
		logger.info("SBT: FullPath: {}", fullPath);
		try {
			if(fullPath != null && !fullPath.isEmpty())
			{
				File file = new File(fullPath);
				String canonicalPath = file.getCanonicalPath();
				String absolutePath = file.getAbsolutePath();
				String finalPath = sanitizeFileNameForPathTraversal(canonicalPath);
				if(!canonicalPath.equals(finalPath) || !absolutePath.equals(finalPath)) {
					logger.error("Exception while validating full path : {}", fullPath);
					isValidPath = false;
				}else {
					isValidPath = true;
				}
			}else {
				logger.error("Specified Path is Empty " + fullPath);
			}
		}catch(InvalidPathException e) {
			logger.error("Exception while validating full path : " + fullPath, e);
		} catch (IOException e) {
			logger.error("Exception while validating full path : " + fullPath, e);
		}
		return isValidPath;
	}
	
	

	public static String checkAndFetchConvContent(Conversation conv) {
		String content = null;
		try {
			if (conv == null) {
				logger.info("Conversation is null");
				return content;
			}
			content = conv.getContent();
			if (conv.isContentArchivedToS3() && StringUtils.isNotBlank(conv.getContentS3UUID())	&& StringUtils.isBlank(conv.getContent())) {
				logger.info("Extracting inq : {}, conv : {} contents from AmazonS3 Cloud ",  conv.getInquiryId(),conv.getId());
				initializeAwsS3Connection();
				if (awsUtility != null) {
					content = awsUtility.readObject(awsUtility.getConnection(), conv.getContentS3UUID());
				} else {
					logger.info("awsUtility identified as null while extracting content for convId : {}, inquiryId :{}" + conv.getId(), conv.getInquiryId());
				}
			} else {
				logger.info("Returning normal contents for  inq : {}, conv : {} from object itself", conv.getInquiryId(), conv.getId());
			}
		} catch (Exception e) {
			logger.warn("Exception while checkAndFetchArchivedContent for convId : {}, inquiryId :{}" + conv.getId(), conv.getInquiryId(), e);
		}
		return content;
	}
	
	/**
	 * 
	 */
	public static AWSUtility initializeAwsS3Connection() {
		try {
			if (awsUtility == null) {
				String DB_S3_BUCKET_CONFIG_KEY = "s3BucketConfig";
				String DB_S3_END_POINT_REGION="endPointRegion";
				String DB_S3_CONV_CONTENT_STORE="convContentS3Store";
				String DB_S3_BUCKET_NAME="bucketName";
				String DB_S3_ACCESS_KEY_NAME="accessKeyName";
				String DB_S3_SECRET_KEY_NAME="secretKeyName";
				String DB_S3_END_POINT="endPoint";
				Map<String, Object> s3BucketConfigMap = getConfigFromDB();//QMACacheFactory.getCache().getConfigById(DB_S3_BUCKET_CONFIG_KEY).getS3BucketConfig();
				if(null != s3BucketConfigMap && !s3BucketConfigMap.isEmpty()) { // sonar fix null pointer
					Map<String, Object> convBucketMap = GenericUtility.getMapValueFromMap(s3BucketConfigMap, DB_S3_CONV_CONTENT_STORE);
					String bucketName = GenericUtility.getStringValueFromMap(convBucketMap, DB_S3_BUCKET_NAME);
					String accessKeyName = GenericUtility.getStringValueFromMap(convBucketMap, DB_S3_ACCESS_KEY_NAME);
					String secretKeyName = GenericUtility.getStringValueFromMap(convBucketMap, DB_S3_SECRET_KEY_NAME);
					String endPoint = GenericUtility.getStringValueFromMap(convBucketMap, DB_S3_END_POINT);
					String endPointRegion = GenericUtility.getStringValueFromMap(convBucketMap, DB_S3_END_POINT_REGION);
					awsUtility = new AWSUtility(bucketName, accessKeyName, secretKeyName, endPoint, endPointRegion);
				}else {
					logger.info("S3 bucket config not found in Config collection or cache.");
				}
			}
		} catch (Exception e) {
			logger.warn("Exception while initialize AwsS3Connection",e);
		}
		return awsUtility;
	}
	private static Map<String, Object> getConfigFromDB() {
		Map<String, Object> configMap = null;
		Query<Config> query = MongoDB.instance().getDataStore().createQuery(Config.class).filter("_id", "s3BucketConfig");
		List<Config> configDataList = query.asList();
		for (Config config : configDataList) {
			if (config != null) {
				configMap = config.getS3BucketConfig();
				break;
			}
		}
		return configMap;
	}

	/**
	 * @param map
	 * @param key
	 * @return
	 */
	public static Map<String, Object> getMapValueFromMap(Map<String, Object> map, String key) {
		if(null!=map && StringUtils.isNotEmpty(key) && null != map.get(key)){
			Map<String, Object> value = (Map<String, Object>) map.get(key);
			return value;
		}
		return null;
	}
	/**
	 * @param map
	 * @param key
	 * @return
	 */
	public static String getStringValueFromMap(Map<String, Object> map, String key) {
		if(null!=map && StringUtils.isNotEmpty(key) && null != map.get(key)){
			String value = (String) map.get(key);
			return value;
		}
		return null;
	}

	public static String getCurrentHost(){
		String currentHost = null;
		try {
			InetAddress hostNameAdd = InetAddress.getLocalHost();
			currentHost = null != hostNameAdd ? hostNameAdd.toString() : "";
		} catch (UnknownHostException e) {
			logger.error("Exception while retrieving current host :", e);
		}
		return currentHost;
	}
	
	public static List<Long> convertToListOfLong(List<String> convIds){
		logger.info("Start Method :: convertToListOfLong");
		List<Long> listOfLong = new ArrayList<Long>();
		try {
			listOfLong = convIds.stream().map(Long::valueOf).collect(Collectors.toList());
		} catch(NumberFormatException e) {
			logger.warn("Exception in convertToListOfLong :: ",e);
		}
		logger.info("End Method :: convertToListOfLong");
		return listOfLong;
	}
	
	// Method to sanitize input string for Cross Site Scripting attacks
	
	public static String sanitizeInputString(String string) {
		return string.replaceAll("(?i)<script.*?>.*?</script.*?>", "") 
		                .replaceAll("(?i)<script.*?/>", "") 
		                .replaceAll("(?i)<script.*?>", "")
		                .replaceAll("(?i)<.*?javascript:.*?>.*?</.*?>", "") 
		                .replaceAll("(?i)<.*?javascript:.*?/>", "") 
		                .replaceAll("(?i)<.*?javascript:.*?>", "") 
		                .replaceAll("(?i)<.*?\\s+on.*?>.*?</.*?>", "")
		                .replaceAll("(?i)<.*?\\s+on.*?/>", "")
		                .replaceAll("(?i)<.*?\\s+on.*?>", ""); 
		 }
	
	
	public static boolean isAutoReplyEnabled(String email, Group fromGroup, QMACache qmaCache) {
		logger.info("Start Method isAutoReplyEnabled");
		boolean isAutoReplyEnabled = false;
		boolean isCitiDomain = GenericUtility.isCitiDomainEmail(email);
		logger.info("isAutoReplyEnabled :: isCitiDomain :: {}",isCitiDomain);
		boolean isAutoResponseEnabledForInternalDomain = fromGroup.isAutoResponseEnabledForInternalDomain();
		logger.info("isAutoResponseEnabledForInternalDomain :: {}", isAutoResponseEnabledForInternalDomain);

		if(fromGroup.isCustomizedAutoResponseEnabled()) {

			logger.info("isAutoReplyEnabled :: customized auto response is enabled");
			if(!isCitiDomain) {
				isAutoReplyEnabled = true;
			} else {
				Config autoResponseConfig = qmaCache.getConfigById("AutoResponse");
				boolean isCustomizedAutoResponseEnabledForInternalDomain = false;
				if(autoResponseConfig != null) {
					isCustomizedAutoResponseEnabledForInternalDomain = autoResponseConfig.isCustomAutoResponseEnabledForInternalDomain();
					logger.info("isAutoReplyEnabled :: isCustomizedAutoResponseEnabledForInternalDomain :: {}", isCustomizedAutoResponseEnabledForInternalDomain);
				}
				isAutoReplyEnabled = isCustomizedAutoResponseEnabledForInternalDomain;
			}
		} else {
			isAutoReplyEnabled = !isCitiDomain || isAutoResponseEnabledForInternalDomain;
		}
		logger.info("End Method isAutoReplyEnabled :: {}",isAutoReplyEnabled);
		return isAutoReplyEnabled;
	}
	
}
