/**
 * 
 */
package com.citi.icg.qma.common.server.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;

public class GlobalDirectoryUtil {
	private static final Logger logger = LoggerFactory.getLogger(GlobalDirectoryUtil.class);

	public static final String ERROR = "Error:";

	private static final String SEARCH_PARAMS_INFO_TYPE_BASIC = "searchParamsInfoTypeBASIC";
	private static final String SEARCH_PARAMS_INFO_TYPE_BASIC_GEID = "searchParamsInfoTypeBASICGEID";
	private static final String CONTACT_INFO_CONFIG = "contactInfoConfig";
	private static final String CONTACT_INFO_END_POINT = "contactInfoEndPoint";
	private static final String AUID_GDIR_CONTANT_INFO = "auid";
	private static final String SOEID_KEY = "SOEID";
	private static final String GEID_KEY = "GEID";
	private static final String GET = "GET";
	private static final List<Integer> RESPONSEERRORCODES = Arrays.asList(400, 403, 404, 206);
	private static final String LOGMSG = "WS ResponseCode is ";
	private static final String ERRORCODE = "ERRORCODE:";
	public static final String ENABLE_NEW_REST_END_POINT = "enableNewRestEndPoint";
	public static final String CONTACT_INFO_END_POINT_XML = "contactInfoEndPoint_xml";
	public static final String GD_ENABLE_NEW_REST_END_POINT = "GD:: enableNewRestEndPoint: ";
	public static final String AU_ID = "#auid#";
	public static final String GE_ID_STRING_WITH_HASH = "#geId#";
	
	
	private GlobalDirectoryUtil() {}
	
	/**
	 * API call to global dir to fetch BASIC user details
	 * 
	 * @param id
	 * @param serachType
	 * @param globalDirConfig
	 * @return
	 */
	public static String fetchUserDetailsFromGlobDir(String id, String serachType, Map<String, Object> globalDirConfig) {
		BasicDBObject contactInfo = (BasicDBObject) globalDirConfig.get(CONTACT_INFO_CONFIG);
		String auid = (String) contactInfo.get(AUID_GDIR_CONTANT_INFO);
		String endPointUrl = (String) contactInfo.get(CONTACT_INFO_END_POINT);
		String searchParamsInfoTypeBASIC = (String) contactInfo.get(SEARCH_PARAMS_INFO_TYPE_BASIC);
		String searchParamsInfoTypeBASICGEID = (String) contactInfo.get(SEARCH_PARAMS_INFO_TYPE_BASIC_GEID);
		boolean enableNewRestEndPoint = (boolean) contactInfo.get(ENABLE_NEW_REST_END_POINT);
		String endPointUrlXml = (String) contactInfo.get(CONTACT_INFO_END_POINT_XML);
		String searchParamsInfoTypeBASICXml = (String) contactInfo.get("searchParamsInfoTypeBASIC_xml");
		String finalUrl = null;
		logger.info(GD_ENABLE_NEW_REST_END_POINT, ":: {}", enableNewRestEndPoint);
		if (enableNewRestEndPoint) {
			if (SOEID_KEY.equalsIgnoreCase(serachType)) {
				finalUrl = endPointUrl + searchParamsInfoTypeBASIC.replace("#id#", id).replace(AU_ID, auid);
			} else if (GEID_KEY.equalsIgnoreCase(serachType)) {
				finalUrl = endPointUrl + searchParamsInfoTypeBASICGEID.replace("#id#", id).replace(AU_ID, auid);
			}
		} else {
			finalUrl = endPointUrlXml + searchParamsInfoTypeBASICXml.replace("#serachType#", serachType)
					.replace("#id#", id).replace(AU_ID, auid);
		}

		String apiResponse = null;
		try {
			apiResponse = doRequest(finalUrl, GET);
		} catch (Exception ex) {
			logger.error(finalUrl + ": Response:", apiResponse, ex);
		}
		return apiResponse;
	}

	/**
	 * @param urlString
	 * @param method
	 * @return
	 * @throws IOException
	 */
	public static String doRequest(String urlString, String method) {
		logger.info("GD:: Global directory url :{} for method : {}", urlString, method);
		String responseString = null;
		try {
			URL url = URI.create(urlString).toURL();
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod(method);
			conn.setDoOutput(true);
			Integer responseCode = conn.getResponseCode();
			if (responseCode == 200) {
				BufferedReader in = new BufferedReader(
						new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				String inputLine;
				StringBuilder response = new StringBuilder();
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
				responseString = response.toString();
			} else if (RESPONSEERRORCODES.contains(responseCode)) {
				logger.info(LOGMSG, "{} is thrown by  Global Dir server and responseMsg is -{}", responseCode,
						conn.getResponseMessage());
				return null;
			} else {
				logger.info(LOGMSG, "{} is thrown by  Global Dir server and responseMsg is -{}", responseCode,
						conn.getResponseMessage());
				return "{" + ERRORCODE + responseCode + "}";
			}
		} catch (Exception e) {
			logger.error("Error while consuming global dir service:", e);
		}
		return responseString;
	}
	
	public static Map<String, Object> getGlobalDirectoryConfig() {
		try {
			QMACache qmaCache = QMACacheFactory.getCache();
			if (null != qmaCache.getConfigById("globalDirectoryConfig")){
				Config globalDirectoryConfig = qmaCache.getConfigById("globalDirectoryConfig");
				if (null != globalDirectoryConfig && null != globalDirectoryConfig.getGlobalDirectoryConfig()){
					return globalDirectoryConfig.getGlobalDirectoryConfig();
				}
			}
		}catch(Exception ex) {
			logger.error("Error while fetching config",ex);
		}
		return null;
	}
}
