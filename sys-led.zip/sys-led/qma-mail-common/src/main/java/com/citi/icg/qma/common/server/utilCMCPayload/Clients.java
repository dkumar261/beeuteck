package com.citi.icg.qma.common.server.utilCMCPayload;

public class Clients
{
    private String clientId;

    private String clientIdType;

    public String getClientId ()
    {
        return clientId;
    }

    public void setClientId (String clientId)
    {
        this.clientId = clientId;
    }

    public String getClientIdType ()
    {
        return clientIdType;
    }

    public void setClientIdType (String clientIdType)
    {
        this.clientIdType = clientIdType;
    }

    @Override
    public String toString()
    {
        return "InputForCMC [clientId = "+clientId+", clientIdType = "+clientIdType+"]";
    }
}