package com.citi.icg.qma.common.server.dao.persistence;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.stream.Collectors;

import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.ws.rs.core.Response;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPathFactory;

import com.citi.icg.qma.common.server.dao.*;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.core.util.InquiryUtil;
import com.citi.icg.qma.common.core.util.MailServiceGenericUtil;
import com.citi.icg.qma.common.core.util.NLPConstants;
import com.citi.icg.qma.common.core.util.QMAActionEnum;
import com.citi.icg.qma.common.core.util.QmaMailConstants;
import com.citi.icg.qma.common.core.util.SolrSocketFactory;
import com.citi.icg.qma.common.core.util.ZipUtil;
import com.citi.icg.qma.common.exception.QMAException;
import com.citi.icg.qma.common.messagebus.entity.PrepareMessageBusPayload;
import com.citi.icg.qma.common.messagebus.resolveinquiry.entity.Data;
import com.citi.icg.qma.common.messagebus.resolveinquiry.entity.EntityDetails;
import com.citi.icg.qma.common.messagebus.resolveinquiry.entity.Payload;
import com.citi.icg.qma.common.messagebus.util.MessageBusUtil;
import com.citi.icg.qma.common.server.cache.ConversationCache;
import com.citi.icg.qma.common.server.dao.QMALinkEntities.EntityGroupData;
import com.citi.icg.qma.common.server.dao.QMALinkEntities.EntityRecord;
import com.citi.icg.qma.common.server.util.AgeAndTimeUtils;
import com.citi.icg.qma.common.server.util.AutoReplyHelper;
import com.citi.icg.qma.common.server.util.ClientMappingUtil;
import com.citi.icg.qma.common.server.util.DateUtil;
import com.citi.icg.qma.common.server.util.EscalationUtility;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.common.server.util.NLPRequestType;
import com.citi.icg.qma.common.server.util.SmartSearchUtil;
import com.citi.icg.qma.common.server.util.SuggestionStatusIndicator;
import com.citi.icg.qma.common.transferobject.ConversationTO;
import com.citi.icg.qma.common.transferobject.DashBoardCntTO;
import com.citi.icg.qma.common.transferobject.DraftTO;
import com.citi.icg.qma.common.transferobject.GridColumnsTO;
import com.citi.icg.qma.common.transferobject.UserTO;
import com.citi.icg.qma.common.transferobject.WorkflowTO;
import com.citi.icg.qma.hazelcast.cache.client.HazelCastCacheIncrementalLoad;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.AggregationOptions;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.Cursor;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.ReadPreference;

import dev.morphia.Datastore;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;
import microsoft.exchange.webservices.data.core.enumeration.service.DeleteMode;


public class InquiryDAO extends InquiryCommonDAO
{

	private static final String CC = "cc";
	private static final String TO = "to";
	private static final String FROM = "from";
	private static final String WORKFLOWS_$_FOLLOW_UP = "workflows.$.followUp";
	private static final String UNASSIGNED = "Unassigned";
	private static final String ASSIGNED_TO_ME_VIEW = "Assigned to me";
	private static final String UN_ASSIGNED_USER_ID = "#assignedUserId#";
	private static final String AGE_BAND_FROM_DATE = "ageBandFromDate";
	private static final String AGE_BAND_TO_DATE = "ageBandToDate";
	private static final String AUTO_ASSIGNED = "autoAssigned";
	private static final String CLNT_CSTM_CATEGORY = "clntCstmCategory";
	private static final String CUSTOM_CLIENT_CATEGORY = "customClientCategory"; 
	private static final String CLIENT_PRIORITY = "clientPriority";
	private static final String PERSONAL_FOLDER_NAME = "personalFolderName";
	private static final Logger subLogger = LoggerFactory.getLogger(InquiryDAO.class);
	private static final String INTENSITY_HEAT_MAP = "intensityHeatMap";
	private static final String HEADER_NAME = "headerName";
	private static final String CLIENT_CATEGORY_SUPERCHARGE = "Supercharge";
	private static final String COL_ID = "colId";
	private static final String HIDE_KEY = "hide";
	private static final String TAG_SEARCH = "tagSearch";
	private static final String TOTAL_UNREAD_RECORDS = "totalUnreadRecords";
	private static final String TOTAL_RECORDS = "totalRecords";
	private static final String TAG_VIEW = "tag view";
	private static final String ASSIGNED_OWNER_ID = "assignedOwnerId";
	private static final String IS_REQ_FROM_QMA2_DASHBOARD2 = "isReqFromQma2Dashboard";
	private static final String IS_REQ_FROM_QMA2_DASHBOARD = IS_REQ_FROM_QMA2_DASHBOARD2;
	private static final String OPEN_INQUIRIES_BY_REQUEST_TYPE = "Open Inquiries By Request Type";
	private static final String OPEN_INQUIRIES_BY_ASSIGNED_OWNERS = "Open Inquiries By Assigned Owners";
	private static final String ACTION_NOMINATE_OWNERSHIP = "NOMINATE_OWNERSHIP";
	private static final String USER_NOTES = "userNotes";
	private static final String NOMINATE_OTHER_OWNERSHIP = "NOMINATE_OTHER_OWNERSHIP";
	private DB database = MongoDB.instance().getDB();
	private DB databaseSecondary = MongoDB.instance().getSecondaryDB();
	public static final String INQUIRY_DIRECTION_IN = "IN";
	public static final String INQUIRY_DIRECTION_OUT = "OUT";
	// Only used to find query where IN or OUT is used
	private static final String INQUIRY_DIRECTION_IN_OR_OUT = "IN_OR_OUT";
	private static final String INQUIRY_DIRECTION_IN_OR_OUT_OR_PA = "IN_OR_OUT_OR_PA";
	private static final String INQUIRY_DIRECTION_PENDING_APPROVAL = "PENDINGAPPROVAL";
	private static final String INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE = "PND_REAGE";
	public static final String CC_CATEGORY = "CC";
	public static final String BCC_CATEGORY = "BCC";
	// Sonar Fix -- Unused local variables should be removed
	private static final String INTERNAL = "INTERNAL";
	private static final String EXTERNAL = "EXTERNAL";
	public static final String FROM_CATEGORY = "FROM";
	public static final String STATUS_OPEN = "Open";
	public static final String STATUS_RESOLVE = "Resolved";
	private static final String WORKFLOW_STATUS_PND_RE_AGE = "Pending Approval - Re-age Inquiry";
	private static final String WORKFLOW_STATUS_PND_OUTBOUND_EMAIL = "Pending Approval - Outbound email";
	private static final String WORKFLOW_STATUS_PND_SIRT_EXT_DOMAIN_EMAIL ="Pending Approval - Potential SIRT (Incorrect Client)";
	private static final String WORKFLOW_STATUS_AP_OUTBOUND_EMAIL = "Approved - Outbound email";
	private static final String WORKFLOW_STATUS_RJ_OUTBOUND_EMAIL = "Rejected - Outbound email";
	private static final String WORKFLOW_STATUS_AP_SIRT_EXT_DOMAIN_EMAIL = "Approved - Potential SIRT (Incorrect Client)";
	private static final String WORKFLOW_STATUS_RJ_SIRT_EXT_DOMAIN_EMAIL = "Rejected - Potential SIRT (Incorrect Client)";
	private static final String WORKFLOW_STATUS_AP_RE_AGE = "Approved - Re-age Inquiry";
	private static final String WORKFLOW_STATUS_RJ_RE_AGE = "Rejected - Re-age Inquiry";
	public static final String TO_CATEGORY = "TO";
	public static final String ACTION_NEW = "New Inquiry";
	public static final String ACTION_NEW_RESOLVE = "New Inquiry Resolve";
	public static final String ACTION_REPLY = "Reply";
	public static final String ACTION_REPLY_ALL = "ReplyAll";
	public static final String ACTION_FORWARD = "Forward";
	public static final String ACTION_REPLY_RESOLVE = "Reply Resolve";
	public static final String ACTION_REPLYALL_RESOLVE = "ReplyAll Resolve";
	public static final String ACTION_REPLY_RESOLVE_ALL = "Reply ResolveAll";
	public static final String ACTION_REPLYALL_RESOLVE_ALL = "ReplyAll ResolveAll";
	public static final String ACTION_RESOLVE = "Resolve";
	public static final String ACTION_ASSIGN_TO_OWNER = "Assign Owner";
	public static final String ACTION_TAKE_OWNERSHIP = "Take Ownership";
	public static final String RESOLVE_ACTION_TAKE_OWNERSHIP = "Resolve By Other Group Ownership";
	private static final String ACTION_SELF_ASSIGN = "Self Assign";
	public static final String ACTION_ASSIGN_REQ_TYPE = "Assign Request Type";
	public static final String ACTION_ASSIGN_ROOT_CAUSE = "Assign Root Cause";
	private static final String ACTION_ASSIGN_TAG = "Assign Tag";
	private static final String ACTION_REOPEN = "Reopen";
	private static final String ID_COLUMN = "_id";
	private static final String AND_CRITERIA_OPERATOR = "$and";
	// Sonar Fix -- Unused local variables should be removed
	private static final String ACTION_APPROVE = "Approve";
	private static final String ACTION_REJECT = "Reject";
	private static final String ACTION_RE_AGE = "Re Age Inquiry";
	private static final String ACTION_MANUAL_ESCALATE = "Manual Escalation";
	private static final String MANUAL_ESC_REASON_KEY = "manualEscReason";
	private static final String ACTION_APPROVE_RJ_EMAIL = "Email Approval";
	private static final String LINK_EXCEPTION = "Link Exception";
	private static final String STRING_YES = "Y";
	
	XPathFactory factory = XPathFactory.newInstance();
	DocumentBuilderFactory documentBuilderFactory = null;
	private static UserDAO userDao = new UserDAO();
	private static AttachmentDAO attachDao = new AttachmentDAO();
	public static final int MAX_SERVER_REC_LIMIT = 5000;
	private static final String ACTION_ASSIGN_PROCESSING_REGION = "Assign Processing Region";
	private static final String ACTION_OUT_OF_OFFICE = "Unassigned";
	private static final String ACTION_OUT_OF_OFFICE_DETAILS = "Unassigned for out of office";
	private static final String ACTION_ASSIGN_INQUIRY_SOURCE = "Assign Inquiry Source";
 
	public static final CLCOperationsDAO clcOperationDao = new CLCOperationsDAO();
	private static PrepareMessageBusPayload payload = new PrepareMessageBusPayload();
	

	/* Sonar Fix : Define a constant instead of duplicating literals in the code */
	public static final String DATE_FORMAT = "{0: M/d/yyyy h:mm tt}";
	public static final String OPEN_USERS = "openUsers";
	public static final String OPEN_GROUPS = "openGroups";
	public static final String MODIFIED_DATE = "modDate";
	public static final String REAGE_DATE = "reAgeDate";
	public static final String WORKFLOWS_ASSIGNED_USERID = "workflows.assignedUserId";
	public static final String WORKFLOWS_ASSIGNED_USERNAME = "workflows.$.assignedUserName";
	public static final String WORKFLOWS_ASSIGNED_USER_ID = "workflows.$.assignedUserId";
	
	public static final String WORKFLOWS_ASSIGNED_GROUPID = "workflows.assignedGroupId";
	public static final String WORKFLOWS_STATUS = "workflows.$.status";
	public static final String WORKFLOWS_OWNERSHIP = "workflows.$.hasOwnership";
	public static final String WORKFLOWS_RESOLVED_BY_OTHER_GROUP = "workflows.$.resolvedByOtherGroupOwnership";
	public static final String WORKFLOWS_RESOLVER = "workflows.$.resolver";
	public static final String WORKFLOWS_RESOLVE_TIME = "workflows.$.resolveTime";
	public static final String WORKFLOWS_REQUEST_TYPE = "workflows.$.requestType";
	public static final String WORKFLOWS_ROOT_CAUSE = "workflows.$.rootCause";
	public static final String WORKFLOWS_REOPENED_DATE = "workflows.$.reOpenDate";
	public static final String WORKFLOWS_PROCESSING_REGION = "workflows.$.processingRegion";
	public static final String WORKFLOWS_MODIFIED_DATE = "workflows.$.modDate";
	public static final String WORKFLOWS_MODIFIED_BY = "workflows.$.modBy";
	public static final String WORKFLOWS_LINK_ID = "workflows.$.linkId";
	public static final String WORKFLOWS_LAST_ACTION_BY = "workflows.$.lastActionby";
	// [C153176-1694] - Acknowledge Escalation flags
	public static final String WORKFLOWS_ACK_ESCALATION = "workflows.$.isAckEscalation";
	public static final String WORKFLOWS_ACK_ESCALATION_BY = "workflows.$.ackEscalationBy";
	public static final String WORKFLOWS_ACK_ESCALATION_TIME = "workflows.$.ackEscalationTime";
	private static final String ACTION_ACKNOWLEDGE_ESCALATION = "Acknowledge Escalation";

	// C153176-875
	public static final String WORKFLOWS_LOCKED_BY = "workflows.$.lockedBy";
	public static final String WORKFLOWS_LOCKED_TIME = "workflows.$.lockedDate";
	public static final String LOCKED_BY = "lockedBy";
	public static final String LOCKED_TIME = "lockedDate";
	public static final String UNLOCKED_BY = "unlockedBy";
	public static final String UNLOCKED_TIME = "unlockedDate";
	public static final String FORCE_UNLOCK = "forceUnlock";
	public static final String WORKFLOWS_LAST_ACTION_TIME = "workflows.$.lastActionTime";
	public static final String WORKFLOWS_INQUIRY_SOURCE = "workflows.$.inquirySource";
	public static final String WORKFLOWS_ACTION = "workflows.$.action";
	public static final String WORKFLOWS_TOTAL_RESOLVE_TIME = "workflows.$.totalResolveTimeQMA";
	public static final String WORKFLOWS_RESOLVE_COUNT = "workflows.$.resolveCountQMA";
	public static final String WORKFLOWS = "workflows";
	public static final String WORKFLOW_AUDIT = "workflowAudit";
	public static final String VIEW_TYPE = "viewType";
	public static final String VIEW_NAME = "viewName";
	public static final String MICRO_UI = "microUi";
	public static final String VIEW_DATA_TYPE = "viewDataType";
	public static final String RECORD_COUNT = "recordCount";
	public static final String VALUE = "value";
	public static final String USER_LIST = "userList";
	public static final String USER_ID = "userId";
	public static final String URGENT_FLAG = "urgentFlag";
	public static final String TAG = "tag";
	public static final String TAG_LIST = "tagList";
	public static final String SUBJECT = "subject";
	public static final String STATUS = "status";
	public static final String SOLR_SEARCH_TEXT = "solrSearchText";
	public static final String SOLR_QUERY = "solrQuery";
	public static final String SOLR_CRITERIA = "solrCriteria";
	public static final String ROOT_CAUSE = "rootCause";
	public static final String RESOLVER_LIST = "resolverList";
	public static final String RESOLVER = "resolver";
	public static final String RESOLVE_TIME = "resolveTime";
	public static final String REQUEST_TYPE_STR = "requestTypeStr";
	public static final String REQUEST_TYPE = "requestType";
	public static final String REQUEST_TYPE_LIST = "reqTypeList";
	public static final String RECEPIENTS = "recipients";
	public static final String READ_BY = "readBy";
	public static final String REOPEN_DATE = "reOpenDate";
	public static final String QUERY_COUNT = "queryCount";
	public static final String PROCESSING_REGION = "processingRegion";
	public static final String PROCESS_FLAG = "processFlag";
	public static final String MODIFIED_BY = "modBy";
	public static final String MAKER_CHECKER_REQUIRED = "makerCheckerRqd";
	public static final String LIST_BY_NAMES = "listByNames";
	public static final String LIST_BY_IDS = "listByIds";
	public static final String LAST_ACTION_BY = "lastActionby";
	public static final String LAST_ACTION_TIME = "lastActionTime";
	public static final String IS_TOP_LEVEL_VERSION_MATCH_REQ = "isTopLevelVersionMatchReq";
	public static final String IS_RETRIEVE_ALL = "isRetrieveAll";
	public static final String INQUIRY_SOURCE = "inquirySource";
	public static final String INQUIRY_IDS = "inquiryIds";
	public static final String INQUIRY_ID = "inquiryId";
	public static final String INQUIRY_DATE_LIST = "inquiryDataList";
	public static final String HOME_BOX = "homeBox";
	public static final String GROUP_NAME = "groupName";
	public static final String GROUP_ID = "groupId";
	public static final String GP_NAME = "gpNum";
	public static final String GFC_ID = "gfcid";
	public static final String FINAL_UI_CRITERIA = "finalUICriteria";
	public static final String FINAL_CRITERIA = "finalCriteria";
	public static final String DIRECTION = "direction";
	private static final String GROUP_IDS_KEY = "groupIds";
	private static final String IS_MULTI_GROUP_ACTION_KEY = "isMultiGroupAction";
	private static final String COMMON_GROUP_ID_KEY = "commonGroupId";

	// C153176-875
	public static final String LOCK = "lock";
	public static final String ACTION_LOCK = "Lock";
	public static final String ACTION_UNLOCK = "Unlock";
	public static final String DEFAULT_USER_CRITERIA = "defaultUserCriteria";
	public static final String DEFAULT_SELECTED_COLUMN_DEF_LIST = "defaultSelectedColumnDefList";
	public static final String CREATED_DATE = "crtDate";
	public static final String CONTENT = "content";
	public static final String COLUMN_DEFS = "columnDefs";
	public static final String ATTACH_FLAG = "attchFlag";
	public static final String ASSIGNED_USER_ID = "assignedUserId";
	public static final String ASSIGNED_GROUP_NAME = "assignedGroupName";
	public static final String ASSIGNED_GROUPID_LIST = "assignedGroupIdList";
	public static final String ASSIGNED_GROUPID = "assignedGroupId";
	public static final String APPROVAL_BYPASSED = "approvalBypassed";
	public static final String APPROVED_EXTERNAL_DOMAINS = "approvedExternalDomains";
	public static final String ADVANCED_SEARCH_DATA = "advanceSearchData";
	public static final String ADVANCED_SEARCH_GFPID = "advSearchGFPID";
	public static final String ACTION_DETAILS = "actionDetails";
	public static final String ACTION = "action";
	public static final String VERSION_MATCH_QRY_STR = "[VERSION_MATCH_QUERY]";
	public static final String ENCODING_UTF8 = "UTF-8";
	public static final String SEARCH = "Search";
	public static final String RESOLVED = "Resolved";
	public static final String INQUIRY = "Inquiry";
	public static final String INBOX = "Inbox";
	public static final String GFPID = "GFPID";
	public static final String GFCID = "GFCID";
	public static final String CRITERIA_MATCH_STR = ",{$match:";
	// [C153176-1082]-Enable de-escalate through context menu
	public static final String WORKFLOWS_CONV_COUNT_ESCALATION = "workflows.$.isConvCountEscalation";
	public static final String WORKFLOWS_RESPONSE_TIME_ESCALATION = "workflows.$.responseTimeEscalationFlag";
	public static final String WORKFLOWS_RESPONSE_TIME_ESCALATION_REASON = "workflows.$.responseTimeEscalationReason";
	public static final String WORKFLOWS_RESPONSE_TIME_NEXT_ESACLATION = "workflows.$.responseTimeNextEscalation";
	//[C170665-1719] DCC Requirement: Add Case status field
	public static final String INQUIRY_SUB_STATUS = "inquirySubStatus";
	public static final String ACTION_ASSIGN_INQUIRY_SUB_STATUS = "Assign Inquiry Sub-Status";
	public static final String WORKFLOWS_INQUIRY_SUB_STATUS = "workflows.$.inquirySubStatus";
	//[C170665-1719] DCC Requirement: Add Case status field
	public static final String WORKFLOWS_INQUIRY_SUB_STATUS_PENDING_INTERNAL = "workflows.$.isSubStatusPendingInternal";
	public static final String SUB_STATUS_COMPLETED = "Completed";
	public static final String SUB_STATUS_REOPEN = "Reopen - To be reviewed";
	public static final String SUB_STATUS_MESSAGE_TO_REVIEW = "Message to review";
	public static final String SUB_STATUS_NEW = "New";
	public static final String SUB_STATUS_PENDING_INTERNAL = "Pending - Internal";
	public static final String WORKFLOWS_ISPENDINGAPPROVAL_ESCALATION = "workflows.$.ispendingApprovalEscalation";
	public static final String WORKFLOWS_CLIENT_CHASE_ESCALATION = "workflows.$.isClientChaseEscalation";
	public static final String WORKFLOWS_SUBJECT_ESCALATION = "workflows.$.isSubjectEscalation";
	public static final String WORKFLOWS_GENERAL_ESCALATION_REASON = "workflows.$.generalEscalationReason";
	public static final String WORKFLOWS_MANUAL_ESCALATION = "workflows.$.isManualEscalation";
	public static final String WORKFLOWS_MANUAL_ESCALATION_REASON = "workflows.$.manualEscalationReason";
	public static final String ACTION_DEESCALATE = "De-escalate";
	public GroupDAO groupDAO = new GroupDAO();
	private IInquiryActionStat iInquiryActionStat = new InquiryActionStatDAO();
	public static final String FOLLOWUP = "FollowUp";
	public static final String REMOVE_FOLLOWUP = "RemoveFollowUp";
	public static final String NEW_REAGE_REQUESTS = "newRequests";
	public static final String OLD_REAGE_REQUESTS = "oldRequests";
	public static final String SUCCESS_KEY = "success";
	public static final String FOLLOWUP_FLAG = "followUp";
	public static final String MEMO = "memo";	
	public static final String SUGGESTION_ACCEPTED = "ReplyAll - Suggestion Accepted";

	private static final String RE_OPEN_AGE_IN_DAYS = "reOpenAgeInDays";
	private static final String AGE_IN_DAYS = "ageInDays";
	private static final String RE_OPEN_AGE_IN_HRS = "reOpenAgeInHrs";
	private static final String RE_OPEN_AGE = "reOpenAge";
	private static final String AGE_IN_HRS = "ageInHrs";
	
	public static final String MOD_DATE_EXP = "#MOD_DATE#";
	private static final String VERSION_BOX_MATCH_QUERY = ", { '$match' : { 'workflows.status' : 'Open' , 'workflows.direction' : 'IN' , 'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'workflows.assignedGroupId' : { '$in' : [?]}}} ";
	private static final String VERSION_BOX_MATCH_QUERY_INTENSITY = ", { '$match' : { 'workflows.status' : 'Open' , 'workflows.direction' : 'IN' , 'workflows.assignedGroupId' : { '$in' : [?]}}} ";
	private static final String VERSION_BOX_MATCH_QUERY_MICRO_UI = ", { '$match' : { 'workflows.direction' : 'IN' , 'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'workflows.assignedGroupId' : { '$in' : [?]}}} ";
	
	private static final String FINAL_VERSION_LEVEL_BASE_QUERY = "{'$project' : {  id:1,allToCCGrps:1,attchFlag:1,notesFlag:1,urgentFlag:1,latestUserName:1,latestEmail:1,subject:1,modDate:1,origUserName:1,action:1,origGroupName:1,origType:1,origEmail:1,crtDate:1,status:1,sourceType:1,workflows:1,readBy:1,clientPriority:1,clientName:1,gpNum:1,gpName:1,tag:'$workflows.tag',action:1,userNotes:1,userFolders:1,latestUserId:1,reOpenDate:'$workflows.reOpenDate',linkId:'$workflows.linkId',assignedUserId:'$workflows.assignedUserId',gfcid:1,gfcName:1,exceptionId:1, memo:1, 'skAccountNo':1, 'branch':1,hasOwnership:'$workflows.hasOwnership', snoozeAction:'$workflows.snoozeAction', 'isTaskizeInquiry':1, 'bubbleId':1, 'taskizeInquiryId':1}}"
			+ ", {'$unwind' : '$workflows'}"
			+ " [VERSION_MATCH_QUERY] "
			+ " , {'$project' : {latestExchangeItemId:'$workflows.latestExchangeItemId',latestSenderDomain:'$workflows.latestSenderDomain', latestConversationPreviewText:'$workflows.latestConversationPreviewText', id:1,allToCCGrps:1,attchFlag:1,notesFlag:1,urgentFlag:1,latestUserName:1,latestEmail:1,subject:1,origUserName:1,action:1,origGroupName:1,origType:1,origEmail:1,crtDate:1,status:1,workflows:1,readBy:1,clientPriority:1,clientName:1,gpNum:1,gpName:1,tag:'$workflows.tag',action:1,userNotes:1,userFolders:1,latestUserId:1,modDate:'$workflows.modDate',crtDate:'$workflows.crtDate',openUsers:'$workflows.assignedUserName',requestTypeStr:'$workflows.requestType',openGroups:'$workflows.assignedGroupName',reOpenDate:'$workflows.reOpenDate' ,linkId:'$workflows.linkId',assignedUserId:'$workflows.assignedUserId',gfcid:1,gfcName:1,exceptionId:1, memo:1, 'skAccountNo':1, 'branch':1,hasOwnership:'$workflows.hasOwnership',snoozeAction:'$workflows.snoozeAction', 'isTaskizeInquiry':1, 'bubbleId':1, 'taskizeInquiryId':1}} ";
	//projection for mixed view 
	private static final String FINAL_VERSION_LEVEL_BASE_QUERY_COMBINED_VIEW = "{'$project' : {  id:1,symphonyStreamId:1,symphonyChatroomName:1,symphonyChatRoomMember:1,isSymphonyChatroom:1,isTaskizeInquiry:1,bubbleId:1,taskizeInquiryId:1,memberList:1,groupList:1,externalUserList:1,allToCCGrps:1,attchFlag:1,notesFlag:1,urgentFlag:1,latestUserName:1,latestEmail:1,subject:1,modDate:1,origUserName:1,action:1,origGroupName:1,origType:1,origEmail:1,crtDate:1,status:1,sourceType:1,workflows:1,readBy:1,clientPriority:1,clientName:1,gpNum:1,gpName:1,tag:'$workflows.tag',action:1,userNotes:1,userFolders:1,latestUserId:1,reOpenDate:'$workflows.reOpenDate',linkId:'$workflows.linkId',assignedUserId:'$workflows.assignedUserId',gfcid:1,gfcName:1,exceptionId:1, memo:1, 'skAccountNo':1, 'branch':1, hasOwnership:'$workflows.hasOwnership', snoozeAction:'$workflows.snoozeAction'}}"
			+ ", {'$unwind' : '$workflows'}"
			+ " [VERSION_MATCH_QUERY] "
			+ " , {'$project' : { id:1,symphonyStreamId:1,symphonyChatroomName:1,symphonyChatRoomMember:1,isSymphonyChatroom:1,isTaskizeInquiry:1,bubbleId:1,taskizeInquiryId:1, memberList:1,groupList:1,externalUserList:1,allToCCGrps:1,attchFlag:1,notesFlag:1,urgentFlag:1,latestUserName:1,latestEmail:1,subject:1,origUserName:1,action:1,origGroupName:1,origType:1,origEmail:1,crtDate:1,status:1,workflows:1,readBy:1,clientPriority:1,clientName:1,gpNum:1,gpName:1,tag:'$workflows.tag',action:1,userNotes:1,userFolders:1,latestUserId:1,modDate:'$workflows.modDate',crtDate:'$workflows.crtDate',openUsers:'$workflows.assignedUserName',requestTypeStr:'$workflows.requestType',openGroups:'$workflows.assignedGroupName',reOpenDate:'$workflows.reOpenDate' ,linkId:'$workflows.linkId',assignedUserId:'$workflows.assignedUserId',gfcid:1,gfcName:1,exceptionId:1, memo:1, 'skAccountNo':1, 'branch':1, hasOwnership:'$workflows.hasOwnership',snoozeAction:'$workflows.snoozeAction'}} ";
	private static final String COMBINED_VIEW_FILTER_CRITERIA = "{'$project': {'chatRoomMember':{'$cond': [ {$eq:[{ '$ifNull': [ '$symphonyChatRoomMember', null ] },null]},['#SOEID'],'$symphonyChatRoomMember']},'id': 1, 'symphonyStreamId':1,'symphonyChatroomName':1,'symphonyChatRoomMember':1,'isSymphonyChatroom':1,isTaskizeInquiry:1,bubbleId:1,taskizeInquiryId:1,memberList:1,groupList:1,externalUserList:1, 'allToCCGrps': 1, 'attchFlag': 1, 'notesFlag': 1, 'urgentFlag': 1, 'latestUserName': 1, 'latestEmail': 1, 'subject': 1, 'origUserName': 1, 'action': 1, 'origGroupName': 1, 'origType': 1, 'origEmail': 1, 'crtDate': '$workflows.crtDate', 'status': 1, 'workflows': 1, 'readBy': 1, 'clientPriority': 1, 'clientName': 1, 'gpNum': 1, 'gpName': 1, 'tag': '$workflows.tag', 'userNotes': 1, 'userFolders': 1, 'latestUserId': 1, 'modDate': '$workflows.modDate', 'openUsers': '$workflows.assignedUserName', 'requestTypeStr': '$workflows.requestType', 'openGroups': '$workflows.assignedGroupName', 'reOpenDate': '$workflows.reOpenDate', 'linkId': '$workflows.linkId', 'assignedUserId': '$workflows.assignedUserId', 'gfcid': 1, 'gfcName': 1, 'exceptionId': 1, 'memo': 1, 'skAccountNo':1, 'branch':1, 'hasOwnership': '$workflows.hasOwnership', 'snoozeAction': '$workflows.snoozeAction'} }\r\n" +
			", {'$match': {'chatRoomMember': {'$in': ['#SOEID']}}}";
	private static final String ESCALATION_MATCH_QUERY = ",{$match:{'$or':[{'workflows.isConvCountEscalation':'Y'},{'workflows.isSubjectEscalation':'Y'},{'workflows.responseTimeEscalationFlag':'Y'},{'workflows.isClientChaseEscalation':'Y'}, {'workflows.ispendingApprovalEscalation':'Y'}, {'workflows.isManualEscalation':'Y'}]}}";
	private static final String WORKFLOW_MATCH = "'workflows.MATCH_FIELD':'MATCH_VALUE'";
	// Used for Home Page Search and Folder Group level Data Loading
	private static final String GLOBAL_GRID_VIEW_TYPE = "GLOBAL_GRID_VIEW";
	private static final String DEFAULT_VIEW_TYPE_PENDING_APPROVAL = "Pending Approval";
	// 2 New Views Added for Non Inquiry and Delete Inquiry
	private static final String DEFAULT_VIEW_TYPE_NON_INQUIRY = "Non Inquiries";
	private static final String DEFAULT_VIEW_TYPE_SNOOZED = "Snoozed";
	private static final String DEFAULT_VIEW_TYPE_DEL_INQUIRY = "Deleted";
	private static final String DEFAULT_VIEW_TYPE_TAG = "Tag";
	private static final String MONGO_UTC_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";



	// [C153176-169] - Server-side export of inquiries
	private static final String EXPORT_CSV_DELIMITER = ",";
	private static final String EXPORT_CSV_NEWLINE = "\n";
	private static final UserActivitiesDAO user_Activities_Dao = new UserActivitiesDAO();
	public static final String INQUIRY_REF_ID_STRING = "<br /><br /><p id=\"inquiryRefId\" style=\"font-size:11pt;font-family:Calibri;\"><em>*Inquiry Reference Id: [INQUIRY_ID]</em></span></p>";
	public static final String MATCH_INQUIRY_REF_ID_STRING = "<em>*Inquiry Reference Id:";
	private static final String ACTION_ASSIGN_GFPID_GFCID = "Assign GFPID/GFCID";
	public static final String DEFAULT_VIEW_TYPE_ESCALATION = "Escalation";
	public static final String DEFAULT_VIEW_TYPE_ESCALATION_UI = "Potential Escalations";

	private static final List<String> assignMenuActionsWithoutModDateUpdate = Arrays.asList(ACTION_ACKNOWLEDGE_ESCALATION,ACTION_ASSIGN_REQ_TYPE, ACTION_ASSIGN_TO_OWNER, ACTION_ASSIGN_PROCESSING_REGION,  ACTION_ASSIGN_INQUIRY_SOURCE,ACTION_ASSIGN_GFPID_GFCID,ACTION_LOCK,ACTION_UNLOCK,ACTION_DEESCALATE,FOLLOWUP,REMOVE_FOLLOWUP,AppserverConstants.ACTION_UNASSIGN_OWNER,AppserverConstants.ACTION_UNASSIGN_PROCESSING_REGION,AppserverConstants.ACTION_UNASSIGN_TAG);
	private static final String HOMEPAGE_WIDGET_AGGR_QUERY_old="{ '$match' : { '$and' : [ { 'status' : 'Open' , 'workflows' : { '$elemMatch' : { 'status' : 'Open'"
			+ ",'assignedGroupId' : { '$in' : [?]}}}}]}} " 
			+",{ '$unwind': '$workflows'} ,"
			+ " { '$match' : { 'workflows.status' : 'Open' , 'workflows.assignedGroupId' : { '$in' : [?]},'workflows.rulesFlag' : { '$exists' : false}}} , "
		//	+" { '$match' : { 'workflows.rulesFlag' : { '$exists' : false}}} , "
			+" { '$group' :  { '_id' : '$workflows.assignedUserId' , 'TOTAL' : { '$sum' : 1}, "
			+" 'PENDINGAPPROVAL': {'$sum': {'$cond': [ { '$in': [ '$workflows.direction',  ['PENDINGAPPROVAL','PND_REAGE','NOMINATE_OWNERSHIP'] ] }, 1, 0] } }, " 
			+" 'IN': {'$sum': {'$cond': [ { '$eq': [ '$workflows.direction',  'IN' ] }, 1, 0] } }, " 
			//+" 'OUT': {'$sum': {'$cond': [ { '$eq': [ '$workflows.direction',  'OUT' ] }, 1, 0] } }, " 
			+" 'ESCALATION': {'$sum': {'$cond': [ {'$and':[{ '$in': [ '$workflows.direction', ['IN','PENDINGAPPROVAL','PND_REAGE','NOMINATE_OWNERSHIP'] ]}"
			//+ ",{ '$eq': [ '$workflows.status',  'Open']} "
			+" ,{'$or' : [ "
			+"{ '$eq': [ '$workflows.isSubjectEscalation',  'Y' ] },"
			+"{ '$eq': [ '$workflows.isClientChaseEscalation',  'Y' ] },"
			+"{ '$eq': [ '$workflows.responseTimeEscalationFlag',  'Y' ] },"
			+"{ '$eq': [ '$workflows.isConvCountEscalation',  'Y' ] },"
			+"{ '$eq': [ '$workflows.ispendingApprovalEscalation',  'Y' ] },"
			+"{ '$eq': [ '$workflows.isManualEscalation',  'Y' ] }"
			+"] } ]}   , 1, 0]}} " 
			+"}}" ;
	
	
	private static final String HOMEPAGE_WIDGET_AGGR_QUERY="{'$match': {'$and': [{'status': 'Open', 'workflows': {'$elemMatch': {'status': 'Open', 'assignedGroupId': {'$in': [?]}}}}]}}"
			+ ", {'$unwind': '$workflows'}"
			+ ", {'$match':{  'workflows.status': 'Open' , 'workflows.assignedGroupId': {'$in': [?]}, 'workflows.rulesFlag': {'$exists': false}, 'workflows.snoozeAction': {$exists:false}}}"
			+ ",{'$project': {'readBy':{'$cond': [ {$eq:[{ '$ifNull': [ '$readBy', null ] },null]},[],'$readBy']},'workflows':1 } }"
			+ ", {'$group': {'_id': '$workflows.assignedUserId', 'TOTAL': {'$sum': 1}"
			+ "                , 'PENDINGAPPROVAL': {'$sum': {'$cond': [{'$in': ['$workflows.direction', ['PENDINGAPPROVAL', 'PND_REAGE', 'NOMINATE_OWNERSHIP']]}, 1, 0]}}"
			+ "                , 'IN': {'$sum': {'$cond': [{'$eq': ['$workflows.direction', 'IN']}, 1, 0]}}"
			//+ "                , 'OUT': {'$sum': {'$cond': [{'$eq': ['$workflows.direction', 'OUT']}, 1, 0]}}"
			+ "                , 'ESCALATION': {'$sum': {'$cond': [{'$and': [{'$in': ['$workflows.direction', ['IN', 'PENDINGAPPROVAL', 'PND_REAGE', 'NOMINATE_OWNERSHIP']]}"
			+ "                                , {'$or': [{'$eq': ['$workflows.isSubjectEscalation', 'Y']}, {'$eq': ['$workflows.isClientChaseEscalation', 'Y']}"
			+ "                                  		, {'$eq': ['$workflows.responseTimeEscalationFlag', 'Y']}, {'$eq': ['$workflows.isConvCountEscalation', 'Y']}"
			+ "                                  		, {'$eq': ['$workflows.ispendingApprovalEscalation', 'Y']}, {'$eq': ['$workflows.isManualEscalation', 'Y']}]}]}, 1, 0]}}"
			+ "               ,'INREAD': {'$sum': {'$cond': [{'$and': [ {'$eq': ['$workflows.direction', 'IN']},{'$in': ['#soeId#','$readBy']}]},1,0]}}"
			//+ "               ,'OUTREAD': {'$sum': {'$cond': [{'$and': [ {'$eq': ['$workflows.direction', 'OUT']},{'$in': ['#soeId#','$readBy']}]},1,0]}}"
			+ "               ,'PNDREAD': {'$sum': {'$cond': [{'$and': [ {'$in': ['$workflows.direction', ['PENDINGAPPROVAL', 'PND_REAGE', 'NOMINATE_OWNERSHIP']]},{'$in': ['#soeId#','$readBy']}]},1,0]}}"
			+"				  ,'ESCREAD': {'$sum': {'$cond': [{'$and': [ {'$in': ['$workflows.direction', ['IN', 'PENDINGAPPROVAL', 'PND_REAGE', 'NOMINATE_OWNERSHIP']]},{'$in': ['#soeId#','$readBy']}]},1,0]}}"
			+ " }}" ;
	private static final String MOD_DATE_PENDINGAPPROVAL = "#MOD_DATE_PENDINGAPPROVAL#";
	private static final String MOD_DATE_INBOX = "#MOD_DATE_INBOX#";
	private static final String MOD_DATE_ESCALATION = "#MOD_DATE_ESCALATION#";	
	private static final String HOMEPAGE_WIDGET_AGGR_QUERY_WITH_MOD_DATE="{'$match': {'$and': [{'status': 'Open', 'workflows': {'$elemMatch': {'status': 'Open', 'modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'assignedGroupId': {'$in': [?]}}}}]}}, "
			+ " {'$unwind': '$workflows'}, "
			+ " {'$match':{  'workflows.status': 'Open', 'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'workflows.assignedGroupId': {'$in': [?]}, 'workflows.rulesFlag': {'$exists': false}, 'workflows.snoozeAction': {$exists:false}}},"
			+ " {'$project': {'readBy':{'$cond': [ {$eq:[{ '$ifNull': [ '$readBy', null ] },null]},[],'$readBy']},'workflows':1 } },"
			+ " {'$group': {'_id': '$workflows.assignedUserId', 'TOTAL': {'$sum': 1} , "
			+ " 'PENDINGAPPROVAL': {'$sum': {'$cond': [{ $and:[{'$gte': ['$workflows.modDate', {'$date':"+ MOD_DATE_PENDINGAPPROVAL +"}]},{ '$in': [ '$workflows.direction', ['PENDINGAPPROVAL', 'PND_REAGE', 'NOMINATE_OWNERSHIP']]}]}, 1, 0]}},"
			+ " 'IN': {'$sum': {'$cond': [{$and:[ {'$gte': ['$workflows.modDate', {'$date':"+ MOD_DATE_INBOX +"}]},{'$eq': ['$workflows.direction', 'IN']}]}, 1, 0]}},"
			+ " 'ESCALATION': {'$sum': {'$cond': [{'$and': [ {'$gte': ['$workflows.modDate', {'$date':"+ MOD_DATE_ESCALATION +"}]}, {'$in': ['$workflows.direction', ['IN', 'PENDINGAPPROVAL', 'PND_REAGE', 'NOMINATE_OWNERSHIP']]} ,"
					+ " {'$or': [{'$eq': ['$workflows.isSubjectEscalation', 'Y']},"
					+ " {'$eq': ['$workflows.isClientChaseEscalation', 'Y']} ,"
					+ " {'$eq': ['$workflows.responseTimeEscalationFlag', 'Y']},"
					+ " {'$eq': ['$workflows.isConvCountEscalation', 'Y']} ,"
					+ " {'$eq': ['$workflows.ispendingApprovalEscalation', 'Y']},"
					+ " {'$eq': ['$workflows.isManualEscalation', 'Y']}]}]}, 1, 0]} },"
			+ " 'INREAD': {'$sum': {'$cond': [{'$and': [{'$gte': ['$workflows.modDate', {'$date':"+ MOD_DATE_PENDINGAPPROVAL +"}]}, {'$eq': ['$workflows.direction', 'IN']}, {'$in': ['#soeId#','$readBy']}]},1,0]}},"
			+ " 'PNDREAD': {'$sum': {'$cond': [{'$and': [ {'$gte': ['$workflows.modDate', {'$date':"+ MOD_DATE_INBOX +"}]},{'$in': ['$workflows.direction', ['PENDINGAPPROVAL', 'PND_REAGE', 'NOMINATE_OWNERSHIP']]},{'$in': ['#soeId#','$readBy']}]},1,0]}},"
			+ "'ESCREAD': {'$sum': {'$cond': [{'$and': [ {'$gte': ['$workflows.modDate', {'$date':"+ MOD_DATE_ESCALATION +"}]},{'$in': ['$workflows.direction', ['IN', 'PENDINGAPPROVAL', 'PND_REAGE', 'NOMINATE_OWNERSHIP']]},{'$in': ['#soeId#','$readBy']}]},1,0]}} }}";
	private static final String HOMEPAGE_WIDGET_AGGR_QUERY_UNREAD_COUNT="{ '$match' : { '$and' : [ { 'status' : 'Open', 'readBy': { $ne: '#soeId#' } ,'workflows' : { '$elemMatch' : { 'status' : 'Open'"
			+ ",'assignedGroupId' : { '$in' : [?]}}}}]}} " 
			+",{ '$unwind': '$workflows'} ,"
			+" { '$match' : { 'workflows.status' : 'Open' , 'workflows.assignedGroupId' : { '$in' : [?]},'workflows.rulesFlag' : { '$exists' : false},'workflows.snoozeAction': {$exists:false}}} ,"
			//+" {'$match' : {'readBy': { $ne: '#soeId#' }}}, "
			+" { '$group' :  { '_id' : '$workflows.assignedUserId' , 'TOTAL' : { '$sum' : 1}, "
			+" 'PENDINGAPPROVAL': {'$sum': {'$cond': [ { '$in': [ '$workflows.direction',  ['PENDINGAPPROVAL','PND_REAGE','NOMINATE_OWNERSHIP'] ] }, 1, 0] } }, " 
			+" 'IN': {'$sum': {'$cond': [ { '$eq': [ '$workflows.direction',  'IN' ] }, 1, 0] } }, " 
			//+" 'OUT': {'$sum': {'$cond': [ { '$eq': [ '$workflows.direction',  'OUT' ] }, 1, 0] } }, " 
			+" 'ESCALATION': {'$sum': {'$cond': [ {'$and':[{ '$in': [ '$workflows.direction', ['IN','PENDINGAPPROVAL','PND_REAGE','NOMINATE_OWNERSHIP'] ]}"
			//+ ",{ '$eq': [ '$workflows.status',  'Open']} "
			+" ,{'$or' : [ "
			+"{ '$eq': [ '$workflows.isSubjectEscalation',  'Y' ] },"
			+"{ '$eq': [ '$workflows.isClientChaseEscalation',  'Y' ] },"
			+"{ '$eq': [ '$workflows.responseTimeEscalationFlag',  'Y' ] },"
			+"{ '$eq': [ '$workflows.isConvCountEscalation',  'Y' ] },"
			+"{ '$eq': [ '$workflows.ispendingApprovalEscalation',  'Y' ] },"
			+"{ '$eq': [ '$workflows.isManualEscalation',  'Y' ] }"
			+"] } ]}   , 1, 0]}} " 
			+"}}" ;
	
	private static final String ASSIGNED_TO_ME="{'$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open' , 'direction' : 'IN' , 'assignedGroupId' : { '$in' : [?]} }}}]}} , "
			+ "{ '$project' : { 'id' : 1 , 'origGroupName' : 1 , 'workflows' : 1 , 'assignedUserId' : '$workflows.assignedUserId' }} , { '$unwind' : '$workflows'} , { '$match' : {'workflows.status' : 'Open' ,"
			+ "'workflows.direction' : 'IN' , 'workflows.assignedGroupId' : { '$in' : [?]}}} ,{ '$match' : { 'workflows.assignedUserId' :?}} , { '$sort' : { 'modDate' : -1}} , { '$limit' : 100}" ;
	
	private static final String FOLLOWUP_MATCH_QUERY = ",{$match:{'workflows.followUp':{ '$exists' : true}}}";
	// C153176-1556 Advanced search returning incorrect results
	private static final int SOLR_QUERY_LIMIT = 1000; 

	//saparator for bubble content
	//private static final String BUBBLE_CONTENT_SAPARATOR = "<div id='bubleContentSeparator'><span id='bubbleContentSeparatorSpan'></span></div>";
	private static final String BUBBLE_CONTENT_SAPARATOR = "<div id=\"bubleContentSeparator\"><span id=\"bubbleContentSeparatorSpan\"></span></div>";
	private static final String CHAR_AT = "@";
	private static final String EMAIL_DOMAIN = "emailDomain";
	private static final String VIEW_FILTERS = "viewFilters";
	private static final String CHAR_DOT = ".";
	private static final String TIME_IN_MIN = "min";
	private static final String TIME_IN_HR = "hour";
	private static final String TIME_IN_DAY = "day";
	private static final String TIME_IN_WEEK = "week";
	private static final String TIME_IN_MONTH = "month";
	private static final String TIME_IN_YEAR = "year";
	private static final String SNOOZE_START_TIME = "snoozeStartTime";
	private static final String SNOOZE_END_TIME = "snoozeEndTime";
	private static final String SNOOZE_DURATION = "snoozeDuration";
	private static final String SNOOZE = "snooze";
	private static final String SCHEDULE_FOR_LATER = "scheduleForLater";
	private static final String SCHEDULE_FOR_LATER_DATE_FORMAT ="dd/MM/yyyy HH:mm:ss Z";
	private static final UserNotificationDAO userNotificationDAO = UserNotificationDAO.getInstance();
	private static final String COLUMN_CONFIG = "columnConfig";
	private static final String CLIENT_CATEGORY_PLATINUM = "Platinum";
	private static final String CLIENT_CATEGORY_PRIORITY = "Priority";
	private static final String CLIENT_CATEGORY_CLIENT = "Other";
	private static final String CATEGORY_NAME = "categoryName";
	private static final String CLIENT_CATEGORY = "clientCategory";
	private static final String CLIENT_CATEGORY_COLOR_CODE = "colorCode";
	private static final String ASSIGNED_GROUPS = "assignedGroups";
	private static final String GROUP_NAME_KEY = "groupName";
	private String userNotificationType = "Inquiry";
	// [C153176-453]-Order of Generic and Advanced Search
	private List<Long> inquiryIdsListFromSolr;

	// C153176-5354 - Panorama feed - Resolution time in working hours
	public static final String RESOLUTION_TIME_IN_MINUTES = "workflows.$.resolutionTimeInMinutes";
	private static final Object DEFAULT_VIEW_TYPE_FYI = "Auto Assign FYI";
	private static final Object DEFAULT_VIEW_TYPE_PERSONAL_MAIL = "Personal Mail";
	private static final String IS_PERSONAL = "isPersonal";
	private static final String PROCESSED_FLAG = "processedFlag";
	private static final String VIEW_RESOLVED = "Resolved";
	private static final String ENTITY_TYPE_KEY = "entityType";
	private static final String ENTITY_IDS_KEY = "entityIds";
	private static final String CLIENT_IDS_KEY = "clientId";
	private static final String ENTITY_GROUP_DATA_KEY = "entityGroupData";
	private static final String ENTITY_ID_KEY = "entityId";
	public static final String ENTITY_DETAILS = "entityDetails";
	public static final String REQUESTER_ID_KEY = "requesterId";
	public static final String ENTITY_ORIGINATOR_ID_KEY ="entityOriginatorId";
	public static final String TAX_ID_KEY = "taxId";
	public static final String LINK_ENTITY_KEY = "QMA.Inquiry.LinkMsg";
	public static final String DELINK_ENTITY_KEY = "QMA.Inquiry.DeLinkMsg";
	public static final String DEAL_ENTITY_TYPE = "Deal";
	public static final String INVALID_INPUT_KEY = "Invalid Input";
	public static final String FOR_LINK_DELINK_KEY = " for link/delink";
	public static final String INVALID_ENTITY_TYPE_KEY = "Invalid entity type: ";
	public static final String BRAZIL_FX_CONFIG_KEY = "brazilFxConfig";
	private static final String EQ = "eq";
	private static final String MATCH_OP = "matchOp";
	private static final String EMAIL_THREAD_CONFIG = "emailThreadConfig";
	private static final String MAIL_SUBJECT_REPLACE_REG_PATTERN_MAP = "subPrefixMap";
	private static final String DELETE_DRAFT_ERROR_MSG = "Exception in deleteDraftById for draftId = ";
	private static final String ASSIGN_TO_USER_ID = "assignToUserId";
	private static final String RESPONSE_EDITED_FLAG = "responseEditedFlag";
	private static final String INTENT_SUGGESTION_NAME = "intentSuggestionName";
	private static final String USER_INTENT_SUGGESTION_NAME = "userIntentSuggestionName";
	private static final String INTENT_TIME_TO_VD = "intentTimeToVD";
	private static final String INTENT_SUGGESTION_INDICATOR = "intentSuggestionIndicator";
	
	private static final String REQUEST_TYPE_CHANGED_KEY = "isRequestTypeChanged";
	private static final String OLD_REQUEST_TYPE_KEY = "oldRequestType";
	private static final String REQUEST_TYPE_CHANGED_TO_KEY = "Request type changed to ";
	private static final String REQUEST_TYPE_CHANGED_FROM_KEY = "Request type changed from ";
	private static final String FOR_KEY = " for ";
	public static final String LINKED_INQUIRY_ID = "linkedInquiryId";
	public static final String DRAFT_INQUIRY_ACTION = "draftInquiryAction";
	public static final String TASKIZE_CONTENT_ID= "taskizeContentId";
	private static final String TASKIZE_UPDATE_ACTION = "Taskize Update";

	private static final String DRAFTS = "Drafts";
	private static final String OUTBOX = "Outbox";


	public InquiryDAO() {}
	public InquiryDAO(Datastore datastore, DB primaryDb, DB secondaryDb) {
		super(datastore);
		this.database = primaryDb;
		this.databaseSecondary = secondaryDb;
	}
	public Inquiry getInquiryById(Long inquiryId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		return mongoDatastore.get(Inquiry.class, inquiryId);
	}

	public List<Inquiry> getInquiryList(List<Long> inquiryIds) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Query<Inquiry> inquiryQuery = mongoDatastore.createQuery(Inquiry.class);
		inquiryQuery.and(inquiryQuery.criteria("id").in(inquiryIds));
		List<Inquiry> inquiryObjs = inquiryQuery.asList();
		return inquiryObjs;
	}

	public ConversationTO getAllInquiryConversations(String soeId,Long inquiryId, List<Long> selectInqAssignedGroupId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of
	{
		List<Conversation> convList = null;
		Inquiry inquiry = null;

		if (inquiryId == null)
		{
			subLogger.error("Invalid input getAllInquiryConversations for InquiryId= " + inquiryId);
			throw new CommunicatorException("Invalid input getAllInquiryConversations for InquiryId= " + inquiryId);
		}
		try
		{
			Set<Long> userGroupsList = userDao.getUserGroupsList(soeId);
			if (userGroupsList == null || userGroupsList.isEmpty() || !userGroupsList.containsAll(selectInqAssignedGroupId)) {
				subLogger.error("User {} dont have privilege for getAllInquiryConversations  - {} ,{}", soeId, inquiryId, selectInqAssignedGroupId);
				throw new CommunicatorException("User dont have privilege to perform getAllInquiryConversations.");
			}
			
			// [C153176-495]Limit number of conversations to be loaded in conversation Pane
			int convLimitCount = QMACacheFactory.getCache().getConvLimitCount();
			convList = getAllConversations(inquiryId, selectInqAssignedGroupId, convLimitCount, true);
			clearOldConvData(convList);
			replaceInlineImgOldUrlWithNew(convList);
			inquiry = getInquiryById(inquiryId);
			ConversationTO conversationTO = new ConversationTO(convList, inquiry);
			long startTime = System.currentTimeMillis();
			// [C153176-413] Inability to simply click on the sender, above the mail, to copy and paste onto trade history
			setEmailDisplayName(conversationTO.getConversationList().get(0));
			BasicDBObject readUnreadData=new BasicDBObject();
			readUnreadData.put("readFlag", STRING_YES);
			List<Long> inqIdList=new ArrayList<>();
			inqIdList.add(inquiryId);
			readUnreadData.put(INQUIRY_IDS,inqIdList );
			markInquiryReadUnRead(soeId, readUnreadData);
			return conversationTO;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getAllInquiryConversations for soeId = "+soeId+" , InquiryId= " + inquiryId, e);
			throw new CommunicatorException("Exception in getAllInquiryConversations for InquiryId= " + inquiryId, e);
		}

	}
	
	public ConversationTO getAllInquiryExtConversationsWithPaging(String soeId,Long inquiryId, List<Long> selectInqAssignedGroupId,boolean isAllConvContent, BasicDBObject inputJsonObject) throws CommunicatorException {
		
		return getAllInquiryExtConversationsWithPaging(soeId,inquiryId,selectInqAssignedGroupId,isAllConvContent,inputJsonObject,null);
	}
	
	public ConversationTO getAllInquiryExtConversationsWithPaging(String soeId,Long inquiryId, List<Long> selectInqAssignedGroupId,boolean isAllConvContent, BasicDBObject inputJsonObject,List<Long> selectConvIds) throws CommunicatorException {
		List<Conversation> convList = null;
		Inquiry inquiry = null;

		if (inquiryId == null) {
			subLogger.error("Invalid input getAllInquiryConversations for InquiryId= " + inquiryId);
			throw new CommunicatorException("Invalid input getAllInquiryConversations for InquiryId= " + inquiryId);
		}
		
		try {
			Set<Long> userGroupsList = userDao.getUserGroupsList(soeId);
			if (userGroupsList == null || userGroupsList.isEmpty() || !userGroupsList.containsAll(selectInqAssignedGroupId)) {
				subLogger.error("User {} dont have privilege for getAllInquiryConversations  - {} ,{}", soeId, inquiryId, selectInqAssignedGroupId);
				throw new CommunicatorException("User dont have privilege to perform getAllInquiryConversations.");
			}
			int convLimitCount = QMACacheFactory.getCache().getConvLimitCount();
			convList = getAllConversationsWithPaging(inquiryId, selectInqAssignedGroupId, convLimitCount, true, inputJsonObject,selectConvIds);
			updateConversations(convList,isAllConvContent, inputJsonObject,selectInqAssignedGroupId);
			inquiry = getInquiryById(inquiryId);
			//Added to avail snoozeDuration at inquiry level
			addSnoozeDetails(inquiry);

			ConversationTO conversationTO = new ConversationTO(convList, inquiry);

			updateNLPAttributes(conversationTO, selectInqAssignedGroupId);
			if(inquiry.isAutoAssignmentAvailable()) {
				conversationTO.setAutoAssignmentAvailable(true);
			}
			return conversationTO;
			
		} catch (Exception e) {
			subLogger.error("Exception in getAllInquiryConversations for soeId = "+soeId+" , InquiryId= " + inquiryId, e);
			throw new CommunicatorException("Exception in getAllInquiryConversations for InquiryId= " + inquiryId, e);
		}
	}
	
	/**
	 * This method will add NLP attributes to the conversation.
	 * @param conversationTO
	 * @param selectInqAssignedGroupId
	 */
	private void updateNLPAttributes(ConversationTO conversationTO, List<Long> selectInqAssignedGroupId) {
		try {
			String requestGrpId;
			if( null != selectInqAssignedGroupId && !selectInqAssignedGroupId.isEmpty()) {
				requestGrpId = String.valueOf(selectInqAssignedGroupId.get(0));
				
				if( null != requestGrpId && null != conversationTO && null != conversationTO.getConversationList() && 
						!conversationTO.getConversationList().isEmpty()) {
					NLPRequestType nlpRequestType = GenericUtility.getNlpRequestTypebyGroupId(requestGrpId);
					if (NLPRequestType.C.equals(nlpRequestType)
							&& null != conversationTO.getConversationList().get(0).getCustodySuggestionIndicator()) {
						conversationTO.setSuggestionStatus(getSuggestion(
								conversationTO.getConversationList().get(0).getCustodySuggestionIndicator()));
					} else if (NLPRequestType.S.equals(nlpRequestType) && null != conversationTO.getConversationList()
							.get(0).getSettlementsSuggestionIndicator()) {
						conversationTO.setSuggestionStatus(getSuggestion(
								conversationTO.getConversationList().get(0).getSettlementsSuggestionIndicator()));
					}   
					
					if(null != conversationTO.getConversationList()
							&& null != conversationTO.getConversationList().get(0)
							&& conversationTO.getConversationList().get(0).isIntentSuggestionAvailable()) {
						conversationTO.setIntentSuggestionAvailable(conversationTO.getConversationList().get(0).isIntentSuggestionAvailable());
					}
					/*
					 * else { //for default nlp subscribed groups. not in C and not in S. Type A
					 * need to be added as one more if here.
					 * conversationTO.setSuggestionStatus(conversationTO.getConversationList().get(0
					 * ).getSuggestionStatus()); }
					 */

					conversationTO.setSuggestionAvailable(conversationTO.getConversationList().get(0).isSuggestionAvailable());
					conversationTO.setAutoAssignmentAvailable(conversationTO.getConversationList().get(0).isAutoAssignmentAvailable());
				} else {
					subLogger.warn("'conversationTO.getConversationList()' is either null or empty.");
				}
			} else {
				subLogger.warn("'selectInqAssignedGroupId' is either null of empty");
			}
			
			
		} catch (Exception e) {
			subLogger.error("Exception while adding NLP attributes to the conversation :",e);
		}
	}

	/**
	 * This method return suggestion indicator in text like green, red, orange, black
	 * @param indicator
	 * @return
	 */
	private String getSuggestion(String indicator) {
		String indicatorInFullText = null;
		if (SuggestionStatusIndicator.G.toString().equals(indicator) || NLPConstants.COLOR_GREEN.equals(indicator)) {
			indicatorInFullText = NLPConstants.COLOR_GREEN;
		} else if (SuggestionStatusIndicator.O.toString().equals(indicator) ||  NLPConstants.COLOR_ORANGE.equals(indicator)
				||   NLPConstants.COLOR_AMBER.equals(indicator)) {
			indicatorInFullText = NLPConstants.COLOR_ORANGE;
		} /*
			 * else if (SuggestionStatusIndicator.R.toString().equals(indicator) ||
			 * NLPConstants.COLOR_RED.equals(indicator)) { indicatorInFullText =
			 * NLPConstants.COLOR_RED; }
			 */else if (SuggestionStatusIndicator.B.toString().equals(indicator) || NLPConstants.COLOR_BLUE.equals(indicator)) {
			indicatorInFullText = NLPConstants.COLOR_BLUE;
		}
		return indicatorInFullText;
	}

	/**
	 * Added to avail snoozeDuration at inquiry level
	 * @param inquiry
	 */
	private void addSnoozeDetails(Inquiry inquiry) {
		try{
			List<Workflow> workflows = inquiry.getWorkflows();
			for(Workflow workflow:workflows){
				if(null != workflow.getSnoozeAction() && "Snooze".equalsIgnoreCase(workflow.getSnoozeAction())){	
					InquirySnoozeDetails isdRecord = getInquirySnoozeDetails(inquiry.getId(), workflow.getAssignedGroupId());
					if (isdRecord != null) {
						inquiry.setSnoozeDuration(isdRecord.getSnoozeDuration());
						inquiry.setSnoozedBy(isdRecord.getSnoozedBy());
					}
				}
			}	
		}catch(Exception ex){
			subLogger.error("Exception while adding snooze details for inquiry: {}",inquiry.getId(),ex); // <-- sonar fix Change this condition so that it does not always evaluate to "true"
		}
		
	}
	private List<Conversation> updateConversations(List<Conversation> convList, boolean isAllConvContent, BasicDBObject inputJsonObject, List<Long> selectInqAssignedGroupId) {
		if (convList != null && !convList.isEmpty()) {
			int count = 0;
			for (Conversation conv : convList) {
				
				/*Update Conversation Contents*/
				updateContent(isAllConvContent, count, conv);
				count++;
				
				/*Replace inline image old URL with new URL*/
				// As contents of only first conversation is available applied below check
				if(count==0) {
					Date convCrtDt = conv.getCrtDate();
					Date convCreatedBefore = QMACacheFactory.getCache().getDefaultStaticData().getConversationCreatedBefore();
					String content = GenericUtility.checkAndFetchConvContent(conv);
					if (!StringUtils.isBlank(content) && null != convCreatedBefore && null != convCrtDt && convCrtDt.before(convCreatedBefore)) {
						String newContent = content.replaceAll("/XStreamCommunicator/rest", GenericUtility.getAppServerContextFromDB()+"/rest");
						conv.setContent(newContent);
					}
				}
				
				/*Update Display Name for QMA1*/
				if( count==0 && !inputJsonObject.getBoolean("isQma2") ) {
					try {
						setEmailDisplayName(conv);
					} catch (CommunicatorException e) {
						subLogger.error("Exception while setting display Name : ", e);
					}
				}
				
				/* Update display name of user for QMA2 */
				if(null != inputJsonObject && null != inputJsonObject.get("isQma2") && inputJsonObject.getBoolean("isQma2")) {
					try {
						getUserDisplayName(conv);
					} catch (CommunicatorException e) {
						subLogger.error("Exception while setting user display Name : ", e);
					}
				}
				if( null != selectInqAssignedGroupId && !selectInqAssignedGroupId.isEmpty()) {
					String requestGrpId = String.valueOf(selectInqAssignedGroupId.get(0));
					NLPRequestType nlpRequestType = GenericUtility.getNlpRequestTypebyGroupId(requestGrpId);
					if(null != nlpRequestType && (nlpRequestType.equals(NLPRequestType.C) || nlpRequestType.equals(NLPRequestType.S)
								|| NLPRequestType.I.equals(nlpRequestType))){
							if(null != conv.getCustodySuggestionIndicator()) {
								conv.setSuggestionStatus(getSuggestion(conv.getCustodySuggestionIndicator()));
							}
							if(null != conv.getSettlementsSuggestionIndicator()) {
								conv.setSuggestionStatus(getSuggestion(conv.getSettlementsSuggestionIndicator()));
							}
						}
					updateIntentSuggestionFields(conv,requestGrpId);
				}
			}
		}
		return convList;
	}
	
	private void updateIntentSuggestionFields(Conversation conv, String requestGrpId) {
		NLPSuggestionDAO suggestionDao = new NLPSuggestionDAO();
		NLPSuggestionRecord sugRecord = suggestionDao.getSuggestionReord(conv.getInquiryId(),conv.getId(),
				NLPRequestType.I.name());
		if(null == sugRecord) {
			return;
		}
		List<Long> groupIds = sugRecord.getEligibleGroupIdList();
		if(null != groupIds && groupIds.contains(Long.valueOf(requestGrpId))) {
			String intentSuggestionIndicator = "";
			String intentSuggestionName = "";
			if(null != conv.getUserIntentSuggestionName() && !conv.getUserIntentSuggestionName().equalsIgnoreCase(conv.getIntentSuggestionName())) {
				intentSuggestionName=conv.getUserIntentSuggestionName();
			}else {
				intentSuggestionName=conv.getIntentSuggestionName();
			}
			String noIntentOtherSuggestionName = "";
			if(StringUtils.isNotBlank(intentSuggestionName)) {
				noIntentOtherSuggestionName = intentSuggestionName.replaceAll(NLPConstants.ALPHABATE_REGEX, " ");
			}
			intentSuggestionIndicator = getIntentSuggestionIndicatorFromCache(intentSuggestionName);
			if(NLPConstants.NO_INTENT_OTHER_INTENT_KEY.equalsIgnoreCase(noIntentOtherSuggestionName)) {
				conv.setIntentSuggestionName("");
				conv.setIntentSuggestionIndicator("");
			}else {
				conv.setIntentSuggestionName(intentSuggestionName);
				conv.setIntentSuggestionIndicator(intentSuggestionIndicator);
			}
			conv.setIntentTimeToVD(AgeAndTimeUtils.getTimeToVD(conv.getIntentTimeToVD(), Long.valueOf(requestGrpId)));			
		}else {
			conv.setIntentSuggestionIndicator(null);
			conv.setIntentTimeToVD(null);
			conv.setIntentSuggestionName(null);		
		}
	}

	/**
	 * @param isAllConvContent
	 * @param count
	 * @param conv
	 */
	private void updateContent(boolean isAllConvContent, int count, Conversation conv) {
		if(!isAllConvContent) {
			if(count ==0) {
				conv.setContent(InquiryUtil.replaceBaseTag(GenericUtility.checkAndFetchConvContent(conv)));
			} else {
				conv.setContent(null);
			}
		} else {
			conv.setContent(InquiryUtil.replaceBaseTag(GenericUtility.checkAndFetchConvContent(conv)));
		}
	}

	private List<Conversation> getAllConversations(Long inquiryId, List<Long> selectInqAssignedGroupId, int convLimitCount, boolean loadContentFromDb)
	{
		Query<Conversation> query;
		List<Conversation> convList;
		query = mongoDatastore.createQuery(Conversation.class);
		query.criteria(INQUIRY_ID).equal(inquiryId);
		// [C153176-419]User should see only conversations for his groups
		if (selectInqAssignedGroupId != null && !selectInqAssignedGroupId.isEmpty())
		{
			query.criteria("recipients.groupId").in(selectInqAssignedGroupId);
		}
		// To exclude conversation contents.
		if (!loadContentFromDb)
		{
			query.retrievedFields(false, "content");
		}

		query.order("-modDate");
		if (convLimitCount > 0)
		{
			query.limit(convLimitCount);
		}
		convList = query.asList();
		return convList;
	}
	
	private List<Conversation> getAllConversationsWithFilters(Long inquiryId, List<Long> selectInqAssignedGroupId, int convLimitCount, boolean loadContentFromDb, List<Long> convIdList, Integer businessDays){
		Query<Conversation> query;
		List<Conversation> convList;
		query = mongoDatastore.createQuery(Conversation.class);
		query.criteria(INQUIRY_ID).equal(inquiryId);
		
		if(!convIdList.isEmpty()) {
			query.criteria("_id").in(convIdList);
		}
		
		if(businessDays != null && businessDays > 0) {
			applyFilterForBusinessDays(query, businessDays);
		}
		
		// [C153176-419]User should see only conversations for his groups
		if (selectInqAssignedGroupId != null && !selectInqAssignedGroupId.isEmpty())
		{
			query.criteria("recipients.groupId").in(selectInqAssignedGroupId);
		}
		// To exclude conversation contents.
		if (!loadContentFromDb)
		{
			query.retrievedFields(false, "content");
		}

		query.order("-modDate");
		if (convLimitCount > 0)
		{
			query.limit(convLimitCount);
		}
		convList = query.asList();
		return convList;
	}

	
	private void applyFilterForBusinessDays(Query<Conversation> query, int businessDays) {
		if(businessDays > 0) {
			subLogger.info("Start Method :: applyFilterForBusinessDays");
			Date requiredDate = null;
			try {
				requiredDate =  com.citi.icg.qma.common.core.util.DateUtil.getBusinessDayBefore(businessDays);
				query.criteria(CREATED_DATE).greaterThanOrEq(requiredDate);
			} catch (Exception e) {
				subLogger.warn("Exception in applyFilterForBusinessDays :: ",e);
			}
			subLogger.info("BusinessDays :: {}, Calculated Date :: {}", businessDays, requiredDate);
			subLogger.info("End Method :: applyFilterForBusinessDays");
		}
	}
	
	public List<Conversation> getAllConversationsWithPaging(Long inquiryId, List<Long> selectInqAssignedGroupId, int convLimitCount, boolean loadContentFromDb, BasicDBObject inputJsonObject)
	{
		return getAllConversationsWithPaging(inquiryId,selectInqAssignedGroupId,convLimitCount,loadContentFromDb,inputJsonObject);
	}
	
	public List<Conversation> getAllConversationsWithPaging(Long inquiryId, List<Long> selectInqAssignedGroupId, int convLimitCount, boolean loadContentFromDb, BasicDBObject inputJsonObject,List<Long> selectedConvIds)
	{
		Query<Conversation> query;
		List<Conversation> convList;
		query = mongoDatastore.createQuery(Conversation.class);
		if(selectedConvIds != null && !selectedConvIds.isEmpty()){
			query.criteria(ID_COLUMN).hasAnyOf(selectedConvIds);
		}
		query.criteria(INQUIRY_ID).equal(inquiryId);
		boolean hasNominatedOwnership = false;
		if(null != inputJsonObject && null != inputJsonObject.get("hasNominatedOwnership") && inputJsonObject.getBoolean("hasNominatedOwnership")){
			hasNominatedOwnership = true;   
		}
		subLogger.info("hasNominatedOwnership for conversation for inquiryId: "+inquiryId + " groupId : "+selectInqAssignedGroupId + " hasNominatedOwnership : "+hasNominatedOwnership);
		// [C153176-419]User should see only conversations for his groups
		if (selectInqAssignedGroupId != null && !selectInqAssignedGroupId.isEmpty())
		{
			if(hasNominatedOwnership){
				/*Criteria[] c = {query.criteria("recipients.groupId").in(selectInqAssignedGroupId), query.criteria("nominatedRecipients.groupId").in(selectInqAssignedGroupId)};
				query.or(c);*/
				query.criteria("nominatedRecipients.groupId").in(selectInqAssignedGroupId);
			} else {
				query.criteria("recipients.groupId").in(selectInqAssignedGroupId);
			}
			//query.criteria("recipients.groupId").in(selectInqAssignedGroupId);
			//TODO: Update below query in order to improve performance on database. 
			//Criteria[] c = {query.criteria("recipients.groupId").in(selectInqAssignedGroupId), query.criteria("nominatedRecipients.groupId").in(selectInqAssignedGroupId)};
			//query.or(c);
		}
		// To exclude conversation contents.
		if (!loadContentFromDb)
		{
			query.retrievedFields(false, "content");
		}

		query.order("-modDate");
		applyConversationPaging(inputJsonObject,convLimitCount, query);
		convList = query.asList();
		return convList;
	}

	private void applyConversationPaging(BasicDBObject inputJsonObj,int defaultConvLimit, Query<Conversation> query) {
		if(query ==null){
			return;
		}
		Integer offset=null;
		if (inputJsonObj != null) {
			Integer pageNum = GenericUtility.convertLongToIntFromBSON(inputJsonObj.get("pageNum"));
			Integer pageSize = GenericUtility.convertLongToIntFromBSON(inputJsonObj.get("pageSize"));

			if (null != pageNum && null != pageSize && pageNum > 0 && pageSize > 0) {
				offset = pageSize * (pageNum - 1);
			}
			if (offset != null && offset >= 0) {
				query.offset(offset).limit(pageSize);
			}
			// Limit as per View Config-- Regular flow without server side paging details from UI
			else if (defaultConvLimit != 0) {
				query.limit(defaultConvLimit);
			}
		} else 	if (defaultConvLimit > 0)
		{
			query.limit(defaultConvLimit);
		}
	}

	// [C153176-413] Inability to simply click on the sender, above the mail, to copy and paste onto trade history
	public void setEmailDisplayName(Conversation inputConv) throws CommunicatorException
	{
		try
		{
		Conversation conversation = inputConv;
		if (!conversation.getRecipients().isEmpty())
			if (null !=conversation.getRecipients().get(0).getDisplayName())
			{
				String displayName = conversation.getRecipients().get(0).getDisplayName();
				if (null != displayName && !StringUtils.isEmpty(displayName))
				{
					if (!displayName.contains("@"))
					{
						Long groupIDs;
						QMACache qmaCache = QMACacheFactory.getCache();
						Map<String, Long> groupCodeToIdMap = qmaCache.getGroupCodeToIdMap();
						Map<Long, String> groupIdToEmailMap = qmaCache.getGroupIdToEmailMap();
						if (conversation.getRecipients().get(0).getEmailAddr() == null)
						{
							for (Map.Entry<String, Long> entry : groupCodeToIdMap.entrySet())
							{
								String key = entry.getKey();
								if (key.equalsIgnoreCase(displayName))
								{
									groupIDs = entry.getValue();
									String email = groupIdToEmailMap.get(groupIDs);
									if (null != email || email != "")
									{
										conversation.getRecipients().get(0)
										.setDisplayName(displayName + " " + "<" + email + ">");
									}
									break;
								}
							}
						}
						else
						{
							if (null != conversation.getRecipients().get(0).getEmailAddr())
							{
								String email = conversation.getRecipients().get(0)
										.getEmailAddr();
								if (null != email || email != "")
								{
									conversation.getRecipients().get(0).setDisplayName(
											conversation.getRecipients().get(0).getDisplayName()
											+ " " + "<" + email + ">");
								}
							}
						}
					}
				}
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in setEmailDisplayName", e);
			throw new CommunicatorException("Exception in setEmailDisplayName for user");
		}
	}

	// Method to get All workflows by InquiryId
	public WorkflowTO getWorkflowsById(Long inquiryId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			WorkflowTO workflowTO = new WorkflowTO();
			Inquiry inquiry = getInquiryById(inquiryId);
			if (inquiry != null && inquiry.getWorkflows() != null)
			{
				workflowTO.setWorkflowList(inquiry.getWorkflows());
			}
			return workflowTO;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getWorkflowsById for InquiryId= " + inquiryId, e);
			throw new CommunicatorException("Exception in getWorkflowsById for InquiryId= " + inquiryId);
		}
	}


	// [C153176-169] - Server-side export of inquiries
	// If isRetrieve all is true, all inquiries are retrieved without limit.
	public DBObject getGridViewData(String soeId, BasicDBObject inputJsonObj, boolean isRetrieveAll, BufferedWriter bw) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using
	// a generic one
	{
		DBObject finalDefaultBoxCriteria = null;
		DBObject orderBy = null;
		DBObject userCriteria = null;
		// [C153176-169] - Server-side export of inquiries
		DBObject defaultUserCriteria = null;
		String viewName = null;
		List<ColumnDef> userViewColumnDefs = null;
		DBObject solrCriteria = null;
		viewName = inputJsonObj.getString(VIEW_NAME);
		if (viewName == null)
		{
			subLogger.error("Invalid input getGridViewData for viewName= " + viewName);
			throw new CommunicatorException("Invalid input getGridViewData for viewName= " + viewName);
		}
		try
		{
			if(viewName.equalsIgnoreCase(DEFAULT_VIEW_TYPE_ESCALATION_UI)){
				viewName = DEFAULT_VIEW_TYPE_ESCALATION;
			}
			//below code added to get grid data for intensity heat map
 			if(INTENSITY_HEAT_MAP.equalsIgnoreCase(viewName)){
				DBObject gridViewTO  = InquiryExtendedDAO.getInstance().getIntensityHeatMapData(soeId, inputJsonObj, isRetrieveAll, bw);
				if (gridViewTO != null)
				{
					return gridViewTO;
				}
			}
 			if("ChatView".equalsIgnoreCase(viewName)){
				DBObject gridViewTO  = SymphonyDAO.getInstance().getSymphonyChatViewData(soeId, inputJsonObj, isRetrieveAll, bw);
				if (gridViewTO != null)
				{
					return gridViewTO;
				}
			}
			
			// All home Page Custom Box Seaches-AssignedToMe,UnReadMessages,Important,Folder Search,Tag Search
			// [C153176-169] - Server-side export of inquiries
			HashMap<String, Object> homeBoxSearchMap = homeBoxSearch(soeId, inputJsonObj, isRetrieveAll, bw);
			DBObject gridViewTO = homeBoxSearchMap.get(HOME_BOX) != null ? (DBObject) homeBoxSearchMap.get(HOME_BOX) : null;

			if (gridViewTO != null)
			{
				return gridViewTO;
			}
			
			// Default 0 means -get all db records
			int maxResults = 0;

			// Get Solr Search Response and build criteria , when solr search is called along with any view's getGridViewData
			List<String> solrSearchText = (List<String>) homeBoxSearchMap.get(SOLR_SEARCH_TEXT);

			solrCriteria = homeBoxSearchMap.get(SOLR_CRITERIA) != null ? (DBObject) homeBoxSearchMap.get(SOLR_CRITERIA) : null;

			if (solrSearchText!=null && !solrSearchText.isEmpty())
			{
				// If no result from solr search, then no need to go to DB for data
				if (solrCriteria == null)
				{
					return gridViewTO;
				}
			}

			gridViewTO = new BasicDBObject();
			// Check is it default view and get criteria-used for inbox/outbox/resolvedbox
			// viewName can be default viewname i,e Inbox etc or it can be one of user created views
			String defaultViewCriteriaStr = getDefaultBoxCriteriaStr(viewName);//
			if(isRetrieveAll){
				inputJsonObj.put("isRetrieveAll", true);
			}
			finalDefaultBoxCriteria = getFinalDefaultBoxCriteria(soeId, defaultViewCriteriaStr, gridViewTO, inputJsonObj);
			
			String viewType = viewName;
			if (finalDefaultBoxCriteria == null)
			{
				// Check for login user views
				ViewConfig userViewConfig = getUserViewConfigForViewName(soeId, viewName);
				if (userViewConfig != null)
				{
					DBObject userOrderBy = null;
					if (userViewConfig.getColumnsToShow() != null)
					{
						userViewColumnDefs = userViewConfig.getColumnsToShow();
						inputJsonObj.put("colToShow", true);
					}

					if (userViewConfig.getOrderByColumns() != null)
					{
						userOrderBy = new BasicDBObject();
						for (ColumnDef columnDef : userViewConfig.getOrderByColumns())
						{
							userOrderBy.put(columnDef.getAttributeName(), 1);
						}
						orderBy = userOrderBy;
					}

					DBObject userViewCriteria = BasicDBObject.parse(userViewConfig.getCriteria());
					// [C153176-160] Saved Search filter criteria is not working for all columns
					getBsonObjForUserCtrWithDateObj(userViewCriteria, MONGO_UTC_FORMAT);
					BasicDBList critArray = (BasicDBList) userViewCriteria.get(AND_CRITERIA_OPERATOR);
					// get the criteria which has both ViewType and Critria
					DBObject viewTypeCriteria = (DBObject) critArray.get(0);
					viewType = (String) viewTypeCriteria.get(VIEW_TYPE);
					// As per view type , load default view criteria

					// [C153176-169] - Server-side export of inquiries - extracting the version match criteria
					DBObject userViewDefaultCriteria = BasicDBObject.parse(userViewConfig.getDefaultCriteria());
					BasicDBList defaultCritArray = null;
					if (userViewDefaultCriteria != null)
					{
						defaultCritArray = (BasicDBList) userViewDefaultCriteria.get(AND_CRITERIA_OPERATOR);
					}

					// calculate again for non-default view
					defaultViewCriteriaStr = getDefaultBoxCriteriaStr(viewType);//

					finalDefaultBoxCriteria = getFinalDefaultBoxCriteria(soeId, defaultViewCriteriaStr, gridViewTO, inputJsonObj);

					// This will be applied along with default criteria
					userCriteria = (DBObject) critArray.get(1);

					if (defaultCritArray != null && defaultCritArray.size() > 1 && defaultCritArray.get(1) != null)
					{
						defaultUserCriteria = (DBObject) defaultCritArray.get(1);
						gridViewTO.put(DEFAULT_USER_CRITERIA, defaultUserCriteria);
					}

				}
				else
				{
					subLogger.error("Invalid View Configuration-No Data returned");
					throw new CommunicatorException("Invalid View Configuration-No Data returned");
				}
			}
			else
			{
				
				userViewColumnDefs = getDefaultBoxUserColDef(soeId, viewName);
				if(DEFAULT_VIEW_TYPE_ESCALATION.equals(viewType) && inputJsonObj.get("viewFilter")!=null)
				{
					//Escalation filter will be treated as a user filter from UI
					userCriteria = new BasicDBObject("viewFilterField",(String)inputJsonObj.get("viewFilter"));
					userCriteria.put("viewFilterValue","Y");
					userCriteria.put("isUIViewFilter",true);
					if(inputJsonObj.get("viewFilterDirection")!=null)
					{
						userCriteria.put("viewFilterDirection", inputJsonObj.get("viewFilterDirection"));
					}
				}
			}

			if (finalDefaultBoxCriteria == null)
			{
				subLogger.error("Invalid Default View Configuration-No Data returned " + viewName);
				throw new CommunicatorException("Invalid View Configuration-No Data returned");
			}
			if(null != gridViewTO && null == gridViewTO.get(COLUMN_CONFIG)) {
				String viewNameForClomnConfig = getViewNameForColumnConfig(inputJsonObj, viewName);
				String nodeType = getViewNodeType(inputJsonObj);
				gridViewTO.put(COLUMN_CONFIG, getCustomColumnsForDefaultViews(viewNameForClomnConfig,nodeType, soeId));
			}
			long startTime = System.currentTimeMillis();
			
			if (isGroupLevelGridView(soeId))
			{
				gridViewTO = getGroupLevelGridViewData(gridViewTO, soeId, finalDefaultBoxCriteria, userCriteria, solrCriteria, orderBy, userViewColumnDefs, maxResults, viewType, false, isRetrieveAll,
						inputJsonObj, bw);
			}
			else
			{
				// Existing Code Flow for Inquiry Level
				// Get data from DB along with user criteria if any
				gridViewTO = getUserGridViewData(gridViewTO, finalDefaultBoxCriteria, userCriteria, solrCriteria, orderBy, userViewColumnDefs, maxResults);
			}
			//gridViewTO.put(VIEW_FILTERS, getViewFilters(soeId));
			subLogger.info("Inside .Create DB Object  Time Diff-"
					+ (System.currentTimeMillis() - startTime)
					+ " in Milli Seconds");
			return gridViewTO;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getGridViewData for user= " + soeId + " and viewName= " + viewName, e);
			throw new CommunicatorException("Exception in getGridViewData for user= " + soeId + " and viewName= " + viewName, e);
		}
	}

	private String getViewNameForColumnConfig(BasicDBObject inputJsonObj, String viewName) {
		String tagSearch = inputJsonObj.getString(TAG_SEARCH);
		boolean isTagSearch = tagSearch != null && "Y".equals(tagSearch);
		String viewNameForClomnConfig = viewName;
		if(isTagSearch){
			viewNameForClomnConfig = "TAG";
		}
		return viewNameForClomnConfig;
	}

	/**
	 * This method will provide node type from the input request.
	 * For the individual view if the node is All | INDIVIDUAL | TEAM
	 * @param requestObj
	 * @return String
	 */
	public String getViewNodeType(BasicDBObject requestObj) {
		String nodeType = null;
		if(null!= requestObj && requestObj.containsField("nodeType")){
			nodeType = requestObj.getString("nodeType");
		}
		return nodeType;
	}


	/**
	 * This method is used to fetch custom column from User
	 * @param viewName
	 * @param soeId
	 * @param inputJsonObj 
	 * @return
	 */
	public BasicDBObject getCustomColumnsForDefaultViews(String viewName, String nodeType, String soeId) {
		if(StringUtils.isNotEmpty(nodeType) && QmaMailConstants.INDIVIDUAL_NODE_TYPE.equalsIgnoreCase(nodeType)) {
			return userDao.getColumnConfigForIndividualView(soeId);
		} else {
			return userDao.getCustomColumnsForDefaultViews(viewName, soeId);
		}
	}

	public BasicDBObject saveInquiry(BasicDBObject inputJsonObj, String content, String soeId, UserActivities userActivity) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic
	// one//Sonar Fix -- remove useless parameter
	{

		String inquiryAction = null;
		Long inquiryId = null;
		BasicDBObject response = null;
		try
		{
			Inquiry dbInquiry = null;
			boolean saveFlag = false;
			inquiryId = GenericUtility.getIdFromRequest(inputJsonObj, INQUIRY_ID);
			inquiryAction = inputJsonObj.getString("inquiryAction");
			String requestType = inputJsonObj.getString(REQUEST_TYPE);
			String to = inputJsonObj.getString(TO);
			String fromGroup = inputJsonObj.getString(FROM);
			Long fromGroupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(fromGroup.toUpperCase());
			String conversationContent = content;
			subLogger.info("saveInquiry-action-" + inquiryAction + " for Id=" + inquiryId + " by " + soeId);
			Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			if (StringUtils.isBlank(inquiryAction) || StringUtils.isBlank(requestType) || StringUtils.isBlank(fromGroup) || StringUtils.isBlank(to))
			{
				throw new CommunicatorException("Invalid Data for saveInquiry.");
			}
			boolean makerCheckerRqd = inputJsonObj.getBoolean(MAKER_CHECKER_REQUIRED);
			boolean approvalBypassed = inputJsonObj.getBoolean(APPROVAL_BYPASSED);
			List<Long> resolveAllGroupList = getResolveGroupIdsFromRequest(inputJsonObj);
			boolean isExternalMail = isToCCHasEMail(inputJsonObj);
			boolean isMakerCheckerEnabled = isExternalMail && makerCheckerRqd && !approvalBypassed;
			String resolveRootCause = inputJsonObj.getString("resolveRootCause");
			String resolveProcessingRegion = inputJsonObj.getString(PROCESSING_REGION);
			String followUpFlag = inputJsonObj.getString(FOLLOWUP_FLAG);
			String memo = inputJsonObj.getString(MEMO);
			FollowUp followUp =null;
			if(!StringUtils.isBlank(followUpFlag))
			{
				followUp = new FollowUp();
				followUp.setFlag(followUpFlag);
			}

			Long queryCount = 1L;
			if (!StringUtils.isBlank(inputJsonObj.getString(QUERY_COUNT)))
			{
				queryCount = Long.parseLong(inputJsonObj.getString(QUERY_COUNT));
			}
			String inquirySource = inputJsonObj.getString(INQUIRY_SOURCE);
			String inquirySubStatus = inputJsonObj.getString(INQUIRY_SUB_STATUS);
			String gfpid = inputJsonObj.getString(GFPID);
			String gfcid = inputJsonObj.getString(GFCID);
			String tag = inputJsonObj.getString(TAG);
			String uiWorkflowStatus = inputJsonObj.getString("uiWorkflowStatus");
			List<String> unApprovedExternalDomainsList = (ArrayList<String>) inputJsonObj.get("unApprovedExternalDomains");
			Set<String> unApprovedExternalDomains = new HashSet<>();

			if(unApprovedExternalDomainsList != null)
			{
				unApprovedExternalDomains.addAll(unApprovedExternalDomainsList);
			}
			subLogger.info("saveInquiry with action ="+inquiryAction+" for soeId "+soeId+" , fromGroup= "+fromGroup+" ,isExternalMail= "+isExternalMail+" , makerCheckerRqd= "+makerCheckerRqd
					+" , approvalBypassed= "+approvalBypassed+" ,isMakerCheckerEnabled= "+isMakerCheckerEnabled+" ,rootCause= "+resolveRootCause+" ,processingRegion= "
					+resolveProcessingRegion+" ,queryCount= "+queryCount+" ,gfpid="+gfpid+", gfcid="+gfcid+", memo="+memo);
			DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
			Date currentTime = new Date();

			if (inquiryId == null)
			{
				saveFlag = true;
			}
			else
			{
				dbInquiry = getInquiryById(inquiryId);
				if (dbInquiry == null)
				{
					subLogger.info("Invalid InquiryId sent for saveInquiry-action-" + inquiryAction + " for Id=" + inquiryId + " by " + soeId);
					saveFlag = true;
				}else {
					subLogger.info("InquiryDAO.saveInquiry subject check inquiryId:{}", dbInquiry.getId());
					String existingSubject=dbInquiry.getSubject();
					String newUiSubject=inputJsonObj.getString(SUBJECT);
					if(!subjectBasedEmailThreading(existingSubject, newUiSubject)) {
						saveFlag = true;
					}
					
				}
			}
			DBObject stats;

			if (saveFlag)
			{
				subLogger.info("Save New Inquiry");
				Inquiry inquiry = new Inquiry();
				updateInquiryDetailsDO(inputJsonObj, inquiry, saveFlag, soeId, currentTime);
				Long draftId = GenericUtility.getIdFromRequest(inputJsonObj, "draftId");
				subLogger.info("Creating inquiry for draftID:"+draftId);
				if(null != draftId){
					inquiry.setDraftId(draftId);
				}
				//flag for symphony originate inquiry
				if(null != inputJsonObj && null != inputJsonObj.get("symphonyStreamId")) {
					String symphonyStreamId = inputJsonObj.getString("symphonyStreamId");
					inquiry.setSymphonyStreamId(symphonyStreamId);
				}
				
				InquiryUtil.updateInquiryOriginSource(inputJsonObj, inquiry);
				inquiryId = persist(inquiry);

				subLogger.info("INQUIRYID:" + inquiry.id);
				dbInquiry = inquiry;
				//Modified for requestType in Action Statistics - C153176-1155
				// getInquiryActionStatistics(dbInquiry,conversation,makerCheckerRqd);
				stats = getStatsObject(soeId, inquiryAction, currentTime, dbInquiry, fromGroupId, false,null, groupIdToNameMap, userInfoMap);
			}
			else
			{
				stats = getStatsObject(soeId, inquiryAction, currentTime, dbInquiry, fromGroupId, false, null, groupIdToNameMap, userInfoMap);

				// Reply,ReplyAll,ReplyResolve,ReplyAllResolve,Forward
				subLogger.info("Update  Inquiry-" + inquiryId);

				updateInquiryDetailsDO(inputJsonObj, dbInquiry, saveFlag, soeId, currentTime);
				dbInquiry.setAction(inquiryAction);

				try
				{
					persist(dbInquiry);
					
				}
				catch (Exception e)
				{
					subLogger.error("Retry case for inquiry update arises, check in next statement if rety was successful or not", e);
					Thread.sleep(5);
					// in case of concurrent issue, retry once again after 5 ms time
					persist(dbInquiry);
					subLogger.info("Retry case for inquiry update is successful");
				}
				subLogger.info("Inquiry Details Updated for action " + dbInquiry.getAction() + "-INQUIRYID:" + inquiryId);
			}
			//resolve allocation for action statistics
			String resolveAllocation = null != inputJsonObj.get("resolveAllocation") ? inputJsonObj.getString("resolveAllocation") : "";
			if(StringUtils.isNotBlank(resolveAllocation) && "Y".equalsIgnoreCase(resolveAllocation)) {
				stats.put("resolveAllocation",resolveAllocation);
			}
						
			// [C153176-853] - Add Inquiry ID in email - inquiry reference id to be added for first reply from group
			conversationContent = updateContentForFirstResponseFromGroup_new(dbInquiry, fromGroupId, conversationContent);

			Conversation conversation = createConversation(inputJsonObj, conversationContent, inquiryId, dbInquiry, soeId, currentTime);

			if (conversation.getAttachments() != null && !conversation.getAttachments().isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness)
			{
				stats.put("hasAttachment", "Y");
			}
			if (makerCheckerRqd)
			{
				stats.put("isMakerChecker", "Y");
			}
			boolean isEmailRoutedFromInternal = GenericUtility.isEmailRoutedFromInternal(getTOCCGrpCodeList(conversation.getRecipients()));
			boolean isEmailSentToExternal = !isMakerCheckerEnabled && isEmailSentToExternal(conversation.getRecipients());
			subLogger.info("saveInuiry: isEmailSentToExternal: ["+isEmailSentToExternal+"], isMakerCheckerEnabled: ["+isMakerCheckerEnabled);

			Workflow uiWorkflowData = new Workflow();// Workflow object copnatining data received from UI
			uiWorkflowData.setRequestType(requestType);
			uiWorkflowData.setRootCause(resolveRootCause);
			uiWorkflowData.setProcessingRegion(resolveProcessingRegion);
			uiWorkflowData.setRootCause(resolveRootCause);
			uiWorkflowData.setQueryCount(queryCount);
			uiWorkflowData.setInquirySource(inquirySource);
			String action = dbInquiry.getAction();
			if(isInquirySubStatusEnabled(dbInquiry.getLatestGroupId()) && action.equalsIgnoreCase(ACTION_NEW)) {
				uiWorkflowData.setInquirySubStatus(SUB_STATUS_NEW);
			}else if(isInquirySubStatusEnabled(dbInquiry.getLatestGroupId()) && (action.equalsIgnoreCase(ACTION_NEW_RESOLVE) || action.equalsIgnoreCase(ACTION_REPLY_RESOLVE) 
					|| action.equalsIgnoreCase(ACTION_REPLYALL_RESOLVE) || action.equalsIgnoreCase(ACTION_REPLY_RESOLVE_ALL)
					|| action.equalsIgnoreCase(ACTION_REPLYALL_RESOLVE_ALL))) {
				uiWorkflowData.setInquirySubStatus(SUB_STATUS_COMPLETED);
			}else {
				uiWorkflowData.setInquirySubStatus(inquirySubStatus);
				if(SUB_STATUS_PENDING_INTERNAL.equalsIgnoreCase(inquirySubStatus)) {
					uiWorkflowData.setIsSubStatusPendingInternal("Y");
				}
			}
			uiWorkflowData.setTag(tag);
			uiWorkflowData.setIsLastConvToExtEmail(isEmailSentToExternal ? "Y" : "N");
			uiWorkflowData.setFollowUp(followUp);
			uiWorkflowData.setUiWorkflowStatus(uiWorkflowStatus);
			uiWorkflowData.setPendingExternalDomains(unApprovedExternalDomains);
			uiWorkflowData.setResolveAllocation(resolveAllocation);

			List<ConversationRecipient> recipientsList = createRecipients(inputJsonObj, soeId);
			List<Workflow> workFlowList = createWorkFlows(dbInquiry, conversation, uiWorkflowData, isMakerCheckerEnabled, soeId, dbInquiry.getAction(), currentTime, resolveAllGroupList,recipientsList);
			if (conversation == null || workFlowList == null || workFlowList.isEmpty())
			{
				subLogger.info("Invalid Inquiry data, No Inquiry created for Action " + dbInquiry.getAction() + "-INQUIRYID:" + inquiryId);
				throw new CommunicatorException("Invalid Inquiry data,Please contact support ");
			}
			// Sonar Fix - remove unused private variables
			//C170665-118 for time in queue
			workFlowList.forEach(wf -> {
				// we need to keep the same value of isLatestReplyFromCurrentWorkflowGrp for the
				// group which is not the form group
				// while it is part of recipient and workflow direction is not IN
				if (!wf.getDirection().equalsIgnoreCase(INQUIRY_DIRECTION_IN)
						&& !fromGroupId.equals(wf.getAssignedGroupId())) {
					wf.setIsLatestReplyFromCurrentWorkflowGrp("Y");
				} else {
					String flag = (fromGroupId.equals(wf.getAssignedGroupId())) ? "Y" : "N";
					wf.setIsLatestReplyFromCurrentWorkflowGrp(flag);
				}
				subLogger.info("SaveInquiry : Time IN Queue : Group: {}", wf.getAssignedGroupName());		
			});
			
			// Making external email routing db driven.
			// All Conversations except Resolve/Reject will send email and route through Mail Receive Module to create INBOX version for internal groups
			if (isEmailRoutedFromInternal || isExternalMail)
			{
				// Create External Email Audit Entry
				createInquiryAuditRaw(inquiryId, conversation.id, makerCheckerRqd, approvalBypassed, fromGroupId, dbInquiry.getAction());
			}

			InquiryExtendedDAO.getInstance().customClientCriteriaExecution(inputJsonObj, dbInquiry, to, fromGroup, conversation, workFlowList);
			//attachment flag at workflow level
			if(null != workFlowList && null != conversation){
				InquiryExtendedDAO.getInstance().stampWorkflowAttachmentFlag(dbInquiry,workFlowList,conversation);
			}
			// Create new Audit for the inquiry
			updateInquiryDetailsDB(inputJsonObj, dbInquiry, conversation, workFlowList,recipientsList,currentTime, soeId, userActivity);
			//Stamp custom categories
			if(null != workFlowList){
				stampCustomClientCategories(dbInquiry, workFlowList);
			}
			//Remove snooze in case Reply,ReplyAll,Forward
			if(!saveFlag && null != inputJsonObj.get("shouldUnsnoozeProcess") && inputJsonObj.getBoolean("shouldUnsnoozeProcess")){
				removeSnooze(inquiryId, conversation);
			}

			subLogger.info("saveInquiry successfull for action " + dbInquiry.getAction() + "-INQUIRYID:" + inquiryId);
			response = new BasicDBObject();
			response.put("inquiryId", String.valueOf(inquiryId));
			response.put("conversationId", String.valueOf(conversation.getId()));
			userNotificationDAO.updateUserNotification(dbInquiry,  dbInquiry.getAction(), soeId, userNotificationType, userActivity);
			saveInquiryToPublish(inquiryId, dbInquiry.getAction(), soeId);

			// C153176-154-ActionStatistics Improvements
			updateStats(workFlowList, fromGroupId, stats, saveFlag ? INQUIRY_DIRECTION_IN : INQUIRY_DIRECTION_OUT, conversation, dbInquiry.getSubject());

			// save Stats
			statsCollection.save(stats);
			//save inquiry trend chart data
			if(stats != null){
				subLogger.info("trend chart data save started for action " + stats.get("action") + "-INQUIRYID:" + inquiryId);
				InquiryTrendDAO.getInstance().saveTrendChartData(stats, workFlowList);
			}
			
			if(saveFlag)
			{
				iInquiryActionStat.createInquiryActionStats(recipientsList, dbInquiry, workFlowList, currentTime, "", null);
			}
			else
			{
				iInquiryActionStat.updateInquiryActionStats(recipientsList, dbInquiry, workFlowList, currentTime, null);
			}
			
			subLogger.info("ActionStatistics Saved for action Test Pritam " + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
			
			// Update InquiryResponseTime Collection.
			//responseTimeUpdate.updateResponseTime(dbInquiry, inquiryAction, soeId, currentTime, fromGroupId, mongoDatastore);
			
			// Update Ext Email Recipient
			updateExtEmailRecipients(fromGroupId, conversation.getRecipients());

			// Delete drafts if any
			deleteDrafts(inputJsonObj, soeId);
			// Update User's Editor preferences if required
			if (inputJsonObj.getBoolean("isUserEditorPrefUpdated"))
			{
				userDao.saveUserEditorPreferences(soeId, inputJsonObj);
			}
			// Check whether exception id is present in json request and post message to CSL accordingly.
			Long exceptionId = dbInquiry.getExceptionId();
			String xstreamReqId = inputJsonObj.getString("requestId");
			if (null != exceptionId)
			{
				GenericUtility.postInquiryDetailsToCSL(dbInquiry, conversation, xstreamReqId);
			}
			if (!saveFlag) {
				//Reply,ReplyALL,replyResolve.replyAllResolve,forward,sendTpPendingApprovalEmail
				ConversationCache.getInstance().removeEntriesWithKeySetIteration(inquiryId);
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in saveInquiry for user= " + soeId + " , InquiryAction=" + inquiryAction + ", inquiryId=" + inquiryId, e);
			throw new CommunicatorException("Exception in saveInquiry for user= " + soeId + " , InquiryAction=" + inquiryAction + ", inquiryId=" + inquiryId, e);
		}
		return response;
	}
	/**
	 * @param inputJsonObj
	 * @param soeId
	 * @param reference 
	 * @throws CommunicatorException
	 */
	public void sendAutoReplyNotificationForNewInquiry(BasicDBObject inputJsonObj, boolean isNewInquiry, Inquiry inquiryObj, Map<String, Object> processorTOMap) throws CommunicatorException {
		try {
			String assignToUserId = inputJsonObj.getString(ASSIGN_TO_USER_ID);
			if(assignToUserId == null) {
				assignToUserId = "";
			}
			long inquiryId = inquiryObj.getId();
			subLogger.info("sendAutoReplyNotificationForNewInquiry :: assignToUserId :: {}, isNewInquiry :: {}, inquiryId :: {}",assignToUserId, isNewInquiry, inquiryId);
			
			String latestToCCGroups = inputJsonObj.getString("latestToCCGroups");
			List<String> latestToCCGroupList = new ArrayList<>();
			if(StringUtils.isNotBlank(latestToCCGroups)) {
				latestToCCGroupList = Arrays.asList(latestToCCGroups.split(";"));
			}
			
			Map<String, Long> groupCodeToIdMap = QMACacheFactory.getCache().getGroupCodeToIdMap();
			
			Set<Long> assignToGroupIds = new HashSet<>();
			for (int i = 0; i < latestToCCGroupList.size(); i++) {
				String toCCGroupName = latestToCCGroupList.get(i);
				if(StringUtils.isNotBlank(toCCGroupName)) {
					Long groupId = groupCodeToIdMap.get(toCCGroupName.toUpperCase());
					assignToGroupIds.add(groupId);
				}
			}
			
			
			if(!assignToGroupIds.isEmpty()) {
				Iterator<Long> itr = assignToGroupIds.iterator();
				while(itr.hasNext()) {
					Long groupId = itr.next();
					Map<Long, Boolean> inquiryIsRefSentMap = new HashMap<>();
					List<Long> inquiryIds = new ArrayList<>();
					inquiryIds.add(inquiryId); //C170665-4031 - As this is New inquiry flow, only 1 inquiry object is available
					List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);

					if (inquiryObjects != null) {
						subLogger.info("sendAutoReplyNotificationForNewInquiry :: {}", inquiryObjects.size());
						for (Inquiry inquiry : inquiryObjects) {
							boolean isInquiryRefSent = isInquiryRefSent(inquiry, groupId);
							inquiryIsRefSentMap.put(inquiry.getId(), isInquiryRefSent);
						}
					}
					String reference = (String) processorTOMap.get("reference");
					sendAutoReplyNotification(assignToUserId, groupId, inquiryObjects, inquiryIsRefSentMap, "", isNewInquiry, reference, processorTOMap);
				}
			}
		}
		catch (Exception e) {
			subLogger.error("Exception in sendAutoReplyNotificationWrapper :: ",e);
			throw new CommunicatorException("Exception in sendAutoReplyNotificationWrapper :: ",e);
		}
	}
	private boolean subjectBasedEmailThreading(String existingSubject,String newUiSubject) {
		boolean isSubMatched =true;
		try {
			String matchOp = null;
			
			Map<String, Object> emailThreadConfigMap = getEmailThreadConfigFromCache();
			 Map<String,String> subPrefixMap=null;
			if(null != emailThreadConfigMap && null != emailThreadConfigMap.get(MAIL_SUBJECT_REPLACE_REG_PATTERN_MAP)) {
				subPrefixMap = (Map<String, String>) emailThreadConfigMap.get(MAIL_SUBJECT_REPLACE_REG_PATTERN_MAP);
				matchOp = null != emailThreadConfigMap.get(MATCH_OP) ? (String) emailThreadConfigMap.get(MATCH_OP) : EQ;
				isSubMatched = MailServiceGenericUtil.sanitizeAndMatchSubject(existingSubject,newUiSubject,subPrefixMap, matchOp);
				subLogger.info(
						"Inside InquiryDAO.subjectBasedEmailThreading after sanitization subject matched :{}  "
						+ "existingThreadTopic subject: {};", isSubMatched, existingSubject);
				subLogger.info(
						"And new mail threadTopic subject: {};", newUiSubject);
				
			}
		} catch (Exception e) {
			subLogger.warn("Exception in InquiryDAO.subjectBasedEmailThreading for existing subject: {};", existingSubject, e);
			subLogger.warn("And new UI subject: {};", newUiSubject);
		}
		return isSubMatched;
	}

	/**
	 * This method is used to save custom client categories to new collection InquiryClientPriority
	 * @param dbInquiry
	 * @param workFlowList
	 */
	private void stampCustomClientCategories(Inquiry dbInquiry, List<Workflow> workFlowList) {
		try{
			Long inquiryId = dbInquiry.getId();
			for(Workflow workflowObj: workFlowList){
				if(null != workflowObj.getAssignedGroupId() && null != workflowObj.getCustomClientCategory()
						&& workflowObj.getCustomClientCategory().size() > 0){
					Long assignedGroupId = workflowObj.getAssignedGroupId();
					Query<InquiryClientPriority> query = mongoDatastore.createQuery(InquiryClientPriority.class)
							.filter("inquiryId", inquiryId)
							.filter("assignedGroupId", assignedGroupId);
					InquiryClientPriority inquiryClientPriority = query.get();
					if(null != inquiryClientPriority){
						UpdateOperations<InquiryClientPriority> updateOps = mongoDatastore.createUpdateOperations(InquiryClientPriority.class);
						updateOps.set("customClientCategory", workflowObj.getCustomClientCategory());
						mongoDatastore.update(query, updateOps);
					}else{
						inquiryClientPriority = new InquiryClientPriority();
						inquiryClientPriority.setInquiryId(inquiryId);
						inquiryClientPriority.setAssignedGroupId(assignedGroupId);
						inquiryClientPriority.setCustomClientCategory(workflowObj.getCustomClientCategory());
						inquiryClientPriority.setCrtDate(new Date());
						mongoDatastore.save(inquiryClientPriority);
					}		
				}
			}
		}catch(Exception ex){
			subLogger.error("Exception occured while stamping custom client category. InquiryDAO#stampCustomClientCategories",ex);
		}
	}

	private void removeSnooze(Long inquiryId, Conversation conversation) {
		try {
			
			Set<Long> incomingAssignedGroupIds = new HashSet<>();
			if(null != conversation && !conversation.getRecipients().isEmpty()){
				for(ConversationRecipient conversationRecipient : conversation.getRecipients()){
					incomingAssignedGroupIds.add(conversationRecipient.getGroupId());
				}
			} 
			
			if(!incomingAssignedGroupIds.isEmpty()){
				Query<InquirySnoozeDetails> query = mongoDatastore.createQuery(InquirySnoozeDetails.class).filter("processedFlag", false).filter("inquiryId", inquiryId);
				query.criteria("assignedGroupId").in(incomingAssignedGroupIds);
				List<InquirySnoozeDetails> snoozeDetailsList = query.asList();
				if(!snoozeDetailsList.isEmpty()){
					Date currentDate = new Date();
					UpdateOperations<InquirySnoozeDetails> updateOps = mongoDatastore.createUpdateOperations(InquirySnoozeDetails.class);
					updateOps.set("processedFlag", true);
					updateOps.set("modDate",currentDate);
					updateOps.set("snoozeEndTime", currentDate);
					mongoDatastore.update(query, updateOps);
					//adjust response escalation time 
					List<InquirySnoozeDetails> listSnoozeDetails = new ArrayList<>();
					for(InquirySnoozeDetails snoozeDetails : snoozeDetailsList){
						snoozeDetails.setProcessedFlag(true);
						snoozeDetails.setSnoozeEndTime(currentDate);
						snoozeDetails.setModDate(currentDate);
						listSnoozeDetails.add(snoozeDetails);
					}
					calculateAndSetResponseEscalationTime(listSnoozeDetails);
				}
			}
			else {
				subLogger.info("no valid assigned groupid for snozzed inquiry :"+inquiryId);
			}
			
		} catch (Exception e) {
			subLogger.error("Error while removing snooze.",e);
		}		
	}


	// Used for mark inquiry read/unread by user
	public boolean markInquiryReadUnRead(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			return bulkMarkInquiryReadUnRead(soeId, inputJsonObj);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in markInquiryReadUnRead for user= " + soeId + " , markAsRead=" + inputJsonObj.getString("readFlag"), e);
			throw new CommunicatorException("Exception in markInquiryReadUnRead for user= " + soeId + " , markAsRead=" + inputJsonObj.getString("readFlag"), e);
		}
	}

	public boolean bulkMarkInquiryReadUnRead(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		boolean bSuccess = Boolean.FALSE;

		// Request Params
		List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
		String markAsReadInput = inputJsonObj.getString("readFlag");
		boolean markAsReadFlag = "Y".equals(markAsReadInput);

		subLogger.info("bulkMarkInquiryReadUnRead for Inquiries size=" + inquiryIds.size() + " ,markAsReadFlag =[" + markAsReadFlag + "]");

		// Prepare findQuery for update
		DBObject findQueryObj = new BasicDBObject("_id", new BasicDBObject("$in", inquiryIds));

		// Prepare inquiryUpdate Object
		DBObject inquiryUpdateDBObj = new BasicDBObject();

		if (markAsReadFlag)
		{
			inquiryUpdateDBObj.put("$addToSet", new BasicDBObject(READ_BY, soeId));
		}
		else
		{
			inquiryUpdateDBObj.put("$pull", new BasicDBObject(READ_BY, soeId));
		}

		// DB Update
		DBCollection inquiryCollection = database.getCollection(INQUIRY);
		try {
		inquiryCollection.updateMulti(findQueryObj, inquiryUpdateDBObj);
		} catch (Exception e) {
			subLogger.error("Exception in bulk read/unread :" ,e);
		}
		bSuccess = Boolean.TRUE;

		return bSuccess;

	}

	public boolean resolveInquiry(String soeId, BasicDBObject inputJsonObj, UserActivities userActivity) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			List<String> fromGroupList = (List<String>) inputJsonObj.get(FROM);
			String requestType = inputJsonObj.getString(REQUEST_TYPE);
			String rootCause = inputJsonObj.getString(ROOT_CAUSE);
			String processingRegion = inputJsonObj.getString(PROCESSING_REGION);
			Long queryCount = null;
			if (!StringUtils.isBlank(inputJsonObj.getString(QUERY_COUNT)))
			{
				queryCount = Long.parseLong(inputJsonObj.getString(QUERY_COUNT));
			}
			String inquirySource = inputJsonObj.getString(INQUIRY_SOURCE);
			String forceUnlock = inputJsonObj.getString("forceUnlock");
			String inquirySubStatus = inputJsonObj.getString(INQUIRY_SUB_STATUS);
			String comment = inputJsonObj.getString("comment");
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			String tag = inputJsonObj.getString("tag");
			
			String resolveAllocation = null != inputJsonObj.get("resolveAllocation") ? inputJsonObj.getString("resolveAllocation") : "";

			if (fromGroupList == null || inquiryIds.isEmpty())
			{
				return false;
			}
			Set<Long> fromGrpIds = new HashSet<Long>();
			QMACache qmaCache = QMACacheFactory.getCache();
			Map<String, Long> groupCodeToIdMap = qmaCache.getGroupCodeToIdMap();
			for (String fromGroup : fromGroupList)
			{
				if (StringUtils.isEmpty(fromGroup) || (groupCodeToIdMap.get(fromGroup.toUpperCase()) == null))
				{
					subLogger.info("Invalid Group " + fromGroup + " for Resolve action");
					return false;
				}
				else
				{
					Long fromGroupId = groupCodeToIdMap.get(fromGroup.toUpperCase());
					fromGrpIds.add(fromGroupId);
				}

			}
		//	responseTimeUpdate.updateResponseTime(dbInquiry, inquiryAction, soeId, currentTime, fromGroupId, mongoDatastore);
			
			List<Inquiry> inquiryObjs = getInquiryList(inquiryIds);
			/*ResponseTimeUpdate responseTimeUpdate = new ResponseTimeUpdate();
			Date currentTime = new Date();
			responseTimeUpdate.updateResponseTime(inquiryObjs, ACTION_RESOLVE, soeId, currentTime, fromGrpIds, mongoDatastore);*/
			//C153176-1449 added one more parameter - ACTION_RESOLVE 
			List<Inquiry> resolveInquiryList = changeStatus(inquiryObjs, soeId, fromGrpIds, requestType, tag, comment, ACTION_RESOLVE, rootCause, processingRegion, queryCount, inquirySource ,forceUnlock,ACTION_RESOLVE,resolveAllocation,inquirySubStatus);

			if (null != resolveInquiryList)
			{
				userNotificationDAO.updateUserNotification(inquiryIds, ACTION_RESOLVE, soeId, userNotificationType, userActivity);
				saveInquiriesToPublish(inquiryIds, ACTION_RESOLVE, soeId);
				for (Inquiry inq : resolveInquiryList)
				{
					GenericUtility.postInquiryDetailsToCSL(inq, null, null);
				}
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in resolveInquiry for user= " + soeId, e);
			throw new CommunicatorException("Exception in resolveInquiry for user= " + soeId, e);
		}
		return true;
	}

	public boolean assignToOwner(String soeId, BasicDBObject inputJsonObj, UserActivities userActivity) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		boolean bSuccess = Boolean.FALSE;
		Map<Long, Boolean> inquiryIsRefSentMap = new HashMap<Long, Boolean>();
		try
		{
			List<Inquiry> inquiryObjects = null;

			String assignToUserId = inputJsonObj.getString(ASSIGN_TO_USER_ID);
			subLogger.info("In InquiryDao.assignToOwner --> input=" + assignToUserId);
			if (StringUtils.isEmpty(assignToUserId))
			{
				subLogger.info("Invalid Input for assignToOwner -" + assignToUserId + " by " + soeId);
				throw new CommunicatorException("Invalid Data for assignToOwner.");
			}

			// begin
			Set<Long> assignToGroupIds = new HashSet<Long>();
			String groupName = inputJsonObj.getString(GROUP_NAME);

			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfoMap =  populateInquiryInfoMap(dbObjs,null,null);

			Long groupId = null;
			// Get the Inquiries Objects from input Inquiry Ids
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			// GroupName null check
			if (!StringUtils.isBlank(groupName))
				groupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
			else
			{
				subLogger.info("Invalid Input for assignToOwner -" + assignToUserId + " by " + soeId + " for group name " + groupName);
				throw new CommunicatorException("Invalid Data for groupName.");
			}

			if (groupId == null)
			{
				subLogger.info("Active group not found in cache for groupName - {}", groupName);
			}
			else
			{
				assignToGroupIds.add(groupId);
				// end

				inquiryObjects = getInquiryList(inquiryIds);

				if (inquiryObjects != null)
				{

					for (Inquiry inquiry : inquiryObjects)
					{
						boolean isInquiryRefSent = isInquiryRefSent(inquiry, groupId);
						inquiryIsRefSentMap.put(inquiry.getId(), isInquiryRefSent);
					}

				}

				bSuccess = bulkAssignOwner(soeId, groupName, assignToGroupIds, assignToUserId, inquiryObjects,inquiryInfoMap);
				
			}
			try
			{
				boolean isNewInquiry = false; // C170665-4031
				sendAutoReplyNotification(assignToUserId, groupId, inquiryObjects, inquiryIsRefSentMap, soeId, isNewInquiry, null, null);
			}
			catch (Exception e)
			{
				subLogger.error("Exception in sendAutoReplyNotification for user= " + soeId, e);
				throw new CommunicatorException("Exception in sendAutoReplyNotification for user= " + soeId, e);
			}

		}
		catch (Exception e)
		{
			subLogger.error("Exception in assignToOwner for user= " + soeId, e);
			throw new CommunicatorException("Exception in assignToOwner for user= " + soeId, e);
		}

		return bSuccess;
	}

	public void sendAutoReplyNotification(String soeId, Long fromGroupId, List<Inquiry> inquiryObjects, Map<Long, Boolean> inquiryIsRefSentMap, String userId, boolean isNewInquiry, String reference, Map<String, Object> processorTOMap) throws CommunicatorException
	{
		AutoReplyHelper autoReplyHelper = new AutoReplyHelper();
		if (fromGroupId != null)
		{
			if (inquiryObjects != null && inquiryObjects.size() > 0)
			{
				QMACache qmaCache = QMACacheFactory.getCache();
				Map<Long, Group> allGroupsMap = qmaCache.getAllGroupsMap();
				Group fromGroup = allGroupsMap.get(fromGroupId);
				for (Inquiry inquiry : inquiryObjects)
				{
					if (inquiry != null && inquiry.getWorkflows() != null && inquiry.getWorkflows().size() > 0)
					{
						if (StringUtils.isNotBlank(inquiry.getOrigEmail()))
						{
							boolean isAutoReplyEnabled = GenericUtility.isAutoReplyEnabled(inquiry.getOrigEmail(), fromGroup, qmaCache);
							if (!isAutoReplyEnabled) {
								subLogger.info("autoReply will not be not sent as it is internal citi domain");
								continue;
							}
						} else if (inquiry.getOrigGroupId() != null) {
							Group toGroup = qmaCache.getAllGroupsMap().get(inquiry.getOrigGroupId());
							boolean isAutoReplyEnabled = GenericUtility.isAutoReplyEnabled(toGroup.getGroupEmail(), fromGroup, qmaCache);
							if (!isAutoReplyEnabled) {
								subLogger.info("autoReply will not be not sent to toGroup.getGroupEmail() :: {}, fromGroup :: {}, fromGroup.isCustomizedAutoResponseEnabled :: {} ", toGroup.getGroupEmail(), fromGroup.getGroupEmail(), fromGroup.isCustomizedAutoResponseEnabled());
								continue;
							}
						}
						
						if(processorTOMap != null) {
							String customAutoResponseOptions = fromGroup.getCustomAutoResponseOptions();
							boolean isCustomizedAutoResponseEnabled = fromGroup.isCustomizedAutoResponseEnabled();
							 HashMap<Long, String> autoReplyMap = (HashMap<Long, String>) processorTOMap.getOrDefault("autoReplyMap", null);
							 if(autoReplyMap != null && autoReplyMap.get(fromGroupId) != null && isCustomizedAutoResponseEnabled && (AutoReplyHelper.ON_USER_ASSIGNMENT.equalsIgnoreCase(customAutoResponseOptions) || AutoReplyHelper.ALL.equalsIgnoreCase(customAutoResponseOptions))) {
								 subLogger.info("autoReply skipped for new email as it will be sent via inquiry rule flow");
								 continue;
							 } else {
								 subLogger.info("autoReply will be sent...");
							 }
						}

						if (fromGroup != null && fromGroup.getAutoReplyEnable() != null && fromGroup.getAutoReplyEnable() == true)
						{
							for (Workflow workflow : inquiry.getWorkflows())
							{
								if (fromGroupId.equals(workflow.getAssignedGroupId()) && !soeId.equalsIgnoreCase(workflow.getAssignedUserId()))
								{
									subLogger.info("About to send AutoReply for OrigEmail:" + inquiry.getOrigEmail() + " , and inquiryRefSent: " + workflow.getInquiryRefSent());

									if (StringUtils.isNotBlank(inquiry.getOrigEmail()))// && workflow.getInquiryRefSent() != null && !workflow.getInquiryRefSent().equalsIgnoreCase("Y"))
									{
										boolean isInquiryRefSent = inquiryIsRefSentMap.get(inquiry.getId()); // isInquiryRefSent(inquiry, fromGroupId);
										boolean isAutoReplySent = autoReplyHelper.sendAutoReply(soeId, fromGroupId, inquiry.getId(), inquiry.getOrigEmail(), isInquiryRefSent, reference, isNewInquiry);
										
										// C153176-5979 | QMA Auto response not considered for Response time metrics.
										setAutoReplyResponseTime(workflow, fromGroupId, inquiry.getId(), userId, isAutoReplySent, fromGroup);
									} else if(inquiry.getOrigGroupId() != null) {
										Long toGroupId = inquiry.getOrigGroupId();
										subLogger.info("About to send AutoReply to OrigGroupId : {}",toGroupId);
										try {
											Group toGroup = qmaCache.getAllGroupsMap().get(toGroupId);
											if(toGroup != null) {
												boolean isInquiryRefSent = inquiryIsRefSentMap.get(inquiry.getId()); // isInquiryRefSent(inquiry, fromGroupId);
												subLogger.info("toGroup.getGroupEmail() :: {}", toGroup.getGroupEmail());
												boolean isAutoReplySent = autoReplyHelper.sendAutoReply(soeId, fromGroupId, inquiry.getId(), toGroup.getGroupEmail(), isInquiryRefSent, reference, isNewInquiry);
												
												// C153176-5979 | QMA Auto response not considered for Response time metrics.
												setAutoReplyResponseTime(workflow, fromGroupId, inquiry.getId(), userId, isAutoReplySent, fromGroup);
											} else {
												subLogger.info("Not able to send AutoReply as toGroup is null");
											}
										} catch(Exception ex) {
											subLogger.error("Exception while sending auto response to DL :: ",ex);
										}
									}

									subLogger.info("sendAutoReplyNotification for actionbySoeId: " + soeId + " ,  workflow's assignedUserSoeId: " + workflow.getAssignedUserId() + ",  fromGroupId: "
											+ fromGroupId
											+ ", inquiryId: " + inquiry.getId());

									break;

								}
							}

						}
					}
				}
			}
		}
	}
	
	/**
	 * Method to set the auto reply response time to inquiry workflow for the assigned group.
	 * 
	 * @param workFlow
	 * @param fromGroupId
	 * @param inquiryId
	 * @param userId
	 */
	public void setAutoReplyResponseTime(Workflow workFlow, Long fromGroupId, Long inquiryId, String userId, boolean isAutoReplySent, Group fromGroup) {
		subLogger.info("setAutoReplyResponseTime for Auto Reply for Inquiry Id =" + inquiryId + " , fromGroupId=" + fromGroupId);
		try {
			DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
			BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();
			DBObject findWorkAuditflowQuery = prepareFindQuery(inquiryId, workFlow.getAssignedGroupId(), STATUS_OPEN, INQUIRY_DIRECTION_IN_OR_OUT, false);
			Timestamp currentTime = new Timestamp(System.currentTimeMillis());
			
			subLogger.info("setAutoReplyResponseTime :: fromGroup.isCustomizedAutoResponseEnabled() :: {}", fromGroup.isCustomizedAutoResponseEnabled());
			if(!fromGroup.isCustomizedAutoResponseEnabled()) {
				DBObject findINWorkflowQuery = prepareFindQuery(inquiryId, workFlow.getAssignedGroupId(), STATUS_OPEN, INQUIRY_DIRECTION_IN, false);
				DBObject inquiryUpdateDBObj = new BasicDBObject();

				List<Workflow> workflowList = new ArrayList<>();
				workflowList.add(workFlow);

				// Calculate Response time
				calculateResponseTime(workflowList, fromGroupId, currentTime);

				// Calculate CITI response time based on new logic related to C153176-5891
				calculateCitiResponseTime(workflowList, fromGroupId, currentTime);

				Workflow wf = workflowList.get(0);
				if (null != wf.getResponseTimeQMA() && null != wf.getReplyCountQMA() && null != wf.getLatestConversationTime() && null != wf.getResponseTimeInMinutes()) {
					inquiryUpdateDBObj.put("workflows.$.responseTimeQMA", wf.getResponseTimeQMA());
					inquiryUpdateDBObj.put("workflows.$.replyCountQMA", wf.getReplyCountQMA());
					inquiryUpdateDBObj.put("workflows.$.latestConversationTime",  wf.getLatestConversationTime());
					inquiryUpdateDBObj.put("workflows.$.responseTimeInMinutes", wf.getResponseTimeInMinutes());
				}
				
				if (null != wf.getCitiResponseTime() && null != wf.getCitiReplyCountFromQMA() && null != wf.getFirstNonChaserResponseTimeByExternal() ) {
					inquiryUpdateDBObj.put("workflows.$.citiResponseTime", wf.getCitiResponseTime());
					inquiryUpdateDBObj.put("workflows.$.citiReplyCountFromQMA", wf.getCitiReplyCountFromQMA());
					inquiryUpdateDBObj.put("workflows.$.firstNonChaserResponseTimeByExternal", wf.getFirstNonChaserResponseTimeByExternal());
					inquiryUpdateDBObj.put("workflows.$.isLatestResponseFromNonQMA", "N");
				}
				
				// Calculate First Response time.
				updateFirstResponseTime(fromGroupId, currentTime, workFlow);
				if (null != workFlow.getFirstResponseInMinutes() && null != workFlow.getFirstResponseTime()) {
					inquiryUpdateDBObj.put("workflows.$.firstResponseInMinutes", workFlow.getFirstResponseInMinutes());
					inquiryUpdateDBObj.put("workflows.$.firstResponseTime", workFlow.getFirstResponseTime());
				}
				
				// Create Audit 
				Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
				Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
				DBObject workflowAudit = createWorkFlowsAuditJavaDriver(workFlow.getAssignedGroupId(), "Auto Response- Reply", workFlow.getAssignedGroupName(), userId, currentTime, groupIdToNameMap, userInfoMap);
				workflowAudit.put(INQUIRY_ID, inquiryId);
				workflowAudit.put(GROUP_ID, workFlow.getAssignedGroupId());

				// Update inquiry fields
				DBObject updateDBFields = new BasicDBObject();
				updateDBFields.put("$set", inquiryUpdateDBObj);
				bulkInquiryUpdOp.find(findINWorkflowQuery).update(updateDBFields);
				
				// Create new Audit for the action
				subLogger.info("Adding WorkflowAudit as Auto Response is sent");
				DBObject updateWorkAuditFields = new BasicDBObject();
				updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));
				bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);
			}
			
			else if(fromGroup.isCustomizedAutoResponseEnabled() && isAutoReplySent) {
				subLogger.info("setAutoReplyResponseTime :: for CustomizedAutoResponse :: {}", fromGroup.isCustomizedAutoResponseEnabled());
				// Create Audit 
				Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
				Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
				DBObject workflowAudit = createWorkFlowsAuditJavaDriver(workFlow.getAssignedGroupId(), "Auto Response- Reply", workFlow.getAssignedGroupName(), userId, currentTime, groupIdToNameMap, userInfoMap);
				workflowAudit.put(INQUIRY_ID, inquiryId);
				workflowAudit.put(GROUP_ID, workFlow.getAssignedGroupId());
				
				subLogger.info("Adding WorkflowAudit as Auto Response is sent");
				DBObject updateWorkAuditFields = new BasicDBObject();
				updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));
				bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);
			}
			
			bulkInquiryUpdOp.execute();			
		} catch (Exception ex) {
			subLogger.error("Exception while setting auto reply response time - setAutoReplyResponseTime:", ex);
		}

	}

	private boolean bulkAssignRequestType(String soeId, Set<Long> assignToGroupIds, String requestType, List<Inquiry> inquiryObjects) throws CommunicatorException// Sonar Fix -- Define and throw a
	// using a generic one
	{
		subLogger.info("bulkAssignRequestType for Inquiries size=" + inquiryObjects.size() + " , fromGrp=" + assignToGroupIds + ",requestType=" + requestType);
		boolean bSuccess = Boolean.FALSE;

		DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
		BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();

		DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
		BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();

		Date currentTime = new Date();
		boolean isMultiGroupOperation = assignToGroupIds != null && !assignToGroupIds.isEmpty();// Sonar Fix -- remove useless parenthesis
		boolean isBulkAction= inquiryObjects != null && inquiryObjects.size() > 1 ;
		if (isMultiGroupOperation)
		{
			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, ACTION_ASSIGN_REQ_TYPE);
			String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
			inquiryUpdateDBObj.put(WORKFLOWS_REQUEST_TYPE, requestType);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
			inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_ASSIGN_REQ_TYPE);
			Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			for (Inquiry inqObj : inquiryObjects)
			{
				// Set request type to inquiry level-
				String inquiryReqTypes = updateInquiryRequestType(inqObj.getWorkflows(), requestType, assignToGroupIds);
				if (!StringUtils.isBlank(inquiryReqTypes))
				{
					inquiryUpdateDBObj.put(REQUEST_TYPE_STR, inquiryReqTypes);
				}
				for (Long assignToGroupId : assignToGroupIds)
				{
					DBObject updateWorkAuditFields = new BasicDBObject();
					List<Workflow> workflows =  inqObj.getWorkflows();
					for(Workflow wf:workflows) {
						if(!assignToGroupIds.contains(wf.getAssignedGroupId())) {
							continue;
						}
						String oldRT = wf.getRequestType();
						String actionDescription = "";
						if(StringUtils.isBlank(oldRT)) {
							actionDescription = REQUEST_TYPE_CHANGED_TO_KEY+requestType + FOR_KEY + groupIdToNameMap.get(assignToGroupId);
						}else {
							actionDescription = REQUEST_TYPE_CHANGED_FROM_KEY+oldRT+" to "+requestType + FOR_KEY + groupIdToNameMap.get(assignToGroupId);
						}
						DBObject workflowAudit = createWorkFlowsAuditJavaDriver(assignToGroupId, ACTION_ASSIGN_REQ_TYPE, actionDescription , soeId, currentTime, groupIdToNameMap, userInfoMap);
						workflowAudit.put(INQUIRY_ID, inqObj.id);
						workflowAudit.put(GROUP_ID, assignToGroupId);
						updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));
					}

					//Modified for requestType in Action Statistics - C153176-1155
					//DBObject stats = getStatsObject(soeId, ACTION_ASSIGN_REQ_TYPE, currentTime, inqObj, assignToGroupId, inquiryObjects);
					ActionStatistics statsObj = new ActionStatistics();
					statsObj.setRequestType(requestType);
					DBObject stats = getStatsObject(soeId, ACTION_ASSIGN_REQ_TYPE, currentTime, inqObj, assignToGroupId, isBulkAction, statsObj, groupIdToNameMap, userInfoMap);

					DBObject updateDBFields = new BasicDBObject();
					// Update inquiry fields
					updateDBFields.put("$set", inquiryUpdateDBObj);
					// Create new Audit for the action
					
					DBObject findINQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN, false);
					// C153176-368-Resolved Inquiry Cannot be found with OUT version
					DBObject findOUTQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_OUT, false);
					DBObject findWorkAuditflowQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN_OR_OUT, false);
					// subLogger.debug("Update Query:" + findINQuery);
					// subLogger.debug("Update Query:" + findOUTQuery);
					// subLogger.debug("Update Infos:" + inquiryUpdateDBObj);
					// Add to bulk
					bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);
					bulkInquiryUpdOp.find(findOUTQuery).update(updateDBFields);
					bulkStatsInsertdOp.insert(stats);
					subLogger.info("ActionStatistics Saved for action  1" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
					bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);
				}				
				iInquiryActionStat.bulkUpdateInquiryActionStats(inqObj,ACTION_ASSIGN_REQ_TYPE, currentTime, assignToGroupIds);

			}
		}
		// Execute
		if (!inquiryObjects.isEmpty())
		{
			bulkInquiryUpdOp.execute();
			bulkStatsInsertdOp.execute();

		}
		bSuccess = Boolean.TRUE;
		return bSuccess;
	}
	
	
	private boolean bulkAssignRootCause(String soeId, Set<Long> assignToGroupIds, String rootCause, List<Inquiry> inquiryObjects) throws CommunicatorException// Sonar Fix -- Define and throw a
	{
		subLogger.info("bulkAssignRootCause for Inquiries size= {}", inquiryObjects.size());
		boolean bSuccess = Boolean.FALSE;

		DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
		BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();

		DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
		BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();

		Date currentTime = new Date();
		boolean isMultiGroupOperation = assignToGroupIds != null && !assignToGroupIds.isEmpty();// Sonar Fix -- remove useless parenthesis
		boolean isBulkAction= inquiryObjects != null && inquiryObjects.size() > 1 ;
		if (isMultiGroupOperation)
		{
			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, ACTION_ASSIGN_ROOT_CAUSE);
			String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
			inquiryUpdateDBObj.put(WORKFLOWS_ROOT_CAUSE, rootCause);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
			inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_ASSIGN_ROOT_CAUSE);
			Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			for (Inquiry inqObj : inquiryObjects)
			{
				for (Long assignToGroupId : assignToGroupIds)
				{

					DBObject workflowAudit = createWorkFlowsAuditJavaDriver(assignToGroupId, ACTION_ASSIGN_ROOT_CAUSE, rootCause, soeId, currentTime, groupIdToNameMap, userInfoMap);

					workflowAudit.put(INQUIRY_ID, inqObj.id);
					workflowAudit.put(GROUP_ID, assignToGroupId);
					
					ActionStatistics statsObj = new ActionStatistics();
					statsObj.setRootCause(rootCause);
					DBObject stats = getStatsObject(soeId, ACTION_ASSIGN_ROOT_CAUSE, currentTime, inqObj, assignToGroupId, isBulkAction, statsObj, groupIdToNameMap, userInfoMap);

					DBObject updateDBFields = new BasicDBObject();
					// Update inquiry fields
					updateDBFields.put("$set", inquiryUpdateDBObj);
					// Create new Audit for the action
					DBObject updateWorkAuditFields = new BasicDBObject();
					updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));

					DBObject findINQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN, false);
					// C153176-368-Resolved Inquiry Cannot be found with OUT version
					DBObject findOUTQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_OUT, false);
					DBObject findWorkAuditflowQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN_OR_OUT, false);
					// subLogger.debug("Update Query:" + findINQuery);
					// subLogger.debug("Update Query:" + findOUTQuery);
					// subLogger.debug("Update Infos:" + inquiryUpdateDBObj);
					// Add to bulk
					bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);
					bulkInquiryUpdOp.find(findOUTQuery).update(updateDBFields);
					bulkStatsInsertdOp.insert(stats);
					subLogger.info("ActionStatistics Saved for action  1" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
					bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);
				}				
				iInquiryActionStat.bulkUpdateInquiryActionStats(inqObj,ACTION_ASSIGN_ROOT_CAUSE, currentTime, assignToGroupIds);

			}
		}
		// Execute
		if (!inquiryObjects.isEmpty())
		{
			bulkInquiryUpdOp.execute();
			bulkStatsInsertdOp.execute();

		}
		bSuccess = Boolean.TRUE;
		return bSuccess;
	}

	private boolean bulkAssignOwner(String soeId, String groupName, Set<Long> assignToGroupIds, String assignToUserId, List<Inquiry> inquiryObjects, Map<Long, ActionStatistics> inquiryInfoMap) throws CommunicatorException// Sonar Fix -- Define
	{
		subLogger.info("bulkAssignOwner for Inquiries size= {}", inquiryObjects.size());
		boolean bSuccess = Boolean.FALSE;

		if (assignToGroupIds != null && !assignToGroupIds.isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
		{
			String assignUserName = getAssignUserName(assignToUserId, groupName);
			Date currentTime = new Date();
			DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
			BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();

			DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
			BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();
			String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, ACTION_ASSIGN_TO_OWNER);
			inquiryUpdateDBObj.put("workflows.$.assignedUserId", assignToUserId);
			inquiryUpdateDBObj.put("workflows.$.assignedUserName", assignUserName);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
			inquiryUpdateDBObj.put("workflows.$.inquiryRefSent", "Y");
			if (assignToUserId.equalsIgnoreCase(soeId))
			{
				inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_SELF_ASSIGN);
			}
			else
			{
				inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_ASSIGN_TO_OWNER);
			}
			boolean isBulkAction= inquiryObjects != null && inquiryObjects.size() > 1 ;
			Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			for (Inquiry inquiry : inquiryObjects)
			{
				updateOpenUserDetails(assignUserName, inquiry, inquiryUpdateDBObj, assignToGroupIds);
				for (Long assignToGroupId : assignToGroupIds)
				{
					DBObject workflowAudit;
					if (assignToUserId.equalsIgnoreCase(soeId))
					{
						// GroupId needs to be sent to take the groupname and update in audit object
						workflowAudit = createWorkFlowsAuditJavaDriver(assignToGroupId, ACTION_SELF_ASSIGN, "", soeId, currentTime, groupIdToNameMap, userInfoMap);
					}
					else
					{
						workflowAudit = createWorkFlowsAuditJavaDriver(assignToGroupId, ACTION_ASSIGN_TO_OWNER, assignUserName, soeId, currentTime, groupIdToNameMap, userInfoMap);
					}

					workflowAudit.put(INQUIRY_ID, inquiry.id);
					workflowAudit.put(GROUP_ID, assignToGroupId);

					String action = assignToUserId.equalsIgnoreCase(soeId) ? ACTION_SELF_ASSIGN : ACTION_ASSIGN_TO_OWNER;

					//Modified for requestType in Action Statistics - C153176-1155
					//DBObject stats = getStatsObject(soeId, action, currentTime, inquiry, assignToGroupId, inquiryObjects);
					ActionStatistics statsObj = inquiryInfoMap.get( inquiry.id+assignToGroupId);
					DBObject stats = getStatsObject(soeId, action, currentTime, inquiry, assignToGroupId, isBulkAction, statsObj, groupIdToNameMap, userInfoMap);
					DBObject updateDBFields = new BasicDBObject();
					Long unassignedTime = calculateAndStampUassignedTimeInFlow(inquiry.getWorkflows(), assignToGroupId);
					if (null != unassignedTime) {
						inquiryUpdateDBObj.put("workflows.$.unassignedTimeInMins", unassignedTime);
					}
					// Update inquiry fields
					updateDBFields.put("$set", inquiryUpdateDBObj);
					// Create new Audit for the action
					DBObject updateWorkAuditFields = new BasicDBObject();
					updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));

					DBObject findINWorkflowQuery = prepareFindQuery(inquiry.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN, false);
					// C153176-368-Resolved Inquiry Cannot be found with OUT version
					DBObject findOUTWorkflowQuery = prepareFindQuery(inquiry.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_OUT, false);

					DBObject findWorkAuditflowQuery = prepareFindQuery(inquiry.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN_OR_OUT, false);

					// subLogger.debug("Update IN Query:" + findINWorkflowQuery);
					// subLogger.debug("Update Query:" + findOUTWorkflowQuery);
					// subLogger.debug("Update Infos:" + inquiryUpdateDBObj);
					// Add to bulk
					bulkInquiryUpdOp.find(findINWorkflowQuery).update(updateDBFields);
					bulkInquiryUpdOp.find(findOUTWorkflowQuery).update(updateDBFields);
					bulkStatsInsertdOp.insert(stats);
					subLogger.info("ActionStatistics Saved for action 2" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
					bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);
				}
				iInquiryActionStat.bulkUpdateInquiryActionStats(inquiry, ACTION_ASSIGN_TO_OWNER, currentTime, assignToGroupIds);
			}
			// Execute
			if (!inquiryObjects.isEmpty())
			{
				bulkInquiryUpdOp.execute();
				bulkStatsInsertdOp.execute();
			}
			bSuccess = Boolean.TRUE;
		}
		return bSuccess;
	}

	/**
	 * method used to calculate unassigned time for from workflowlist IN workflow
	 * @param workflowList
	 * @param assignToGroupId
	 * @return
	 */
	private Long calculateAndStampUassignedTimeInFlow(List<Workflow> workflowList, Long assignToGroupId) {
		try {
			Workflow fromWorkflow = getWorkflow(workflowList, assignToGroupId, INQUIRY_DIRECTION_IN);
			return calculateUnassignedTime(fromWorkflow);
			
		} catch (Exception ex) {
			subLogger.error("Exception while calculating unassigned time:", ex);
		}
		return null;
	}
	/**
	 * method used to calculate unassigned time for resolve/reply workflow
	 * @param fromWorkflow
	 * @return
	 */
	private Long calculateUnassignedTime(Workflow fromWorkflow){
		Long diffMinutes = null;
		try {
			if (null != fromWorkflow && null == fromWorkflow.getAssignedUserId() && null == fromWorkflow.getUnassignedTimeInMins()) {
				Date crtDate = (Date) fromWorkflow.getCrtDate();
				long diff = new Date().getTime() - crtDate.getTime();
				diffMinutes = diff / (60 * 1000);
				return diffMinutes;
			}
		} catch (Exception e) {
			subLogger.error("Exception while calculating unassigned time:", e);;
		}
		return diffMinutes;
	}
	private void updateOpenUserDetails(String assignToUserId, Inquiry inquiry, DBObject inquiryUpdateDBObj, Set<Long> assignGrpId)
	{
		// latest open Users update-
		Map<String, String> openGroupsAndUserMap = getOpenGroups(inquiry.getWorkflows(), assignToUserId, assignGrpId);
		String openUsers = openGroupsAndUserMap.get(OPEN_USERS);
		if (!StringUtils.isBlank(openUsers))
		{
			inquiryUpdateDBObj.put(OPEN_USERS, openUsers);
		}
	}

	public boolean assignRequestType(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		boolean bSuccess = Boolean.FALSE;
		try
		{
			// begin - Friday - Nov20th - update only the version that is selected from UI, not all
			Set<Long> userGroupsList = new HashSet<Long>();

			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			String groupName = inputJsonObj.getString(GROUP_NAME);
			String userDefinedRequestType = inputJsonObj.getString(REQUEST_TYPE);
			Long groupId = null;
			if (!StringUtils.isBlank(groupName))
				groupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
			else
			{
				subLogger.info("Invalid Input for assignRequestType -" + userDefinedRequestType + " by " + soeId + " for group name " + groupName);
				throw new CommunicatorException("Invalid Data for groupName.");
			}

			if (groupId == null)
			{
				subLogger.info("Active group not found in cache for groupName - {}", groupName );
			}
			else
			{
				userGroupsList.add(groupId);
				// end

				List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);

				if (StringUtils.isEmpty(userDefinedRequestType))
				{
					subLogger.info("Invalid Input for assignRequestType -" + userDefinedRequestType + " by " + soeId);
					throw new CommunicatorException("Invalid Data for assignRequestType.");
				}
				bSuccess = bulkAssignRequestType(soeId, userGroupsList, userDefinedRequestType, inquiryObjects);
				
			}

		}
		catch (Exception e)
		{
			subLogger.error("Exception in assignRequestType for user= " + soeId, e);
			throw new CommunicatorException("Exception in assignRequestType for user= " + soeId, e);
		}

		return bSuccess;
	}
	
	
	public boolean assignRootCause(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		boolean bSuccess = Boolean.FALSE;
		try
		{
			Set<Long> userGroupsList = new HashSet<Long>();

			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			String groupName = inputJsonObj.getString(GROUP_NAME);
			String userDefinedRootCause = inputJsonObj.getString(ROOT_CAUSE);
			Long groupId = null;
			if (!StringUtils.isBlank(groupName))
				groupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
			else
			{
				subLogger.info("Invalid Input for assignRootCause -" + userDefinedRootCause + " by " + soeId + " for group name " + groupName);
				throw new CommunicatorException("Invalid Data for groupName.");
			}

			if (groupId == null)
			{
				subLogger.info("Active group not found in cache for groupName - {}", groupName);
			}
			else
			{
				userGroupsList.add(groupId);
				// end

				List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);

				if (StringUtils.isEmpty(userDefinedRootCause))
				{
					subLogger.info("Invalid Input for assignRootCause -" + userDefinedRootCause + " by " + soeId);
					throw new CommunicatorException("Invalid Data for assignRootCause.");
				}
				bSuccess = bulkAssignRootCause(soeId, userGroupsList, userDefinedRootCause, inquiryObjects);
				
			}

		}
		catch (Exception e)
		{
			subLogger.error("Exception in assignRootCause for user= " + soeId, e);
			throw new CommunicatorException("Exception in assignRootCause for user= " + soeId, e);
		}

		return bSuccess;
	}

	public boolean assignProcessingRegion(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		boolean bSuccess = Boolean.FALSE;
		try
		{

			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			String processingRegion = inputJsonObj.getString(PROCESSING_REGION);
			boolean isMultiGroupAction = inputJsonObj.getBoolean(IS_MULTI_GROUP_ACTION_KEY);
			String commonGroupId = inputJsonObj.getString(COMMON_GROUP_ID_KEY);


			if (inquiryIds.size() != groupIds.size())
			{
				subLogger.info("Invalid Input for assignProcessingRegion -" + processingRegion + " by " + soeId + ". InquiryIdList size and groupIdList size do not match.");
				throw new CommunicatorException("InquiryIdList size - [" + inquiryIds.size() + "] and groupIdList size - [" + groupIds.size() + "] do not match for assignProcessingRegion.");
			}
			if (StringUtils.isBlank(processingRegion))
			{
				subLogger.info("Invalid Input for assignProcessingRegion - [" + processingRegion + "] by " + soeId);
				throw new CommunicatorException("Invalid Processing Region for assignProcessingRegion.");
			}
	
			List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);
			Map<Long, String> inquiryGroupIdMap =populateInquiryGrpMapForMultiGrpAction(ACTION_ASSIGN_PROCESSING_REGION, groupIds, isMultiGroupAction);
			
			Date currentTime = new Date();
			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, ACTION_ASSIGN_PROCESSING_REGION);
			String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
			inquiryUpdateDBObj.put(WORKFLOWS_PROCESSING_REGION, processingRegion);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
			inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_ASSIGN_PROCESSING_REGION);

			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfo =  populateInquiryInfoMap(dbObjs,ACTION_ASSIGN_PROCESSING_REGION,processingRegion);

			bSuccess = bulkMultiGroupAction(soeId, inquiryObjects, isMultiGroupAction, inquiryGroupIdMap, commonGroupId,ACTION_ASSIGN_PROCESSING_REGION,inquiryUpdateDBObj, null, inquiryInfo );
		}
		catch (Exception e)
		{
			subLogger.error("Exception in assignProcessingRegion for user= " + soeId, e);
			throw new CommunicatorException("Exception in assignProcessingRegion for user= " + soeId, e);
		}

		return bSuccess;
	}
	
	public boolean assignInquirySubStatus(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException
	{
		boolean bSuccess = false;

		try
		{
			List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			//List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			String inquirySubStatus = inputJsonObj.getString(INQUIRY_SUB_STATUS);
			inquirySubStatus = inquirySubStatus.replace("?","-");
			boolean isMultiGroupAction = inputJsonObj.getBoolean(IS_MULTI_GROUP_ACTION_KEY);
			String commonGroupId = inputJsonObj.getString(COMMON_GROUP_ID_KEY);

			if (inquiryIds.size() != groupIds.size())
			{
				subLogger.info("Invalid Input for assignInquirySubStatus - {} by {}. InquiryIdList size and groupIdList size do not match." ,inquirySubStatus, soeId );
				throw new CommunicatorException("InquiryIdList size - [" + inquiryIds.size() + "] and groupIdList size - [" + groupIds.size() + "] do not match for assignInquirySource.");
			}
			if (StringUtils.isBlank(inquirySubStatus))
			{
				subLogger.info("Invalid Input for assignInquirySubStatus - [{}] by {}",inquirySubStatus, soeId);
				throw new CommunicatorException("Invalid Inquiry Sub-Status for assignInquirySubStatus.");
			}
			List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);
			Map<Long, String> inquiryGroupIdMap =populateInquiryGrpMapForMultiGrpAction(ACTION_ASSIGN_INQUIRY_SUB_STATUS, groupIds, isMultiGroupAction);

			Date currentTime = new Date();
			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, ACTION_ASSIGN_INQUIRY_SUB_STATUS);
			String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
			inquiryUpdateDBObj.put(WORKFLOWS_INQUIRY_SUB_STATUS, inquirySubStatus);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
			inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_ASSIGN_INQUIRY_SUB_STATUS);
			inquiryUpdateDBObj.put(MODIFIED_DATE, currentTime);
			inquiryUpdateDBObj.put(MODIFIED_BY, userName);
			if(SUB_STATUS_PENDING_INTERNAL.equals(inquirySubStatus)) {
				inquiryUpdateDBObj.put(WORKFLOWS_INQUIRY_SUB_STATUS_PENDING_INTERNAL, "Y");
			}

			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfo =  populateInquiryInfoMap(dbObjs,ACTION_ASSIGN_INQUIRY_SUB_STATUS,inquirySubStatus);

			bSuccess = bulkMultiGroupAction(soeId, inquiryObjects, isMultiGroupAction, inquiryGroupIdMap, commonGroupId,ACTION_ASSIGN_INQUIRY_SUB_STATUS,inquiryUpdateDBObj, null, inquiryInfo );
			
		}
		catch (Exception e)
		{
			subLogger.error("Exception in assignInquirySubStatus for user= {}, {}", soeId, e);
			throw new CommunicatorException("Exception in assignInquirySubStatus for user= " + soeId, e);
		}

		return bSuccess;
	}
	
	// [C153176-854] - Add new drop-down: Inquiry Source
	public boolean assignInquirySource(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException
	{
		boolean bSuccess = false;

		try
		{
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			String inquirySource = inputJsonObj.getString(INQUIRY_SOURCE);
			boolean isMultiGroupAction = inputJsonObj.getBoolean(IS_MULTI_GROUP_ACTION_KEY);
			String commonGroupId = inputJsonObj.getString(COMMON_GROUP_ID_KEY);

			if (inquiryIds.size() != groupIds.size())
			{
				subLogger.info("Invalid Input for assignInquirySource -" + inquirySource + " by " + soeId + ". InquiryIdList size and groupIdList size do not match.");
				throw new CommunicatorException("InquiryIdList size - [" + inquiryIds.size() + "] and groupIdList size - [" + groupIds.size() + "] do not match for assignInquirySource.");
			}
			if (StringUtils.isBlank(inquirySource))
			{
				subLogger.info("Invalid Input for assignInquirySource - [" + inquirySource + "] by " + soeId);
				throw new CommunicatorException("Invalid Inquiry Source for assignInquirySource.");
			}
			List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);
			Map<Long, String> inquiryGroupIdMap =populateInquiryGrpMapForMultiGrpAction(ACTION_ASSIGN_INQUIRY_SOURCE, groupIds, isMultiGroupAction);

			Date currentTime = new Date();
			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, ACTION_ASSIGN_INQUIRY_SOURCE);
			String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
			inquiryUpdateDBObj.put(WORKFLOWS_INQUIRY_SOURCE, inquirySource);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
			inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_ASSIGN_INQUIRY_SOURCE);

			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfo =  populateInquiryInfoMap(dbObjs,ACTION_ASSIGN_INQUIRY_SOURCE,inquirySource);

			bSuccess = bulkMultiGroupAction(soeId, inquiryObjects, isMultiGroupAction, inquiryGroupIdMap, commonGroupId,ACTION_ASSIGN_INQUIRY_SOURCE,inquiryUpdateDBObj, null, inquiryInfo );
			
		}
		catch (Exception e)
		{
			subLogger.error("Exception in assignInquirySource for user= " + soeId, e);
			throw new CommunicatorException("Exception in assignInquirySource for user= " + soeId, e);
		}

		return bSuccess;
	}

	private Map<Long, String> populateInquiryGrpMapForMultiGrpAction(String action,List<String> inquiryGroupMap, boolean isMultiGroupAction)
	{
		Map<Long, String> inquiryGroupIdMap = new HashMap<Long, String>();
		if (isMultiGroupAction)
		{

			for (String inquiryGroupMapping : inquiryGroupMap)
			{
				if (!StringUtils.isBlank(inquiryGroupMapping))
				{
					String[] mapping = inquiryGroupMapping.split(":");
					if (!StringUtils.isBlank(mapping[0]) && mapping.length > 1)
						inquiryGroupIdMap.put(Long.valueOf(mapping[0]), mapping[1]);
				}
			}
		}
		return inquiryGroupIdMap;
	}

	private Map<Long, ActionStatistics> populateInquiryInfoMap(List<BasicDBObject> dbObjs, String action, String actionDetails)
	{
		Map<Long, ActionStatistics> inquiryRequestTypeMap = new HashMap<Long, ActionStatistics>();
		try{

			if(null!=dbObjs)
			{
				for (BasicDBObject dbObj : dbObjs)
				{
					Long inquiryId = GenericUtility.getIdFromRequest(dbObj, INQUIRY_ID);
					String requestType = dbObj.getString(REQUEST_TYPE);
					Long groupId = GenericUtility.getIdFromRequest(dbObj, GROUP_ID);

					if(null!=inquiryId && null!=groupId)
					{
						ActionStatistics stats = new ActionStatistics();
						stats.setInquiryId(inquiryId);
						stats.setRequestType(requestType);
						stats.setGroupId(groupId);

						if(ACTION_ASSIGN_INQUIRY_SOURCE.equalsIgnoreCase(action))
							stats.setInquirySource(actionDetails);
						else if(PROCESSING_REGION.equalsIgnoreCase(action))
							stats.setProcessingRegion(actionDetails);
						else if(TAG.equalsIgnoreCase(action))
							stats.setTag(actionDetails);	
						else if(ACTION_ASSIGN_INQUIRY_SUB_STATUS.equalsIgnoreCase(action))
							stats.setInquirySubStatus(actionDetails);

						inquiryRequestTypeMap.put(inquiryId+groupId, stats);
					}
				}
			}
		}catch(CommunicatorException e)
		{
			subLogger.info(" Error populating populateInquiryRequestTypeMap:");
		}
		return inquiryRequestTypeMap;
	}

	// [C153176-884] - Add GFCID Field and GFCID/GFPID Pop-up to Context Menu
	public boolean assignGfpidGfcid(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException
	{
		boolean bSuccess = false;

		try
		{
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			String gfpid = inputJsonObj.getString("gfpid");
			String gfcid = inputJsonObj.getString(GFC_ID);
			String gfpidName = inputJsonObj.getString("gfpidName");
			String gfcidName = inputJsonObj.getString("gfcidName");
			
			boolean isMultiGroupAction = inputJsonObj.getBoolean(IS_MULTI_GROUP_ACTION_KEY);
			String commonGroupId = inputJsonObj.getString(COMMON_GROUP_ID_KEY);

			if (inquiryIds.size() != groupIds.size())
			{
				subLogger.info("Invalid Input for assignGfpidGfcid - GFPID/GFCID" + gfpid + "/" + gfcid + " by " + soeId + ". InquiryIdList size and groupIdList size do not match.");
				throw new CommunicatorException("InquiryIdList size - [" + inquiryIds.size() + "] and groupIdList size - [" + groupIds.size() + "] do not match for assignGfpidGfcid.");
			}
			if (StringUtils.isBlank(gfpid) || StringUtils.isBlank(gfcid))
			{
				subLogger.info("Invalid Input for assignGfpidGfcid - GFPID/GFCID" + gfpid + "/" + gfcid + " by " + soeId);
				throw new CommunicatorException("Invalid GFPID/GFCID for assignGfpidGfcid.");
			}
			
			// C170665-5 | Sk Account Number and Branch which getting populated from AMCAR
			String skAccountNo = null != inputJsonObj.get("skAccountNo") ? inputJsonObj.getString("skAccountNo") : null;
			String branch = null != inputJsonObj.get("branch") ? inputJsonObj.getString("branch") : null;
		
			List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);
			Map<Long, String> inquiryGroupIdMap = new HashMap<Long, String>();

			if (isMultiGroupAction)
			{
				subLogger.info("assignGfpidGfcid for Inquiries with isMultiGroupAction=true");
				for (String inquiryGroupMapping : groupIds)
				{
					if (!StringUtils.isBlank(inquiryGroupMapping))
					{
						String[] mapping = inquiryGroupMapping.split(":");
						if (!StringUtils.isBlank(mapping[0]) && mapping.length > 1)
							inquiryGroupIdMap.put(Long.valueOf(mapping[0]), mapping[1]);
					}
				}
			}
			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfoMap =  populateInquiryInfoMap(dbObjs,null,null);

			bSuccess = bulkAssignGfpidGfcid(soeId, gfpid, gfpidName, gfcid, gfcidName, inquiryObjects, isMultiGroupAction, inquiryGroupIdMap, commonGroupId,inquiryInfoMap, skAccountNo, branch);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in assignGfpidGfcid for user= " + soeId, e);
			throw new CommunicatorException("Exception in assignGfpidGfcid for user= " + soeId, e);
		}

		return bSuccess;
	}

	public boolean reOpenInquiry(String soeId, BasicDBObject inputJsonObj, UserActivities userActivity) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			List<String> fromGroupNameList = (List<String>) inputJsonObj.get(FROM);
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			Map<Long, List<Long>> inquiryGroupMap=  populateInquiryGroupListMap((List<String>) inputJsonObj.get("allInqGroupIds"));
			String actionDetails = inputJsonObj.getString("actionDetail");

			if (fromGroupNameList == null || fromGroupNameList.isEmpty())
			{
				subLogger.info("Invalid Group " + " for reOpen action");
				return false;
			}
			//C153176-1449 added one more parameter ACTION_REOPEN
			reOpenInquiryList(soeId, fromGroupNameList, inquiryIds,ACTION_REOPEN, inquiryGroupMap, userActivity,actionDetails);

		}
		catch (Exception e)
		{
			subLogger.error("Exception in reOpenInquiry for user= " + soeId, e);
			throw new CommunicatorException("Exception in reOpenInquiry for user= " + soeId, e);
		}
		return Boolean.TRUE;
	}

	// C153176-427 Ability to take all actions from Resolved Box
	private void reOpenInquiryList(String soeId, List<String> fromGroupNameList, List<Long> inquiryIds, String inquiryActionOnUI, Map<Long, List<Long>> inquiryGroupMap, UserActivities userActivity,String actionDetials )
			throws CommunicatorException
	{
		List<Inquiry> inquiryObjs = getInquiryList(inquiryIds);

		Set<Long> fromGrpIds = new HashSet<Long>();
		QMACache qmaCache = QMACacheFactory.getCache();
		Map<String, Long> groupCodeToIdMap = qmaCache.getGroupCodeToIdMap();
		for (String fromGroupName : fromGroupNameList)
		{
			Long fromGroupId = groupCodeToIdMap.get(fromGroupName.toUpperCase());
			fromGrpIds.add(fromGroupId);
		}
		
		// C153176-1449 - Added one more parameter 
		//List<Inquiry> resolveInquiryList = changeStatus(inquiryObjs, soeId, fromGrpIds, null, null, null, ACTION_REOPEN, null, null, null, null, "Y",inquiryActionOnUI);//C153176-875 
		List<Inquiry> resolveInquiryList = changeStatus_reopen(inquiryObjs, soeId, fromGrpIds,  ACTION_REOPEN,inquiryActionOnUI, inquiryGroupMap, actionDetials);

		if (null != resolveInquiryList)
		{
			userActivity.setResponseTimeInMills(System.currentTimeMillis());
			userNotificationDAO.updateUserNotification(inquiryIds, ACTION_REOPEN, soeId,userNotificationType, userActivity);
			saveInquiriesToPublish(inquiryIds, ACTION_REOPEN, soeId);
			
			for (Inquiry inq : resolveInquiryList)
			{
				// Always fetch latest conversation.
				List<Conversation> convList = getAllConversations(inq.getId(), null, 1, false);
				if (null != convList && !convList.isEmpty())
				{
					GenericUtility.postInquiryDetailsToCSL(inq, convList.get(0), null);
				}
				else
				{
					// No conversation found hence passing null object.
					GenericUtility.postInquiryDetailsToCSL(inq, null, null);
				}

			}
		}
	}

	// C153176-427 Ability to take all actions from Resolved Box
	public Response reOpenResolvedInquiry(String request, List<Long> inquiryIds, String soeId, UserActivities userActivity) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a
	// generic one
	{
		long startTime = System.currentTimeMillis();
		BasicDBObject inputJsonObj = BasicDBObject.parse(request);
		subLogger.info("Inside InquiryRestServiceImpl.reOpenResolvedInquiry for UserId- {}", soeId);
		String inquiryAction = AppserverConstants.REOPEN_INQUIRY;
		String actionDetails = "InquiryId : " + inquiryIds.toString();
		userActivity.setActionType(inquiryAction);
		userActivity.setDescription(actionDetails);
		user_Activities_Dao.saveUserActivities(soeId, userActivity, System.currentTimeMillis() - startTime);
		boolean success = reOpenResolvedInquiry(soeId, inputJsonObj, userActivity);
		return DataConversionUtil.sendJsonResponseForBoolean(success);
	}

	// C153176-427 Ability to take all actions from Resolved Box
	public boolean reOpenResolvedInquiry(String soeId, BasicDBObject inputJsonObj, UserActivities userActivity) throws CommunicatorException
	{
		try
		{
			String from = (String) inputJsonObj.get(FROM);
			List<String> fromList = new ArrayList<String>();
			fromList.add(from);
			Object inqId = inputJsonObj.get(INQUIRY_ID);

			Long inquiryId;
			List<Long> inquiryList = new ArrayList<>();
			inquiryId = GenericUtility.convertIdFromRequest(inqId);
			if (inquiryId != null)
			{
				inquiryList.add(inquiryId);
			}
			if (fromList == null || fromList.isEmpty())
			{
				subLogger.info("Invalid Group " + " for reOpen action");
				return false;
			}
			//C153176-1449
			// inquiryActionFromUI will have Reply,ReplyAll,Forword, ReplyAllResolve,ReplyResolve if the reopen is called for a resolved inquiry from resolved box in UI.
			//So- No Stats will be saved for internal reOpen happened due to reply action.
			String inquiryActionOnUI = inputJsonObj.getString("inquiryAction");
			reOpenInquiryList(soeId, fromList, inquiryList,inquiryActionOnUI, null, userActivity,"");

		}
		catch (Exception e)
		{
			subLogger.error("Exception in reOpenInquiry for user= " + soeId, e);
			throw new CommunicatorException("Exception in reOpenResolvedInquiry for user= " + soeId, e);
		}
		return Boolean.TRUE;
	}

	// This is used to move inquiry to Group tag
	public boolean moveInquiryToTag(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		boolean bSucess = Boolean.FALSE;
		// UpdateOperations<Inquiry> ops = null;
		// Query<Inquiry> filterQuery = null;
		Group group = null;
		List<Long> inquiryIds = null;

		try
		{
			String tagName = inputJsonObj.getString("folderName");
			inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj,
					INQUIRY_IDS);
			String groupName = inputJsonObj.getString(GROUP_NAME);
			List<Inquiry> inquiryObjs = getInquiryList(inquiryIds);

			if (StringUtils.isBlank(groupName))
			{
				subLogger.info("Incorrect group data entered");
				throw new CommunicatorException("Incorrect group data entered for the method InquiryDAO.moveInquiryToTag");
			}
			else if (QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase()) == null)// Sonar Fix -- remove useless parenthesis
			{
				subLogger.info("Active group not found in cache for groupName - {}" + groupName);
				// throw new CommunicatorException("Group entered is inactive for the method InquiryDAO.moveInquiryToTag");
			}
			else
			{

				group = mongoDatastore.createQuery(Group.class).filter(GROUP_NAME, groupName).get();
				// Prepare Update Operations
				// ops = mongoDatastore.createUpdateOperations(Inquiry.class);

				DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
				BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();
				Date currentTime = new Date();
				String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
				//Request type, Subject, Assigned user - C153176-1054
				DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
				BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();
				boolean isBulkAction= inquiryObjs != null && inquiryObjs.size() > 1 ;
				List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
				Map<Long, ActionStatistics> inquiryInfoMap =  populateInquiryInfoMap(dbObjs,TAG,tagName);
				Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
				Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
				for (Inquiry inqObj : inquiryObjs)
				{
					DBObject inquiryUpdateDBObj = new BasicDBObject();
					if (!StringUtils.isBlank(tagName))
						inquiryUpdateDBObj.put("workflows.$.tag", tagName);
					inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
					inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
					inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_ASSIGN_TAG);

					DBObject updateDBFields = new BasicDBObject();
					updateDBFields.put("$set", inquiryUpdateDBObj);

					DBObject findINQuery = new BasicDBObject();
					findINQuery.put("_id", inqObj.id);

					DBObject findOUTQuery = new BasicDBObject();
					findOUTQuery.put("_id", inqObj.id);

					DBObject findPAQuery = new BasicDBObject();
					findPAQuery.put("_id", inqObj.id);

					DBObject workflowAudit = createWorkFlowsAuditJavaDriver(group.id, ACTION_ASSIGN_TAG, tagName, soeId, currentTime, groupIdToNameMap, userInfoMap);

					workflowAudit.put(INQUIRY_ID, inqObj.id);
					workflowAudit.put(GROUP_ID, group.id);

					// Create new Audit for the action Assign Tag
					DBObject updateWorkAuditFields = new BasicDBObject();
					updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));

					BasicDBObject workflowCriteria = new BasicDBObject();
					workflowCriteria.put(ASSIGNED_GROUPID, group.id);
					workflowCriteria.put(DIRECTION, INQUIRY_DIRECTION_IN);

					BasicDBObject workflowCriteriaOUT = new BasicDBObject();
					workflowCriteriaOUT.put(ASSIGNED_GROUPID, group.id);
					workflowCriteriaOUT.put(DIRECTION, INQUIRY_DIRECTION_OUT);

					BasicDBObject workflowCriteriaPA = new BasicDBObject();
					workflowCriteriaPA.put(ASSIGNED_GROUPID, group.id);
					workflowCriteriaPA.put(DIRECTION, INQUIRY_DIRECTION_PENDING_APPROVAL);

					findPAQuery.put(WORKFLOWS, new BasicDBObject("$elemMatch", workflowCriteriaPA));
					findOUTQuery.put(WORKFLOWS, new BasicDBObject("$elemMatch", workflowCriteriaOUT));
					findINQuery.put(WORKFLOWS, new BasicDBObject("$elemMatch", workflowCriteria));
					// C153176-368-Resolved Inquiry Cannot be found with OUT version
					DBObject findWorkAuditflowQuery = prepareFindQuery(inqObj.id, group.id, STATUS_OPEN, INQUIRY_DIRECTION_IN_OR_OUT, false);

					bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);
					bulkInquiryUpdOp.find(findOUTQuery).update(updateDBFields);
					bulkInquiryUpdOp.find(findPAQuery).update(updateDBFields);

					bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);

					//Modified for requestType in Action Statistics - C153176-1155
					//DBObject stats = getStatsObject(soeId, ACTION_ASSIGN_TAG, currentTime, inqObj, group.id, inquiryObjs);
					ActionStatistics statsObj = inquiryInfoMap.get(inqObj.id+group.id);						
					DBObject stats = getStatsObject(soeId, ACTION_ASSIGN_TAG, currentTime, inqObj, group.id, isBulkAction, statsObj, groupIdToNameMap, userInfoMap);
					bulkStatsInsertdOp.insert(stats);

					subLogger.info("ActionStatistics Saved for action 3" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));

				}
				if (!inquiryObjs.isEmpty())
				{
					bulkInquiryUpdOp.execute();
					bulkStatsInsertdOp.execute();
				}

				bSucess = Boolean.TRUE;
			}

		}
		catch (Exception e)
		{
			subLogger.error("Exception in moveInquiryToTag for user= " + soeId, e);
			throw new CommunicatorException("Exception in moveInquiryToTag for user= " + soeId, e);
		}
		return bSucess;
	}

	// C153176-875
	public Boolean lockUnlockInquiry(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException
	{
		boolean bSucess = Boolean.FALSE;
		List<Long> inquiryIds = null;
		try
		{
			if (inputJsonObj == null || StringUtils.isBlank(inputJsonObj.getString("action")))
			{
				subLogger.error("No Lock/UnLock Action received for user={}", soeId);
				throw new CommunicatorException("Exception in getting the Lock Unlock action for user= " + soeId);
			}
			String lockUnlockAction = inputJsonObj.getString("action");
			String lockFlag = ACTION_LOCK.equalsIgnoreCase(lockUnlockAction) ? STRING_YES : "N";
			inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj,INQUIRY_IDS);
			List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);

			if (inquiryObjects == null || inquiryObjects.isEmpty())
			{
				subLogger.error("No Inquiries received for user=" + soeId + "as the inquiryObjs is null or empty " + inquiryObjects); // <-- sonar fix null pointer
				throw new CommunicatorException("Exception in getting the inquiries for user= " + soeId);
			}
			List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			boolean isMultiGroupAction = inputJsonObj.getBoolean(IS_MULTI_GROUP_ACTION_KEY);
			String commonGroupId = inputJsonObj.getString(COMMON_GROUP_ID_KEY);
			if (inquiryIds.size() != groupIds.size())
			{
				subLogger.info("Invalid Input for Lock/UnLock action -" +  " by " + soeId + ". InquiryIdList size and groupIdList size do not match.");
				throw new CommunicatorException("InquiryIdList size - [" + inquiryIds.size() + "] and groupIdList size - [" + groupIds.size() + "] do not match for Lock/UnLock.");
			}

			Map<Long, String> inquiryGroupIdMap =populateInquiryGrpMapForMultiGrpAction(lockUnlockAction, groupIds, isMultiGroupAction);
			Date currentTime = new Date();

			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, lockUnlockAction);

			DBObject inquiryUnsetDBObj=null;
			String userName = "";
			if (STRING_YES.equalsIgnoreCase(lockFlag))
			{
				userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
				inquiryUpdateDBObj.put("workflows.$.lock", lockFlag);
				inquiryUpdateDBObj.put(WORKFLOWS_LOCKED_BY, userName);
				inquiryUpdateDBObj.put(WORKFLOWS_LOCKED_TIME, currentTime);
				inquiryUpdateDBObj.put(WORKFLOWS_ACTION, lockUnlockAction);
			}
			else
			{
				inquiryUpdateDBObj.put(WORKFLOWS_ACTION, lockUnlockAction);
				inquiryUnsetDBObj = new BasicDBObject(WORKFLOWS_LOCKED_BY, "");
				inquiryUnsetDBObj.put(WORKFLOWS_LOCKED_TIME, "");
				inquiryUnsetDBObj.put("workflows.$.lock", "");
			}

			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfoMap =  populateInquiryInfoMap(dbObjs,null,null);

			bSucess = bulkMultiGroupAction(soeId, inquiryObjects, isMultiGroupAction, inquiryGroupIdMap, commonGroupId,lockUnlockAction,inquiryUpdateDBObj,inquiryUnsetDBObj, inquiryInfoMap);
			
		}
		catch (Exception e)
		{
			subLogger.error("Exception in lockingInquiry for user= " + soeId, e);
			throw new CommunicatorException("Exception in lockingInquiry for user= " + soeId, e);
		}
		return bSucess;
	}
	
	/**
	 * @param soeId
	 * @param inputJsonObj
	 * @param servletRequest 
	 * @return
	 * @throws CommunicatorException
	 * This method is responsible for Take Ownership functionality.
	 * When user take ownership, only the requested workflow will stay in the inbox and rest other workflows will be moved to resolve box 
	 * and will not display in Inbox
	 */
	public boolean takeOwnership(String soeId, BasicDBObject inputJsonObj, UserActivities userActivity) throws CommunicatorException
	{
		boolean successFlag = Boolean.FALSE;
		String action = inputJsonObj.getString("action");
		List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
		successFlag = takeOwnershipBulkAction(soeId, action, inputJsonObj, userActivity);
		
		return successFlag;
	}
	

	/**
	 * @param workflowList
	 * @param inquiryObj
	 * @param inquiryCollection
	 * @param groupId
	 * @param soeId
	 * @param currentTime
	 * @return
	 */
	public boolean takeOwnershipBulkAction( String soeId, String action, BasicDBObject inputJsonObj, UserActivities userActivity) throws CommunicatorException{
		Date currentTime = new Date();
		List <Workflow> workflowList = null;
		List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
		String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
		DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
		BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();
		Map<Long, Long> inquiryGroupMap=  populateInquiryGrpMap(((List<String>) inputJsonObj.get(GROUP_IDS_KEY)));
		for (Long inqId: inquiryIds)
		{
			Inquiry inquiryObj = getInquiryById(inqId);
			Long groupId = inquiryGroupMap.get(inqId);
		if (null != inquiryObj){
			 workflowList = new ArrayList<>();
		}
		workflowList = (null == inquiryObj ? workflowList : inquiryObj.getWorkflows()); // <-- sonar fix null pointer
		for (Workflow workflow : workflowList)
		{
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, ACTION_TAKE_OWNERSHIP);
			if ((null!= workflow.getAssignedGroupId()) && workflow.getAssignedGroupId().equals(groupId))
			{
				inquiryUpdateDBObj.put(WORKFLOWS_OWNERSHIP, "Y");
				inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_TAKE_OWNERSHIP);
			}
			else
			{
				inquiryUpdateDBObj.put(WORKFLOWS_STATUS, RESOLVED);
				inquiryUpdateDBObj.put(WORKFLOWS_REQUEST_TYPE, "FYI");
				inquiryUpdateDBObj.put(WORKFLOWS_RESOLVED_BY_OTHER_GROUP, "Y");
				inquiryUpdateDBObj.put(WORKFLOWS_ACTION, RESOLVE_ACTION_TAKE_OWNERSHIP);
			}
			bulkWorkflowUpdateOperation(inquiryObj, inquiryUpdateDBObj, userName, currentTime, workflow.getAssignedGroupId(), bulkInquiryUpdOp);
		}
		iInquiryActionStat.bulkUpdateInquiryActionStats(inquiryObj, ACTION_TAKE_OWNERSHIP, currentTime,  new HashSet<>(Arrays. asList(groupId)));
		updateAuditForTakeOwnershipAction(groupId, action, soeId, currentTime,inquiryObj, inputJsonObj);
		}
		bulkInquiryUpdOp.execute();
		return true;
	}
	
	
	/**
	 * @param inquiryGroupMap
	 * @return
	 * Create a Map contains inquiryId and GroupId
	 */
	public Map<Long, Long> populateInquiryGrpMap(List<String> inquiryGroupMap)
	{
		 Map<Long, Long> inquiryGroupIdMap= inquiryGroupMap.stream().map(inquiryGroup -> inquiryGroup.split(":"))
			        .collect(Collectors.toMap(inq -> Long.valueOf(inq[0]), grp ->Long.valueOf(grp[1])));
		return inquiryGroupIdMap;
	}
	
	
	/**
	 * @param inquiryGroupMap
	 * @return
	 * Create a Map contains inquiryId and GroupIdList
	 */
	public Map<Long, List<Long>> populateInquiryGroupListMap(List<String> inquiryGroupMap)
	{	
		 Map<Long, List<Long>> inquiryGroupIdMap= inquiryGroupMap.stream().map(inquiryGroup -> inquiryGroup.split(":"))
			        .collect(Collectors.toMap(inquiry -> Long.valueOf(inquiry[0]), groupIdStr ->populateGroupList(groupIdStr[1])));
		return inquiryGroupIdMap;
	}
	
	/**
	 * @param groupIdStr
	 * @return
	 * Group Array to group List conversion  
	 */
	public List<Long> populateGroupList(String groupIdStr)
	{
		String[] groupListStr = groupIdStr.split("\\s*,\\s*");
	    List<Long> groupList =Arrays.asList(groupListStr).stream().map(Long::valueOf).collect(Collectors.toList());
		return groupList;
	}
	
	
	/**
	 * @param inquiryCollection
	 * @param inquiryUpdateDBObj
	 * @param findINWorkflowQuery
	 * @param userName
	 * @param currentTime
	 * Execute the update query
	 */
	public void bulkWorkflowUpdateOperation(Inquiry inquiryObj, DBObject inquiryUpdateDBObj,
			String userName, Date currentTime, Long groupId, BulkWriteOperation bulkInquiryUpdOp) throws CommunicatorException{
		
		DBObject findINWorkflowQuery = prepareFindQuery(inquiryObj.id, groupId, STATUS_OPEN, INQUIRY_DIRECTION_IN, true);
		DBObject findOutWorkflowQuery = prepareFindQuery(inquiryObj.id,groupId, STATUS_OPEN, INQUIRY_DIRECTION_OUT, true);
		inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
		inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
		DBObject updateDBFields = new BasicDBObject();
		updateDBFields.put("$set", inquiryUpdateDBObj);
		bulkInquiryUpdOp.find(findINWorkflowQuery).update(updateDBFields);
		bulkInquiryUpdOp.find(findOutWorkflowQuery).update(updateDBFields);
	}
	
	
	public void updateAuditForTakeOwnershipAction(Long groupId, String action, String soeId, Date currentTime,
			Inquiry inquiryObj, BasicDBObject inputJsonObj) throws CommunicatorException{
		DBObject workflowAudit;
		DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
		BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();
		Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
		Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
		workflowAudit = createWorkFlowsAuditJavaDriver(groupId, action, ACTION_TAKE_OWNERSHIP, soeId, currentTime, groupIdToNameMap, userInfoMap);
		workflowAudit.put(INQUIRY_ID, inquiryObj.id);
		workflowAudit.put(GROUP_ID, groupId);
		workflowAudit.put(ACTION, action);
		DBObject updateWorkAuditFields = new BasicDBObject();
		updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));
		DBObject findWorkAuditflowQuery = prepareFindQuery(inquiryObj.id, groupId, STATUS_OPEN, INQUIRY_DIRECTION_IN_OR_OUT, false);
		bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);
		bulkInquiryUpdOp.execute();
		
		DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
		BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();
		List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
		Map<Long, ActionStatistics> inquiryInfoMap =  populateInquiryInfoMap(dbObjs,null,null);
		ActionStatistics statsObj = inquiryInfoMap.get( inquiryObj.id+groupId);
		DBObject stats = getStatsObject(soeId, ACTION_TAKE_OWNERSHIP, currentTime, inquiryObj, groupId, false, statsObj, groupIdToNameMap, userInfoMap);
		bulkStatsInsertdOp.insert(stats);
		bulkStatsInsertdOp.execute();
	}
	
	

	public boolean addNoteToInquiry(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		boolean bSucess = Boolean.FALSE;
		UpdateOperations<Inquiry> ops = null;
		Query<Inquiry> updateQuery = null;
		List<Long> inquiryIds = null;
		try
		{
			String userNote = inputJsonObj.getString("userNote");
			inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			if (StringUtils.isEmpty(userNote) || inquiryIds == null || inquiryIds.isEmpty())
			{
				subLogger.info("addNoteToInquiry-Invalid Request -Operation Failed");
				return bSucess;
			}
			User loginUser = getUser(soeId);
			if (loginUser == null)
			{
				subLogger.info("User Details are not Found. Please contact Support for UserId-" + soeId);
				throw new CommunicatorException(" User Details not Found.");
			}
			// Prepare Update Operations
			ops = mongoDatastore.createUpdateOperations(Inquiry.class);
			Note note = new Note(soeId, loginUser.getName(), new Date(), userNote);
			subLogger.info("soeId-" + soeId + "name" + loginUser.getName() + ", comment=" + userNote);
			List<Inquiry> inquiryObjs = getInquiryList(inquiryIds);
			for (Inquiry inqObj : inquiryObjs)
			{
				updateQuery = mongoDatastore.createQuery(Inquiry.class);
				updateQuery.filter("_id", inqObj.id);
				ops.set(MODIFIED_BY, soeId);
				ops.set(MODIFIED_DATE, new Date());
				if (inqObj.getUserNotes() != null && !inqObj.getUserNotes().isEmpty())
				{
					inqObj.getUserNotes().add(note);
					ops.set("userNotes", inqObj.getUserNotes());
				}
				else
				{
					List<Note> noteList = new ArrayList<>();
					noteList.add(note);
					ops.set("userNotes", noteList);
				}
				ops.set("notesFlag", "Y");
				mongoDatastore.update(updateQuery, ops);
			}
			bSucess = Boolean.TRUE;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in addNoteToInquiry for user= " + soeId, e);
			throw new CommunicatorException("Exception in addNoteToInquiry for user= " + soeId, e);
		}
		return bSucess;
	}

	// Method to save or update draft from UI
	public DraftTO saveDraft(BasicDBObject inputJsonObj, String content, String soeId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic
	// one//Sonar Fix -- remove useless parameter
	{

		String action = null;
		Long inquiryId = null;
		Long draftId = null;
		DraftTO draftReponse = null;
		boolean saveFlag = false;
		try
		{
			Inquiry dbInquiry = null;
			Draft draftRecord = null;

			// Read request
			inquiryId = GenericUtility.getIdFromRequest(inputJsonObj, INQUIRY_ID);
			draftId = GenericUtility.getIdFromRequest(inputJsonObj, "draftId");

			Date currentTime = new Date();

			// Validate Draft
			if (draftId == null)
			{
				saveFlag = true;
			}
			else
			{
				// Validate draftId from UI with DB
				draftRecord = getDraft(draftId);

				if (draftRecord == null)
				{
					subLogger.error("No Valid Draft found for draftId= " + draftId);
					saveFlag = true;
				}
			}

			// Validate Inquiry--InquiryId will always be null in 'New Inquiry draft flow'

			if (inquiryId != null)
			{
				
				dbInquiry = getInquiryById(inquiryId);
				if (dbInquiry == null)
				{
					subLogger.info("Invalid InquiryId sent for saveDraft-action-" + action + " for Id=" + inquiryId + " by " + soeId);
				}

			}

			if (saveFlag)
			{
				// Create New Draft
				draftRecord = createNewDraft(inputJsonObj, content, soeId, currentTime);
			}
			else
			{
				// update DB Draft
				// va fix to validate ownership
				if (!soeId.equalsIgnoreCase(draftRecord.getUserId()))
				{
					subLogger.error("No entitlemnt to user to edit draftId:{}", draftId);
					throw new CommunicatorException("No entitlemnt to user to edit draftId= %s".formatted(draftId));
				} else {
					updateDraftAttributesFromUi(inputJsonObj, draftRecord, content, soeId, currentTime);					
				}

			}

			// Persist the draft// in case of save and update both.
			if (draftRecord != null)
			{
				persist(draftRecord);
			}

			subLogger.info("saveDraft successfull " + "-DRAFT ID:" + draftRecord.getId());
			// response = String.valueOf(draftRecord.getId());
			// draftRecord.content=null;
			draftReponse = new DraftTO(draftRecord);

			// Update User's Editor preferences if required
			if (inputJsonObj.getBoolean("isUserEditorPrefUpdated"))
			{
				userDao.saveUserEditorPreferences(soeId, inputJsonObj);
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in saveDraft for user= " + soeId, e);
			throw new CommunicatorException("Exception in saveDraft for user= " + soeId, e);
		}
		return draftReponse;
	}


	public DraftTO getDraftById(Long draftId, String soeId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one

	{
		if (draftId == null)
		{
			subLogger.error("Invalid input getDraftById for draftId= " + draftId);
			throw new CommunicatorException("Invalid input getDraftById for draftId= " + draftId);
		}
		try
		{

			Draft draft = getDraft(draftId);
			draft.setContent(InquiryUtil.replaceBaseTag(GenericUtility.checkAndFetchConvContent(draft)));
			// Only conversation details required hence creating conversationTO by only passing conversation list.
			DraftTO draftsTO = new DraftTO(draft);

			return draftsTO;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getDraftById for draftId= " + draftId, e);
			throw new CommunicatorException("Exception in getDraftById for draftId=" + draftId, e);
		}
	}

	// Method to deleteDraft with draftId as parameter
	public Boolean deleteDraftById(String soeId, List<Long> draftIdList) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{

		if (draftIdList == null)
		{
			subLogger.error("Invalid input deleteDraftById for draftId= " + draftIdList);
			throw new CommunicatorException("Invalid input deleteDraftById for draftId= " + draftIdList);
		}
		try
		{
			// va issue fix
	        List<Long> elegibleDraftIdList = new ArrayList<Long>();
	        draftIdList.forEach(draftId->{
	        	try {
	        	Draft draft = getDraft(draftId);
	        	if (draft != null)
				{
	        		elegibleDraftIdList.add(draftId);
				}
	        	}
	        	catch (Exception e)
	    		{
	    			subLogger.error(DELETE_DRAFT_ERROR_MSG + draftIdList.toString(), e);
	    		}
	        	
	        });
			BasicDBObject delCriteria = new BasicDBObject();
			delCriteria.put("_id", new BasicDBObject("$in", elegibleDraftIdList));

			mongoDatastore.getCollection(Draft.class).remove(delCriteria);

		}
		catch (Exception e)
		{
			subLogger.error(DELETE_DRAFT_ERROR_MSG + draftIdList.toString(), e);
			throw new CommunicatorException(DELETE_DRAFT_ERROR_MSG + draftIdList.toString(), e);
		}

		return true;
	}

	// C153176-875
	/*
	 * @ param soeId
	 * @ param inputJsonObj
	 * @ return true/false
	 * @ throws CommunicatorException
	 * Method for saving inquiry with follow up flag, which will make it eligible appear in follow up box. 
	 */
	public Boolean followUpInquiry(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException
	{
		boolean bSucess = Boolean.FALSE;
		List<Long> inquiryIds = null;
		try
		{
			if (inputJsonObj == null || StringUtils.isBlank(inputJsonObj.getString("action")))
			{
				subLogger.error("No FollowUp/RemoveFollowUp Action received for user=" + soeId + "as the inputJsonObj" + inputJsonObj);
				throw new CommunicatorException("Exception in getting the FollowUp RemoveFollowUp action for user= " + soeId);
			}
			DBObject followUpObj = (DBObject) inputJsonObj.get("followUp");
			String followUpAction = inputJsonObj.getString("action");
			inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);

			if (inquiryObjects == null || inquiryObjects.isEmpty())
			{
				subLogger.error("No Inquiries received for user={}as the inquiryObjs is null or empty {} ",soeId, inquiryObjects); //<-- sonar fix null pointer
				throw new CommunicatorException("Exception in getting the inquiries for user= " + soeId);
			}
			List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			boolean isMultiGroupAction = inputJsonObj.getBoolean(IS_MULTI_GROUP_ACTION_KEY);
			String commonGroupId = inputJsonObj.getString(COMMON_GROUP_ID_KEY);
			if (inquiryIds.size() != groupIds.size())
			{
				subLogger.info("Invalid Input for FollowUp/RemoveFollowUp action -" + " by " + soeId + ". InquiryIdList size and groupIdList size do not match.");
				throw new CommunicatorException("InquiryIdList size - [" + inquiryIds.size() + "] and groupIdList size - [" + groupIds.size() + "] do not match for FollowUp/RemoveFollowUp.");
			}

			Map<Long, String> inquiryGroupIdMap = populateInquiryGrpMapForMultiGrpAction(followUpAction,  groupIds, isMultiGroupAction);
			Date currentTime = new Date();

			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, followUpAction);

			DBObject inquiryUnsetDBObj = null;
			if (null != followUpObj)
			{
				inquiryUpdateDBObj.put(WORKFLOWS_$_FOLLOW_UP, followUpObj);
				inquiryUpdateDBObj.put(WORKFLOWS_ACTION, followUpAction);
			}
			else
			{
				inquiryUpdateDBObj.put(WORKFLOWS_ACTION, followUpAction);
				inquiryUnsetDBObj = new BasicDBObject(WORKFLOWS_$_FOLLOW_UP, "");
			}

			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfoMap =  populateInquiryInfoMap(dbObjs,null,null);

			bSucess = bulkMultiGroupAction(soeId, inquiryObjects, isMultiGroupAction, inquiryGroupIdMap, commonGroupId, followUpAction, inquiryUpdateDBObj, inquiryUnsetDBObj, inquiryInfoMap);
			
		}
		catch (Exception e)
		{
			subLogger.error("Exception in lockingInquiry for user= " + soeId, e);
			throw new CommunicatorException("Exception in lockingInquiry for user= " + soeId, e);
		}
		return bSucess;
	}


	public boolean prepareUnassignInquiry(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		boolean bSuccess = Boolean.FALSE;
		Map<Long, Boolean> inquiryIsRefSentMap = new HashMap<Long, Boolean>();
		try
		{
			String assignUserId = inputJsonObj.getString(ASSIGN_TO_USER_ID);
			String inquiryAction = inputJsonObj.getString("inquiryAction");
			subLogger.info("In InquiryDao.assignToOwner --> input=" + assignUserId);
			if (StringUtils.isEmpty(inquiryAction))
			{
				subLogger.info("Invalid Input for unAssignInquiry -" + assignUserId + " by " + soeId);
				throw new CommunicatorException("Invalid Data for unAssignInquiry.");
			}
			// begin
			Set<Long> assignToGroupIds = new HashSet<>();
			String groupName = inputJsonObj.getString(GROUP_NAME);

			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfoMap = populateInquiryInfoMap(dbObjs, null, null);
			Long groupId;
			// Get Inquiry id's from input json object.
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			// GroupName null check
			if (!StringUtils.isBlank(groupName))
			{
				groupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
				if (groupId == null)
				{
					subLogger.info("Active group not found in cache for groupName - {}" + groupName);
				}
				else
				{
					bSuccess = unAssignInquiry(soeId, inquiryIsRefSentMap, assignToGroupIds, inquiryInfoMap, groupId, inquiryIds, inputJsonObj);
				}
			}
			else
			{
				subLogger.info("Invalid Input for assignToOwner -" + assignUserId + " by " + soeId + " for group name " + groupName);
				throw new CommunicatorException("Invalid Data for groupName.");
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in assignToOwner for user= " + soeId, e);
			throw new CommunicatorException("Exception in assignToOwner for user= " + soeId, e);
		}

		return bSuccess;
	}

	private boolean unAssignInquiry(String soeId, Map<Long, Boolean> inquiryIsRefSentMap, Set<Long> assignToGroupIds, Map<Long, ActionStatistics> inquiryInfoMap, Long groupId, List<Long> inquiryIds, BasicDBObject inputJsonObj) throws CommunicatorException
	{
		boolean bSuccess = false;
		String assignUserId = inputJsonObj.getString(ASSIGN_TO_USER_ID);
		String inquiryAction = inputJsonObj.getString("inquiryAction");
		String groupName = inputJsonObj.getString(GROUP_NAME);
		List<Inquiry> inquiryObjects;
		assignToGroupIds.add(groupId);
		// end
		inquiryObjects = getInquiryList(inquiryIds);
		if (inquiryObjects != null)
		{
			for (Inquiry inquiry : inquiryObjects)
			{
				boolean isInquiryRefSent = isInquiryRefSent(inquiry, groupId);
				inquiryIsRefSentMap.put(inquiry.getId(), isInquiryRefSent);
			}
		}
		if (null != inquiryAction && AppserverConstants.ACTION_UNASSIGN_OWNER.equals(inquiryAction))
		{
			bSuccess = bulkUnassignOwner(soeId, groupName, assignToGroupIds, assignUserId, inquiryObjects, inquiryInfoMap, inquiryAction);
		}
		else if (null != inquiryAction && AppserverConstants.ACTION_UNASSIGN_TAG.equals(inquiryAction))
		{
			bSuccess = bulkUnassignTag(soeId, assignToGroupIds, inquiryObjects, inquiryInfoMap, inquiryAction);
		}
		else if (null != inquiryAction && AppserverConstants.ACTION_UNASSIGN_PROCESSING_REGION.equals(inquiryAction))
		{
			bSuccess = bulkUnassignProcessingRegion(soeId, assignToGroupIds, inquiryObjects, inquiryInfoMap, inquiryAction);
		}
		return bSuccess;
	}

	/*
	 * ________________________________________Private methods starts here ___________________________________
	 */
	private HashMap<String, Object> homeBoxSearch(String soeId, BasicDBObject inputJsonObj, boolean isRetrieveAll, BufferedWriter bw) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception
	// instead of using a generic one
	{
		HashMap<String, Object> homeBoxSearchMap = new HashMap<String, Object>();

		DBObject gridViewTO = null;
		DBObject userCriteria = null;
		DBObject orderByCriteria = null;
		DBObject solrCriteria = null;
		HashMap<String, List<String>> solrQueryMap = createSolrQuery(inputJsonObj, soeId);
		List<String> solrSearchTexts = solrQueryMap.get(SOLR_QUERY);// inputJsonObj.getString(SOLR_SEARCH_TEXT);
		String mongoDBObjectCriteria = (solrQueryMap.get("mongoDBObjectCriteria")==null) ? null : solrQueryMap.get("mongoDBObjectCriteria").get(0); // NO SOLR at all.
		// [C153176-453]-Order of Generic and Advanced Search
		inquiryIdsListFromSolr = new ArrayList<Long>();
		homeBoxSearchMap.put(SOLR_SEARCH_TEXT, solrSearchTexts);

		String viewName = inputJsonObj.getString(VIEW_NAME);
		if(null != inputJsonObj.get("isQMA2Origin") && inputJsonObj.getBoolean("isQMA2Origin") && null != inputJsonObj.get("advanceSearchData")) {
			viewName = SEARCH;
		}
		// [C153176-392] - Get columndefs from user collection for HomePage widgets if available.
		List<ColumnDef> userViewColumnDefs = getDefaultBoxUserColDef(soeId, viewName);
		// Draft View Data
		if (viewName.equals(DRAFTS))
		{
			// return getDraftsViewData(soeId);
			homeBoxSearchMap.put(HOME_BOX, getDraftsViewData(soeId, inputJsonObj));
			return homeBoxSearchMap;
		}
		// Home Page Solr Search
		if (solrSearchTexts!=null && !solrSearchTexts.isEmpty() && viewName.equals(SEARCH))
		{
			// return getHomePageSolrSearchViewData(soeId, solrSearchText);
			homeBoxSearchMap.put(HOME_BOX, getHomePageSolrSearchViewData(soeId, solrSearchTexts, isRetrieveAll, inputJsonObj, bw));
			return homeBoxSearchMap;
		}
		// Home Page Advance Solr Search
		if (!StringUtils.isBlank(mongoDBObjectCriteria) && viewName.equals(SEARCH))
		{
			// return getHomePageSolrSearchViewData(soeId, solrSearchText);
			homeBoxSearchMap.put(HOME_BOX, getHomePageAdvanceSolrSearchViewData(soeId, mongoDBObjectCriteria, isRetrieveAll, inputJsonObj, bw));
			return homeBoxSearchMap;
		}
		//sunil starts
		if ( isHomePageAdvancedSearchWithDatesOnly(inputJsonObj) && viewName.equals(SEARCH))
		{
			// return getHomePageSolrSearchViewData(soeId, solrSearchText);
			homeBoxSearchMap.put(HOME_BOX, getHomePageAdvanceSearchWithDatesOnlyViewData(soeId, null, isRetrieveAll, inputJsonObj, bw));
			return homeBoxSearchMap;
		}
		
		//sunil ends
		
		// Get Chart Data
		Boolean isChartView = STRING_YES.equals(inputJsonObj.getString("isChartView")) ? true : false;

		if (isChartView)
		{
			// return getChartViewData(soeId, viewName, solrSearchText);
			homeBoxSearchMap.put(HOME_BOX, getChartViewData(soeId, viewName, solrSearchTexts, isRetrieveAll, userViewColumnDefs, inputJsonObj, bw));
			return homeBoxSearchMap;
		}

		String tagSearch = inputJsonObj.getString(TAG_SEARCH);
		boolean isTagSearch = tagSearch != null && tagSearch.equals("Y");// Sonar Fix -- remove useless parenthesis
		if (isTagSearch)
		{
			// Groupwise Data Load approach for Tag
			String groupName = inputJsonObj.getString(GROUP_NAME);
			BasicDBObject tagVersionCriteria = null;
			Long groupId = null;

			// GroupName null check
			if (!StringUtils.isBlank(groupName))
			{
				groupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
			}
			else
			{
				subLogger.info("Invalid Input for getTagViewData - by " + soeId + " for group name " + groupName);
				throw new CommunicatorException("Invalid Data for groupName.");
			}

			if (groupId == null)
			{
				subLogger.info("groupId not found in cache for groupName -" + groupName);
				throw new CommunicatorException("Invalid Data for groupName.");
			}

			if (isRetrieveAll)
			{
				tagVersionCriteria = new BasicDBObject();
				tagVersionCriteria.append("workflows.tag", viewName);
				tagVersionCriteria.append(WORKFLOWS_ASSIGNED_GROUPID, groupId);
				subLogger.info("homeBoxSearch----isRetrieveAll: [" + isRetrieveAll + "], tagVersionCriteria applied: " + tagVersionCriteria.toString());
			}

			// return getTagViewData(soeId, viewName, solrSearchText,groupId);
			homeBoxSearchMap.put(HOME_BOX, getTagViewData(soeId, viewName, solrSearchTexts, groupId, isRetrieveAll, inputJsonObj, tagVersionCriteria, bw));
			return homeBoxSearchMap;
		}

		// Get Solr Search Response and build criteria
		if ((solrSearchTexts!=null && !solrSearchTexts.isEmpty()) || !StringUtils.isBlank(mongoDBObjectCriteria))
		{
			if (!StringUtils.isBlank(mongoDBObjectCriteria))
			{
				solrCriteria = BasicDBObject.parse(mongoDBObjectCriteria);
				homeBoxSearchMap.put(SOLR_CRITERIA, solrCriteria);
			}
			else if (solrSearchTexts!=null && !solrSearchTexts.isEmpty())
			{
				solrCriteria = callSolrSearchCriteria(solrSearchTexts, soeId, inputJsonObj);
				homeBoxSearchMap.put(SOLR_CRITERIA, solrCriteria);
			}

			if (solrCriteria == null)
			{
				subLogger.info("No Data returned for solr search  " + solrSearchTexts + " , returning blank result");
				// return getBlankGridResponse();
				homeBoxSearchMap.put(HOME_BOX, getBlankGridResponse());

				return homeBoxSearchMap;
			}
		}
		String assignToMeBox = inputJsonObj.getString("assignedToMe");
		String unAssignToMeBox = inputJsonObj.getString("unAssignedMessage");
		String importantMsgBox = inputJsonObj.getString("importantMsg");
		boolean isAssignedToMeSearch = assignToMeBox != null && assignToMeBox.equals("Y");// Sonar Fix -- remove useless parenthesis
		boolean isUnAssignedToMeSearch = unAssignToMeBox != null && unAssignToMeBox.equals("Y");// Sonar Fix -- remove useless parenthesis
		boolean isImportantMsgBox = importantMsgBox != null && importantMsgBox.equals("Y");// Sonar Fix -- remove useless parenthesis
		boolean isVersionUserCriteriaMatch = false;
		if (isAssignedToMeSearch)
		{
			userCriteria = new BasicDBObject(WORKFLOWS_ASSIGNED_USERID, soeId);
			isVersionUserCriteriaMatch = true;
		}
		else if (isUnAssignedToMeSearch)
		{
			List<String> soeIdList = new ArrayList<String>();
			soeIdList.add(soeId);
			userCriteria = new BasicDBObject(WORKFLOWS_ASSIGNED_USERID, new BasicDBObject("$exists", false));
			isVersionUserCriteriaMatch = true;
		}
		else if (isImportantMsgBox)
		{
			userCriteria = new BasicDBObject(URGENT_FLAG, "Y");
		}
		if (userCriteria != null)
		{
			// DBObject orderByCriteria=new BasicDBObject(MODIFIED_DATE,-1);
			gridViewTO = getCustomInboxViewData(soeId, userCriteria, solrCriteria, orderByCriteria, isVersionUserCriteriaMatch, isRetrieveAll, userViewColumnDefs, inputJsonObj, bw);
		}
		// return gridViewTO;
		homeBoxSearchMap.put(HOME_BOX, gridViewTO);
		return homeBoxSearchMap;
	}



	private boolean isHomePageAdvancedSearchWithDatesOnly(BasicDBObject inputJsonObj)
	{
		if (inputJsonObj != null && StringUtils.isNotEmpty(inputJsonObj.toString()) && inputJsonObj.getString(ADVANCED_SEARCH_DATA) != null )
		{
			
			BasicDBObject inputJsonObj1 = BasicDBObject.parse(inputJsonObj.getString(ADVANCED_SEARCH_DATA));
		
			String startDate = inputJsonObj1.getString("startDt");
			String endDate = inputJsonObj1.getString("endDt");

			if (startDate != null && endDate != null)
			{
				return true;
			}
		
		}
		return false;
	}

	private String getAssignUserName(String soeId, String assignGroupName) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		String assignUserStr = null;
		if (StringUtils.isBlank(assignGroupName) || StringUtils.isBlank(soeId))
		{
			subLogger.error("Invalid details for InquiryDao.getAssignUserStr -" + soeId);
			// throw new CommunicatorException("Invalid Input Data for user "+soeId);
			return assignUserStr;
		}
		if(null == QMACacheFactory.getCache().getUserInfoMap() || null == QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase())) {
			subLogger.error("Invalid user -" + soeId);
			// throw new CommunicatorException("Invalid User Data for user "+soeId);
			return assignUserStr;
		}
		User user = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase());
		if (user == null)
		{
			subLogger.error("Invalid user -" + soeId);
			// throw new CommunicatorException("Invalid User Data for user "+soeId);
			return assignUserStr;
		}
		assignUserStr = user.getName() + " (" + soeId + ")";

		assignUserStr = assignUserStr + "[" + assignGroupName + "]";

		return assignUserStr;
	}

	// Get Chart View Data -Default View Type Set to Inbox
	private DBObject getChartViewData(String soeId, String chartViewName, List<String> solrSearchText, boolean isRetrieveAll, List<ColumnDef> userViewColumnDefs, BasicDBObject inputJsonObj, BufferedWriter bw)
			throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("In getChartViewData  " + chartViewName);
		DBObject gridViewTO = new BasicDBObject();
		if (StringUtils.isBlank(chartViewName))
		{
			subLogger.info("In getChartViewData -Blank or Null Chart ViewName, No Data returned");
			return gridViewTO;
		}
		DBObject solrCriteria = null;
		if (solrSearchText!=null && !solrSearchText.isEmpty())
		{
			solrCriteria = callSolrSearchCriteria(solrSearchText, soeId, inputJsonObj);
			// If no result from solr search, then no need to go to DB for data
			if (solrCriteria == null)
			{
				return getBlankGridResponse();
			}
		}

		// Get the base criteria from the Configuration
		String defaultViewCriteriaStr = getDefaultBoxCriteriaStr(QMACacheFactory.getCache().getDefaultInboxName());
		if(null != inputJsonObj && null != inputJsonObj.get("isChartView") && "Y".equalsIgnoreCase(inputJsonObj.getString("isChartView")) 
				&& null != inputJsonObj.get("groupId") && StringUtils.isNotBlank(inputJsonObj.getString("groupId"))){
		// Load data specific the group data
			Set<Long> userGroupsList = getUserAssignedGroupIds(soeId, inputJsonObj);
			if(null != defaultViewCriteriaStr && null != userGroupsList) { //<-- sonar fix null pointer exception
				 defaultViewCriteriaStr = defaultViewCriteriaStr.replace("?", ""+userGroupsList.toString()); 
			}
			
		
		}
		 
		DBObject boxCriteria = getFinalDefaultBoxCriteria(soeId, defaultViewCriteriaStr, gridViewTO, inputJsonObj);
		String defaultViewName = QMACacheFactory.getCache().getDefaultInboxName();
		if(null != inputJsonObj && null != inputJsonObj.get(IS_REQ_FROM_QMA2_DASHBOARD) && inputJsonObj.getBoolean(IS_REQ_FROM_QMA2_DASHBOARD) 
				&& (OPEN_INQUIRIES_BY_REQUEST_TYPE.equalsIgnoreCase(chartViewName) || OPEN_INQUIRIES_BY_ASSIGNED_OWNERS.equalsIgnoreCase(chartViewName))){
			defaultViewName = chartViewName;
		}

		
		if (isGroupLevelGridView(soeId))
		{
			gridViewTO = getGroupLevelGridViewData(gridViewTO, soeId, boxCriteria, null, solrCriteria, null, userViewColumnDefs, 0, defaultViewName, false, isRetrieveAll, inputJsonObj, bw);
		}
		else
		{
			gridViewTO = getUserGridViewData(gridViewTO, boxCriteria, null, solrCriteria, null, userViewColumnDefs, 0);
		}

		return gridViewTO;
	}

	private DBObject getTagViewData(String soeId, String tagName, List<String> solrSearchText, Long groupId, boolean isRetrieveAll, BasicDBObject inputJsonObj, DBObject tagVersionCriteria, BufferedWriter bw)
			throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("In getTagViewData for folder " + tagName);
		DBObject gridViewTO = new BasicDBObject();
		if (StringUtils.isBlank(tagName))
		{
			subLogger.info("In getTagViewData -Blank or Null Tag Name, No Data returned");
			return gridViewTO;
		}
		DBObject solrCriteria = null;
		if (solrSearchText!=null && !solrSearchText.isEmpty())
		{
			solrCriteria = callSolrSearchCriteria(solrSearchText, soeId, inputJsonObj);
			// If no result from solr search, then no need to go to DB for data
			if (solrCriteria == null)
			{
				return getBlankGridResponse();
			}
		}

		// Get the base criteria from the Configuration
		String defaultViewCriteriaStr = getDefaultBoxCriteriaStr(DEFAULT_VIEW_TYPE_TAG);
		// Append tagName

		// [C153176-432] - Escaping $ in tagname for replaceAll to function as expected.
		String replacedTagName = Matcher.quoteReplacement(tagName);
		defaultViewCriteriaStr = defaultViewCriteriaStr.replaceAll("TAG_NAME", replacedTagName);

		// Load data specific the group data
		if (groupId != null)
		{
			defaultViewCriteriaStr = defaultViewCriteriaStr.replace("assignedGroupId : ?", "assignedGroupId : " + groupId + "");
		}
		DBObject boxCriteria = getFinalDefaultBoxCriteria(soeId, defaultViewCriteriaStr, gridViewTO, inputJsonObj);

		
		if (isGroupLevelGridView(soeId))
		{
			//replace GLOBAL_GRID_VIEW_TYPE with TAG_VIEW for tag search data count mismatch for QMA1 and QMA2
			gridViewTO = getGroupLevelGridViewData(gridViewTO, soeId, boxCriteria, tagVersionCriteria, solrCriteria, null, null, 0, TAG_VIEW, isRetrieveAll, isRetrieveAll, inputJsonObj, bw);
		}
		else
		{
			gridViewTO = getUserGridViewData(gridViewTO, boxCriteria, null, solrCriteria, null, null, 0);
		}

		return gridViewTO;
	}

	private DBObject getDraftsViewData(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("In getDraftsViewData for user " + soeId);

		// Prepare Draft Column Defs
		List<ColumnDef> draftColumnDefs = prepareDraftColumnDefs();

		String strColList;
		try
		{
			strColList = DataConversionUtil.convertJavaObjectToJson(draftColumnDefs);
		}
		catch (Exception e)
		{
			subLogger.error("InquiryDAO Exception in getBlankGridResponse ", e);
			throw new CommunicatorException("Exception in getBlankGridResponse", e);
		}

		DBObject gridViewTO = new BasicDBObject();

		// Add Column Defs
		gridViewTO.put(DEFAULT_SELECTED_COLUMN_DEF_LIST, strColList);
		String colDef = prepareGridColsView(draftColumnDefs);

		gridViewTO.put(COLUMN_DEFS, colDef);
		gridViewTO.put(VIEW_TYPE, DRAFTS);

		// Draft View Query
		//DBObject boxCriteria = new BasicDBObject(USER_ID, soeId);
		
		//modified draft query to show scheduled inquiries to entitled groups
		DBObject boxCriteria = getDraftQuery(soeId);
		//if assigned groups are not available or any exception is there then load user's default draft
		if(null == boxCriteria){
			boxCriteria = new BasicDBObject(USER_ID, soeId);
		}
		

		DBObject viewSelectCols = prepareDraftViewSelectCols();

		// Get Draft Data and add it to response
		gridViewTO.put(INQUIRY_DATE_LIST, getViewData("Draft", boxCriteria, viewSelectCols, null, 0));

		//Added below code to get total record count for draft QMA2
		Integer pageNum = GenericUtility.convertLongToIntFromBSON(inputJsonObj.get("pageNum"));

		if (null != pageNum &&  pageNum == 1) {
			gridViewTO.put(TOTAL_RECORDS, getViewDataCount("Draft", boxCriteria));
		}

		return gridViewTO;
	}

	/** this methods gets the query to get the drafts and schedule for later inquiries
	 * @param soeId
	 * @return
	 * @throws CommunicatorException
	 */
	DBObject getDraftQuery(String soeId) throws CommunicatorException {
		String criteria = "{ '$or' : [{'userId' : '#SOEID#'}, {'scheduleForLater' : {'$exists' : 'true'}, 'fromGroupId' : {'$in' : #ASSIGNEDGROUPIDS#}}]}";
		DBObject boxCriteria = null;
		try {
			criteria =  criteria.replace("#SOEID#", soeId);
			Set<Long> assignedGroupIds =  getUserAssignedGroupIds(soeId, null);
			if(null == assignedGroupIds){
				subLogger.info("no assigned groups to get draft");
				return boxCriteria;
			}
			criteria =  criteria.replace("#ASSIGNEDGROUPIDS#", assignedGroupIds.toString());
			boxCriteria = BasicDBObject.parse(criteria);
		} catch (Exception e) {
			subLogger.error("Exception while forming the draft query", e);
		}
		return boxCriteria;
	}

	private DBObject prepareDraftViewSelectCols()
	{
		// Draft View Select Query-This is added to avoid content(clob) data to loaded in the grid
		DBObject colmnCriteria = new BasicDBObject();
		colmnCriteria.put(SUBJECT, true);
		colmnCriteria.put(URGENT_FLAG, true);
		// [C153176-430] - Updating attachment column as well
		colmnCriteria.put(ATTACH_FLAG, true);
		colmnCriteria.put(USER_ID, true);
		colmnCriteria.put(RECEPIENTS, true);
		colmnCriteria.put(CREATED_DATE, true);
		colmnCriteria.put(MODIFIED_DATE, true);
		return colmnCriteria;
	}

	private List<ColumnDef> prepareDraftColumnDefs()
	{
		// Prepare Draft Column Defs
		List<ColumnDef> draftColumnDefs = new ArrayList<>();

		ColumnDef draftIdColDef = new ColumnDef();
		draftIdColDef.setAttributeName("_id");
		draftIdColDef.setDisplayName("ID");

		ColumnDef subColDef = new ColumnDef();
		subColDef.setAttributeName(SUBJECT);
		subColDef.setDisplayName("Subject");

		ColumnDef urgentColDef = new ColumnDef();
		urgentColDef.setAttributeName(URGENT_FLAG);
		urgentColDef.setDisplayName("Urgent");

		ColumnDef attachColDef = new ColumnDef();
		attachColDef.setAttributeName(ATTACH_FLAG);
		attachColDef.setDisplayName("Attachment");

		ColumnDef crtDateColDef = new ColumnDef();
		crtDateColDef.setAttributeName(CREATED_DATE);
		crtDateColDef.setDisplayName("Created Date");
		crtDateColDef.setDataType("Date");

		ColumnDef modDateColDef = new ColumnDef();
		modDateColDef.setAttributeName(MODIFIED_DATE);
		modDateColDef.setDisplayName("Modified Date");
		modDateColDef.setDataType("Date");

		// Draft Column Def List
		draftColumnDefs.add(urgentColDef);
		draftColumnDefs.add(attachColDef);
		draftColumnDefs.add(draftIdColDef);
		draftColumnDefs.add(subColDef);
		draftColumnDefs.add(crtDateColDef);
		draftColumnDefs.add(modDateColDef);
		return draftColumnDefs;
	}

	private DBObject getHomePageSolrSearchViewData(String soeId, List<String> solrSearchStr, boolean isRetrieveAll, BasicDBObject inputJsonObj, BufferedWriter bw) throws CommunicatorException// Sonar Fix -- Define and throw a
	// dedicated exception instead
	// of using a generic one
	{
		subLogger.info("In getHomePageSearchViewData " + solrSearchStr + ".");
		DBObject gridViewTO = new BasicDBObject();

		// Get Solr Search Response and build criteria
		DBObject solrCriteria = callSolrSearchCriteria(solrSearchStr, soeId, inputJsonObj);
		if (solrCriteria == null)
		{
			return getBlankGridResponse();
		}
		Set<Long> userGroupsList = userDao.getUserGroupsList(soeId);
		DBObject boxCriteria = new BasicDBObject(WORKFLOWS_ASSIGNED_GROUPID, new BasicDBObject("$in", userGroupsList));
		DBObject versionMatchCriteria = null;
		boolean isVersionMatchCriteria = false;		
		
		DBObject advanceSolrSearchCriteria = null;
		
		if(null != inputJsonObj.get(ADVANCED_SEARCH_DATA)){
			BasicDBObject advanceSearchData = (BasicDBObject) inputJsonObj.get(ADVANCED_SEARCH_DATA);
			String viewForAdvanceSearch = SEARCH;
			if(null != inputJsonObj.get("isQMA2Origin") && inputJsonObj.getBoolean("isQMA2Origin") && null != inputJsonObj.get("advanceSearchData")) {
				viewForAdvanceSearch = inputJsonObj.getString(VIEW_NAME);
			}
			advanceSolrSearchCriteria = createPreSolrMongoDBObjectForAdvanceSearch(advanceSearchData, viewForAdvanceSearch);
			
			isVersionMatchCriteria = modifiyBoxCriteriaForAdvanceSearch(advanceSearchData, boxCriteria, advanceSolrSearchCriteria);
						
		}
		
		if(isVersionMatchCriteria){
			versionMatchCriteria = advanceSolrSearchCriteria;
		} else {
			isVersionMatchCriteria = true;
			versionMatchCriteria = boxCriteria;
		}

		if (isRetrieveAll)
		{
			// [C153176-169] - Server-side export of inquiries
			// Sending boxCriteria as the userCriteria for version filtering of inquiries to be exported.
			versionMatchCriteria = boxCriteria;
			gridViewTO.put(DEFAULT_USER_CRITERIA, versionMatchCriteria);

		}

		
		if (isGroupLevelGridView(soeId))
		{
			gridViewTO = getGroupLevelGridViewData(gridViewTO, soeId, boxCriteria, versionMatchCriteria,
					solrCriteria, null, null, 0, GLOBAL_GRID_VIEW_TYPE, isVersionMatchCriteria, isRetrieveAll, inputJsonObj, bw);
		}
		else
		{
			gridViewTO = getUserGridViewData(gridViewTO, boxCriteria, null, solrCriteria, null, null, 0);
		}
		if(isWebSocketRedesignEnable() && null != gridViewTO) {
			gridViewTO.put(VIEW_TYPE, 5);
		}
		return gridViewTO;
	}
	
	private DBObject getHomePageAdvanceSearchWithDatesOnlyViewData(String soeId, String advanceSolrSearch, boolean isRetrieveAll, BasicDBObject inputJsonObj, BufferedWriter bw) throws CommunicatorException// Sonar Fix -- Define 
	{
		DBObject gridViewTO = new BasicDBObject();
		Set<Long> userGroupsList = userDao.getUserGroupsList(soeId);
		DBObject boxCriteria = new BasicDBObject(WORKFLOWS_ASSIGNED_GROUPID, new BasicDBObject("$in", userGroupsList));
		//BasicDBObject boxCriteriaWithDates = getAdvancedSearchDateQuery(inputJsonObj, boxCriteria);
		//DBObject advanceSolrSearchCriteria = BasicDBObject.parse(advanceSolrSearch);
		// artf242354-Grid Version behavior - a separate line for each version
		
		DBObject versionMatchCriteria = boxCriteria;
		
		boolean isVersionMatchCriteria = true;
		
		
		if (isGroupLevelGridView(soeId))
		{
			gridViewTO = getGroupLevelGridViewData(gridViewTO, soeId, boxCriteria, versionMatchCriteria,
					null, null, null, 0, GLOBAL_GRID_VIEW_TYPE, isVersionMatchCriteria, isRetrieveAll, inputJsonObj, bw);
		}
		else
		{
			gridViewTO = getUserGridViewData(gridViewTO, boxCriteria, null, null, null, null, 0);
		}
		return gridViewTO;
	}

	private DBObject getHomePageAdvanceSolrSearchViewData(String soeId, String advanceSolrSearch, boolean isRetrieveAll, BasicDBObject inputJsonObj, BufferedWriter bw) throws CommunicatorException// Sonar Fix -- Define
	// and throw a
	// dedicated
	// exception instead
	// of using a
	// generic one
	{
		DBObject gridViewTO = new BasicDBObject();
		Set<Long> userGroupsList = userDao.getUserGroupsList(soeId);
		DBObject boxCriteria = new BasicDBObject(WORKFLOWS_ASSIGNED_GROUPID, new BasicDBObject("$in", userGroupsList));
		DBObject advanceSolrSearchCriteria = BasicDBObject.parse(advanceSolrSearch);
		BasicDBObject advanceSearchData = null;
		if(null != inputJsonObj.get(ADVANCED_SEARCH_DATA)){
			advanceSearchData = (BasicDBObject) inputJsonObj.get(ADVANCED_SEARCH_DATA);
						
		}
		
		DBObject versionMatchCriteria = null;
		
		boolean isVersionMatchCriteria = modifiyBoxCriteriaForAdvanceSearch(advanceSearchData, boxCriteria, advanceSolrSearchCriteria);
		if(isVersionMatchCriteria){
			versionMatchCriteria = advanceSolrSearchCriteria;
		}
		
		if (isGroupLevelGridView(soeId))
		{
			gridViewTO = getGroupLevelGridViewData(gridViewTO, soeId, boxCriteria, versionMatchCriteria,
					advanceSolrSearchCriteria, null, null, 0, GLOBAL_GRID_VIEW_TYPE, isVersionMatchCriteria, isRetrieveAll, inputJsonObj, bw);
		}
		else
		{
			gridViewTO = getUserGridViewData(gridViewTO, boxCriteria, null, advanceSolrSearchCriteria, null, null, 0);
		}
		return gridViewTO;
	}

	private boolean modifiyBoxCriteriaForAdvanceSearch(BasicDBObject advanceSearchData, DBObject boxCriteriaInput,
			DBObject advanceSolrSearchCriteria) {
		boolean modified = false;
		if(null != advanceSolrSearchCriteria && null != advanceSearchData){
			BasicDBObject advancedSearchDateQuery = null;
			if(null != advanceSearchData && null != advanceSearchData.get("startDt") && null != advanceSearchData.get("endDt")) {
				BasicDBObject input = new BasicDBObject();
				input.put(ADVANCED_SEARCH_DATA, advanceSearchData);
				advancedSearchDateQuery = getAdvancedSearchDateQuery(input, new BasicDBObject());
			}
			if(null != advancedSearchDateQuery) {
				BasicDBList criteriaList = (BasicDBList) advanceSolrSearchCriteria.get("$and");
				criteriaList.add(advancedSearchDateQuery);
			}
			@SuppressWarnings("unchecked")
			List<Long> assignedGroupIdList = (List<Long>) advanceSearchData.get(ASSIGNED_GROUPID_LIST);
			if(null != assignedGroupIdList && !assignedGroupIdList.isEmpty()){
				boxCriteriaInput = new BasicDBObject(WORKFLOWS_ASSIGNED_GROUPID, new BasicDBObject("$in", assignedGroupIdList));
			} else {
				BasicDBList criteriaList = (BasicDBList) advanceSolrSearchCriteria.get("$and");
				criteriaList.add(boxCriteriaInput);
			}
			modified = true;
			
			
		}
		return modified;
	}

	private DBObject getBlankGridResponse() throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		DBObject gridViewTO = new BasicDBObject();
		List<ColumnDef> columnDef = QMACacheFactory.getCache().getMasterColumnDef();
		String colDef;
		try
		{
			String strrdefaultList = DataConversionUtil.convertJavaObjectToJson(columnDef);
			gridViewTO.put(DEFAULT_SELECTED_COLUMN_DEF_LIST, strrdefaultList);
			colDef = prepareGridColsView(columnDef);
		}
		catch (Exception e)
		{
			subLogger.error("InquiryDAO Exception in getBlankGridResponse ", e);
			throw new CommunicatorException("Exception in getBlankGridResponse", e);
		}
		gridViewTO.put(COLUMN_DEFS, colDef);
		return gridViewTO;
	}

	private DBObject getCustomInboxViewData(String soeId, DBObject userCriteria, DBObject solrCriteria, DBObject orderByCriteria, Boolean isVersionUserCriteriaMatch, boolean isRetrieveAll,
			List<ColumnDef> userViewColumnDefs, BasicDBObject inputJsonObj, BufferedWriter bw) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("In getCustomInboxViewData with criteria--> " + userCriteria);
		DBObject gridViewTO = new BasicDBObject();
		DBObject defaultBoxCriteria = getFinalDefaultBoxCriteria(soeId, getDefaultBoxCriteriaStr(QMACacheFactory.getCache().getDefaultInboxName()), gridViewTO, inputJsonObj);
		if (defaultBoxCriteria == null)
		{
			subLogger.info("Invalid Default View Configuration-No Data returned " + userCriteria);
			throw new CommunicatorException("Invalid View Configuration-No Data returned");
		}
		
		if (isGroupLevelGridView(soeId))
		{
			gridViewTO = getGroupLevelGridViewData(gridViewTO, soeId, defaultBoxCriteria, userCriteria, solrCriteria, orderByCriteria, userViewColumnDefs, 0, QMACacheFactory.getCache().getDefaultInboxName(),
					isVersionUserCriteriaMatch, isRetrieveAll, inputJsonObj, bw);
		}
		else
		{
			gridViewTO = getUserGridViewData(gridViewTO, defaultBoxCriteria, userCriteria, solrCriteria, orderByCriteria, userViewColumnDefs, 0);
		}
		
		return gridViewTO;
	}

	DBObject getGroupLevelGridViewData(DBObject gridViewTO, String soeId, DBObject finalDefaultBoxCriteria, DBObject userCriteria1, DBObject solrCriteria, DBObject orderBy,
			List<ColumnDef> userViewColmnDefList,
			int maxResults, String viewType, Boolean isVersionUserCriteriaMatch1, boolean isRetrieveAll, BasicDBObject inputJsonObject, BufferedWriter bw) throws CommunicatorException// Sonar Fix -- Define and throw a
	// dedicated exception instead of
	// using a generic one
	{
		DBObject userCriteria = userCriteria1;
		Boolean isVersionUserCriteriaMatch = isVersionUserCriteriaMatch1;
		DBObject gridDataResponse = null;
		
		prepareGridDataResponse(gridViewTO, finalDefaultBoxCriteria, userCriteria, solrCriteria, userViewColmnDefList);
		DBObject finalCriteria = (DBObject) gridViewTO.get(FINAL_CRITERIA);
		//to fix the finalUICriteria for advance search in QMA2
		if(null != inputJsonObject && null != inputJsonObject.get("isQMA2Origin") && inputJsonObject.getBoolean("isQMA2Origin")){
			modifyFinalCriteriaForWebSocketQma2(inputJsonObject, gridViewTO, soeId);
		}
		// [C153176-169] - Server-side export of inquiries - Object containing details regarding query type to be constructed for inquiry export
		DBObject dbQueryType = null;
		String viewName = inputJsonObject.getString(VIEW_NAME);
		if(null != gridViewTO && null == gridViewTO.get(COLUMN_CONFIG)) {
			String viewNameForClomnConfig = getViewNameForColumnConfig(inputJsonObject, viewName);
			String nodeType = getViewNodeType(inputJsonObject);
			gridViewTO.put(COLUMN_CONFIG, getCustomColumnsForDefaultViews(viewNameForClomnConfig,nodeType, soeId));
		}
		

		if (isRetrieveAll)
		{
			dbQueryType = new BasicDBObject();
			dbQueryType.put(IS_RETRIEVE_ALL, isRetrieveAll);
			// Sending the defaultCriteria of saved search as the version match criteria, in case of isRetrieveAll
			if (!isVersionUserCriteriaMatch && userCriteria != null)
			{
				// if defaultUserCriteria is available for Saved Search as per [C153176-160] else criteria of saved search itself is used
				if (gridViewTO.get(DEFAULT_USER_CRITERIA) != null)
				{
					userCriteria = (DBObject) gridViewTO.get(DEFAULT_USER_CRITERIA);
					getBsonObjForUserCtrWithDateObj(userCriteria, "dd/MMM/yyyy");
				}
				isVersionUserCriteriaMatch = true;
				dbQueryType.put(IS_TOP_LEVEL_VERSION_MATCH_REQ, true);
			}
		} else {
			if (null != inputJsonObject && null != inputJsonObject.get("isQMA2Origin") && inputJsonObject.getBoolean("isQMA2Origin") && !isVersionUserCriteriaMatch && userCriteria != null)
			{
				dbQueryType = new BasicDBObject();
				if (gridViewTO.get(DEFAULT_USER_CRITERIA) != null)
				{
					userCriteria = (DBObject) gridViewTO.get(DEFAULT_USER_CRITERIA);
					getBsonObjForUserCtrWithDateObj(userCriteria, "dd/MMM/yyyy");
				}
				isVersionUserCriteriaMatch = true;
				dbQueryType.put(IS_TOP_LEVEL_VERSION_MATCH_REQ, true);
			}
		}
		//Apply default date config for resolved folder if loading from search
		if (null != inputJsonObject.getString(ADVANCED_SEARCH_DATA) && VIEW_RESOLVED.equalsIgnoreCase(viewName)) {
			String defaultDataRangeViewName = "Default";
			//pass defaultViewName so default config will be picked for resolved box
			finalCriteria = InquiryExtendedDAO.getInstance().updateFinalCriteriaWithDateConfig(defaultDataRangeViewName , finalCriteria);
		}else {
			finalCriteria = InquiryExtendedDAO.getInstance().updateFinalCriteriaWithDateConfig(viewName, finalCriteria);
		}
		
		// Group Level Data Fetch Query
		gridViewTO.put(INQUIRY_DATE_LIST, getGroupLevelViewData(soeId, viewType, isVersionUserCriteriaMatch, finalCriteria, userCriteria, orderBy, maxResults, dbQueryType, inputJsonObject, bw, gridViewTO));
		//gridViewTO.put(FINAL_CRITERIA, ((DBObject) gridViewTO.get(FINAL_UI_CRITERIA)).toString());// UI only needs finalCriteria which should not have any SOLR Criteria(pass only basic criteria)
		gridViewTO.put(FINAL_CRITERIA, GenericUtility.parseJsonInRelaxedMode((DBObject) gridViewTO.get(FINAL_UI_CRITERIA)));
		
		if(null != inputJsonObject && null != inputJsonObject.get(TOTAL_RECORDS)){
			gridViewTO.put(TOTAL_RECORDS, inputJsonObject.getInt(TOTAL_RECORDS));
		}
		if(null != inputJsonObject && null != inputJsonObject.get(TOTAL_UNREAD_RECORDS)){
			gridViewTO.put(TOTAL_UNREAD_RECORDS, inputJsonObject.getInt(TOTAL_UNREAD_RECORDS));
		}
		
		// TODO:remove redundant criteria
		gridDataResponse = gridViewTO;

		// subLogger.info("finalUICriteria --> "+gridViewTO.get(FINAL_CRITERIA));
		// subLogger.info("inquiryDataListSize --> "+ ((List<DBObject>)gridViewTO.get(INQUIRY_DATE_LIST)).size());
		return gridDataResponse;
	}



	private void modifyFinalCriteriaForAdvanceSearchQma2(BasicDBObject inputJsonObject, DBObject gridViewTO, String soeId) {
		try {
			if(isWebSocketRedesignEnable() && null != gridViewTO && null != gridViewTO.get("finalUICriteria")) {
				BasicDBObject advanceSearchData = (BasicDBObject) inputJsonObject.get("advanceSearchData");
				advanceSearchData.put("isQma2", true);
				String viewName = inputJsonObject.getString(VIEW_NAME);
				boolean preSolrMongoSearchRequired = isPreSolrMongoSearchRequired(advanceSearchData);
				if(preSolrMongoSearchRequired) {
					DBObject advanceSearchCriteria = createPreSolrMongoDBObjectForAdvanceSearch(advanceSearchData, viewName);
					if(null != gridViewTO && null != gridViewTO.get("finalUICriteria") && null != ((BasicDBObject) gridViewTO.get("finalUICriteria")).get("$and")) {
					  BasicDBObject finalUICriteria = (BasicDBObject) gridViewTO.get("finalUICriteria");
					  BasicDBList andCriteria = (BasicDBList) finalUICriteria.get("$and"); 
					  if(null!= andCriteria && null != andCriteria.get(0)) {
						  andCriteria.add(advanceSearchCriteria);
					  }
					gridViewTO.put("finalUICriteria", finalUICriteria);
					gridViewTO.put("finalCriteria", finalUICriteria.toString());
					}
				}
				gridViewTO.put("viewType", 5);
			}
			
		} catch (Exception e) {
			subLogger.error("Exception in modifyFinalCriteriaForAdvanceSearchQma2 for soeId: "+soeId, e);
		}
		
	}
	
	private void modifyFinalCriteriaForWebSocketQma2(BasicDBObject inputJsonObject, DBObject gridViewTO, String soeId) {
		try {
			if(null != inputJsonObject && null != inputJsonObject.get("advanceSearchData")) {
				modifyFinalCriteriaForAdvanceSearchQma2(inputJsonObject, gridViewTO, soeId);
			} else if(null != inputJsonObject && null != inputJsonObject.get("viewName") 
					&& OPEN_INQUIRIES_BY_REQUEST_TYPE.equalsIgnoreCase(inputJsonObject.getString("viewName")) && null != inputJsonObject.get("requestType")) {
				modifyFinalCriteriaForOpenInqByRequestTypeChartQma2(inputJsonObject, gridViewTO, soeId);
			}  else if(null != inputJsonObject && null != inputJsonObject.get("viewName") 
					&& OPEN_INQUIRIES_BY_ASSIGNED_OWNERS.equalsIgnoreCase(inputJsonObject.getString("viewName")) && null != inputJsonObject.get("assignedOwnerId")
					&& null != inputJsonObject.get("ageBand")) {
				modifyFinalCriteriaForOpenInqByAssignedOwnerAgeBandChartQma2(inputJsonObject, gridViewTO, soeId);
			}
			
		} catch (Exception e) {
			subLogger.error("Exception in modifyFinalCriteriaForWebSocketQma2 for soeId: "+soeId, e);
		}
		
	}
	
	private void modifyFinalCriteriaForOpenInqByRequestTypeChartQma2(BasicDBObject inputJsonObject, DBObject gridViewTO, String soeId) {
		try {
			if(isWebSocketRedesignEnable() && null != gridViewTO && null != gridViewTO.get("finalUICriteria")) {
				String requestType = inputJsonObject.getString("requestType");
				DBObject requestTypeCriteria = new BasicDBObject("workflows.requestType",requestType);
				if(null != gridViewTO && null != gridViewTO.get("finalUICriteria") && null != ((BasicDBObject) gridViewTO.get("finalUICriteria")).get("$and")) {
				  BasicDBObject finalUICriteria = (BasicDBObject) gridViewTO.get("finalUICriteria");
				  BasicDBList andCriteria = (BasicDBList) finalUICriteria.get("$and"); 
				  if(null!= andCriteria && null != andCriteria.get(0)) {
					  andCriteria.add(requestTypeCriteria);
				  }
				gridViewTO.put("finalUICriteria", finalUICriteria);
				gridViewTO.put("finalCriteria", finalUICriteria.toString());
				}
			}
			
		} catch (Exception e) {
			subLogger.error("Exception in modifyFinalCriteriaForOpenInqByRequestTypeChartQma2 for soeId: "+soeId, e);
		}
	}
	
	private void modifyFinalCriteriaForOpenInqByAssignedOwnerAgeBandChartQma2(BasicDBObject inputJsonObject, DBObject gridViewTO, String soeId) {
		try {
			if(isWebSocketRedesignEnable() && null != gridViewTO && null != gridViewTO.get("finalUICriteria")) {
				String assignedOwnerId = inputJsonObject.getString("assignedOwnerId");
				String ageBand = inputJsonObject.getString("ageBand");
				DBObject assignedOwnerAgeBandCriteria = new BasicDBObject("workflows.assignedUserId",assignedOwnerId).append("workflows.ageInDays",ageBand);
				if(null != gridViewTO && null != gridViewTO.get("finalUICriteria") && null != ((BasicDBObject) gridViewTO.get("finalUICriteria")).get("$and")) {
				  BasicDBObject finalUICriteria = (BasicDBObject) gridViewTO.get("finalUICriteria");
				  BasicDBList andCriteria = (BasicDBList) finalUICriteria.get("$and"); 
				  if(null!= andCriteria && null != andCriteria.get(0)) {
					  andCriteria.add(assignedOwnerAgeBandCriteria);
				  }
				gridViewTO.put("finalUICriteria", finalUICriteria);
				gridViewTO.put("finalCriteria", finalUICriteria.toString());
				}
			}
			
		} catch (Exception e) {
			subLogger.error("Exception in modifyFinalCriteriaForOpenInqByAssignedOwnerAgeBandChartQma2 for soeId: "+soeId, e);
		}
	}

	/**
	 * 
	 */
	public boolean isWebSocketRedesignEnable() {
		boolean flag = false;
		try {
			QMACache qmaCache = QMACacheFactory.getCache();
			if (null != qmaCache.getConfigById("cvWebsocketConfig")) {
				Map<String, Object> cvWebsocketConfig = qmaCache.getConfigById("cvWebsocketConfig").getCvWebsocketConfig();
				if ( null != cvWebsocketConfig && null != cvWebsocketConfig.get("isWebSocketRedesignEnable")) {
					flag = (boolean) cvWebsocketConfig.get("isWebSocketRedesignEnable");
				}
			}
		} catch (Exception e) {
			subLogger.error("Excpetion in isWebSocketRedesignEnable", e);
		}
		return flag;
	}

	// Existing Method Refactor for Reuse
	private DBObject getUserGridViewData(DBObject gridViewTO, DBObject finalDefaultBoxCriteria, DBObject userCriteria, DBObject solrCriteria, DBObject orderBy, // Sonar Fix -- remove useless parameter
			List<ColumnDef> userViewColmnDefList,
			int maxResults) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		prepareGridDataResponse(gridViewTO, finalDefaultBoxCriteria, userCriteria, solrCriteria, userViewColmnDefList);

		DBObject finalCriteria = (DBObject) gridViewTO.get(FINAL_CRITERIA);
		DBObject finalUICriteria = (DBObject) gridViewTO.get(FINAL_UI_CRITERIA);
		// subLogger.info("finalCriteria --> "+gridViewTO.get(FINAL_CRITERIA));

		gridViewTO.put(INQUIRY_DATE_LIST, getViewData(INQUIRY, finalCriteria, null, orderBy, maxResults));
		gridViewTO.put(FINAL_CRITERIA, finalUICriteria.toString());// UI only needs finalCriteria which should not have any SOLR Criteria(pass only basic criteria)

		// subLogger.info("finalUICriteria --> "+gridViewTO.get(FINAL_CRITERIA));
		// subLogger.info("inquiryDataListSize --> "+ ((List<DBObject>)gridViewTO.get(INQUIRY_DATE_LIST)).size());
		// TODO:remove redundant criteria
		return gridViewTO;

	}

	public void prepareGridDataResponse(DBObject gridViewTO, DBObject finalDefaultBoxCriteria, DBObject userCriteria, DBObject solrCriteria, // Sonar Fix -- remove useless parameter
			List<ColumnDef> userViewColmnDefList) throws CommunicatorException// , JsonMappingException, IOException, Exception// Sonar Fix -- remove useless parameter
	{
		List<ColumnDef> columnDef = QMACacheFactory.getCache().getDefaultStaticData().getMasterColumnDef();

		// BasicDBObject db = new BasicDBObject(strrdefaultList);
		// Get basic db object of it.

		// get oe by one for all opf them and then append them and send as response .//
		if (userViewColmnDefList != null)
		{
			columnDef = userViewColmnDefList;

		}
		// C153176-1411 Bring all indicator flag columns to the start
		columnDef = InquiryUtil.reArrangeColumnDef(columnDef);
		long startTime = System.currentTimeMillis();
		String strrdefaultList;
		try
		{
			strrdefaultList = DataConversionUtil.convertJavaObjectToJson(columnDef);
		}
		catch (Exception e)
		{
			subLogger.error("InquiryDAO Exception in prepareGridDataResponse ", e);
			throw new CommunicatorException("Exception in getBlankGridResponse", e);
		}

		subLogger.info("Inside .strrdefaultList Time Diff-"
				+ (System.currentTimeMillis() - startTime)
				+ " in Milli Seconds");
		gridViewTO.put(DEFAULT_SELECTED_COLUMN_DEF_LIST, strrdefaultList);

		BasicDBList finalCriteria = new BasicDBList();
		if(null != finalDefaultBoxCriteria){
		finalCriteria.add(finalDefaultBoxCriteria);
		}
		

		BasicDBList finalUICriteria = new BasicDBList();
		if(null != finalDefaultBoxCriteria){
		finalUICriteria.add(finalDefaultBoxCriteria);
		}
		

		if (userCriteria != null)
		{
			Boolean isUIViewFilter = userCriteria.get("isUIViewFilter")!=null ? (Boolean) userCriteria.get("isUIViewFilter") : false;

			//[C153176-1302] - Create left-hand sub-menu items for Escalation - UIViewFilter will only be added to filterUICriteria
			if(isUIViewFilter)
			{
				BasicDBObject uiCriteria = new BasicDBObject((String)userCriteria.get("viewFilterField"),userCriteria.get("viewFilterValue"));

				if(userCriteria.get("viewFilterDirection")!=null)
				{
					uiCriteria.put("direction", userCriteria.get("viewFilterDirection"));
				}
				finalUICriteria.add(uiCriteria);
			}
			else
			{
				finalCriteria.add(userCriteria);
				finalUICriteria.add(userCriteria);
			}
		}
		if (solrCriteria != null)
		{
			finalCriteria.add(solrCriteria);
		}
		DBObject finalCrtQuery = new BasicDBObject("$and", finalCriteria);// Sonar Fix -- Rename "content" which hides the field declared
		DBObject finalUIQuery = new BasicDBObject("$and", finalUICriteria);
		// subLogger.debug(finalQuery.toString());

		// end

		gridViewTO.put(FINAL_CRITERIA, finalCrtQuery);
		gridViewTO.put(FINAL_UI_CRITERIA, finalUIQuery);
		long ColDefTime = System.currentTimeMillis();
		String colDef = prepareGridColsView(columnDef);
		subLogger.info("Inside .colDef Time Diff-"
				+ (System.currentTimeMillis() - ColDefTime)
				+ " in Milli Seconds");

		gridViewTO.put(COLUMN_DEFS, colDef);
	}

	public BasicDBObject getFinalDefaultBoxCriteria(String soeId, String defaultViewCriteria, DBObject gridViewTO, BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception
	// instead of using a generic one
	{
		BasicDBObject finalBoxCriteria = null;
		String defaultViewCrit = defaultViewCriteria;// Sonar Fix -- Introduce a new variable instead of reusing the parameter
		if (!StringUtils.isBlank(defaultViewCrit))
		{
			Set<Long> userGroupsList = getUserAssignedGroupIds(soeId, inputJsonObj);
			boolean isQMA2Request = null != inputJsonObj && null != inputJsonObj.get(IS_REQ_FROM_QMA2_DASHBOARD) && inputJsonObj.getBoolean(IS_REQ_FROM_QMA2_DASHBOARD);
			boolean isRetrieveAll = null != inputJsonObj && null != inputJsonObj.get("isRetrieveAll") && inputJsonObj.getBoolean("isRetrieveAll");
			boolean isRequestFromMailBoxStats = null != inputJsonObj && null != inputJsonObj.get("isRequestFromMailBoxStats") && inputJsonObj.getBoolean("isRequestFromMailBoxStats"); 
			boolean isQMA2Origin = null != inputJsonObj && null != inputJsonObj.get("isQMA2Origin")	&& inputJsonObj.getBoolean("isQMA2Origin");
					
			// C170665-42 | Get the selected assigned groups in dashboard setting
			if ((isQMA2Request && isRetrieveAll && isRequestFromMailBoxStats) || isQMA2Origin) {
				userGroupsList = getAssignedGroupsfromDashboard(soeId, userGroupsList);
			}
			getPersonalGroupId(soeId, inputJsonObj, userGroupsList);
			addSymphonyGroup(soeId, inputJsonObj, userGroupsList);
			
			// replace ? with user groups
			defaultViewCrit = defaultViewCrit.replace("?", userGroupsList.toString());
			if(null != defaultViewCrit && defaultViewCrit.contains(MOD_DATE_EXP)){
				String viewNameDateCriteria = inputJsonObj.getString("viewName");
				if(StringUtils.isEmpty(viewNameDateCriteria)) {
					viewNameDateCriteria = "Default";
				}
				Date dateCriteriaDefaulBoxCriteria =  MailboxModDateUtil.getModDateAsPerDateConfig(soeId, inputJsonObj, viewNameDateCriteria,false);
				if(null != dateCriteriaDefaulBoxCriteria) {
					Long dateLong = dateCriteriaDefaulBoxCriteria.getTime();
					defaultViewCrit = defaultViewCrit.replaceAll(MOD_DATE_EXP, dateLong.toString());
				}
			}
			DBObject boxCriteria = BasicDBObject.parse(defaultViewCrit);

			BasicDBList critArray = (BasicDBList) boxCriteria.get(AND_CRITERIA_OPERATOR);
			if (gridViewTO != null && critArray != null && critArray.size() == 2)
			{
				// get the criteria which has both ViewType and Critria
				DBObject viewTypeCriteria = (DBObject) critArray.get(0);
				String viewType = (String) viewTypeCriteria.get(VIEW_TYPE);
				if (!StringUtils.isBlank(viewType))
				{
					gridViewTO.put(VIEW_TYPE, viewType);
				}
				// As per view type , load default view criteria

				finalBoxCriteria = (BasicDBObject) critArray.get(1);
			}
			else
			{
				finalBoxCriteria = (BasicDBObject) boxCriteria;
			}
		}
		// return final view criteria
		return finalBoxCriteria;
	}

	/**
	 * @param soeId
	 * @param inputJsonObj
	 * @param userGroupsList
	 */
	private void addSymphonyGroup(String soeId, BasicDBObject inputJsonObj, Set<Long> userGroupsList) {
		try {
			String viewName = null;
			boolean isQMA2Origin = false;
			if(null != inputJsonObj && null != inputJsonObj.get("isQMA2Origin") && inputJsonObj.getBoolean("isQMA2Origin")) {
				isQMA2Origin = true;
			}
			if(isQMA2Origin && null != inputJsonObj && null != inputJsonObj.get("viewName")) {
				viewName = inputJsonObj.getString("viewName");
			}
			if(isQMA2Origin && StringUtils.isNotBlank(viewName) && SymphonyDAO.getInstance().isCombinedViewRequired(viewName, soeId) && null !=userGroupsList && !userGroupsList.isEmpty()) {//<-- sonar fix null pointer
				Long symphonyGroupId = SymphonyDAO.getInstance().getSymphonyGroupId();
				userGroupsList.add(symphonyGroupId);
				subLogger.info("Symphony:: added symphony groupId to combined view query : "+ symphonyGroupId);
			} else if(isQMA2Origin && StringUtils.isNotBlank(viewName) && "ChatView".equalsIgnoreCase(viewName) && null !=userGroupsList && !userGroupsList.isEmpty()) {//<-- sonar fix null pointer
				Long symphonyGroupId = SymphonyDAO.getInstance().getSymphonyGroupId();
				userGroupsList.clear();
				userGroupsList.add(symphonyGroupId);
				subLogger.info("Symphony:: added symphony groupId to combined view query : "+ symphonyGroupId);
			}
		} catch (Exception e) {
			subLogger.error("Exception in addSymphonyGroup", e);
		}
	}
	/**
	 * @param soeId
	 * @param inputJsonObj
	 * @param userGroupsList
	 */
	private void getPersonalGroupId(String soeId, BasicDBObject inputJsonObj, Set<Long> userGroupsList) {
		try {
			if(null != inputJsonObj && inputJsonObj.containsField(IS_PERSONAL) && "Y".equalsIgnoreCase(inputJsonObj.getString(IS_PERSONAL))) {
				Map<String, Long> personalMailBoxMap = QMACacheFactory.getCache().getPersonalMailboxIdToGroupIdMap();
				subLogger.debug("From Hazelcast personalMailBoxMap: {}", personalMailBoxMap.size());
				if(null != personalMailBoxMap && null != personalMailBoxMap.get(soeId)) {
					subLogger.debug("Personal GroupId:[{}]",personalMailBoxMap.get(soeId));
					if(null != userGroupsList) { //<-- sonar fix null pointer
						userGroupsList.clear();
						userGroupsList.add(personalMailBoxMap.get(soeId));
					}else {
						subLogger.warn("userGroupsList is null");
					}
					
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in get personal groupId", e);
		}
	}
	/**
	 * This method is used to get assigned groups from dashboard settings
	 * @param soeId
	 * @param userGroupsList
	 * @return
	 */
	public Set<Long> getAssignedGroupsfromDashboard(String soeId, Set<Long> userGroupsList) {
		try {
			BasicDBObject dashBoardSettings = DashboardDAO.getInstance().getDashboardSettings(soeId);
			if (null != dashBoardSettings && null != dashBoardSettings.get(ASSIGNED_GROUPS)) {
				BasicDBList assignedGroupsList = (BasicDBList) dashBoardSettings.get(ASSIGNED_GROUPS);
				if (!assignedGroupsList.isEmpty()) {
					return prepareAssignedGroupSet(assignedGroupsList);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in InquiryDAO#getAssignedGroupsfromDashboard",e);
		}
		return userGroupsList;
	}

	/**
	 * This method is used to prepare set for assigned group ids
	 * @param assignedGroupsList
	 * @return
	 */
	private Set<Long> prepareAssignedGroupSet(BasicDBList assignedGroupsList) {
		Set<Long> groupCodeList = new HashSet<>();
		QMACache qmaCache = QMACacheFactory.getCache();
		Map<String, Long> groupCodeToIdMap = qmaCache.getGroupCodeToIdMap();
		for (int i = 0; i < assignedGroupsList.size(); i++) {
			BasicDBObject assignedGroup = (BasicDBObject) assignedGroupsList.get(i);
			String groupName = assignedGroup.getString(GROUP_NAME_KEY);
			if (null != groupName) {
				Long groupCode = groupCodeToIdMap.get(groupName.toUpperCase());
				groupCodeList.add(groupCode);
			}
		}
		return groupCodeList;
	}

	// ViewName for default boxes, and viewype for other boxes are same. i.e inbox, outbox etc.
	private String getDefaultBoxCriteriaStr(String viewName) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		String defaultViewCriteria = null;
		ViewConfig defaultViewConfig = QMACacheFactory.getCache().getDefaultViewMap().get(viewName);
		if (defaultViewConfig != null)
		{
			defaultViewCriteria = defaultViewConfig.getCriteria();
		}
		return defaultViewCriteria;
	}

	private String prepareGridColsView(List<ColumnDef> colDefList) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		int size = colDefList.size();
		List<GridColumnsTO> columnDefs = new ArrayList<GridColumnsTO>();

		String displayName;
		String attributeName;
		// Creating a width column to assign default values.
		int width;

		for (int i = 0; i <= size - 1; i++)
		{
			displayName = colDefList.get(i).getDisplayName();
			attributeName = colDefList.get(i).getAttributeName();
			width = (int) colDefList.get(i).getWidth();

			// Assign default width if width is not set by user
			if (width == 0)
			{
				width = 150;
			}

			if ("id".equals(colDefList.get(i).getDataType()))
			{
				columnDefs.add(new GridColumnsTO(displayName, attributeName, width, "number", null));
			}
			else if ("Date".equals(colDefList.get(i).getDataType()))
			{
				columnDefs.add(new GridColumnsTO(displayName, attributeName, width, "date", DATE_FORMAT));
			}

			else
			{
				columnDefs.add(new GridColumnsTO(displayName, attributeName, width, null, null));
			}

			// if(i>20) break;
		}
		// gridViewTO.columnDefs = columnDefs.toArray(new GridColumns[columnDefs.size()]);
		String json = null;
		try
		{
			json = DataConversionUtil.convertJavaObjectToJson(columnDefs.toArray(new GridColumnsTO[columnDefs.size()]));
		}
		catch (Exception e)
		{
			subLogger.error("InquiryDAO Exception in prepareGridColsView ", e);
			throw new CommunicatorException("Exception in prepareGridColsView", e);
		}
		return json;
	}

	public DBObject getRecentInboxData(String soeId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			DBObject gridViewTO = new BasicDBObject();
			DBObject defaultBoxCriteria = getFinalDefaultBoxCriteria(soeId, getDefaultBoxCriteriaStr(QMACacheFactory.getCache().getDefaultInboxName()), gridViewTO, null);
			if (defaultBoxCriteria == null)
			{
				subLogger.info("getRecentInboxData-Invalid Default View Configuration-No Data returned ");
			}
			else
			{
				DBObject defaultOrderBy = new BasicDBObject();
				defaultOrderBy.put(MODIFIED_DATE, -1);
				int maxRecentMsgCount = 10;
				gridViewTO = getUserGridViewData(gridViewTO, defaultBoxCriteria, null, null, defaultOrderBy, null, maxRecentMsgCount);
			}
			return gridViewTO;
		}
		catch (Exception e)
		{
			subLogger.error("Generic Exception in getRecentInboxData for user " + soeId, e);
			throw new CommunicatorException("Generic Exception in getRecentInboxData for user " + soeId, e);
		}
	}

	private String getAllToCCgroups(List<Workflow> workFlowList, String dbAllToCCGroups)
	{
		// Sonar-Fixes-Replace the synchronized class "StringBuffer" by an unsynchronized one such as "StringBuilder"
		StringBuilder allToCCGroup = new StringBuilder();
		allToCCGroup.append(dbAllToCCGroups != null ? dbAllToCCGroups : "");
		QMACache qmaCache = QMACacheFactory.getCache();
		Map<Long, String> groupIdToNameMap = qmaCache.getGroupIdToNameMap();
		for (Workflow workflow : workFlowList)
		{
			// Sonar fix - remove the usless assignments
			if (workflow.getAssignedGroupId() != null)
			{
				String groupCode = groupIdToNameMap.get(workflow.getAssignedGroupId());
				if (!StringUtils.isEmpty(groupCode) && workflow.getDirection().equals("IN") && allToCCGroup.indexOf(groupCode) == -1)
				{
					allToCCGroup.append(groupCode + ";");
				}
			}

		}

		return allToCCGroup.toString();
	}

	private DBObject createWorkFlowsAuditJavaDriver(Long groupId, String action, String actionDesc, String userId, Date currentTime, Map<Long, String> groupIdToNameMap, Map<String, User> userInfoMap)
	{
		DBObject workflowAudit = new BasicDBObject();
		String userName = "";
		workflowAudit.put(ACTION, action);
		workflowAudit.put(ACTION_DETAILS, actionDesc);
		workflowAudit.put(GROUP_ID, groupId);

		// Get group name from group cache through id and include it in workflow audit object

		if (groupId != null)
			workflowAudit.put(GROUP_NAME, groupIdToNameMap.get(groupId));

		if (InquiryDAO.ACTION_REOPEN.equalsIgnoreCase(action))
		{
			workflowAudit.put(REOPEN_DATE, currentTime);
		}

		User user = userInfoMap.get(userId.toUpperCase());
		if (user != null)
		{
			userName = user.getName();
		}
		workflowAudit.put(USER_ID, userName);
		workflowAudit.put(MODIFIED_BY, userName);
		workflowAudit.put(MODIFIED_DATE, currentTime);
		workflowAudit.put(LAST_ACTION_TIME, currentTime);
		workflowAudit.put(LAST_ACTION_BY, userName);

		// C153176-875 -- Logging the lockedBy , lockedDate, unlockedBy, unlockedDate in the workflow audit for the lock & unlock flow respt.
		if (InquiryDAO.ACTION_LOCK.equalsIgnoreCase(action))
		{
			workflowAudit.put(LOCKED_BY, userName);
			workflowAudit.put(LOCKED_TIME, currentTime);
		}

		if (InquiryDAO.ACTION_UNLOCK.equalsIgnoreCase(action))
		{
			workflowAudit.put(UNLOCKED_BY, userName);
			workflowAudit.put(UNLOCKED_TIME, currentTime);
		}
		return workflowAudit;
	}

	private WorkflowAudit createWorkFlowsAudit(Long groupId, String action, String actionDesc, String userId, Date currentTime, String forceUnlock, String tag, Map<Long, String> groupIdToNameMap, Map<String, User> userInfoMap)
	{
		WorkflowAudit workflowAudit = new WorkflowAudit();
		String userName = "";
		workflowAudit.setAction(action);
		workflowAudit.setActionDetails(actionDesc);
		workflowAudit.setGroupId(groupId);
		if (("true").equals(forceUnlock))
		{
			workflowAudit.setForceUnlock(STRING_YES);
		}
		if (null != groupId)
		{
			workflowAudit.setGroupName(groupIdToNameMap.get(groupId));
		}
		User user = userInfoMap.get(userId.toUpperCase());
		if (null != user)
		{
			userName = user.getName();
		}
		workflowAudit.setModDate(currentTime);
		workflowAudit.setModBy(userName);
		workflowAudit.setUserId(userName);
		workflowAudit.setTag(tag);

		return workflowAudit;
	}

	private DBObject createInquiryNote(String userId, String userName, Date commentDate, String comments)// Sonar Fix -- remove useless parameter
	{
		DBObject note = new BasicDBObject();
		note.put(USER_ID, userId);
		note.put("userName", userName);
		note.put("comments", comments);
		note.put("commentDate", commentDate);
		return note;
	}

	private List<Workflow> createWorkFlows(Inquiry inquiry, Conversation conversation, Workflow uiWorkflowData, boolean isMakerCheckerEnabled, String soeId, String action, Date currentTime,
			List<Long> resolveAllGroupList, List<ConversationRecipient> recipientsList) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic
																													// one
	{
		List<Workflow> workflowList = new ArrayList<Workflow>(0);
		List<Long> toCcGroupIdList = new ArrayList<Long>();
		Map<Long, String> toCcGrpIdMap = getRecipientsUserIdMap(conversation.getRecipients(), toCcGroupIdList, TO_CATEGORY + CC_CATEGORY + BCC_CATEGORY);
		Long fromGroupId = inquiry.getLatestGroupId();
		String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
		if (inquiry.getAction().equals(ACTION_NEW) || inquiry.getAction().equals(ACTION_NEW_RESOLVE))
		{
			for (Long grpId : toCcGrpIdMap.keySet())
			{
				Workflow verDO = createNewWorkflowForInquiry(grpId, INQUIRY_DIRECTION_IN, inquiry.getAction(), uiWorkflowData, soeId, currentTime, conversation.getRecipients(),
						inquiry.getLatestGroupId());
				if (grpId.equals(fromGroupId) && inquiry.getAction().equals(ACTION_NEW_RESOLVE))
				{
					verDO.setStatus(STATUS_RESOLVE);
					verDO.setFollowUp(null);
					verDO.setLastActionby(userName);
					verDO.setLastActionTime(currentTime);
					verDO.setResolver(userName);
					verDO.setResolveTime(currentTime);
				} 

				 //C153176-1715 : New Inquiry : If external domain is present in the recipientList then make isLastConvToExtEmail = Y for all the recipients(groups).
				boolean isEmailSentToExternal = isEmailSentToExternal(recipientsList);
				verDO.setIsLastConvToExtEmail( isEmailSentToExternal ? "Y" : "N");
				uiWorkflowData.setIsLastConvToExtEmail(isEmailSentToExternal ? "Y" : "N");
				
				workflowList.add(verDO);

				// Inquiry to self
				if (grpId.equals(fromGroupId))
				{
					if (StringUtils.isNotBlank(uiWorkflowData.getProcessingRegion()))
					{
						verDO.setProcessingRegion(uiWorkflowData.getProcessingRegion());
					}
					if (StringUtils.isNotBlank(uiWorkflowData.getRootCause()))
					{
						verDO.setRootCause(uiWorkflowData.getRootCause());
					}
					if (uiWorkflowData.getQueryCount() != null)
					{
						verDO.setQueryCount(uiWorkflowData.getQueryCount());
					}
					
					if (null != uiWorkflowData.getFollowUp())
					{
						verDO.setFollowUp(uiWorkflowData.getFollowUp());
					}
					
					// C153176-5987 | Tag should be populating to work flow if same group
					if(StringUtils.isNotBlank(uiWorkflowData.getTag())) {
						verDO.setTag(uiWorkflowData.getTag());
					}
					//set resolve allocation
					if(null != uiWorkflowData && StringUtils.isNotBlank(uiWorkflowData.getResolveAllocation())) {
						verDO.setResolveAllocation(uiWorkflowData.getResolveAllocation());
					}
				}
			}

			// Pass reopen date as null in the below method for New Inquiry action
			if (uiWorkflowData != null)
			{
				uiWorkflowData.setLatestConversationTime(currentTime);
			}
			createWorkflowsForNewInquiryEditActions(inquiry, workflowList, soeId, currentTime, uiWorkflowData, toCcGrpIdMap, fromGroupId, isMakerCheckerEnabled, action, resolveAllGroupList,
					recipientsList);
			// createOutBoxWorkFlow(inquiry, workflowList, uiWorkflowData, fromGroupId, soeId, action, currentTime, isMakerCheckerEnabled, null, null, 0, null, recipientsList);
			calculateResponseTime(workflowList, fromGroupId, currentTime);

			// C153176-5891 | Calculate CITI response time based on new logic. 
			calculateCitiResponseTime(workflowList, fromGroupId, currentTime); 
		
			//return workflowList; 
		}else {
			// Reply,ReplyAll,ReplyResolve,ReplyAllResolve/Forward Flows
			workflowList = createWorkflowsForEditActions(inquiry, soeId, currentTime, uiWorkflowData, toCcGrpIdMap, fromGroupId, isMakerCheckerEnabled, action, resolveAllGroupList,recipientsList);
			// [C153176-818]-Add 'Response Time'
			calculateResponseTime(workflowList, fromGroupId, currentTime);
	
			// C153176-5891 | Calculate CITI response time based on new logic. 
			calculateCitiResponseTime(workflowList, fromGroupId, currentTime);
			
			// C153176-5354 - Add first response time for out workflow
			calculateAndUpdateFirstResponseTime(workflowList, fromGroupId, currentTime);
			
			if(!ACTION_NEW.equalsIgnoreCase(action)) {
				boolean autoAssigned = removeAutoAssignmentNonInquiryFlag(workflowList, fromGroupId, soeId, inquiry.getId());
				if(!autoAssigned) {
					inquiry.setAutoAssignmentAvailable(false);
				}
				//Revoke from AutoAssignInquiry collection
				revokeAutoAssign(inquiry.getId());
			}
		}
		boolean isTaskizeInquiry = false;
		setChangedInquirySubStatus(workflowList, uiWorkflowData.getInquirySubStatus() , fromGroupId, toCcGroupIdList,inquiry.getId(), uiWorkflowData.getIsSubStatusPendingInternal(),isTaskizeInquiry);
		return workflowList;

	}

	
	private List<Long> getIgnoredQmaDlForTaskizeFromCache() {
		List<Long> ignoredQmaDlForTaskizeList = new ArrayList<>();
		Config config = QMACacheFactory.getCache().getConfigById("taskizeConfig");
		if(null != config) {
			Map<String, Object> taskizeConfig = config.getTaskizeConfig();
			if(null != taskizeConfig && !taskizeConfig.isEmpty())
				ignoredQmaDlForTaskizeList = (List<Long>) taskizeConfig.get("ignoredQmaDlForTaskize");
		}
		return ignoredQmaDlForTaskizeList;
	}
	private List<Workflow> createWorkflowsForNewInquiryEditActions(Inquiry inquiry, List<Workflow> workflowList, String soeId, Date currentTime, Workflow workflowTransferDataObj,
			Map<Long, String> toCcGrpIdMap, Long fromGroupId, boolean isMakerCheckerEnabled, String action, List<Long> resolveAllGroupList, List<ConversationRecipient> recipientsList)
			throws CommunicatorException {

		// Create Outbox workflow for From Group
		createOutBoxWorkFlow(inquiry, workflowList, workflowTransferDataObj, fromGroupId, soeId, action, currentTime, isMakerCheckerEnabled, null, null, 0, null, recipientsList);
		Workflow fromWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_OUT);
		changeModDateForInWorkFlow(workflowList, currentTime);

		String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
		if (fromWorkflow != null && (inquiry.getAction().equals(ACTION_NEW_RESOLVE)))
		{

			resolveWorkflow(soeId, currentTime, fromWorkflow, userName);
			//check if IN workflow is present then 
			Workflow inWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_IN);
			if(null != inWorkflow) {
				calculateResolutionTime(inWorkflow, null, currentTime);
			}

		}
		else if (resolveAllGroupList != null && !resolveAllGroupList.isEmpty() && (ACTION_NEW_RESOLVE.equals(inquiry.getAction())))
		{
			resolveWorkflowForGroupIds(soeId, currentTime, resolveAllGroupList, userName, workflowList);
		}
		return workflowList;
	}

	private boolean isEmailSentToExternal(List<ConversationRecipient> recipients)
	{
		boolean isEmailSentToExternal = false;

//		if (CollectionUtils.isNotEmpty(recipients))
		if (recipients!=null && !recipients.isEmpty())
		{
			for (ConversationRecipient recipient : recipients)
			{
				if (recipient != null && (TO_CATEGORY + CC_CATEGORY + BCC_CATEGORY).contains(recipient.getToFrom()))
				{
					isEmailSentToExternal = recipient.getEmailAddr() != null && !GenericUtility.isCitiDomainEmail(recipient.getEmailAddr());
					if(isEmailSentToExternal)
					{
						break;
					}
				}
			}
		}
		return isEmailSentToExternal;
	}

	// createWorkflowsForEditActions used for Reply,ReplyAll,ReplyResolve,ReplyAllResolve/Forward Flows
	private List<Workflow> createWorkflowsForEditActions(Inquiry inquiry, String soeId, Date currentTime, Workflow workflowTransferDataObj, Map<Long, String> toCcGrpIdMap, Long fromGroupId,
			boolean isMakerCheckerEnabled, String action, List<Long> resolveAllGroupList, List<ConversationRecipient> recipientsList) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic
	// one
	{
		List<Workflow> workflowList = new ArrayList<Workflow>(0);
		Date latestConversationTime = null;
		workflowList.addAll(inquiry.getWorkflows());
		Workflow fromWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_IN);

		changeModDateForInWorkFlow(workflowList, currentTime);
		boolean isHoldFromGrpVersion = true;
		// Reopendate variable to hold the value to be passed to Outbox workflow
		Date reOpenDate = null;
		Long linkId = null;
		int convCount = 0;
		String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
		Date oldestConvDate = getOldestWorkflowCrtDate(fromGroupId, workflowList);

		String resolveRootCause = null;
		String resolveProcessingRegion = null;
		Long queryCount = null;
		String inquirySource = null;
		String tag = null;
		Date originDate = null;
		String isLastConvToExtEmail = "N";
		FollowUp followUp = null;
		String isManualEscalation = null;
		String manualEscalationReason = null;

		if (null != oldestConvDate)
		{
			latestConversationTime = oldestConvDate;
		}

		if (workflowTransferDataObj != null)
		{
			resolveRootCause = workflowTransferDataObj.getRootCause();
			resolveProcessingRegion = workflowTransferDataObj.getProcessingRegion();
			queryCount = workflowTransferDataObj.getQueryCount();
			inquirySource = workflowTransferDataObj.getInquirySource();
			workflowTransferDataObj.setLatestConversationTime(latestConversationTime);
			isLastConvToExtEmail = workflowTransferDataObj.getIsLastConvToExtEmail();
			tag = workflowTransferDataObj.getTag();
			if((null == tag || tag.isEmpty()) && null!= fromWorkflow)
			{
				tag = fromWorkflow.getTag();
				workflowTransferDataObj.setTag(tag);
			} 
			followUp = workflowTransferDataObj.getFollowUp();
			isManualEscalation = workflowTransferDataObj.getIsManualEscalation();
			manualEscalationReason = workflowTransferDataObj.getManualEscalationReason();
		}
		if (fromWorkflow != null)
		{

			workflowTransferDataObj.setLock(fromWorkflow.getLock());
			workflowTransferDataObj.setLock(fromWorkflow.getLock());
			workflowTransferDataObj.setLockedBy(fromWorkflow.getLockedBy());
			workflowTransferDataObj.setLockedDate(fromWorkflow.getLockedDate());
			workflowTransferDataObj.setWorkflowStatus(fromWorkflow.getWorkflowStatus());
			workflowTransferDataObj.setReAgeDate(fromWorkflow.getReAgeDate());
			workflowTransferDataObj.setCrtDate(fromWorkflow.getCrtDate());
			workflowTransferDataObj.setCrtBy(fromWorkflow.getCrtBy());
			workflowTransferDataObj.setIsManualEscalation(fromWorkflow.getIsManualEscalation());
			workflowTransferDataObj.setManualEscalationReason(fromWorkflow.getManualEscalationReason());
			workflowTransferDataObj.setSuggestionIndicator(fromWorkflow.getSuggestionIndicator());
			workflowTransferDataObj.setIntentSuggestionName(fromWorkflow.getIntentSuggestionName());
			workflowTransferDataObj.setUserIntentSuggestionName(fromWorkflow.getUserIntentSuggestionName());
			workflowTransferDataObj.setIntentTimeToVD(fromWorkflow.getIntentTimeToVD());
			workflowTransferDataObj.setReOpenDate(fromWorkflow.getReOpenDate());
			// C153176-5891 | Set the firstNonChaserResponseTimeByExternal from fromGroup. As we sending the mail from QMA set isLatestResponseFromNonQMA to 'N'
			workflowTransferDataObj.setFirstNonChaserResponseTimeByExternal(fromWorkflow.getFirstNonChaserResponseTimeByExternal());
			workflowTransferDataObj.setIsLatestResponseFromNonQMA("N");
			fromWorkflow.setIsLatestResponseFromNonQMA("N");
			
			linkId=fromWorkflow.getLinkId();
			convCount=fromWorkflow.getConvCount();
			subLogger.info("CreateWorkflow.fromWorkflow ConvCount is: "+convCount);
			originDate=fromWorkflow.getOriginDate();
			fromWorkflow.setLastActionby(userName);
			fromWorkflow.setLastActionTime(currentTime);
			// [C153176-774] - Root cause drop down for resolve
			if (!StringUtils.isBlank(resolveRootCause))
			{
				fromWorkflow.setRootCause(resolveRootCause);
			}

			// [C153176-774] - Root cause drop down for resolve
			if (!StringUtils.isBlank(resolveProcessingRegion))
			{
				fromWorkflow.setProcessingRegion(resolveProcessingRegion);
			}
			if (queryCount != null)
			{
				fromWorkflow.setQueryCount(queryCount);
			}
			// [C153176-854] - Add new drop-down: Inquiry Source
			if (!StringUtils.isBlank(inquirySource))
			{
				fromWorkflow.setInquirySource(inquirySource);
			}
			if (StringUtils.isNotBlank(isLastConvToExtEmail))
			{
				fromWorkflow.setIsLastConvToExtEmail(isLastConvToExtEmail);
			}
			if(StringUtils.isNotBlank(tag))
			{
				fromWorkflow.setTag(tag);
			}
			if(!StringUtils.isBlank(isManualEscalation))
			{
				fromWorkflow.setIsManualEscalation(isManualEscalation);
			}
			if(!StringUtils.isBlank(manualEscalationReason))
			{
				fromWorkflow.setManualEscalationReason(manualEscalationReason);
			}
			if(null != followUp)
			{
				fromWorkflow.setFollowUp(followUp);
			}
			//set resolve allocation
			if(null != workflowTransferDataObj && StringUtils.isNotBlank(workflowTransferDataObj.getResolveAllocation())) {
				fromWorkflow.setResolveAllocation(workflowTransferDataObj.getResolveAllocation());
			}
		}
		// C153176-1055 -- Assign to user who has taken action on Inquiry/WF 
		if (ACTION_REPLY_ALL.equals(inquiry.getAction()) || ACTION_REPLY.equals(inquiry.getAction()) || ACTION_FORWARD.equals(inquiry.getAction()) || TASKIZE_UPDATE_ACTION.equalsIgnoreCase(inquiry.getAction()))
		{
			updateAssignedUser(soeId, fromWorkflow);
		}

		if (fromWorkflow != null && (inquiry.getAction().equals(ACTION_REPLY_RESOLVE) || inquiry.getAction().equals(ACTION_REPLYALL_RESOLVE)))
		{
			isHoldFromGrpVersion = false;
			resolveWorkflow(soeId, currentTime, fromWorkflow, userName);

		}
		else if (resolveAllGroupList != null && !resolveAllGroupList.isEmpty() && (ACTION_REPLY_RESOLVE_ALL.equals(inquiry.getAction()) || ACTION_REPLYALL_RESOLVE_ALL.equals(inquiry.getAction())))
		{

			resolveWorkflowForGroupIds(soeId, currentTime, resolveAllGroupList, userName, workflowList);
		}

		// reply to self only
		if (toCcGrpIdMap.keySet().contains(fromGroupId) && toCcGrpIdMap.size() == 1)
		{
			createOutBoxWorkFlow(inquiry, workflowList, workflowTransferDataObj, fromGroupId, soeId,action, currentTime, isMakerCheckerEnabled,reOpenDate,linkId,convCount, originDate, recipientsList);
			return workflowList;
		}

		// reopen resolved versions in the reply list
		reopenResolvedWorkflowsInToCcList(workflowList, toCcGrpIdMap.keySet(), fromGroupId, currentTime, soeId, inquiry.getAction());

		// Reply Including from Group-No Need to create workflow if the inbox version already exists
		//toCcGrpIdMap map is for creating Inbox version		
		if (fromWorkflow != null && toCcGrpIdMap.keySet().contains(fromGroupId)) {		
			isHoldFromGrpVersion = false;
			toCcGrpIdMap.remove(fromGroupId);	
			subLogger.info("IN version removed for FromGroupId");
		}

		// reply to external only .e no internal grousp involved, so no workflow
		// needs to be created
		if (toCcGrpIdMap.size() == 0 && isHoldFromGrpVersion) {
			createOutBoxWorkFlow(inquiry, workflowList, workflowTransferDataObj, fromGroupId, soeId, action,
					currentTime, isMakerCheckerEnabled, reOpenDate, linkId, convCount, originDate, recipientsList);
			// Just Rearranged the code, as we refer IN Version data incase of
			// self inquiry
			workflowList.remove(fromWorkflow);
			return workflowList;
		}

		// New Groups who needs inbox workflow
		Set<Long> grpsNeedNewWorkflow = getGrpIdsNeedNewWorkflow(workflowList, toCcGrpIdMap.keySet()/* ,isEmailRoutedFromInternal */);

		if (isHoldFromGrpVersion && fromWorkflow != null)
		{
			if (!grpsNeedNewWorkflow.isEmpty())
			{
				Long grpId = (Long) grpsNeedNewWorkflow.toArray()[0];
				fromWorkflow.setStatus(STATUS_OPEN);
				fromWorkflow.setAssignedGroupId(grpId);
				fromWorkflow.setAssignedGroupName(QMACacheFactory.getCache().getGroupIdToNameMap().get(grpId));
				fromWorkflow.setCrtBy(soeId);
				fromWorkflow.setCrtDate(currentTime);
				fromWorkflow.setRequestType(null);
				fromWorkflow.setAssignedUserId(null);
				fromWorkflow.setAssignedUserName(null);
				fromWorkflow.setRootCause(null);
				fromWorkflow.setProcessingRegion(null);
				fromWorkflow.setQueryCount(null);
				fromWorkflow.setStage(null);
				// Release 1.2 changes-Add action in the workflow
				fromWorkflow.setAction(null);
			
				reOpenDate = fromWorkflow.getReOpenDate();
				// linkId=fromWorkflow.getLinkId();
				fromWorkflow.setReOpenDate(null);
				fromWorkflow.setLinkId(null);
				fromWorkflow.setLock(null);
				fromWorkflow.setLockedBy(null);
				fromWorkflow.setLockedDate(null);
				fromWorkflow.setConvCount(0);
				fromWorkflow.setLastActionby(userName);
				fromWorkflow.setLastActionTime(currentTime);
				fromWorkflow.setResolver("");
				fromWorkflow.setResolveTime(null);
				fromWorkflow.setLatestConversationTime(currentTime);
				fromWorkflow.setResponseTimeQMA(null);
				fromWorkflow.setReplyCountQMA(null);
				fromWorkflow.setTag(null);
				fromWorkflow.setTotalResolveTimeQMA(null);
				fromWorkflow.setResolveCountQMA(null);
				fromWorkflow.setIsLastConvToExtEmail(null);
				fromWorkflow.setClientChaseCounter(null);
				if(isInquirySubStatusEnabled(grpId)) {
					fromWorkflow.setInquirySubStatus(SUB_STATUS_NEW);
				}
				
				fromWorkflow.setIsSubjectEscalation(null);
				fromWorkflow.setResponseTimeEscalationFlag(null);
				fromWorkflow.setResponseTimeNextEscalation(null);
				fromWorkflow.setResponseTimeEscalationReason(null);
				fromWorkflow.setIsManualEscalation(null);
				fromWorkflow.setManualEscalationReason(null);
				fromWorkflow.setLatestClientChaseCounter(null);
				fromWorkflow.setOriginDate(currentTime);
				fromWorkflow.setFollowUp(followUp);
				fromWorkflow.setWorkflowStatus(null);
				fromWorkflow.setReAgeDate(null);
				//[C153176-1270] - Add Escalation criteria for 'Pending Approval' emails
				fromWorkflow.setIspendingApprovalEscalation(null);
				
				// C153176-5354 | Panorama feed
				fromWorkflow.setFirstResponseTime(null);
				fromWorkflow.setFirstResponseInMinutes(null);
				fromWorkflow.setResponseTimeInMinutes(null);
				fromWorkflow.setResolutionTimeInMinutes(null);
				
				// C153176-5891 | Average response time not calculated correctly
				fromWorkflow.setCitiResponseTime(null);
				fromWorkflow.setCitiReplyCountFromQMA(null);
				
				// C153176-5977 | Nominate ownership : Resolution time getting considered from the time of ownership requested
				fromWorkflow.setOwnershipAcceptedTime(null);
				
				copyOutVerDetailsToIn(fromWorkflow, workflowList, grpId);
				grpsNeedNewWorkflow.remove(grpId);

			}
			else
			{
				workflowList.remove(fromWorkflow);
			}
		}
		for (Long grpId : grpsNeedNewWorkflow)
		{
			Workflow verDO = createNewWorkflowForInquiry(grpId, INQUIRY_DIRECTION_IN, action, workflowTransferDataObj, soeId, currentTime, recipientsList, inquiry.getLatestGroupId());
			// if externalEmail is present then set to setIsLastConvToExtEmail = Y.
			// If any prior workflow is present copyOutVerDetailsToIn method then setIsLastConvToExtEmail will be reset to existing value.
			verDO.setIsLastConvToExtEmail( isEmailSentToExternal(recipientsList) ? "Y" : "N");
			
			copyOutVerDetailsToIn(verDO, workflowList, grpId);
			workflowList.add(verDO);
		}

		// Create Outbox workflow for From Group
		createOutBoxWorkFlow(inquiry, workflowList, workflowTransferDataObj, fromGroupId, soeId,action, currentTime, isMakerCheckerEnabled,reOpenDate,linkId,convCount, originDate, recipientsList );
		return workflowList;
	}

	/**
	 * This method used to convert non inquiry to inquiry when inquiry action ! New Inquiry
	 * @param workflowList
	 * @param soeId 
	 * @param fromGroupId 
	 * @param soeId
	 * @param inquiryId 
	 * @param inquiryId 
	 */
	public boolean removeAutoAssignmentNonInquiryFlag(List<Workflow> workflowList, Long fromGroupId, String soeId, Long inquiryId) {
		boolean autoAssigned = false;
		try {
			NLPSuggestionDAO nlpSuggestionDao = new NLPSuggestionDAO();
			for (Workflow workflow : workflowList) {
				if (null != workflow.getRulesFlag() && null != workflow.getAssignedGroupId() && workflow.getAssignedGroupId().equals(fromGroupId)) {
					RulesFlag rulesFlag = workflow.getRulesFlag();
					if (null != rulesFlag && rulesFlag.getMarkAsNonInquiry()
							&& NLPConstants.AUTO_ASSIGNMENT_RULE.equalsIgnoreCase(rulesFlag.getRuleType())) {
						workflow.setRulesFlag(null);
						workflow.setModBy(soeId);
						workflow.setModDate(new Date());
						workflow.setAutoAssigned(NLPConstants.REVOKED);
						workflow.setAutoAssignedAction(NLPConstants.REVOKE_REPLY +" "+soeId);
					}
				}
				if( NLPConstants.YES.equals(workflow.getAutoAssigned())) {
					autoAssigned = true;
				}
			}
			
			if(!autoAssigned) {
				nlpSuggestionDao.updateConversationAutoAssignFlag(inquiryId, NLPConstants.REVOKED);
			}
		} catch (Exception e) {
			subLogger.error("Exception while removing auto-assigned workflows",e);
		}
		return autoAssigned;
	}

	/**
	 * This method used to revoke auto assigned inquiries [processedFlag=true]
	 * @param assignedGroupId
	 * @param inquiryId
	 * @param fromGroupId 
	 */
	public void revokeAutoAssign(Long inquiryId) {
		try {
			DBCollection inquiryCollection = mongoDatastore.getCollection(AutoAssignedInquiry.class);
			BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();
			DBObject findINQuery = new BasicDBObject();
			findINQuery.put(PROCESSED_FLAG, false);
			findINQuery.put(INQUIRY_ID, inquiryId);
			DBObject updateDBObj = new BasicDBObject();
			DBObject updateDBFields = new BasicDBObject();
			updateDBObj.put(PROCESSED_FLAG, true);
			updateDBFields.put("$set", updateDBObj);
			bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);
			bulkInquiryUpdOp.execute();
		} catch (Exception e) {
			subLogger.error("Error while updating auto assigned details", e);
		}
	}

	private void updateAssignedUser(String soeId, Workflow fromWorkflow)
	{		
		try{
			if(null!= fromWorkflow && null != fromWorkflow.getAssignedGroupId())
			{
				boolean isUserActiveAndInOffice = isUserActiveAndInOffice(soeId);
				Long unAssignedTime = calculateUnassignedTime(fromWorkflow);
				if (null != unAssignedTime) {
					fromWorkflow.setUnassignedTimeInMins(unAssignedTime);
				}
				String assignGroupName = QMACacheFactory.getCache().getGroupIdToNameMap().get(fromWorkflow.getAssignedGroupId());
				String assignUserName = getAssignUserName(soeId, assignGroupName);
				if (isUserActiveAndInOffice) {
					fromWorkflow.setAssignedUserId(soeId);
					fromWorkflow.setAssignedUserName(assignUserName);	
				} else {
					fromWorkflow.setAssignedUserId(null);
					fromWorkflow.setAssignedUserName(null);
				} 
			}
		}catch(CommunicatorException ex)
		{
			subLogger.error(" Error while updating AssignedUser:" + ex );
		}

	}

	private void resolveWorkflowForGroupIds(String soeId, Date currentTime, List<Long> groupIdList, String userName, List<Workflow> workflowList) throws CommunicatorException
	{
		for (Long groupId : groupIdList)
		{
			resolveWorkflowForGroupId(soeId, currentTime, groupId, userName, workflowList);
		}
	}

	private void resolveWorkflowForGroupId(String soeId, Date currentTime, long groupId, String userName, List<Workflow> workflowList) throws CommunicatorException
	{
		Workflow inWorkflow = getWorkflow(workflowList, groupId, INQUIRY_DIRECTION_IN);
		if (null != inWorkflow)
		{
			resolveWorkflow(soeId, currentTime, inWorkflow, userName);
		}
		Workflow outWorkflow = getWorkflow(workflowList, groupId, INQUIRY_DIRECTION_OUT);
		if (null != outWorkflow)
		{
			resolveWorkflow(soeId, currentTime, outWorkflow, userName);
		}
	}

	private void resolveWorkflow(String soeId, Date currentTime, Workflow workflow, String userName) throws CommunicatorException
	{
		boolean isUserActiveAndInOffice = isUserActiveAndInOffice(soeId);
		workflow.setStatus(STATUS_RESOLVE);
		//Set followup flag null on action Reply Resolve
		workflow.setFollowUp(null);
		Long unAssignedTime = calculateUnassignedTime(workflow);
		if (null != unAssignedTime) {
			workflow.setUnassignedTimeInMins(unAssignedTime);
		}
		if (isUserActiveAndInOffice) {
			workflow.setAssignedUserId(soeId);
			String assignGroupName = QMACacheFactory.getCache().getGroupIdToNameMap().get(workflow.getAssignedGroupId());
			String assignUserName = getAssignUserName(soeId, assignGroupName);
			workflow.setAssignedUserName(assignUserName);	
		} else {
			workflow.setAssignedUserId(null);
			workflow.setAssignedUserName(null);	
		}

		calculateResolutionTime(workflow, null, currentTime);

		// Reset reopen date.
		//workflow.setReOpenDate(null);
		workflow.setResolver(userName);
		workflow.setResolveTime(currentTime);

		//	reset escalation fields to null.
		if(null !=workflow.getResponseTimeNextEscalation())
		{
			workflow.setResponseTimeEscalationFlag(null);
			workflow.setResponseTimeNextEscalation(null);
			workflow.setResponseTimeEscalationReason(null);
			// [C153176-1270] - Add Escalation criteria for 'Pending Approval' emails
			workflow.setIspendingApprovalEscalation(null);
		}
		// [C153176-1694] - reset Acknowledge escalation fields to null
		if (null != workflow.getIsAckEscalation())
		{
			workflow.setIsAckEscalation(null);
			workflow.setAckEscalationBy(null);
			workflow.setAckEscalationTime(null);
		}
		// reset lock fields to null.
		if(null !=workflow.getLock())
		{
			workflow.setLock(null);
			workflow.setLockedBy(null);
			workflow.setLockedDate(null);
		}

	}

	// changes for change mod date for all existing workflow in inquiry
	private void changeModDateForInWorkFlow(List<Workflow> workflowList, Date currentTime)
	{
		for (Workflow inqWorkflow : workflowList)
		{
			if (inqWorkflow.getDirection() != null)
			{
				inqWorkflow.setModDate(currentTime);
			}

		}
	}

	
	private void copyOutVerDetailsToIn(Workflow inVersion, List<Workflow> workflowList, Long grpId)
	{
		Workflow outWorkflowForNewGroup = getWorkflow(workflowList, grpId, INQUIRY_DIRECTION_OUT);
		Workflow pndWorkflowForNewGroup = getWorkflow(workflowList, grpId, INQUIRY_DIRECTION_PENDING_APPROVAL);
		Workflow pndReageWorkflowForNewGroup = getWorkflow(workflowList, grpId, INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE);
		if (outWorkflowForNewGroup != null){
			syncWorkflowData(inVersion, outWorkflowForNewGroup);
		}else if (pndWorkflowForNewGroup != null){
			syncWorkflowData(inVersion, pndWorkflowForNewGroup);
		}else if (pndReageWorkflowForNewGroup != null){
			syncWorkflowData(inVersion, pndReageWorkflowForNewGroup);
		}
	}

	private void syncWorkflowData(Workflow inVersion, Workflow outWorkflowForNewGroup)
	{
		if (outWorkflowForNewGroup != null && !StringUtils.isBlank(outWorkflowForNewGroup.getAssignedUserName()))
		{
			boolean isUserActiveAndInOffice = isUserActiveAndInOffice(outWorkflowForNewGroup.getAssignedUserId());
			if (isUserActiveAndInOffice) {
				inVersion.setAssignedUserId(outWorkflowForNewGroup.getAssignedUserId());
				inVersion.setAssignedUserName(outWorkflowForNewGroup.getAssignedUserName());
			} else {
				inVersion.setAssignedUserId(null);
				inVersion.setAssignedUserName(null);
			}
		}
		if (outWorkflowForNewGroup != null)
		{
			// If there's already an out workflow for the same group, copy the reopen date to in workflow
			inVersion.setReOpenDate(outWorkflowForNewGroup.getReOpenDate());
			// [C153176-774] - Root cause for reaply/reply all resolve
			if (!StringUtils.isBlank(outWorkflowForNewGroup.getRootCause()))
			{
				inVersion.setRootCause(outWorkflowForNewGroup.getRootCause());
			}

			// [C153176-793] Add Processing Region as a drop-down in Group Admin screen
			if (!StringUtils.isBlank(outWorkflowForNewGroup.getProcessingRegion()))
			{
				inVersion.setProcessingRegion(outWorkflowForNewGroup.getProcessingRegion());
			}

			if (null != outWorkflowForNewGroup.getResponseTimeQMA())
			{
				inVersion.setResponseTimeQMA(outWorkflowForNewGroup.getResponseTimeQMA());
			}
			if (null != outWorkflowForNewGroup.getReplyCountQMA())
			{
				inVersion.setReplyCountQMA(outWorkflowForNewGroup.getReplyCountQMA());
			}
			if (null != outWorkflowForNewGroup.getTotalResolveTimeQMA())
			{
				inVersion.setTotalResolveTimeQMA(outWorkflowForNewGroup.getTotalResolveTimeQMA());
			}
			if (null != outWorkflowForNewGroup.getResolveCountQMA())
			{
				inVersion.setResolveCountQMA(outWorkflowForNewGroup.getResolveCountQMA());
			}

			inVersion.setQueryCount(outWorkflowForNewGroup.getQueryCount());
			if (!StringUtils.isBlank(outWorkflowForNewGroup.getInquirySource()))
			{
				inVersion.setInquirySource(outWorkflowForNewGroup.getInquirySource());
			}
			
			//[C170665-1719] DCC Requirement: Add Case status field
			if (!StringUtils.isBlank(outWorkflowForNewGroup.getInquirySubStatus()) && isInquirySubStatusEnabled(outWorkflowForNewGroup.getAssignedGroupId()))
			{
				inVersion.setInquirySubStatus(outWorkflowForNewGroup.getInquirySubStatus());
			}
			if (!StringUtils.isBlank(outWorkflowForNewGroup.getPrevInqSubStatus()))
			{
				inVersion.setPrevInqSubStatus(outWorkflowForNewGroup.getPrevInqSubStatus());
			}
			
			if (!StringUtils.isBlank(outWorkflowForNewGroup.getTag()))
			{
				inVersion.setTag(outWorkflowForNewGroup.getTag());
			}
			if (outWorkflowForNewGroup.getClientChaseCounter() != null)
			{
				inVersion.setClientChaseCounter(outWorkflowForNewGroup.getClientChaseCounter());
			}
			if (outWorkflowForNewGroup.getLatestClientChaseCounter() != null)
			{
				inVersion.setLatestClientChaseCounter(outWorkflowForNewGroup.getLatestClientChaseCounter());
			}
			if (outWorkflowForNewGroup.getOriginDate() != null)
			{
				inVersion.setOriginDate(outWorkflowForNewGroup.getOriginDate());
			}
			if (outWorkflowForNewGroup.getIsManualEscalation() != null)
			{
				inVersion.setIsManualEscalation(outWorkflowForNewGroup.getIsManualEscalation());
			}
			if (outWorkflowForNewGroup.getManualEscalationReason() != null)
			{
				inVersion.setManualEscalationReason(outWorkflowForNewGroup.getManualEscalationReason());
			}
			if (outWorkflowForNewGroup.getSuggestionIndicator() != null)
			{
				inVersion.setSuggestionIndicator(outWorkflowForNewGroup.getSuggestionIndicator());
			}
			if (outWorkflowForNewGroup.getIntentSuggestionName() != null)
			{
				inVersion.setIntentSuggestionName(outWorkflowForNewGroup.getIntentSuggestionName());
			}
			if (outWorkflowForNewGroup.getUserIntentSuggestionName() != null)
			{
				inVersion.setUserIntentSuggestionName(outWorkflowForNewGroup.getUserIntentSuggestionName());
			}
			if (outWorkflowForNewGroup.getIntentTimeToVD() != null)
			{
				inVersion.setIntentTimeToVD(outWorkflowForNewGroup.getIntentTimeToVD());
			}
			inVersion.setCrtBy(outWorkflowForNewGroup.getCrtBy());
			inVersion.setCrtDate(outWorkflowForNewGroup.getCrtDate());
			inVersion.setWorkflowStatus(outWorkflowForNewGroup.getWorkflowStatus());
			inVersion.setReAgeDate(outWorkflowForNewGroup.getReAgeDate());
			if (StringUtils.isNotBlank(outWorkflowForNewGroup.getIsLastConvToExtEmail()))
			{
				inVersion.setIsLastConvToExtEmail(outWorkflowForNewGroup.getIsLastConvToExtEmail());
			}
			if (StringUtils.isNotBlank(outWorkflowForNewGroup.getInquiryRefSent()))
			{
				inVersion.setInquiryRefSent(outWorkflowForNewGroup.getInquiryRefSent());
			}
			
			// C153176-5354 | Panorama feed
			if (null != outWorkflowForNewGroup.getFirstResponseTime()) {
				inVersion.setFirstResponseTime(outWorkflowForNewGroup.getFirstResponseTime());
			}
			
			if (null != outWorkflowForNewGroup.getFirstResponseInMinutes()) {
				inVersion.setFirstResponseInMinutes(outWorkflowForNewGroup.getFirstResponseInMinutes());
			}
			
			if (null != outWorkflowForNewGroup.getResponseTimeInMinutes()) {
				inVersion.setResponseTimeInMinutes(outWorkflowForNewGroup.getResponseTimeInMinutes());
			}
			
			if(null != outWorkflowForNewGroup.getResolutionTimeInMinutes()) {
				inVersion.setResolutionTimeInMinutes(outWorkflowForNewGroup.getResolutionTimeInMinutes());
			}
			
			// C153176-5891 | Average response time not calculated correctly
			if (null != outWorkflowForNewGroup.getIsLatestResponseFromNonQMA()) {
				inVersion.setIsLatestResponseFromNonQMA(outWorkflowForNewGroup.getIsLatestResponseFromNonQMA());
			}

			if (null != outWorkflowForNewGroup.getFirstNonChaserResponseTimeByExternal()) {
				inVersion.setFirstNonChaserResponseTimeByExternal(outWorkflowForNewGroup.getFirstNonChaserResponseTimeByExternal());
			}

			if (null != outWorkflowForNewGroup.getCitiResponseTime()) {
				inVersion.setCitiResponseTime(outWorkflowForNewGroup.getCitiResponseTime());
			}
			
			if (null != outWorkflowForNewGroup.getCitiReplyCountFromQMA()) {
				inVersion.setCitiReplyCountFromQMA(outWorkflowForNewGroup.getCitiReplyCountFromQMA());
			}
			
			// C153176-5977 | Nominate ownership : Resolution time getting considered from the time of ownership requested
			if(null != outWorkflowForNewGroup.getOwnershipAcceptedTime()) {
				inVersion.setOwnershipAcceptedTime(outWorkflowForNewGroup.getOwnershipAcceptedTime());
			}
		}
		inVersion.setConvCount(outWorkflowForNewGroup != null ? outWorkflowForNewGroup.getConvCount() : 0);
	}

	public Conversation createConversation(BasicDBObject inputJsonObj, String content, Long inquiryId, Inquiry dbInquiry , String soeId, Date currentTime) throws CommunicatorException
	{

		String action = dbInquiry.getAction();
		List<ConversationRecipient> recipientList = createRecipients(inputJsonObj, soeId);
		
		//C153176-1910:Add new DL for Global coverage : *ICG US Global Client Service (for ETF Settlements & Client Services)
		LinkedHashSet<ConversationRecipient> hSet = new LinkedHashSet<ConversationRecipient>(recipientList); 
        recipientList.addAll(GenericDAO.addAutoFwdRecipients(hSet));
       
		String urgentFlag = inputJsonObj.getString(URGENT_FLAG);
		boolean makerCheckerRqd = inputJsonObj.getBoolean(MAKER_CHECKER_REQUIRED);
		String cntn = content;// Sonar Fix -- Introduce a new variable instead of reusing the parameter

		Conversation conversation = new Conversation();
		conversation.setInquiryId(inquiryId);
		conversation.setSubject(inputJsonObj.getString(SUBJECT));
		conversation.setRecipients(recipientList);

		cntn = GenericUtility.updateContentWithImages(cntn, soeId);

		conversation.setContent(cntn);
		conversation.setUrgentFlag(urgentFlag);
		conversation.setAction(action);

		conversation.setNLPDataStampedAtConv(true);
		conversation.setSuggestionAvailable(false);
		conversation.setAutoAssignmentAvailable(false);
		
		conversation.setAttachments(getAttachmentsInfo(inputJsonObj));

		if (makerCheckerRqd)
		{
			String approvalBypassed = inputJsonObj.getString(APPROVAL_BYPASSED);
			conversation.setApprovalBypassed(approvalBypassed);

		}

		conversation.setModBy(soeId);
		conversation.setModDate(currentTime);

		// populate audFlag - audFlag can INTERNAL or EXTERNAL or BOTH
		boolean internalFlag = false;
		boolean enternalFlag = false;

		// sonar complies for this null check on recipientList, b'coz 'not null' check on recipientList always evaluates to true
		// recipientList never be null, so null check is not performed,
		for (ConversationRecipient recipient : recipientList)
		{
			if ("CC".equals(recipient.getToFrom()) || "TO".equals(recipient.getToFrom()) || "BCC".equals(recipient.getToFrom()))
			{
				if (null != recipient.getEmailAddr() && !GenericUtility.isCitiDomainEmail(recipient.getEmailAddr().trim()))
				{
					enternalFlag = true;
				}
				else
				{
					internalFlag = true;
				}
			}
		}

		if (internalFlag && enternalFlag)
		{
			conversation.setAudFlag("BOTH");
		}
		else if (internalFlag)
		{
			conversation.setAudFlag("INTERNAL");
		}
		else
		{
			conversation.setAudFlag("EXTERNAL");
		}

		String memo = inputJsonObj.getString(MEMO);
		if (!StringUtils.isBlank(memo))
		{
			conversation.setMemo(memo);
		}
		//add bubbleContent and parentConversationId
		addBubbleContentAndParentConvId(inputJsonObj, cntn, conversation);
		
		updateNominatedRecipients(conversation,dbInquiry);
		
	
		List<Long> groupIds = new ArrayList<Long>();
		for (ConversationRecipient recipient : recipientList) {
			if (!FROM_CATEGORY.equalsIgnoreCase(recipient.getToFrom())){
			Long groupId = recipient.getGroupId();
			groupIds.add(groupId);
		}
		}
		for(Long groupId : groupIds) {
			subLogger.info("Inside InquiryDao Create conversation :" + groupId);
			InquiryExtendedDAO.getInstance()
			.updateConversationContentPreviewInTO(conversation,dbInquiry, groupId,false);
		}
		
		Long conversationId = persist(conversation);
		subLogger.info("conversationId" + conversationId);

		return conversation;

	}
	
	/**
	 * This method updates nominated recipient in the converation.
	 * @param conversation
	 * @param dbInquiry
	 */
	private void updateNominatedRecipients(Conversation conversation, Inquiry dbInquiry) {
		
		try {
			if( null != dbInquiry && null != dbInquiry.getWorkflows() && null != conversation && null != conversation.getRecipients()) {
				for (Workflow workflow : dbInquiry.getWorkflows()){
					for (ConversationRecipient recipient : conversation.getRecipients()) {
						if (null!=recipient && ("CC".equals(recipient.getToFrom()) || "TO".equals(recipient.getToFrom())) 
								&& null != recipient.getGroupId() && recipient.getGroupId().equals(workflow.getAssignedGroupId())) {
							updatedNominatedRecipient(workflow, conversation);
							break;
						}
					}
				}
			} else {
				subLogger.warn("Either 'conversation' or 'conversation.getRecipients()' or 'dbInquiry' is null.");
			}
		} catch (Exception e) {
			subLogger.warn("Exception while updating nominated recipient for inquiry :{} and conversation :{} : ",
					dbInquiry.getId(), conversation.getId(),e);
		}
	}

	private void updatedNominatedRecipient(Workflow workflow,Conversation currentConv) {
		try {
			subLogger.info("Workflow scanning started for nominated ownership.");
			if(null != workflow.getNominatedTo() && !workflow.getNominatedTo().isEmpty()){
				subLogger.info("Workflow contains nominated recipient, it need to be added to latest conversation");
				updateConversationWithNominatedRecipient(currentConv, workflow.getNominatedTo());
			}
			
		} catch (Exception e) {
			subLogger.error("Exception while evaluated nominated recipient : ", e);
		}
	}
	
	/**
	 * This method identifies existing nominated recipient and if not found, add the new recipient.
	 * @param currentConv
	 * @param nominatedToGrpIds
	 * @throws CommunicatorException
	 */
	private void updateConversationWithNominatedRecipient(Conversation currentConv, List<Long> nominatedToGrpIds) throws CommunicatorException {
		
		if( null != currentConv && null != nominatedToGrpIds && !nominatedToGrpIds.isEmpty() ) {
			subLogger.info("'nominatedToGrpIds' is not null or not empty. scanning through all nominatedTo group id's");
			for(Long nominatedToGrpId : nominatedToGrpIds){
				ConversationRecipient existingNominatedRecipient = getExistingRecipientFromNominatedRecipientsList(currentConv, nominatedToGrpId);
				if(null == existingNominatedRecipient) {
					subLogger.info("'Nomiated recipient not found for the group : {} in the current list of nominated recipient for conv : {}"
							, nominatedToGrpId, currentConv.getId());
					Group group =QMACacheFactory.getCache().getAllGroupsMap().get(nominatedToGrpId);
					if(null != group){
						subLogger.info("'Group found in cache for the group : {}'", nominatedToGrpId);
						ConversationRecipient nominatedRecipient = new ConversationRecipient();
						nominatedRecipient.setGroupId(nominatedToGrpId);
						nominatedRecipient.setDisplayName(group.getGroupName());
						nominatedRecipient.setEmailAddr(group.getGroupEmail());
						nominatedRecipient.setToFrom("TO");
						
						if(null == currentConv.getNominatedRecipients()) {
							currentConv.setNominatedRecipients(new ArrayList<>());
						}
						currentConv.getNominatedRecipients().add(nominatedRecipient);
					}
				} else {
					subLogger.info("Nominated recipient already exists.");
				}
			}
		}
	}
	
	/**
	 * This method identifies existing nominated recipient
	 * @param conversation
	 * @param nominatedGroupId
	 * @return
	 */
	private ConversationRecipient getExistingRecipientFromNominatedRecipientsList(Conversation conversation, Long nominatedGroupId) {
		ConversationRecipient existingRecipient = null;
		if(null != conversation && null != conversation.getNominatedRecipients() && !conversation.getNominatedRecipients().isEmpty()){
			for(ConversationRecipient recipient : conversation.getNominatedRecipients()){
				if(null != recipient && null != recipient.getGroupId() && recipient.getGroupId().longValue() == nominatedGroupId ){
					existingRecipient = recipient;
					break;
				}
			}
		}
		return existingRecipient;
	}

	private void addBubbleContentAndParentConvId(BasicDBObject inputJsonObj, String content, Conversation conversation){
		try {
			//String bubbleContent = inputJsonObj.getString("bubbleContent");
			String parentConversationId = inputJsonObj.getString("parentConversation");
			if (!StringUtils.isBlank(parentConversationId))
			{
				conversation.setParentConversationId(Long.parseLong(parentConversationId));
				subLogger.info("parentConversationId " + parentConversationId);
			}
			//commented below code to get bubble content since we use AI/ML service to get it
			/*if (StringUtils.isBlank(bubbleContent))
			{
				int index = content.indexOf(BUBBLE_CONTENT_SAPARATOR);
				if(index > -1) {
					bubbleContent = content.substring(0, index);
				}
				
			}
			conversation.setBubbleContent(bubbleContent);
			subLogger.info("bubbleContent " + bubbleContent);*/
		} catch (Exception e) {
			subLogger.error("Exception in addBubbleContentAndParentConvId with exception "+ e);
		}
	}

	private List<Attachment> getAttachmentsInfo(BasicDBObject inputJsonObj)
	{

		List<Attachment> attachmentList = new ArrayList<Attachment>();

		try {
			JSONArray jsArray = new JSONArray(inputJsonObj.getString("attachment"));
			subLogger.info("Attachment Size {}", jsArray.length());

			for (int i = 0; i < jsArray.length(); i++)
			{
				if(jsArray.isNull(i)){
					continue;
				}
				JSONObject jsonObj = jsArray.getJSONObject(i);
				if (!jsonObj.isNull("name") && !jsonObj.isNull("id"))
				{
					Attachment attch;
					if(jsonObj.isNull("secure"))
					{
						attch = new Attachment(jsonObj.getString("name"), jsonObj.getString("id"));
						attachmentList.add(attch);
					}
					else
					{
						attch = new Attachment(jsonObj.getString("name"), jsonObj.getString("id"), jsonObj.getString("secure"));
						attachmentList.add(attch);
					}

					if (!jsonObj.isNull("fileInfo") )
					{
						attch.setFileInfo(jsonObj.getString("fileInfo"));
					}

					if (!jsonObj.isNull("isSecuredByQMA") )
					{
						attch.setIsSecuredByQMA(jsonObj.getString("isSecuredByQMA"));
					}
					//QMA-977 To display file size along with attachment name
					if (!jsonObj.isNull("fileSize") )
					{
						attch.setFileSize(Double.parseDouble(jsonObj.getString("fileSize")));
					}
				}

			}
		} catch (Exception e ){
			subLogger.warn("Exception while getting attachment info in InquiryDAO#getAttachmentsInfo()",e);
		}

		return attachmentList;
	}

	private List<ConversationRecipient> createRecipients(BasicDBObject inputJsonObj, String soeId)
	{
		List<ConversationRecipient> recipientList = new ArrayList<ConversationRecipient>();

		ArrayList<String> fromList = new ArrayList<String>();
		List<String> list = new ArrayList<String>();
		HashMap<String, ArrayList<String>> toCCGrpMap = null;

		String fromGroup = inputJsonObj.getString(FROM);
		fromList.add(fromGroup);
		setupRecipients(recipientList, fromList, "FROM", soeId, null);

		toCCGrpMap = getToCcList(inputJsonObj, TO);
		HashMap<String, String> toCCGrpMapIdName = getToCcListMapIdName(inputJsonObj, TO);
		if (toCCGrpMap != null && !toCCGrpMap.isEmpty())
		{
			list = toCCGrpMap.get(LIST_BY_IDS);
		}
		setupRecipients(recipientList, list, "TO", soeId, toCCGrpMapIdName);

		toCCGrpMap = getToCcList(inputJsonObj, CC);
		toCCGrpMapIdName = getToCcListMapIdName(inputJsonObj, CC);
		if (toCCGrpMap != null && !toCCGrpMap.isEmpty())
		{
			list = toCCGrpMap.get(LIST_BY_IDS);
		}
		setupRecipients(recipientList, list, "CC", soeId, toCCGrpMapIdName);

		// [C153176-1052] Ability to BCC when sending email
		toCCGrpMap = getToCcList(inputJsonObj, "bcc");
		toCCGrpMapIdName = getToCcListMapIdName(inputJsonObj, "bcc");
		if (toCCGrpMap != null && !toCCGrpMap.isEmpty())
		{
			list = toCCGrpMap.get(LIST_BY_IDS);
		}
		setupRecipients(recipientList, list, "BCC", soeId, toCCGrpMapIdName);

		return recipientList;
	}

	// [C15176-347]- All inactive and active groups should be part of TO/CC recipients
	private void setupRecipients(List<ConversationRecipient> recipientList, List<String> toccRecipients, String tofrom, String soeId, HashMap<String, String> toCCGrpMapIdName)
	{
		if (toccRecipients != null)
		{
			QMACache qmaCache = QMACacheFactory.getCache();
			String grpCode = null;
			User user = null;
			if (tofrom.equalsIgnoreCase("FROM"))
			{
				String fromGroupCode = toccRecipients.get(0);
				// [C15176-347]- All inactive and active groups should be part of TO/CC recipients
				Long fromGroupId =  qmaCache.getGroupCodeToIdMapBothActiveInactive().get(fromGroupCode.toUpperCase());
				subLogger.debug("From Hazelcast fromGroupId:"+fromGroupId);
				ConversationRecipient conversationRecipient = new ConversationRecipient(null, fromGroupId, soeId, fromGroupCode, tofrom);
				recipientList.add(conversationRecipient);
			}
			else
			{
				for (String grpOrUserId : toccRecipients)
				{
					// [C15176-347]- All inactive and active groups should be part of TO/CC recipients
					//grpCode = CacheDAO.getInstance().getGroupIdToCodeMap().get(grpOrUserId.toUpperCase());
					grpCode = qmaCache.getGroupIdToDBCodeMap().get(grpOrUserId);
					String inActiveGrpCode = qmaCache.getGroupIdToCodeMapBothActiveInactive().get(grpOrUserId.toUpperCase());
					if( !isEmailAddress(grpOrUserId) && NumberUtils.isParsable(grpOrUserId) && qmaCache.getPersonalGroupIdList().contains(Long.valueOf(grpOrUserId))){
						subLogger.info("grpOrUserId : {} is identified as Individual group, hence ignoring identifying Group.",grpOrUserId);
						grpCode=null;
						inActiveGrpCode = null;
					}
					subLogger.debug("From Hazelcast inActiveGrpCode:"+inActiveGrpCode);
					// [C15176-347]- All inactive and active groups should be part of TO/CC recipients
					//user = CacheDAO.getInstance().getUserDetailsMapInactiveActive().get(grpOrUserId.toUpperCase());
					user = qmaCache.getUserInfoMap().get(grpOrUserId.toUpperCase());
					if (grpCode != null)
					{// [C15176-347]- All inactive and active groups should be part of TO/CC recipients
						Long groupId = qmaCache.getGroupCodeToIdMap().get(grpCode.toUpperCase());
						// [C153176-748] - to and cc fields enrichments
						String email = qmaCache.getGroupIdToEmailMap().get(groupId);
						ConversationRecipient conversationRecipient = new ConversationRecipient(email, groupId, null, grpCode, tofrom);
						recipientList.add(conversationRecipient);
					}
					else if (inActiveGrpCode != null)
					{
//						Long groupId = CacheDAO.getInstance().getGroupCodeToIdMapBothActiveInactive().get(inActiveGrpCode.toUpperCase());
//						ConversationRecipient conversationRecipient = new ConversationRecipient(CacheDAO.getInstance().getGroupIdToEmailMapBothActiveInactive().get(groupId.toString()), null, null, inActiveGrpCode,
//								tofrom);
						Long groupId = qmaCache.getGroupCodeToIdMapBothActiveInactive().get(inActiveGrpCode.toUpperCase());
						subLogger.debug("From Hazelcast GroupId:"+groupId);
						String groupEmail = qmaCache.getGroupIdToEmailMapBothActiveInactive().get(groupId.toString());
						subLogger.debug("From Hazelcast groupEmail:"+groupEmail);
						ConversationRecipient conversationRecipient = new ConversationRecipient(groupEmail, null, null, inActiveGrpCode,tofrom);
						recipientList.add(conversationRecipient);
					}
					else if (user != null)
					{
						String userLDesc = user.getName();
						if(null != user.getLongDesc() && StringUtils.isNotBlank(user.getLongDesc())) {
							userLDesc = user.getLongDesc();
						}
						ConversationRecipient conversationRecipient = new ConversationRecipient(user.getEmail(), null, user.getId(), userLDesc, tofrom);
						recipientList.add(conversationRecipient);
					}
					else if (isEmailAddress(grpOrUserId))
					{
						ConversationRecipient conversationRecipient = null;

						String groupEmailAlias = grpOrUserId.substring(0, grpOrUserId.indexOf('@'));
						grpCode = qmaCache.getGroupEmailToCodeMap().get(groupEmailAlias.toUpperCase());

						if(Objects.nonNull(grpCode) && Objects.nonNull(qmaCache.getGroupCodeToIdMap().get(grpCode.toUpperCase()))) {
							Long grpId = qmaCache.getGroupCodeToIdMap().get(grpCode.toUpperCase());
							if(qmaCache.getPersonalGroupIdList().contains(grpId)){
								subLogger.info("groupEmailAlias : {} is identified as Individual group, hence ignoring identifying Group.",groupEmailAlias);
								grpCode=null;
							}
						}
						// Set GroupID in recipient and create version for that group if email matches the groupEmail
						// Check for Group Email, then convert to groupId, also send email with groupEmail
						// Check for the external email - [C153176-891]
						if (GenericUtility.isCitiDomainEmail(grpOrUserId) && null != grpCode ){
							// [C15176-347]- All inactive and active groups should be part of TO/CC recipients
							Long groupId = qmaCache.getGroupCodeToIdMapBothActiveInactive().get(grpCode.toUpperCase());
							subLogger.info("Received group email : " + grpOrUserId + " , groupAlias before @ = " + groupEmailAlias + " ,groupCode = " + grpCode + " ,groupId = " + groupId);
							// Set group email , groupId, But display name as email address(displayed in conversation detail in UI
							
							//set display name as received from UI
							String displayName = null != toCCGrpMapIdName && StringUtils.isNotBlank(toCCGrpMapIdName.get(grpOrUserId))?(toCCGrpMapIdName.get(grpOrUserId)):grpOrUserId ;
							conversationRecipient = new ConversationRecipient(grpOrUserId, groupId, null, displayName, tofrom);
							
							recipientList.add(conversationRecipient);
						}
						//[C153176-1273]- Child group does not receive the mail in QMA for Mail sent from QMA to Parent. 
						//This is case of mail being sent to parentDL, which directly does not exists in group table. But exists as parenTDLAliases for all groups.
						else if (GenericUtility.isCitiDomainEmail(grpOrUserId) && null == grpCode) {
							Map<String, List<String>> parentToChild = qmaCache.getParentToChildDLsListMap();
							subLogger.debug("From Hazelcast parentToChild:"+parentToChild.size());
							String grpOrUserIdUpper  = grpOrUserId.toUpperCase();
							List<String> listofChildEmail = parentToChild.get(grpOrUserIdUpper);
							if (null != listofChildEmail && !listofChildEmail.isEmpty()) 
							{
								//set display name as received from UI
								String displayName = null != toCCGrpMapIdName && StringUtils.isNotBlank(toCCGrpMapIdName.get(grpOrUserId))?(toCCGrpMapIdName.get(grpOrUserId)):grpOrUserId ;
								conversationRecipient = new ConversationRecipient(grpOrUserId, null, null, displayName, tofrom);
								
								recipientList.add(conversationRecipient);
								for (String childDLEmailAddres : listofChildEmail) 
								{
									//childDLEmailAddres is already in caps in cache
									String emailAddress = childDLEmailAddres.substring(0,childDLEmailAddres.indexOf('@'));
									grpCode = qmaCache.getGroupEmailToCodeMap().get(emailAddress);
									if (null != grpCode)
									{
										Long groupId = qmaCache.getGroupCodeToIdMap().get(grpCode.toUpperCase());
										if(qmaCache.getPersonalGroupIdList().contains(groupId)){
											subLogger.info("groupId : {} is identified as Individual group in the group email flow, hence ignoring identifying Group.",groupEmailAlias);
											groupId= null;
										}
										subLogger.info("grpCode for Child Email ID: " + emailAddress + "is: " + grpCode + "and group ID::" + groupId);
										conversationRecipient = new ConversationRecipient(childDLEmailAddres, groupId, null, grpCode, tofrom);
										recipientList.add(conversationRecipient);
									}
								}
							}
							else
							{
								getConversationRecipientAliasFromMail(recipientList, tofrom, grpOrUserId); 
								String displayName = null != toCCGrpMapIdName && StringUtils.isNotBlank(toCCGrpMapIdName.get(grpOrUserId))?(toCCGrpMapIdName.get(grpOrUserId)):grpOrUserId ;
								conversationRecipient = new ConversationRecipient(grpOrUserId, null, null, displayName, tofrom);
								subLogger.info("Received group email : " + grpOrUserId);
								recipientList.add(conversationRecipient);
							}

						}
						// This is for External Email Address.
						else
						{
							String displayName = null != toCCGrpMapIdName && StringUtils.isNotBlank(toCCGrpMapIdName.get(grpOrUserId))?(toCCGrpMapIdName.get(grpOrUserId)):grpOrUserId ;
							conversationRecipient = new ConversationRecipient(grpOrUserId, null, null, displayName, tofrom);
							
							subLogger.info("Received group email : " + grpOrUserId);
							recipientList.add(conversationRecipient);
						}

					}

				}
			}

		}
	}

	private void getConversationRecipientAliasFromMail(List<ConversationRecipient> recipientList, String tofrom,
			String grpOrUserId) {
		ConversationRecipient conversationRecipient;
		List<IncomingToCcDLAliasMapping> toCCGrpAliasList = QMACacheFactory.getCache().getIncomingToCcDLAliasMapping();
		if(toCCGrpAliasList!=null && !toCCGrpAliasList.isEmpty()) {
			String aliasEmailAdd = "";
			String aliasDisplayName = "";
			for(int i=0; i<toCCGrpAliasList.size(); i++){
				if(grpOrUserId.equals(toCCGrpAliasList.get(i).getEmail())){
					aliasEmailAdd = toCCGrpAliasList.get(i).getXscDLEmail();
					aliasDisplayName = toCCGrpAliasList.get(i).getXscDlName();
					break;
				}
			}
			if(!aliasDisplayName.isEmpty()){
				Long aliasGroupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(aliasDisplayName.toUpperCase());
				if(QMACacheFactory.getCache().getPersonalGroupIdList().contains(aliasGroupId)){
					subLogger.info("aliasGroupId : {} is identified as Individual group, hence ignoring identifying Group.",aliasGroupId);
					aliasGroupId= null;
				}
				conversationRecipient = new ConversationRecipient(aliasEmailAdd, aliasGroupId, null, aliasDisplayName, tofrom);
				subLogger.info("grpCode for : " + grpOrUserId + "is: " + aliasDisplayName + "and group ID::" + aliasGroupId);
				Boolean isGroupExist = isGroupExist(recipientList, tofrom, aliasGroupId);
				if(!isGroupExist){											
					recipientList.add(conversationRecipient);
				}				
			}
		}
		
	}

	private Boolean isGroupExist(List<ConversationRecipient> recipientList, String tofrom, Long aliasGroupId) {
		Boolean isGroupExist = false;
		for(int i=0; i<recipientList.size(); i++){
			if(Objects.nonNull(aliasGroupId) && Objects.nonNull(tofrom) 
					&& aliasGroupId.equals(recipientList.get(i).getGroupId()) 
					&& tofrom.equals(recipientList.get(i).getToFrom())){
				subLogger.info("Group already exists in list");
				isGroupExist = true;
				break;
			}
		}
		return isGroupExist;
	}



	public Workflow createNewWorkflowForInquiry(Long assignToGrpId, String direction, String action, Workflow uiWorkflowData, String soeId, Date currentTime,
			List<ConversationRecipient> recipientsList, Long inquiryLatestGroupId) throws CommunicatorException// Sonar Fix -- Define and
	{
		Workflow workflow = new Workflow();
		List<String> requestTypesList = QMACacheFactory.getCache().getGroupIdToRequestTypeMap().get(assignToGrpId);
		String requestType = null;
		String inquirySource = null;
		if (uiWorkflowData != null)
		{
			requestType = uiWorkflowData.getRequestType();
			inquirySource = uiWorkflowData.getInquirySource();
		}

		workflow.setStatus(STATUS_OPEN);
		workflow.setCrtBy(soeId);
		workflow.setCrtDate(currentTime);
		workflow.setModBy(soeId);
		workflow.setModDate(currentTime);
		workflow.setAssignedGroupId(assignToGrpId);
		// Release 1.2 Changes-
		workflow.setAssignedGroupName(QMACacheFactory.getCache().getGroupIdToNameMap().get(assignToGrpId));
		// Release 1.2 changes-Add action in the workflow
		// workflow.setAction(action);
		// workflow.assignedUserId = assignToUserId;
		workflow.setDirection(direction);
		// Added for C153176-486
		if (null != requestTypesList && requestTypesList.contains(requestType))
		{
			workflow.setRequestType(requestType);
		}
		// [C153176-818]-Add 'Response Time'
		workflow.setLatestConversationTime(currentTime);
		// C153176-486
		// C153176-852
		workflow.setQueryCount(1L);
		workflow.setOriginDate(currentTime);

		if (!StringUtils.isBlank(inquirySource))
		{
			workflow.setInquirySource(inquirySource); // [C153176-854] - Add new drop-down: Inquiry Source
		}

		return workflow;
	}

	public Map<Long, String> getRecipientsUserIdMap(List<ConversationRecipient> recipientList, List<Long> toCcGroupIdList, String category)
	{
		Map<Long, String> recipientsMap = new HashMap<Long, String>();
		for (ConversationRecipient inqRecp : filterParentDL(recipientList, category))
		{
			if (category.contains(inqRecp.getToFrom()) && inqRecp.getGroupId() != null)
			{
				recipientsMap.put(inqRecp.getGroupId(), inqRecp.getUserId());
				toCcGroupIdList.add(inqRecp.getGroupId());
			}
		}
		return recipientsMap;
	}
	
	private List<ConversationRecipient> filterParentDL(List<ConversationRecipient> recipientList, String category) {
		List<String> skipDLList = new ArrayList<String>();
		for (ConversationRecipient inqRecp : recipientList)
		{
			if (category.contains(inqRecp.getToFrom()) && inqRecp.getGroupId() != null)
			{
				Group group = QMACacheFactory.getCache().getAllGroupsMap().get(inqRecp.getGroupId());
				
				if (group != null) {
					
					List<EmailAlias> emailAliasList = group.getParentDLAliases();
					
					if(emailAliasList != null && emailAliasList.size() > 0) {
						skipDLList.addAll(emailAliasList.stream().map(EmailAlias :: getAlias).collect(Collectors.toList()));
					}
				}
				
			}
		}
		return recipientList.stream().filter(conversationRecipient -> !skipDLList.contains(conversationRecipient.getDisplayName())).collect(Collectors.toList());
	}

	private boolean isEmailAddress(String grpStr)
	{
		if (grpStr.indexOf("@") == -1)
		{
			return false;
		}
		return true;
	}

	private boolean isToCCHasEMail(BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		boolean externalCommunication = false;
		BasicDBList to = null;
		BasicDBList cc = null;
		BasicDBList bcc = null;

		if (inputJsonObj.get(TO) != null)
		{
			to = (BasicDBList) inputJsonObj.get(TO);
		}

		if (inputJsonObj.get(CC) != null)
		{
			cc = (BasicDBList) inputJsonObj.get(CC);
		}

		if (inputJsonObj.get("bcc") != null)
		{
			bcc = (BasicDBList) inputJsonObj.get("bcc");
		}


		if(checkExternalFromUiReceipients(to)||checkExternalFromUiReceipients(cc)||checkExternalFromUiReceipients(bcc)) {
			externalCommunication=true;
		}

		return externalCommunication;
	}

	private boolean checkExternalFromUiReceipients(BasicDBList recpList)
	{
		boolean externalCommunication = false;
		if (recpList != null)
		{
			for (Object recpObj : recpList)
			{
				if (recpObj !=null && ((BasicDBObject) recpObj).getString(VALUE) != null && ((BasicDBObject) recpObj).getString(VALUE).indexOf("@") > -1)
				{
					externalCommunication = true;
					break;
				}
			}
		}
		return externalCommunication;
	}

	private ArrayList<String> getToCCGroupsListFromJson(BasicDBObject inputJsonObj)
	{
		ArrayList<String> recpList = new ArrayList<String>();
		HashMap<String, ArrayList<String>> toCCGrpMap = getToCcList(inputJsonObj, TO);

		if (toCCGrpMap != null && !toCCGrpMap.isEmpty())
		{
			recpList.addAll(toCCGrpMap.get(LIST_BY_NAMES));
		}

		toCCGrpMap = getToCcList(inputJsonObj, CC);

		if (toCCGrpMap != null && !toCCGrpMap.isEmpty())
		{
			recpList.addAll(toCCGrpMap.get(LIST_BY_NAMES));
		}

		return recpList;
	}

	private void createInquiryAuditRaw(Long inquiryId, Long convId, boolean makerCheckerRqd, boolean approvalBypassed, Long groupId, String action) throws CommunicatorException
	{
		try
		{
			OutBoundEmails outBoundEmails = new OutBoundEmails();
			outBoundEmails.setMessageId(null);
			outBoundEmails.setReferences(null);
			outBoundEmails.setInquiryId(inquiryId);

			outBoundEmails.setConversationId(convId);
			outBoundEmails.setDirection("EXTERNAL");
			if (makerCheckerRqd && !approvalBypassed)
			{
				outBoundEmails.setProcessFlag("P");
			}
			else
			{
				outBoundEmails.setProcessFlag("N");
			}

			// Maker Checker group Based implementation
			outBoundEmails.setGroupId(groupId);

			//// mongoDatastore.save(outBoundEmails,WriteConcern.REPLICA_ACKNOWLEDGED);
			DBCollection outboundEmailsCollection = mongoDatastore.getCollection(OutBoundEmails.class);
			extractDBCollection(outboundEmailsCollection);

			mongoDatastore.save(outBoundEmails);

			Long auditId = outBoundEmails.getId();

			// Long auditId = persist(outBoundEmails);

			subLogger.info("createAuditRaw-Inquiry Audit id ::" + auditId);

		}
		catch (Exception e)
		{
			subLogger.info("createAuditRaw-Issue in creating Audit Row for Inquiry-" + inquiryId + "  for Action " + action, e);
			throw new CommunicatorException("createAuditRaw-Issue in creating Audit Row for Inquiry-" + inquiryId + "  for Action " + action, e);

		}

	}



	private void updateInquiryDetailsDO(BasicDBObject inputJsonObj, Inquiry inquiryObj, boolean saveFlag, String soeId, Date currentTime)
	{
		String fromGroup = inputJsonObj.getString(FROM);
		User loginUser = getUser(soeId);
		if (saveFlag)
		{
			inquiryObj.setStatus(STATUS_OPEN);
			if (inputJsonObj.getString("inquiryAction").equalsIgnoreCase(ACTION_NEW_RESOLVE)){
				inquiryObj.setAction(ACTION_NEW_RESOLVE);
			} else {
			inquiryObj.setAction(ACTION_NEW);
			}
			inquiryObj.setOrigGroupId(QMACacheFactory.getCache().getGroupCodeToIdMap().get(fromGroup.toUpperCase()));
			inquiryObj.setOrigGroupName(fromGroup.trim());
			inquiryObj.setOrigSubject(inputJsonObj.getString(SUBJECT));
			inquiryObj.setOrigUserId(soeId);
			
			if (loginUser != null)
			{
				inquiryObj.setOrigUserName(loginUser.getName());
			}
			inquiryObj.setOrigType(INTERNAL);
		}
		if (null != inquiryObj.getNlpRPTSuggestionId())
		{
			inquiryObj.setNlpRPTFreeze(true);
		}
		inquiryObj.setSubject(inputJsonObj.getString(SUBJECT));
		inquiryObj.setLatestGroup(fromGroup);
		inquiryObj.setLatestGroupId(QMACacheFactory.getCache().getGroupCodeToIdMap().get(fromGroup.toUpperCase()));
		/*String comment = inputJsonObj.getString("notes");
		if (!StringUtils.isEmpty(comment))
		{
			Note userNote = new Note(soeId, loginUser.getName(), new Date(), comment);
			ArrayList<Note> noteList = new ArrayList<Note>(0);
			noteList.addAll(inquiryObj.getUserNotes());
			noteList.add(userNote);
			inquiryObj.setUserNotes(noteList);
			inquiryObj.setNotesFlag("Y");
		}*/
		//commentes above code and added below code to save multiple notes
		
		@SuppressWarnings("unchecked")
		List<String> userNotes = (List<String>) inputJsonObj.get("notes");
		if(userNotes != null && !userNotes.isEmpty() && loginUser !=null){
			addNotesToInquiry(soeId, loginUser.getName(), userNotes, inquiryObj);
		} else {
			inquiryObj.setNotesFlag("N");
		}
		
		
		inquiryObj.setLatestUserId(soeId);
		if (loginUser != null)
		{
			inquiryObj.setLatestUserName(loginUser.getName());
			inquiryObj.setLatestEmail(loginUser.getEmail());
		}
		inquiryObj.setModBy(soeId);
		inquiryObj.setModDate(currentTime);

		String gfpid = inputJsonObj.getString(GFPID);
		if (!StringUtils.isBlank(gfpid))
		{
			inquiryObj.setGpNum(gfpid);
			inquiryObj.setGpName(inputJsonObj.getString("GFPIDName"));
		}
		if (!StringUtils.isBlank(inputJsonObj.getString(GFCID)))
		{
			inquiryObj.setGfcid(inputJsonObj.getString(GFCID));
			inquiryObj.setGfcName(inputJsonObj.getString("GFCIDName"));
		}
		String exceptionId = inputJsonObj.getString("exceptionId");
		if (!StringUtils.isBlank(exceptionId))
		{
			inquiryObj.setExceptionId(Long.parseLong(exceptionId));
		}
		
		// C170665-5 | Add Account Number and Branch to Inquiry.
		if (null != inputJsonObj.get("skAccountNo") && !StringUtils.isBlank(inputJsonObj.getString("skAccountNo"))) {
			inquiryObj.setSkAccountNo(inputJsonObj.getString("skAccountNo"));
			inquiryObj.setBranch(inputJsonObj.getString("branch"));
		}
		
		updateTaskizeFields(inputJsonObj, inquiryObj);
	}

	/**
	 * @param inputJsonObj
	 * @param inquiryObj
	 * @param currentTime
	 * @param soeId
	 * @param loginUser
	 * Update User Note in Inquiry collection, when user update the NOte on reply actions
	 * --(reply, replyAll, replyresolve, replyallresolve, forward).
	 * [C153176-1478]-Reply Resolve in QMA should have the ability to save user notes
	 */
	private void updateUserNotes(BasicDBObject inputJsonObj, Inquiry inquiryObj, Date currentTime, String soeId, UpdateOperations<Inquiry> ops){

		String userNote = inputJsonObj.getString("userNotes");
		User loginUser = getUser(soeId);
		Note note = new Note(soeId, (null == loginUser ? "" :loginUser.getName()), new Date(), userNote);
		ops.set("notesFlag", "Y");
		try {
			inquiryObj = getInquiryById(inquiryObj.getId());
		} catch (CommunicatorException e) {
		    subLogger.warn("Exception in  updateUserNotes", e);
		}
		if (inquiryObj.getUserNotes() != null && !inquiryObj.getUserNotes().isEmpty())
		{
			inquiryObj.getUserNotes().add(note);
			ops.set("userNotes", inquiryObj.getUserNotes());
		}
		else
		{
			List<Note> noteList = new ArrayList<>();
			noteList.add(note);
			ops.set("userNotes", noteList);
		}
	} 

	private User getUser(String soeId)
	{
		for (User user : QMACacheFactory.getCache().getUserInfoMap().values())
		{
			if (user.getId().equalsIgnoreCase(soeId))
			{
				return user;
			}
		}
		return null;
	}

	private List<Long> getAllGroupsWithinEmailConversation(String fromGroup, Conversation conversation)
	{
		Long fromGrpId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(fromGroup.toUpperCase());
		List<Long> allGroupIdList = new ArrayList<Long>();
		getRecipientsUserIdMap(conversation.getRecipients(), allGroupIdList, TO_CATEGORY + CC_CATEGORY);
		allGroupIdList.add(fromGrpId);
		return allGroupIdList;
	}

	private void updateInquiryDetailsDB(BasicDBObject inputJsonObj, Inquiry inquiry, Conversation conversation, List<Workflow> workFlowList, List<ConversationRecipient> recipientsList, Date currentTime, String soeId, UserActivities userActivity)// Sonar Fix -- remove useless parameter
	{
		String fromGroup = inputJsonObj.getString(FROM);
		String iRequestName = inputJsonObj.getString(REQUEST_TYPE);
		String forceUnlock = inputJsonObj.getString(FORCE_UNLOCK);
		String tag = inputJsonObj.getString(TAG);
		long startTime = System.currentTimeMillis(); 
		List<Long> allGroupIdList = getAllGroupsWithinEmailConversation(fromGroup, conversation);
		// Inquiry Database Update
		UpdateOperations<Inquiry> ops = mongoDatastore.createUpdateOperations(Inquiry.class);
		// Prepare Find Query to find record
		Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("id", inquiry.id);
		String allToCCGroups;
		String latestToCCGroups = getLatestToCCGroups(inputJsonObj);
		String userNote = inputJsonObj.getString("userNotes");
		if (null!= userNote && StringUtils.isNotBlank(userNote)){
			updateUserNotes(inputJsonObj, inquiry, currentTime, soeId, ops);
		}

		if ("NEW".equals(inquiry.getAction())) // For new Inq both are same.. otherwise existing db value by appending new groups involved. Do not override with workflows data
		{
			allToCCGroups = latestToCCGroups; // <-- sonar fix This conditional operation returns the same value whether the condition is "true" or "false"

		}
		else
		{
			// Clear read trace for Response Actions
			ops.unset(READ_BY);
			allToCCGroups = getAllToCCgroups(workFlowList, inquiry.getAllToCCGrps());
		}

		Map<String, String> openGroupsAndUserMap = getOpenGroups(workFlowList);
		setInquiryOpenUsers(openGroupsAndUserMap, ops, inquiry);
		
		if (!ACTION_NEW.equals(inquiry.getAction()))
		{
			String openUsers = openGroupsAndUserMap.get(OPEN_USERS);
			// Added null check for openUsers
			if (!StringUtils.isBlank(openUsers))
			{
				ops.set(OPEN_USERS, openUsers);
				inquiry.setOpenUsers(openUsers);
			}
		}

		setInquiryOpenUsersGroups(openGroupsAndUserMap, ops, inquiry);
		String latestToCCUsers = getLatestToCcUsersList(conversation.getRecipients());
		// ResolveInquiry If all workflows are already resolved, it also handles ReOpen case
		String inquiryStatus = STATUS_OPEN;
		if (isAllWorkflowResolved(workFlowList))
		{
			// mark as Resolved
			inquiryStatus = STATUS_RESOLVE;
		}
		if (workFlowList.size() == 1 && ACTION_NEW_RESOLVE.equalsIgnoreCase(inquiry.getAction()))
		{
		                Workflow out = workFlowList.get(0);
		                if (out.getStatus().equalsIgnoreCase(STATUS_RESOLVE))
		                                inquiryStatus = STATUS_RESOLVE;
		}
		ops.set(STATUS, inquiryStatus);
		ops.set(ACTION, inquiry.getAction());
		Long fromGrpId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(fromGroup.toUpperCase());

		updateWorkflowRequesTypeAction(workFlowList, fromGrpId, iRequestName, inquiry.getAction(),allGroupIdList, inputJsonObj);

		String reqTypes = getSummaryReqTypeName(workFlowList);
		if (reqTypes != null)
		{
			ops.set(REQUEST_TYPE_STR, reqTypes);
			inquiry.setRequestTypeStr(reqTypes);
		}

		//[C153176-1072] - Escalate based on inquiry actions

		EscalationUtility escalationUtility = new EscalationUtility();
		escalationUtility.setAllGroupsEscalationCriteriaMap(groupDAO.getGroupEscalationDetailsById(allGroupIdList));
		escalationUtility.flagEscalations(allGroupIdList, workFlowList, inquiry, fromGrpId,QMACacheFactory.getCache().getConfigIdEscalationCriteriaMap());
		escalationUtility.setRespontimeEscalationForInternalMail(workFlowList, recipientsList, fromGrpId, inquiry, currentTime,inquiry.getAction());
		//[C153176-1270] - Add Escalation criteria for 'Pending Approval' emails
		escalationUtility.setEscalationTimeforPendingApproval(workFlowList, fromGrpId, currentTime);

		//EscalationUtility.allGroupsEscalationCriteriaMap = ;
		if (workFlowList != null)
		{
			// Set each time because of workflow re-use & avoid multiple DB Updates considering workflow small workflow array size
			ops.set(WORKFLOWS, workFlowList);
		}
		//C170665-4412: When "Request Type" is changed on existing inquiry, action should be added to Audit Trail
		Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
		Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
		if(null != inputJsonObj.getString(REQUEST_TYPE_CHANGED_KEY) && inputJsonObj.getBoolean(REQUEST_TYPE_CHANGED_KEY)) {
			String actionDescription = "";
			if(StringUtils.isBlank(inputJsonObj.getString(OLD_REQUEST_TYPE_KEY)) || inputJsonObj.getString(OLD_REQUEST_TYPE_KEY).equalsIgnoreCase(iRequestName)) {
				actionDescription = REQUEST_TYPE_CHANGED_TO_KEY + iRequestName + FOR_KEY +groupIdToNameMap.get(fromGrpId);
			}else {
				actionDescription = REQUEST_TYPE_CHANGED_FROM_KEY + inputJsonObj.getString(OLD_REQUEST_TYPE_KEY) + " to "+ iRequestName + FOR_KEY + groupIdToNameMap.get(fromGrpId);;
			}
			WorkflowAudit workflowAuditRequestTypeChange = createWorkFlowsAudit(fromGrpId, ACTION_ASSIGN_REQ_TYPE, actionDescription ,inquiry.getModBy(), inquiry.getModDate(), forceUnlock, tag, groupIdToNameMap, userInfoMap);
			setInquiryAudit(inquiry, workflowAuditRequestTypeChange, ops);
		}

		List<Long> resolveGroupIds = getResolveGroupIdsFromRequest(inputJsonObj);
		if (resolveGroupIds != null && !resolveGroupIds.isEmpty() && (ACTION_REPLY_RESOLVE_ALL.equals(inquiry.getAction()) || ACTION_REPLYALL_RESOLVE_ALL.equals(inquiry.getAction())))
		{
			// Create a audit for each record
			for (Long grpId : resolveGroupIds)
			{
				// Create workflow audit for inquiry action ex reply reply all forward etc.
				WorkflowAudit workflowAudit = createWorkFlowsAudit(grpId, inquiry.getAction(), "Internal", inquiry.getModBy(), inquiry.getModDate(), forceUnlock, tag, groupIdToNameMap, userInfoMap);
				if(null != inputJsonObj.get("resolveAllocation") && StringUtils.isNotBlank(inputJsonObj.getString("resolveAllocation"))) {
					workflowAudit.setAction(inquiry.getAction()+" Allocation");
				}
				setInquiryAudit(inquiry, workflowAudit, ops);
			}
		}
		else
		{
			// Create workflow audit for inquiry action ex reply reply all forward etc.
			WorkflowAudit workflowAudit = null;
			if(null != inputJsonObj && null != inputJsonObj.get("symphonyStreamId")) {
				workflowAudit = createWorkFlowsAudit(fromGrpId, inquiry.getAction(), "Internal : Created from Symphony chatroom", inquiry.getModBy(), inquiry.getModDate(), forceUnlock, tag, groupIdToNameMap, userInfoMap);
			}  else if(null != inputJsonObj.get("resolveAllocation") && StringUtils.isNotBlank(inputJsonObj.getString("resolveAllocation"))) {
				workflowAudit = createWorkFlowsAudit(fromGrpId, inquiry.getAction()+" Allocation", "Internal", inquiry.getModBy(), inquiry.getModDate(), forceUnlock, tag, groupIdToNameMap, userInfoMap);
			} else {
				workflowAudit = createWorkFlowsAudit(fromGrpId, inquiry.getAction(), "Internal", inquiry.getModBy(), inquiry.getModDate(), forceUnlock, tag, groupIdToNameMap, userInfoMap);
			}
			
			setInquiryAudit(inquiry, workflowAudit, ops);
			if (inputJsonObj.getString(MEMO) != null)
			{
				WorkflowAudit workflowAuditmemo = createWorkFlowsAudit(fromGrpId, AppserverConstants.UPDATEMEMO, "Internal", inquiry.getModBy(), inquiry.getModDate(), forceUnlock, tag, groupIdToNameMap, userInfoMap);
				setInquiryAudit(inquiry, workflowAuditmemo, ops);
			}
			if(null != inputJsonObj && inputJsonObj.getBoolean("suggestion") ) {
				WorkflowAudit workflowAuditAcceptSuggestion = createWorkFlowsAudit(fromGrpId, SUGGESTION_ACCEPTED, "Internal", inquiry.getModBy(), inquiry.getModDate(), forceUnlock, tag, groupIdToNameMap, userInfoMap);
				setInquiryAudit(inquiry, workflowAuditAcceptSuggestion, ops);
				NLPSuggestionDAO nlpSuggestionDao = new NLPSuggestionDAO();
				nlpSuggestionDao.acceptSuggestion(inquiry,inputJsonObj.getLong("suggestionConvId"),GenericUtility.checkAndFetchConvContent(conversation),fromGrpId, AppserverConstants.SUGGESTION_ACCEPT_ACTION,inputJsonObj.getString(RESPONSE_EDITED_FLAG));
			}
			
			if( inputJsonObj.getBoolean("clcSuggestion") ) {
				try{
					userActivity.setActionType("CLC Suggestion");
					userActivity.setDescription("CLC Suggestion added to reply for InquiryId: "+inquiry.id+" and GroupId: "+fromGrpId);
					user_Activities_Dao.saveUserActivities(soeId, userActivity, System.currentTimeMillis() - startTime);
				} catch (Exception e) {
					subLogger.error("Error while capturing CLC suggestion user activity" + e);
				}
				
			}
			
			if( null != inputJsonObj.get("selectedCLCTrades") ) {
				BasicDBList linkedTradeRefs = (BasicDBList) inputJsonObj.get("selectedCLCTrades");
				if(linkedTradeRefs!=null && linkedTradeRefs.size() > 0 ) {
					clcOperationDao.linkTradesToInquiryOnReply(inquiry,fromGrpId,linkedTradeRefs);
				}
			}
		}
		if (latestToCCUsers != null)
		{
			ops.set("latestToCCUser", latestToCCUsers);
		}
		if (latestToCCGroups != null)
		{
			ops.set("latestToCCGroups", latestToCCGroups);
		}
		if (allToCCGroups != null)
		{
			ops.set("allToCCGrps", allToCCGroups);
		}
		if (conversation.getUrgentFlag() != null)
		{
			ops.set(URGENT_FLAG, conversation.getUrgentFlag());
		}
		if (conversation.getAttachments() != null && !conversation.getAttachments().isEmpty())
		{
			ops.set(ATTACH_FLAG, 'Y');
		}
		
		String memo = inputJsonObj.getString(MEMO);
		if (!StringUtils.isBlank(memo))
		{
			ops.set(MEMO,memo);
		}else
		{
			ops.unset(MEMO);
		}
		if(null != inputJsonObj.get("draftId")){
			try {
				Long draftId = GenericUtility.getIdFromRequest(inputJsonObj, "draftId");
				ops.set("draftId",draftId);
			} catch (CommunicatorException e) {
				subLogger.error("Issue while getting draftId.",e);
			}
		}
		updateInquiryEntityDetails(inputJsonObj, inquiry);
		mongoDatastore.update(query, ops);
	}
	
	//System generated email match for auto prematch
	private void updateInquiryEntityDetails(BasicDBObject inputJsonObj, Inquiry inquiry) {
		try {
			String fromGroup = inputJsonObj.getString(FROM);
			Long fromGrpId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(fromGroup.toUpperCase());
			
			
			if (!StringUtils.isBlank(inputJsonObj.getString(ENTITY_TYPE_KEY))
					&& !StringUtils.isBlank(inputJsonObj.getString(ENTITY_IDS_KEY))
					&& !StringUtils.isBlank(inputJsonObj.getString(CLIENT_IDS_KEY)) 
					&& isBrazilFxEnabledGroupId(fromGrpId)
					&& ACTION_NEW.equalsIgnoreCase(inquiry.getAction())
					&& StringUtils.isNotBlank(inputJsonObj.getString(REQUESTER_ID_KEY))) {
				
					subLogger.info("Saving Inquiry Entitities");
					EntityRecord entityRecord = new EntityRecord();
					entityRecord.setClientId(inputJsonObj.getString(CLIENT_IDS_KEY));
					entityRecord.setEntityId(inputJsonObj.getString(ENTITY_IDS_KEY));
					entityRecord.setEntityStatus("New");
					entityRecord.setEntityType(inputJsonObj.getString(ENTITY_TYPE_KEY));
					entityRecord.setProcessDate(new Date());
					entityRecord.setProductFamily(Long.toString(fromGrpId));
					entityRecord.setEntityOriginatorId(inputJsonObj.getString(REQUESTER_ID_KEY));
					
					QMALinkEntities entities = new QMALinkEntities();
					entities.setInquiryId(inquiry.getId());
					List<QMALinkEntities.EntityGroupData> groupDataList = new ArrayList<>();
					EntityGroupData groupData = new EntityGroupData();
					groupData.setGroupId(fromGrpId);
					groupData.setEntityRecords(new ArrayList<>(Arrays.asList(entityRecord)));
					groupDataList.add(groupData);
					entities.setEntityGroupData(groupDataList);
					Object key = mongoDatastore.save(entities);
					if(null != key) {
						subLogger.info("saved entity details for inquiryID: {}",inquiry.getId());
					}else {
						subLogger.warn("falied save entity details for inquiryID: {}",inquiry.getId());
					}
			}else {
				subLogger.warn("One of the input for Brazil FX is missing");
			}
		}catch(Exception e) {
			subLogger.warn("exception in savin entity details: ", e);
		}
		
	}

	private boolean isBrazilFxEnabledGroupId(Long fromGrpId) {
			boolean isFromGrpIdEnabledForBrazilFx = false;
			Map<Long, String> brazilFxDlMap = getBrazilFxDL();
			if(null == brazilFxDlMap || brazilFxDlMap.isEmpty()) {
				subLogger.warn("Error: No data in brazilFxDlMap");
				return isFromGrpIdEnabledForBrazilFx;
			}
			if(brazilFxDlMap.containsKey(fromGrpId)) {
				subLogger.warn("Brazil Fx Configured for group Id: {}",fromGrpId);
				isFromGrpIdEnabledForBrazilFx = true;
			}else {
				subLogger.warn("Group DL not configured for Brazil Fx: group Id: {}",fromGrpId);
			}
		return isFromGrpIdEnabledForBrazilFx;
	}
	
	protected static Map<Long, String> getBrazilFxDL(){
		Map<Long, String> brazilFxDlMap = null;
		try {
			if (null != QMACacheFactory.getCache().getConfigById(BRAZIL_FX_CONFIG_KEY)) {
				Config configData = QMACacheFactory.getCache().getConfigById(BRAZIL_FX_CONFIG_KEY);
				if (null != configData) {
					brazilFxDlMap = configData.getBrazilFxDlMap();
				}
			}
		} catch (Exception e) {
			subLogger.warn("exception: retriving brazilFxConfig", e);
		}
		return brazilFxDlMap;
	}
	
	private List<Long> getResolveGroupIdsFromRequest(BasicDBObject inputJsonObj)
	{
		List<Long> groupIds = null;
		try
		{
			groupIds = GenericUtility.getIdListFromRequest(inputJsonObj, "resolveAllGroupList");
		}
		catch (Exception e)
		{
			subLogger.debug("Unable to retrieve resolve group ids from request");
		}
		return groupIds;
	}

	private void setInquiryAudit(Inquiry inquiry, WorkflowAudit workflowAudit, UpdateOperations<Inquiry> ops)
	{
		if (workflowAudit != null)
		{
			List<WorkflowAudit> dbWorkflowAuditList = inquiry.getWorkflowAudit();
			if (dbWorkflowAuditList == null)
			{
				dbWorkflowAuditList = new ArrayList<WorkflowAudit>();
			}
			dbWorkflowAuditList.add(workflowAudit);
			ops.set(WORKFLOW_AUDIT, dbWorkflowAuditList);
		}
	}

	private void setInquiryOpenUsers(Map<String, String> openGroupsAndUserMap, UpdateOperations<Inquiry> ops, Inquiry inquiry)// Sonar Fix -- remove useless parameter
	{
		String openUsers = openGroupsAndUserMap.get(OPEN_USERS);
		// This Code is not Used any more as ACTION_ASSIGN_TO_OWNER uses bulk call and has own logic

		if (openUsers != null)
		{
			ops.set(OPEN_USERS, openUsers);
			inquiry.setOpenUsers(openUsers);
		}
	}

	private void setInquiryOpenUsersGroups(Map<String, String> openGroupsAndUserMap, UpdateOperations<Inquiry> ops, Inquiry inquiry)// Sonar Fix -- remove useless parameter
	{
		String openGroups = openGroupsAndUserMap.get(OPEN_GROUPS);
		if (openGroups != null)
		{
			ops.set(OPEN_GROUPS, openGroups);
			inquiry.setOpenGroups(openGroups);
		}
	}

	private String getLatestToCcUsersList(List<ConversationRecipient> recipients)
	{
		List<String> latestToCcUsersList = new ArrayList<String>();
		String latestToCcUsers = null;

		for (ConversationRecipient recipient : recipients)
		{
			if (!FROM_CATEGORY.equalsIgnoreCase(recipient.getToFrom()) && recipient.getGroupId() == null)
			{
				// Sonar Fix -- Merge if statement with enclosing one...
				// if (recipient.getGroupId() == null)
				// {
				latestToCcUsersList.add(recipient.getUserId() != null ? recipient.getDisplayName() : recipient.getEmailAddr());// Sonar Fix -- remove useless parenthesis
				// }
			}
		}

		if (!latestToCcUsersList.isEmpty())
		{
			latestToCcUsers = StringUtils.join(latestToCcUsersList, ";");
		}

		return latestToCcUsers;

	}

	private String getLatestToCCGroups(BasicDBObject inputJsonObj)
	{
		Long grpId = null;
		String latestToCCGroups = null;
		List<String> latestToCCgroupsList = new ArrayList<String>();

		ArrayList<String> recpList = getToCCGroupsListFromJson(inputJsonObj);
		QMACache qmaCache = QMACacheFactory.getCache();
		for (String recp : recpList)
		{
			grpId = qmaCache.getGroupCodeToIdMap().get(recp.toUpperCase());
			if (grpId != null)
			{
				latestToCCgroupsList.add(recp);
			}
		}

		if (!latestToCCgroupsList.isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
		{
			latestToCCGroups = StringUtils.join(latestToCCgroupsList, ";");
		}

		return latestToCCGroups;
	}

	private Set<Long> getGrpIdsNeedNewWorkflow(List<Workflow> dbWorkflow, Set<Long> toCcGroupIdList/* ,boolean isEmailRoutedFromInternal */)
	{
		if (toCcGroupIdList.isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
		{
			return toCcGroupIdList;
		}
		for (Workflow dbWorkFlow : dbWorkflow)
		{
			if (INQUIRY_DIRECTION_IN.equals(dbWorkFlow.getDirection()) && toCcGroupIdList.contains(dbWorkFlow.getAssignedGroupId()))
			{
				toCcGroupIdList.remove(dbWorkFlow.getAssignedGroupId());
			}
		}


		return toCcGroupIdList;
	}

	private void createOutBoxWorkFlow(Inquiry inquiry, List<Workflow> workflowList, Workflow workflowTransferDataObj, Long fromGroupId, String soeId, String action, Date currentTime,
			boolean isMakerCheckerEnabled, Date reOpenDate, Long linkId, int prevConvCount, Date originDate, List<ConversationRecipient> recipientsList) throws CommunicatorException
	{
		Boolean isNewOutWorkflow = false;
		Workflow outWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_OUT);
		String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();

		String resolveRootCause = null;
		String resolveProcessingRegion = null;
		String tag = null;
		Long queryCount = null;
		String inquirySource = null;
		Date latestConversationTime = null;
		String isLastConvToExtEmail = "N";
		FollowUp followUp=null;
		String isManualEscalation = null;
		String manualEscalationReason = null;
		String uiWorkflowStatus = null;
		Set<String> pendingExternalDomains = null;
		String suggestionIndicator = null;
		String intentSuggestionName = null;
		String userIntentSuggestionName = null;
		String intentTimeToVD = null;
		// C153176-5891 | Variable of isLatestResponseFromNonQMA and firstNonChaserResponseTimeByExternal
		String isLatestResponseFromNonQMA = "N";
		Date firstNonChaserResponseTimeByExternal = null;
		String resolveAllocation = "";
		
		if (workflowTransferDataObj != null)
		{
			resolveRootCause = workflowTransferDataObj.getRootCause();
			resolveProcessingRegion = workflowTransferDataObj.getProcessingRegion();
			tag = workflowTransferDataObj.getTag();
			queryCount = workflowTransferDataObj.getQueryCount();
			inquirySource = workflowTransferDataObj.getInquirySource();
			latestConversationTime = workflowTransferDataObj.getLatestConversationTime();
			isLastConvToExtEmail = workflowTransferDataObj.getIsLastConvToExtEmail();
			followUp = workflowTransferDataObj.getFollowUp();
			isManualEscalation = workflowTransferDataObj.getIsManualEscalation();
			manualEscalationReason = workflowTransferDataObj.getManualEscalationReason();
			uiWorkflowStatus = workflowTransferDataObj.getUiWorkflowStatus();
			pendingExternalDomains = workflowTransferDataObj.getPendingExternalDomains();
			suggestionIndicator = workflowTransferDataObj.getSuggestionIndicator();
			intentSuggestionName = workflowTransferDataObj.getIntentSuggestionName();
			userIntentSuggestionName =workflowTransferDataObj.getUserIntentSuggestionName();
			intentTimeToVD = workflowTransferDataObj.getIntentTimeToVD();
			// C153176-5891 | Set value of isLatestResponseFromNonQMA and firstNonChaserResponseTimeByExternal.
			isLatestResponseFromNonQMA = workflowTransferDataObj.getIsLatestResponseFromNonQMA();
			firstNonChaserResponseTimeByExternal = workflowTransferDataObj.getFirstNonChaserResponseTimeByExternal();
			//set resolve allocation
			if(null != workflowTransferDataObj && StringUtils.isNotBlank(workflowTransferDataObj.getResolveAllocation())) {
				resolveAllocation = workflowTransferDataObj.getResolveAllocation();
			}
		}

		if (outWorkflow != null)
		{
			outWorkflow.setStatus(STATUS_OPEN);
			updateMakerChecker(inquiry, fromGroupId, outWorkflow, isMakerCheckerEnabled, currentTime, uiWorkflowStatus);
			outWorkflow.setModDate(currentTime);// Reply case modDate is not updated for OUT version if OUT version for the fromGroup exists.
			outWorkflow.setLastActionby(userName);
			outWorkflow.setLastActionTime(currentTime);
			// [C153176-774] - Root cause for reaply/reply all resolve
			if (!StringUtils.isBlank(resolveRootCause))
			{
				outWorkflow.setRootCause(resolveRootCause);
			}

			// [C153176-793] Add Processing Region as a drop-down in Group Admin screen
			if (!StringUtils.isBlank(resolveProcessingRegion))
			{
				outWorkflow.setProcessingRegion(resolveProcessingRegion);
			}

			if(!StringUtils.isBlank(tag))
			{
				outWorkflow.setTag(tag);
			}
			if(!StringUtils.isBlank(isManualEscalation))
			{
				outWorkflow.setIsManualEscalation(isManualEscalation);
			}
			if(!StringUtils.isBlank(manualEscalationReason))
			{
				outWorkflow.setManualEscalationReason(manualEscalationReason);
			}

			if(queryCount != null)
			{
				outWorkflow.setQueryCount(queryCount);
			}
			if(null != followUp)
			{
				outWorkflow.setFollowUp(followUp);
			}
			if(!StringUtils.isBlank(suggestionIndicator))
			{
				outWorkflow.setSuggestionIndicator(suggestionIndicator);
			}
			if(!StringUtils.isBlank(intentSuggestionName))
			{
				outWorkflow.setIntentSuggestionName(intentSuggestionName);
			}
			if(!StringUtils.isBlank(userIntentSuggestionName))
			{
				outWorkflow.setUserIntentSuggestionName(userIntentSuggestionName);
			}
			if(null != intentTimeToVD)
			{
				outWorkflow.setIntentTimeToVD(intentTimeToVD);
			}
			//C153176-1055 -- Assign to user who has taken action on Inquiry/WF
			if (ACTION_REPLY_ALL.equals(inquiry.getAction()) || ACTION_REPLY.equals(inquiry.getAction()) || ACTION_FORWARD.equals(inquiry.getAction()))
			{
				updateAssignedUser(soeId, outWorkflow);
			}
			if (ACTION_REPLY_RESOLVE.equalsIgnoreCase(inquiry.getAction()) || ACTION_REPLYALL_RESOLVE.equalsIgnoreCase(inquiry.getAction()))
			{
				outWorkflow.setReOpenDate(null);
				//set resolve allocation
				if(StringUtils.isNotBlank(resolveAllocation)) {
					outWorkflow.setResolveAllocation(resolveAllocation);
				}
				outWorkflow.setFollowUp(null);
			}
			// [C153176-854] - Add new drop-down: Inquiry Source
			if (!StringUtils.isBlank(inquirySource))
			{
				outWorkflow.setInquirySource(inquirySource);
			}
			//outWorkflow.setInquiryRefSent("Y");
			// C153176-154 ActionStatistics Improvements-C153176-290
			updatePrevResponseCounterForOutVersion(outWorkflow, action);

			outWorkflow.setIsLastConvToExtEmail(isLastConvToExtEmail);
			// C153176-1549 Add pending external domains to paWorkflow if any
			if (isMakerCheckerEnabled && "Y".equalsIgnoreCase(QMACacheFactory.getCache().getEnableMakerCheckerForUnapprovedDomains()))
			{
				InquiryUtil.updatePendingExternalDomainForWorkflow(outWorkflow, pendingExternalDomains);
			}
			
			// C153176-5891 | Set values to out workflow
			outWorkflow.setIsLatestResponseFromNonQMA(isLatestResponseFromNonQMA);
			
			if(null != firstNonChaserResponseTimeByExternal) {
				outWorkflow.setFirstNonChaserResponseTimeByExternal(firstNonChaserResponseTimeByExternal);
			}
			
			
		}
		else
		{
			Workflow paWorkflow = getPendingApprovalWorkflow(inquiry.getWorkflows(), fromGroupId, isMakerCheckerEnabled);
			//Do not create workflow for internal orgnaization
			List<Long> ignoredDLForTaskize = getIgnoredQmaDlForTaskizeFromCache();
			 if(ignoredDLForTaskize.contains(fromGroupId)) {
				subLogger.info("Taskize Group Id: {} skipping further processing",fromGroupId);
			}else if (paWorkflow == null)
			{
				// No out/No pending approval row, Create new row
				outWorkflow = createNewWorkflowForInquiry(fromGroupId, INQUIRY_DIRECTION_OUT, action, workflowTransferDataObj, soeId, currentTime, null, inquiry.getLatestGroupId());
				//outWorkflow.setInquiryRefSent("Y");
				isNewOutWorkflow = true;
				
				updateLastAssignUserDetail(workflowList, fromGroupId, inquiry.getLatestGroup(), soeId, outWorkflow);
				// Method to update Re-Open date for Outbox version
				updateReOpenDateForOutVersion(outWorkflow, reOpenDate);
				outWorkflow.setLinkId(linkId);
				if(null != workflowTransferDataObj)
				{
					outWorkflow.setLock(workflowTransferDataObj.getLock());
					outWorkflow.setLockedBy(workflowTransferDataObj.getLockedBy());
					outWorkflow.setLockedDate(workflowTransferDataObj.getLockedDate());
					outWorkflow.setWorkflowStatus(workflowTransferDataObj.getWorkflowStatus());
					outWorkflow.setReAgeDate(workflowTransferDataObj.getReAgeDate());
					outWorkflow.setIsManualEscalation(workflowTransferDataObj.getIsManualEscalation());
					outWorkflow.setManualEscalationReason(workflowTransferDataObj.getManualEscalationReason());
					outWorkflow.setSuggestionIndicator(workflowTransferDataObj.getSuggestionIndicator());
					outWorkflow.setIntentSuggestionName(workflowTransferDataObj.getIntentSuggestionName());
					outWorkflow.setUserIntentSuggestionName(workflowTransferDataObj.getUserIntentSuggestionName());
					outWorkflow.setIntentTimeToVD(workflowTransferDataObj.getIntentTimeToVD());
					}
				if(null != originDate)
				{
					outWorkflow.setOriginDate(originDate);
				}
				outWorkflow.setCrtDate(null != workflowTransferDataObj.getCrtDate()? workflowTransferDataObj.getCrtDate():outWorkflow.getCrtDate());
				outWorkflow.setCrtBy(null != workflowTransferDataObj.getCrtBy()?workflowTransferDataObj.getCrtBy():outWorkflow.getCrtBy());
				// C153176-154 ActionStatistics Improvements-C153176-290
				updatePrevResponseCounterForOutVersion(outWorkflow, action);

				outWorkflow.setConvCount(prevConvCount);
				outWorkflow.setLastActionby(userName);
				outWorkflow.setLastActionTime(currentTime);
				// [C153176-774] - Root cause for reaply/reply all resolve
				if (!StringUtils.isBlank(resolveRootCause))
				{
					outWorkflow.setRootCause(resolveRootCause);
				}
				// [C153176-793] Add Processing Region as a drop-down in Group Admin screen
				if (!StringUtils.isBlank(resolveProcessingRegion))
				{
					outWorkflow.setProcessingRegion(resolveProcessingRegion);
				}				
				if(!StringUtils.isBlank(tag))
				{
					outWorkflow.setTag(tag);
				}
				if (null != latestConversationTime)
				{
					outWorkflow.setLatestConversationTime(latestConversationTime);
				}
				if (queryCount != null)
				{
					outWorkflow.setQueryCount(queryCount);
				}
				if (null != followUp)
				{
					outWorkflow.setFollowUp(followUp);
				}
				outWorkflow.setIsLastConvToExtEmail(isLastConvToExtEmail);
				if (isMakerCheckerEnabled && "Y".equalsIgnoreCase(QMACacheFactory.getCache().getEnableMakerCheckerForUnapprovedDomains()))
				{
					InquiryUtil.updatePendingExternalDomainForWorkflow(outWorkflow, pendingExternalDomains);
				}
				
				// C153176-5891 | Set values to out workflow
				outWorkflow.setIsLatestResponseFromNonQMA(isLatestResponseFromNonQMA);
				
				if(null != firstNonChaserResponseTimeByExternal) {
					outWorkflow.setFirstNonChaserResponseTimeByExternal(firstNonChaserResponseTimeByExternal);
				}
				
			}
			else
			{
				
				updateLastAssignUserDetail(workflowList, fromGroupId, inquiry.getLatestGroup(), soeId, paWorkflow);
				// C153176-154 ActionStatistics Improvements-C153176-290
				updatePrevResponseCounterForOutVersion(paWorkflow, action);
				paWorkflow.setLastActionby(userName);
				paWorkflow.setLastActionTime(currentTime);
				if (!StringUtils.isBlank(resolveRootCause))
				{
					paWorkflow.setRootCause(resolveRootCause);
				}
				if (!StringUtils.isBlank(resolveProcessingRegion))
				{
					paWorkflow.setProcessingRegion(resolveProcessingRegion);
				}				
				if(!StringUtils.isBlank(tag))
				{
					paWorkflow.setTag(tag);
				}
				if (queryCount != null)
				{
					paWorkflow.setQueryCount(queryCount);
				}
				if(null != followUp)
				{
					paWorkflow.setFollowUp(followUp);
				}
				paWorkflow.setIsLastConvToExtEmail(isLastConvToExtEmail);
				if (isMakerCheckerEnabled && "Y".equalsIgnoreCase(QMACacheFactory.getCache().getDefaultStaticData().getEnableMakerCheckerForUnapprovedDomains()))
				{
					InquiryUtil.updatePendingExternalDomainForWorkflow(paWorkflow, pendingExternalDomains);
				}
				
				// C153176-5891 | Set values to out workflow
				paWorkflow.setIsLatestResponseFromNonQMA(isLatestResponseFromNonQMA);
				
				if(null != firstNonChaserResponseTimeByExternal) {
					paWorkflow.setFirstNonChaserResponseTimeByExternal(firstNonChaserResponseTimeByExternal);
				}
			}
			updateMakerChecker(inquiry, fromGroupId, outWorkflow, isMakerCheckerEnabled, currentTime, uiWorkflowStatus);
			if (isNewOutWorkflow)
			{
				workflowList.add(outWorkflow);
			}
		}
		// Keep Outbox status upto date with inbox
		if (!isMakerCheckerEnabled && outWorkflow != null)
		{
			Workflow inWorkflow = getWorkflow(inquiry.getWorkflows(), fromGroupId, INQUIRY_DIRECTION_IN);
			copyWorkFlowStatus(inWorkflow, outWorkflow, action, resolveRootCause, resolveProcessingRegion, queryCount, currentTime, inquirySource);
		}
	}

	private void updateReOpenDateForOutVersion(Workflow outWorkflow, Date reOpenDate)
	{
		// Set ReOpen Date from IN workflow
		if (reOpenDate != null)
		{
			outWorkflow.setReOpenDate(reOpenDate);
		}
	}

	
	private void updateLastAssignUserDetail(List<Workflow> workflowList, Long fromGroupId, String groupName, String soeId,
			Workflow outWorkflow) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		boolean isUserActiveAndInOffice = true;
		// handles Self Inquiry and Retaining IN Version assigned data if any
		String assignUserId = soeId;
		String assignUserName = getAssignUserName(soeId, groupName);
		// Check for any existing IN Version and retain the assignment if any
		Workflow inWorkflow = getWorkflow(workflowList, fromGroupId,
				INQUIRY_DIRECTION_IN);
		// Retain Existing IN Version Data
		if (inWorkflow != null)
		{

			if (!StringUtils.isBlank(inWorkflow.getAssignedUserId()))
			{
				// Retain the InBox assignment in outversion
				assignUserId = inWorkflow.getAssignedUserId();
				assignUserName = inWorkflow.getAssignedUserName();
			}
			else
			{
				isUserActiveAndInOffice = isUserActiveAndInOffice(assignUserId);
				if (isUserActiveAndInOffice) {
					// Update IN Version with Last Action User
					inWorkflow.setAssignedUserName(assignUserName);
					inWorkflow.setAssignedUserId(assignUserId);	
				} else {
					inWorkflow.setAssignedUserName(null);
					inWorkflow.setAssignedUserId(null);
				}
			}
			if (null != inWorkflow.getUnassignedTimeInMins())
			{
				outWorkflow.setUnassignedTimeInMins(inWorkflow.getUnassignedTimeInMins());
			}
			if(null != inWorkflow.getResolutionTimeInMinutes()) {
				outWorkflow.setResolutionTimeInMinutes(inWorkflow.getResolutionTimeInMinutes());
			}
		}
		if (isUserActiveAndInOffice) {
			outWorkflow.setAssignedUserName(assignUserName);
			outWorkflow.setAssignedUserId(assignUserId);
		} else {
			outWorkflow.setAssignedUserName(null);
			outWorkflow.setAssignedUserId(null);
		}
		
	}

	private void updateMakerChecker(Inquiry inquiry, Long groupId, Workflow outWorkflow, boolean isMakerCheckerEnabled, Date currentTime, String uiWorkflowStatus)
	{
		// boolean isMakerCheckerEnabled= isExternalMail&&makerCheckerRqd&& !approvalBypassed;
		// Get PA Workflow based on isExternalMail,makerCheckerRqd,approvalBypassed flag
		Workflow pendingAppWorkflow = getPendingApprovalWorkflow(inquiry.getWorkflows(), groupId, isMakerCheckerEnabled);

		// If PA workflow exists, update it else update OUTworkflow

		updateMakerCheckerForWorkflow(outWorkflow, currentTime, pendingAppWorkflow, inquiry.getModBy(), isMakerCheckerEnabled, uiWorkflowStatus);
	}

	private Workflow getPendingApprovalWorkflow(List<Workflow> workflowList, Long groupId, Boolean isMakerCheckerEnabled)
	{
		Workflow pendingAppWorkflow = null;
		if (isMakerCheckerEnabled)
		{
			// Check if Pending approval row already exists
			pendingAppWorkflow = getWorkflow(workflowList, groupId, INQUIRY_DIRECTION_PENDING_APPROVAL);
		}
		return pendingAppWorkflow;
	}

	private void updateMakerCheckerForWorkflow(Workflow outWorkflow, Date currentTime, Workflow pendingAppWorkflow, String modBy, Boolean isMakerCheckerEnabled, String uiWorkflowStatus)// Sonar Fix -- remove useless parameter
	{
		if (isMakerCheckerEnabled)
		{
			// If exists, update maker and moddate
			if (pendingAppWorkflow != null)
			{
				pendingAppWorkflow.setMaker(modBy);
				pendingAppWorkflow.setModDate(currentTime);
				pendingAppWorkflow.setWorkflowStatus(WORKFLOW_STATUS_PND_OUTBOUND_EMAIL);
				if(StringUtils.isNotBlank(uiWorkflowStatus))
				{
					pendingAppWorkflow.setWorkflowStatus(uiWorkflowStatus);
				}
				// Update reopendate if present
				if (outWorkflow != null && outWorkflow.getReOpenDate() != null)
				{
					pendingAppWorkflow.setReOpenDate(outWorkflow.getReOpenDate());
				}
			}
			else if (outWorkflow != null)
			{
				// Move OUT to PENDING Approval
				outWorkflow.setDirection(INQUIRY_DIRECTION_PENDING_APPROVAL);
				outWorkflow.setMaker(modBy);
				outWorkflow.setModDate(currentTime);
				outWorkflow.setWorkflowStatus(WORKFLOW_STATUS_PND_OUTBOUND_EMAIL);
				if(StringUtils.isNotBlank(uiWorkflowStatus))
				{
					outWorkflow.setWorkflowStatus(uiWorkflowStatus);
				}
			}
		}
	}

	private Workflow getWorkflow(List<Workflow> inquiryWorkflowList, Long groupId, String direction)
	{
		//return getWorkflow(inquiryWorkflowList, groupId, direction,null);
		Workflow workflow = null;
		if (inquiryWorkflowList == null || inquiryWorkflowList.isEmpty())
		{
			return workflow;
		}
		//Do not get workflow for external organization
		List<Long> ignoredDLForTaskize = getIgnoredQmaDlForTaskizeFromCache();
		for (Workflow inqWorkflow : inquiryWorkflowList)
		{
			if (inqWorkflow.getDirection() != null && direction.equals(inqWorkflow.getDirection()) && inqWorkflow.getAssignedGroupId() != null && inqWorkflow.getAssignedGroupId().equals(groupId) && !ignoredDLForTaskize.contains(inqWorkflow.getAssignedGroupId()))
			{
				workflow = inqWorkflow;
				break;
			}
		}
		return workflow;
	}


	private Workflow getWorkflow(List<Workflow> inquiryWorkflowList, Long groupId, String direction, String workflowType)
	{
		Workflow workflow = null;
		if (inquiryWorkflowList == null || inquiryWorkflowList.isEmpty())
		{
			return workflow;
		}
		for (Workflow inqWorkflow : inquiryWorkflowList)
		{
			if (inqWorkflow.getDirection() != null && direction.equals(inqWorkflow.getDirection()) && inqWorkflow.getAssignedGroupId() != null && inqWorkflow.getAssignedGroupId().equals(groupId))
			{
				workflow = inqWorkflow;
				if(StringUtils.isBlank(workflowType) || workflowType.equals(inqWorkflow.getWorkflowStatus())){
					break;
				}

			}

		}

		return workflow;
	}

	// Get Groups which has Open WOrkflows
	public Map<String, String> getOpenGroups(List<Workflow> workFlowList)
	{
		// existing call
		return getOpenGroups(workFlowList, null, null);

	}

	private Map<String, String> getOpenGroups(List<Workflow> workFlowList, String newOpenUser, Set<Long> skipGroupIds)
	{
		HashMap<String, String> openGroupUsersMap = new HashMap<String, String>();
		Set<String> openGroupsList = new HashSet<String>();
		Set<String> openUsersList = new HashSet<String>();
		String openGroups = null;
		String openUsers = null;
		getOpenUsers(workFlowList, openGroupsList, openUsersList, skipGroupIds);

		// New Code added to support bulk
		if (!StringUtils.isBlank(newOpenUser))
		{
			openUsersList.add(newOpenUser);
		}

		if (!openGroupsList.isEmpty())
		{
			openGroups = StringUtils.join(openGroupsList, ";");
			openGroupUsersMap.put(OPEN_GROUPS, openGroups);
		}
		if (!openUsersList.isEmpty())
		{
			openUsers = StringUtils.join(openUsersList, ";");
			openGroupUsersMap.put(OPEN_USERS, openUsers);
		}

		return openGroupUsersMap;

	}

	private void getOpenUsers(List<Workflow> workFlowList, Set<String> openGroupsList, Set<String> openUsersList, Set<Long> skipAssignGroupIds)
	{
		Set<Long> groupUsedForCalculation = new HashSet<Long>();
		QMACache qmaCache =  QMACacheFactory.getCache();
		for (Workflow workflow : workFlowList)
		{
			if (STATUS_OPEN.equals(workflow.getStatus()))
			{
				Long workflowAssignGrpId = workflow.getAssignedGroupId();
				if (workflowAssignGrpId != null && !groupUsedForCalculation.contains(workflowAssignGrpId) && !(skipAssignGroupIds != null && skipAssignGroupIds.contains(workflowAssignGrpId)))
				{
					groupUsedForCalculation.add(workflowAssignGrpId);

					String groupCode = qmaCache.getGroupIdToNameMap().get(workflowAssignGrpId);
					if (groupCode != null && !StringUtils.isEmpty(groupCode))
					{
						if (INQUIRY_DIRECTION_IN.equals(workflow.getDirection()))
						{
							openGroupsList.add(groupCode);
						}
						if (!StringUtils.isBlank(workflow.getAssignedUserName()))
						{
							openUsersList.add(workflow.getAssignedUserName());
						}
					}
				}
			}
		}
	}

	private boolean isAllWorkflowResolvedBulk(List<Workflow> workFlowList, Long fromGroupId)
	{
		return isAllWorkflowOfSameStatus(workFlowList, fromGroupId, STATUS_OPEN);
	}

	private boolean isAllWorkflowReOpenBulk(List<Workflow> workFlowList, Long fromGroupId)
	{
		return isAllWorkflowOfSameStatus(workFlowList, fromGroupId, STATUS_RESOLVE);
	}

	// Method to check whether all workflows in the inquiry are of same status
	private boolean isAllWorkflowOfSameStatus(List<Workflow> workFlowList, Long fromGroupId, String checkStatus)
	{
		boolean isSameState = false;
		// It is because, In case external outgoing(reply etc) inquiry there is no internal workflow created, We have to check IN+Open+Resolve exist for this case, Then Mark it as Resolved
		List<Workflow> allINWorkflowListWithCheckStatus = getWorkflowList(workFlowList, INQUIRY_DIRECTION_IN, checkStatus);

		// C153176-1178  - check in pending approval and pending reage as well
		allINWorkflowListWithCheckStatus.addAll(getWorkflowList(workFlowList, INQUIRY_DIRECTION_PENDING_APPROVAL, checkStatus));
		allINWorkflowListWithCheckStatus.addAll(getWorkflowList(workFlowList, INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE, checkStatus));

		if (allINWorkflowListWithCheckStatus == null || allINWorkflowListWithCheckStatus.isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
		{
			// get all open+ resolved workflow with direction = IN, or simply all data with direction = IN both are same thing.
			// as outbox data has direction = out.
			List<Workflow> allINWorkflowListWithoutStatus = getWorkflowList(workFlowList, INQUIRY_DIRECTION_IN, null);
			if (!allINWorkflowListWithoutStatus.isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
			{
				isSameState = true;
			}
		}
		// This condition required if we are resolving the last left over workflow
		else if (allINWorkflowListWithCheckStatus.size() == 1)
		{
			Workflow inWorkflow = allINWorkflowListWithCheckStatus.get(0);
			if (fromGroupId != null && fromGroupId.equals(inWorkflow.getAssignedGroupId()))
			{
				isSameState = true;
			}
		}
		return isSameState;
	}

	/*
	 * Method to check and mark resolve after all workflows are resolved
	 */
	private boolean isAllWorkflowResolved(List<Workflow> workFlowList)
	{
		boolean bReturn = false;
		// It is because, In case external outgoing(reply etc) inquiry there is no internal workflow created, We have to check IN+Open+Resolve exist for this case, Then Mark it as Resolved
		List<Workflow> allOpenINWorkflowList = getWorkflowList(workFlowList, INQUIRY_DIRECTION_IN, STATUS_OPEN);

		// C153176-1178 - check in pending approval and pending reage as well
		allOpenINWorkflowList.addAll(getWorkflowList(workFlowList, INQUIRY_DIRECTION_PENDING_APPROVAL, STATUS_OPEN));
		allOpenINWorkflowList.addAll(getWorkflowList(workFlowList, INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE, STATUS_OPEN));

		if (allOpenINWorkflowList == null || allOpenINWorkflowList.isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
		{
			// get all open+ resolved workflow with direction = IN, or simply all data with direction = IN both are same thing.
			// as outbox data has direction = out.
			List<Workflow> allINOpenResolvedWorkflowList = getWorkflowList(workFlowList, INQUIRY_DIRECTION_IN, null);
			if (!allINOpenResolvedWorkflowList.isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
			{
				bReturn = true;
			}
		}
		return bReturn;
	}

	private List<Workflow> getWorkflowList(List<Workflow> dbWorkflowList, String direction, String status)
	{
		List<Workflow> workflowList = new ArrayList<Workflow>();
		boolean statusFilter = !StringUtils.isEmpty(status);
		for (Workflow inqWorkflow : dbWorkflowList)
		{
			if (inqWorkflow.getDirection() != null && direction.equals(inqWorkflow.getDirection()))
			{
				if (!statusFilter)
				{
					workflowList.add(inqWorkflow);
				}
				else if (null != status && status.equals(inqWorkflow.getStatus())) //<-- sonar fix null pointer
				{
					workflowList.add(inqWorkflow);
				}

			}

		}
		return workflowList;
	}

	private void reopenResolvedWorkflowsInToCcList(List<Workflow> workflowList, Set<Long> toCcGroupIdList, Long fromGrpId, Date currentTime, String userId,String inquiryAction)// Sonar Fix -- remove useless parameter
	{
		if (toCcGroupIdList == null || toCcGroupIdList.isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
		{
			return;
		}
		Workflow replyToWorkflow;
		for (Long groupId : toCcGroupIdList)
		{
			replyToWorkflow = getWorkflow(workflowList, groupId, INQUIRY_DIRECTION_IN);
			Workflow replyToOUTWorkflow = getWorkflow(workflowList, groupId, INQUIRY_DIRECTION_OUT);
			if ((replyToWorkflow == null && replyToOUTWorkflow ==null) 
					|| ((ACTION_REPLY_RESOLVE.contentEquals(inquiryAction) || ACTION_REPLYALL_RESOLVE.equalsIgnoreCase(inquiryAction)) && fromGrpId.equals(groupId)))// Sonar fix -- Reduce the total number of break and continue statements in this loop
				continue;
			if (replyToWorkflow !=null && STATUS_RESOLVE.equals(replyToWorkflow.getStatus()))
			{
				replyToWorkflow.setStatus(STATUS_OPEN);
				if(isInquirySubStatusEnabled(groupId)) {
					replyToWorkflow.setInquirySubStatus(SUB_STATUS_REOPEN);
				}
				replyToWorkflow.setModBy(userId);
				replyToWorkflow.setModDate(currentTime);
				
				replyToWorkflow.setReOpenDate(currentTime);
				// C153176-154-ActionStatistics Improvements
				replyToWorkflow.setPrevResponseCntr(0);// Reset the counter
				replyToWorkflow.setResolver("");
				replyToWorkflow.setResolveTime(null);
				// reopen OUT Workflow if any


			}
			if (replyToOUTWorkflow != null && STATUS_RESOLVE.equals(replyToOUTWorkflow.getStatus()))
			{
				replyToOUTWorkflow.setStatus(STATUS_OPEN);
				if(isInquirySubStatusEnabled(groupId)) {
					replyToOUTWorkflow.setInquirySubStatus(SUB_STATUS_REOPEN);
				}
				replyToOUTWorkflow.setModBy(userId);
				replyToOUTWorkflow.setModDate(currentTime);
				
				replyToOUTWorkflow.setReOpenDate(currentTime);
				// C153176-154-ActionStatistics Improvements
				replyToOUTWorkflow.setPrevResponseCntr(0);// reset the counter
				replyToOUTWorkflow.setResolver("");
				replyToOUTWorkflow.setResolveTime(null);
			}
		}
	}

	// Rules only apply for Inbox Types of View. It doent apply on Resolvedbox , Outbox and Peding Approval Box.
	List<DBObject> getViewData(String collectionName, DBObject finalQuery, DBObject selectColQuery, DBObject orderBy, int maxResults) throws CommunicatorException// Sonar Fix -- Define and throw a
	// dedicated exception instead of
	// using a generic one
	{
		long startTime = System.currentTimeMillis();
		DBCursor cursorDoc = null;
		cursorDoc = getViewDataDBResultSet(collectionName, finalQuery, selectColQuery, orderBy, maxResults);

		List<DBObject> dbObjectList = new ArrayList<DBObject>();
		while (cursorDoc.hasNext())
		{
			dbObjectList.add(cursorDoc.next());
		}

		subLogger.info("Inside .getViewDataDBResultSet Time Diff-"
				+ (System.currentTimeMillis() - startTime)
				+ " in Milli Seconds");
		return dbObjectList;
	}

	private DBCursor getViewDataDBResultSet(String collectionName, DBObject finalQuery, DBObject selectColQuery, DBObject orderBy, int uiGridRecordLimit)
	{
		DBCursor cursorDoc = null;
		int uiGridRecLimit = uiGridRecordLimit;// Sonar Fix -- Introduce a new variable instead of reusing the parameter
		DBObject selectColQry = selectColQuery;// Sonar Fix -- Introduce a new variable instead of reusing the parameter
		DBObject orderByToPass = orderBy;// Sonar Fix -- Introduce a new variable instead of reusing the parameter

		if (uiGridRecLimit == 0)
		{
			uiGridRecLimit = MAX_SERVER_REC_LIMIT;
		}
		else
		{
			uiGridRecLimit = (uiGridRecLimit > MAX_SERVER_REC_LIMIT) ? MAX_SERVER_REC_LIMIT : uiGridRecLimit;
		}

		// boolean bLimitRecord = uiGridRecordLimit > 0;

		subLogger.info("FinalQuery:"+finalQuery);
		if (orderByToPass == null)
		{
			orderByToPass = new BasicDBObject(MODIFIED_DATE, -1);
		}
		if (selectColQry == null)
		{
			// Select all columns
			selectColQry = new BasicDBObject();
		}
		// system.out.println("***Final query is:" + finalQuery);
		cursorDoc = database.getCollection(collectionName).find(finalQuery, selectColQry).sort(orderByToPass).limit(uiGridRecLimit);
		// System.out.println("***Final query is:" + finalQuery);
		return cursorDoc;
	}

	public List<DashBoardCntTO> getHomePageWidgetCount(String soeId) //throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			//String query = HOMEPAGE_WIDGET_AGGR_QUERY.replaceAll("#soeId#", soeId);
			String query = HOMEPAGE_WIDGET_AGGR_QUERY_WITH_MOD_DATE.replaceAll("#soeId#", soeId);
			String viewName = null;
			Map<String, Integer> viewsSortedMapForUserId = getUserDateConfigForViewFromCache(soeId);
			if(null != viewsSortedMapForUserId && viewsSortedMapForUserId.size() > 0) {
					viewName = (String) viewsSortedMapForUserId.keySet().toArray()[0];
			}
			if(StringUtils.isEmpty(viewName)) {
				viewName = "Default";
			}
			Date dateCriteria =  MailboxModDateUtil.getModDateAsPerDateConfig(soeId, null, viewName,false);
			if(null != dateCriteria) {
				Long dateLong = dateCriteria.getTime();
				query = query.replaceAll(MOD_DATE_EXP, dateLong.toString());				
			}
			query = replaceCriteriaAsPerView(soeId, query, dateCriteria, viewsSortedMapForUserId);
			List<DBObject>  output = BuildGroupLevelAggregateOption(INQUIRY, soeId,query, null, null, 0, null);
			return processWidgetCountData(soeId, output);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getDashSnapshotCnts for user= " + soeId, e);
			//throw new CommunicatorException("Exception in getDashSnapshotCnts for user= " + soeId, e);
			return null;
		}
	}

	/**
	 * @return
	 */
	public Map<String, Integer> getUserDateConfigForViewFromCache(String soeId) {
		Map<String, Integer> userHighestDateConfiguredViewSortedMap = null;
		try {
			userHighestDateConfiguredViewSortedMap = QMACacheFactory.getCache().getUserHighestDateConfiguredViewMap().get(soeId.toUpperCase());
		} catch (Exception e) {
			subLogger.warn("Error while fetching userHighestDateConfiguredViewSortedMap fromcache userId:"+soeId, e);
		}
		return userHighestDateConfiguredViewSortedMap;
	}
	/**
	 * @param soeId
	 * @param query
	 * @param dateCriteria
	 * @param viewsSortedMap 
	 * @return
	 * @throws CommunicatorException
	 */
	private String replaceCriteriaAsPerView(String soeId, String query, Date dateCriteria, Map<String, Integer> viewNameMonthsMap) {
		try {
			Long dateLongDefault = dateCriteria.getTime();
			if(null != viewNameMonthsMap) {
				Integer noOfMonthsPending = viewNameMonthsMap.get(DEFAULT_VIEW_TYPE_PENDING_APPROVAL);
				if(null != noOfMonthsPending && 0 < noOfMonthsPending) {
					Date dateCriteriaPending =  MailboxModDateUtil.getDateRangeModDate(noOfMonthsPending);
					Long dateLong = dateCriteriaPending.getTime();
					query = query.replaceAll(MOD_DATE_PENDINGAPPROVAL, dateLong.toString());
				}else {
					query = query.replaceAll(MOD_DATE_PENDINGAPPROVAL, dateLongDefault.toString());
				}
				Integer noOfMonthsInbox = viewNameMonthsMap.get(INBOX);
				if(null != noOfMonthsInbox && 0 < noOfMonthsInbox){
					Date dateCriteriaInbox =  MailboxModDateUtil.getDateRangeModDate(noOfMonthsInbox);
					Long dateLong = dateCriteriaInbox.getTime();
					query = query.replaceAll(MOD_DATE_INBOX, dateLong.toString());
				}else {
					query = query.replaceAll(MOD_DATE_INBOX, dateLongDefault.toString());
				}
				Integer noOfMonthsEscalation = viewNameMonthsMap.get(DEFAULT_VIEW_TYPE_ESCALATION);
				if(null != noOfMonthsEscalation && 0 < noOfMonthsEscalation) {
					Date dateCriteriaEscalation =  MailboxModDateUtil.getDateRangeModDate(noOfMonthsEscalation);
					Long dateLong = dateCriteriaEscalation.getTime();
					query = query.replaceAll(MOD_DATE_ESCALATION, dateLong.toString());
				}else {
					query = query.replaceAll(MOD_DATE_ESCALATION, dateLongDefault.toString());
				}
			}else {
				query = query.replaceAll(MOD_DATE_PENDINGAPPROVAL, dateLongDefault.toString());
				query = query.replaceAll(MOD_DATE_INBOX, dateLongDefault.toString());
				query = query.replaceAll(MOD_DATE_ESCALATION, dateLongDefault.toString());
			}
		} catch (Exception e) {
			Long dateLongDefault = dateCriteria.getTime();
			query = query.replaceAll(MOD_DATE_PENDINGAPPROVAL, dateLongDefault.toString());
			query = query.replaceAll(MOD_DATE_INBOX, dateLongDefault.toString());
			query = query.replaceAll(MOD_DATE_ESCALATION, dateLongDefault.toString());
			subLogger.warn("Error while adding date criteria for soeId:"+soeId, e);
		}
		return query;
	}
	
	
	/**
	 * @param soeId
	 * @return
	 * @throws CommunicatorException
	 */
	private Map<String, Integer> getViewNameMonthsMap(String soeId) throws CommunicatorException {
		List<String> dashBoardCountDefaultViews = Arrays.asList(INBOX, ASSIGNED_TO_ME_VIEW, UNASSIGNED, DEFAULT_VIEW_TYPE_PENDING_APPROVAL,DEFAULT_VIEW_TYPE_ESCALATION);
		Map<String, Integer> viewsMap = new HashMap<>();
		
		if(!StringUtils.isEmpty(soeId)) {
			User user = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase());
			if(null == user) {
				user = userDao.getUserById(soeId);
			}
			for(String viewName:dashBoardCountDefaultViews) {
				int dateRangeInMonths = 0;
				if (null != user && null != user.getViewDateRangeConfig()) {
					for(Map<String, Object> viewConfig : user.getViewDateRangeConfig()) {
						if(null != viewConfig.get("viewName") && null != viewConfig.get("months") && viewName.equalsIgnoreCase(viewConfig.get("viewName").toString())) {
							dateRangeInMonths = (int) viewConfig.get("months");
							break;
						}
					}			
				}
				if(0 < dateRangeInMonths) {
					viewsMap.put(viewName, dateRangeInMonths);
				}else {
					dateRangeInMonths =  MailboxModDateUtil.getDateConfigDefault(viewName);
					if(0 < dateRangeInMonths) {
						viewsMap.put(viewName, dateRangeInMonths);
						break;
					}
				}
			}
		}
		 return viewsMap;
	}

	/**
	 * @param viewsMap
	 * @return
	 * @throws CommunicatorException 
	 */
	public Map<String, Integer> getHighestConfiguredDatRangeSortedMap(String soeId) throws CommunicatorException {
	Map<String, Integer> viewsMap = getViewNameMonthsMap(soeId);
	Map<String, Integer> viewsSortedMap = null;
		if(null != viewsMap && viewsMap.size() > 0) {
		viewsSortedMap = viewsMap.entrySet().stream()
	                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
	                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
	                        (oldValue, newValue) -> oldValue, LinkedHashMap::new));
		}
		if(null != viewsSortedMap && viewsSortedMap.size() > 0) {
			return viewsSortedMap;
		}else {
			return viewsMap;
		}
	}

	public List<DashBoardCntTO> getUnReadCount(String soeId) {
		List<DashBoardCntTO> unreadCountList = new ArrayList<>();
		try {
			String finalQuery = HOMEPAGE_WIDGET_AGGR_QUERY_UNREAD_COUNT.replace("#soeId#", soeId);
			List<DBObject>  outputUnread = BuildGroupLevelAggregateOption(INQUIRY, soeId,finalQuery, null, null, 0, null);
			unreadCountList = processWidgetCountData(soeId, outputUnread);
			
		} catch (Exception e) {
			subLogger.error("Error while getting unRead count",e);
		}
		return unreadCountList;
	}

	/**
	 * @param soeId
	 * @return
	 * @throws CommunicatorException
	 * Prepare the final query to fetch the list of inquiries in the Assigned to me box
	 */
	public Cursor getListOfAssignedtoMeInquiry(String soeId) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		//db.Inquiry.aggregate({   "$match" : { "$and" : [ { "status" : "Open" , "workflows" : { "$elemMatch" : { "status" : "Open" , "direction" : "IN" , "assignedGroupId" : { "$in" : [ 2533 , 2534 , 2535 , 2522 , 53051 , 55051 , 4395 , 347 , 53052 , 5965 , 53053 , 62]} }}}]}} , { "$project" : { "id" : 1 , "origGroupName" : 1 , "workflows" : 1 , "assignedUserId" : "$workflows.assignedUserId" }} , { "$unwind" : "$workflows"} , { "$match" : { "workflows.status" : "Open" , "workflows.direction" : "IN" , "workflows.assignedGroupId" : { "$in" : [ 2533 , 2534 , 2535 , 2522 , 53051 , 55051 , 4395 , 347 , 53052 , 5965 , 53053 , 62]}}} ,{ "$match" : { "workflows.assignedUserId" : "XXXXXX"}} , { "$sort" : { "modDate" : -1}} , { "$limit" : 100} )
		StringBuilder finalQueryBuilder = new StringBuilder("[");
		finalQueryBuilder.append(ASSIGNED_TO_ME);
		finalQueryBuilder.append(" ]");
		Set<Long> userGroupsList = userDao.getUserGroupsList(soeId);
		List<DBObject> query = DataConversionUtil.convertJsonToDBObjectList(finalQueryBuilder.toString().replace("[?]", "" + userGroupsList.toString()).replace(":?", ":"+"'"+soeId+"'"));
		DBCollection col = database.getCollection(INQUIRY);
		AggregationOptions aggregationOptions = AggregationOptions.builder().build();
		Cursor output = col.aggregate(query, aggregationOptions, ReadPreference.secondaryPreferred());
			
		return output;
	}
	
	
	/**
	 * @param soeId
	 * @return
	 * @throws CommunicatorException
	 * Create the list inquiry Object from the list of inquiryId 
	 */
	public boolean resetInquiryAssignmentForOOO(String soeId) throws CommunicatorException
	{
		boolean bSuccess = true;
		List<Long> inquiryIds;
		List<Inquiry> inquiryObjs = null;
		try {
			Cursor outputList = getListOfAssignedtoMeInquiry(soeId);
			if (null != outputList) 
			{
				inquiryIds = new  ArrayList<>();
				while (outputList.hasNext())
				{
					DBObject viewCountObj = outputList.next();
					Long inquiryId=(Long) viewCountObj.get("_id");
					inquiryIds.add(inquiryId);
				}
				outputList.close();
				
				if (null!=inquiryIds && !inquiryIds.isEmpty()) 
				{
					inquiryObjs = getInquiryList(inquiryIds);
				}
				if (inquiryObjs != null)
				{
					bSuccess = makeInquiryWrokflowUnassignedForOOO(inquiryObjs, soeId);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in resetInquiryAssignmentForOOO for user= " + soeId, e);
			throw new CommunicatorException("Exception in resetInquiryAssignmentForOOO for user= " + soeId, e);
		}
		return bSuccess; 
		
	}
	
	/**
	 * @param inquiryObjs
	 * @param soeId
	 * @return
	 * @throws CommunicatorException
	 * Create the DBObject for the required workflow to be updated as a part of OOO Operation and execute the Update Operation
	 */
	public boolean makeInquiryWrokflowUnassignedForOOO(List<Inquiry> inquiryObjs, String soeId)throws CommunicatorException
	{
		DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
		BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();
		Date currentTime = new Date();
		Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
		Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
		for (Inquiry inquiry :inquiryObjs)
		{
			List<Workflow> workflowList= inquiry.getWorkflows();
			
			for (Workflow workflow: workflowList)
			{
				DBObject inquiryUpdateDBObj = new BasicDBObject();
				DBObject inquiryUnsetDBObj = new BasicDBObject();
				if ((null!= workflow.getAssignedUserId()) && workflow.getAssignedUserId().equals(soeId) && workflow. getDirection().equals("IN"))
				{
					inquiryUpdateDBObj.put(WORKFLOWS_MODIFIED_BY, soeId);
					inquiryUpdateDBObj.put(WORKFLOWS_MODIFIED_DATE, currentTime);
					
					inquiryUnsetDBObj.put(WORKFLOWS_ASSIGNED_USER_ID, workflow.getAssignedUserId());
					inquiryUnsetDBObj.put(WORKFLOWS_ASSIGNED_USERNAME, workflow.getAssignedUserName());
					bulkWorkflowUpdateOperationForOOO(inquiry, inquiryUpdateDBObj,inquiryUnsetDBObj, soeId, currentTime, workflow.getAssignedGroupId(), bulkInquiryUpdOp);
					UpdateAuditForOOOAction(inquiry, soeId, currentTime, bulkInquiryUpdOp, workflow.getAssignedGroupId());
				}
			}
			
			
			
		}
		bulkInquiryUpdOp.execute();
		return true;
	}
	
	/**
	 * @param inquiry
	 * @param soeId
	 * @param currentTime
	 * @param bulkInquiryUpdOp
	 * @param groupId
	 * Update workflow audit for Out of office.
	 */
	public void UpdateAuditForOOOAction(Inquiry inquiry, String soeId, Date currentTime, BulkWriteOperation bulkInquiryUpdOp, Long groupId)
	{	
		Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
		Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
		DBObject workflowAudit = createWorkFlowsAuditJavaDriver(groupId, ACTION_OUT_OF_OFFICE, ACTION_OUT_OF_OFFICE_DETAILS, soeId, currentTime, groupIdToNameMap, userInfoMap);
		workflowAudit.put(INQUIRY_ID, inquiry.id);
		DBObject updateWorkAuditFields = new BasicDBObject();
		updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));
		DBObject findWorkAuditflowQuery = prepareFindQuery(inquiry.id, groupId, STATUS_OPEN, INQUIRY_DIRECTION_IN_OR_OUT, false);
		bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);
	}
	
	/**
	 * @param inquiryCollection
	 * @param inquiryUpdateDBObj
	 * @param findINWorkflowQuery
	 * @param userName
	 * @param currentTime
	 * Set the fields to be updated.
	 */
	public void bulkWorkflowUpdateOperationForOOO(Inquiry inquiryObj, DBObject inquiryUpdateDBObj,DBObject inquiryUnsetDBObj,
			String userName, Date currentTime, Long groupId, BulkWriteOperation bulkInquiryUpdOp) throws CommunicatorException{
		
		DBObject findINWorkflowQuery = prepareFindQuery(inquiryObj.id, groupId, STATUS_OPEN, INQUIRY_DIRECTION_IN, true);
		inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
		inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
		DBObject updateDBFields = new BasicDBObject();
		updateDBFields.put("$set", inquiryUpdateDBObj);
		updateDBFields.put("$unset", inquiryUnsetDBObj);
		bulkInquiryUpdOp.find(findINWorkflowQuery).update(updateDBFields);
	}
	
	
	private List<DashBoardCntTO> processWidgetCountData(String soeId, List<DBObject> output) throws CommunicatorException
	{
		List<DashBoardCntTO> dashBoardCntTOList = new ArrayList<>();
		Long assignedToUserCount = 0L;
		Long unAssignedToUserCount = 0L;
		Long pendingApprovalCount = 0L;
		Long inboxCount = 0L;
		Long escalationCount = 0L;
		Long assignedToUserCountUnRead = 0L;
		Long unAssignedToUserCountUnRead = 0L;
		Long pendingApprovalCountUnRead = 0L;
		Long inboxCountUnRead = 0L;
		Long escalationCountUnRead = 0L;
		// Only One Record with Count
		for (DBObject viewCountObj : output)
		{
			String dataSoeId=(String) viewCountObj.get("_id");
			Long inboxRecCnt=GenericUtility.getIdFromRequest((BasicDBObject) viewCountObj, "IN");
			Long inboxRecCntRead=GenericUtility.getIdFromRequest((BasicDBObject) viewCountObj, "INREAD");
			if(soeId.equalsIgnoreCase(dataSoeId)){
				assignedToUserCount=assignedToUserCount+inboxRecCnt;
				assignedToUserCountUnRead = assignedToUserCountUnRead+inboxRecCntRead;
			}else if(null == dataSoeId){
				unAssignedToUserCount+=inboxRecCnt;
				unAssignedToUserCountUnRead=unAssignedToUserCountUnRead+inboxRecCntRead;
			}
			inboxCount=inboxCount+inboxRecCnt;
			inboxCountUnRead=inboxCountUnRead+inboxRecCntRead;
			
			pendingApprovalCount=pendingApprovalCount+GenericUtility.getIdFromRequest((BasicDBObject) viewCountObj, "PENDINGAPPROVAL");
			escalationCount=escalationCount+GenericUtility.getIdFromRequest((BasicDBObject) viewCountObj, "ESCALATION");
			
			pendingApprovalCountUnRead=pendingApprovalCountUnRead+GenericUtility.getIdFromRequest((BasicDBObject) viewCountObj, "PNDREAD");
			escalationCountUnRead=escalationCountUnRead+GenericUtility.getIdFromRequest((BasicDBObject) viewCountObj, "ESCREAD");
			
		}

		DashBoardCntTO inboxCnt = new DashBoardCntTO(INBOX, inboxCount,inboxCount-inboxCountUnRead );
		dashBoardCntTOList.add(inboxCnt);

		DashBoardCntTO assignCnt = new DashBoardCntTO("Assigned to me", assignedToUserCount,assignedToUserCount-assignedToUserCountUnRead);
		dashBoardCntTOList.add(assignCnt);

		DashBoardCntTO unAssignCnt = new DashBoardCntTO("Unassigned", unAssignedToUserCount,unAssignedToUserCount-unAssignedToUserCountUnRead);
		dashBoardCntTOList.add(unAssignCnt);

		DashBoardCntTO pendingApprovalMsgTo = new DashBoardCntTO(DEFAULT_VIEW_TYPE_PENDING_APPROVAL, pendingApprovalCount,pendingApprovalCount-pendingApprovalCountUnRead);
		dashBoardCntTOList.add(pendingApprovalMsgTo);

		DashBoardCntTO escalationMsgTo = new DashBoardCntTO(DEFAULT_VIEW_TYPE_ESCALATION, escalationCount,escalationCount-escalationCountUnRead);
		dashBoardCntTOList.add(escalationMsgTo);

		DBObject sent = getBasicDBObject(OUTBOX,"1", soeId);
		DashBoardCntTO sentCnt = new DashBoardCntTO("Sent",getTotalRecords(sent),getTotalUnreadRecords(sent));
		dashBoardCntTOList.add(sentCnt);

		DBObject resolved = getBasicDBObject(STATUS_RESOLVE,"2", soeId);
		DashBoardCntTO resolvedCnt = new DashBoardCntTO(STATUS_RESOLVE, getTotalRecords(resolved),getTotalUnreadRecords(resolved));
		dashBoardCntTOList.add(resolvedCnt);

		DBObject snoozed = getBasicDBObject(DEFAULT_VIEW_TYPE_SNOOZED,"0", soeId);
		DashBoardCntTO snoozedCnt = new DashBoardCntTO(DEFAULT_VIEW_TYPE_SNOOZED, getTotalRecords(snoozed),getTotalUnreadRecords(snoozed));
		dashBoardCntTOList.add(snoozedCnt);

		DBObject drafts = getBasicDBObject(DRAFTS,"9", soeId);
		DashBoardCntTO draftsCnt = new DashBoardCntTO(DRAFTS,  getTotalRecords(drafts),getTotalUnreadRecords(drafts));
		dashBoardCntTOList.add(draftsCnt);

		DBObject nonInquiries = getBasicDBObject(DEFAULT_VIEW_TYPE_NON_INQUIRY,"0",soeId);
		DashBoardCntTO nonInquiriesCnt = new DashBoardCntTO(DEFAULT_VIEW_TYPE_NON_INQUIRY, getTotalRecords(nonInquiries),getTotalUnreadRecords(nonInquiries));
		dashBoardCntTOList.add(nonInquiriesCnt);

		return dashBoardCntTOList;
	}

	private DBObject getBasicDBObject(String viewName, String viewType, String soeId) {
		BasicDBObject baseDBObject = new BasicDBObject();
		baseDBObject.put(VIEW_NAME, viewName);
		baseDBObject.put(VIEW_TYPE, viewType);
		baseDBObject.put("pageNum", 1);
		baseDBObject.put("pageSize", 100);
		return InquiryExtendedDAO.getInstance().getGridViewTotalCount(soeId,baseDBObject);
	}

	private Long getTotalRecords(DBObject dbObject){
		return  Long.parseLong(String.valueOf(dbObject.get(TOTAL_RECORDS)));
	}

	private Long getTotalUnreadRecords(DBObject dbObject){
		return Long.parseLong(String.valueOf(dbObject.get(TOTAL_UNREAD_RECORDS)));
	}


	// Method can be moved to Util
	private HashMap<String, ArrayList<String>> getToCcList(BasicDBObject inputJsonObj, String recipientCategory)
	{
		HashMap<String, ArrayList<String>> toCCDataFromJson = null;
		ArrayList<String> groupNameslist = null;
		ArrayList<String> groupIdslist = null;

		if (inputJsonObj.getString(recipientCategory) != null)
		{
			toCCDataFromJson = new HashMap<String, ArrayList<String>>();
			groupNameslist = new ArrayList<String>();
			groupIdslist = new ArrayList<String>();

			JSONArray jsArray = new JSONArray(inputJsonObj.getString(recipientCategory));
			for (int i = 0; i < jsArray.length(); i++)
			{
				JSONObject jsonObj = jsArray.getJSONObject(i);

				groupNameslist.add(jsonObj.getString("text"));
				groupIdslist.add(jsonObj.getString(VALUE));

			}

			toCCDataFromJson.put(LIST_BY_NAMES, groupNameslist);
			toCCDataFromJson.put(LIST_BY_IDS, groupIdslist);
		}

		return toCCDataFromJson;
	}
	
	private HashMap<String, String> getToCcListMapIdName(BasicDBObject inputJsonObj, String recipientCategory)
	{
		HashMap<String, String> toCCDataFromJson = null;
		ArrayList<String> groupNameslist = null;
		ArrayList<String> groupIdslist = null;

		if (inputJsonObj.getString(recipientCategory) != null)
		{
			toCCDataFromJson = new HashMap<String, String>();
			JSONArray jsArray = new JSONArray(inputJsonObj.getString(recipientCategory));
			for (int i = 0; i < jsArray.length(); i++)
			{
				JSONObject jsonObj = jsArray.getJSONObject(i);
				toCCDataFromJson.put(jsonObj.getString(VALUE), jsonObj.getString("text"));
			}
		}
		return toCCDataFromJson;
	}

	private String updateInquiryRequestType(List<Workflow> workflowList, String newReqTypeStr, Set<Long> skipAssignGrpIds)
	{
		StringBuilder requestTypes = new StringBuilder();
		String reqTypesStr = null;
		String newReqTypeString = newReqTypeStr;// Sonar Fix -- Introduce a new variable instead of reusing the parameter
		QMACache qmaCache = QMACacheFactory.getCache();
		Map<Long, String> groupIdToNameMap = qmaCache.getGroupIdToNameMap();
		if (skipAssignGrpIds != null)
		{
			for (Long grpId : skipAssignGrpIds)
			{
				String groupName = groupIdToNameMap.get(grpId);
				if (groupName != null)
					newReqTypeString = newReqTypeString + "[" + groupName + "]";
			}
		}

		// New ReqType
		if (!StringUtils.isBlank(newReqTypeString) && requestTypes.indexOf(newReqTypeString) == -1)
		{
			requestTypes.append(newReqTypeString).append(",");
		}

		if (workflowList != null)
		{
			for (Workflow wrkflow : workflowList)
			{
				if (!(skipAssignGrpIds != null && skipAssignGrpIds.contains(wrkflow.getAssignedGroupId())) && wrkflow.getRequestType() != null)
				{
					String groupName = qmaCache.getGroupIdToNameMap().get(wrkflow.getAssignedGroupId());
					if (groupName != null)
					{
						String assignReqStr = wrkflow.getRequestType() + "[" + groupName + "]";
						if (requestTypes.toString().toLowerCase().indexOf(assignReqStr.toLowerCase()) == -1)
						{
							requestTypes.append(assignReqStr).append(",");
						}
					}
				}
			}
		}
		if (requestTypes.length() > 0)
		{
			reqTypesStr = requestTypes.substring(0, requestTypes.length() - 1);
		}

		return reqTypesStr;
	}

	private ViewConfig getUserViewConfigForViewName(String soeId, String viewName) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Query<User> query = mongoDatastore.createQuery(User.class).filter(ID_COLUMN, soeId).filter("views.viewName", viewName);
		User user = query.get();
		// get the existing criteria
		ViewConfig viewConfig = getUserViewConfig(viewName, user);
		return viewConfig;
	}

	private ViewConfig getUserViewConfig(String viewName, User user) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		ViewConfig viewConfig = null;
		if (user == null || user.getViews() == null)
		{
			return viewConfig;
		}
		for (ViewConfig vConfig : user.getViews())
		{
			if (viewName.equals(vConfig.getViewName()))
			{
				viewConfig = vConfig;
				break;
			}
		}
		return viewConfig;
	}

	private List<Inquiry> changeStatus_reopen(List<Inquiry> inquiryObjs, String soeId, Set<Long> fromGroupIds, String action, String inquiryActionOnUI, Map<Long, List<Long>> inquiryGroupMap, String actionDetails) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		
		subLogger.info("resolveInquiryBulk for Inquiries size=" + inquiryObjs.size());
		// boolean isResolveAction="RESOLVE".equals(action);
		boolean isReOpenAction = ACTION_REOPEN.equalsIgnoreCase(action);
		List<Inquiry> resolveInquiryList = null;
		DBObject stats = null;
		try
		{
			DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
			BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();

			DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
			BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();
			Date currentTime = new Date();
			DBObject inquiryNote =null;
			resolveInquiryList = new ArrayList<>();
			EscalationUtility escalationUtility = new EscalationUtility();
			escalationUtility.setAllGroupsEscalationCriteriaMap(groupDAO.getGroupEscalationDetailsById(new ArrayList<Long>(fromGroupIds)));
			boolean isBulkAction= inquiryObjs != null && inquiryObjs.size() > 1 ;
			Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			
			for (Inquiry inqObj : inquiryObjs)
			{
				// ReOpen Resolved workflow's only
				String workflowStatus = isReOpenAction ? STATUS_RESOLVE : STATUS_OPEN;
				boolean isInquiryLevelBulkAction = false;
				/*String userName = CacheDAO.getInstance().getUserDetailsMap().get(soeId.toUpperCase()).getName();*/
				List<Long> groupList;
				if(null != inquiryGroupMap && !inquiryGroupMap.isEmpty())
				{
					groupList =  inquiryGroupMap.get(inqObj.getId());
				}else{
					groupList = new ArrayList<>(fromGroupIds);
				}
				
				for (Long fromGroupId : groupList)
				{
					DBObject updateDBFields = new BasicDBObject();
					DBObject unsetFieldObject = new BasicDBObject();
					DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, action);
					inquiryUpdateDBObj.put(MODIFIED_DATE, currentTime);
					inquiryUpdateDBObj.put(MODIFIED_BY, soeId);

					// Prepare new workflow audit obj
					DBObject workflowAudit = createWorkFlowsAuditJavaDriver(fromGroupId, action, action, soeId, currentTime, groupIdToNameMap, userInfoMap);
					workflowAudit.put(INQUIRY_ID, inqObj.id);


					//Modified for requestType in Action Statistics - C153176-1155
					ActionStatistics statsObj = new ActionStatistics();
					stats = getStatsObject(soeId, action, currentTime, inqObj, fromGroupId, isBulkAction, statsObj, groupIdToNameMap, userInfoMap);

					String openGroups = null;
					if (isReOpenAction)
					{
						inquiryUpdateDBObj.put(WORKFLOWS_STATUS, STATUS_OPEN);
						//[C170665-1719] DCC Requirement: Add Case status field
						if(isInquirySubStatusEnabled(fromGroupId)) {
							inquiryUpdateDBObj.put(WORKFLOWS_INQUIRY_SUB_STATUS, SUB_STATUS_REOPEN);
						}
						
						// Release 1.2 changes-Add action in the workflow
						inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_REOPEN);
						inquiryUpdateDBObj.put(ACTION, ACTION_REOPEN);
						if(StringUtils.isNotBlank(actionDetails)) 
							workflowAudit.put(ACTION_DETAILS, actionDetails);
						else
							workflowAudit.put(ACTION_DETAILS, "");
						// Set Inquiry status as Resolved if all workflow status is resolved
						inquiryUpdateDBObj.put(STATUS, STATUS_OPEN);
						
						inquiryUpdateDBObj.put(WORKFLOWS_REOPENED_DATE, currentTime);
						
						inquiryUpdateDBObj.put("workflows.$.prevResponseCntr", 0);// Reset Previous Response counter before resolve to 0
						inquiryUpdateDBObj.put(WORKFLOWS_RESOLVE_TIME, null);
						// re-open action updates the IN version workflow status to 'Open', so Inquiiries opneGroups has to be updated i.e. the re-open group has to be removed from opneGroups
						openGroups = updatedInquiryOpenGroups(ACTION_REOPEN, inqObj, fromGroupIds);
						inqObj.setAction(ACTION_REOPEN);

						//C153176-1055 -- Assign to user who reopened the Inquiry/WF
						String assignGroupName = groupIdToNameMap.get(fromGroupId);
						String assignUserName = getAssignUserName(soeId, assignGroupName);						
						inquiryUpdateDBObj.put("workflows.$.assignedUserId", soeId);
						inquiryUpdateDBObj.put("workflows.$.assignedUserName", assignUserName);

						// Set Inquiry status as Resolved if all workflow status is resolved
						if (isAllWorkflowReOpenBulk(inqObj.getWorkflows(), fromGroupId))
						{
							isInquiryLevelBulkAction = true;

						}
						//set Escalation Time
						if (null != escalationUtility.getAllGroupsEscalationCriteriaMap() && null!= escalationUtility.getAllGroupsEscalationCriteriaMap().get(fromGroupId))
						{
							Integer responseTimeThreshold = escalationUtility.getAllGroupsEscalationCriteriaMap().get(fromGroupId).getResponseTimeThresholdForEscalation();
							if(null!= responseTimeThreshold && responseTimeThreshold > 0)
							{
								inquiryUpdateDBObj.put(WORKFLOWS_RESPONSE_TIME_ESCALATION, "N");
								inquiryUpdateDBObj.put(WORKFLOWS_RESPONSE_TIME_NEXT_ESACLATION, escalationUtility.generateNextEscalationTime(fromGroupId,currentTime,responseTimeThreshold));
								inquiryUpdateDBObj.put(WORKFLOWS_ISPENDINGAPPROVAL_ESCALATION, "N");
							}
						}
						InquiryExtendedDAO.getInstance().removeNominationFieldFromWorkflow(inquiryUpdateDBObj, unsetFieldObject, inqObj.id, fromGroupId, soeId);
						updateDBFields.put("$unset", unsetFieldObject);
					}
					String usrName = GenericUtility.getUserOrSystemName(soeId, userInfoMap);
					inquiryUpdateDBObj.put(OPEN_GROUPS, openGroups);
					inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, usrName);
					inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
					addNoteInResolveInquiry(inquiryNote, inqObj, inquiryUpdateDBObj);
					
					updateDBFields.put("$set", inquiryUpdateDBObj);
					
					// Create new Audit for the action
					updateDBFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));

					// Prepare basic query for IN
					DBObject findINQuery = prepareFindQuery(inqObj.id, fromGroupId, workflowStatus, INQUIRY_DIRECTION_IN);
					// For Reopen, Inquiry Status check shpuld not be there
					findINQuery.removeField(STATUS);
					bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);

					DBObject findOUTQuery = prepareFindAssignQuery(inqObj.id, fromGroupId, workflowStatus, INQUIRY_DIRECTION_OUT);
					DBObject updateOutWorkflows = new BasicDBObject();
					DBObject updateOutWorkflowsUnset = new BasicDBObject();
					updateOutWorkflows.put(WORKFLOWS_MODIFIED_BY, soeId);
					updateOutWorkflows.put(WORKFLOWS_MODIFIED_DATE, currentTime);
					updateOutWorkflows.put(WORKFLOWS_ACTION, action);
					updateOutWorkflows.put(WORKFLOWS_LAST_ACTION_BY, usrName);
					updateOutWorkflows.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
					DBObject updateReqDBFields = new BasicDBObject();

					if (isReOpenAction)
					{
						updateOutWorkflows.put(WORKFLOWS_STATUS, STATUS_OPEN);
						//[C170665-1719] DCC Requirement: Add Case status field
						if(isInquirySubStatusEnabled(fromGroupId)) {
						updateOutWorkflows.put(WORKFLOWS_INQUIRY_SUB_STATUS, SUB_STATUS_REOPEN);
						}
						updateOutWorkflows.put(WORKFLOWS_REOPENED_DATE, currentTime);
						inquiryUpdateDBObj.put("workflows.$.prevResponseCntr", 0);// Reset Previous Response counter before resolve to 0
						findOUTQuery.removeField(STATUS);
						updateOutWorkflows.put(WORKFLOWS_RESOLVE_TIME, null);
						inqObj.setStatus(STATUS_OPEN);
						
						//get workflow
						//Workflow workflow = getWorkflow(inqObj.getWorkflows(),fromGroupId,"OUT");
						InquiryExtendedDAO.getInstance().removeNominationFieldFromWorkflow(updateOutWorkflows,updateOutWorkflowsUnset, inqObj.id, fromGroupId, soeId);
						updateReqDBFields.put("$unset", updateOutWorkflowsUnset);
					}

					updateReqDBFields.put("$set", updateOutWorkflows);

					bulkInquiryUpdOp.find(findOUTQuery).update(updateReqDBFields);
					List<String> directions = new ArrayList<String>();
					directions.add(INQUIRY_DIRECTION_PENDING_APPROVAL);
					directions.add(INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE);
					subLogger.info("isInquiryLevelBulkAction= " + isInquiryLevelBulkAction);
					if (isInquiryLevelBulkAction)
					{
						subLogger.info("Open all Out workflows- isInquiryLevelBulkAction= " + isInquiryLevelBulkAction);
						openAllOutWorkflows(soeId, bulkInquiryUpdOp, inqObj, currentTime);
					}


					// C153176-1449 if user action is just reply or replyall or replyallresolve or forward, and QMA action is Reopen (means QMA is re-opening workflow for others groups) then don't add entry in ActionStatistics for Re-open
					// b'coz Reopen is QMA action not the User action, ( user did only one action (reply...))
					if(!inquiryActionOnUI.equals(action))
					{
						subLogger.info("changeStatus Saved for UI action is :"+ inquiryActionOnUI + ", action " + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID) );
						stats = null;						
					}else
					{
						updateStats(inqObj.getWorkflows(), fromGroupId, stats, INQUIRY_DIRECTION_IN, null, inqObj.getSubject());
						bulkStatsInsertdOp.insert(stats);
						subLogger.info("ActionStatistics Saved for action 4" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
					}

					if (isReOpenAction  && null != inqObj.getExceptionId())
					{
						copyResolveDetailsToInquiry(inquiryUpdateDBObj, inqObj, soeId, currentTime);
						resolveInquiryList.add(inqObj);
					}
				}
				iInquiryActionStat.bulkUpdateInquiryActionStats(inqObj, ACTION_RESOLVE, currentTime, fromGroupIds);
			}
			if (!inquiryObjs.isEmpty())
			{
				bulkInquiryUpdOp.execute();
				if(null!=stats)
					bulkStatsInsertdOp.execute();
			}

		}
		catch (Exception e)
		{
			subLogger.info("Generic Exception in resolveInquiryBulk-" + e.getMessage());
			throw new CommunicatorException("Generic Exception in resolveInquiryBulk-" + e.getMessage(), e);
		}
		return resolveInquiryList;
	}
	
	
	
	
	

	private List<Inquiry> changeStatus(List<Inquiry> inquiryObjs, String soeId, Set<Long> fromGroupIds, String requestType, String tag, String comment, String action, String rootCause,
			String processingRegion, Long queryCount, String inquirySource ,String forceUnlock, String inquiryActionOnUI, String resolveAllocation,String inquirySubStatus) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("resolveInquiryBulk for Inquiries size= {}", inquiryObjs.size());
		// boolean isResolveAction="RESOLVE".equals(action);
		boolean isResolveAction = ACTION_RESOLVE.equalsIgnoreCase(action);
		boolean isReOpenAction = ACTION_REOPEN.equalsIgnoreCase(action);
		List<Inquiry> resolveInquiryList = null;
		DBObject stats = null;
		try
		{
			if (!(isResolveAction || isReOpenAction))
			{
				subLogger.info("InquiryDao.changeStatus for soeId +" + soeId + " -Not a valid change status action -" + action);
				return resolveInquiryList;
			}
			DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
			BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();

			DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
			BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();
			Date currentTime = new Date();
			DBObject inquiryNote =null;
			if(!StringUtils.isEmpty(comment))
			{
				inquiryNote = createInquiryNote(soeId, soeId, currentTime, comment);
			}
			resolveInquiryList = new ArrayList<>();
			EscalationUtility escalationUtility = new EscalationUtility();
			escalationUtility.setAllGroupsEscalationCriteriaMap(groupDAO.getGroupEscalationDetailsById(new ArrayList<Long>(fromGroupIds)));
			boolean isBulkAction= inquiryObjs != null && inquiryObjs.size() > 1 ;
			
			Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			for (Inquiry inqObj : inquiryObjs)
			{

				// ReOpen Resolved workflows only
				String workflowStatus = isReOpenAction ? STATUS_RESOLVE : STATUS_OPEN;
				boolean isInquiryLevelBulkAction = false;
				String userName = GenericUtility.getUserOrSystemName(soeId,userInfoMap);
				
				
				
				
				for (Long fromGroupId : fromGroupIds)
				{

					DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, action);
					inquiryUpdateDBObj.put(MODIFIED_DATE, currentTime);
					inquiryUpdateDBObj.put(MODIFIED_BY, soeId);

					// Prepare new workflow audit obj
					DBObject workflowAudit = createWorkFlowsAuditJavaDriver(fromGroupId, action, action, soeId, currentTime, groupIdToNameMap, userInfoMap);

					workflowAudit.put(INQUIRY_ID, inqObj.id);


					//Modified for requestType in Action Statistics - C153176-1155
					ActionStatistics statsObj = new ActionStatistics();
					statsObj.setRequestType(requestType);
					statsObj.setTag(tag);
					statsObj.setProcessingRegion(processingRegion); 
					statsObj.setInquirySource(inquirySource);
					if(isInquirySubStatusEnabled(fromGroupId)) {
						statsObj.setInquirySubStatus(inquirySubStatus);
					}
					
					stats = getStatsObject(soeId, action, currentTime, inqObj, fromGroupId, isBulkAction, statsObj, groupIdToNameMap, userInfoMap);
					if(StringUtils.isNotBlank(resolveAllocation) && "Y".equalsIgnoreCase(resolveAllocation)) {
						stats.put("resolveAllocation",resolveAllocation);
					}

					String openGroups = null;
					if (isResolveAction)
					{
						String assignedUserName = "";
						String assignedUserId = "";
						// Set workflow status as resolved
						inquiryUpdateDBObj.put(ACTION, ACTION_RESOLVE);
						// on resolve action followup is set as null
						inquiryUpdateDBObj.put(WORKFLOWS_$_FOLLOW_UP, null);
						inquiryUpdateDBObj.put(WORKFLOWS_STATUS, STATUS_RESOLVE);
						//[C170665-1719] DCC Requirement: Add Case status field
						if(isInquirySubStatusEnabled(fromGroupId)) {
						inquiryUpdateDBObj.put(WORKFLOWS_INQUIRY_SUB_STATUS, SUB_STATUS_COMPLETED);
						}
						inquiryUpdateDBObj.put(WORKFLOWS_REQUEST_TYPE, requestType);
						// on resolve action workflow ownership is set as null
						inquiryUpdateDBObj.put(WORKFLOWS_OWNERSHIP, null);
						if (!StringUtils.isBlank(tag))
							inquiryUpdateDBObj.put("workflows.$.tag", tag);
						if (!StringUtils.isBlank(rootCause))
							inquiryUpdateDBObj.put("workflows.$.rootCause", rootCause);
						if (!StringUtils.isBlank(processingRegion))
							inquiryUpdateDBObj.put(WORKFLOWS_PROCESSING_REGION, processingRegion);
						if (queryCount != null)
							inquiryUpdateDBObj.put("workflows.$.queryCount", queryCount);
						// Release 1.2 changes-Add action in the workflow
						inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_RESOLVE);
						workflowAudit.put(ACTION_DETAILS, comment);
						if (null!= tag){
							workflowAudit.put(TAG, tag);
						}
						if (!StringUtils.isBlank(inquirySource))
							inquiryUpdateDBObj.put(WORKFLOWS_INQUIRY_SOURCE, inquirySource);
						// Set Inquiry status as Resolved if all workflow status is resolved
						if (isAllWorkflowResolvedBulk(inqObj.getWorkflows(), fromGroupId))
						{
							inquiryUpdateDBObj.put(STATUS, STATUS_RESOLVE);
							isInquiryLevelBulkAction = true;
							// This will be used while sending message to X-Stream
							inqObj.setAction(ACTION_RESOLVE);
						}
						Workflow inWorkFlow = getWorkflow(inqObj.getWorkflows(), fromGroupId, INQUIRY_DIRECTION_IN);
						if (inWorkFlow != null) 
						{
							//C153176-875
							if (!StringUtils.isBlank(inWorkFlow.getLockedBy()) && !userName.equals(inWorkFlow.getLockedBy()) && !StringUtils.isBlank(forceUnlock) && ("Y").equals(forceUnlock))
							{
								workflowAudit.put(FORCE_UNLOCK,forceUnlock);
							}
							inWorkFlow.setStatus(STATUS_RESOLVE);
							if(isInquirySubStatusEnabled(fromGroupId)) {
							inWorkFlow.setInquirySubStatus(SUB_STATUS_COMPLETED);
							}
							inWorkFlow.setFollowUp(null);
							//Calculate unassigned time for the inquiry
							Long unAssignedTime = calculateUnassignedTime(inWorkFlow);
							inquiryUpdateDBObj.put("workflows.$.unassignedTimeInMins", unAssignedTime);
							// [C153176-698] - Assign an unassigned inquiry to the user resolving it
							assignedUserName = inWorkFlow.getAssignedUserName();
							assignedUserId = inWorkFlow.getAssignedUserId();

							if (!(assignedUserName != null && !assignedUserName.isEmpty()))
							{
								assignedUserName = userName + " (" + soeId + ")[" + inWorkFlow.getAssignedGroupName() + "]";
							}
							if (!(assignedUserId != null && !assignedUserId.isEmpty()))
							{
								assignedUserId = soeId;
							}
						}

						String inquiryReqTypes = updateInquiryRequestType(inqObj.getWorkflows(), requestType, fromGroupIds);
						if (!StringUtils.isBlank(inquiryReqTypes))
						{
							inquiryUpdateDBObj.put(REQUEST_TYPE_STR, inquiryReqTypes);
						}
						// [C153176-1694] - reset acknowledge escalation fields to null
						if(null!= inWorkFlow && null !=inWorkFlow.getIsAckEscalation())
						{
							inquiryUpdateDBObj.put(WORKFLOWS_ACK_ESCALATION, null);
							inquiryUpdateDBObj.put(WORKFLOWS_ACK_ESCALATION_BY, null);
							inquiryUpdateDBObj.put(WORKFLOWS_ACK_ESCALATION_TIME, null);
							
						}
						
						if (null!= inWorkFlow && null!= inWorkFlow.getHasOwnership())
						{
							inquiryUpdateDBObj.put(WORKFLOWS_OWNERSHIP, inWorkFlow.getHasOwnership());
						}
						inquiryUpdateDBObj.put(WORKFLOWS_RESOLVER, userName);
						// [C153176-698] - Assign an unassigned inquiry to the user resolving it
						inquiryUpdateDBObj.put("workflows.$.assignedUserName", assignedUserName);
						inquiryUpdateDBObj.put("workflows.$.assignedUserId", assignedUserId);
						inquiryUpdateDBObj.put(WORKFLOWS_RESOLVE_TIME, currentTime);
						if(null!= inWorkFlow && null != inWorkFlow.getReOpenDate()){
							inquiryUpdateDBObj.put(WORKFLOWS_REOPENED_DATE, inWorkFlow.getReOpenDate());
						}
						
						// resolve action updates the IN version workflow status to 'Resolved', so Inquiiries opneGroups has to be updated i.e. the resolved group has to be removed from opneGroups
						openGroups = updatedInquiryOpenGroups(ACTION_RESOLVE, inqObj, fromGroupIds);
						// C153176-981 Compute 'Avg Resolution Time' for workflow
						calculateResolutionTime(inWorkFlow, inquiryUpdateDBObj, currentTime);

						//	reset escalation fields to null.
						if(null!= inWorkFlow && null !=inWorkFlow.getResponseTimeNextEscalation())
						{
							inquiryUpdateDBObj.put(WORKFLOWS_RESPONSE_TIME_ESCALATION, null);
							inquiryUpdateDBObj.put(WORKFLOWS_RESPONSE_TIME_NEXT_ESACLATION, null);
							inquiryUpdateDBObj.put(WORKFLOWS_RESPONSE_TIME_ESCALATION_REASON, null);
							inquiryUpdateDBObj.put(WORKFLOWS_ISPENDINGAPPROVAL_ESCALATION, null);
						}
						
						// C153176-5891 | Set isLatestResponseFromNonQMA to "N"
						inquiryUpdateDBObj.put("workflows.$.isLatestResponseFromNonQMA", "N");
					}
					else if (isReOpenAction)
					{
						inquiryUpdateDBObj.put(WORKFLOWS_STATUS, STATUS_OPEN);
						//[C170665-1719] DCC Requirement: Add Case status field
						if(isInquirySubStatusEnabled(fromGroupId)) {
							inquiryUpdateDBObj.put(WORKFLOWS_INQUIRY_SUB_STATUS, SUB_STATUS_REOPEN);
						}
						
						// Release 1.2 changes-Add action in the workflow
						inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_REOPEN);
						inquiryUpdateDBObj.put(ACTION, ACTION_REOPEN);
						workflowAudit.put(ACTION_DETAILS, "");
						// Set Inquiry status as Resolved if all workflow status is resolved
						inquiryUpdateDBObj.put(STATUS, STATUS_OPEN);
						
						inquiryUpdateDBObj.put(WORKFLOWS_REOPENED_DATE, currentTime);
						// C153176-154-ActionStatistics Improvements
						inquiryUpdateDBObj.put("workflows.$.prevResponseCntr", 0);// Reset Previous Response counter before resolve to 0
						//						inquiryUpdateDBObj.put("$unset", new BasicDBObject(WORKFLOW_RESOLVER, ""));
						//						inquiryUpdateDBObj.put("$unset", new BasicDBObject(WORKFLOWS_RESOLVE_TIME,""));
						inquiryUpdateDBObj.put(WORKFLOWS_RESOLVER, "");
						inquiryUpdateDBObj.put(WORKFLOWS_RESOLVE_TIME, null);
						// re-open action updates the IN version workflow status to 'Open', so Inquiiries opneGroups has to be updated i.e. the re-open group has to be removed from opneGroups
						openGroups = updatedInquiryOpenGroups(ACTION_REOPEN, inqObj, fromGroupIds);
						inqObj.setAction(ACTION_REOPEN);

						//C153176-1055 -- Assign to user who reopened the Inquiry/WF
						String assignGroupName = groupIdToNameMap.get(fromGroupId);
						String assignUserName = getAssignUserName(soeId, assignGroupName);						
						inquiryUpdateDBObj.put("workflows.$.assignedUserId", soeId);
						inquiryUpdateDBObj.put("workflows.$.assignedUserName", assignUserName);

						// Set Inquiry status as Resolved if all workflow status is resolved
						if (isAllWorkflowReOpenBulk(inqObj.getWorkflows(), fromGroupId))
						{
							isInquiryLevelBulkAction = true;

						}
						//set Escalation Time
						if (null != escalationUtility.getAllGroupsEscalationCriteriaMap() && null!= escalationUtility.getAllGroupsEscalationCriteriaMap().get(fromGroupId))
						{
							Integer responseTimeThreshold = escalationUtility.getAllGroupsEscalationCriteriaMap().get(fromGroupId).getResponseTimeThresholdForEscalation();
							if(null!= responseTimeThreshold && responseTimeThreshold > 0)
							{
								inquiryUpdateDBObj.put(WORKFLOWS_RESPONSE_TIME_ESCALATION, "N");
								inquiryUpdateDBObj.put(WORKFLOWS_RESPONSE_TIME_NEXT_ESACLATION, escalationUtility.generateNextEscalationTime(fromGroupId,currentTime,responseTimeThreshold));
								inquiryUpdateDBObj.put(WORKFLOWS_ISPENDINGAPPROVAL_ESCALATION, "N");
							}
						}
					}
					String usrName = GenericUtility.getUserOrSystemName(soeId, userInfoMap);
					inquiryUpdateDBObj.put(OPEN_GROUPS, openGroups);
					inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, usrName);
					inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
					inquiryUpdateDBObj.put("workflows.$.isLastConvToExtEmail","Y");
					addNoteInResolveInquiry(inquiryNote, inqObj, inquiryUpdateDBObj);

					DBObject updateDBFields = new BasicDBObject();
					//set resolve allocation to inquiry workflow
					if(StringUtils.isNotBlank(resolveAllocation) && "Y".equalsIgnoreCase(resolveAllocation)) {
						inquiryUpdateDBObj.put("workflows.$.resolveAllocation", resolveAllocation);
						workflowAudit.put(ACTION, "Resolve Allocation");
					} else {
						updateDBFields.put("$unset",new BasicDBObject("workflows.$.resolveAllocation", ""));
					}
					// Update inquiry fields
					updateDBFields.put("$set", inquiryUpdateDBObj);
					// Unset workflow reopendate & Unset lock fields for in workflow
					if (isResolveAction){
						BasicDBObject unlockDataWithReopenedDate = getUnlockRequestObj();
						//reset isClientChaseEscalation and latestClientChaseCounter on Resolve action
						unlockDataWithReopenedDate.put("workflows.$.isClientChaseEscalation","");
						unlockDataWithReopenedDate.put("workflows.$.latestClientChaseCounter","");
						//unset resolve allocation to inquiry workflow
						if(StringUtils.isNotBlank(resolveAllocation) && "Y".equalsIgnoreCase(resolveAllocation)) {
							//do nothing
						} else {
							unlockDataWithReopenedDate.put("workflows.$.resolveAllocation", "");
						}
						updateDBFields.put("$unset",unlockDataWithReopenedDate);
					}
					// Create new Audit for the action
					updateDBFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));

					// Prepare basic query for IN
					DBObject findINQuery = prepareFindQuery(inqObj.id, fromGroupId, workflowStatus, INQUIRY_DIRECTION_IN);
					if (isReOpenAction)
					{
						// For Reopen, Inquiry Status check shpuld not be there
						findINQuery.removeField(STATUS);
					}
					// subLogger.debug("Update IN Query:" + findINQuery);
					// subLogger.debug("Update Infos:" + inquiryUpdateDBObj);

					// Add to bulk for IN
					bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);

					DBObject findOUTQuery = prepareFindAssignQuery(inqObj.id, fromGroupId, workflowStatus, INQUIRY_DIRECTION_OUT);
					DBObject updateOutWorkflows = new BasicDBObject();
					updateOutWorkflows.put(WORKFLOWS_MODIFIED_BY, soeId);
					updateOutWorkflows.put(WORKFLOWS_MODIFIED_DATE, currentTime);
					updateOutWorkflows.put(WORKFLOWS_ACTION, action);
					updateOutWorkflows.put(WORKFLOWS_LAST_ACTION_BY, usrName);
					updateOutWorkflows.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);

					// Update inquiry fields
					DBObject updateReqDBFields = new BasicDBObject();

					// Request Type is mandatory in Resolve Flow only
					if (isResolveAction)
					{
						
						// updateOutWorkflows.removeField(WORKFLOWS_REOPENED_DATE);
						updateReqDBFields.put("$unset", new BasicDBObject(WORKFLOWS_REOPENED_DATE, ""));
						updateOutWorkflows.put(WORKFLOWS_REQUEST_TYPE, requestType);
						// Resolve OUTBOX workflow also
						updateOutWorkflows.put(WORKFLOWS_STATUS, STATUS_RESOLVE);
						//[C170665-1719] DCC Requirement: Add Case status field
						if(isInquirySubStatusEnabled(fromGroupId)) {
						updateOutWorkflows.put(WORKFLOWS_INQUIRY_SUB_STATUS, SUB_STATUS_COMPLETED);
						}
						updateOutWorkflows.put(WORKFLOWS_$_FOLLOW_UP, null);
						updateOutWorkflows.put(WORKFLOWS_RESOLVER, userName);
						updateOutWorkflows.put(WORKFLOWS_RESOLVE_TIME, currentTime);
						updateOutWorkflows.put("workflows.$.tag", tag);
						if (!StringUtils.isBlank(rootCause))
							updateOutWorkflows.put("workflows.$.rootCause", rootCause);
						if (!StringUtils.isBlank(processingRegion))
							updateOutWorkflows.put(WORKFLOWS_PROCESSING_REGION, processingRegion);
						if (!StringUtils.isBlank(inquirySource))
							updateOutWorkflows.put(WORKFLOWS_INQUIRY_SOURCE, inquirySource);
						if (null != inquiryUpdateDBObj.get(WORKFLOWS_TOTAL_RESOLVE_TIME))
							updateOutWorkflows.put(WORKFLOWS_TOTAL_RESOLVE_TIME, inquiryUpdateDBObj.get(WORKFLOWS_TOTAL_RESOLVE_TIME));
						
						// C153176-5354 | Resolution time considering working hours
						if (null != inquiryUpdateDBObj.get(RESOLUTION_TIME_IN_MINUTES)) {
							updateOutWorkflows.put(RESOLUTION_TIME_IN_MINUTES, inquiryUpdateDBObj.get(RESOLUTION_TIME_IN_MINUTES));
							stats.put("resolutionTimeInMinutes", inquiryUpdateDBObj.get(RESOLUTION_TIME_IN_MINUTES));
						}
						if (null != inquiryUpdateDBObj.get(WORKFLOWS_RESOLVE_COUNT))
							updateOutWorkflows.put(WORKFLOWS_RESOLVE_COUNT, inquiryUpdateDBObj.get(WORKFLOWS_RESOLVE_COUNT));

						updateOutWorkflows.put("workflows.$.isLastConvToExtEmail","Y");
						BasicDBObject unlockDataWithReopenedDate = getUnlockRequestObj();
						//reset isClientChaseEscalation and latestClientChaseCounter on Resolve action
						unlockDataWithReopenedDate.put("workflows.$.isClientChaseEscalation","");
						unlockDataWithReopenedDate.put("workflows.$.latestClientChaseCounter","");
						updateReqDBFields.put("$unset",unlockDataWithReopenedDate);
						inqObj.setStatus(STATUS_RESOLVE);
						
						// C153176-5891 | Set isLatestResponseFromNonQMA to "N" to out workflow
						updateOutWorkflows.put("workflows.$.isLatestResponseFromNonQMA", "N");
						//set resolve allocation to inquiry workflow
						if(StringUtils.isNotBlank(resolveAllocation) && "Y".equalsIgnoreCase(resolveAllocation)) {
							updateOutWorkflows.put("workflows.$.resolveAllocation", resolveAllocation);
							//workflowAudit.put(ACTION, "Resolve Allocation");
						} else {
							unlockDataWithReopenedDate.put("workflows.$.resolveAllocation", "");
						}
						if (queryCount != null)
							updateOutWorkflows.put("workflows.$.queryCount", queryCount);
					}
					else if (isReOpenAction)
					{
						// Reopen OUTBox Workflow also
						updateOutWorkflows.put(WORKFLOWS_STATUS, STATUS_OPEN);
						//[C170665-1719] DCC Requirement: Add Case status field
						if(isInquirySubStatusEnabled(fromGroupId)) {
							updateOutWorkflows.put(WORKFLOWS_INQUIRY_SUB_STATUS, SUB_STATUS_REOPEN);
						}
						
						updateOutWorkflows.put(WORKFLOWS_REOPENED_DATE, currentTime);
						// C153176-154-ActionStatistics Improvements
						inquiryUpdateDBObj.put("workflows.$.prevResponseCntr", 0);// Reset Previous Response counter before resolve to 0

						// For Reopen, Inquiry Status check shpuld not be there
						findOUTQuery.removeField(STATUS);
						// updateOutWorkflows.put(WORKFLOW_RESOLVER, "");
						//						updateOutWorkflows.put("$unset", new BasicDBObject(WORKFLOW_RESOLVER, ""));
						//						updateOutWorkflows.put("$unset", new BasicDBObject(WORKFLOWS_RESOLVE_TIME,""));
						updateOutWorkflows.put(WORKFLOWS_RESOLVER, "");
						updateOutWorkflows.put(WORKFLOWS_RESOLVE_TIME, null);
						inqObj.setStatus(STATUS_OPEN);
					}

					updateReqDBFields.put("$set", updateOutWorkflows);

					bulkInquiryUpdOp.find(findOUTQuery).update(updateReqDBFields);
					// Tag change for Pending Approval Inquiry at the time of resolve action.
					//[C153176-1449]- MIS Report - Duplicate Records
					// find queries for Pending approval and Pending-Re-age
					List<String> directions = new ArrayList<String>();
					directions.add(INQUIRY_DIRECTION_PENDING_APPROVAL);
					directions.add(INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE);
					DBObject findPendingApprovalQuery = prepareFindAssignQueryDirectionList(inqObj.id, fromGroupId, workflowStatus, directions);
					DBObject updatePendingApprovalWorkflows = new BasicDBObject();
					if (isResolveAction)
					{
						updatePendingApprovalWorkflows.put("workflows.$.tag", tag);
						updatePendingApprovalWorkflows.put(WORKFLOWS_REQUEST_TYPE, requestType);
						DBObject updateReqDBFieldsforPendingApproval = new BasicDBObject();
						updateReqDBFieldsforPendingApproval.put("$set", updatePendingApprovalWorkflows);
						bulkInquiryUpdOp.find(findPendingApprovalQuery).update(updateReqDBFieldsforPendingApproval);
					}

					subLogger.info("isInquiryLevelBulkAction= " + isInquiryLevelBulkAction);
					if (isResolveAction && isInquiryLevelBulkAction)
					{
						subLogger.info("Close all Out workflows- isInquiryLevelBulkAction= " + isInquiryLevelBulkAction);
						closeAllOutWorkflows(soeId, bulkInquiryUpdOp, inqObj, currentTime);
					}
					else if (isReOpenAction && isInquiryLevelBulkAction)
					{
						subLogger.info("Open all Out workflows- isInquiryLevelBulkAction= " + isInquiryLevelBulkAction);
						openAllOutWorkflows(soeId, bulkInquiryUpdOp, inqObj, currentTime);
					}


					// C153176-1449 if user action is just reply or replyall or replyallresolve or forward, and QMA action is Reopen (means QMA is re-opening workflow for others groups) then don't add entry in ActionStatistics for Re-open
					// b'coz Reopen is QMA action not the User action, ( user did only one action (reply...))
					if(!inquiryActionOnUI.equals(action))
					{
						subLogger.info("changeStatus Saved for UI action is :"+ inquiryActionOnUI + ", action " + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID) );
						stats = null;						
					}else
					{
						// C153176-154-ActionStatistics Improvements
						updateStats(inqObj.getWorkflows(), fromGroupId, stats, INQUIRY_DIRECTION_IN, null, inqObj.getSubject());
						bulkStatsInsertdOp.insert(stats);
						subLogger.info("ActionStatistics Saved for action 4" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
					}

					boolean isInquiryResolved = isResolveAction && isInquiryLevelBulkAction;
					if ((isReOpenAction || isInquiryResolved) && null != inqObj.getExceptionId())
					{
						copyResolveDetailsToInquiry(inquiryUpdateDBObj, inqObj, soeId, currentTime);
						resolveInquiryList.add(inqObj);
					}
				}
				iInquiryActionStat.bulkUpdateInquiryActionStats(inqObj, ACTION_RESOLVE, currentTime, fromGroupIds);
			}
			// Execute
			if (!inquiryObjs.isEmpty())
			{
				bulkInquiryUpdOp.execute();
				if(null!=stats)
					bulkStatsInsertdOp.execute();
			}

		}
		catch (Exception e)
		{
			subLogger.info("Generic Exception in resolveInquiryBulk-" + e.getMessage());
			throw new CommunicatorException("Generic Exception in resolveInquiryBulk-" + e.getMessage(), e);
		}
		return resolveInquiryList;
	}

	/*
	 * Method for adding note to inquiry while resolving an inquiry.
	 */
	private void addNoteInResolveInquiry(DBObject inquiryNote, Inquiry inqObj, DBObject inquiryUpdateDBObj)
	{
		if (null != inquiryNote)
		{
			BasicDBList notesList = new BasicDBList();
			if (null != inqObj.getUserNotes())
			{
				for (Note note : inqObj.getUserNotes())
				{
					notesList.add(createInquiryNote(note.getUserId(), note.getUserName(), note.getCommentDate(), note.getComments()));
				}
			}
			notesList.add(inquiryNote);
			inquiryUpdateDBObj.put("userNotes", notesList);
			//Added for Jira-[C153176-1594]-Notes icon not visible when resolve is performed form UI.
			inqObj.setNotesFlag("Y");
			inquiryUpdateDBObj.put("notesFlag",inqObj.getNotesFlag());
		}
	}

	private BasicDBObject getUnlockRequestObj()
	{
		BasicDBObject unlockDataWithReopenedDate = new BasicDBObject("workflows.$.lock", "");
		unlockDataWithReopenedDate.put(WORKFLOWS_LOCKED_BY, "");
		unlockDataWithReopenedDate.put(WORKFLOWS_LOCKED_TIME, "");
		//unlockDataWithReopenedDate.put(WORKFLOWS_REOPENED_DATE, "");
		return unlockDataWithReopenedDate;
	}

	private void copyResolveDetailsToInquiry(DBObject source, Inquiry destination, String soeId, Date currentTime)
	{
		if (null != source && null != destination)
		{
			String reqTypeStr = (String) source.get(REQUEST_TYPE_STR);
			destination.setRequestTypeStr(reqTypeStr);
			String openGroups = (String) source.get(OPEN_GROUPS);
			destination.setOpenGroups(openGroups);
			String openUsers = (String) source.get(OPEN_USERS);
			destination.setOpenUsers(openUsers);
			destination.setModBy(soeId);
			destination.setModDate(currentTime);
		}
	}

	private void calculateResolutionTime(Workflow Workflow, DBObject inquiryUpdateDBObj, Date currentTime)
	{
		if (null != Workflow)
		{
			Long totalResolveTimeQMA = Workflow.getTotalResolveTimeQMA();
			Date reOpenDate = Workflow.getReOpenDate();
			Date originDate = Workflow.getOriginDate();
			Date reAgeDate = Workflow.getReAgeDate();
			
			Integer resolveCountQMA = Workflow.getResolveCountQMA();
			if (null == reOpenDate && null != originDate)
			{
				long elapsedTime = (currentTime.getTime() - originDate.getTime()) / 1000;
				totalResolveTimeQMA = (null == totalResolveTimeQMA) ? elapsedTime : elapsedTime + totalResolveTimeQMA;
				resolveCountQMA = (null == resolveCountQMA) ? 1 : resolveCountQMA + 1;
			}
			else if (null != reOpenDate && null == reAgeDate)
			{
				long elapsedTime = (currentTime.getTime() - reOpenDate.getTime()) / 1000;
				totalResolveTimeQMA = (null == totalResolveTimeQMA) ? elapsedTime : elapsedTime + totalResolveTimeQMA;
				resolveCountQMA = (null == resolveCountQMA) ? 1 : resolveCountQMA + 1;
			}
			else if (null != reOpenDate && null != reAgeDate)
			{
				long elapsedTime = (currentTime.getTime() - reAgeDate.getTime()) / 1000;
				totalResolveTimeQMA = elapsedTime;
				resolveCountQMA = (null == resolveCountQMA) ? 1 : resolveCountQMA + 1;
			}
			
			// C153176-5977 | Nominate ownership : Resolution time getting considered from the time of ownership requested
			Date ownershipAcceptDate = Workflow.getOwnershipAcceptedTime();
			if(null != ownershipAcceptDate && null == reAgeDate) {
				long elapsedTime = (currentTime.getTime() - ownershipAcceptDate.getTime()) / 1000;
				totalResolveTimeQMA = elapsedTime;
			}

			// used in case of REPLY RESOVE
			if (null == inquiryUpdateDBObj)
			{
				Workflow.setTotalResolveTimeQMA(totalResolveTimeQMA);
				Workflow.setResolveCountQMA(resolveCountQMA);
			}
			// used in case of RESOLVE
			else
			{
				inquiryUpdateDBObj.put(WORKFLOWS_TOTAL_RESOLVE_TIME, totalResolveTimeQMA);
				inquiryUpdateDBObj.put(WORKFLOWS_RESOLVE_COUNT, resolveCountQMA);
			}
			
			// C153176-5354 - Calculate resolution time with respect to working hours
			this.calculateResolutionTimeInMins(Workflow, inquiryUpdateDBObj, currentTime, totalResolveTimeQMA);
		}
	}

	/**
	 * C153176-5354 - Panorama Feed.
	 * 
	 * Method to calculate resolution time with respect to working hours.
	 * 
	 * @param workflow
	 * @param inquiryUpdateDBObj
	 * @param currentTime
	 */
	private void calculateResolutionTimeInMins(Workflow workflow, DBObject inquiryUpdateDBObj, Date currentTime, Long totalResolveTimeQMA)
	{
		try {
			Long resolutionTimeInMins = workflow.getResolutionTimeInMinutes();
			Date reOpenDate = workflow.getReOpenDate();
			Date originDate = workflow.getOriginDate();
			Date reAgeDate = workflow.getReAgeDate();
			
			Long groupId = workflow.getAssignedGroupId();

			BasicDBObject resultObj = new BasicDBObject();
			if (null == reOpenDate && null != originDate) {
				AgeAndTimeUtils.getTimeDiffBasedOnAgeConfig(resultObj, groupId, originDate, currentTime, AppserverConstants.TIME_UNIT_MINS);
			} 
			// In sync with calculateResolutionTime changes for re-age date.
			else if (null != reOpenDate && null == reAgeDate) {
				AgeAndTimeUtils.getTimeDiffBasedOnAgeConfig(resultObj, groupId, reOpenDate, currentTime, AppserverConstants.TIME_UNIT_MINS);
			}
			else if (null != reOpenDate && null != reAgeDate) {
				AgeAndTimeUtils.getTimeDiffBasedOnAgeConfig(resultObj, groupId, reAgeDate, currentTime, AppserverConstants.TIME_UNIT_MINS);
			}
			
			// C153176-5977 | Nominate ownership : Resolution time getting considered from the time of ownership requested
			Date ownershipAcceptDate = workflow.getOwnershipAcceptedTime();
			if(null != ownershipAcceptDate && null == reAgeDate) {
				AgeAndTimeUtils.getTimeDiffBasedOnAgeConfig(resultObj, groupId, ownershipAcceptDate, currentTime, AppserverConstants.TIME_UNIT_MINS);
			}

			if (null != resultObj.get(AppserverConstants.TIME_DIFF)) {
				long elapsedTime = resultObj.getLong(AppserverConstants.TIME_DIFF);
				resolutionTimeInMins = (null == resolutionTimeInMins) ? elapsedTime : elapsedTime + resolutionTimeInMins;
				
				// If the workflow has reopen and reage date then. we are considering resolutionTimeInMins as elapsedTime.
				if (null != reOpenDate && null != reAgeDate) {
					resolutionTimeInMins = elapsedTime;
				}
				
				// If the workflow has ownershipAcceptDate and but not re-age date then we are considering resolutionTimeInMins as elapsedTime.
				if (null != ownershipAcceptDate && null == reAgeDate) {
					resolutionTimeInMins = elapsedTime;
				}
				subLogger.info("Resolution time in minutes considering working hours logic : " + resolutionTimeInMins);
			} else {
				// When working hours are not configured for the group, totalResolveTimeWorkHrs should be equivalent to totalResolveTimeQMA.
				resolutionTimeInMins = (null != totalResolveTimeQMA) ? totalResolveTimeQMA / 60 : 0;
				subLogger.info("Resolution time in minutes : "+ resolutionTimeInMins);
			}

			// used in case of REPLY RESOVE
			if (null == inquiryUpdateDBObj && resolutionTimeInMins >= 0) {
				workflow.setResolutionTimeInMinutes(resolutionTimeInMins);
				workflow.setOwnershipAcceptedTime(null);
			}
			// used in case of RESOLVE
			else {
				inquiryUpdateDBObj.put(RESOLUTION_TIME_IN_MINUTES, resolutionTimeInMins);
				inquiryUpdateDBObj.put("workflows.$.ownershipAcceptedTime", null);
			}
		} catch (Exception e) {
			subLogger.error("Exception in InquiryDAO#calculateResolutionTimeInMins() : ", e);
		}

	}

	private void closeAllOutWorkflows(String soeId, BulkWriteOperation bulkInquiryUpdOp, Inquiry inqObj, Date currentTime)
	{
		BasicDBObject workflowCriteriaClose = new BasicDBObject();
		String userName = GenericUtility.getUserOrSystemName(soeId, QMACacheFactory.getCache().getUserInfoMap());
		DBObject findOUTCloseQuery = new BasicDBObject();
		findOUTCloseQuery.put("_id", inqObj.id);

		workflowCriteriaClose.put(STATUS, STATUS_OPEN);
		workflowCriteriaClose.put(DIRECTION, INQUIRY_DIRECTION_OUT);
		findOUTCloseQuery.put(WORKFLOWS, new BasicDBObject("$elemMatch", workflowCriteriaClose));

		DBObject updateOutWorkflowsClose = new BasicDBObject();
		updateOutWorkflowsClose.put(WORKFLOWS_MODIFIED_BY, soeId);
		updateOutWorkflowsClose.put(WORKFLOWS_MODIFIED_DATE, currentTime);
		updateOutWorkflowsClose.put(WORKFLOWS_STATUS, STATUS_RESOLVE);
		updateOutWorkflowsClose.put(WORKFLOWS_$_FOLLOW_UP, null);
		updateOutWorkflowsClose.put(WORKFLOWS_LAST_ACTION_BY, userName);
		updateOutWorkflowsClose.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
		updateOutWorkflowsClose.put(WORKFLOWS_RESOLVER, userName);
		updateOutWorkflowsClose.put(WORKFLOWS_RESOLVE_TIME, currentTime);
		DBObject updateCloseDBFields = new BasicDBObject();
		// Update inquiry fields
		updateCloseDBFields.put("$set", updateOutWorkflowsClose);
		BasicDBObject unlockDataWithReopenedDate = getUnlockRequestObj();
		updateCloseDBFields.put("$unset",unlockDataWithReopenedDate);
		bulkInquiryUpdOp.find(findOUTCloseQuery).update(updateCloseDBFields);
	}

	private void openAllOutWorkflows(String soeId, BulkWriteOperation bulkInquiryUpdOp, Inquiry inqObj, Date currentTime)
	{
		BasicDBObject workflowCriteriaClose = new BasicDBObject();

		DBObject findOUTCloseQuery = new BasicDBObject();
		findOUTCloseQuery.put("_id", inqObj.id);
		String userName = GenericUtility.getUserOrSystemName(soeId, QMACacheFactory.getCache().getUserInfoMap());
		workflowCriteriaClose.put(STATUS, STATUS_RESOLVE);
		workflowCriteriaClose.put(FOLLOWUP, null);
		workflowCriteriaClose.put(DIRECTION, INQUIRY_DIRECTION_OUT);
		findOUTCloseQuery.put(WORKFLOWS, new BasicDBObject("$elemMatch", workflowCriteriaClose));

		DBObject updateOutWorkflowsClose = new BasicDBObject();
		updateOutWorkflowsClose.put(WORKFLOWS_MODIFIED_BY, soeId);
		updateOutWorkflowsClose.put(WORKFLOWS_MODIFIED_DATE, currentTime);
		updateOutWorkflowsClose.put(WORKFLOWS_STATUS, STATUS_OPEN);
		updateOutWorkflowsClose.put(WORKFLOWS_LAST_ACTION_BY, userName);
		updateOutWorkflowsClose.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
		updateOutWorkflowsClose.put(WORKFLOWS_RESOLVER, "");
		updateOutWorkflowsClose.put(WORKFLOWS_RESOLVE_TIME, null);
		// updateOutWorkflowsClose.put(WORKFLOW_RESOLVER, "");
		//		updateOutWorkflowsClose.put("$unset", new BasicDBObject(WORKFLOW_RESOLVER, ""));
		//		updateOutWorkflowsClose.put("$unset", new BasicDBObject(WORKFLOWS_RESOLVE_TIME,""));

		DBObject updateCloseDBFields = new BasicDBObject();
		// Update inquiry fields
		updateCloseDBFields.put("$set", updateOutWorkflowsClose);
		bulkInquiryUpdOp.find(findOUTCloseQuery).update(updateCloseDBFields);
	}

	// basing on the action type this function returns the Inquiry openGropups string after 1.removing the resolved group or 2.adding the re-open group
	private String updatedInquiryOpenGroups(String action, Inquiry inquiry, Set<Long> fromGroupIds) throws CommunicatorException
	{
		String openGroups = null;
		try
		{
			openGroups = inquiry.getOpenGroups();
			subLogger.info("Resolve/Re-open InquiryBulk  before processing openGroups");
			QMACache qmaCache = QMACacheFactory.getCache();
			Map<Long, String> groupIdToNameMap =  qmaCache.getGroupIdToNameMap();
			for (Long groupId : fromGroupIds)
			{
				Workflow workflow = getWorkflow(inquiry.getWorkflows(), groupId, INQUIRY_DIRECTION_IN);
				if (null != workflow)
				{
					String groupCode = groupIdToNameMap.get(workflow.getAssignedGroupId());
					if (ACTION_RESOLVE.equals(action))
					{
						if (StringUtils.endsWith(openGroups, groupCode))
						{
							openGroups = StringUtils.remove(openGroups, groupCode);
						}
						else
						{
							openGroups = StringUtils.remove(openGroups, groupCode + ";");
						}

						if (StringUtils.endsWith(openGroups, ";"))
						{
							openGroups = StringUtils.stripEnd(openGroups, ";");
						}
					}
					else if (ACTION_REOPEN.equals(action))
					{
						openGroups = StringUtils.isBlank(openGroups) ? groupCode : openGroups + ";" + groupCode;
					}
				}
			}
		}
		catch (Exception e)
		{
			subLogger.error("Resolve/Re-open InquiryBulk - exception in updatedInquiryOpenGroups-" + e.getMessage(), e);
			openGroups = inquiry.getOpenGroups();
			throw new CommunicatorException("Resolve/Re-open InquiryBulk - exception in updatedInquiryOpenGroups-" + e.getMessage(), e);
		}

		subLogger.info("Resolve/Re-open InquiryBulk  after processing openGroups-");

		return openGroups;
	}

	private DBObject createAuditUpdateDBObj(String soeId, Date currentTime, String action)
	{
		DBObject updateDBObj = new BasicDBObject();
		// updateDBObj.put(MODIFIED_DATE, currentTime); // SUNIL COMMENTED AS DISCUSSED WITH PRITHPAL ON 17 NOV.
		// updateDBObj.put(MODIFIED_BY, soeId); // SUNIL COMMENTED AS DISCUSSED WITH PRITHPAL ON 17 NOV.
		updateDBObj.put(WORKFLOWS_MODIFIED_BY, soeId);
		// as discused with prith pal mode date update is no more required for menu items(request type ,assigne owner )
		if ( !assignMenuActionsWithoutModDateUpdate.contains(action))
		{
			updateDBObj.put(WORKFLOWS_MODIFIED_DATE, currentTime);
		}
		return updateDBObj;
	}

	private DBObject prepareFindQuery(Long id, Long fromGroupId, String inquiryStatus, String direction, boolean isStatusFilterNeeded)
	{
		BasicDBObject workflowCriteria = new BasicDBObject();

		DBObject updateQuery = new BasicDBObject();
		updateQuery.put("_id", id);

		if (isStatusFilterNeeded)
		{
			// Inquiry.status=Open, Workflow.Resolve
			updateQuery.put(STATUS, inquiryStatus);
			workflowCriteria.put(STATUS, inquiryStatus);
		}

		workflowCriteria.put(ASSIGNED_GROUPID, fromGroupId);
		if (direction != null)
		{
			// INQUIRY_DIRECTION_IN_OR_OUT will be used for adding Audit Entry in Bulk Case
			if (INQUIRY_DIRECTION_IN_OR_OUT.equals(direction))
			{
				List<String> directions = new ArrayList<String>();
				directions.add(INQUIRY_DIRECTION_IN);
				directions.add(INQUIRY_DIRECTION_OUT);
				workflowCriteria.put(DIRECTION, new BasicDBObject("$in", directions));
			}
			else if (INQUIRY_DIRECTION_IN_OR_OUT_OR_PA.equals(direction))
			{
				List<String> directions = new ArrayList<String>();
				directions.add(INQUIRY_DIRECTION_IN);
				directions.add(INQUIRY_DIRECTION_OUT);
				directions.add(INQUIRY_DIRECTION_PENDING_APPROVAL);
				workflowCriteria.put(DIRECTION, new BasicDBObject("$in", directions));
			}
			else
			{
				workflowCriteria.put(DIRECTION, direction);
			}
		}

		updateQuery.put(WORKFLOWS, new BasicDBObject("$elemMatch", workflowCriteria));

		return updateQuery;

	}

	private DBObject prepareFindQuery(Long id, Long fromGroupId, String inquiryStatus, String direction)
	{
		return prepareFindQuery(id, fromGroupId, inquiryStatus, direction, true);
	}

	private DBObject prepareFindAssignQuery(Long id, Long fromGroupId, String inquiryStatus, String direction)
	{
		BasicDBObject workflowCriteria = new BasicDBObject();

		DBObject updateQuery = new BasicDBObject();
		updateQuery.put("_id", id);

		workflowCriteria.put(ASSIGNED_GROUPID, fromGroupId);
		workflowCriteria.put(STATUS, inquiryStatus);
		workflowCriteria.put(DIRECTION, direction);
		updateQuery.put(WORKFLOWS, new BasicDBObject("$elemMatch", workflowCriteria));

		return updateQuery;
	}


	/**
	 * @param id
	 * @param fromGroupId
	 * @param inquiryStatus
	 * @param directions - Accept direction List
	 * @return return the update query.
	 */
	private DBObject prepareFindAssignQueryDirectionList(Long id, Long fromGroupId, String inquiryStatus, List<String> directions)
	{
		BasicDBObject workflowCriteria = new BasicDBObject();
		DBObject updateQuery = new BasicDBObject();
		updateQuery.put("_id", id);
		workflowCriteria.put(ASSIGNED_GROUPID, fromGroupId);
		workflowCriteria.put(STATUS, inquiryStatus);
		workflowCriteria.put(DIRECTION, new BasicDBObject("$in", directions));
		updateQuery.put(WORKFLOWS, new BasicDBObject("$elemMatch", workflowCriteria));
		return updateQuery;
	}

	private Set<Long> getSolrSearchCriteria(String qString, String soeId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Set<Long> inquiryList = null;
		InputStream in = null;
		String url = null;
		String urlWithQString = null;
		try
		{
			url = QMACacheFactory.getCache().getSolrURL();
			//			UserDAO userDao = new UserDAO();
			//String userGroupsListForSolr = userDao.getUserGroupsListForSolr(soeId);
			// System.out.println(userGroupsListForSolr);
			// String myGroups = "53051 OR 53052";
			// qString = qString + " && (" + userGroupsListForSolr + ")" + "&sort=_id desc";
			// System.out.println("Qstring is: " + qString);
			//urlWithQString = url + "&q=" + URLEncoder.encode(qString, ENCODING_UTF8) + "&fq=" + URLEncoder.encode(userGroupsListForSolr, ENCODING_UTF8);
			urlWithQString = url + qString;
			subLogger.info("Solr Search URL : " + urlWithQString);
			URL connection = URI.create(urlWithQString).toURL();
			in = connection.openStream();

			// Parse JSON Output from Solr response
			BasicDBObject solrResponse = parse(in);
			inquiryList = new HashSet<Long>();
			BasicDBList inquiryIdDocs = (BasicDBList) (solrResponse.get("docs"));
			Long inquiryId = null;
			for (Object idDoc : inquiryIdDocs)
			{
				BasicDBObject document = (BasicDBObject) idDoc;
				Object inqId = document.get(INQUIRY_ID);

				inquiryId = GenericUtility.convertIdFromRequest(inqId);
				if (inquiryId != null)
				{
					inquiryList.add(inquiryId);
				}

			}
			// System.out.println("Total no of Unique Inquiries using Solr Search : " + inquiryList.size() + " and those are" + inquiryList);
			//subLogger.info("Total no of Unique Inquiries using Solr Search : " + inquiryList.size());

		}
		catch (Exception e)
		{
			subLogger.error("Error in getSolrSearchCriteria for solr search qstring is:" + qString + ",     and -completeURL is:" + urlWithQString, e);
			throw new CommunicatorException("Error in getSolrSearchCriteria for solr search qstring is:" + qString + ",     and -completeURL is:" + urlWithQString, e);
		}
		finally
		{
			if (in != null)
			{
				try
				{
					in.close();
				}
				catch (IOException e)
				{
					subLogger.error("Error in getSolrSearchCriteria while closing input stream ", e);
				}

			}
		}

		return inquiryList;
	}

	/*
	 * Sonar fix remove unused methods private String prepareSolrSearchString(String searchString) { StringBuffer sb = new StringBuffer(); sb.append("content:") .append("\"*")
	 * .append(searchString.replaceAll(" ", "*")) .append("*") .append("\""); subLogger.info("Modified Search string:" + sb.toString()); return sb.toString(); }
	 */

	private BasicDBObject parse(InputStream is) throws CommunicatorException
	{
		BasicDBObject solrResponse = null;

		try
		{
			BufferedReader streamReader = new BufferedReader(new InputStreamReader(is, ENCODING_UTF8));
			StringBuilder responseStrBuilder = new StringBuilder();

			String inputStr;
			while ((inputStr = streamReader.readLine()) != null)
				responseStrBuilder.append(inputStr);

			BasicDBObject response = BasicDBObject.parse(responseStrBuilder.toString());
			solrResponse = (BasicDBObject) response.get("response");

		}
		catch (Exception e)
		{
			subLogger.error("Error in solrResponse parsing ", e);
			throw new CommunicatorException("Error in solrResponse parsing", e);
		}

		return solrResponse;
	}

	// clear conversation data except the latest conversation.
	private List<Conversation> clearOldConvData(List<Conversation> convList)
	{
		if (convList != null && !convList.isEmpty())
		{
			if (convList.size() == 1 )
			{
				convList.get(0).setContent(InquiryUtil.replaceBaseTag(GenericUtility.checkAndFetchConvContent(convList.get(0))));
				return convList;
			}
			else
			{

				// conversation list is sorted by mod date so first conversation will be latest one
				// clear all other conversation content data except the latest one.
				boolean latestConv = true;
				for (Conversation conv : convList)
				{
					// Clear content
					if (latestConv)
					{
						latestConv = false;
						conv.setContent(InquiryUtil.replaceBaseTag(GenericUtility.checkAndFetchConvContent(conv)));
					}
					else
					{
						conv.setContent(null);
					}
				}
			}
		}

		return convList;

	}

	/**
	 * @deprecated as it's not required now *
	 */
	@Deprecated
	private void updateInquiryAudit(Inquiry inqObj, String flag) throws CommunicatorException

	{
		if ("N".equalsIgnoreCase(flag))
		{
			// createInquiryAuditRaw(inqObj, inqObj.id,inqObj. false, false);
			Query<OutBoundEmails> query1 = mongoDatastore.createQuery(OutBoundEmails.class).filter(INQUIRY_ID, inqObj.id).filter(PROCESS_FLAG, "P");
			List<OutBoundEmails> list = query1.asList();
			if (!list.isEmpty())
			{
				createInquiryAuditRaw(inqObj.id, list.get(0).getConversationId(), false, false, null, inqObj.getAction());
			}
			Query<OutBoundEmails> query = mongoDatastore.createQuery(OutBoundEmails.class).filter(INQUIRY_ID, inqObj.id).filter(PROCESS_FLAG, "P");
			// UpdateOperations<OutBoundEmails> ops = mongoDatastore.createUpdateOperations(OutBoundEmails.class).set(PROCESS_FLAG, "AP").set(MODIFIED_DATE, new Date());//AP means already processed.
			UpdateOperations<OutBoundEmails> ops = mongoDatastore.createUpdateOperations(OutBoundEmails.class).set(PROCESS_FLAG, "A").set(MODIFIED_DATE, new Date());// AP means already processed.
			mongoDatastore.update(query, ops);
		}
		else if ("R".equalsIgnoreCase(flag))
		{
			Query<OutBoundEmails> query = mongoDatastore.createQuery(OutBoundEmails.class).filter(INQUIRY_ID, inqObj.id).filter(PROCESS_FLAG, "P");
			UpdateOperations<OutBoundEmails> ops = mongoDatastore.createUpdateOperations(OutBoundEmails.class).set(PROCESS_FLAG, flag).set(MODIFIED_DATE, new Date());// R means reject
			mongoDatastore.update(query, ops);
		}

	}
	
	
	// This method updates the broadcasted status
	public void updateBroadcastInquiryProcessFlag(Long inquiryId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			UINotificationsAudit audit = new UINotificationsAudit(inquiryId);

			persist(audit);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in inserting UINotificationsAudit", e);
			throw new CommunicatorException("Exception in inserting UINotificationsAudit", e);

		}
	}

	private void updateWorkflowRequesTypeAction(List<Workflow> workflowList, Long fromGrpId, String requestTypeFromUi, String actionFromUI,List<Long> allGroupIdList, BasicDBObject inputJsonObj)
	{
		// Null check specially for External Cases where there is no from group
		if (fromGrpId == null)
		{
			return;
		}
		QMACache qmaCache =  QMACacheFactory.getCache();
		for (Workflow workflow : workflowList)
		{
			Long grpId = workflow.getAssignedGroupId();

			boolean isGroupMatch = grpId != null && grpId.equals(fromGrpId);// Sonar Fix -- remove useless parenthesis

			if (isGroupMatch)
			{
				if(null != requestTypeFromUi && !requestTypeFromUi.equalsIgnoreCase(workflow.getRequestType())
						|| (INQUIRY_DIRECTION_OUT.equalsIgnoreCase(workflow.getDirection()) && ACTION_FORWARD.equalsIgnoreCase(actionFromUI))){
					inputJsonObj.put(REQUEST_TYPE_CHANGED_KEY, true);
					inputJsonObj.put(OLD_REQUEST_TYPE_KEY, workflow.getRequestType());
				}
				// If the action 'From' group workflow requesttype update, regardless of direction
				workflow.setRequestType(requestTypeFromUi);
				// Release 1.4 changes-Add action in the workflow
				// rule of thumb of updating the action for the group taking the action only
				// Action should be applied to all 'From Group ' Versions regardless of Direction
				workflow.setAction(actionFromUI);
				
			}
			else if (!isGroupMatch)
			{

				List<String> requestTypesList = qmaCache.getGroupIdToRequestTypeMap().get(grpId);
				if (null != requestTypesList && requestTypesList.contains(requestTypeFromUi))
				{
					workflow.setRequestType(requestTypeFromUi);
				}
				else
				{
					String requestName = getValidVersionRequestName(workflowList, grpId);
					if (requestName != null)
					{
						// preserve the existing request type for other groups
						workflow.setRequestType(requestName);
					}
				}
				// C153176-486

				// Release 1.4 changes-Add action in the workflow
				// Retain Old Actions for the group
				String versionAction = getValidVersionAction(workflowList, grpId, workflow.getDirection());
				if (versionAction != null)
				{
					// preserve the existing request type for other groups
					workflow.setAction(versionAction);
				}

			}

			// Sync reopen date in all the workflows of a particular group
			Date reOpenDate = getValidVersionReOpenDate(workflowList, grpId);
			workflow.setReOpenDate(reOpenDate);
			// Sync Linc Id
			Long linkId = getValidVersionLinkId(workflowList, grpId);
			workflow.setLinkId(linkId);

			// Sync Lock details
			Map<String, Object> lockedObjectDetails = getValidVersionLockedDetails(workflowList, grpId);

			if (null != lockedObjectDetails.get("lock"))
			{
				workflow.setLock((String) lockedObjectDetails.get("lock"));
			}
			if (null != lockedObjectDetails.get("lockedBy"))
			{
				workflow.setLockedBy((String) lockedObjectDetails.get("lockedBy"));
			}
			if (null != lockedObjectDetails.get("lockedDate"))
			{
				workflow.setLockedDate((Date) lockedObjectDetails.get("lockedDate"));
			}

			// C153176-154 ActionStatistics Improvements-C153176-290
			// Sync prevResponseCntr
			Integer prevResponseCntr = getValidPrevResponseCounter(workflowList, grpId);
			workflow.setPrevResponseCntr(prevResponseCntr);

			if(allGroupIdList.contains(grpId)){
				workflow.setConvCount(workflow.getConvCount()>0?workflow.getConvCount()+1:1);
			}
			String uiFollowUpFlag = inputJsonObj.getString(FOLLOWUP_FLAG);
			FollowUp followUp = getValidVersionFollowUp(workflowList, grpId, uiFollowUpFlag, fromGrpId);
			workflow.setFollowUp(followUp);
			if(null != workflow.getSnoozeAction() && workflow.getSnoozeAction().equalsIgnoreCase(SNOOZE) && allGroupIdList.contains(workflow.getAssignedGroupId())){
				//reply received on workflow make it un-snooze
				//workflow.setSnoozeDetails(null);
				workflow.setSnoozeAction(null);;
				workflow.setAction(actionFromUI);
				inputJsonObj.put("shouldUnsnoozeProcess", true);
			}
		}

	}

	// Get Version Action Details Used for Preserving action in IN and OUT , Pending resolve direction
	private String getValidVersionAction(List<Workflow> workflowSet, Long grpId, String direction)
	{
		String versionAction = null;

		for (Workflow version : workflowSet)
		{
			Long versionGrpId = version.getAssignedGroupId();
			String versionDirection = version.getDirection();
			boolean isGroupMatch = versionGrpId != null && versionGrpId.equals(grpId) && !StringUtils.isBlank(version.getAction()) && versionDirection.equalsIgnoreCase(direction);// Sonar Fix -- remove useless parenthesis
			if (isGroupMatch)
			{
				// get existing request type for any group(IN/OUT will have same request type and assign user)
				versionAction = version.getAction();
				return versionAction;
			}
		}
		return versionAction;
	}

	private String getValidVersionRequestName(List<Workflow> workflowSet, Long grpId)
	{
		String requestName = null;

		for (Workflow version : workflowSet)
		{
			Long versionGrpId = version.getAssignedGroupId();
			boolean isGroupMatch = versionGrpId != null && versionGrpId.equals(grpId) && !StringUtils.isBlank(version.getRequestType());// Sonar Fix -- remove useless parenthesis
			if (isGroupMatch)
			{
				// get existing request type for any group(IN/OUT will have same request type and assign user)
				requestName = version.getRequestType();
				return requestName;
			}
		}
		return requestName;
	}

	// Get Link Id
	private Long getValidVersionLinkId(List<Workflow> workflowSet, Long grpId)
	{
		Long LinkId = null;

		for (Workflow version : workflowSet)
		{
			Long versionGrpId = version.getAssignedGroupId();
			boolean isGroupMatch = versionGrpId != null && versionGrpId.equals(grpId) && null != version.getLinkId();// Sonar Fix -- remove useless parenthesis
			if (isGroupMatch)
			{
				// get existing LinkId type for any group(IN/OUT will have same LinkId)
				LinkId = version.getLinkId();
				return LinkId;
			}
		}
		return LinkId;
	}

	//Get Locked Detail
	private Map<String, Object> getValidVersionLockedDetails(List<Workflow> workflowSet, Long grpId)
	{
		String lock = null;
		String lockedBy = null;
		Date lockedDate = null;
		Map<String, Object> lockMapObjectDetails =  new HashMap<String, Object>();

		for (Workflow version : workflowSet)
		{
			Long versionGrpId = version.getAssignedGroupId();
			boolean isGroupMatch = versionGrpId != null && versionGrpId.equals(grpId) && null != version.getLock();
			if (isGroupMatch)
			{
				// get existing Lock type for any group(IN/OUT will have same Lock detail)
				lock = version.getLock();
				lockedBy = version.getLockedBy();
				lockedDate = version.getLockedDate();

				lockMapObjectDetails.put("lock", lock);
				lockMapObjectDetails.put("lockedBy", lockedBy);
				lockMapObjectDetails.put("lockedDate", lockedDate);
			}
		}
		return lockMapObjectDetails;
	}

	// Find the reOpenDate for a group in the workflow list
	private Date getValidVersionReOpenDate(List<Workflow> workflowSet, Long grpId)
	{
		Date reOpenDate = null;

		for (Workflow version : workflowSet)
		{
			Long versionGrpId = version.getAssignedGroupId();
			boolean isGroupMatch = versionGrpId != null && versionGrpId.equals(grpId) && (version.getReOpenDate() != null);// Sonar Fix -- remove useless parenthesis
			if (isGroupMatch)
			{
				// get existing reopen date for any group(IN/OUT will have same reopen date)
				reOpenDate = version.getReOpenDate();
				return reOpenDate;
			}
		}
		return reOpenDate;
	}

	// C153176-154 ActionStatistics Improvements-C153176-290
	// Get Previous Response Counter Set in Last Reply version for the Group Id
	private Integer getValidPrevResponseCounter(List<Workflow> workflowSet, Long grpId)
	{
		Integer prevRespCntr = null;

		for (Workflow version : workflowSet)
		{
			Long versionGrpId = version.getAssignedGroupId();
			boolean isGroupMatch = versionGrpId != null && INQUIRY_DIRECTION_OUT.equals(version.getDirection()) && versionGrpId.equals(grpId) && null != version.getPrevResponseCntr();
			if (isGroupMatch)
			{
				// get existing Previous Response Counter for group in OUT workflow used for last reply
				prevRespCntr = version.getPrevResponseCntr();
				return prevRespCntr;
			}
		}
		return prevRespCntr;
	}

	private String getSummaryReqTypeName(List<Workflow> workflowList)
	{
		StringBuilder sb = new StringBuilder();
		String reqTypesStr = null;
		QMACache qmaCache = QMACacheFactory.getCache();
		Map<Long, String> groupIdToNameMap = qmaCache.getGroupIdToNameMap();
		if (workflowList != null)
		{
			for (Workflow wrkflow : workflowList)
			{
				String groupName = groupIdToNameMap.get(wrkflow.getAssignedGroupId());
				if (groupName != null)
				{
					String reqTypeVal = wrkflow.getRequestType() == null ? "" : wrkflow.getRequestType();
					String assignReqStr = reqTypeVal + "[" + groupName + "]";
					if (sb.toString().toLowerCase().indexOf(groupName.toLowerCase()) == -1)
					{
						sb.append(assignReqStr).append(",");
					}
				}
			}
		}
		if (sb.length() > 0)
		{
			reqTypesStr = (sb.substring(0, sb.length() - 1)).toString();
		}
		return reqTypesStr;
	}



	
	private List<DBObject> getGroupLevelViewData(String soeid, String viewType, boolean isVersionUserCriteriaMatch, DBObject finalBoxMatchCriteria, DBObject userCriteria, DBObject orderBy,
			int uiGridRecordLimit, DBObject dbQueryType, BasicDBObject inputJsonObj1, BufferedWriter bw, DBObject gridViewTO) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		long startTime = System.currentTimeMillis();
		boolean mobileFlag = false;
		if(null != inputJsonObj1 && null != inputJsonObj1.get("mobileViewFlag")){
			mobileFlag = inputJsonObj1.getBoolean("mobileViewFlag");
		}
		subLogger.info("mobileFlag is : " + mobileFlag);
		boolean isQMA2Origin = false;
		if(null != inputJsonObj1 && null != inputJsonObj1.get("isQMA2Origin")){
			isQMA2Origin = inputJsonObj1.getBoolean("isQMA2Origin");
		}
		BasicDBObject inputJsonObj = inputJsonObj1;
		// [C153176-453]-Order of Generic and Advanced Search initialize map to hold the inquiries to sort it in relevance.
		Map<String, DBObject> inquiryObjListMap = new HashMap<String, DBObject>();
		List<DBObject> dbObjectList = new ArrayList<DBObject>();

		boolean isRetrieveAll = false;
		boolean isTopLevelVersionMatchReq = false;
		if (dbQueryType != null)
		{
			isRetrieveAll = dbQueryType.get(IS_RETRIEVE_ALL) != null ? (boolean) dbQueryType.get(IS_RETRIEVE_ALL) : isRetrieveAll;
			isTopLevelVersionMatchReq = dbQueryType.get(IS_TOP_LEVEL_VERSION_MATCH_REQ) != null ? (boolean) dbQueryType.get(IS_TOP_LEVEL_VERSION_MATCH_REQ) : isTopLevelVersionMatchReq;
		}

		String groupLevelBaseQuery = getGroupLevelBaseQuery(viewType, isVersionUserCriteriaMatch, userCriteria, soeid, isQMA2Origin,inputJsonObj1);
		String viewName  = null;
		if (inputJsonObj != null && inputJsonObj.get(VIEW_NAME) != null)
		{
			viewName = (String) inputJsonObj.get(VIEW_NAME);
		}
		Date dateCriteria =  MailboxModDateUtil.getModDateAsPerDateConfig(soeid, inputJsonObj, viewName,false);
		if(null != dateCriteria) {
			Long dateLong = dateCriteria.getTime();
			groupLevelBaseQuery = groupLevelBaseQuery.replaceAll(MOD_DATE_EXP, dateLong.toString());
		}
		DBObject orderByToPass = orderBy;// Sonar Fix -- Introduce a new variable instead of reusing the parameter

		int uiGridRecLimit = uiGridRecordLimit;// Sonar Fix -- Introduce a new variable instead of reusing the parameter
		DBObject finalBoxMatchCrit = finalBoxMatchCriteria;// Sonar Fix -- Introduce a new variable instead of reusing the parameter
		// system.out.println("Last final Query" + finalBoxMatchCrit);

		// Set grid record limit based on user entry from ui
		// If there's an exception, reset the row count to 5000
		uiGridRecLimit = checkUserRowCountPreference(soeid, uiGridRecLimit);

		if (uiGridRecLimit == 0)
		{
			uiGridRecLimit = MAX_SERVER_REC_LIMIT;
		}
		
		if(null != inputJsonObj && inputJsonObj.containsField(RECORD_COUNT)){
			uiGridRecLimit = inputJsonObj.getInt(RECORD_COUNT);
		}
		// Commenting the below else block to change the data based on user's entry
		/*
		 * else { uiGridRecLimit = (uiGridRecLimit > MAX_SERVER_REC_LIMIT) ? MAX_SERVER_REC_LIMIT : uiGridRecLimit; }
		 */
		if (orderByToPass == null)
		{
			orderByToPass = new BasicDBObject(MODIFIED_DATE, -1);
		}

		// [C153176-169] - Server-side export of inquiries
		// not removing top level filter incase of isRetrieveAll, since it contains $elemMatch in cases like Saved Search
		if (isVersionUserCriteriaMatch && !isTopLevelVersionMatchReq)
		{
			// Remove Top Inquiry level Filter as we are adding at version level
			finalBoxMatchCrit = BasicDBObject.parse(finalBoxMatchCrit.toString().replace(
					", " + userCriteria.toString(), ""));
		}
		// [C153176-169] - Server-side export of inquiries
		// Export all inquiry records without 20k limit
		if (isRetrieveAll)
		{
			int noGridRecLimit = 0;// SUNIL //6 dEC iSSUE, Thsi is temporary solution, later needs to be streamed to avoid limit.
			Cursor currOutput = BuildGroupLevelAggregateOptionForExport(INQUIRY, soeid, groupLevelBaseQuery, finalBoxMatchCrit, orderByToPass, noGridRecLimit, inputJsonObj);
			subLogger.debug("noGridRecLimit is" + noGridRecLimit);

			String dateFormat = userDao.getUserDateFormatPreference(soeid);
			boolean isQMA22Origin=false;
			if (null != inputJsonObj && null != inputJsonObj.get("isQMA2Origin"))
			{
				isQMA22Origin = inputJsonObj.getBoolean("isQMA2Origin");
			}
			try {
				writeGridViewDataToFile(bw, currOutput, dateFormat, viewName, viewType, gridViewTO,soeid,isQMA22Origin, inputJsonObj);
			} catch (IOException e) {
				subLogger.error("Issue while writing grid data to a file", e);
			}
		}
		else
		{
			boolean isDataSizeIssue = false;
			List<DBObject>  output = null;
			Cursor currOutput = null;
			// As Per discussion with Sunil-AggregartionOutput is used instead of Cursor and AggregateOptions
			try
			{
				if(null != inputJsonObj && null != inputJsonObj.get("isRequestFromMailBoxStats") && inputJsonObj.getBoolean("isRequestFromMailBoxStats")){
					//get all db records for age count
					uiGridRecLimit = 0;
				}
				if(null != inputJsonObj && null != inputJsonObj.get(IS_REQ_FROM_QMA2_DASHBOARD2) && inputJsonObj.getBoolean(IS_REQ_FROM_QMA2_DASHBOARD2)){
					//get all db records for age count
					uiGridRecLimit = 0;
				}
				output = BuildGroupLevelAggregateOption(INQUIRY, soeid, groupLevelBaseQuery, finalBoxMatchCrit, orderByToPass, uiGridRecLimit, inputJsonObj);
			}
			catch (Exception e)
			{
				// e.printStackTrace();
				subLogger.warn("Data size exceeded mongoDB limit, Now allowDisk option will be used", e);
				isDataSizeIssue = true;
				// TODO: handle exception
			}
			if (isDataSizeIssue)
			{
				currOutput = BuildGroupLevelAggregateOptionForExport(INQUIRY, soeid, groupLevelBaseQuery, finalBoxMatchCrit, orderByToPass, uiGridRecLimit, inputJsonObj);
			}

			if (inputJsonObj.getString(ADVANCED_SEARCH_DATA) != null)
			{
				inputJsonObj = BasicDBObject.parse(inputJsonObj.getString(ADVANCED_SEARCH_DATA));
			}
			Map<Long,MicroUiTO> microUiTOMap = new HashedMap<>();
			if (isPreSolrMongoSearchRequired(inputJsonObj))
			{
				if (isDataSizeIssue)
				{
					while (currOutput.hasNext())
					{
						DBObject currInqObj = currOutput.next();
						DBObject inquiry = getInquiryGroupLevelResponseForAdvanceSearch(currInqObj, inputJsonObj, mobileFlag, soeid, isQMA2Origin);
						prepareInquiryDbObjectList(viewType, inquiryObjListMap, dbObjectList, inquiry,inputJsonObj,inputJsonObj1,microUiTOMap);
					}

				}
				else
				{
					
					for(DBObject currInqObj: output) {
						DBObject inquiry = getInquiryGroupLevelResponseForAdvanceSearch(currInqObj, inputJsonObj, mobileFlag, soeid, isQMA2Origin);
						
						prepareInquiryDbObjectList(viewType, inquiryObjListMap, dbObjectList, inquiry,inputJsonObj,inputJsonObj1,microUiTOMap);
					}
				}
			}
			else
			{
				boolean isRequestFromOpenInquiriesByAssignedOwner = false;
				String ageBand = null;
				if(null != inputJsonObj.get(IS_REQ_FROM_QMA2_DASHBOARD2) && OPEN_INQUIRIES_BY_ASSIGNED_OWNERS.equalsIgnoreCase(inputJsonObj.getString(VIEW_NAME))){
					isRequestFromOpenInquiriesByAssignedOwner = inputJsonObj.getBoolean(IS_REQ_FROM_QMA2_DASHBOARD2);
					ageBand = inputJsonObj.getString("ageBand");
				}
				if (isDataSizeIssue)
				{
					while (currOutput.hasNext())
					{
						DBObject currInqObj = currOutput.next();
						DBObject inquiry = getInquiryGroupLevelResponse(currInqObj, mobileFlag, soeid, isQMA2Origin, false);
						//below code is added to get Open Inquiries by Assigned Owner (age band ) data for QMA2
						if(isRequestFromOpenInquiriesByAssignedOwner){
							prepareInquiryDbObjectListBasedOnAgeBand(ageBand, dbObjectList, inquiry);
						} else {
						prepareInquiryDbObjectList(viewType, inquiryObjListMap, dbObjectList, inquiry,inputJsonObj,inputJsonObj1,microUiTOMap);
					}
				}
				}
				else
				{
					
					boolean isRequestFromMailBoxStats = false;
					if(null != inputJsonObj.get("isRequestFromMailBoxStats")){
						isRequestFromMailBoxStats = (boolean) inputJsonObj.get("isRequestFromMailBoxStats");
					}
					Integer lt5 = 0;
					Integer gt5 = 0;
					Integer gt15 = 0;
					Integer gt30 = 0;
					for (DBObject result : output)
					{
						
						DBObject inquiry = getInquiryGroupLevelResponse(result, mobileFlag, soeid, isQMA2Origin, false);
						/*C153176-4878: Add snooze details for all snoozed inquiry.*/
						if("Snoozed".equalsIgnoreCase(inputJsonObj.getString("viewName"))) {
							updateSnoozeData(inquiry);
						}
						
						
						if(isRequestFromMailBoxStats){
							long age = (long) inquiry.get("ageForStats");
							if (age > 5 && age <= 15) {
								gt5 = gt5+1;
							}
							if (age > 15 && age <= 30) {
								gt15 = gt15+1;
							}
							if (age > 30) {
								gt30 = gt30+1;
							}
							if (age <= 5) {
								lt5=lt5+1;
							}
						}
						if(isRequestFromOpenInquiriesByAssignedOwner){
							prepareInquiryDbObjectListBasedOnAgeBand(ageBand, dbObjectList, inquiry);
						} else{
						prepareInquiryDbObjectList(viewType, inquiryObjListMap, dbObjectList, inquiry,inputJsonObj,inputJsonObj1,microUiTOMap);
					}
						
						
					}
					if(isRequestFromMailBoxStats){
						prepareAgeBandData(gridViewTO, lt5, gt5, gt15, gt30);
					}
					
				}
			}

			if (dbObjectList.isEmpty() && !inquiryObjListMap.isEmpty())
			{
				dbObjectList.addAll(inquiryObjListMap.values());
			}
		}
		
		//getTotalRecords(INQUIRY, soeid, groupLevelBaseQuery, finalBoxMatchCrit, inputJsonObj, inputJsonObj1);
		subLogger.info("Inside .getGroupLevelViewData Time Diff-"
				+ (System.currentTimeMillis() - startTime)
				+ " in Milli Seconds");

		return dbObjectList;
	}


	/**
	 * This method will dynamically add snooze details to inquiry in snoozed view.
	 * @param inquiry
	 */
	private void updateSnoozeData(DBObject inquiry) {
		try {
			Long inqId = (Long) inquiry.get("_id");
			BasicDBList workflows = (BasicDBList) inquiry.get("workflows");
			if(inqId != null && null !=workflows && null != workflows.get(0)) {
				BasicDBObject workflow = (BasicDBObject) workflows.get(0);
				Long assignedGrpId = workflow.getLong("assignedGroupId");
				if(assignedGrpId != null) {
					addSnoozeDetailsToObject(inquiry, inqId, assignedGrpId);
				}
			}
			
		} catch (Exception e) {
			subLogger.error("Exception while retrieveing snooze details for inquiry :" + inquiry.get("id") + " : ", e);
		}
	}

	/**
	 * @param inquiry
	 * @param inqId
	 * @param assignedGrpId
	 */
	private void addSnoozeDetailsToObject(DBObject inquiry, Long inqId, Long assignedGrpId) {
		InquirySnoozeDetails isdRecord = getInquirySnoozeDetails(inqId, assignedGrpId);
		if (isdRecord != null) {
			inquiry.put("snoozeDuration", isdRecord.getSnoozeDuration());
			inquiry.put("snoozedBy", isdRecord.getSnoozedBy());
		}
	}

	/**
	 * @param inq
	 * @return
	 */
	private InquirySnoozeDetails getInquirySnoozeDetails(Long inquiryID, Long assignedGrpId) {
		InquirySnoozeDetails isdRecord= null;
		try {
			if(null != inquiryID && null != assignedGrpId) {
				Query<InquirySnoozeDetails> query = mongoDatastore.createQuery(InquirySnoozeDetails.class).filter("inquiryId", inquiryID).
						filter("assignedGroupId", assignedGrpId)
						.filter("processedFlag", false);
				isdRecord = query.first();
			}
		} catch (Exception e) {
			subLogger.error("Exception while retrieveing snooze details for inquiry :" + inquiryID + " and groupId : " + assignedGrpId + " : ", e);
		}
		return isdRecord;
	}

	/**
	 * @param inquiryInput
	 * @param isMobileView
	 */
	private void extractEmailContentForMobile(DBObject inquiryInput, boolean isMobileView, String soeId) {
				
		try {
			if(null != inquiryInput && isMobileView){
				Long inquiryId  = (Long) inquiryInput.get("_id");
				/*BasicDBObject contentWithUnreadCount = getEmailContentFromConversation(inquiryId, soeId);
				if(null != contentWithUnreadCount && null != contentWithUnreadCount.get("content") && null != contentWithUnreadCount.get("unreadConvCount")){
					inquiryInput.put("recentContent", contentWithUnreadCount.getString("content"));
					inquiryInput.put("unreadConvCount", contentWithUnreadCount.getInt("unreadConvCount"));
				}*/
				
				inquiryInput.put("recentContent", "Static recent conversation contents.");
				inquiryInput.put("unreadConvCount", 0);
			}
		} catch (Exception e) {
			subLogger.error("Exception in extractEmailContentForMobile", e);
		}
	}

	private BasicDBObject getEmailContentFromConversation(Long inquiryId, String soeId) {
		
		String content = "";
		int unreadConvCount = 0;
		BasicDBObject contentWithUnreadCount = new BasicDBObject();
		try {
			List<Conversation> conversationList = mongoDatastore.createQuery(Conversation.class).filter("inquiryId", inquiryId).order("-id").find().toList();
			Conversation conversation = conversationList.get(0);
			if(null != conversation){
				content = GenericUtility.checkAndFetchConvContent(conversation);
			}
			
			unreadConvCount = getUneadCountOnConversation(conversationList, soeId);
			contentWithUnreadCount.put("content", content);
			contentWithUnreadCount.put("unreadConvCount", unreadConvCount);
		} catch (Exception e) {
			subLogger.error("Exception in getEmailContentFromConversation", e);
		}
		return contentWithUnreadCount;
	}
	
	private int getUneadCountOnConversation(List<Conversation> conversationList, String soeId){
		int unreadCount = 0;
		long convId = 0;
		
		try {
			for(Conversation conversation : conversationList){
				List<String> readBy = conversation.getReadBy();
				convId = conversation.getId();
				if(null == readBy || !readBy.contains(soeId)){
					unreadCount++;
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in getUneadCountOnConversation for convId "+convId, e);
		}
		return unreadCount;
		
	}

	/**
	 * @param ageBand
	 * @param dbObjectList
	 * @param inquiry
	 */
	private void prepareInquiryDbObjectListBasedOnAgeBand(String ageBand, List<DBObject> dbObjectList,
			DBObject inquiry) {
		int daysElapsed = 0;
		String inquiryAgeBand = null;
		Object ageObject = inquiry.get("age");
		if(ageObject instanceof Long ){
			daysElapsed = ((Long) inquiry.get("age")).intValue();
		} else if(ageObject instanceof Integer ){
			daysElapsed = ((Integer) inquiry.get("age")).intValue();
		}
		if (daysElapsed >= 0 && daysElapsed <= 1)
		{
			inquiryAgeBand = "0-1 day";
		}
		else if (daysElapsed == 2)
		{
			inquiryAgeBand = "2 days";
		}
		else if (daysElapsed > 2 && daysElapsed <= 5)
		{
			inquiryAgeBand = "3-5 days";
		}
		else if (daysElapsed > 5 && daysElapsed <= 10)
		{
			inquiryAgeBand = "6-10 days";
		}
		else if (daysElapsed > 10 && daysElapsed <= 30)
		{
			inquiryAgeBand = "11-30 days";
		}
		else if (daysElapsed > 30)
		{
			inquiryAgeBand = "30+ days";
		}
		subLogger.info("inquiry Id : "+inquiry.get("_id") + " and ageBand: "+inquiryAgeBand);
		if(null != inquiryAgeBand && inquiryAgeBand.equalsIgnoreCase(ageBand))
		{
			dbObjectList.add(inquiry);
		}
		
	}

	private void prepareAgeBandData(DBObject gridViewTO, Integer lt5, Integer gt5, Integer gt15,
			Integer gt30) {
		BasicDBObject agebandObject = new BasicDBObject();
		agebandObject.put("05+", gt5);
		agebandObject.put("lt5", lt5);
		agebandObject.put("15+", gt15);
		agebandObject.put("30+", gt30);
		gridViewTO.put("ageData", agebandObject);
	}

	private void divideInquiriesAsPerband(Integer lt5, Integer gt5, Integer gt15, Integer gt30, DBObject inquiryAge) {
		try {
			
		} catch (Exception e) {
			subLogger.error("Error while divideInquiriesAsPerband", e);
		}
	}

	// Method to prepare inquiry db list.
	private void prepareInquiryDbObjectList(String viewType, Map<String, DBObject> inquiryObjListMap, List<DBObject> dbObjectList, DBObject inquiry,BasicDBObject inputJsonObj,BasicDBObject inputJsonObj1,Map<Long,MicroUiTO> microUiTOList)
	{
		if (inquiry != null)
		{
			if (GLOBAL_GRID_VIEW_TYPE.equalsIgnoreCase(viewType) &&
					  SEARCH.equals(inputJsonObj1.get(VIEW_NAME)) &&
					  MICRO_UI.equalsIgnoreCase((String) inputJsonObj1.get(VIEW_DATA_TYPE)) &&
					 inputJsonObj.containsKey(INQUIRY_ID)) {
				prepareInquiryDbObjectListForMicroUI(dbObjectList, inquiry, microUiTOList);
			}else {
				dbObjectList.add(inquiry); 
			}
			
		}
	}
	private void prepareInquiryDbObjectListForMicroUI(List<DBObject> dbObjectList, DBObject inquiry,
			Map<Long, MicroUiTO> microUiTOMap) {
		MicroUiTO to = new MicroUiTO();
		
		DBObject workflow = (DBObject) (((BasicDBList)inquiry.get(WORKFLOWS)).get(0));
		Long inquiryId = (Long) inquiry.get(ID_COLUMN);
		Long groupId = (Long) workflow.get(ASSIGNED_GROUPID);
		String direction = (String) workflow.get(DIRECTION);
		to.setGroupId(groupId);
		to.setDirection(direction);
		to.setInquiry(inquiry);
		
		if(microUiTOMap.isEmpty() || !microUiTOMap.containsKey(inquiryId)) {
			microUiTOMap.put(inquiryId,to);
			dbObjectList.add(inquiry); 
		}else if(microUiTOMap.containsKey(inquiryId)) {
			MicroUiTO obj = microUiTOMap.get(inquiryId);
			if((obj.getDirection().equalsIgnoreCase(INQUIRY_DIRECTION_OUT) 
					|| obj.getDirection().equalsIgnoreCase(INQUIRY_DIRECTION_PENDING_APPROVAL))
					&& INQUIRY_DIRECTION_IN.equalsIgnoreCase((String) inquiry.get(DIRECTION))) {
				dbObjectList.remove(obj.getInquiry());
				dbObjectList.add(inquiry); 
			}
			if(obj.getDirection().equalsIgnoreCase(INQUIRY_DIRECTION_PENDING_APPROVAL) && INQUIRY_DIRECTION_OUT.equalsIgnoreCase((String) inquiry.get(DIRECTION))) {
				dbObjectList.remove(obj.getInquiry());
				dbObjectList.add(inquiry); 
			}
		}
	}

	private void filterInquiriesForSolrSearch(Map<String, DBObject> inquiryObjListMap, DBObject inquiry)
	{
		Long inquiryId = (Long) inquiry.get("_id");
		List<BasicDBObject> workflows = (List<BasicDBObject>) inquiry.get(WORKFLOWS);
		if (null != workflows && !workflows.isEmpty())
		{
			// Inquiry will always have only one workflow as it's already unwinded.
			BasicDBObject workflow = workflows.get(0);
			Long groupId = (Long) workflow.get(ASSIGNED_GROUPID);
			String inquiryGroupIdKey = Long.toString(inquiryId) + Long.toString(groupId);
			String direction = (String) inquiry.get(DIRECTION);
			if (inquiryGroupIdKey != null && inquiryObjListMap.get(inquiryGroupIdKey) == null)
			{
				inquiryObjListMap.put(inquiryGroupIdKey, inquiry);
			}
			if (inquiryGroupIdKey != null && inquiryObjListMap.get(inquiryGroupIdKey) != null && INQUIRY_DIRECTION_IN.equals(direction))
			{
				inquiryObjListMap.put(inquiryGroupIdKey, inquiry);
			}
		}

	}

	private int checkUserRowCountPreference(String soeid, int uiGridRecLimit) throws CommunicatorException
	{
		// Sonar fix - Use of new variable
		int gridLimit = uiGridRecLimit;
		try
		{
			if (UserDAO.getUserProfileMap() != null && UserDAO.getUserProfileMap().get(soeid) != null && UserDAO.getUserProfileMap().get(soeid).getPreferences() != null)
			{
				List<Preference> preferenceList = UserDAO.getUserProfileMap().get(soeid).getPreferences();
				for (Preference preference : preferenceList)
				{
					if ("viewRowCount".equalsIgnoreCase(preference.getKey()) && !preference.getValue().isEmpty())
					{
						gridLimit = Integer.parseInt(preference.getValue());
					}
				}
			}
		}
		catch (Exception e)
		{
			subLogger.error("Issue with retrieving user's inquiry row count data", e);
			gridLimit = 0;
			throw new CommunicatorException("Issue with retrieving user's inquiry row count data", e);

		}
		return gridLimit;
	}

	
	private List<DBObject> BuildGroupLevelAggregateOption(String collectionName, String soeid, String groupLevelBaseQuery, DBObject finalBoxMatchCriteria, DBObject orderBy, int uiGridRecordLimit,
			BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		//Set<Long> userGroupsList = userDao.getUserGroupsList(soeid);
		Set<Long> userGroupsList = getUserAssignedGroupIds(soeid, inputJsonObj);
		//subLogger.info("usergroups are" + userGroupsList.toString());
		getPersonalGroupId(soeid, inputJsonObj, userGroupsList);
		addSymphonyGroup(soeid, inputJsonObj, userGroupsList);

		List<BasicDBObject> query = buildVersionLevelGridQuery(finalBoxMatchCriteria,
				orderBy, uiGridRecordLimit, userGroupsList, groupLevelBaseQuery,inputJsonObj);
		
		//subLogger.debug("Grid Group Level query for soeId : "+soeid+ " --> "+ query);
		DBCollection col = database.getCollection(collectionName);
		List<DBObject> output = MongoDB.executeAggregatePipelineAndGetData(collectionName, query, ReadPreference.primaryPreferred(),false,DBObject.class);
		return output;
	}

	

	/** this method returns the total count of grid data
	 * @param collectionName
	 * @param soeid
	 * @param groupLevelBaseQuery
	 * @param finalBoxMatchCriteria
	 * @param orderBy
	 * @param inputJsonObj
	 * @param dbObjectList
	 * @return
	 * @throws CommunicatorException
	 */
	private void getTotalRecords(String collectionName, String soeid, String groupLevelBaseQuery, DBObject finalBoxMatchCriteria,
			BasicDBObject inputJsonObj, BasicDBObject inputJsonObj1)
	{
		try {
			long startTime = System.currentTimeMillis();
			String viewName  = null;
			if (inputJsonObj != null && inputJsonObj.get(VIEW_NAME) != null)
			{
				viewName = (String) inputJsonObj.get(VIEW_NAME);
			}
			Integer pageNum = GenericUtility.convertLongToIntFromBSON(inputJsonObj1.get("pageNum"));

			if (null != pageNum &&  pageNum == 1 && inputJsonObj != null) { //<-- sonar fix null pointer
				int totalRecords = 0;
				int totalUnreadRecords = 0;
				inputJsonObj.put("executeTotalCount", true);
				subLogger.info("get total records");
				Set<Long> userGroupsList = getUserAssignedGroupIds(soeid, inputJsonObj);

				List<BasicDBObject> query = buildVersionLevelGridQuery(finalBoxMatchCriteria,
						null, 0, userGroupsList, groupLevelBaseQuery,inputJsonObj);
				query.add(new BasicDBObject("$count",TOTAL_RECORDS));
                subLogger.info("Grid Group Level query for total records for soeId : "+soeid+ " --> "+ query);

				DBCollection col = database.getCollection(collectionName);
				AggregationOptions aggregationOptions = AggregationOptions.builder().build();
				Cursor output = col.aggregate(query, aggregationOptions, ReadPreference.secondaryPreferred());
				while (output.hasNext()) {
					DBObject result = output.next();
					totalRecords = (int) result.get(TOTAL_RECORDS);
				}
				inputJsonObj1.put(TOTAL_RECORDS, totalRecords);
				
				subLogger.info("PERFORMANCE :: getGridViewData for viewName: "+viewName+" and soeId: "+soeid+" - to fetch total record count : "
						+ (System.currentTimeMillis() - startTime)
						+ " in Milli Seconds");
				
				startTime = System.currentTimeMillis();
				
				List<BasicDBObject> queryTotalUnreadCount = buildVersionLevelGridQuery(finalBoxMatchCriteria,
						null, 0, userGroupsList, groupLevelBaseQuery,inputJsonObj);
				
				//queryTotalUnreadCount.add(new BasicDBObject("$match",new BasicDBObject("readBy",new BasicDBObject("$exists",true))));
				queryTotalUnreadCount.add(new BasicDBObject("$match",new BasicDBObject("readBy",new BasicDBObject("$ne",soeid))));
				queryTotalUnreadCount.add(new BasicDBObject("$count",TOTAL_RECORDS));
				subLogger.info("Grid Group Level query for total unread records for soeId : "+soeid+ " --> "+ queryTotalUnreadCount);
				Cursor outputUnreadCount = col.aggregate(queryTotalUnreadCount, aggregationOptions, ReadPreference.secondaryPreferred());
				while (outputUnreadCount.hasNext())	{
					DBObject result = outputUnreadCount.next();
					totalUnreadRecords = (int) result.get(TOTAL_RECORDS);
				}
				inputJsonObj1.put(TOTAL_UNREAD_RECORDS, totalUnreadRecords);
				
				subLogger.info("PERFORMANCE :: getGridViewData for viewName: "+viewName+" and soeId: "+soeid+" - to fetch total unread record count : "
						+ (System.currentTimeMillis() - startTime)
						+ " in Milli Seconds");
			}
			
		} catch (CommunicatorException e) {
			subLogger.error("Exception while fetching total records count in getTotalRecords method", e);
		}
	}

	/**
	 * @param soeid
	 * @param inputJsonObj
	 * @return
	 * @throws CommunicatorException
	 */
	private Set<Long> getUserAssignedGroupIds(String soeid, BasicDBObject inputJsonObj) throws CommunicatorException {
		Set<Long> userGroupsList = null;
		//if request is from mailbox stats
		if(null != inputJsonObj && null != inputJsonObj.get("isRequestFromMailBoxStats") && inputJsonObj.getBoolean("isRequestFromMailBoxStats")){
			//get user group from dashboard settings
			userGroupsList = InquiryExtendedDAO.getInstance().getAssignedGroupdIdFromDashboardSetting(soeid);
			if(null == userGroupsList || userGroupsList.isEmpty()){
				// get user groups
				userGroupsList = userDao.getUserGroupsList(soeid);
			}
		} else {
			if(null != inputJsonObj && null != inputJsonObj.get("isChartView") && "Y".equalsIgnoreCase(inputJsonObj.getString("isChartView")) 
					&& null != inputJsonObj.get("groupId") && StringUtils.isNotBlank(inputJsonObj.getString("groupId"))){
				// Load data specific the group data
				if("All".equalsIgnoreCase(inputJsonObj.getString("groupId"))){
					userGroupsList = InquiryExtendedDAO.getInstance().getAssignedGroupdIdFromDashboardSetting(soeid);
					if(null == userGroupsList || userGroupsList.isEmpty()){
						// get user groups
						userGroupsList = userDao.getUserGroupsList(soeid);
					}
				} else {
					Long groupId=GenericUtility.getIdFromRequest(inputJsonObj, "groupId");
					
					 if(groupId !=null){ 
						 userGroupsList = new HashSet<>();
						 userGroupsList.add(groupId);
					 }
				}
				
			} else if(null != inputJsonObj && null != inputJsonObj.get(TAG_SEARCH) && "Y".equalsIgnoreCase(inputJsonObj.getString(TAG_SEARCH)) 
					&& null != inputJsonObj.get(GROUP_NAME) && StringUtils.isNotBlank(inputJsonObj.getString(GROUP_NAME))){
				String groupName = inputJsonObj.getString(GROUP_NAME);

				// GroupName null check
				if (!StringUtils.isBlank(groupName))
				{
					Long groupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
					if(groupId !=null){ 
						 userGroupsList = new HashSet<>();
						 userGroupsList.add(groupId);
					 }
				}
			} 
			// C170665-42 | Fetch only selected assigned group in dashboard setting.
			else if(null != inputJsonObj && null != inputJsonObj.get("viewType") && null != inputJsonObj.get("isQMA2Origin") && inputJsonObj.getBoolean("isQMA2Origin")) {
				userGroupsList = InquiryExtendedDAO.getInstance().getAssignedGroupdIdFromDashboardSetting(soeid);
				if(null == userGroupsList || userGroupsList.isEmpty()){
					// get user groups
					userGroupsList = userDao.getUserGroupsList(soeid);
				}
			} else {
			// get user groups
				userGroupsList = InquiryExtendedDAO.getInstance().getAssignedGroupdIdFromDashboardSetting(soeid);
				if(null == userGroupsList || userGroupsList.isEmpty()){
					// get user groups
					userGroupsList = userDao.getUserGroupsList(soeid);
				}
			 }
		}
		return userGroupsList;
	}

	// [C153176-169] - Server-side export of inquiries
	// Method to extract inquiries without record limit and return result as a cursor
	private Cursor BuildGroupLevelAggregateOptionForExport(String collectionName, String soeid, String groupLevelBaseQuery, DBObject finalBoxMatchCriteria, DBObject orderBy, int uiGridRecordLimit, BasicDBObject inputJsonObj)
			throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		//Set<Long> userGroupsList = userDao.getUserGroupsList(soeid);
		Set<Long> userGroupsList = getUserAssignedGroupIds(soeid, inputJsonObj);
		//subLogger.info("usergroups are ****" + userGroupsList.toString());
		getPersonalGroupId(soeid, inputJsonObj, userGroupsList);
		addSymphonyGroup(soeid, inputJsonObj, userGroupsList);
		// Removing record limit
		// int uiGridRecordLimit = 0;
		List<BasicDBObject> query = buildVersionLevelGridQuery(finalBoxMatchCriteria,
				orderBy, uiGridRecordLimit, userGroupsList, groupLevelBaseQuery,  inputJsonObj);
		//subLogger.debug("Grid Group Level query for soeId "+soeid+ " ---> "+ query);
		AggregationOptions aggregationOptions = AggregationOptions.builder()
				//.outputMode(AggregationOptions.OutputMode.CURSOR)
				.allowDiskUse(true)
				.build();
		// DBCollection col = database.getCollection(collectionName);
		DBCollection col = databaseSecondary.getCollection(collectionName);
		Cursor currOutput = col.aggregate(query, aggregationOptions);

		return currOutput;
	}

	
	public DBObject getInquiryGroupLevelResponse(DBObject inquiry, boolean mobileFlag, String soeId, boolean isQMA2Origin, boolean isWebSocketUpdate)
	{
		if(isQMA2Origin && null != inquiry && null != inquiry.get("latestUserName") && null != inquiry.get("latestEmail")){
			String displayName = formatDisplayName((String)inquiry.get("latestUserName"), (String) inquiry.get("latestEmail"));
			if(StringUtils.isNotBlank(displayName)){
				inquiry.put("latestUserName", displayName);
			}
		}

		
		DBObject workflow;
		if(inquiry.get(WORKFLOWS) instanceof Document) {
			workflow = BasicDBObject.parse(((Document)inquiry.get(WORKFLOWS)).toJson());
		} else {
			workflow = (DBObject) inquiry.get(WORKFLOWS);
		}
		setClientCategoryForWorkflows(inquiry, workflow);
		// Remove below code after migration
		//Long assignedGrpId = (Long) workflow.get(ASSIGNED_GROUPID);
		//websocket 
		Long assignedGrpId = isWebSocketUpdate ? ((Number) workflow.get(ASSIGNED_GROUPID)).longValue() :  (Long) workflow.get(ASSIGNED_GROUPID);
		
		String assignedGroupName = QMACacheFactory.getCache().getGroupIdToNameMap().get(assignedGrpId);
		if (StringUtils.isBlank(assignedGroupName))
		{
			subLogger.info("Group Id deactivated and not considered for Group Id: " + assignedGrpId + " , Inquiry Id=" + inquiry.get("_id"));
			return null;
		}
		/*updated field for websocket*/
		if(isWebSocketUpdate) {
			inquiry.put("openUsers", workflow.get("assignedUserName"));
			inquiry.put("requestTypeStr", workflow.get("requestType"));
		}
		/**/
		String workflowStatus = (String) workflow.get(STATUS);
		workflow.put(ASSIGNED_GROUP_NAME, assignedGroupName);
		inquiry.put(OPEN_GROUPS, assignedGroupName);
		// Grid Status column will show workflow level status
		inquiry.put(STATUS, workflowStatus);
		inquiry.put(ACTION, workflow.get(ACTION));
		inquiry.put(INQUIRY_SUB_STATUS, workflow.get(INQUIRY_SUB_STATUS));
		inquiry.put("prevInqSubStatus", workflow.get("prevInqSubStatus"));
		// Adding tag as well to reflect in PubSub
		inquiry.put("tag", workflow.get("tag"));
		BasicDBList workflowList = new BasicDBList();
		workflowList.add(workflow);
		inquiry.put(WORKFLOWS, workflowList);
		inquiry.put(DIRECTION, workflow.get(DIRECTION));
		// Added two new columns (lastActionTime and lastActionBy) to show which user taken an action and at what time.
		inquiry.put(LAST_ACTION_BY, workflow.get(LAST_ACTION_BY));
		inquiry.put(LAST_ACTION_TIME, workflow.get(LAST_ACTION_TIME));
		// Added two new columns (resolver and resolveTime) to show which user resolved the inquiry.
		inquiry.put(RESOLVER, workflow.get(RESOLVER));
		inquiry.put(RESOLVE_TIME, workflow.get(RESOLVE_TIME));
		inquiry.put("convCount", workflow.get("convCount"));
		inquiry.put(ROOT_CAUSE, workflow.get(ROOT_CAUSE));
		inquiry.put(PROCESSING_REGION, workflow.get(PROCESSING_REGION));
		inquiry.put(QUERY_COUNT, workflow.get(QUERY_COUNT));
		inquiry.put("responseTimeQMA", workflow.get("responseTimeQMA"));
		inquiry.put("avgResponseTimeQMA", workflow.get("avgResponseTimeQMA"));
		inquiry.put("replyCountQMA", workflow.get("replyCountQMA"));
		inquiry.put(INQUIRY_SOURCE, workflow.get(INQUIRY_SOURCE));
		inquiry.put("totalResolveTimeQMA", workflow.get("totalResolveTimeQMA"));
		inquiry.put("resolveCountQMA", workflow.get("resolveCountQMA"));
		inquiry.put("clientChaseCounter", workflow.get("clientChaseCounter"));
		inquiry.put(LOCK, workflow.get("lock"));// C153176-875
		inquiry.put(LOCKED_BY, workflow.get("lockedBy"));
		inquiry.put(LOCKED_TIME, workflow.get("lockedDate"));
		//[C153176-1014] - Add Escalation functionality
		inquiry.put("isConvCountEscalation", workflow.get("isConvCountEscalation"));
		inquiry.put("responseTimeEscalationFlag", workflow.get("responseTimeEscalationFlag"));
		inquiry.put("isClientChaseEscalation", workflow.get("isClientChaseEscalation"));
		inquiry.put("isSubjectEscalation", workflow.get("isSubjectEscalation"));
		inquiry.put("generalEscalationReason", workflow.get("generalEscalationReason"));
		inquiry.put("responseTimeEscalationReason", workflow.get("responseTimeEscalationReason"));
		inquiry.put("ispendingApprovalEscalation", workflow.get("ispendingApprovalEscalation"));
		inquiry.put("isManualEscalation", workflow.get("isManualEscalation"));
		inquiry.put("manualEscalationReason", workflow.get("manualEscalationReason"));
		inquiry.put("followUp", workflow.get("followUp"));
		inquiry.put("workflowStatus", workflow.get("workflowStatus"));
		inquiry.put("reAgeDate", workflow.get("reAgeDate"));
		inquiry.put("suggestionIndicator", workflow.get("suggestionIndicator"));
		
		String intent = (StringUtils.isBlank((String)workflow.get(USER_INTENT_SUGGESTION_NAME)) ? (String)workflow.get(INTENT_SUGGESTION_NAME): (String)workflow.get(USER_INTENT_SUGGESTION_NAME));
		String name = getIntentSuggestionIndicatorFromCache(intent);
		if(StringUtils.isNotBlank(name)) {
			String intentSuggestionName = (StringUtils.isNotBlank(intent)? intent : "");
			String noIntentOtherSuggestionName = intentSuggestionName.replaceAll(NLPConstants.ALPHABATE_REGEX, " ");
			if(NLPConstants.NO_INTENT_OTHER_INTENT_KEY.equalsIgnoreCase(noIntentOtherSuggestionName)) {
				inquiry.put(INTENT_SUGGESTION_NAME, "");
				inquiry.put(INTENT_SUGGESTION_INDICATOR, "");
			}else {
				inquiry.put(INTENT_SUGGESTION_NAME, intentSuggestionName);
				inquiry.put(INTENT_SUGGESTION_INDICATOR, name);
			}
			String timeToVDs = (String)workflow.get(INTENT_TIME_TO_VD);
			if(StringUtils.isNotBlank(timeToVDs)) {
				String[] arr =  timeToVDs.split("-");
				if (null != arr && arr.length > 2){
					inquiry.put(INTENT_TIME_TO_VD,AgeAndTimeUtils.getTimeToVD((String)workflow.get(INTENT_TIME_TO_VD), assignedGrpId));
				}else {
					inquiry.put(INTENT_TIME_TO_VD,(String)workflow.get(INTENT_TIME_TO_VD));
				}	
			}
			
		}else{
			inquiry.put(INTENT_SUGGESTION_NAME, null);
			inquiry.put(INTENT_SUGGESTION_INDICATOR, null);
			inquiry.put(INTENT_TIME_TO_VD, null);
		}
		
		// [C153176-1694] - Acknowledge Escalation flags
		inquiry.put("isAckEscalation", workflow.get("isAckEscalation"));
		inquiry.put("ackEscalationBy", workflow.get("ackEscalationBy"));
		inquiry.put("ackEscalationTime", workflow.get("ackEscalationTime"));
		inquiry.put("latestConversationPreviewText", workflow.get("latestConversationPreviewText"));
		inquiry.put("latestSenderDomain", workflow.get("latestSenderDomain"));
		inquiry.put("latestExchangeItemId", workflow.get("latestExchangeItemId"));
		//Map<String,Config> configIdMap =  CacheDAO.getInstance().getConfigIdMap();
		if( null != QMACacheFactory.getCache().getConfigById("enableAgeBasedCalculation") ) {
			Config ageConfig = QMACacheFactory.getCache().getConfigById("enableAgeBasedCalculation");
			if( ageConfig.isEnableAgeBasedCalculation() ) {
				AgeAndTimeUtils.updateAgeData(assignedGrpId, (BasicDBObject) workflow);
			}
		}
		long age =  (null != workflow.get("ageInDays")) ? (int) workflow.get("ageInDays") : AgeAndTimeUtils.getAgeForNonHolidayConfig(workflow, "age");
		inquiry.put("age", null != workflow.get("ageInDays") ? workflow.get("ageInDays") : AgeAndTimeUtils.getAgeForNonHolidayConfig(workflow, "age"));
		inquiry.put("ageForStats", age);
		inquiry.put("ageInHrs", null != workflow.get("ageInHrs") ? workflow.get("ageInHrs") : "");
		inquiry.put("reOpenAge", null != workflow.get("reOpenAgeInDays") ? workflow.get("reOpenAgeInDays") : workflow.get("reOpenAge") != null ? AgeAndTimeUtils.getAgeForNonHolidayConfig(workflow, "reOpenAge"):"");
		inquiry.put("reOpenAgeInHrs", null != workflow.get("reOpenAgeInHrs") ? workflow.get("reOpenAgeInHrs") : "");
		// C170665-6 Time in queue
	    inquiry.put("timeInQueue",AgeAndTimeUtils.calculateTimeInQueue(assignedGrpId,(BasicDBObject)workflow,isWebSocketUpdate));
		/*workflow.put(ASSIGNED_GROUPID,GenericUtility.convertLongToIntFromBSON(workflow.get(ASSIGNED_GROUPID)));
		workflow.put(QUERY_COUNT,GenericUtility.convertLongToIntFromBSON(workflow.get(QUERY_COUNT)));
		inquiry.put("_id",GenericUtility.convertLongToIntFromBSON(inquiry.get("_id")));*/
		inquiry.put(AUTO_ASSIGNED, workflow.get(AUTO_ASSIGNED));
		//below code is added to get the email content for mobile view only
		if(!isWebSocketUpdate) {
			extractEmailContentForMobile(inquiry, mobileFlag, soeId);
		}
		
		return inquiry;
	}

	
	
	private String getIntentSuggestionIndicatorFromCache(Object intentSuggestionName) {
		Config nlpConfig = QMACacheFactory.getCache().getConfigById("nlpConfiguration");
		String intentSuggestionIndicator = "";
		if(null != nlpConfig && null != nlpConfig.getNlpConfiguration() && null != intentSuggestionName) {
			Map<String, Object> configMap =  nlpConfig.getNlpConfiguration();
			Map<String,String> intentIndicatorMap = (Map<String, String>) configMap.get(INTENT_SUGGESTION_INDICATOR);
			if(null != intentIndicatorMap && !intentIndicatorMap.isEmpty() && intentIndicatorMap.containsKey(intentSuggestionName)) {
				intentSuggestionIndicator = intentIndicatorMap.get(intentSuggestionName);
			}
		}
		return intentSuggestionIndicator;
	}
	private String formatDisplayName(String latestUserName, String latestEmail) {
		String formattedLatestUserName = null;
		try {
			String latestUserNameTrim = latestUserName.trim();
			String latestEmailTrim = latestEmail.trim();
			boolean isCitiDomain = true;
			String domain = null;
			if(StringUtils.isNotBlank(latestEmailTrim) && latestEmailTrim.contains("@")){
				isCitiDomain = GenericUtility.isCitiDomainEmail(latestEmail);
			}
			if(!isCitiDomain){
				domain = getExternalEmailDomain(latestEmailTrim);
				if(StringUtils.isNotBlank(domain) &&  StringUtils.isNotBlank(latestUserNameTrim) && latestUserNameTrim.startsWith("[External]")){
					formattedLatestUserName = latestUserNameTrim.replace("[External]", "["+ domain+"]");
				} else if(StringUtils.isNotBlank(domain) && StringUtils.isNotBlank(latestUserNameTrim) && !latestUserNameTrim.startsWith("[")){
					formattedLatestUserName = "["+ domain+"] "+latestUserNameTrim;
				}
			}
			
		} catch (Exception e) {
			subLogger.error("Exception while formatting display name", e);
			formattedLatestUserName = null;
		}
		return formattedLatestUserName;
	}
	
	private String getExternalEmailDomain(String email)
	{
		if(StringUtils.isNotBlank(email) && email.contains("@")){
			String[] parts = email.split("@");
			return parts[parts.length-1].toUpperCase();
		}
		return "";
		
	}

	/**
	 * Method used to set client category at workflow level in response of getGridViewData
	 * @param inquiry
	 * @param workflow
	 */
	public void setClientCategoryForWorkflows(DBObject inquiry, DBObject workflow) {
		try {
			BasicDBObject basicObject = new BasicDBObject();
			String clientPriority = null;
			if (null != inquiry && null != inquiry.get("clientPriority")) {
				clientPriority = (String) inquiry.get("clientPriority");
			}
			if (StringUtils.isNotEmpty(clientPriority) && (CLIENT_CATEGORY_PLATINUM.equalsIgnoreCase(clientPriority) || CLIENT_CATEGORY_SUPERCHARGE.equalsIgnoreCase(clientPriority))) {
				basicObject.put(CATEGORY_NAME,CLIENT_CATEGORY_PLATINUM);
				basicObject.put(CLIENT_CATEGORY_COLOR_CODE,"#FD62C5");
				workflow.put(CLIENT_CATEGORY, basicObject);
			} else if (StringUtils.isNotEmpty(clientPriority) && CLIENT_CATEGORY_PRIORITY.equalsIgnoreCase(clientPriority)) {
				basicObject.put(CATEGORY_NAME,CLIENT_CATEGORY_PRIORITY);
				basicObject.put(CLIENT_CATEGORY_COLOR_CODE,"#914EFF");
				workflow.put(CLIENT_CATEGORY, basicObject);
			} else if (isOtherClientCategory(inquiry)) {
				basicObject.put(CATEGORY_NAME,CLIENT_CATEGORY_CLIENT);
				basicObject.put(CLIENT_CATEGORY_COLOR_CODE,"#00D1D1");
				workflow.put(CLIENT_CATEGORY, basicObject);
			}
			
		} catch (Exception e) {
			subLogger.error("Exception while setting client priority workflow level:", e);
		}
	}
	
	/** to check if inquiry is from other client
	 * @param inquiry
	 * @return
	 */
	boolean isOtherClientCategory(DBObject inquiry){
		boolean status = false;
		try {
			String gpNum = null;
			String gpName = null;
			String clientName = null;
			if(null != inquiry.get("gpNum")){
				gpNum = (String) inquiry.get("gpNum");
			} 
			if(null != inquiry.get("gpName")){
				gpName = (String) inquiry.get("gpName");
			} 
			if(null != inquiry.get("clientName")){
				clientName = (String) inquiry.get("clientName");
			} 
			if(!StringUtils.isBlank(gpNum) && !StringUtils.isBlank(gpName) && !StringUtils.isBlank(clientName)){
				status = true;
			}
		} catch (Exception e) {
			subLogger.error("Exception in isOtherClientCategory", e);
		}
		
		return status;
		
	}

	private DBObject getInquiryGroupLevelResponseForAdvanceSearch(DBObject inquiry, BasicDBObject inputJsonObj, boolean mobileFlag, String soeId, boolean isQMA2Origin) throws CommunicatorException
	{
		List<String> reqTypeList = (List<String>) inputJsonObj.get(REQUEST_TYPE_LIST);
		// List<Long> assignedGroupIdList = (List<Long>) inputJsonObj.get(ASSIGNED_GROUP_NAME);
		//List<Long> assignedGroupIdList = GenericUtility.getIdListFromRequest(inputJsonObj, ASSIGNED_GROUP_NAME);
		List<Long> assignedGroupIdList = GenericUtility.getIdListFromRequest(inputJsonObj, ASSIGNED_GROUPID_LIST);
		
		List<String> tagList = (List<String>) inputJsonObj.get(TAG_LIST);
		List<String> userList = (List<String>) inputJsonObj.get(USER_LIST);
		//		List<String> statusList = (List<String>) inputJsonObj.get("statusList");
		List<String> resolverList = (List<String>) inputJsonObj.get(RESOLVER_LIST);
		String advSearchGFCID = (String) inputJsonObj.get("advSearchGFCID");
		String advSearchGFPID = (String) inputJsonObj.get(ADVANCED_SEARCH_GFPID);

		String startDt = inputJsonObj.getString("startDt");
		Date startDate =null;
		if(startDt!=null) startDate = toDate(startDt, MONGO_UTC_FORMAT);

		String endDt = inputJsonObj.getString("endDt");
		Date endDate =null;
		if(endDt!=null) endDate = toDate(endDt, MONGO_UTC_FORMAT);

		List<String> rootCauseList = (List<String>) inputJsonObj.get("rootCauseList");
		List<String> processingRegionList = (List<String>) inputJsonObj.get("processingRegionList");
		List<String> inquirySourceList = (List<String>) inputJsonObj.get("inquirySourceList");
		String queryCnt = inputJsonObj.getString(QUERY_COUNT);
		String convCnt = inputJsonObj.getString("convCount");


		DBObject workflow = (DBObject) inquiry.get(WORKFLOWS);

		// Remove below code after migration
		Long assignedGrpId = (Long) workflow.get(ASSIGNED_GROUPID);
		String assignedGroupName = QMACacheFactory.getCache().getGroupIdToNameMap().get(assignedGrpId);
		if (StringUtils.isBlank(assignedGroupName))
		{
			subLogger.info("Group Id deactivated and not considered for Group Id: " + assignedGrpId + " , Inquiry Id=" + inquiry.get("_id"));
			return null;
		}
		String workflowStatus = (String) workflow.get(STATUS);
		String tag = (String) workflow.get("tag");
		String requestType = (String) workflow.get(REQUEST_TYPE);
		String assignedUserId = (String) inquiry.get(ASSIGNED_USER_ID);
		String resolver = (String) workflow.get(RESOLVER);
		String gfpId = (String) inquiry.get(GP_NAME);
		String gfcId = (String) inquiry.get(GFC_ID);
		Date modDate = (Date) inquiry.get(MODIFIED_DATE);
		String rootCause = (String) workflow.get(ROOT_CAUSE);
		String processingRegion = (String) workflow.get(PROCESSING_REGION);
		String inquirySource = (String) workflow.get(INQUIRY_SOURCE);
		String queryCount = String.valueOf(workflow.get(QUERY_COUNT));
		String convCount = String.valueOf(workflow.get("convCount"));

		// Case for filtering open inquries.
		if (null != resolverList && (!resolverList.contains(resolver) || !STATUS_RESOLVE.equalsIgnoreCase(workflowStatus)))

		{
			return null;
		}

		// Not included date condition, not required as discussed.
		// Added gfcId and gfpId into the advaned search.
		if ((assignedGroupIdList != null && !assignedGroupIdList.isEmpty() && !assignedGroupIdList.contains(assignedGrpId))
				|| (tagList != null && !tagList.contains(tag))
				|| (reqTypeList != null && !reqTypeList.contains(requestType)) || (userList != null && !userList.contains(assignedUserId)) 
				|| (!StringUtils.isBlank(advSearchGFPID) && !advSearchGFPID.equals(gfpId)) 
				|| (!StringUtils.isBlank(advSearchGFCID) && !advSearchGFCID.equals(gfcId))
				|| (rootCauseList != null && !rootCauseList.contains(rootCause))
				|| (processingRegionList != null && !processingRegionList.contains(processingRegion))
				|| (inquirySourceList != null && !inquirySourceList.contains(inquirySource))
				|| (!StringUtils.isBlank(queryCnt) && !queryCnt.equals(queryCount))
				|| (!StringUtils.isBlank(convCnt) && !convCnt.equals(convCount))
				|| (startDate!=null && startDate.after(modDate))
				|| (endDate!=null && endDate.before(modDate))
				)

		{
			return null;
		}

		getInquiryGroupLevelResponse(inquiry, mobileFlag, soeId, isQMA2Origin, false);
		return inquiry;
	}

	private List<BasicDBObject> buildVersionLevelGridQuery(DBObject finalBoxMatchCriteria,
			DBObject orderBy, int uiGridRecordLimit, Set<Long> userGroupsList,
			String groupLevelBaseQueryStr, BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		StringBuilder finalQueryBuilder = new StringBuilder("[");

		//subLogger.info("finalBoxMatchCriteria is********:" + finalBoxMatchCriteria);
		
		BasicDBObject advancedSearchDateQuery = getAdvancedSearchDateQuery(inputJsonObj, finalBoxMatchCriteria);

		// First Match Criteria
		if ( null != advancedSearchDateQuery )
		{
			finalQueryBuilder.append("{ $match : " + advancedSearchDateQuery.toString() + "}");
		}else if (null != finalBoxMatchCriteria )
		{
			finalQueryBuilder.append("{ $match : " + finalBoxMatchCriteria.toString() + "}");
		}
		//added below code to get open inquiries by request type chart data for QMA2
		if(null != inputJsonObj && null != inputJsonObj.get(IS_REQ_FROM_QMA2_DASHBOARD) && inputJsonObj.getBoolean(IS_REQ_FROM_QMA2_DASHBOARD)
				&& null != inputJsonObj.get(VIEW_NAME) && OPEN_INQUIRIES_BY_REQUEST_TYPE.equalsIgnoreCase(inputJsonObj.getString(VIEW_NAME))
				&& null != inputJsonObj.get(REQUEST_TYPE)){
			if("Unassigned".equalsIgnoreCase(inputJsonObj.getString(REQUEST_TYPE))){
				groupLevelBaseQueryStr = groupLevelBaseQueryStr.replace("#reqType#", "{'$exists': false}");
			}else {
				groupLevelBaseQueryStr = groupLevelBaseQueryStr.replace("#reqType#", "'"+inputJsonObj.getString(REQUEST_TYPE)+"'");
			}
			
		}
		//added below code to get open inquiries by assigned group chart data for QMA2
		if(null != inputJsonObj && null != inputJsonObj.get(IS_REQ_FROM_QMA2_DASHBOARD) && inputJsonObj.getBoolean(IS_REQ_FROM_QMA2_DASHBOARD)
				&& null != inputJsonObj.get(VIEW_NAME) && OPEN_INQUIRIES_BY_ASSIGNED_OWNERS.equalsIgnoreCase(inputJsonObj.getString(VIEW_NAME))
				&& null != inputJsonObj.get(ASSIGNED_OWNER_ID)){
			if("Unassigned".equalsIgnoreCase(inputJsonObj.getString(ASSIGNED_OWNER_ID))){
				Map<String, Long> dateByAgeBandMap = GenericUtility.getDateByAgeBand(inputJsonObj);
				String unAssignedAndAgeBandCriteria = "{'$exists': false}";
				if(null != dateByAgeBandMap.get(AGE_BAND_TO_DATE)) {
					long ageBandToDate = dateByAgeBandMap.get(AGE_BAND_TO_DATE);
					unAssignedAndAgeBandCriteria = unAssignedAndAgeBandCriteria+", 'workflows.crtDate':{'$gt':{'$date':"+ageBandToDate+"}}";
				}
				if(null != dateByAgeBandMap.get(AGE_BAND_FROM_DATE)) {
					long ageBandFromDate = dateByAgeBandMap.get(AGE_BAND_FROM_DATE);
					unAssignedAndAgeBandCriteria = unAssignedAndAgeBandCriteria+", 'workflows.crtDate':{'$lte':{'$date':"+ageBandFromDate+"}}";
				}
				
				groupLevelBaseQueryStr = groupLevelBaseQueryStr.replace(UN_ASSIGNED_USER_ID, unAssignedAndAgeBandCriteria);
			} else {
				groupLevelBaseQueryStr = groupLevelBaseQueryStr.replace(UN_ASSIGNED_USER_ID, "'"+inputJsonObj.getString(ASSIGNED_OWNER_ID)+"'");
			}
			
		}
		//added below code to get tag view data
		if(null != inputJsonObj && null != inputJsonObj.get(TAG_SEARCH) && "Y".equalsIgnoreCase(inputJsonObj.getString(TAG_SEARCH))
				&& null != inputJsonObj.get(VIEW_NAME)){
			groupLevelBaseQueryStr = groupLevelBaseQueryStr.replace("#tagName#", "'"+inputJsonObj.getString(VIEW_NAME)+"'");
			
		}
		if(null != inputJsonObj && inputJsonObj.containsField(IS_PERSONAL) 
				&& "Y".equalsIgnoreCase(inputJsonObj.getString(IS_PERSONAL))
				&& null != inputJsonObj.get(PERSONAL_FOLDER_NAME)){
			groupLevelBaseQueryStr = groupLevelBaseQueryStr.replace("#personalFolderName#", "'"+inputJsonObj.getString(PERSONAL_FOLDER_NAME)+"'");

		}
		if (!StringUtils.isBlank(groupLevelBaseQueryStr))
		{
			/// Project , UnWrap, Version Match Query, Group(for count)/Project to Load boxes
			finalQueryBuilder=finalBoxMatchCriteria != null?finalQueryBuilder.append(",").append(groupLevelBaseQueryStr):finalQueryBuilder.append(groupLevelBaseQueryStr);
		}
		
		// Sort as per View Config
		if (orderBy != null)
		{
			finalQueryBuilder.append(" , ").append("{ $sort : " + orderBy.toString() + "}");
		}
		boolean executeTotalCountFlag = false;
		if(null != inputJsonObj && null != inputJsonObj.get("executeTotalCount") && inputJsonObj.getBoolean("executeTotalCount")){
			executeTotalCountFlag = true;
		}
		if(null != inputJsonObj && null != inputJsonObj.get(VIEW_NAME) && INTENSITY_HEAT_MAP.equalsIgnoreCase(inputJsonObj.getString(VIEW_NAME))
				&& null != inputJsonObj.get("categoryType") && "system".equalsIgnoreCase(inputJsonObj.getString("categoryType"))) {
			
			finalQueryBuilder.append(" , ").append("{'$group':{'_id':{'inquiryId':'$_id','assignedGroupId':'$workflows.assignedGroupId'},'doc':{'$first':'$$ROOT'}}}");
			finalQueryBuilder.append(" , ").append("{'$replaceRoot':{'newRoot':'$doc'}}");
			finalQueryBuilder.append(" , ").append("{'$sort':{'workflows.modDate':-1}}");
		}
		if(!executeTotalCountFlag){
			applyServerSidePaging(uiGridRecordLimit, inputJsonObj, finalQueryBuilder);
		}
		finalQueryBuilder.append(" ]");

		List<BasicDBObject> query = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(finalQueryBuilder.toString().replace("[?]", "" + userGroupsList.toString())));
		//subLogger.debug("Grid Group Level query--> " + query);
		return query;
	}

	private void applyServerSidePaging(int uiGridRecordLimit, BasicDBObject inputJsonObj,
			StringBuilder finalQueryBuilder) {

		Integer skipCount = null;
		if (inputJsonObj != null) {
			Integer pageNum = GenericUtility.convertLongToIntFromBSON(inputJsonObj.get("pageNum"));
			Integer pageSize = GenericUtility.convertLongToIntFromBSON(inputJsonObj.get("pageSize"));

			if (null != pageNum && null != pageSize && pageNum > 0 && pageSize > 0) {
				skipCount = pageSize * (pageNum - 1);
			}
			if (skipCount != null && skipCount >= 0) {
				finalQueryBuilder.append(" , ").append("{ $skip : " + skipCount + "}").append(" , ")
						.append("{ $limit : " + pageSize + "}");
			}
			// Limit as per View Config-- Regular flow without server side paging details from UI
			else if (uiGridRecordLimit != 0) {
				finalQueryBuilder.append(" , ").append("{ $limit : " + uiGridRecordLimit + "}");
			}
		} else if (uiGridRecordLimit != 0) {
			//Regular flow without request
			finalQueryBuilder.append(" , ").append("{ $limit : " + uiGridRecordLimit + "}");
		}

	}

	
	private String getGroupLevelBaseQuery(String viewType, boolean versionUserFilter, DBObject userCriteria, String soeid, boolean isQMA2Origin,BasicDBObject inputJsonObj1) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead
	// of using a generic one
	{
		String query = null;
		if (isQMA2Origin && INBOX.equals(viewType) && !versionUserFilter && SymphonyDAO.getInstance().isCombinedViewRequired(viewType, soeid))
		{
			//subLogger.info("Symphony:: inside getGroupLevelBaseQuery for Combined view query");
			query = FINAL_VERSION_LEVEL_BASE_QUERY_COMBINED_VIEW;
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			// Rules Filter for Inbox
			String ruleInboxFilter = ",{$match:{'workflows.rulesFlag':{'$exists':false},'workflows.snoozeAction': {$exists:false}}}";
			versionBaseMatch = versionBaseMatch + ruleInboxFilter;
			String filterCriteria = ","+ COMBINED_VIEW_FILTER_CRITERIA;
			versionBaseMatch = versionBaseMatch + filterCriteria;
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
			query = query.replaceAll("#SOEID", soeid);
			//subLogger.info("Symphony:: replace soeid in combined view filter criteria");
		}
		else if ("ChatView".equals(viewType))
		{
			//subLogger.info("Symphony:: inside getGroupLevelBaseQuery for chat view query");
			query = FINAL_VERSION_LEVEL_BASE_QUERY_COMBINED_VIEW;
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			// Rules Filter for Inbox
			String ruleInboxFilter = ",{$match:{'workflows.rulesFlag':{'$exists':false},'workflows.snoozeAction': {$exists:false}, 'isSymphonyChatroom':'Y'}}";
			versionBaseMatch = versionBaseMatch + ruleInboxFilter;
			String filterCriteria = ","+ COMBINED_VIEW_FILTER_CRITERIA;
			versionBaseMatch = versionBaseMatch + filterCriteria;
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
			query = query.replaceAll("#SOEID", soeid);
			//subLogger.info("Symphony:: replace soeid in combined view filter criteria");
		}
		else if (INBOX.equals(viewType))
		{
			query = FINAL_VERSION_LEVEL_BASE_QUERY;
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			// Rules Filter for Inbox
			String ruleInboxFilter = ",{$match:{'workflows.rulesFlag':{'$exists':false},'workflows.snoozeAction': {$exists:false}}}";
			versionBaseMatch = versionBaseMatch + ruleInboxFilter;

			// Below Code is used for any version level filter like assignToUser/UnAssignToUser Box Widget
			if (versionUserFilter && userCriteria != null)
			{
				String userCriteriaMatch = CRITERIA_MATCH_STR + userCriteria.toString() + "}";
				versionBaseMatch = versionBaseMatch + userCriteriaMatch;
			}
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
		}
		
		else if ("Outbox".equals(viewType))
		{
			query = FINAL_VERSION_LEVEL_BASE_QUERY;

			// [C153176-169] - Server-side export of inquiries
			// In case of isRetrieveAll, defaultCritria/criteria is applied for Saved Search to filter out valid versions
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			// Covert to OUTBox Match Query
			versionBaseMatch = versionBaseMatch.replace("'workflows.direction' : 'IN'", "'workflows.direction' : 'OUT'");
			// C153176-368-Resolved Inquiry Cannot be found with OUT version
			versionBaseMatch = versionBaseMatch.replace("'workflows.status' : 'Open' ,", "");
			if (versionUserFilter && userCriteria != null)
			{
				String userCriteriaMatch = CRITERIA_MATCH_STR + userCriteria.toString() + "}";
				versionBaseMatch = versionBaseMatch + userCriteriaMatch;
			}

			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
		}
		else if (RESOLVED.equals(viewType))
		{
			query = FINAL_VERSION_LEVEL_BASE_QUERY;

			// [C153176-169] - Server-side export of inquiries
			// In case of isRetrieveAll, defaultCritria/criteria is applied for Saved Search to filter out valid versions
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			// Convert to resolved Box Match
			versionBaseMatch = versionBaseMatch.replace("'workflows.status' : 'Open'", "'workflows.status' : 'Resolved'");

			if (versionUserFilter && userCriteria != null)
			{
				String userCriteriaMatch = CRITERIA_MATCH_STR + userCriteria.toString() + "}";
				versionBaseMatch = versionBaseMatch + userCriteriaMatch;
			}

			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
		}
		else if (DEFAULT_VIEW_TYPE_NON_INQUIRY.equals(viewType))
		{
			query = FINAL_VERSION_LEVEL_BASE_QUERY;
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			// Below Code is used for version level filter -markNonInquiry Match
			String ruleDelBoxFilter = ",{$match:{'workflows.rulesFlag.markAsNonInquiry':true}}";
			versionBaseMatch = versionBaseMatch + ruleDelBoxFilter;
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
		}
		else if (DEFAULT_VIEW_TYPE_DEL_INQUIRY.equals(viewType))
		{
			query = FINAL_VERSION_LEVEL_BASE_QUERY;
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			// Below Code is used for version level filter -delCriteriaMatch
			String ruleDelBoxFilter = ",{$match:{'workflows.rulesFlag.markForDeletion':true}}";
			versionBaseMatch = versionBaseMatch + ruleDelBoxFilter;
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
		}
		else if (DEFAULT_VIEW_TYPE_PENDING_APPROVAL.equals(viewType))
		{
			query = FINAL_VERSION_LEVEL_BASE_QUERY;
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			String ruleInboxFilter = ",{$match:{'workflows.rulesFlag':{'$exists':false},'workflows.snoozeAction': {$exists:false}}}";
			versionBaseMatch = versionBaseMatch + ruleInboxFilter;
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
			// Convert to Pending resolve
			query = query.replace("'workflows.direction' : 'IN'", "'workflows.direction' : { '$in\' :['PENDINGAPPROVAL','PND_REAGE','NOMINATE_OWNERSHIP']}");
		}
		else if (DEFAULT_VIEW_TYPE_ESCALATION.equals(viewType))
		{
			query = FINAL_VERSION_LEVEL_BASE_QUERY;
			//Convert to Escalation Box Criteria
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			versionBaseMatch = versionBaseMatch.replace("'workflows.direction' : 'IN'", "'workflows.direction' : { '$in\' :['IN','PENDINGAPPROVAL','PND_REAGE','NOMINATE_OWNERSHIP']}");
			String ruleInboxFilter = ",{$match:{'workflows.rulesFlag':{'$exists':false}}}";

			String escalationMatchQuery = ESCALATION_MATCH_QUERY;
			//[C153176-1302] - Create left-hand sub-menu items for Escalation
			if(userCriteria!=null)
			{
				escalationMatchQuery = WORKFLOW_MATCH.replace("MATCH_FIELD", (String)userCriteria.get("viewFilterField")).replace("MATCH_VALUE", (String)userCriteria.get("viewFilterValue"));
				//Adding direction to match query, if specified
				if(userCriteria.get("viewFilterDirection")!=null)
				{
					escalationMatchQuery = escalationMatchQuery + "," + WORKFLOW_MATCH.replace("MATCH_FIELD", "direction").replace("MATCH_VALUE", (String)userCriteria.get("viewFilterDirection"));
				}
				escalationMatchQuery = ",{$match:{" + escalationMatchQuery + "}}";
			}

			versionBaseMatch = versionBaseMatch + ruleInboxFilter + escalationMatchQuery;
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);		
		}
		else if (GLOBAL_GRID_VIEW_TYPE.equals(viewType))
		{
			// No Base Match Query required-It will be used for Solr Search and Folder as per corresponding user based filter criteria
			query = FINAL_VERSION_LEVEL_BASE_QUERY;
			String versionBaseMatch ="";
			if(null!=inputJsonObj1 && INTENSITY_HEAT_MAP.equalsIgnoreCase(inputJsonObj1.getString("viewName"))) {
				versionBaseMatch = VERSION_BOX_MATCH_QUERY_INTENSITY;
				String ruleInboxFilter1 = ",{$match:{'workflows.rulesFlag':{'$exists':false}}}";
				versionBaseMatch = versionBaseMatch + ruleInboxFilter1;
				
			}
		

			// [C153176-169] - Server-side export of inquiries
			// Applying version match criteria after unwinding workflows, for inquiry export
			if (versionUserFilter && userCriteria != null)
			{
				String versionMatchCriteria = CRITERIA_MATCH_STR + userCriteria.toString() + "}";
				if(null != inputJsonObj1 && INBOX.equals((String)inputJsonObj1.get(VIEW_NAME)) && MICRO_UI.equals((String)inputJsonObj1.get(VIEW_DATA_TYPE))) {
					versionMatchCriteria = versionMatchCriteria.replaceAll("\"workflows.status\": \"Open\",", "");
					String ruleInboxFilter = ",{$match:{'workflows.rulesFlag':{'$exists':false},'workflows.snoozeAction': {$exists:false}}}";
					versionMatchCriteria = versionMatchCriteria + ruleInboxFilter;
				}
				
				if(null!=inputJsonObj1 && INTENSITY_HEAT_MAP.equalsIgnoreCase(inputJsonObj1.getString("viewName"))) {
					//For only Priority inbox search view, customize query to match priority flag, count
					query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
				}else {
					//Global search view criteria for all regular search views and brazil fx, advanced search
					query = query.replace(VERSION_MATCH_QRY_STR, versionMatchCriteria);
				}
				
			}
			query = query.replace(VERSION_MATCH_QRY_STR, "");

		}

		else if (FOLLOWUP.equals(viewType))
		{
			query = FINAL_VERSION_LEVEL_BASE_QUERY;
			//Convert to Follow Box Criteria
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			String ruleInboxFilter = ",{$match:{'workflows.rulesFlag':{'$exists':false}}}";
			versionBaseMatch = versionBaseMatch + ruleInboxFilter + FOLLOWUP_MATCH_QUERY;
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
			query = query.replace(", 'workflows.direction' : 'IN'", "");
		}
		else if (DEFAULT_VIEW_TYPE_SNOOZED.equals(viewType))
		{
			query = FINAL_VERSION_LEVEL_BASE_QUERY;
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			// Rules Filter for Inbox
			String ruleInboxFilter = ",{$match:{'workflows.rulesFlag':{'$exists':false},'workflows.snoozeAction': 'Snooze'}}";
			versionBaseMatch = versionBaseMatch + ruleInboxFilter;

			// Below Code is used for any version level filter like assignToUser/UnAssignToUser Box Widget
			if (versionUserFilter && userCriteria != null)
			{
				String userCriteriaMatch = CRITERIA_MATCH_STR + userCriteria.toString() + "}";
				versionBaseMatch = versionBaseMatch + userCriteriaMatch;
			}
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
		}
		//below code is added to form query for Open inquiries by request type data for QMA2
		else if (OPEN_INQUIRIES_BY_REQUEST_TYPE.equals(viewType))
		{
			query = FINAL_VERSION_LEVEL_BASE_QUERY;
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			// Rules Filter for Inbox
			String ruleInboxFilter = ",{$match:{'workflows.rulesFlag':{'$exists':false},'workflows.snoozeAction': {$exists:false}}}";
			versionBaseMatch = versionBaseMatch + ruleInboxFilter + ",{$match:{'workflows.requestType':#reqType#}}";

			// Below Code is used for any version level filter like assignToUser/UnAssignToUser Box Widget
			if (versionUserFilter && userCriteria != null)
			{
				String userCriteriaMatch = CRITERIA_MATCH_STR + userCriteria.toString() + "}";
				versionBaseMatch = versionBaseMatch + userCriteriaMatch;
			}
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
		}
		//below code is added to form query for Open inquiries by assigned owner data for QMA2
		else if (OPEN_INQUIRIES_BY_ASSIGNED_OWNERS.equals(viewType))
		{
			query = FINAL_VERSION_LEVEL_BASE_QUERY;
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			// Rules Filter for Inbox
			String ruleInboxFilter = ",{$match:{'workflows.rulesFlag':{'$exists':false},'workflows.snoozeAction': {$exists:false}}}";
			versionBaseMatch = versionBaseMatch + ruleInboxFilter + ",{$match:{'workflows.assignedUserId':#assignedUserId#}}";

			// Below Code is used for any version level filter like assignToUser/UnAssignToUser Box Widget
			if (versionUserFilter && userCriteria != null)
			{
				String userCriteriaMatch = CRITERIA_MATCH_STR + userCriteria.toString() + "}";
				versionBaseMatch = versionBaseMatch + userCriteriaMatch;
			}
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
		}
		//below code is added to form query for tag search data for QMA1 and QMA2
		else if (TAG_VIEW.equals(viewType))
		{
			query = FINAL_VERSION_LEVEL_BASE_QUERY;

			// Rules Filter for Inbox
			String versionBaseMatch = ",{$match:{'workflows.tag':#tagName#,'workflows.assignedGroupId' : { '$in' : [?]}}}";
			
			if (versionUserFilter && userCriteria != null)
			{
				String versionMatchCriteria = CRITERIA_MATCH_STR + userCriteria.toString() + "}";
				
				query = query.replace(VERSION_MATCH_QRY_STR, versionMatchCriteria);
			}
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);

		}else if (DEFAULT_VIEW_TYPE_FYI.equals(viewType))
		{
			query = FINAL_VERSION_LEVEL_BASE_QUERY;
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			// Below Code is used for version level filter -'rulesFlag.ruleType':"autoAssignmentRule"
			String ruleDelBoxFilter = ",{$match:{'workflows.rulesFlag.ruleType':'autoAssignmentRule'}}";
			versionBaseMatch = versionBaseMatch + ruleDelBoxFilter;
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
		}else if (DEFAULT_VIEW_TYPE_PERSONAL_MAIL.equals(viewType)) {
			query = FINAL_VERSION_LEVEL_BASE_QUERY;
			String versionBaseMatch = VERSION_BOX_MATCH_QUERY;
			// Below Code is used for version level filter -'rulesFlag.ruleType':"autoAssignmentRule"
			String ruleDelBoxFilter = ",{$match:{'workflows.personalFolders':{'$exists':true},'workflows.personalFolders':{'$in':[#personalFolderName#]}}}";
			versionBaseMatch = versionBaseMatch + ruleDelBoxFilter;
			query = query.replace(VERSION_MATCH_QRY_STR, versionBaseMatch);
		}
		else
		{
			throw new CommunicatorException("Invalid view type for Version Level grid view Data.");
		}
		return query;
	}

	// Method to get Group or Inquiry Level View based on User Preference
	Boolean isGroupLevelGridView(String soeId)
	{
		// Default Group Level View
		Boolean isGroupLevelView = true;

		/*
		 * Switch Off User Preference based Grid View. if (UserDAO.getUserProfileMap() == null|| UserDAO.getUserProfileMap().get(soeId) ==null ||
		 * UserDAO.getUserProfileMap().get(soeId).getPreferences() ==null) { subLogger.info("isGroupLevelGridView- User Profile Not Found for soeId= " +
		 * soeId+" , so switching back to Inquiry Level View."); } else { UserTO userProfileInfo = UserDAO.getUserProfileMap().get(soeId); List<Preference> userPreferencList =
		 * userProfileInfo.getPreferences(); for (Preference pref : userPreferencList) { if ("groupLevelViewId".equals(pref.key) && "N".equals(pref.value)) { //Inquiry Level View isGroupLevelView =
		 * false; break; } } }
		 */
		subLogger.info("isGroupLevelGridView = " + isGroupLevelView + " for user " + soeId);
		return isGroupLevelView;
	}

	// Method to get User's Custom ColumnDef for Default Views
	private List<ColumnDef> getDefaultBoxUserColDef(String soeId, String viewName) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		List<ColumnDef> userViewColumnDefs = null;
		if (UserDAO.getUserProfileMap() == null || UserDAO.getUserProfileMap().get(soeId) == null || UserDAO.getUserProfileMap().get(soeId).getViewColumnDefs() == null)
		{
			// Custom Column Def Not Found, So It will use master column def to show Grid columns in the UI.
			subLogger.info("getDefaultBoxUserColDef- User's Custom Column Def Not Found in User Profile  for soeId= " + soeId);
		}
		else
		{
			UserTO userProfileInfo = UserDAO.getUserProfileMap().get(soeId);
			// This will loop for Inbox/OutBox/Resolved/Pending Approval Default Views
			for (ViewConfig userViewConfig : userProfileInfo.getViewColumnDefs())
			{
				if (userViewConfig.getViewName().equals(viewName))
				{
					// Take null value for ColumnDefs if its empty or null
					userViewColumnDefs = (userViewConfig.getColumnsToShow() != null && !userViewConfig.getColumnsToShow().isEmpty()) ? userViewConfig.getColumnsToShow() : null;
					break;
				}
			}
		}
		return userViewColumnDefs;
	}

	// fetch previousmodifiedTime i.e. previousActionTime . we are not making any explicit DB queries for the stats, so no secondary read .
	// C153176-154-ActionStatistics Improvements
	// Chnages to make it generic and used it to fetch different direction workflow.
	private Workflow getLastModifiedWorkflow(List<Workflow> workflowList, Long groupId, String direction)
	{
		Workflow lastModifiedWorkflow = null;
		if (workflowList != null)
		{
			for (Workflow workflow : workflowList)
			{
				if (null != groupId && null != workflow.getAssignedGroupId() && groupId.equals(workflow.getAssignedGroupId()))
				{
					lastModifiedWorkflow = workflow;
					if (null != direction && direction.equals(workflow.getDirection()))
					{
						return lastModifiedWorkflow;
					}
				}
			}
		}
		return lastModifiedWorkflow;
	}

	/**
	 * @param soeId
	 * @param action
	 * @param currentTime
	 * @param inquiry
	 * @param assignToGroupId
	 * @param userInfoMap 
	 * @param groupIdToNameMap 
	 * @param inquiryObjs
	 * @return
	 * @throws CommunicatorException
	 * Update the Action Statistics collection.
	 */
	private DBObject getStatsObject(String soeId, String action,Date currentTime, Inquiry inquiry, Long assignToGroupId, boolean isBulkAction, ActionStatistics actstatsObj, Map<Long, String> groupIdToNameMap, Map<String, User> userInfoMap) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one 
	{

		DBObject stats = new BasicDBObject();
		String assignedUserName = null;
		stats.put(INQUIRY_ID, inquiry.id);
		stats.put(USER_ID, soeId);
		String userName = "";
		User user = userInfoMap.get(soeId.toUpperCase());
		if(null != user) {
			stats.put("emailId", user.getEmail());
		}
		userName = GenericUtility.getUserOrSystemName(soeId, userInfoMap);
		stats.put("userName", userName);
		

		stats.put(GROUP_ID, assignToGroupId);
		stats.put(GROUP_NAME, groupIdToNameMap.get(assignToGroupId));
		//Request type, Subject, Assigned user - C153176-1054
		//stats.put(REQUEST_TYPE, actstatsObj);

		stats.put(SUBJECT, inquiry.getSubject());
		stats.put("assignedUserName", inquiry.getLatestUserName());
		if (null != inquiry.getWorkflows()){
			Workflow inWorkFlow=getWorkflow(inquiry.getWorkflows(), assignToGroupId, INQUIRY_DIRECTION_IN);
			if(null != inWorkFlow && null != inWorkFlow.getAssignedGroupName())
			{
				assignedUserName = inquiry.getLatestUserName() + " (" +soeId + ")[" + inWorkFlow.getAssignedGroupName() + "]";
				stats.put("assignedUserName", assignedUserName);
			}
		}
		if(isBulkAction )
		{
			stats.put("isBulkAction","Y");
		}
		if(ACTION_NEW.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_NEW);
		else if(ACTION_REPLY_RESOLVE.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_REPLY_RESOLVE);
		else if(ACTION_REPLYALL_RESOLVE.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_REPLYALL_RESOLVE);
		else if(ACTION_RESOLVE.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_RESOLVE);
		else if(ACTION_ASSIGN_TAG.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_ASSIGN_TAG);
		else if(ACTION_TAKE_OWNERSHIP.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_TAKE_OWNERSHIP);
		else if(ACTION_ACKNOWLEDGE_ESCALATION.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_ACKNOWLEDGE_ESCALATION);
		else
			stats.put(ACTION, action);

		stats.put("actionTime", currentTime);

		if(null!=actstatsObj)
		{
			setParamForActionStastics(actstatsObj, stats);
		}

		Workflow lastModifiedWorkflow = getLastModifiedWorkflow(inquiry.getWorkflows(), assignToGroupId,INQUIRY_DIRECTION_IN);
		String isLastConvToExtEmail = null;
		if(lastModifiedWorkflow != null)
		{
			stats.put("createdTime", lastModifiedWorkflow.getCrtDate());
			stats.put("lastModifiedTime", lastModifiedWorkflow.getModDate());
			// C153176-5653 :  QMA should not measure time between Citiâ€™s response to client with 2 x consecutive e-mails as Response time
			boolean resolveAction = action.equals(ACTION_REPLY_RESOLVE) || action.equals(ACTION_REPLYALL_RESOLVE) || action.equals(ACTION_RESOLVE);
			isLastConvToExtEmail = null != lastModifiedWorkflow.getIsLastConvToExtEmail() ?  lastModifiedWorkflow.getIsLastConvToExtEmail() : "N";
			if (!ACTION_RESOLVE.equalsIgnoreCase(action)) {
			stats.put("responseTime", (currentTime.getTime() - lastModifiedWorkflow.getModDate().getTime())/60000);
			}
			
			if (resolveAction) {
				Date lastModifiedTime = (Date) stats.get("lastModifiedTime");
				Date createdTime = (Date) stats.get("createdTime");

				stats.put("resolveTimeSinceLastResponse",(currentTime.getTime() - lastModifiedTime.getTime())/60000);
				stats.put("resolveTimeSinceCreation",(currentTime.getTime() - createdTime.getTime())/60000);
			}
			if (action.equals(ACTION_REPLY) || action.equals(ACTION_REPLY_ALL) || action.equals(ACTION_REPLY_RESOLVE) || action.equals(ACTION_REPLYALL_RESOLVE) || action.equals(ACTION_RESOLVE))
			{
				if(null != lastModifiedWorkflow.getIsClientChaseEscalation() && "Y".equalsIgnoreCase(lastModifiedWorkflow.getIsClientChaseEscalation())) {
					stats.put("isResponseToClientChaser", lastModifiedWorkflow.getIsClientChaseEscalation());
				}
			}
		}

		// C153176-5653 | Update the response time with first client email of consecutive email.
		this.updateResponseTimeInStatistics(currentTime, inquiry.getWorkflows(), assignToGroupId, stats);
		
		// C153176-5882 | Response time not captured for ReplyResolve action
		// We would not consider response for action activities when CITI replied consecutively and action is Reply Resolve or Reply All Resolve
		if((ACTION_REPLY_RESOLVE.equalsIgnoreCase(action) 
			|| ACTION_REPLYALL_RESOLVE.equalsIgnoreCase(action)
			|| ACTION_REPLY.equalsIgnoreCase(action)
			|| ACTION_REPLY_ALL.equalsIgnoreCase(action))) {
			if(null == stats.get("responseTimeInMinutes") && null != lastModifiedWorkflow) {//<-- sonar fix null pointer
				long responseTimeInMinutes = calculateResponseTimeWrkShiftBased(currentTime, lastModifiedWorkflow.getModDate(),assignToGroupId);
				stats.put("responseTimeInMinutes", responseTimeInMinutes);
			}
			if("Y".equalsIgnoreCase(isLastConvToExtEmail)) {
				stats.removeField("responseTime");
				stats.removeField("responseTimeInMinutes");
			}
		}
		
		if("Y".equalsIgnoreCase(inquiry.getIsTaskizeInquiry())){
			if(StringUtils.isNotEmpty(inquiry.getBubbleId())) {
				stats.put("bubbleId", inquiry.getBubbleId());
				stats.put("isTaskizeInquiry",inquiry.getIsTaskizeInquiry());
			}
			if(StringUtils.isNotEmpty(inquiry.getTaskizeInquiryId())) {
				stats.put("taskizeInquiryId", inquiry.getTaskizeInquiryId());
			}
		}
		
		return stats;
	}

	/**
	 * @param actstatsObj
	 * @param stats
	 * Update the Status of Each action on ActionStatistics Collection
	 * 
	 */
	private void setParamForActionStastics(ActionStatistics actstatsObj, DBObject stats) {

		if (null != actstatsObj.getRequestType()){
			stats.put(REQUEST_TYPE, actstatsObj.getRequestType());
		}

		if (null != actstatsObj.getTag()){
			stats.put("tag", actstatsObj.getTag());
		}

		if (null != actstatsObj.getInquirySource()){
			stats.put("inquirySource", actstatsObj.getInquirySource());
		}

		if (null != actstatsObj.getProcessingRegion()){
			stats.put("processingRegion", actstatsObj.getProcessingRegion());
		}

		if (null != actstatsObj.getGpNum()){
			stats.put("gpNum", actstatsObj.getGpNum());
		}

		if (null != actstatsObj.getGpName()){
			stats.put("gpName", actstatsObj.getGpName());
		}

		if (null != actstatsObj.getGfcid()){
			stats.put("gfcid", actstatsObj.getGfcid());
		}

		if (null != actstatsObj.getGfcName()){
			stats.put("gfcName", actstatsObj.getGfcName());
		}
		if (null != actstatsObj.getRootCause()){
			stats.put("rootCause", actstatsObj.getRootCause());
		}
	}



	// Method to process Ext Email recipients and update to Sender's Group.
	private void updateExtEmailRecipients(Long fromGrpId, List<ConversationRecipient> convRecipientList) throws CommunicatorException
	{
		try
		{

			subLogger.info(" Inside updateExtEmailRecipients for Group Id= " + fromGrpId);

			if (convRecipientList == null)
			{
				return;
			}
			
			Set<String> groupExtEmailRecipients = new HashSet<String>();
			for (ConversationRecipient conversationRecipient : convRecipientList)
			{
				if (conversationRecipient.getToFrom().equalsIgnoreCase("TO"))
				{
					populateGrpExtRecipients(groupExtEmailRecipients, conversationRecipient);
				}
				else if (conversationRecipient.getToFrom().equalsIgnoreCase("CC"))
				{
					populateGrpExtRecipients(groupExtEmailRecipients, conversationRecipient);

				}
			}

			
			if (groupExtEmailRecipients != null && !groupExtEmailRecipients.isEmpty())
			{
				updateGroupExtRecipients(fromGrpId, groupExtEmailRecipients);
			}
		}
		catch (Exception e)
		{
			subLogger.error("Issue in updateExtEmailRecipients for fromGrpId=" + fromGrpId, e);
			// throw new CommunicatorException("Issue in updateExtEmailRecipients for fromGrpId=" + fromGrpId, e);
		}
	}

	private void populateGrpExtRecipients(Set<String> groupExtEmailRecipients, ConversationRecipient conversationRecipient)
	{
		String email = conversationRecipient.getEmailAddr();
		// First Check for Non Internal Group Email Address
		if (email != null )// Sonar Fix -- merge if statement
		{
			
			groupExtEmailRecipients.add(email.trim());
			
		}
	}

	/* Method to update external recipients of Group */
	private Boolean updateGroupExtRecipients(Long fromGroupId, Set<String> newExtRecipientList) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a
	// generic one
	{
		Boolean bSuccess = false;
		try
		{
			if (newExtRecipientList == null || newExtRecipientList.isEmpty())
			{
				return bSuccess;
			}
			Query<Group> query = mongoDatastore.createQuery(Group.class);
			query.criteria("id").equal(fromGroupId);
			Group group = query.get();
			if (group != null)
			{
				List<String> groupRecipients = group.getRecipients();
				ArrayList<String> groupRecipientsNew = new ArrayList<>();
				// check if new external recipients added  
				boolean isNewExternalRecipients=false;
				
				if (groupRecipients != null)
				{
					// check if new external recipients added  
					for(String rec:newExtRecipientList){
						if(!groupRecipients.contains(rec)) {
							isNewExternalRecipients = true;
							break;
						}
					}
					// add in group collection only if there is new external contact
					if(isNewExternalRecipients) {
						newExtRecipientList.addAll(groupRecipients);
					}
				}// [C170665-4319] Unable to add users / create rules while DLs are in use
				if(isNewExternalRecipients) { // add in group collection only if there is new external contact
				groupRecipientsNew.addAll(newExtRecipientList);
				group.setRecipients(groupRecipientsNew);
				mongoDatastore.save(group);
				//updateGroupExtRecipients
				HazelCastCacheIncrementalLoad.refreshGroupInCache(group.getId());
				bSuccess = true;
				}

			}

		}
		catch (Exception e)
		{
			subLogger.error(" Issue in setting External recipients for Group id:  " + fromGroupId, e);
			throw new CommunicatorException(" Issue in setting External recipients for Group id: " + fromGroupId, e);
		}
		return bSuccess;
	}

	// Method to Create Draft
	private Draft createNewDraft(BasicDBObject inputJsonObj, String content, String soeId, Date currentTime) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead
	// of using a generic one
	{

		Draft draft = new Draft();
		draft.setCrtBy(soeId);
		draft.setCrtDate(currentTime);

		// Update All other attribute from Ui request
		updateDraftAttributesFromUi(inputJsonObj, draft, content, soeId, currentTime);
		return draft;
	}

	// Method to update Draft fields based on UI request
	private void updateDraftAttributesFromUi(BasicDBObject inputJsonObj, Draft draft, String content, String soeId, Date currentTime) throws CommunicatorException// Sonar Fix -- Define and throw a
	// dedicated exception instead of
	// using a generic one
	{

		// Create or override recipients based on UI Input
		List<ConversationRecipient> draftRecipients = createRecipients(inputJsonObj, soeId);
		draft.setRecipients(draftRecipients);

		String urgentFlag = inputJsonObj.getString(URGENT_FLAG);
		boolean makerCheckerRqd = inputJsonObj.getBoolean(MAKER_CHECKER_REQUIRED);
		String requestType = inputJsonObj.getString(REQUEST_TYPE);
		String processingRegion = inputJsonObj.getString(PROCESSING_REGION);
		String inquirySource = inputJsonObj.getString(INQUIRY_SOURCE);
		String inquirySubStatus = inputJsonObj.getString("inquirySubStatus");
		String rootCause = inputJsonObj.getString(ROOT_CAUSE);	//[C153176-959]-When a saved draft is opened the From and Root cause field are not carried back to the screen.
		String gfpid = inputJsonObj.getString(GFPID);
		String gfcid = inputJsonObj.getString(GFCID);
		String gfpName = inputJsonObj.getString("GFPIDName");
		String gfcName = inputJsonObj.getString("GFCIDName");
		String action;
		if(null != inputJsonObj.getString(ACTION)){
			action = inputJsonObj.getString(ACTION);
			draft.setAction(action);
		}
		Date scheduleForLater;
		if(null != inputJsonObj.getString(SCHEDULE_FOR_LATER)){
			scheduleForLater = parseDate(inputJsonObj.getString(SCHEDULE_FOR_LATER),SCHEDULE_FOR_LATER_DATE_FORMAT);
			draft.setScheduleForLater(scheduleForLater);
		}
		
		if(inputJsonObj.getBoolean("isCancelled")){
			draft.setScheduleForLater(null);
		}

		String cntn = content;// Sonar Fix -- Introduce a new variable instead of reusing the parameter

		draft.setSubject(inputJsonObj.getString(SUBJECT));
		// Inline Images within draft
		cntn = GenericUtility.updateContentWithImages(cntn, soeId);

		draft.setContent(cntn);
		draft.setUrgentFlag(urgentFlag);

		// Attachments
		draft.setAttachments(getAttachmentsInfo(inputJsonObj));

		// attchFlag
		if (draft.getAttachments() != null && !draft.getAttachments().isEmpty())
		{
			draft.setAttchFlag("Y");
		}

		if (makerCheckerRqd)
		{
			String approvalBypassed = inputJsonObj.getString(APPROVAL_BYPASSED);
			draft.setApprovalBypassed(approvalBypassed);
			draft.setMakerCheckerRqd(makerCheckerRqd);
		}

		draft.setModBy(soeId);
		draft.setModDate(currentTime);
		draft.setUserId(soeId);
		draft.setRequestType(requestType);
		draft.setProcessingRegion(processingRegion);
		draft.setRootCause(rootCause);//[C153176-959]-When a saved draft is opened the From and Root cause field are not carried back to the screen.
		
		if (!StringUtils.isBlank(inputJsonObj.getString(QUERY_COUNT)))
		{
			draft.setQueryCount(Long.parseLong(inputJsonObj.getString(QUERY_COUNT)));
		}
		if (!StringUtils.isBlank(inquirySource))
		{
			draft.setInquirySource(inquirySource);
		}
		
		if (!StringUtils.isBlank(gfpid))
		{
			draft.setGfpid(gfpid);
			draft.setGfpName(gfpName);
		}
		if (!StringUtils.isBlank(gfcid))
		{
			draft.setGfcid(gfcid);
			draft.setGfcName(gfcName);
		}

		
		Long inquiryId = GenericUtility.getIdFromRequest(inputJsonObj, INQUIRY_ID);
		draft.setInquiryId(inquiryId);

		User loginUser = getUser(soeId);
		@SuppressWarnings("unchecked")
		List<String> userNotes = (List<String>) inputJsonObj.get("notes");
		if(userNotes != null && !userNotes.isEmpty() && loginUser !=null){
			addNotesToDraft(soeId, loginUser.getName(), userNotes, draft);
		}
		
		// C170665-5 | Add Account Number and Branch to Inquiry.
		if (null != inputJsonObj.get("skAccountNo") && !StringUtils.isBlank(inputJsonObj.getString("skAccountNo"))) {
			draft.setSkAccountNo(inputJsonObj.getString("skAccountNo"));
			draft.setBranch(inputJsonObj.getString("branch"));
		}
		
		//added from GroupId to get schedule for later inquiries at group level
		addFromGroupIdToDraft(draft, draftRecipients);
		//DCC- Draft inquiry sub status
		if (!StringUtils.isBlank(inquirySubStatus) && isInquirySubStatusEnabled(draft.getFromGroupId()))
		{
			draft.setInquirySubStatus(inquirySubStatus);
		}
		
		//C170665-3228: Save Draft for Reply
		if (!StringUtils.isBlank(inputJsonObj.getString(LINKED_INQUIRY_ID)))
		{
			draft.setLinkedInquiryId(Long.parseLong(inputJsonObj.getString(LINKED_INQUIRY_ID)));
		}
		if (!StringUtils.isBlank(inputJsonObj.getString(DRAFT_INQUIRY_ACTION)))
		{
			draft.setDraftInquiryAction(inputJsonObj.getString(DRAFT_INQUIRY_ACTION));
		}
		
	}

	/** This method will add fromGroupId to draft for scheduleForLater functionality
	 * @param draft
	 * @param draftRecipients
	 */
	private void addFromGroupIdToDraft(Draft draft, List<ConversationRecipient> draftRecipients) {
		try {
			for(ConversationRecipient conversationRecipient : draftRecipients){
				if(null != conversationRecipient.getToFrom() && "FROM".equalsIgnoreCase(conversationRecipient.getToFrom()) && null != conversationRecipient.getGroupId()){
					draft.setFromGroupId(conversationRecipient.getGroupId());
					break;
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception while adding fromGroupId in addFromGroupIdToDraft for draft id : "+ draft.getId(), e);
		}
	}

	/**
	 * @param inputDate
	 * @param scheduleForLaterDateFormat
	 * @return
	 * @throws CommunicatorException
	 */
	private Date parseDate(String inputDate, String scheduleForLaterDateFormat) throws CommunicatorException {
		Date date = null;
		try {
			if (null != inputDate) {
				SimpleDateFormat sdf = new SimpleDateFormat(scheduleForLaterDateFormat, Locale.ENGLISH);
				date = sdf.parse(inputDate);
			}
		} catch (Exception e) {
			subLogger.error("Exception while parsing scheduleForLater",e);
			throw new CommunicatorException("Exception while parsing scheduleForLater",e);
		}
		return date;
	}

	private Draft getDraft(Long draftId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Query<Draft> query = null;

		query = mongoDatastore.createQuery(Draft.class);

		query.criteria("_id").equal(draftId);

		Draft draft = query.get();
		return draft;
	}

	private void deleteDrafts(BasicDBObject inputJsonObj, String soeId) throws CommunicatorException
	{
		Long draftId = null;
		try
		{
			draftId = GenericUtility.getIdFromRequest(inputJsonObj, "draftId");
			subLogger.info("deleteDrafts for Id= " + draftId);
			if (draftId != null)
			{
				ArrayList<Long> draftIds = new ArrayList<>();
				draftIds.add(draftId);
				deleteDraftById(soeId, draftIds);
			}
		}
		catch (Exception e)
		{
			subLogger.error(" Issue in deleteDrafts for draftId:  " + draftId, e);
			// Error is consumed as it is called from new inquiry flow
			throw new CommunicatorException(" Issue in deleteDrafts for draftId:  " + draftId, e);
		}
	}

	// Release 1.5 Changes -Maker Checker Group Level Implementation start
	public boolean updatePendingGroupInquiry(String soeId, BasicDBObject inputJsonObj, UserActivities userActivity) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		boolean bSuccess = Boolean.FALSE;
		try
		{
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			String groupName = inputJsonObj.getString(ASSIGNED_GROUP_NAME);
			List<Inquiry> inquiryObjs = getInquiryList(inquiryIds);

			String action = inputJsonObj.getString(ACTION);
			Long groupId = null;
			String type = inputJsonObj.getString("type");
			String nominationRejectionReason = inputJsonObj.getString("nominationRejectionReason");

			// GroupName null check
			if (!StringUtils.isBlank(groupName))
			{
				groupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
			}
			else
			{
				subLogger.info("Invalid Input for updatePendingInquiry  by " + soeId + " for group name " + groupName);
				throw new CommunicatorException("Invalid Data for groupName.");
			}
			if (inquiryObjs != null)
			{
				bSuccess = updatePendingGroupInquiry(soeId, inquiryObjs, action, groupId,type, nominationRejectionReason, userActivity);
			}


		}
		catch (Exception e)
		{
			subLogger.error("Exception in updatePendingInquiry for user= " + soeId, e);
			throw new CommunicatorException("Exception in updatePendingInquiry for user= " + soeId, e);
		}
		return bSuccess;
	}

	private Boolean updatePendingGroupInquiry(String soeId, List<Inquiry> inquiryObjs, String action, Long groupId, String type, String nominationRejectionReason, UserActivities userActivity) throws CommunicatorException// Sonar Fix -- Define and throw a
	{
		QMACache cache = QMACacheFactory.getCache();
		Map<Long, String> groupIdToNameMap = cache.getGroupIdToNameMap();
		Map<String, User> userInfoMap = cache.getUserInfoMap();
		for (Inquiry inqObj : inquiryObjs)
		{
			if (inqObj.getWorkflows() != null && !inqObj.getWorkflows().isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
			{
				if (ACTION_RE_AGE.equals(type))
				{
					updateReAgePendingGroupWorkflow(soeId, inqObj, groupId, action, groupIdToNameMap, userInfoMap);
				}
				else if (ACTION_APPROVE_RJ_EMAIL.equals(type) || StringUtils.isBlank(type))
				{
					//Default EMail approval
					updateEmailPendingGroupWorkflow(soeId, inqObj, groupId, action, userActivity, groupIdToNameMap, userInfoMap);
					ConversationCache.getInstance().removeEntriesWithKeySetIteration(inqObj.getId());
				} else if(ACTION_NOMINATE_OWNERSHIP.equalsIgnoreCase(type)){
					//update nominating and nominated workflow on approve/reject action
					InquiryExtendedDAO.getInstance().updateNominatedOwnershipWorkflow(soeId, inqObj, groupId, action, nominationRejectionReason, userActivity, cache);
				}
				//QMA-471 Starts - Accepting other group ownership if one of multiple is accepting by other nominated group.
				else if(NOMINATE_OTHER_OWNERSHIP.equalsIgnoreCase(type)){
					InquiryExtendedDAO.getInstance().updateNominatedOwnershipWorkflow(inqObj, groupId, action, nominationRejectionReason);
				}
				//QMA-471 Ends
			}
		}
		return Boolean.TRUE;

	}

	

	private void updateEmailPendingGroupWorkflow(String soeId, Inquiry inqObj, Long groupId, String action, UserActivities userActivity, Map<Long, String> groupIdToNameMap, Map<String, User> userInfoMap) throws CommunicatorException
	{
		String openGroups = inqObj.getOpenGroups();
		Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("id", inqObj.id);
		DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);

		Date currentTime = new Date();
		////Modified for requestType in Action Statistics - C153176-1155
		DBObject stats = getStatsObject(soeId, action, currentTime, inqObj, groupId, false, null, groupIdToNameMap, userInfoMap);
		Workflow pendingWorkflow = getWorkflow(inqObj.getWorkflows(), groupId, INQUIRY_DIRECTION_PENDING_APPROVAL);
		if (pendingWorkflow != null)
		{
			// C153176-154 ActionStatistics Improvements
			updateStats(inqObj.getWorkflows(), groupId, stats, INQUIRY_DIRECTION_PENDING_APPROVAL, null, inqObj.getSubject());
			String status = inqObj.getStatus();

			// Fix for - Reject an inquiry by approval doesnot set AssignGroup(TO Group STR) in the Inquiry Grid.
			if (ACTION_REJECT.equals(action))
			{

				emailRejectProcess(soeId, inqObj, groupId, action, openGroups, pendingWorkflow);
			}
			else
			{
				emailAproveProcess(soeId, inqObj, groupId, action,  pendingWorkflow);

				// C153176-1178 if all the workflows are resolved then resolve the inquiry. 
				//Do this check only for "approve" flow. Reject flow will always be Open, bcoz it opens up IN workflow for the selected group. 
				if (inqObj.getAction().equals(ACTION_NEW_RESOLVE))
				{
					status = changeOutVersionOfNewInquiry(inqObj, soeId);
				}
				else
				status = resolveInquiryFromPendingApprovalBox(inqObj);

			}
			
			createWorkflowAudit(soeId, inqObj, groupId, action, currentTime, groupIdToNameMap, userInfoMap);
			UpdateOperations<Inquiry> ops = mongoDatastore.createUpdateOperations(Inquiry.class).set(ACTION, action).set(STATUS, status).set(WORKFLOWS, inqObj.getWorkflows());
			ops = ops.set(WORKFLOW_AUDIT, inqObj.getWorkflowAudit());
			if (openGroups != null)
			{
				ops = ops.set(OPEN_GROUPS, openGroups);
			}
			if(inqObj.getApprovedExternalDomains()!=null)
			{
				ops = ops.set(APPROVED_EXTERNAL_DOMAINS,inqObj.getApprovedExternalDomains());
			} 
			mongoDatastore.update(query, ops);
			query = null;
			ops = null;
			subLogger.info("updatePendingInquiry for Inquiry =" + inqObj.id + " , fromGrp=" + groupId);

			statsCollection.save(stats);
			subLogger.info("ActionStatistics Saved for action 5" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
		}
		//Update Inquiry Audit for Sending Email
		String audFlag= ACTION_APPROVE.equals(action)?"N":"R";
		updateInquiryGroupAudit(inqObj, groupId, audFlag);

	}

	private String changeOutVersionOfNewInquiry(Inquiry inqObj, String soeId)
	{
		String status = inqObj.getStatus();

		// check - in , pending reage, pending approval workflows are resolved
		if (isAllWorkflowResolved(inqObj.getWorkflows()))
		{
			status = STATUS_RESOLVE;

			// if - in , pending reage, pending approval workflows are resolved
			// then resolve OUT workflows as well, if any.
		}
		List<Workflow> outWorkflowList = getWorkflowList(inqObj.getWorkflows(), INQUIRY_DIRECTION_OUT, STATUS_OPEN);

		if (null != outWorkflowList && !outWorkflowList.isEmpty())
		{
			Date currentTime = new Date();
			String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
			for (Workflow outworkflow : outWorkflowList)
			{
				outworkflow.setStatus(STATUS_RESOLVE);
				outworkflow.setFollowUp(null);
				outworkflow.setLastActionTime(currentTime);
				outworkflow.setResolveTime(currentTime);
				outworkflow.setResolver(userName);
				outworkflow.setLastActionby(userName);
			}
		}

		return status;
	}

	/**
	 * @param inqObj
	 * @return
	 * 
	 * C153176-1178 - if all the workflows(in, pending approval, pending reage) are resolved then resolve the inquiry. 
	 */
	private String resolveInquiryFromPendingApprovalBox(Inquiry inqObj)
	{

		String status = inqObj.getStatus();

		// check - in , pending reage, pending approval workflows are resolved 
		if(isAllWorkflowResolved(inqObj.getWorkflows()))
		{
			status = STATUS_RESOLVE;

			// if -  in , pending reage, pending approval workflows are resolved 
			// then resolve OUT workflows as well, if any.
			List<Workflow> outWorkflowList = getWorkflowList(inqObj.getWorkflows(), INQUIRY_DIRECTION_OUT, STATUS_OPEN);

			if(null!=outWorkflowList && !outWorkflowList.isEmpty())
			{
				for(Workflow outworkflow : outWorkflowList)
				{
					outworkflow.setStatus(STATUS_RESOLVE);
					outworkflow.setFollowUp(null);
				}
			}

		}

		return status;

	}

	private void createWorkflowAudit(String soeId, Inquiry inqObj, Long groupId, String action, Date currentTime, Map<Long, String> groupIdToNameMap, Map<String, User> userInfoMap)
	{
		// REQU0002243347: add the workflowAudit for Pending Inquiry Actions as per mail on April 12, 2016
		WorkflowAudit workflowAudit = new WorkflowAudit(action, action, groupId, soeId, currentTime, soeId);
		User user = userInfoMap.get(soeId.toUpperCase());
		if (user != null)
		{
			workflowAudit.setUserId(user.getName());
		}
		if (groupId != null)
		{
			workflowAudit.setGroupName(groupIdToNameMap.get(groupId));
		}

		if (inqObj.getWorkflowAudit() == null)
		{
			inqObj.setWorkflowAudit(new ArrayList<WorkflowAudit>());
		}
		inqObj.getWorkflowAudit().add(workflowAudit);
	}

	private UpdateOperations<Inquiry> emailAproveProcess(String soeId, Inquiry inqObj, Long groupId, String action, Workflow pendingWorkflow) throws CommunicatorException
	{
		UpdateOperations<Inquiry> ops;
		Date currentTime = new Date();
		Workflow inWorkflow = getWorkflow(inqObj.getWorkflows(), groupId, INQUIRY_DIRECTION_IN);
		Workflow outWorkflow = getWorkflow(inqObj.getWorkflows(), groupId, INQUIRY_DIRECTION_OUT);
		String lastAction = pendingWorkflow.getAction();
		String workflowStatus = pendingWorkflow.getWorkflowStatus();
		if (outWorkflow != null)
		{
			// Update existing OUT version and remove pending approval
			outWorkflow.setModDate(currentTime);
			outWorkflow.setModBy(soeId);
			// Release 1.2 changes-Add action in the workflow
			outWorkflow.setAction(action);
			outWorkflow.setIsLastConvToExtEmail("Y");
			outWorkflow.setWorkflowStatus(StringUtils.isNotBlank(workflowStatus) && WORKFLOW_STATUS_PND_SIRT_EXT_DOMAIN_EMAIL.equals(workflowStatus) ?WORKFLOW_STATUS_AP_SIRT_EXT_DOMAIN_EMAIL:WORKFLOW_STATUS_AP_OUTBOUND_EMAIL);
			addApprovedExternalDomain(inqObj, outWorkflow);
			calculateResponseTime(inqObj.getWorkflows(), groupId, currentTime);
			copyWorkFlowStatus(inWorkflow, outWorkflow, lastAction, null, null, null, currentTime, null);
			//C153176-1397
			if(null!=inWorkflow)
			{
				inWorkflow.setWorkflowStatus(outWorkflow.getWorkflowStatus());
			}
			//Remove Pending Approval
			inqObj.getWorkflows().remove(pendingWorkflow);
		}
		else
		{
			// Move the pending approval to INBOX
			pendingWorkflow.setDirection(INQUIRY_DIRECTION_OUT);
			pendingWorkflow.setModDate(currentTime);
			pendingWorkflow.setModBy(soeId);
			// Release 1.2 changes-Add action in the workflow
			pendingWorkflow.setAction(action);
			// Set maker blank on accept
			pendingWorkflow.setMaker(null);
			pendingWorkflow.setIsLastConvToExtEmail("Y");
			pendingWorkflow.setWorkflowStatus(StringUtils.isNotBlank(workflowStatus) && WORKFLOW_STATUS_PND_SIRT_EXT_DOMAIN_EMAIL.equals(workflowStatus) ?WORKFLOW_STATUS_AP_SIRT_EXT_DOMAIN_EMAIL:WORKFLOW_STATUS_AP_OUTBOUND_EMAIL);
			addApprovedExternalDomain(inqObj, pendingWorkflow);
			calculateResponseTime(inqObj.getWorkflows(), groupId, currentTime);
			copyWorkFlowStatus(inWorkflow, pendingWorkflow, lastAction, null, null, null, currentTime, null);
			//C153176-1397
			if(null!=inWorkflow)
			{
				inWorkflow.setWorkflowStatus(pendingWorkflow.getWorkflowStatus());
			}
			//[C153176-1270] - Add Escalation criteria for 'Pending Approval' emails
			// On approval we are making the below field null for out box mail
			pendingWorkflow.setIspendingApprovalEscalation(null);
			pendingWorkflow.setResponseTimeEscalationFlag(null);
			pendingWorkflow.setResponseTimeEscalationReason(null);
			pendingWorkflow.setResponseTimeNextEscalation(null);

		}
		if (inWorkflow != null)
		{
			inWorkflow.setIsLastConvToExtEmail("Y");
		}
		List<Long> allGroupIdList = new ArrayList<Long>();
		allGroupIdList.add(groupId);
		EscalationUtility escalationUtility = new EscalationUtility();
		escalationUtility.setAllGroupsEscalationCriteriaMap(groupDAO.getGroupEscalationDetailsById(allGroupIdList));
		escalationUtility.flagEscalations(allGroupIdList, inqObj.getWorkflows(), inqObj, groupId,QMACacheFactory.getCache().getConfigIdEscalationCriteriaMap());
		ops = mongoDatastore.createUpdateOperations(Inquiry.class).set(ACTION, action).set(WORKFLOWS, inqObj.getWorkflows());
		return ops;
	}

	private void emailRejectProcess(String soeId, Inquiry inqObj, Long groupId, String action, String openGroups, Workflow pendingWorkflow)
	{
		Date currentTime = new Date();
		Workflow inWorkflow = getWorkflow(inqObj.getWorkflows(), groupId, INQUIRY_DIRECTION_IN);
		Workflow outWorkflow = getWorkflow(inqObj.getWorkflows(), groupId, INQUIRY_DIRECTION_OUT);
		List<Long> allGroupIdList = new ArrayList<Long>();
		allGroupIdList.add(groupId);
		EscalationUtility escalationUtility = new EscalationUtility();
		escalationUtility.setAllGroupsEscalationCriteriaMap(groupDAO.getGroupEscalationDetailsById(allGroupIdList));
		if (inWorkflow != null)
		{
			// Update Existing INBOX workflow
			updateInboxWithRejectStatus(soeId, inqObj, action, currentTime, pendingWorkflow, inWorkflow);
		}
		else
		{
			// Move the pending approval to INBOX
			convertPendingApprovalToInbox(soeId, action, currentTime, pendingWorkflow, escalationUtility, groupId);
		}
		if (outWorkflow != null)
		{
			outWorkflow.setIsLastConvToExtEmail("N");
		}

		appendToOpenGroups(groupId, openGroups);

		escalationUtility.flagEscalations(allGroupIdList, inqObj.getWorkflows(), inqObj, groupId,QMACacheFactory.getCache().getConfigIdEscalationCriteriaMap());

	}

	private void updateInboxWithRejectStatus(String soeId, Inquiry inqObj, String action, Date currentTime, Workflow pendingWorkflow, Workflow inWorkflow)
	{
		inWorkflow.setModDate(currentTime);
		inWorkflow.setModBy(soeId);
		// Release 1.2 changes-Add action in the workflow
		inWorkflow.setAction(action);
		inWorkflow.setStatus(STATUS_OPEN);

		inWorkflow.setIsLastConvToExtEmail("N");
		inWorkflow.setWorkflowStatus(StringUtils.isNotBlank(pendingWorkflow.getWorkflowStatus()) && WORKFLOW_STATUS_PND_SIRT_EXT_DOMAIN_EMAIL.equals(pendingWorkflow.getWorkflowStatus()) ?WORKFLOW_STATUS_RJ_SIRT_EXT_DOMAIN_EMAIL:WORKFLOW_STATUS_RJ_OUTBOUND_EMAIL);
		// Remove PENDING Approval Workflow
		inqObj.getWorkflows().remove(pendingWorkflow);
		// in case of reject we are setting  IspendingApprovalEscalation "N"
		inWorkflow.setIspendingApprovalEscalation(null);

		// in case of reject we are again setting the escalation for inbox verson of workflow 
		List<Long> allGroupIdList = new ArrayList<Long>();
		allGroupIdList.add(inWorkflow.getAssignedGroupId());
		EscalationUtility escalationUtility = new EscalationUtility();
		escalationUtility.setAllGroupsEscalationCriteriaMap(groupDAO.getGroupEscalationDetailsById(allGroupIdList));
		escalationUtility.setEscalationTime(inWorkflow.getAssignedGroupId(),inWorkflow, currentTime);

	}

	private void convertPendingApprovalToInbox(String soeId, String action, Date currentTime, Workflow pendingWorkflow, EscalationUtility escalationUtility, Long groupId)
	{
		// Move the pending approval to INBOX
		pendingWorkflow.setDirection(INQUIRY_DIRECTION_IN);
		pendingWorkflow.setModDate(currentTime);
		pendingWorkflow.setModBy(soeId);
		// Release 1.2 changes-Add action in the workflow
		pendingWorkflow.setAction(action);
		// Set maker blank on reject
		pendingWorkflow.setMaker(null);
		pendingWorkflow.setIsLastConvToExtEmail("N");
		pendingWorkflow.setWorkflowStatus(StringUtils.isNotBlank(pendingWorkflow.getWorkflowStatus()) && WORKFLOW_STATUS_PND_SIRT_EXT_DOMAIN_EMAIL.equals(pendingWorkflow.getWorkflowStatus()) ?WORKFLOW_STATUS_RJ_SIRT_EXT_DOMAIN_EMAIL:WORKFLOW_STATUS_RJ_OUTBOUND_EMAIL);
		//[C153176-1270] - Add Escalation criteria for 'Pending Approval' emails
		pendingWorkflow.setIspendingApprovalEscalation(null);
		pendingWorkflow.setResponseTimeEscalationReason(null);
		pendingWorkflow.setResponseTimeEscalationFlag(null);
		pendingWorkflow.setResponseTimeNextEscalation(null);
		pendingWorkflow.setPendingExternalDomains(null);
		Integer responseTimeThreshold = escalationUtility.getAllGroupsEscalationCriteriaMap().get(groupId).getResponseTimeThresholdForEscalation();
		if (null != responseTimeThreshold && responseTimeThreshold > 0 && null == pendingWorkflow.getResponseTimeNextEscalation())
			pendingWorkflow.setResponseTimeEscalationFlag("N");
		pendingWorkflow.setResponseTimeNextEscalation(escalationUtility.generateNextEscalationTime(groupId,currentTime, responseTimeThreshold));
	}

	private void updateInquiryGroupAudit(Inquiry inqObj, Long groupId, String flag) throws CommunicatorException

	{
		// Get DB OutBount Email's Inquiry's Group Id
		Query<OutBoundEmails> query1 = mongoDatastore.createQuery(OutBoundEmails.class).filter(INQUIRY_ID, inqObj.id).filter(GROUP_ID, groupId).filter(PROCESS_FLAG, "P");
		List<OutBoundEmails> inqGrpOutEmailAudList = query1.asList();

		if (inqGrpOutEmailAudList == null || inqGrpOutEmailAudList.isEmpty())
		{
			// Inquiry level update, this is needed untill old rows from Pending Approval Queue Clears
			updateInquiryAudit(inqObj, flag);
		}
		else
		{
			// Group Level implementation
			updateOutBoundEmailAudGrpLevel(inqObj, groupId, flag, inqGrpOutEmailAudList);
		}

	}

	private void updateOutBoundEmailAudGrpLevel(Inquiry inqObj, Long groupId, String flag, List<OutBoundEmails> inqGrpOutEmailAudList) throws CommunicatorException

	{
		// Approve Flow
		if ("N".equalsIgnoreCase(flag))
		{
			// Check Row Exists in Outbound email table
			if (!inqGrpOutEmailAudList.isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
			{
				
				for (OutBoundEmails outEmailAud : inqGrpOutEmailAudList)
				{
					createInquiryAuditRaw(inqObj.id, outEmailAud.getConversationId(), false, false, groupId, inqObj.getAction());
				}
				// Update existing outbound email audit entry for a inquiry's groupId to A
				Query<OutBoundEmails> query = mongoDatastore.createQuery(OutBoundEmails.class).filter(INQUIRY_ID, inqObj.id).filter(GROUP_ID, groupId).filter(PROCESS_FLAG, "P");
				UpdateOperations<OutBoundEmails> ops = mongoDatastore.createUpdateOperations(OutBoundEmails.class).set(PROCESS_FLAG, "A").set(MODIFIED_DATE, new Date());// A means already processed.
				mongoDatastore.update(query, ops);

				updateOutboundConversationAction(inqGrpOutEmailAudList, "Approve");
			}
		}
		// Reject Flow
		else if ("R".equalsIgnoreCase(flag))
		{
			// All Outbound email entries for a Inquiry's GroupId are marked as Rejected
			Query<OutBoundEmails> query = mongoDatastore.createQuery(OutBoundEmails.class).filter(INQUIRY_ID, inqObj.id).filter(GROUP_ID, groupId).filter(PROCESS_FLAG, "P");
			UpdateOperations<OutBoundEmails> ops = mongoDatastore.createUpdateOperations(OutBoundEmails.class).set(PROCESS_FLAG, flag).set(MODIFIED_DATE, new Date());// R means reject
			mongoDatastore.update(query, ops);

			updateOutboundConversationAction(inqGrpOutEmailAudList, "Reject");
		}
	}

	private void updateOutboundConversationAction(List<OutBoundEmails> inqGrpOutEmailAudList, String action)
	{
		if (inqGrpOutEmailAudList != null && !inqGrpOutEmailAudList.isEmpty())
		{
			for (OutBoundEmails outEmailAud : inqGrpOutEmailAudList)
			{
				// if (STRING_YES.equals(CacheDAO.getInstance().getDefaultStaticData().getEnableInternalGroupEmailRouting()))
				// {
				// Update the action as Approve. This will reflected in the Group's Versions if the routing enabled
				Query<Conversation> convQuery = mongoDatastore.createQuery(Conversation.class).filter("_id", outEmailAud.getConversationId());
				UpdateOperations<Conversation> opsConv = mongoDatastore.createUpdateOperations(Conversation.class).set(ACTION, action).set(MODIFIED_DATE, new Date());// A means already
				// processed.
				mongoDatastore.update(convQuery, opsConv);
				// }
			}
		}
	}

	private void copyWorkFlowStatus(Workflow workflowFromObj, Workflow workflowToObj, String action, String resolveRootCause, String resolveProcessingRegion, Long queryCount, Date currentTime,
			String inquirySource)
	{
		if (workflowToObj != null)
		{
			if (workflowFromObj != null)
			{
				workflowToObj.setStatus(workflowFromObj.getStatus());
				// keep resovler and resolve time in sync with inbox version.
				workflowToObj.setResolver(workflowFromObj.getResolver());
				workflowToObj.setResolveTime(workflowFromObj.getResolveTime());
				workflowToObj.setTotalResolveTimeQMA(workflowFromObj.getTotalResolveTimeQMA());
				workflowToObj.setResolveCountQMA(workflowFromObj.getResolveCountQMA());
				workflowToObj.setClientChaseCounter(workflowFromObj.getClientChaseCounter());
				workflowToObj.setLatestClientChaseCounter(workflowFromObj.getLatestClientChaseCounter());
				workflowToObj.setIsManualEscalation(workflowFromObj.getIsManualEscalation());
				workflowToObj.setManualEscalationReason(workflowFromObj.getManualEscalationReason());
				workflowToObj.setOriginDate(workflowFromObj.getOriginDate());
				workflowToObj.setCrtBy(workflowFromObj.getCrtBy());
				workflowToObj.setCrtDate(workflowFromObj.getCrtDate());
				
				// C153176-5354 | Panorama feed
				workflowToObj.setResolutionTimeInMinutes(workflowFromObj.getResolutionTimeInMinutes());
				workflowToObj.setFirstResponseInMinutes(workflowFromObj.getFirstResponseInMinutes());
				workflowToObj.setFirstResponseTime(workflowFromObj.getFirstResponseTime());
				workflowToObj.setResponseTimeInMinutes(workflowFromObj.getResponseTimeInMinutes());
				
				workflowFromObj.setSuggestionIndicator(workflowFromObj.getSuggestionIndicator());
				workflowFromObj.setIntentSuggestionName(workflowFromObj.getIntentSuggestionName());
				workflowFromObj.setUserIntentSuggestionName(workflowFromObj.getUserIntentSuggestionName());
				workflowFromObj.setIntentTimeToVD(workflowFromObj.getIntentTimeToVD());
				workflowFromObj.setInquiryRefSent(workflowFromObj.getInquiryRefSent());
				
				// C153176-5891 | Average response time not calculated correctly
				workflowToObj.setIsLatestResponseFromNonQMA(workflowFromObj.getIsLatestResponseFromNonQMA());
				workflowToObj.setFirstNonChaserResponseTimeByExternal(workflowFromObj.getFirstNonChaserResponseTimeByExternal());
				workflowToObj.setCitiResponseTime(workflowFromObj.getCitiResponseTime());
				
				// C153176-5977 | Nominate ownership : Resolution time getting considered from the time of ownership requested
				workflowToObj.setOwnershipAcceptedTime(workflowFromObj.getOwnershipAcceptedTime());
			}
			else if (ACTION_REPLY_RESOLVE.equals(action) || ACTION_REPLYALL_RESOLVE.equals(action))
			{
				workflowToObj.setStatus(STATUS_RESOLVE);
				workflowToObj.setFollowUp(null);
				calculateResolutionTime(workflowToObj, null, currentTime);
			}
			// [C153176-774] - Root cause drop down for resolve
			if (!StringUtils.isBlank(resolveRootCause))
			{
				workflowToObj.setRootCause(resolveRootCause);
			}
			// [C153176-793] Add Processing Region as a drop-down in Group Admin screen
			if (!StringUtils.isBlank(resolveProcessingRegion))
			{
				workflowToObj.setProcessingRegion(resolveProcessingRegion);
			}
			if (queryCount != null)
			{
				workflowToObj.setQueryCount(queryCount);
			}
			// [C153176-854] - Add new drop-down: Inquiry Source
			if (!StringUtils.isBlank(inquirySource))
			{
				workflowToObj.setInquirySource(inquirySource);
			}
		}

	}

	private List<String> getTOCCGrpCodeList(List<ConversationRecipient> conversationRecipientList)
	{
		List<String> toCcGroupCodes = new ArrayList<String>();
		for (ConversationRecipient conversationRecipient : conversationRecipientList)
		{
			if (conversationRecipient != null && (TO_CATEGORY.equalsIgnoreCase(conversationRecipient.getToFrom())
					|| CC_CATEGORY.equalsIgnoreCase(conversationRecipient.getToFrom())) && null != conversationRecipient.getGroupId())
			{
				String groupName = conversationRecipient.getDisplayName();
				if (!StringUtils.isBlank(groupName))
				{
					toCcGroupCodes.add(groupName);
				}

			}
		}
		return toCcGroupCodes;
	}

	// link de-link service method 
	public boolean bulkLinkDeLink(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException
	{
		boolean bSuccess = Boolean.FALSE;
		DBObject stats = null;
		Inquiry dbInquiry = null;
		Date currentTime = new Date();
		DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
		BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();

		DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
		BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();
		String action = inputJsonObj.getString(ACTION);
		Long linkId = GenericUtility.getIdFromRequest(inputJsonObj, "linkId");

		List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);

		List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "linkInquiryData");

		List<BasicDBObject> dbinquiryInfo = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
		Map<Long, ActionStatistics> inquiryInfoMap =  populateInquiryInfoMap(dbinquiryInfo,null,null);

		// Prepare Update-workflow link update
		DBObject updateDBFields = prepareLinkInquiryUpdateObj(action, linkId);
		Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
		Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
		if (!inquiryIds.isEmpty() && !dbObjs.isEmpty())

		{
			for (BasicDBObject obj : dbObjs)
			{
				// Get Data
				Long inquiryId = GenericUtility.getIdFromRequest(obj, INQUIRY_ID);
				dbInquiry = getInquiryById(inquiryId);
				Long groupId = GenericUtility.getIdFromRequest(obj, GROUP_ID);
				if (inquiryId == null || groupId == null)
				{
					subLogger.info("InquiryDAO.bulkLinkDeLink inquiry Id = " + inquiryId + "Group Id = " + groupId);
					continue;
				}

				if (updateDBFields.get("$set") != null && ((DBObject) updateDBFields.get("$set")).get(WORKFLOWS_LINK_ID) != null)
				{
					linkId = Long.valueOf(((DBObject) updateDBFields.get("$set")).get(WORKFLOWS_LINK_ID).toString());
				}

				// Create new Audit for the action
				DBObject workflowAudit = createWorkFlowsAuditJavaDriver(null, action, linkId + "", soeId, currentTime, groupIdToNameMap, userInfoMap);
				workflowAudit.put(INQUIRY_ID, inquiryId);

				DBObject updateWorkAuditFields = new BasicDBObject();
				updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));

				// Prepare Query for InBox +Resolvebox
				DBObject findINQuery = prepareFindQuery(inquiryId, groupId, null, INQUIRY_DIRECTION_IN, false);
				// C153176-368-Resolved Inquiry Cannot be found with OUT version
				DBObject findOUTQuery = prepareFindQuery(inquiryId, groupId, STATUS_OPEN, INQUIRY_DIRECTION_OUT, false);
				DBObject findPNDQuery = prepareFindQuery(inquiryId, groupId, STATUS_OPEN, INQUIRY_DIRECTION_PENDING_APPROVAL);

				// Audit Query
				// C153176-368-Resolved Inquiry Cannot be found with OUT version
				DBObject findWorkAuditflowQuery = prepareFindQuery(inquiryId, groupId, STATUS_OPEN, INQUIRY_DIRECTION_IN_OR_OUT_OR_PA, false);

				bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);
				bulkInquiryUpdOp.find(findOUTQuery).update(updateDBFields);
				bulkInquiryUpdOp.find(findPNDQuery).update(updateDBFields);

				// Audit Insert
				bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);

				// Stats
				//Modified for requestType in Action Statistics - C153176-1155
				ActionStatistics statsObj = inquiryInfoMap.get(inquiryId+groupId);

				stats = getStatsObject(soeId, action, currentTime, dbInquiry, groupId, false, statsObj, groupIdToNameMap, userInfoMap);
				bulkStatsInsertdOp.insert(stats);
				subLogger.info("ActionStatistics Saved for action 6" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID) + " linkId-" + linkId + " ,groupId-" + groupId);

			}
			// Execute
			if (!inquiryIds.isEmpty())
			{
				bulkInquiryUpdOp.execute();
				bulkStatsInsertdOp.execute();
			}
			bSuccess = Boolean.TRUE;
		}

		return bSuccess;

	}

	// if link id is send from ui is not zero then use link id comming from ui else crete new link id for linking inquiry
	private DBObject prepareLinkInquiryUpdateObj(String action, Long linkId1)
	{
		Long linkId = linkId1;
		DBObject inquiryUpdateDBObj = new BasicDBObject();
		if (action.equals("Link"))
		{
			// inquiryUpdateDBObj.put(WORKFLOWS_LINK_ID, 0);
			if (linkId == 0)
			{
				// create Link ID if ite new Link else use existing one
				SequenceId newId = GenericUtility.generateSequenceId("Link");
				linkId = newId.getValue();
				inquiryUpdateDBObj.put(WORKFLOWS_LINK_ID, newId.getValue());
			}
			else
			{
				inquiryUpdateDBObj.put(WORKFLOWS_LINK_ID, linkId);
			}
		}

		DBObject updateDBFields = new BasicDBObject();
		// Update inquiry fields
		if ("Link".equals(action))
		{
			updateDBFields.put("$set", inquiryUpdateDBObj);
		}
		else
		{
			// updateDBFields.put("$unset", new BasicDBObject(WORKFLOWS_LINK_ID,""));
			updateDBFields.put("$unset", new BasicDBObject(WORKFLOWS_LINK_ID, ""));
		}
		return updateDBFields;
	}

	// C153176-154-ActionStatistics Improvements
	private void updateStats(List<Workflow> workflowList, Long groupId, DBObject statsObj, String dataRowBoxDirection, Conversation conversation, String subject)
	{
		Workflow lastModifiedWorkflow = getLastModifiedWorkflow(workflowList, groupId, dataRowBoxDirection);
		if (null != lastModifiedWorkflow)
		{
			// Avoid Null data saving in DB Ex. "assignedUserId" : null,
			if (null != lastModifiedWorkflow.getRequestType())
			{
				statsObj.put(REQUEST_TYPE, lastModifiedWorkflow.getRequestType());
			}
			if (null != lastModifiedWorkflow.getAssignedUserId())
			{
				statsObj.put(ASSIGNED_USER_ID, lastModifiedWorkflow.getAssignedUserId());
			}
			if (null != lastModifiedWorkflow.getAssignedUserName())
			{
				statsObj.put("assignedUserName", lastModifiedWorkflow.getAssignedUserName());
			}

			if (null != lastModifiedWorkflow.getPrevResponseCntr())
			{
				statsObj.put("prevResponseCntr", lastModifiedWorkflow.getPrevResponseCntr());
			}
			//added resolutionTimeInMinutes in action statistics
			if (null != lastModifiedWorkflow.getResolutionTimeInMinutes()){
				statsObj.put("resolutionTimeInMinutes", lastModifiedWorkflow.getResolutionTimeInMinutes());
			}
			
		}
		statsObj.put(SUBJECT, subject);

		if (null != conversation)
		{
			updateConversationStats(conversation.getRecipients(), statsObj);
		}

	}

	private void updateConversationStats(List<ConversationRecipient> recipientList, DBObject statsObj)
	{
		BasicDBList dbConVRecpList = new BasicDBList();
		Integer noOfExtRecp = 0;
		Integer noOfInternalRecp = 0;
		for (ConversationRecipient recipient : recipientList)
		{
			BasicDBObject recp = new BasicDBObject();
			if (null != recipient.getGroupId())
				recp.put(GROUP_ID, recipient.getGroupId());
			if (null != recipient.getEmailAddr())
				recp.put("emailAddr", recipient.getEmailAddr());
			if (null != recipient.getUserId())
				recp.put(USER_ID, recipient.getUserId());
			if (null != recipient.getDisplayName())
				recp.put("displayName", recipient.getDisplayName());
			recp.put("toFrom", recipient.getToFrom());

			if (!"FROM".equalsIgnoreCase(recipient.getToFrom()))
			{
				if (recipient.getDisplayName().contains("@") && !GenericUtility.isCitiDomainEmail(recipient.getDisplayName().trim()))
				{
					noOfExtRecp++;
				}
				else
				{
					noOfInternalRecp++;
				}
			}
			dbConVRecpList.add(recp);
		}
		statsObj.put(RECEPIENTS, dbConVRecpList);
		statsObj.put("noOfInternalRecipients", noOfInternalRecp);
		statsObj.put("noOfExternalRecipients", noOfExtRecp);
	}

	private void updatePrevResponseCounterForOutVersion(Workflow outWorkflow, String action)
	{
		// Increment Previous Responsponse Counter in OUT Workflow used for Reply
		if (outWorkflow != null && !ACTION_NEW.equals(action))
		{
			Integer oldPrevRespCntr = outWorkflow.getPrevResponseCntr();
			Integer newPrevRespCntr = (null == oldPrevRespCntr) ? 1 : oldPrevRespCntr + 1;
			outWorkflow.setPrevResponseCntr(newPrevRespCntr);
		}
	}

	public BasicDBObject callSolrSearchCriteria(List<String> qStringList, String soeId, BasicDBObject inputJsonObj)
	{
		BasicDBObject solrCriteria = null;
		Set<Long> inquiryList = new HashSet<Long>();
		try
		{
			String userGroupsListForSolr = userDao.getUserGroupsListForSolr(soeId);
			for(String qString1 : qStringList)
			{
				String qString = qString1;
				qString = "&q=" + URLEncoder.encode(qString, ENCODING_UTF8) + "&fq=" + URLEncoder.encode(userGroupsListForSolr, ENCODING_UTF8);
				String url = QMACacheFactory.getCache().getDefaultStaticData().getSolrURL();
				boolean isSSLEnabledUrl = null != url && (url.startsWith("https") || url.startsWith("http")) && SolrSocketFactory.isSolrSSLEnabled();
				if(isSSLEnabledUrl) {
					inquiryList.addAll(sslEnabledPostSolrSearchCriteria(qString, url, inputJsonObj));
				}else {
					if (qString.length() < 2048) // could be till 8kb though.
					{
						inquiryList.addAll(getSolrSearchCriteria(qString, soeId));
					}
					else
					{
						inquiryList.addAll(postSolrSearchCriteria(qString, soeId));
					}
				}
			}

			if (!inquiryList.isEmpty())
			{
				solrCriteria = new BasicDBObject("_id", new BasicDBObject("$in", inquiryList));
			}
		}
		catch (Exception e)
		{
			subLogger.error("Error in callSolrSearchCriteria for solr search-query" + qStringList, e);
		}
		return solrCriteria;
	}

	private Set<Long> sslEnabledPostSolrSearchCriteria(String qString1, String url, BasicDBObject inputJsonObj) throws CommunicatorException {
		subLogger.info("Performing Solr search with SSL enabled..");
		Set<Long> inquiryList = new HashSet<>(); // C170665-3783 assigned "new HashSet<>()" object to handle Nullpointer Exception when responseResult is empty
		String qString = qString1;
		try {
			
			BasicDBObject responseResult = new BasicDBObject();
			responseResult = getResponseFromSolr(url, qString, responseResult);
			// Parse JSON Output from Solr response
			inquiryList = parseSolrResponse(inquiryList, responseResult, inputJsonObj);
		} catch (Exception e) {
			subLogger.error("Error in sslEnabledPostSolrSearchCriteria for solr search-url=" + url + qString, e);
			throw new CommunicatorException("Error in sslEnabledPostSolrSearchCriteria for solr search-url=" + url + qString, e);
		}
		return inquiryList;
	}
	/**
	 * @param url
	 * @param qString
	 * @param responseResult
	 * @return
	 */
	private BasicDBObject getResponseFromSolr(String url, String qString, BasicDBObject responseResult) {
		HttpPost postRequest = null;
		try {
			HttpClient httpClient = SolrSocketFactory.getHttpClientSSLEnabled();
			if (httpClient != null) {
				postRequest = new HttpPost(url);
				postRequest.addHeader("Content-Type", "application/x-www-form-urlencoded");
				StringEntity input = new StringEntity(qString+ "&sort%3D_id%20desc");
				postRequest.setEntity(input);
				
				HttpResponse response = httpClient.execute(postRequest);
				if (response.getStatusLine().getStatusCode() == 200) {
					String resp_body = EntityUtils.toString(response.getEntity());
					responseResult = BasicDBObject.parse(resp_body);
					//Commented because huge response getting logged 
					//subLogger.info("Response:{}", responseResult.toString());
				}
			}
		} catch (Exception ex) {
			subLogger.error("Error in invokeURL(" + qString + ")", ex);
		}finally {
			if (postRequest != null) {
				try {
					postRequest.completed();
				} catch (Exception e) {
					subLogger.error("Error in postSolrSearchCriteria while closing input stream ", e);
				}

			}

		}
		return responseResult;
	}
	/**
	 * @param inquiryList
	 * @param responseResult
	 * @param inputJsonObj 
	 * @return
	 */
	private Set<Long> parseSolrResponse(Set<Long> inquiryList, BasicDBObject responseResult, BasicDBObject inputJsonObj) {
		if (null != responseResult.get("response")) {
			BasicDBObject solrResponse = (BasicDBObject) responseResult.get("response");
			inquiryList = new HashSet<Long>();
			if (null != solrResponse.get("docs")) {
				inquiryList = new HashSet<Long>();
				BasicDBList inquiryIdDocs = (BasicDBList) (solrResponse.get("docs"));
				Long inquiryId = null;
				for (Object idDoc : inquiryIdDocs) {
					boolean match = false;
					BasicDBObject document = (BasicDBObject) idDoc;
					Object inqId = document.get(INQUIRY_ID);
					match = InquiryUtil.isToCcFromMatch(inputJsonObj, match, document);
					inquiryId = GenericUtility.convertIdFromRequest(inqId);
					if (inquiryId != null && match) {
							inquiryList.add(inquiryId);
					}
				}
			}
		}
		return inquiryList;
	}
	
	public Set<Long> postSolrSearchCriteria(String qString1, String soeId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Set<Long> inquiryList = null;
		InputStream in = null;
		String url = null;
		String qString = qString1;
		try
		{
			url = QMACacheFactory.getCache().getDefaultStaticData().getSolrURL();
			//			UserDAO userDao = new UserDAO();
			//String userGroupsListForSolr = userDao.getUserGroupsListForSolr(soeId);
			// System.out.println(userGroupsListForSolr);
			// String myGroups = "53051 OR 53052";
			// qString = qString + " && (" + userGroupsListForSolr + ")" + "&sort=_id desc";
			// qString = URLEncoder.encode(qString + "&q="+ " &sort=_id desc");
			// qString = URLEncoder.encode("&q="+ qString + " &sort=_id desc");
			// qString = "&q=" + qString + "&fq=" + userGroupsListForSolr;

			//			qString = "&q=" + URLEncoder.encode(qString, ENCODING_UTF8) + "&fq=" + URLEncoder.encode(userGroupsListForSolr, ENCODING_UTF8);
			//			System.out.println("Qstring is: " + qString);



			//qString="&q=" + URLEncoder.encode(qString, ENCODING_UTF8);
			// System.out.println("Qstring is: " + qString);
			// String urlWithQString = url + "Content-Type:application/x-www-form-urlencoded" + "&q=" + URLEncoder.encode(qString, ENCODING_UTF8);
			// qString = "Content-Type:application/x-www-form-urlencoded" + "&q=" + URLEncoder.encode(qString, ENCODING_UTF8);
			// subLogger.info("Solr Search URL : " + urlWithQString);
			// URL connection = new URL(urlWithQString);
			URL connection = URI.create(url).toURL();

			/*
			 * var request = (HttpWebRequest)WebRequest.Create(u.Uri); request.Method = "POST"; 37 request.ContentType = "application/x-www-form-urlencoded";
			 */
			HttpURLConnection httpCon = (HttpURLConnection) connection.openConnection();
			httpCon.setDoOutput(true);
			httpCon.setRequestMethod("POST");
			httpCon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			// String USER_AGENT = "Mozilla/5.0"; //or chrome one etc.
			// httpCon.setRequestProperty("User-Agent", USER_AGENT);
			// httpCon.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			// httpCon.setRequestProperty("Content-Length", "10000000");

			DataOutputStream p = new DataOutputStream(httpCon.getOutputStream());
			p.writeBytes(qString);
			p.flush();
			p.close();

			// in = connection.openStream();
			in = httpCon.getInputStream();

			// Parse JSON Output from Solr response
			BasicDBObject solrResponse = parse(in);
			inquiryList = new HashSet<Long>();
			BasicDBList inquiryIdDocs = (BasicDBList) (solrResponse.get("docs"));
			Long inquiryId = null;
			for (Object idDoc : inquiryIdDocs)
			{
				BasicDBObject document = (BasicDBObject) idDoc;
				Object inqId = document.get(INQUIRY_ID);
				// System.out.println("inqId" + inqId);
				inquiryId = GenericUtility.convertIdFromRequest(inqId);
				if (inquiryId != null)
				{
					inquiryList.add(inquiryId);
				}

			}
			// System.out.println("solr search lis" + inquiryList);

		}
		catch (Exception e)
		{
			subLogger.error("Error in postSolrSearchCriteria for solr search-url=" + url + qString, e);
			throw new CommunicatorException("Error in postSolrSearchCriteria for solr search-url=" + url + qString, e);
		}
		finally
		{
			if (in != null)
			{
				try
				{
					in.close();
				}
				catch (IOException e)
				{
					subLogger.error("Error in postSolrSearchCriteria while closing input stream ", e);
				}

			}
		}

		return inquiryList;
	}

	// Thsi creates solr query for search.
	HashMap<String, List<String>> createSolrQuery(BasicDBObject inputJsonObj1, String soeId) throws CommunicatorException
	{
		BasicDBObject inputJsonObj = inputJsonObj1;
		String solrQuery = "";
		String viewName = inputJsonObj.getString(VIEW_NAME);
		if(SmartSearchUtil.isSmartSearchEnabled() && SmartSearchUtil.requestFromSearch(inputJsonObj)) {
			subLogger.info("Smart search enabled..");
			inputJsonObj = SmartSearchUtil.getSmartSearchCriteria(inputJsonObj1);
		}else {
			subLogger.info("Smart search config not found or it is disabled either request is not from search.");
			inputJsonObj = SmartSearchUtil.getInputForRegularSearch(inputJsonObj);
		}
		HashMap<String, List<String>> solrQueryMap = new HashMap<>();
		String url = QMACacheFactory.getCache().getDefaultStaticData().getSolrURL();
		boolean isSSLEnabledUrl = null != url && (url.startsWith("https") || url.startsWith("http")) && SolrSocketFactory.isSolrSSLEnabled();
		// basic search
		if (inputJsonObj.getString(SOLR_SEARCH_TEXT) != null)
		{
			String solrSearchText = inputJsonObj.getString(SOLR_SEARCH_TEXT);
			if(solrSearchText.contains(" ") && !solrSearchText.contains("\"") && isSSLEnabledUrl) {
				solrSearchText = "("+solrSearchText.trim().replaceAll(" ", " OR ")+")";
			} else {
				solrSearchText = "\"" + solrSearchText + "\"";
			}

			if (StringUtils.isNumeric(solrSearchText.replaceAll("(^\"{1,10})|(\"{1,10}$)", "")))
			{
				solrQuery = solrQuery + "inquiryId:" + solrSearchText;
				solrQuery = solrQuery + " || " + "subject:" + solrSearchText + " || content:" + solrSearchText + " || recipients:" + solrSearchText;
			}
			else
			{
				//				UserDAO userDao = new UserDAO();
				//				String userGroupsListForSolr = userDao.getUserGroupsListForSolr(soeId);
				// system.out.println(userGroupsListForSolr);
				// String myGroups = "53051 OR 53052";
				// String recipients = "(" + solrSearchText + " && (" + userGroupsListForSolr + "))";
				solrQuery = solrQuery + "subject:" + solrSearchText + " || content:" + solrSearchText + " || recipients:" + solrSearchText;
			}
			if(!isSSLEnabledUrl) { //<-- sonar fix Remove or correct this useless self-assignment.
				solrQuery = solrQuery + " &&sort=_id desc";
			}
			List<String> list = new ArrayList<>();
			list.add(solrQuery);
			solrQueryMap.put(SOLR_QUERY, list);
		}
		// advance search
		else if (inputJsonObj.getString(ADVANCED_SEARCH_DATA) != null)
		{
			// TODO:check if premongo also required then it become input for solr
			//// isPreSolrMongoSearchRequired(inputJsonObj);
			// createMongoDBQuery(inputJsonObj);
			// pass this as criteria as string to solr, this could be no solr as well, that is another case .. handle later
			inputJsonObj = BasicDBObject.parse(inputJsonObj.getString(ADVANCED_SEARCH_DATA));
			boolean solrSearchRequired = isSolrSearchRequired(inputJsonObj);
			boolean preSolrMongoSearchRequired = isPreSolrMongoSearchRequired(inputJsonObj);

			// This means solr search to be done, mongo serach can be or cannot be
			if (solrSearchRequired)
			{

				List<String> preSolrMongoDBInquiryList = new ArrayList<>();
				if (preSolrMongoSearchRequired)
				{
					// preSolrMongoDBInquiryList = createPreSolrMongoDBInquiryList(inputJsonObj,viewName);
					//commented below code as db hit is not required here
					/*DBObject finalQuery = createPreSolrMongoDBObject(inputJsonObj, viewName);
					preSolrMongoDBInquiryList = createSolrSearchList(finalQuery);*/
				}
				// String inquiryId = inputJsonObj.getString(INQUIRY_ID);// != null ? inputJsonObj.getLong(INQUIRY_ID) : null;
				String subject = inputJsonObj.getString(SUBJECT);
				String content = inputJsonObj.getString(CONTENT);
				if (null != subject && subject.contains(" ") && isSSLEnabledUrl) {
					subject = subject.trim().replaceAll(" ", "+");
				}
				if (null != content && content.contains(" ") && isSSLEnabledUrl) {
					content = content.trim().replaceAll(" ", "+");
				}

				String recipients = inputJsonObj.getString("originator");
				String memo = inputJsonObj.getString("memo");

				// String str = "";
				boolean flag = false;

				// InquiryId can be from solr or advance search, not both.
				/*
				 * if (!StringUtils.isBlank(preSolrMongoDBInquiryList)) { solrQuery = solrQuery + "inquiryId:" + preSolrMongoDBInquiryList; flag = true; }
				 */
				/*
				 * else if (inquiryId != null) { solrQuery = solrQuery + "inquiryId:" + Long.valueOf(inquiryId); flag = true; }
				 */

				if (content != null)
				{
					solrQuery = appendSolrQuery(solrQuery, content, flag, CONTENT);
					flag = true;
				}
				if (subject != null)
				{
					solrQuery = appendSolrQuery(solrQuery, subject, flag, SUBJECT);
					flag = true;
					/*
					 * if (flag == true) { solrQuery = solrQuery + " && subject:" + subject; }else { solrQuery = solrQuery + "subject:" + subject; } flag = true;
					 */

				}
				if (recipients != null)
				{
					//					UserDAO userDao = new UserDAO();
					//					String userGroupsListForSolr = userDao.getUserGroupsListForSolr(soeId);
					// system.out.println(userGroupsListForSolr);
					// String myGroups = "53051 OR 53052";
					// recipients = recipients + " && (" + userGroupsListForSolr + ")";
					// recipients = "(" + recipients + " && (" + userGroupsListForSolr + "))";

					solrQuery = appendSolrQuery(solrQuery, recipients, flag, RECEPIENTS);
					flag = true;
					/*
					 * if (flag == true) { solrQuery = solrQuery + " && recipients:" + recipients; }else { solrQuery = solrQuery + "recipients:" + recipients; }
					 */

				}
				
				if (memo != null)
				{
					 
					solrQuery = appendSolrQuery(solrQuery, memo, flag, "memo");
					flag = true;
					/*
					 * if (flag == true) { solrQuery = solrQuery + " && recipients:" + recipients; }else { solrQuery = solrQuery + "recipients:" + recipients; }
					 */

				}
				if (!preSolrMongoDBInquiryList.isEmpty())
				{
					for(int i=0;i< preSolrMongoDBInquiryList.size();i++)
					{
						if(isSSLEnabledUrl) {
							preSolrMongoDBInquiryList.set(i, appendSolrQuery(solrQuery, preSolrMongoDBInquiryList.get(i), flag, INQUIRY_ID));
						}else{
							preSolrMongoDBInquiryList.set(i, appendSolrQuery(solrQuery, preSolrMongoDBInquiryList.get(i), flag, INQUIRY_ID));
						}
					}
				}
				else
				{
					if(isSSLEnabledUrl)  {
						preSolrMongoDBInquiryList.add(solrQuery);
					}else {
                        try {
                            preSolrMongoDBInquiryList.add(solrQuery + " && sort=" + URLEncoder.encode("_id desc", ENCODING_UTF8));
                        } catch (UnsupportedEncodingException e) {
                            throw new RuntimeException("Exception while encoding " + e.getMessage());
                        }
                    }
				}

				solrQueryMap.put(SOLR_QUERY, preSolrMongoDBInquiryList);

				if (preSolrMongoSearchRequired)
			{
					DBObject finalQuery = createPreSolrMongoDBObjectForAdvanceSearch(inputJsonObj, viewName);//createPreSolrMongoDBObject(inputJsonObj, viewName);
					//DBObject finalQuery1 = createMongoSearchDBObject(finalQuery);

//					solrQuery = finalQuery1.toString();
					solrQuery = finalQuery.toString();

					//solrQuery = solrQuery + " &&sort=_id desc";
					List<String> list = new ArrayList<>();
					list.add(solrQuery);
					solrQueryMap.put("mongoDBObjectCriteria", list);

				}

			}
			// This is case of only mongo search, no solr required, then append thsi to base query
			else if (!solrSearchRequired && preSolrMongoSearchRequired)
			{
				DBObject finalQuery = createPreSolrMongoDBObjectForAdvanceSearch(inputJsonObj, viewName);//createPreSolrMongoDBObject(inputJsonObj, viewName);
				//DBObject finalQuery1 = createMongoSearchDBObject(finalQuery);

//				solrQuery = finalQuery1.toString();
				solrQuery = finalQuery.toString();

				//solrQuery = solrQuery + " &&sort=_id desc";
				List<String> list = new ArrayList<>();
				list.add(solrQuery);
				solrQueryMap.put("mongoDBObjectCriteria", list);

			}

		}

		return solrQueryMap;

	}

	BasicDBObject getAdvancedSearchDateQuery(BasicDBObject inputJsonObj, DBObject finalBoxMatchCriteria  ){
	
		//BasicDBObject finalQuery = null;
		BasicDBObject finalBoxMatchCriteriaWithAdvSearchDates = null;
		try
		{
			finalBoxMatchCriteriaWithAdvSearchDates = (BasicDBObject)finalBoxMatchCriteria;
			
			if (inputJsonObj != null && StringUtils.isNotEmpty(inputJsonObj.toString()) && inputJsonObj.getString(ADVANCED_SEARCH_DATA) != null )
			{
				
				BasicDBObject inputJsonObj1 = BasicDBObject.parse(inputJsonObj.getString(ADVANCED_SEARCH_DATA));
			
				String startDate = inputJsonObj1.getString("startDt");
				String endDate = inputJsonObj1.getString("endDt");
	
				if (startDate != null && endDate != null)
				{
					finalBoxMatchCriteriaWithAdvSearchDates.put("modDate",new BasicDBObject("$gte", toDate(startDate, MONGO_UTC_FORMAT)).append("$lt", toDate(endDate, MONGO_UTC_FORMAT)));
				}
				else if (startDate != null) 
				{

					finalBoxMatchCriteriaWithAdvSearchDates.put("modDate",new BasicDBObject("$gte", toDate(startDate, MONGO_UTC_FORMAT)));
				}
				else if (endDate != null) 
				{

					finalBoxMatchCriteriaWithAdvSearchDates.put("modDate",new BasicDBObject("$lte", toDate(endDate, MONGO_UTC_FORMAT)));
				}
								
		
			}
			
		} catch (Exception e) 
		{
			subLogger.error("Error in getAdvancedSearchDateQuery", e);
		}
			
		return finalBoxMatchCriteriaWithAdvSearchDates;
	}

	private String appendSolrQuery(String solrQuery1, String content, boolean flag, String fieldName)
	{
		String solrQuery = solrQuery1;
		if (flag == true)
		{
			solrQuery = solrQuery + " && " + fieldName + ":" + content;
		}
		else
		{
			solrQuery = solrQuery + fieldName + ":" + content;
		}
		return solrQuery;
	}

	private DBObject createPreSolrMongoDBObject(BasicDBObject inputJsonObj, String viewName) throws CommunicatorException

	{
		List<String> reqTypeList = (List<String>) inputJsonObj.get(REQUEST_TYPE_LIST);
		List<Long> assignedGroupIdList = (List<Long>) inputJsonObj.get(ASSIGNED_GROUPID_LIST);
		List<String> tagList = (List<String>) inputJsonObj.get(TAG_LIST);
		List<String> userList = (List<String>) inputJsonObj.get(USER_LIST);
		List<String> statusList = (List<String>) inputJsonObj.get("statusList");
		List<String> resolverList = (List<String>) inputJsonObj.get(RESOLVER_LIST);
		String advSearchGFCID = (String) inputJsonObj.get("advSearchGFCID");
		String advSearchGFPID = (String) inputJsonObj.get(ADVANCED_SEARCH_GFPID);
		String exceptionId = inputJsonObj.getString("exceptionId");

	//	String startDate = inputJsonObj.getString("startDt");
	//	String endDate = inputJsonObj.getString("endDt");

		String inquiryId = inputJsonObj.getString(INQUIRY_ID);

		// C153176-839 - Add Root Cause, Processing Region to Advanced Search
		List<String> rootCauseList = (List<String>) inputJsonObj.get("rootCauseList");
		List<String> processingRegionList = (List<String>) inputJsonObj.get("processingRegionList");
		List<String> inquirySourceList = (List<String>) inputJsonObj.get("inquirySourceList");
		String queryCount = inputJsonObj.getString(QUERY_COUNT);
		String convCount = inputJsonObj.getString("convCount");
		boolean attachment = inputJsonObj.getBoolean("attachment");

		BasicDBList query = new BasicDBList();
		BasicDBObject dbObject = null;

		if (reqTypeList != null)
		{
			// dbObject = new BasicDBObject(REQUEST_TYPE, new BasicDBObject("$in", reqTypeList));
			dbObject = appendListTypeQueryForPreSolrMongo(reqTypeList, dbObject, REQUEST_TYPE);

		}
		if (assignedGroupIdList != null)
		{

			dbObject = appendListTypeQueryForPreSolrMongo(assignedGroupIdList, dbObject, ASSIGNED_GROUPID);
		}
		if (tagList != null)
		{
			dbObject = appendListTypeQueryForPreSolrMongo(tagList, dbObject, "tag");

		}
		if (userList != null)
		{
			dbObject = appendListTypeQueryForPreSolrMongo(userList, dbObject, ASSIGNED_USER_ID);

		}
		if (resolverList != null)
		{
			dbObject = appendListTypeQueryForPreSolrMongo(resolverList, dbObject, RESOLVER);
			dbObject.append(STATUS, RESOLVED);

		}
		if (rootCauseList != null)
		{
			dbObject = appendListTypeQueryForPreSolrMongo(rootCauseList, dbObject, ROOT_CAUSE);
		}
		if (processingRegionList != null)
		{
			dbObject = appendListTypeQueryForPreSolrMongo(processingRegionList, dbObject, PROCESSING_REGION);
		}
		if (inquirySourceList != null)
		{
			dbObject = appendListTypeQueryForPreSolrMongo(inquirySourceList, dbObject, INQUIRY_SOURCE);
		}
		if (StringUtils.isNotBlank(queryCount))
		{
			if(dbObject == null) dbObject = new BasicDBObject();
			dbObject.append(QUERY_COUNT, Long.valueOf(queryCount));
		}
		if (StringUtils.isNotBlank(convCount))
		{
			if(dbObject == null) dbObject = new BasicDBObject();
			dbObject.append("convCount", Integer.valueOf(convCount));
		}

		appendBoxTypeQueryForPreSolrMongo(viewName, dbObject);

		if (dbObject != null)
		{
			query.add(new BasicDBObject(WORKFLOWS, new BasicDBObject("$elemMatch", dbObject)));
		}

		if (statusList != null)//
		{
			query.add(new BasicDBObject(STATUS, new BasicDBObject("$in", statusList)));
		}

	/*	if (startDate != null)
		{
			Date dt = toDate(startDate, MONGO_UTC_FORMAT);
			query.add(new BasicDBObject(MODIFIED_DATE, new BasicDBObject("$gte", dt)));
		}
		if (endDate != null)
		{
			Date dt = toDate(endDate, MONGO_UTC_FORMAT);
			query.add(new BasicDBObject(MODIFIED_DATE, new BasicDBObject("$lte", dt)));
		}*/

		if (!StringUtils.isBlank(advSearchGFPID))
		{
			query.add(new BasicDBObject(GP_NAME, new BasicDBObject("$eq", advSearchGFPID)));
		}
		if (!StringUtils.isBlank(advSearchGFCID))
		{
			query.add(new BasicDBObject(GFC_ID, new BasicDBObject("$eq", advSearchGFCID)));
		}

		if (!StringUtils.isBlank(inquiryId))
		{
			query.add(new BasicDBObject("_id", Long.valueOf(inquiryId)));

		}
		else
		{
			// If inqiury id present ignore excetion id in search
			if (!StringUtils.isBlank(exceptionId))
			{
				query.add(new BasicDBObject("exceptionId", Long.valueOf(exceptionId)));

			}
		}
		if (attachment)
		{
			//query.add(new BasicDBObject(ATTACH_FLAG, new BasicDBObject("$eq", "Y")));
			query.add(new BasicDBObject("workflows.attchFlag", new BasicDBObject("$eq", "Y")));
		}

		DBObject finalQuery = new BasicDBObject("$and", query);

		// system.out.println("Print pre solr Mongo query"+ finalQuery);
		return finalQuery;

		// finalQuery = createSearchSolrList(solrOrMongoSearch, query);

		// return finalQuery;
	}
	
	/** To get the query to filter result set
	 * @param inputJsonObj
	 * @param viewName
	 * @return
	 * @throws CommunicatorException
	 */
	DBObject createPreSolrMongoDBObjectForAdvanceSearch(BasicDBObject inputJsonObj, String viewName) throws CommunicatorException

	{
		List<String> reqTypeList = (List<String>) inputJsonObj.get(REQUEST_TYPE_LIST);
		List<Long> assignedGroupIdList = (List<Long>) inputJsonObj.get(ASSIGNED_GROUPID_LIST);
		List<String> tagList = (List<String>) inputJsonObj.get(TAG_LIST);
		List<String> userList = (List<String>) inputJsonObj.get(USER_LIST);
		List<String> statusList = (List<String>) inputJsonObj.get("statusList");
		List<String> resolverList = (List<String>) inputJsonObj.get(RESOLVER_LIST);
		String advSearchGFCID = (String) inputJsonObj.get("advSearchGFCID");
		String advSearchGFPID = (String) inputJsonObj.get(ADVANCED_SEARCH_GFPID);
		String exceptionId = inputJsonObj.getString("exceptionId");

	//	String startDate = inputJsonObj.getString("startDt");
	//	String endDate = inputJsonObj.getString("endDt");

		//String inquiryId = inputJsonObj.getString(INQUIRY_ID);
		List<Long> inquiryIds = (List<Long>) inputJsonObj.get(INQUIRY_ID);
		// C153176-839 - Add Root Cause, Processing Region to Advanced Search
		List<String> rootCauseList = (List<String>) inputJsonObj.get("rootCauseList");
		List<String> processingRegionList = (List<String>) inputJsonObj.get("processingRegionList");
		List<String> inquirySourceList = (List<String>) inputJsonObj.get("inquirySourceList");
		String queryCount = inputJsonObj.getString(QUERY_COUNT);
		String convCount = inputJsonObj.getString("convCount");
		boolean attachment = inputJsonObj.getBoolean("attachment");

		BasicDBList query = new BasicDBList();
		BasicDBObject dbObject = new BasicDBObject();

		if (reqTypeList != null)
		{
			// dbObject = new BasicDBObject(REQUEST_TYPE, new BasicDBObject("$in", reqTypeList));
			dbObject = appendListTypeQueryForPreSolrMongo(reqTypeList, dbObject, "workflows.requestType");

		}
		if (assignedGroupIdList != null)
		{

			dbObject = appendListTypeQueryForPreSolrMongo(assignedGroupIdList, dbObject, "workflows.assignedGroupId");
		}
		if (tagList != null)
		{
			dbObject = appendListTypeQueryForPreSolrMongo(tagList, dbObject, "workflows.tag");

		}
		if (userList != null)
		{
			dbObject = appendListTypeQueryForPreSolrMongo(userList, dbObject, "workflows.assignedUserId");

		}
		if (resolverList != null)
		{
			dbObject = appendListTypeQueryForPreSolrMongo(resolverList, dbObject, "workflows.resolver");
			dbObject.append("workflows.status", RESOLVED);

		}
		if (rootCauseList != null)
		{
			dbObject = appendListTypeQueryForPreSolrMongo(rootCauseList, dbObject, "workflows.rootCause");
		}
		if (processingRegionList != null)
		{
			dbObject = appendListTypeQueryForPreSolrMongo(processingRegionList, dbObject, "workflows.processingRegion");
		}
		if (inquirySourceList != null)
		{
			dbObject = appendListTypeQueryForPreSolrMongo(inquirySourceList, dbObject, "workflows.inquirySource");
		}
		if (StringUtils.isNotBlank(queryCount))
		{
			if(dbObject == null) dbObject = new BasicDBObject();
			dbObject.append("workflows.queryCount", Long.valueOf(queryCount));
		}
		if (StringUtils.isNotBlank(convCount))
		{
			if(dbObject == null) dbObject = new BasicDBObject();
			dbObject.append("workflows.convCount", Integer.valueOf(convCount));
		}
		boolean isQma2 = false;
		if(null != inputJsonObj && null != inputJsonObj.get("isQma2") && inputJsonObj.getBoolean("isQma2")) {
			isQma2 = true;
		}
		appendBoxTypeQueryForPreSolrMongoForAdvanceSearch(viewName, dbObject, isQma2);

		if (dbObject != null)
		{
			query.add(dbObject);
		}

		if (statusList != null)//
		{
			query.add(new BasicDBObject("workflows.status", new BasicDBObject("$in", statusList)));
		}

	/*	if (startDate != null)
		{
			Date dt = toDate(startDate, MONGO_UTC_FORMAT);
			query.add(new BasicDBObject(MODIFIED_DATE, new BasicDBObject("$gte", dt)));
		}
		if (endDate != null)
		{
			Date dt = toDate(endDate, MONGO_UTC_FORMAT);
			query.add(new BasicDBObject(MODIFIED_DATE, new BasicDBObject("$lte", dt)));
		}*/

		if (!StringUtils.isBlank(advSearchGFPID))
		{
			query.add(new BasicDBObject(GP_NAME, new BasicDBObject("$eq", advSearchGFPID)));
		}
		if (!StringUtils.isBlank(advSearchGFCID))
		{
			query.add(new BasicDBObject(GFC_ID, new BasicDBObject("$eq", advSearchGFCID)));
		}

		if(null != inquiryIds && !inquiryIds.isEmpty()) {
			
			if(inquiryIds.size() == 1) {
				query.add(new BasicDBObject("_id", new BasicDBObject("$eq",inquiryIds.get(0))));
			}else {
				query.add(new BasicDBObject("_id",new BasicDBObject("$in", inquiryIds)));
			}
			
		}
		else
		{
			// If inqiury id present ignore excetion id in search
			if (!StringUtils.isBlank(exceptionId))
			{
				query.add(new BasicDBObject("exceptionId", Long.valueOf(exceptionId)));

			}
		}
		if (attachment)
		{
			//query.add(new BasicDBObject(ATTACH_FLAG, new BasicDBObject("$eq", "Y")));
			query.add(new BasicDBObject("workflows.attchFlag", new BasicDBObject("$eq", "Y")));
		}

		DBObject finalQuery = new BasicDBObject("$and", query);

		// system.out.println("Print pre solr Mongo query"+ finalQuery);
		return finalQuery;

		// finalQuery = createSearchSolrList(solrOrMongoSearch, query);

		// return finalQuery;
	}

	private List<String> createSolrSearchList(DBObject finalQuery)
	{

		// run inquiry query based on it and get dbobject condition and pass that.
		// DBCursor inqCur = database.getCollection(INQUIRY).find(finalQuery);
		DBCursor inqCur = databaseSecondary.getCollection(INQUIRY).find(finalQuery);

		StringBuffer buf = new StringBuffer();
		List<String> inquiryStrList = new ArrayList<>();
		String inquiryStr = null;
		int count=0;

		while (inqCur.hasNext())
		{

			DBObject inquiry = inqCur.next();
			Long inquiryId = (Long) inquiry.get("_id");

			buf.append(inquiryId + " ");
			count++;

			if(count % SOLR_QUERY_LIMIT==0)
			{
				inquiryStr = "(" + buf.toString() + ")";
				inquiryStrList.add(inquiryStr);
				buf = new StringBuffer();
			}

		}

		inqCur.close();

		if (buf.length() > 1)
		{

			inquiryStr = "(" + buf.toString() + ")";
		}
		else if (inquiryStrList.isEmpty())
		{
			// system.out.println("No inquiries found for advance preSolrMongo query");
			inquiryStr = "( -1 )";
		}
		inquiryStrList.add(inquiryStr);


		// system.out.println("SolrSearchQuery:" + inquiryStr);
		return inquiryStrList;
	}

	private DBObject createMongoSearchDBObject(DBObject finalQuery1)
	{
		DBObject finalQuery = finalQuery1;
		// run inquiry query based on it and get dbobject condition and pass that.
		// DBCursor inqCur = database.getCollection(INQUIRY).find(finalQuery);
		DBCursor inqCur = databaseSecondary.getCollection(INQUIRY).find(finalQuery);

		List<Long> inquiryList = new ArrayList<Long>();
		StringBuffer buf = new StringBuffer();

		while (inqCur.hasNext())
		{

			DBObject inquiry = inqCur.next();
			Long inquiryId = (Long) inquiry.get("_id");

			buf.append(inquiryId + " ");

			inquiryList.add(inquiryId);
		}

		inqCur.close();

		if (!inquiryList.isEmpty())
		{

			finalQuery = new BasicDBObject("_id", new BasicDBObject("$in", inquiryList));
		}
		else
		{
			// system.out.println("No inquiries found for advance MongoOnly query");
			inquiryList.add(-1L);
			finalQuery = new BasicDBObject("_id", new BasicDBObject("$in", inquiryList));
		}
		// system.out.println("mongosearchdbObject:" + finalQuery);
		return finalQuery;
	}

	private BasicDBObject appendListTypeQueryForPreSolrMongo(List<?> list, BasicDBObject dbObject1, String workflowField)
	{
		BasicDBObject dbObject = dbObject1;
		if (dbObject != null)
		{
			dbObject.append(workflowField, new BasicDBObject("$in", list));
		}
		else
		{
			dbObject = new BasicDBObject(workflowField, new BasicDBObject("$in", list));
		}
		return dbObject;
	}

	private void appendBoxTypeQueryForPreSolrMongo(String viewName, BasicDBObject dbObject)
	{
		if (dbObject != null && !StringUtils.isBlank(viewName) && viewName.equals(INBOX))
		{
			dbObject.append(STATUS, "Open").append(DIRECTION, "IN");
		}
		else if (dbObject != null && !StringUtils.isBlank(viewName) && viewName.equals("Outbox"))
		{
			dbObject.append(STATUS, "Open").append(DIRECTION, "OUT");
		}
		else if (dbObject != null && !StringUtils.isBlank(viewName) && viewName.equals(RESOLVED))
		{
			dbObject.append(STATUS, RESOLVED).append(DIRECTION, "IN");
		}
		else if (dbObject != null && !StringUtils.isBlank(viewName) && viewName.equals("Pending Approval"))
		{
			List<String> pndDirections=new ArrayList<String>();
			pndDirections.add(INQUIRY_DIRECTION_PENDING_APPROVAL);
			pndDirections.add(INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE);
			dbObject.append(STATUS, RESOLVED).append(DIRECTION, new BasicDBObject("$in", pndDirections));
		}
	}

	private void appendBoxTypeQueryForPreSolrMongoForAdvanceSearch(String viewName, BasicDBObject dbObject, boolean isQma2)
	{
		if (dbObject != null && !StringUtils.isBlank(viewName) && viewName.equals(INBOX))
		{
			dbObject.append("workflows.status", "Open").append("workflows.direction", "IN");
		}
		else if (dbObject != null && !StringUtils.isBlank(viewName) && viewName.equals("Outbox"))
		{
			dbObject.append("workflows.status", "Open").append("workflows.direction", "OUT");
		}
		else if (dbObject != null && !StringUtils.isBlank(viewName) && viewName.equals(RESOLVED))
		{
			dbObject.append("workflows.status", RESOLVED).append("workflows.direction", "IN");
		}
		else if (dbObject != null && !StringUtils.isBlank(viewName) && viewName.equals("Pending Approval"))
		{
			List<String> pndDirections=new ArrayList<String>();
			pndDirections.add(INQUIRY_DIRECTION_PENDING_APPROVAL);
			pndDirections.add(INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE);
			if(isQma2 && isWebSocketRedesignEnable()) {
				pndDirections.add("NOMINATE_OWNERSHIP");
				dbObject.append("workflows.status", "Open").append("workflows.direction", new BasicDBObject("$in", pndDirections));
			} else {
				dbObject.append("workflows.status", RESOLVED).append("workflows.direction", new BasicDBObject("$in", pndDirections));
			}
			
		}
	}

	private boolean isSolrSearchRequired(BasicDBObject inputJsonObj)
	{
		if (inputJsonObj != null)
		{
			String subject = inputJsonObj.getString(SUBJECT);
			String content = inputJsonObj.getString(CONTENT);
			// String inquiryId = inputJsonObj.getString(INQUIRY_ID);
			String originator = inputJsonObj.getString("originator");
			String memo = inputJsonObj.getString("memo");

			if (StringUtils.isNotBlank(subject) || StringUtils.isNotBlank(content)
					// || StringUtils.isNotBlank(inquiryId)
					|| StringUtils.isNotBlank(originator) || StringUtils.isNotBlank(memo))
			{
				return true;
			}
		}

		return false;
	}

	private boolean isPreSolrMongoSearchRequired(BasicDBObject inputJsonObj)
	{
		List<String> reqTypeList = (List<String>) inputJsonObj.get(REQUEST_TYPE_LIST);
		List<Long> assignedGroupIdList = (List<Long>) inputJsonObj.get(ASSIGNED_GROUPID_LIST);
		List<String> tagList = (List<String>) inputJsonObj.get(TAG_LIST);
		List<String> userList = (List<String>) inputJsonObj.get(USER_LIST);
		List<String> resolverList = (List<String>) inputJsonObj.get(RESOLVER_LIST);
		List<String> statusList = (List<String>) inputJsonObj.get("statusList");
	//	String crtDate = inputJsonObj.getString("startDt");
	//	String modDate = inputJsonObj.getString("endDt");
		String advSearchGFCID = (String) inputJsonObj.get("advSearchGFCID");
		String advSearchGFPID = (String) inputJsonObj.get(ADVANCED_SEARCH_GFPID);
		String exceptionId = inputJsonObj.getString("exceptionId");
		String inquiryId = inputJsonObj.getString(INQUIRY_ID);

		List<String> rootCauseList = (List<String>) inputJsonObj.get("rootCauseList");
		List<String> processingRegionList = (List<String>) inputJsonObj.get("processingRegionList");
		List<String> inquirySourceList = (List<String>) inputJsonObj.get("inquirySourceList");
		String queryCount = inputJsonObj.getString(QUERY_COUNT);
		String convCount = inputJsonObj.getString("convCount");
		boolean attachment = inputJsonObj.getBoolean("attachment");

	/*	if (reqTypeList != null || assignedGroupIdList != null || tagList != null || userList != null || statusList != null || crtDate != null || modDate != null || inquiryId != null
				|| resolverList != null || null != advSearchGFCID || null != advSearchGFPID || null != exceptionId
				|| rootCauseList != null || processingRegionList != null || inquirySourceList != null || queryCount != null || convCount != null)
		{
			return true;
		}*/
		
		if (reqTypeList != null || assignedGroupIdList != null || tagList != null || userList != null || statusList != null || inquiryId != null
				|| resolverList != null || null != advSearchGFCID || null != advSearchGFPID || null != exceptionId
				|| rootCauseList != null || processingRegionList != null || inquirySourceList != null || queryCount != null || convCount != null || attachment)
		{
			return true;
		}

		return false;

	}

	public static Date toDate(String inputDate, String format) throws CommunicatorException
	{
		SimpleDateFormat sDateFormat = new SimpleDateFormat(format);
		sDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		Date date = null;
		try
		{
			date = sDateFormat.parse(inputDate);

		}
		catch (ParseException e)
		{
			// return null;
			throw new CommunicatorException("Parsing Exception", e);
		}

		return date;
	}

	// [C153176-169] - Server-side export of inquiries
	// Method to export inquiries of selected view, to csv file
	public File exportGridViewDataToFile(String soeId, BasicDBObject inputJsonObj, boolean isRetrieveAll) throws CommunicatorException
	{
		BufferedWriter bw = null;
		FileWriter fw = null;
		long timestamp = System.currentTimeMillis();
		String fileName = "Export_id_" + timestamp + "_soeid_" + soeId+".csv";
		File file = GenericUtility.createFile(fileName);
		try
		{	
			if (!file.exists())
				file.createNewFile();
			fw = new FileWriter(file.getAbsoluteFile());
			bw = new BufferedWriter(fw);
			subLogger.info("exportGridViewDataToFile -- fetching grid view data.");
			getGridViewData(soeId, inputJsonObj, isRetrieveAll, bw);
		}
		catch (IOException e)
		{
			subLogger.error("IO Error in exportGridViewDataToFile while exporting file: " + fileName, e);
			throw new CommunicatorException("Error while exporting file: " + fileName, e);
		}
		catch (Exception e)
		{
			subLogger.error("Error in exportGridViewDataToFile while exporting file: " + fileName, e);
			throw new CommunicatorException("Error while exporting file: " + fileName, e);
		}
		finally
		{
			if (bw != null)
			{
				try
				{
					bw.close();
				}
				catch (IOException e)
				{
					subLogger.error("Error closing buffeed writer for file: " + fileName, e);
				}
			}
			if (fw != null)
			{
				try
				{
					fw.close();
				}
				catch (IOException ex)
				{
					subLogger.error("Error closing file writer for file: " + fileName, ex);
				}
			}
		}
		return file;
	}

	// [C153176-1082]-Enable de-escalate through context menu
	public Boolean deescalateInquiry(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException
	{
		boolean bSucess = Boolean.FALSE;
		List<Long> inquiryIds = null;
		try
		{
			if (inputJsonObj == null)
			{
				subLogger.error(" deescalate inputJsonObj can't be null: " + inputJsonObj);
				throw new CommunicatorException("Exception in getting the inputJsonObj for user= " + soeId);
			}
			inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);

			if (inquiryObjects == null || inquiryObjects.isEmpty())
			{
				subLogger.error("No Inquiries received for user={} as the inquiryObjs is null or empty {}", soeId,inquiryObjects); //<-- sonar fix null pointer
				throw new CommunicatorException("Exception in getting the inquiries for user= " + soeId);
			}
			List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			boolean isMultiGroupAction = inputJsonObj.getBoolean(IS_MULTI_GROUP_ACTION_KEY);
			String commonGroupId = inputJsonObj.getString(COMMON_GROUP_ID_KEY);
			String action = inputJsonObj.getString("action")== null ? ACTION_DEESCALATE : inputJsonObj.getString("action");
			if (inquiryIds.size() != groupIds.size())
			{
				subLogger.info("Invalid Input for deescalate action -" + " by " + soeId + ". InquiryIdList size and groupIdList size do not match.");
				throw new CommunicatorException("InquiryIdList size - [" + inquiryIds.size() + "] and groupIdList size - [" + groupIds.size() + "] do not match for Lock/UnLock.");
			}
			Map<Long, String> inquiryGroupIdMap = populateInquiryGrpMapForMultiGrpAction(action,  groupIds, isMultiGroupAction);
			Date currentTime = new Date();
			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, action);
			inquiryUpdateDBObj.put(WORKFLOWS_ACTION, action);
			DBObject inquiryUnsetDBObj = new BasicDBObject(WORKFLOWS_CONV_COUNT_ESCALATION, "");
			inquiryUnsetDBObj.put(WORKFLOWS_CONV_COUNT_ESCALATION, "");
			inquiryUnsetDBObj.put(WORKFLOWS_RESPONSE_TIME_ESCALATION, "");
			inquiryUnsetDBObj.put(WORKFLOWS_RESPONSE_TIME_NEXT_ESACLATION, "");
			inquiryUnsetDBObj.put(WORKFLOWS_RESPONSE_TIME_ESCALATION_REASON, "");
			inquiryUnsetDBObj.put(WORKFLOWS_CLIENT_CHASE_ESCALATION, "");
			inquiryUnsetDBObj.put(WORKFLOWS_SUBJECT_ESCALATION, "");
			inquiryUnsetDBObj.put(WORKFLOWS_GENERAL_ESCALATION_REASON, "");
			inquiryUnsetDBObj.put(WORKFLOWS_ISPENDINGAPPROVAL_ESCALATION, "");
			inquiryUnsetDBObj.put(WORKFLOWS_MANUAL_ESCALATION, "");
			inquiryUnsetDBObj.put(WORKFLOWS_MANUAL_ESCALATION_REASON, "");
			inquiryUnsetDBObj.put(WORKFLOWS_ACK_ESCALATION, "");
			inquiryUnsetDBObj.put(WORKFLOWS_ACK_ESCALATION_BY, "");
			inquiryUnsetDBObj.put(WORKFLOWS_ACK_ESCALATION_TIME, "");

			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfoMap =  populateInquiryInfoMap(dbObjs,null,null);

			bSucess = bulkMultiGroupAction(soeId, inquiryObjects, isMultiGroupAction, inquiryGroupIdMap, commonGroupId, action, inquiryUpdateDBObj, inquiryUnsetDBObj, inquiryInfoMap);
		}
		catch (Exception e)
		{
			subLogger.error("Exception while Deescalating inquiry for user= " + soeId, e);
			throw new CommunicatorException("Exception while Deescalating inquiry for user= " + soeId, e);
		}
		return bSucess;
	}


	/**
	 * @param bw
	 * @param currOutput
	 * @param dateFormat
	 * @param viewName
	 * @param viewType
	 * @param gridViewTO
	 * @param soeid 
	 * @param isQMA22Origin 
	 * @param inputJsonObj 
	 * @throws IOException
	 *  Method to write DBObject inquiries to csv file
	 */
	private void writeGridViewDataToFile(BufferedWriter bw, Cursor currOutput, String dateFormat, String viewName,  String viewType, DBObject gridViewTO, String soeid, boolean isQMA22Origin, BasicDBObject inputJsonObj) throws IOException
	{
		BasicDBList columnDefList = DataConversionUtil.convertJsonToBasicDBList((String) gridViewTO.get(COLUMN_DEFS));
		boolean isColToShow = false;
		if(null!=inputJsonObj && null!=inputJsonObj.get("colToShow") && inputJsonObj.getBoolean("colToShow")) {
			isColToShow = true;
		}
		if(isQMA22Origin && !isColToShow){
			columnDefList = getColumnConfigQMA2(gridViewTO,viewName, soeid);
		}
		if (currOutput != null) {
			List<String> fieldNameList = new ArrayList<String>();
			StringBuffer sb = new StringBuffer();
			boolean isInquiryStateReq = false;
			subLogger.info("writeGridViewDataToFile -- writing data to file for viewType: " + viewType);
			EscalationUtility escalationUtility = new EscalationUtility();

			// Flag to append inquiry state for GLOBALSEARCH.TYPE and
			// FOLDER.TYPE, as per logic in ui
			if ((!StringUtils.isBlank(viewType) && ("4".equals(viewType) || "5".equals(viewType)))
					|| (StringUtils.isBlank(viewType) && SEARCH.equalsIgnoreCase(viewName))) {
				isInquiryStateReq = true;
			}

			if (columnDefList != null) {
				sb.append("'");
				for (Object columnDef : columnDefList) {
					if (columnDef != null) {
						String title = (String) ((BasicDBObject) columnDef).get("title");
						String fieldName = (String) ((BasicDBObject) columnDef).get("field");
						fieldNameList.add(fieldName);
						// Escaping special characters
						title = title == null ? "" : StringEscapeUtils.escapeCsv(title);
						sb.append(title + EXPORT_CSV_DELIMITER);
					}
				}

				// Appending " ' " to first column name, to prevent SYLK error
				// if first column is ID.
				sb.append("'");
				if (isInquiryStateReq) {
					sb.append("State" + EXPORT_CSV_DELIMITER);
				}
				sb.append(EXPORT_CSV_NEWLINE);
				bw.write(sb.toString());

				
				boolean ageConfigEnabled = false;
				QMACache qmaCache =  QMACacheFactory.getCache();
				if( null != qmaCache.getConfigById("enableAgeBasedCalculation") ) {
					Config ageConfig = qmaCache.getConfigById("enableAgeBasedCalculation");
					if( ageConfig.isEnableAgeBasedCalculation() ) {
						ageConfigEnabled = true;
					}
				}
				
				while (currOutput.hasNext()) {
					DBObject currInqObj = currOutput.next();
					DBObject inquiry = getInquiryGroupLevelResponse(currInqObj, false, null, isQMA22Origin, false);
					if (inquiry != null) {
						sb = new StringBuffer();

						String mailBoxDirection = null;

						if (isInquiryStateReq) {
							mailBoxDirection = setInquiryMailBoxDirection((BasicDBObject) inquiry);
							// Filtering out inquiries with no mailBoxDirection
							// Assigned, like direction = OUT and statues =
							// Resolved
							if (mailBoxDirection == null) {
								continue;
							}
						}
						BasicDBList workflows = (BasicDBList) inquiry.get(WORKFLOWS);
						BasicDBObject workflow = null;
						Object assignedGrpId =null;
						if(workflows!=null && null != workflows.get(0)) {
							workflow = (BasicDBObject)workflows.get(0);
							assignedGrpId = workflow.get(ASSIGNED_GROUPID);
						}
						if(ageConfigEnabled) {
							AgeAndTimeUtils.updateAgeData(assignedGrpId, (BasicDBObject) workflow);
						}
						
						for (String field : fieldNameList) {
							if (!StringUtils.isBlank(field)) {
								Object dbFieldValue = inquiry.get(field);
								String fieldValue = "";
								if (!StringUtils.isBlank(dateFormat) && dbFieldValue != null
										&& dbFieldValue instanceof Date) {
									String javaDateFormat = dateFormat.replace("tt", "a") + " z";
									// Converting to SimpleDateFormat string and appending time zone
									SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat(javaDateFormat);
									localSimpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
									fieldValue = localSimpleDateFormat.format(dbFieldValue);
								} else if (dbFieldValue != null) {
									fieldValue = String.valueOf(dbFieldValue);
								}
								// C170665-445 Client Category doesnt shown on download
								if (CLNT_CSTM_CATEGORY.equalsIgnoreCase(field)) {
									fieldValue = getClientCategory(inquiry, viewName);
								}
								/*Enable below code for shift and time calculation*/
								if ("age".equalsIgnoreCase(field)) {
									fieldValue = ageConfigEnabled && null != workflow.getString(AGE_IN_DAYS) ? workflow.getString(AGE_IN_DAYS) : getInquiryVersionAge((BasicDBObject) inquiry, CREATED_DATE);
								} else if (AGE_IN_HRS.equalsIgnoreCase(field)) {
									fieldValue = ageConfigEnabled && null != workflow.getString(AGE_IN_HRS) ? workflow.getString(AGE_IN_HRS) : "";
								} else if (RE_OPEN_AGE.equalsIgnoreCase(field)) {
									fieldValue = ageConfigEnabled && null != workflow.getString(RE_OPEN_AGE_IN_DAYS) ? workflow.getString(RE_OPEN_AGE_IN_DAYS) : getInquiryVersionAge((BasicDBObject) inquiry, REOPEN_DATE);
								} else if (RE_OPEN_AGE_IN_HRS.equalsIgnoreCase(field)) {
									fieldValue = ageConfigEnabled && null != workflow.getString(RE_OPEN_AGE_IN_HRS) ? workflow.getString(RE_OPEN_AGE_IN_HRS) : "";
								}
								else if (USER_NOTES.equalsIgnoreCase(field)) {
									fieldValue = getRecentNote(inquiry);
								}
								// Setting age field
								/*if ("age".equalsIgnoreCase(field)) {
									fieldValue = getInquiryVersionAge((BasicDBObject) inquiry, CREATED_DATE);
								} else if (AGE_IN_HRS.equalsIgnoreCase(field)) {
									fieldValue = "";
								} else if (RE_OPEN_AGE.equalsIgnoreCase(field)) {
									fieldValue = getInquiryVersionAge((BasicDBObject) inquiry, REOPEN_DATE);
								} else if (RE_OPEN_AGE_IN_HRS.equalsIgnoreCase(field)) {
									fieldValue = "";
								} */else if ("isEscalated".equalsIgnoreCase(field)) {
									fieldValue = escalationUtility
											.getInquiryEscalationReasonForGroup((BasicDBObject) inquiry);
								} else if ("responseTimeQMA".equalsIgnoreCase(field)) {
									Long responseTime = (Long) inquiry.get("responseTimeQMA");
									if (null != responseTime) {
										fieldValue = GenericUtility.convertSecsToDayHourMin(responseTime.longValue());
									}
								} else if ("avgResponseTimeQMA".equalsIgnoreCase(field)) {
									Long responseTime = (Long) inquiry.get("responseTimeQMA");
									Integer replyCount = (Integer) inquiry.get("replyCountQMA");
									if (null != responseTime && null != replyCount && replyCount > 0) {
										Long tempVal = responseTime / replyCount;
										tempVal = tempVal == null ? 0L : tempVal;
										fieldValue = GenericUtility.convertSecsToDayHourMin(tempVal.longValue());
									}
								} else if ("avgResolutionTimeQMA".equalsIgnoreCase(field)) {
									Long totalResTime = (Long) inquiry.get("totalResolveTimeQMA");
									Integer resolveCount = (Integer) inquiry.get("resolveCountQMA");
									if (null != totalResTime && null != resolveCount && resolveCount > 0) {
										Long tempVal = totalResTime / resolveCount;
										tempVal = tempVal == null ? 0L : tempVal;
										fieldValue = GenericUtility.convertSecsToDayHourMin(tempVal.longValue());
									}
								}else if("followUp".equalsIgnoreCase(field) && null != dbFieldValue){
									BasicDBObject followUp = (BasicDBObject) dbFieldValue;
									fieldValue = followUp.getString("flag");
								} 
								
								// Escaping special characters
								fieldValue = StringEscapeUtils.escapeCsv(fieldValue);
								sb.append(fieldValue + EXPORT_CSV_DELIMITER);
							}
						}
						if (isInquiryStateReq && !StringUtils.isBlank(mailBoxDirection)) {
							sb.append(mailBoxDirection + EXPORT_CSV_DELIMITER);
						}
						sb.append(EXPORT_CSV_NEWLINE);
						bw.write(sb.toString());
					}
				}
			}
		}
	}
	/**
	 * @param inquiry
	 * @param viewName
	 * @return
	 */
	private String getClientCategory(DBObject inquiry, String viewName) {
		String clientCategory = "";
		try {
			//Check for inquiry marked for Other
			clientCategory = checkIfOtherCategory(inquiry);
			//Check for System Client category
			clientCategory = checkForSystemCategory(inquiry, clientCategory);
			//Override if System category with custom category
			clientCategory = checkForCustomCategory(inquiry, viewName, clientCategory);
		} catch (Exception e) {
			subLogger.error("Exception while getting client category:",e);
		}
		return clientCategory;
	} 

	/**
	 * @param inquiry
	 * @param viewName
	 * @return
	 */
	private String getRecentNote(DBObject inquiry) {
		String recentNote = "";
		BasicDBList userNotes = new BasicDBList();
		try {
			if (null != inquiry && null != inquiry.get(USER_NOTES)) {
				userNotes = (BasicDBList) inquiry.get(USER_NOTES);
				if (userNotes != null && userNotes.size() > 0) {
					if (null != userNotes.get(userNotes.size() - 1)
						&& ((DBObject) userNotes.get(userNotes.size() - 1)).containsField("comments")
						&& null !=((DBObject) userNotes.get(userNotes.size() - 1)).get("comments")) {
						recentNote = (String) ((DBObject) userNotes.get(userNotes.size() - 1)).get("comments");
					}
				}
			}

		} catch (Exception e) {
			subLogger.warn("Exception while getRecentNote:", e);
		}
		return recentNote;
	}
	/**
	 * This method used to get custom client category
	 * @param inquiry
	 * @param viewName
	 * @param clientCategoryPrevious 
	 * @param clientCategory
	 * @return
	 */
	private String checkForCustomCategory(DBObject inquiry, String viewName, String clientCategoryPrevious) {
		String clientCategory = clientCategoryPrevious;
		BasicDBList workflows = (BasicDBList) inquiry.get(WORKFLOWS);
		BasicDBObject workflow = null;
		Object assignedGrpId =null;
		if(workflows!=null && null != workflows.get(0) && !INTENSITY_HEAT_MAP.equalsIgnoreCase(viewName)) {
			workflow = (BasicDBObject)workflows.get(0);
			if(null != workflow.get(CUSTOM_CLIENT_CATEGORY)) {
				BasicDBList customCategoryList = (BasicDBList) workflow.get(CUSTOM_CLIENT_CATEGORY);
				if(null != customCategoryList && null != customCategoryList.get(0)) {
					BasicDBObject categoryObject = (BasicDBObject) customCategoryList.get(0);
					clientCategory = categoryObject.getString(CATEGORY_NAME);
				}
			}
		}
		return clientCategory;
	}

	/**
	 * Method used to get System level category Platinum, Priority
	 * @param inquiry
	 * @param clientCategoryPrevious 
	 * @param clientCategory
	 * @return
	 */
	private String checkForSystemCategory(DBObject inquiry, String clientCategoryPrevious) {
		String clientCategory = clientCategoryPrevious;
		if(null != inquiry.get(CLIENT_PRIORITY)) {
			clientCategory = (String) inquiry.get(CLIENT_PRIORITY);
		}
		return clientCategory;
	}

	/**
	 * Method used to get no category defined so consider as other
	 * @param inquiry
	 * @param clientCategory
	 * @return
	 */
	private String checkIfOtherCategory(DBObject inquiry) {
		String clientCategory = "";
		BasicDBList workflows = (BasicDBList) inquiry.get(WORKFLOWS);
		BasicDBObject workflow = null;
		Object assignedGrpId =null;
		if(workflows!=null && null != workflows.get(0)) {
			workflow = (BasicDBObject)workflows.get(0);
			if(null != workflow.get(CLIENT_CATEGORY)) {
				BasicDBObject categoryObject = (BasicDBObject) workflow.get(CLIENT_CATEGORY);
				if(null != categoryObject.get(CATEGORY_NAME))
				clientCategory = categoryObject.getString(CATEGORY_NAME);
			}
		}
		return clientCategory;
	}

	/**
	 * This method will return columnConfig defined QMA2 agrid views
	 * @param gridViewTO
	 * @param viewName
	 * @param soeId
	 * @return
	 */
	private BasicDBList getColumnConfigQMA2(DBObject gridViewTO, String viewName, String soeId) {
		BasicDBList finalColumnDefList = new BasicDBList();
		try {
			BasicDBObject columnConfigObj = (BasicDBObject) gridViewTO.get(COLUMN_CONFIG);
			String columnConfigString = (String)columnConfigObj.get(COLUMN_CONFIG);
			CustomColumnsView customColumnsView = (CustomColumnsView) DataConversionUtil.convertJSONToJava(columnConfigString, CustomColumnsView.class);
			List<Map<String, Object>> columnConfigList = customColumnsView.getColumnConfig();
			for(Map<String, Object> columConfigMap:columnConfigList){
				if (null != columConfigMap.get(HIDE_KEY) && null != columConfigMap.get(COL_ID)) {
					Boolean hide = (Boolean) columConfigMap.get(HIDE_KEY);
					String colId = (String) columConfigMap.get(COL_ID);
					String displayName = getColumnDisplayName(columConfigMap, colId);
					if(!StringUtils.isEmpty(displayName) && displayName.equals("ANNEX")){
						getAnnexColumnConfig(finalColumnDefList);				
					}else{
						prepareColumnConfigList(finalColumnDefList, columConfigMap, hide, colId, displayName);
					}
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in InquiryDAO.getColumnConfigQMA2:",e);
		}
		return finalColumnDefList;
	}

	/**
	 * This method will prepare finalColumnDefList for QMA2
	 * @param finalColumnDefList
	 * @param columConfigMap
	 * @param hide
	 * @param colId
	 * @param displayName
	 */
	private void prepareColumnConfigList(BasicDBList finalColumnDefList, Map<String, Object> columConfigMap,
			Boolean hide, String colId, String displayName) {
		if (!(hide) && !StringUtils.isEmpty(displayName)) {
			BasicDBObject basicDBObject = new BasicDBObject();
			basicDBObject.put("title", displayName);
			if(colId.contains(".$date")){
				String dateColId = colId.replace(".$date", "");
				basicDBObject.put("field", dateColId);
			}else{
				basicDBObject.put("field", colId);
			}
			basicDBObject.put("width", columConfigMap.get("width"));
			finalColumnDefList.add(basicDBObject);
		}
	}

	private void getAnnexColumnConfig(BasicDBList finalColumnDefList) {
		//Followup Attachment	Escalation	Notes	Suggestion Indicator	Urgent
		Map<String, String> annexColMap = new HashMap<>();
		annexColMap.put("Followup", "followUp");
		annexColMap.put("Attachment", "attchFlag");
		annexColMap.put("Escalation", "isEscalated");
		annexColMap.put("Notes", "notesFlag");
		annexColMap.put("Suggestion Indicator", "suggestionIndicator");
		annexColMap.put("Urgent", "urgentFlag");
		annexColMap.put("Auto Assigned", AUTO_ASSIGNED);
		for(Entry<String, String> entry :annexColMap.entrySet()){
			BasicDBObject basicDBObject = new BasicDBObject();
			basicDBObject.put("title", entry.getKey());
			basicDBObject.put("field", entry.getValue());
			basicDBObject.put("width", "0");
			finalColumnDefList.add(basicDBObject);
		}
	}
	
	/**
	 * This method will return display name, if available in saved column config
	 * else fetch from default aggrid column config
	 * @param columConfigMap
	 * @param colId
	 * @return
	 */
	private String getColumnDisplayName(Map<String, Object> columConfigMap, String colId) {
		String displayName;
		if(null != columConfigMap.get(HEADER_NAME)){
			displayName =  (String) columConfigMap.get(HEADER_NAME);
		}else{
			displayName =  getDisplyNameFromDefaultConfig(colId);
		}
		return displayName;
	}

	/**
	 * This method fetch Display name from master column def
	 * @param colId
	 * @return
	 */
	private String getDisplyNameFromDefaultConfig(String colId) {
		List<Map<String, Object>> columnDefList = QMACacheFactory.getCache().getConfigById("masterColumnDefAgGrid").getMasterColumnDefAgGrid();
		for(Map<String, Object> columnMap:columnDefList){
			if(null != columnMap.get(COL_ID) && null != columnMap.get(HEADER_NAME) && columnMap.get(COL_ID).equals(colId)){
				return (String) columnMap.get(HEADER_NAME);
			}
		}
		return null;
	}

	// Returns the mailBoxDirection of inquiry version, to be displayed as 'State'
	private String setInquiryMailBoxDirection(BasicDBObject inquiry)
	{
		// "direction" and "status" are set as worflows.direction and workflows.status by getInquiryGroupLevelResponse() method, for each version
		String mailBoxDirection = null;
		String direction = inquiry.getString(DIRECTION);
		String status = inquiry.getString(STATUS);

		if (INQUIRY_DIRECTION_IN.equalsIgnoreCase(direction))
		{
			mailBoxDirection = AppserverConstants.INBOX;

			// If inquiry direction is IN check for inquiry status if RESOLVED it will go to RESOLVED BOX else INBOX.
			if (STATUS_RESOLVE.equalsIgnoreCase(status))
			{
				mailBoxDirection = AppserverConstants.RESOLVEDBOX;
			}
		}
		else if (INQUIRY_DIRECTION_OUT.equalsIgnoreCase(direction))
		{
			mailBoxDirection = AppserverConstants.OUTBOX;
		}
		else if (INQUIRY_DIRECTION_PENDING_APPROVAL.equalsIgnoreCase(direction)||INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE.equalsIgnoreCase(direction))
		{
			mailBoxDirection = AppserverConstants.PENDINGAPPROVAL;
		}
		return mailBoxDirection;
	}

	// Returns the inquiry age/reopen-age as string
	private String getInquiryVersionAge(BasicDBObject inquiry, String startDateField)
	{
		String ageString = "";
		BasicDBList workflows = (BasicDBList) inquiry.get(WORKFLOWS);

		if (workflows != null && workflows.get(0) != null)
		{
			Date createdDate = (Date) ((BasicDBObject) workflows.get(0)).get(startDateField);
			createdDate = updateWithReAgeDateIfPresent(startDateField, workflows, createdDate);

			long createdDateInMillis = 0;
			long modifiedDateInMillis = 0;

			if (createdDate != null)
			{
				double age = 0;
				createdDateInMillis = createdDate.getTime();

				String status = (String) ((BasicDBObject) workflows.get(0)).get(STATUS);
				if (STATUS_RESOLVE.equalsIgnoreCase(status) && CREATED_DATE.equalsIgnoreCase(startDateField))
				{
					Date modDate = (Date) ((BasicDBObject) workflows.get(0)).get(MODIFIED_DATE);
					if (modDate != null)
					{
						modifiedDateInMillis = modDate.getTime();
					}
				}
				else
				{
					modifiedDateInMillis = System.currentTimeMillis();
				}

				age = DateUtil.getInquiryAge(createdDateInMillis, modifiedDateInMillis);
				ageString = String.valueOf(age);
			}

		}
		return ageString;
	}

	private Date updateWithReAgeDateIfPresent(String startDateField, BasicDBList workflows, Date createdDate)
	{
		if(CREATED_DATE.equals(startDateField)){
			Date reAgeDate = (Date) ((BasicDBObject) workflows.get(0)).get("reAgeDate");
			createdDate=(reAgeDate==null)?createdDate:reAgeDate;
		}
		return createdDate;
	}

	// [C153176-160] Saved Search filter criteria is not working for all columns
	// dateFormat is the format of the date which needs to be converted e.g. dd/MMM/yyyy
	public void getBsonObjForUserCtrWithDateObj(DBObject jsonObj, String dateFormat)
	{
		//list of dateColumns
		for (Object key : jsonObj.keySet())
		{
			// based on you key types
			String keyStr = (String) key;
			Object keyvalue = jsonObj.get(keyStr);

			// Print key and value
			//subLogger.info(" getBsonObjForUserCtrWithDateObj key1: " + keyStr + " value1: " + keyvalue);

			// for nested objects iteration if required
			// add all columns which can be filters for saved search and are of type Date
			if (!StringUtils.isBlank(keyStr) && ( keyStr.contains(CREATED_DATE)|| keyStr.contains(MODIFIED_DATE) || keyStr.contains(RESOLVE_TIME) || keyStr.contains(LAST_ACTION_TIME) || keyStr.contains(REAGE_DATE) || keyStr.contains(REOPEN_DATE))) 
			{
				DBObject dateObject = (DBObject) keyvalue;
				for (String dateKey : dateObject.keySet())
				{
					//subLogger.info("getBsonObjForUserCtrWithDateObj key2: " + dateKey + " value2: " + dateObject.get(dateKey));
					if ("$lte".equals(dateKey) || "$gte".equals(dateKey) || "$lt".equals(dateKey) || "$gt".equals(dateKey))
					{
						SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
						/* [C170665-1597] - In saved views UI criteria carries below date format and gets data out of provided date range*/
						//simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
						Date dt = null;
						try
						{
							Calendar c = Calendar.getInstance();
							TimeZone timeZone = c.getTimeZone();
							simpleDateFormat.setTimeZone(timeZone);
							dt = simpleDateFormat.parse((String) dateObject.get(dateKey));
						}
						catch (ParseException e)
						{
							dt = null;
						}
						/* query.add(new BasicDBObject(MODIFIED_DATE, new BasicDBObject("$lte", dt))); */
						dateObject.put(dateKey, dt);

					}
					else if ("$nin".equals(dateKey))
					{
						dateObject.put(dateKey, dateObject.get(dateKey));
					}

				}
				jsonObj.put(keyStr, dateObject);
			}
			if (keyvalue instanceof DBObject object)
				getBsonObjForUserCtrWithDateObj(object, dateFormat);
		}
	}

	private void replaceInlineImgOldUrlWithNew(List<Conversation> convList)
	{
		if (null != convList && !convList.isEmpty())
		{
			for (Conversation conv : convList)
			{
				Date convCrtDt = conv.getCrtDate();
				Date convCreatedBefore = QMACacheFactory.getCache().getDefaultStaticData().getConversationCreatedBefore();
				String content = GenericUtility.checkAndFetchConvContent(conv);
				if (!StringUtils.isBlank(content) && null != convCreatedBefore && null != convCrtDt && convCrtDt.before(convCreatedBefore))
				{
					String newContent = content.replaceAll("/XStreamCommunicator/rest", GenericUtility.getAppServerContextFromDB()+"/rest");
					conv.setContent(newContent);
				}
			}
		}

	}

	private boolean bulkAssignProcessingRegion(String soeId, Set<Long> assignToGroupIds, String processingRegion, List<Inquiry> inquiryObjects, Map<Long, ActionStatistics> inquiryInfoMap) throws CommunicatorException// Sonar Fix -- Define and
	{
		subLogger.info("bulkAssignProcessingRegion for Inquiries size=" + inquiryObjects.size() + " , fromGrp=" + assignToGroupIds + ",processingRegion=" + processingRegion);
		boolean bSuccess = Boolean.FALSE;

		DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
		BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();

		DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
		BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();

		Date currentTime = new Date();
		boolean isMultiGroupOperation = assignToGroupIds != null && !assignToGroupIds.isEmpty();// Sonar Fix -- remove useless parenthesis

		if (isMultiGroupOperation)
		{
			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, ACTION_ASSIGN_PROCESSING_REGION);
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			String userName = userInfoMap.get(soeId.toUpperCase()).getName();
			inquiryUpdateDBObj.put(WORKFLOWS_PROCESSING_REGION, processingRegion);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
			inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_ASSIGN_PROCESSING_REGION);
			boolean isBulkAction= inquiryObjects != null && inquiryObjects.size() > 1 ;
			Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
			
			for (Inquiry inqObj : inquiryObjects)
			{
				for (Long assignToGroupId : assignToGroupIds)
				{

					DBObject workflowAudit = createWorkFlowsAuditJavaDriver(assignToGroupId, ACTION_ASSIGN_PROCESSING_REGION, processingRegion, soeId, currentTime, groupIdToNameMap, userInfoMap);

					workflowAudit.put(INQUIRY_ID, inqObj.id);
					workflowAudit.put(GROUP_ID, assignToGroupId);
					//Modified for requestType in Action Statistics - C153176-1155
					//DBObject stats = getStatsObject(soeId, ACTION_ASSIGN_PROCESSING_REGION, currentTime, inqObj, assignToGroupId, inquiryObjects);

					ActionStatistics statsObj = inquiryInfoMap.get(inqObj.id+assignToGroupId);
					DBObject stats = getStatsObject(soeId, ACTION_ASSIGN_PROCESSING_REGION, currentTime, inqObj, assignToGroupId, isBulkAction, statsObj, groupIdToNameMap, userInfoMap);

					DBObject updateDBFields = new BasicDBObject();
					// Update inquiry fields
					updateDBFields.put("$set", inquiryUpdateDBObj);
					// Create new Audit for the action
					DBObject updateWorkAuditFields = new BasicDBObject();
					updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));

					DBObject findINQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN, false);
					// C153176-368-Resolved Inquiry Cannot be found with OUT version
					DBObject findOUTQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_OUT, false);

					// C153176-427 Ability to take all actions from Resolved Box
					// DBObject findRESOLVEINQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_RESOLVE, INQUIRY_DIRECTION_IN);
					// C153176-427 Ability to take all actions from Resolved Box
					// DBObject findRESOLVEOUTQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_RESOLVE, INQUIRY_DIRECTION_OUT,false);

					DBObject findWorkAuditflowQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN_OR_OUT, false);
					// Add to bulk
					bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);
					bulkInquiryUpdOp.find(findOUTQuery).update(updateDBFields);
					bulkStatsInsertdOp.insert(stats);
					subLogger.info("ActionStatistics Saved for action 7" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
					bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);
				}

			}
		}
		// Execute
		if (!inquiryObjects.isEmpty())
		{
			bulkInquiryUpdOp.execute();
			bulkStatsInsertdOp.execute();

		}
		bSuccess = Boolean.TRUE;
		return bSuccess;
	}

	public boolean isInquiryRefSent(Inquiry dbInquiry, Long fromGroupId)
	{
		List<Workflow> dbWorkFlowList = dbInquiry.getWorkflows();
			
		boolean inquiryRefToBeSent = false;
		
		boolean isInquiryRefReqForGroup = false;
		Map<Long, Group> allGroupsMap = QMACacheFactory.getCache().getAllGroupsMap();

		if (allGroupsMap != null && !allGroupsMap.isEmpty() && allGroupsMap.get(fromGroupId) != null && allGroupsMap.get(fromGroupId).getIsInqReferenceIdReq() != null)
		{
			isInquiryRefReqForGroup = allGroupsMap.get(fromGroupId).getIsInqReferenceIdReq();
			// isFirstReplyFromGroup = isInquiryRefReqForGroup; //Checking for first reply only if isInquiryRefReq is true for group
		}
		
		if (isInquiryRefReqForGroup &&  null == dbWorkFlowList){
			inquiryRefToBeSent =isInquiryRefReqForGroup;
		}

		else if (isInquiryRefReqForGroup && dbWorkFlowList != null && !dbWorkFlowList.isEmpty())
		{
			for (Workflow workflow : dbWorkFlowList)
			{
				if (workflow != null && fromGroupId.equals(workflow.getAssignedGroupId()))
				{
					if ("Y".equalsIgnoreCase(workflow.getInquiryRefSent()))// && (INQUIRY_DIRECTION_OUT.equalsIgnoreCase(workflow.getDirection()) ||
						// INQUIRY_DIRECTION_PENDING_APPROVAL.equalsIgnoreCase(workflow.getDirection())))
					{
						inquiryRefToBeSent=false;
						break;
					}
					else
					{// setting it , as later it should be true
						workflow.setInquiryRefSent("Y");
						inquiryRefToBeSent=true;
					}
				}
			}
		}

		return inquiryRefToBeSent;
	}

	public String updateContentForFirstResponseFromGroup_new(Inquiry dbInquiry, Long fromGroupId, String conversationContent)
	{
			
		
		boolean isInquiryRefSent = isInquiryRefSent(dbInquiry, fromGroupId);

		if (isInquiryRefSent)
		{
			String inquiryRef = INQUIRY_REF_ID_STRING.replace("[INQUIRY_ID]", "" + dbInquiry.getId());
			boolean isRefAlreadtExists = conversationContent.contains(MATCH_INQUIRY_REF_ID_STRING);
			if(! isRefAlreadtExists)
				conversationContent = conversationContent + inquiryRef;
		}
		return conversationContent;
	}

	public BasicDBObject getExceptionByIdCSL(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		String expId = inputJsonObj.getString("exceptionId");
		String url = QMACacheFactory.getCache().getCslRestServerUrl() + "/getExceptionById/" + expId;
		subLogger.info("CSL URL : " + url + " for ExceptionId:= " + expId);
		URL connection = null;
		BasicDBObject response = new BasicDBObject();
		try
		{
			connection = URI.create(url).toURL();
			InputStream in = connection.openStream();
			// Parse JSON Output from CSL response
			response = parse(in);
		}
		catch (Exception e)
		{
			subLogger.error("Error while reading the from CSL for ExceptionId:= " + expId+", soeid: "+soeId);
			// throw new CommunicatorException("Error while reading the data from CSL for ExceptionId:= " + expId);
		}

		return response;
	}

	// [C153176-818]-Add 'Response Time'
	private void calculateResponseTime(List<Workflow> workflowList, Long fromGroupId, Date currentTime) throws CommunicatorException
	{
		Workflow inWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_IN);
		Workflow outWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_OUT);
		Workflow paWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_PENDING_APPROVAL);
		List<Long> ignoredQMADLForTaskize = getIgnoredQmaDlForTaskizeFromCache();
		if (null == inWorkflow && null == outWorkflow && null == paWorkflow && !ignoredQMADLForTaskize.contains(fromGroupId))
		{
			subLogger.error("Invalid input for calculateResponseTime for fromGroupId = " + fromGroupId);
			throw new CommunicatorException("Invalid input calculateResponseTime for from group id = " + fromGroupId);
		}
		Date lastConvTime = null != inWorkflow && null != inWorkflow.getLatestConversationTime() ? inWorkflow.getLatestConversationTime() : currentTime;
		if (null != lastConvTime && null != outWorkflow && null != outWorkflow.getLatestConversationTime() && lastConvTime.getTime() > outWorkflow.getLatestConversationTime().getTime())
		{
			lastConvTime = outWorkflow.getLatestConversationTime();
		}
		if (null != lastConvTime && null != paWorkflow && paWorkflow.getLatestConversationTime() != null && lastConvTime.getTime() > paWorkflow.getLatestConversationTime().getTime())
		{
			lastConvTime = paWorkflow.getLatestConversationTime();
		}
		long newResponseTimeQMA = (currentTime.getTime() - lastConvTime.getTime()) / 1000;
		long totalResponseTimeQMA = 0;
		totalResponseTimeQMA = newResponseTimeQMA;
		updateQMAResponseTime(inWorkflow, currentTime, newResponseTimeQMA, totalResponseTimeQMA, lastConvTime);
		updateQMAResponseTime(outWorkflow, currentTime, newResponseTimeQMA, totalResponseTimeQMA, lastConvTime);
		updateQMAResponseTime(paWorkflow, currentTime, newResponseTimeQMA, totalResponseTimeQMA, lastConvTime);
	}

	/**
	 * C153176-5354 - Add first response time to in, out and pa workflow.
	 * 
	 * Method to add the first response time to in, out and pa workflow.
	 * 
	 * @param workflowList
	 * @param fromGroupId
	 * @param currentTime
	 */
	private void calculateAndUpdateFirstResponseTime(List<Workflow> workflowList, Long fromGroupId, Date currentTime) {
		Workflow inWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_IN);
		Workflow outWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_OUT);
		Workflow paWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_PENDING_APPROVAL);

		updateFirstResponseTime(fromGroupId, currentTime, outWorkflow);

		if (null != outWorkflow && null != outWorkflow.getFirstResponseTime() && null != outWorkflow.getFirstResponseInMinutes()) {
			if (null != inWorkflow && null == inWorkflow.getFirstResponseTime()) {
				inWorkflow.setFirstResponseTime(outWorkflow.getFirstResponseTime());
				inWorkflow.setFirstResponseInMinutes(outWorkflow.getFirstResponseInMinutes());
			}

			if (null != paWorkflow && null == paWorkflow.getFirstResponseTime()) {
				paWorkflow.setFirstResponseTime(outWorkflow.getFirstResponseTime());
				paWorkflow.setFirstResponseInMinutes(outWorkflow.getFirstResponseInMinutes());
			}
		}
	}

	/**
	 * Method to calculate the first response time from out work flow.
	 * 
	 * @param fromGroupId
	 * @param currentTime
	 * @param workflow
	 */
	private void updateFirstResponseTime(Long fromGroupId, Date currentTime, Workflow workflow) {
		
		// First response time is get captured when user response first time on inquiry
		if (null != workflow && null == workflow.getFirstResponseTime()) {
			workflow.setFirstResponseTime(currentTime);
			Date createdDate = workflow.getCrtDate();

			// Calculate First Response time in Minutes based on working hour logic
			BasicDBObject resultObj = new BasicDBObject();
			AgeAndTimeUtils.getTimeDiffBasedOnAgeConfig(resultObj, fromGroupId, createdDate, currentTime, AppserverConstants.TIME_UNIT_MINS);
			if (null != resultObj.get(AppserverConstants.TIME_DIFF)) {
				workflow.setFirstResponseInMinutes(resultObj.getLong(AppserverConstants.TIME_DIFF));
				subLogger.info("First Response time considering working hours logic : " + resultObj.getLong(AppserverConstants.TIME_DIFF));
			} else {
				// Non - Working hours logic
				// C153176-5899 | First Response time calculation.
				long timeDiff = (currentTime.getTime() - createdDate.getTime());
				long firstResponseTimeInMins = (timeDiff / 60000); // Convert it to Minutes.
				workflow.setFirstResponseInMinutes(firstResponseTimeInMins);
				subLogger.info("First Response time in minutes : " + firstResponseTimeInMins);
			}
			subLogger.info("First Response time in minutes : " + workflow.getFirstResponseInMinutes(), ", First Response time : " + workflow.getFirstResponseTime() +
					", Workflow created date : " + workflow.getCrtDate() +" , Group Id : " + fromGroupId);
		}
	}

	private void updateQMAResponseTime(Workflow workflow, Date currentTime, long newResponseTimeQMA, long totalResponseTimeQMA, Date lastConvTime)
	{
		if (null != workflow) {
			int replyCountQMA = 1;
			Long prevRespTime = workflow.getResponseTimeQMA();
			if (null != prevRespTime) {
				totalResponseTimeQMA = prevRespTime + newResponseTimeQMA;
			}

			if (totalResponseTimeQMA > 0) {
				workflow.setResponseTimeQMA(totalResponseTimeQMA);

				if (null != workflow.getReplyCountQMA()) {
					replyCountQMA = workflow.getReplyCountQMA().intValue() + 1;
				}
				workflow.setReplyCountQMA(replyCountQMA);
				workflow.setLatestConversationTime(currentTime);
			}
			subLogger.info("Workflow Direction: " + workflow.getDirection() + " ,Response Time: previous= " + prevRespTime + " New= " + newResponseTimeQMA + " Total= " + totalResponseTimeQMA
					+ " Reply count= " + replyCountQMA + " , Last Conversation DateTime= " + lastConvTime + " current time= " + currentTime);

			// C153176-5354 - Update the response time for working hours
			this.updateQMAResponseTimeInMins(workflow, currentTime, lastConvTime);
		}
	}
	
	/**
	 * C153176-5354 - Panorama Feed.
	 * 
	 * Method to update the Response time with respect to working hours.
	 * 
	 * @param workflow
	 * @param currentTime
	 * @param lastConvTime
	 */
	private void updateQMAResponseTimeInMins(Workflow workflow, Date currentTime, Date lastConvTime) {
		try {
			Long prevRespTimeWorkHrs = workflow.getResponseTimeInMinutes();
			Long groupId = workflow.getAssignedGroupId();

			long newResponseTimeInMins = 0;
			BasicDBObject resultObj = new BasicDBObject();

			AgeAndTimeUtils.getTimeDiffBasedOnAgeConfig(resultObj, groupId, lastConvTime, currentTime, AppserverConstants.TIME_UNIT_MINS);

			if (null != resultObj.get(AppserverConstants.TIME_DIFF)) {
				newResponseTimeInMins = resultObj.getLong(AppserverConstants.TIME_DIFF);
				subLogger.info("Response time in minutes considering working hours logic : "+ newResponseTimeInMins);
			} else {
				// When working hours are not configured for the group.
				// C153176-5891 : newResponseTimeInMins should be equivalent to difference of lastConvTime and currentTime.
				newResponseTimeInMins = (currentTime.getTime() - lastConvTime.getTime()) / 60000; // Consider in minutes
				subLogger.info("Response time in minutes : "+ newResponseTimeInMins);
			}
			
			long totalResponseTimeInMins = newResponseTimeInMins;
			if (null != prevRespTimeWorkHrs) {
				totalResponseTimeInMins = prevRespTimeWorkHrs + newResponseTimeInMins;
			}

			if (totalResponseTimeInMins >= 0) {
				workflow.setResponseTimeInMinutes(totalResponseTimeInMins);
			}
			subLogger.info("Workflow Direction: " + workflow.getDirection() + " Previous Response Time: = " + prevRespTimeWorkHrs + " New Response Time= " + newResponseTimeInMins 
					+ " Total Response Time= " + totalResponseTimeInMins + " current time= " + currentTime);
		} catch (Exception e) {
			subLogger.error("Exception in InquiryDAO#updateQMAResponseTimeInMins() : ", e);
		}
	}

	private Date getOldestWorkflowCrtDate(Long fromGroupId, List<Workflow> workflowList)
	{
		Date oldestDate = null;
		Workflow outVersion = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_OUT);
		Workflow paVersion = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_PENDING_APPROVAL);
		Workflow inVersion = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_IN);
		// Look for inversion latest conversation date first if not look for out/pending approval versions.
		if (null != inVersion && null != inVersion.getLatestConversationTime())
		{
			oldestDate = inVersion.getLatestConversationTime();
		}
		else if (null != outVersion && null != outVersion.getLatestConversationTime())
		{
			oldestDate = outVersion.getLatestConversationTime();
		}
		/*
		 * else { oldestDate = paVersion.getLatestConversationTime(); }
		 */
		else if (null != paVersion && null != paVersion.getLatestConversationTime())
		{
			oldestDate = paVersion.getLatestConversationTime();
		}
		else
		{
			oldestDate = new Date();
		}

		return oldestDate;
	}

	private boolean bulkMultiGroupAction(String soeId, List<Inquiry> inquiryObjects, boolean isMultiGroupAction, Map<Long, String> inquiryGroupIdMap, String commonGroupId,String action,DBObject inquiryUpdateDBObj,DBObject inquiryUnsetDBObj,
			Map<Long, ActionStatistics> inquiryInfoMap)
					throws CommunicatorException
	{
		boolean bSuccess = false;
		if (inquiryObjects != null)
		{
			subLogger.info("bulkAction for Inquiries size=" + inquiryObjects.size() + " , action=" + action);

			DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
			BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();

			DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
			BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();

			Date currentTime = new Date();
			boolean isBulkAction= inquiryObjects != null && inquiryObjects.size() > 1 ;
			Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			for (Inquiry inqObj : inquiryObjects)
			{
				if (inqObj == null)
				{
					break;
				}

				String groupIdsString = commonGroupId;
				if (isMultiGroupAction && inquiryGroupIdMap != null)
				{
					groupIdsString = inquiryGroupIdMap.get(inqObj.id);
				}

				if (StringUtils.isBlank(groupIdsString))
				{
					subLogger.info("bulk action -" + action + " by " + soeId + ". No groups sent for inquiryId - [" + inqObj.id + "].");
					break;
				}
				String[] groupIdsList = groupIdsString.split(",");
				for (String versionGroupId : groupIdsList)
				{
					if (!StringUtils.isBlank(versionGroupId))
					{
						Long assignToGroupId = Long.valueOf(versionGroupId);

						ActionStatistics statsObj = inquiryInfoMap.get(inqObj.id+assignToGroupId);
						bulkInquiryWorkflowUpdateOperationForAction(soeId,  isBulkAction, bulkInquiryUpdOp, bulkStatsInsertdOp, currentTime, inquiryUpdateDBObj,inquiryUnsetDBObj, inqObj,
								assignToGroupId,action, statsObj);
					}
				}
			}
			// Execute
			if (!inquiryObjects.isEmpty())
			{
				bulkInquiryUpdOp.execute();
				bulkStatsInsertdOp.execute();
			}
			bSuccess = Boolean.TRUE;
		}
		return bSuccess;
	}

	private boolean saveLinkExceptionAction(String soeId, 
			List<Inquiry> inquiryObjects, 
			boolean isMultiGroupAction, 
			String commonGroupId, 
			String action,
			DBObject inquiryUpdateDBObj)
					throws CommunicatorException
	{
		boolean bSuccess = false;
		if (inquiryObjects != null)
		{
			subLogger.info("saveLinkExceptionAction for Inquiries size=" + inquiryObjects.size() + " , action=" + action);

			DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);			
			BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();			

			DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
			BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();

			Date currentTime = new Date();
			boolean isBulkAction= inquiryObjects != null && inquiryObjects.size() > 1 ;
			Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			for (Inquiry inqObj : inquiryObjects)
			{
				if (inqObj == null)
				{
					break;
				}

				String groupIdsString = commonGroupId; 
				if (StringUtils.isBlank(groupIdsString))
				{
					subLogger.info("saveLinkExceptionAction  -" + action + " by " + soeId + ". No groups sent for inquiryId - [" + inqObj.id + "].");
					break;
				}				
				String[] groupIdsList = groupIdsString.split(",");
				for (String versionGroupId : groupIdsList)
				{
					if (!StringUtils.isBlank(versionGroupId))
					{
						Long assignToGroupId = Long.valueOf(versionGroupId);						
						DBObject stats = getStatsObject(soeId, action, currentTime, inqObj, assignToGroupId, isBulkAction, null, groupIdToNameMap, userInfoMap);
						subLogger.info("Inside  bulkLinkExceptionAction before workflowAudit update for action " + 
								stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));

						// Create new Audit for the action
						DBObject workflowAudit = createWorkFlowsAuditJavaDriver(assignToGroupId, action, action, soeId, currentTime, groupIdToNameMap, userInfoMap);
						DBObject updateWorkAuditFields = new BasicDBObject();
						updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));

						DBObject findWorkAuditflowQuery = prepareFindQuery(inqObj.id, 
								assignToGroupId, 
								STATUS_OPEN, 
								INQUIRY_DIRECTION_IN_OR_OUT_OR_PA, false);  

						bulkStatsInsertdOp.insert(stats);
						subLogger.info("ActionStatistics Saved for action 8" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
						bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);			

					}
				}
			}
			// Execute
			if (!inquiryObjects.isEmpty())
			{
				bulkInquiryUpdOp.execute();
				bulkStatsInsertdOp.execute();
			}
			bSuccess = Boolean.TRUE;
		}
		return bSuccess;
	}

	private boolean bulkAssignGfpidGfcid(String soeId, String gfpid, String gfpidName, String gfcid, String gfcidName, List<Inquiry> inquiryObjects, boolean isMultiGroupAction,
			Map<Long, String> inquiryGroupIdMap, String commonGroupId, Map<Long, ActionStatistics> inquiryInfoMap, String skAccountNo, String branch) throws CommunicatorException
	{
		boolean bSuccess = false;
		String gfpidGfcid = gfpid + "/" + gfcid;

		if (inquiryObjects != null)
		{

			subLogger.info("bulkAssignGfpidGfcid for Inquiries size=" + inquiryObjects.size() + " , GFPID/GFCID" + gfpid + "/" + gfcid);

			DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
			BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();

			DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
			BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();

			Date currentTime = new Date();

			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, ACTION_ASSIGN_GFPID_GFCID);
			String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
			inquiryUpdateDBObj.put(GP_NAME, gfpid);
			inquiryUpdateDBObj.put("gpName", gfpidName);
			inquiryUpdateDBObj.put(GFC_ID, gfcid);
			inquiryUpdateDBObj.put("gfcName", gfcidName);
			
			// C170665-5 | Sk Account Number and Branch
			inquiryUpdateDBObj.put("skAccountNo", skAccountNo);
			inquiryUpdateDBObj.put("branch", branch);
			
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
			inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_ASSIGN_GFPID_GFCID);
			boolean isBulkAction= inquiryObjects != null && inquiryObjects.size() > 1 ;
			Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			for (Inquiry inqObj : inquiryObjects)
			{
				if (inqObj == null)
				{
					break;
				}

				String groupIdsString = commonGroupId;
				if (isMultiGroupAction && inquiryGroupIdMap != null)
				{
					groupIdsString = inquiryGroupIdMap.get(inqObj.id);
				}

				if (StringUtils.isBlank(groupIdsString))
				{
					subLogger.info("bulkAssignGfpidGfcid -GFPID/GFCID" + gfpid + "/" + gfcid + " by " + soeId + ". No groups sent for inquiryId - [" + inqObj.id + "].");
					break;
				}
				String[] groupIdsList = groupIdsString.split(",");
				for (String versionGroupId : groupIdsList)
				{
					if (!StringUtils.isBlank(versionGroupId))
					{
						Long assignToGroupId = Long.valueOf(versionGroupId);

						DBObject workflowAudit = createWorkFlowsAuditJavaDriver(assignToGroupId, ACTION_ASSIGN_GFPID_GFCID, gfpidGfcid, soeId, currentTime, groupIdToNameMap, userInfoMap);

						workflowAudit.put(INQUIRY_ID, inqObj.id);
						workflowAudit.put(GROUP_ID, assignToGroupId);

						ActionStatistics statsObj = inquiryInfoMap.get(inqObj.id+assignToGroupId);
						if(null!=statsObj)
						{
							statsObj.setGfcid(gfcid);
							statsObj.setGfcName(gfcidName);
							statsObj.setGpName(gfpidName);
							statsObj.setGpNum(gfpid);
						}
						//Modified for requestType in Action Statistics - C153176-1155
						//DBObject stats = getStatsObject(soeId, ACTION_ASSIGN_GFPID_GFCID, currentTime, inqObj, assignToGroupId, inquiryObjects);
						DBObject stats = getStatsObject(soeId, ACTION_ASSIGN_GFPID_GFCID, currentTime, inqObj, assignToGroupId, isBulkAction, statsObj, groupIdToNameMap, userInfoMap);

						DBObject updateDBFields = new BasicDBObject();
						// Update inquiry fields
						updateDBFields.put("$set", inquiryUpdateDBObj);
						// Create new Audit for the action
						DBObject updateWorkAuditFields = new BasicDBObject();
						updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));

						DBObject findINQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN, false);
						DBObject findOUTQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_OUT, false);

						DBObject findWorkAuditflowQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN_OR_OUT, false);
						// Add to bulk
						bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);
						bulkInquiryUpdOp.find(findOUTQuery).update(updateDBFields);
						bulkStatsInsertdOp.insert(stats);
						subLogger.info("ActionStatistics Saved for action 9" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
						bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);
					}
				}
			}
			// Execute
			if (!inquiryObjects.isEmpty())
			{
				bulkInquiryUpdOp.execute();
				bulkStatsInsertdOp.execute();

			}
			bSuccess = Boolean.TRUE;

		}
		return bSuccess;
	}

	/**
	 * @param soeId
	 * @param inquirySource
	 * @param inquiryObjects
	 * @param bulkInquiryUpdOp
	 * @param bulkStatsInsertdOp
	 * @param currentTime
	 * @param inquiryUpdateDBObj
	 * @param inqObj
	 * @param assignToGroupId
	 * @throws CommunicatorException
	 */
	private void bulkInquiryWorkflowUpdateOperationForAction(String soeId,boolean isBulkAction, BulkWriteOperation bulkInquiryUpdOp,
			BulkWriteOperation bulkStatsInsertdOp,
			Date currentTime, DBObject inquiryUpdateDBObj,DBObject inquiryUnsetDBObj, Inquiry inqObj, Long assignToGroupId,String action, ActionStatistics statsObj) throws CommunicatorException
	{
		Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
		Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
		String actionDetails=action;
		//[C170665-1719] DCC Requirement: Add Case status field
		if("Assign Inquiry Sub-Status".equalsIgnoreCase(action)) {
			actionDetails=(String)inquiryUpdateDBObj.get(WORKFLOWS_INQUIRY_SUB_STATUS);
		}
		
		DBObject workflowAudit = createWorkFlowsAuditJavaDriver(assignToGroupId, action, actionDetails, soeId, currentTime, groupIdToNameMap, userInfoMap);
		workflowAudit.put(GROUP_ID, assignToGroupId);
		//Modified for requestType in Action Statistics - C153176-1155
		DBObject stats = getStatsObject(soeId, action, currentTime, inqObj, assignToGroupId, isBulkAction, statsObj, groupIdToNameMap, userInfoMap);

		DBObject updateDBFields = new BasicDBObject();
		// Update inquiry fields
		if(null != inquiryUpdateDBObj){
			updateDBFields.put("$set", inquiryUpdateDBObj);
		}
		if(null != inquiryUnsetDBObj){
			updateDBFields.put("$unset", inquiryUnsetDBObj);
		}
		// Create new Audit for the action
		DBObject updateWorkAuditFields = new BasicDBObject();
		updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));

		DBObject findINQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN, false);
		DBObject findOUTQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_OUT, false);
		DBObject findPNDQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_PENDING_APPROVAL, false);

		DBObject findPNDREAGEQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE, false);
		DBObject findWorkAuditflowQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN_OR_OUT_OR_PA, false);
		// Add to bulk
		if(StringUtils.isNotBlank(action) && action.equalsIgnoreCase(SNOOZE)){
			bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);
		} else {
		bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);
		bulkInquiryUpdOp.find(findOUTQuery).update(updateDBFields);
		bulkInquiryUpdOp.find(findPNDQuery).update(updateDBFields);
		bulkInquiryUpdOp.find(findPNDREAGEQuery).update(updateDBFields);
		}
		
		bulkStatsInsertdOp.insert(stats);
		subLogger.info("ActionStatistics Saved for action 10" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
		bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);
	}

	public List<Attachment> checkSecureAttachments(String soeId, BasicDBObject inputJsonObj)
	{
		List<Attachment> attachmentsTOList = new ArrayList<>();
		JSONArray jsArray = new JSONArray(inputJsonObj.getString("attachment"));

		subLogger.info("Checking secure for attachment size: {}", jsArray.length());

		for (int i = 0; i < jsArray.length(); i++)
		{
			JSONObject jsonObj = jsArray.getJSONObject(i);
			String attachId = jsonObj.getString("id");
			String attachName = jsonObj.getString("name");		
			if (StringUtils.isNotEmpty(attachId) && StringUtils.isNotEmpty(attachName))
			{

				Attachment attch;
				if(jsonObj.isNull("secure"))
				{
					boolean isFileSecure = false;
					try{
						// get inputstream for the attachment
						Map<String, Object> downloadedFileMap = attachDao.getFile(attachId);
						File file = (File) downloadedFileMap.get("fileObject");
						InputStream inputStream = new FileInputStream(file);

						// checks if the file is secure or not
						isFileSecure = GenericUtility.isFileSecure(attachName, inputStream, soeId);
						inputStream.close();
					}
					catch (Exception e)
					{
						subLogger.error("Error in InquiryDAO.checkSecureAttachments for attachment: "+ attachName, e);
					}

					if(isFileSecure)
					{
						attch = new Attachment(attachName, attachId, "Y");
					}
					else
					{
						attch = new Attachment(attachName, attachId, "N");
					}
				}
				else
				{
					String attachSecure = jsonObj.getString("secure");
					attch = new Attachment(attachName, attachId, attachSecure);
				}
				attachmentsTOList.add(attch);
			}
		}
		return attachmentsTOList;
	}

	/*
	 * Method to create Pending approval for Re-age Inquiry request It can take one or more re-age requests for the same group. It will create new Pending Approval version based on Inbox selected
	 * version, set the maker and workflow status as Pending Approval -re-age Inquiry.
	 */
	public BasicDBObject sendReAgePendingApproval(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		BasicDBObject result = new BasicDBObject();

		try
		{
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			List<Inquiry> inquiryObjs = getInquiryList(inquiryIds);

			String action = inputJsonObj.getString(ACTION);
			List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			boolean isMultiGroupAction = inputJsonObj.getBoolean(IS_MULTI_GROUP_ACTION_KEY);
			String commonGroupId = inputJsonObj.getString(COMMON_GROUP_ID_KEY);

			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfoMap =  populateInquiryInfoMap(dbObjs,null,null);

			if (inquiryIds ==null &&  groupIds ==null)
			{
				subLogger.info("Invalid Input for sendReAgePendingApproval action -" + " by " + soeId + ". InquiryIdList size or groupIdList size blank");
				throw new CommunicatorException("InquiryIdList size  Or groupIdList size do not match for sendReAgePendingApproval.");
			}
			if (null!= inquiryIds && null!= groupIds && inquiryIds.size() != groupIds.size())//<-- sonar fix null pointer
			{
				subLogger.info("Invalid Input for sendReAgePendingApproval action -" + " by " + soeId + ". InquiryIdList size and groupIdList size do not match.");
				throw new CommunicatorException("InquiryIdList size - [" + inquiryIds.size() + "] and groupIdList size - [" + groupIds.size() + "] do not match for sendReAgePendingApproval.");
			}
			Map<Long, String> inquiryGroupIdMap = populateInquiryGrpMapForMultiGrpAction(action,  groupIds, isMultiGroupAction);

			Workflow uiWorkflowTransferData = new Workflow();


			uiWorkflowTransferData.setAction(action);
			uiWorkflowTransferData.setSoeId(soeId);


			if (inquiryObjs != null && ACTION_RE_AGE.equals(action))
			{
				result = sendReAgePendingApproval(inquiryObjs, uiWorkflowTransferData,inquiryGroupIdMap,isMultiGroupAction,commonGroupId,inquiryInfoMap);
			}

			
		}
		catch (Exception e)
		{
			subLogger.error("Exception in updatePendingInquiry for user= " + soeId, e);
			throw new CommunicatorException("Exception in updatePendingInquiry for user= " + soeId, e);
		}
		return result;
	}

	/*
	 * Method to handle bulk reAge request
	 */
	private BasicDBObject sendReAgePendingApproval(List<Inquiry> inquiryObjs, Workflow uiWorkflowTransferData,Map<Long, String> inquiryGroupIdMap,boolean isMultiGroupAction, String commonGroupId, Map<Long, ActionStatistics> inquiryInfoMap) throws CommunicatorException// Sonar Fix -- Define and throw a
	{
		BasicDBObject result = new BasicDBObject();
		BasicDBList newRequests = new BasicDBList();
		BasicDBList oldRequests = new BasicDBList();
		BasicDBList autoApprovedRequest = new BasicDBList();  // C153176-6148 | for auto approved inquiry for UI.
		QMACache qmaCache = QMACacheFactory.getCache();
		Map<Long, Group> allGroupsMap = qmaCache.getAllGroupsMap();
		Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
		Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
		for (Inquiry inqObj : inquiryObjs)
		{
			boolean isNewRequest = false;
			boolean isAutoApproved = false; // C153176-6148 | Flag for auto approved inquiry for UI.
			if (inqObj.getWorkflows() != null && !inqObj.getWorkflows().isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
			{
				String groupIdsString = commonGroupId;
				if (isMultiGroupAction && inquiryGroupIdMap != null)
				{
					groupIdsString = inquiryGroupIdMap.get(inqObj.id);
				}

				if (StringUtils.isBlank(groupIdsString))
				{
					subLogger.info("bulk action -" + uiWorkflowTransferData.getAction() + " by " + uiWorkflowTransferData.getSoeId() + ". No groups sent for inquiryId - [" + inqObj.id + "].");
					break;
				}
				String[] groupIdsList = groupIdsString.split(",");
				
				for (String versionGroupId : groupIdsList)
				{
					if (!StringUtils.isBlank(versionGroupId))
					{
						Long assignToGroupId = Long.valueOf(versionGroupId);
						
						// C153176-6148 | Get the Re-age need supervisor approval flag for assigned group.
						Group grp = allGroupsMap.get(assignToGroupId);
						if(null != grp.getSupervisiorApprovalForReage() && Boolean.TRUE.equals(grp.getSupervisiorApprovalForReage())) {
							// C153176-6148 | No need to create workflow for pending approval and consider it for Auto Approval.
							subLogger.info("Auto Approval for Inquiry ReAge for inquiryId - [" + inqObj.id + "].");
							autoApprovalForInquiryReAge(uiWorkflowTransferData.getSoeId(), inqObj, assignToGroupId, uiWorkflowTransferData.getAction(),groupIdToNameMap, userInfoMap);
							isAutoApproved = true;
						} else {
						uiWorkflowTransferData.setAssignedGroupId(assignToGroupId);
						isNewRequest = createReAgePNDWorkFlow(inqObj, uiWorkflowTransferData,inquiryInfoMap);
						}
					}
				}

				if (isAutoApproved) {
					autoApprovedRequest.add(inqObj.getId());
				} else {
				if(isNewRequest) {
					newRequests.add(inqObj.getId());
				} else {
					oldRequests.add(inqObj.getId());
				}
			}
		}
		}
		result.put(NEW_REAGE_REQUESTS, newRequests);
		result.put(OLD_REAGE_REQUESTS, oldRequests);
		result.put("autoApproved", autoApprovedRequest);
		result.put(SUCCESS_KEY, Boolean.TRUE);
		return result;

	}

	/**
	 * C153176-6148 - Auto approval for inquiry reAge.
	 * 
	 * Method to auto approval of Inquiry while reAge.
	 * 
	 * @param soeId
	 * @param inqObj
	 * @param groupId
	 * @param action
	 * @param groupIdToNameMap 
	 * @param userInfoMap 
	 * @throws CommunicatorException
	 */
	private void autoApprovalForInquiryReAge(String soeId, Inquiry inqObj, Long groupId, String action, Map<Long, String> groupIdToNameMap, Map<String, User> userInfoMap) throws CommunicatorException {
		subLogger.info("Method for AutoApprovalForInquiryReAge for Inquiry =" + inqObj.id + " , fromGrp=" + groupId);
	
		Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("id", inqObj.id);
		DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);

		Date currentTime = new Date();
		DBObject stats = getStatsObject(soeId, action, currentTime, inqObj, groupId, false, null, groupIdToNameMap, userInfoMap);
		Workflow inWorkflow = getWorkflow(inqObj.getWorkflows(), groupId, INQUIRY_DIRECTION_IN);
		if (inWorkflow != null) {
			String openGroups = inqObj.getOpenGroups();
			
			// Update Statistics
			updateStats(inqObj.getWorkflows(), groupId, stats, INQUIRY_DIRECTION_IN, null, inqObj.getSubject());

			// Approve Inquiry re-age process
			reAgeApproveProcess(inqObj, groupId, currentTime);

			// Create audit
			createWorkflowAudit(soeId, inqObj, groupId, action, currentTime,groupIdToNameMap, userInfoMap);

			UpdateOperations<Inquiry> ops = mongoDatastore.createUpdateOperations(Inquiry.class).set(ACTION, action).set(WORKFLOWS, inqObj.getWorkflows());
			ops.set(WORKFLOW_AUDIT, inqObj.getWorkflowAudit());
			if (openGroups != null) {
				ops.set(OPEN_GROUPS, openGroups);
			}

			mongoDatastore.update(query, ops);
			query = null;
			ops = null;
			subLogger.info("autoApprovalForInquiryReAge for Inquiry =" + inqObj.id + " , fromGrp=" + groupId);

			statsCollection.save(stats);
			subLogger.info("ActionStatistics Saved for action : " + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
		}
	}
	 
	/*
	 * Method to create pending approval for Re-age inquiry
	 */
	private boolean createReAgePNDWorkFlow(Inquiry inquiry, Workflow uiWorkflowData, Map<Long, ActionStatistics> inquiryInfoMap) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		boolean isNewRequest = false;
		Long fromGroupId = uiWorkflowData.getAssignedGroupId();
		List<Workflow> workflowList = inquiry.getWorkflows();
		Workflow existingWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE);
		Workflow existingINWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_IN);

		if (existingWorkflow != null)
		{
			subLogger.info(" Workflow already exists for " + INQUIRY_DIRECTION_PENDING_APPROVAL + " , type = " + "Pending Approval - Re-age Inquiry");
		}
		else
		{
			isNewRequest = true;
			createPendingApprovalForReAge(inquiry, existingINWorkflow, uiWorkflowData,inquiryInfoMap);
		}
		return isNewRequest;
	}

	private void createPendingApprovalForReAge(Inquiry inquiry, Workflow existingINWorkflow, Workflow uiWorkflowData, Map<Long, ActionStatistics> inquiryInfoMap) throws CommunicatorException
	{
		Date currentTime = new Date();
		Long fromGroupId = uiWorkflowData.getAssignedGroupId();
		String soeId = uiWorkflowData.getSoeId();
		String action = uiWorkflowData.getAction();
		UpdateOperations<Inquiry> ops = null;
		Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("id", inquiry.id);
		DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
		List<Workflow> workflowList = inquiry.getWorkflows();
		List<Long> allGroupIdList = new ArrayList<Long>();
		allGroupIdList.add(fromGroupId);
		EscalationUtility  escalationUtility = new EscalationUtility();
		escalationUtility.setAllGroupsEscalationCriteriaMap(groupDAO.getGroupEscalationDetailsById(new ArrayList<Long>(allGroupIdList)));

		setWorkflowStatus(workflowList, fromGroupId, INQUIRY_DIRECTION_IN, WORKFLOW_STATUS_PND_RE_AGE);
		setWorkflowStatus(workflowList, fromGroupId, INQUIRY_DIRECTION_OUT, WORKFLOW_STATUS_PND_RE_AGE);
		setWorkflowStatus(workflowList, fromGroupId, INQUIRY_DIRECTION_PENDING_APPROVAL, WORKFLOW_STATUS_PND_RE_AGE);
		// No pending approval row, Create new row
		Workflow newWorkflow = InquiryUtil.createWorkflowFromExisting(soeId, existingINWorkflow, escalationUtility, fromGroupId, currentTime);
		newWorkflow.setDirection(INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE);
		newWorkflow.setWorkflowStatus(WORKFLOW_STATUS_PND_RE_AGE);
		newWorkflow.setMaker(soeId);
		newWorkflow.setIsMakerCheckerEnabled(true);
		newWorkflow.setReAgeSentDate(currentTime);
		workflowList.add(newWorkflow);
		ops = mongoDatastore.createUpdateOperations(Inquiry.class).set(WORKFLOWS, workflowList);
		// REQU0002243347: add the workflowAudit for Pending Inquiry Actions as per mail on April 12, 2016
		WorkflowAudit workflowAudit = new WorkflowAudit(action, action, fromGroupId, soeId, currentTime, soeId);
		User user = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase());
		Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
		Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
		if (user != null)
		{
			workflowAudit.setUserId(user.getName());
		}
		if (fromGroupId != null)
		{
			workflowAudit.setGroupName(QMACacheFactory.getCache().getGroupIdToNameMap().get(fromGroupId));
		}

		if (inquiry.getWorkflowAudit() == null)
		{
			inquiry.setWorkflowAudit(new ArrayList<WorkflowAudit>());
		}
		inquiry.getWorkflowAudit().add(workflowAudit);
		ops = ops.set(WORKFLOW_AUDIT, inquiry.getWorkflowAudit());
		// end

		mongoDatastore.update(query, ops);
		ops = null;
		subLogger.info(WORKFLOW_STATUS_PND_RE_AGE + inquiry.id + " , fromGrp=" + fromGroupId);
		ActionStatistics statsObj = inquiryInfoMap.get(inquiry.id+fromGroupId);		
		DBObject stats = getStatsObject(soeId, action, currentTime, inquiry, fromGroupId, false, statsObj, groupIdToNameMap, userInfoMap);
		statsCollection.save(stats);
		subLogger.info("ActionStatistics Saved for action 11" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
	}

	private void updateReAgePendingGroupWorkflow(String soeId, Inquiry inqObj, Long groupId, String action, Map<Long, String> groupIdToNameMap, Map<String, User> userInfoMap) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead
	// of
	{
		Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("id", inqObj.id);
		DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);

		Date currentTime = new Date();
		//// Modified for requestType in Action Statistics - C153176-1155
		DBObject stats = getStatsObject(soeId, action, currentTime, inqObj, groupId, false, null, groupIdToNameMap, userInfoMap);
		Workflow pendingWorkflow = getWorkflow(inqObj.getWorkflows(), groupId, INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE);
		if (pendingWorkflow != null)
		{
			String openGroups = inqObj.getOpenGroups();
			// C153176-154 ActionStatistics Improvements
			updateStats(inqObj.getWorkflows(), groupId, stats, INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE, null, inqObj.getSubject());

			// Fix for - Reject an inquiry by approval doesnot set AssignGroup(TO Group STR) in the Inquiry Grid.
			if (ACTION_REJECT.equals(action))
			{
				reAgeRejectProcess( inqObj, groupId, pendingWorkflow,openGroups);
			}
			else
			{
				Date reAgeDate=(pendingWorkflow.getReAgeSentDate() !=null?pendingWorkflow.getReAgeSentDate():pendingWorkflow.getCrtDate());
				//Reage inquiry workflow :: reAgeDate=Pending Workflow Created Date
				reAgeApproveProcess(inqObj, groupId, reAgeDate);
				inqObj.getWorkflows().remove(pendingWorkflow);
			}

			//C153176-1178 - if all the workflows(in, pending approval, pending reage) are resolved then resolve the inquiry. 
			String status = resolveInquiryFromPendingApprovalBox(inqObj);
			
			createWorkflowAudit(soeId, inqObj, groupId, action, currentTime, groupIdToNameMap, userInfoMap);

			UpdateOperations<Inquiry> ops = mongoDatastore.createUpdateOperations(Inquiry.class).set(ACTION, action).set(STATUS, status).set(WORKFLOWS, inqObj.getWorkflows());
			ops.set(WORKFLOW_AUDIT, inqObj.getWorkflowAudit());
			if(openGroups !=null){
				ops.set(OPEN_GROUPS, openGroups);
			}

			mongoDatastore.update(query, ops);
			subLogger.info("updatePendingInquiry for Inquiry =" + inqObj.id + " , fromGrp=" + groupId);

			statsCollection.save(stats);
			subLogger.info("ActionStatistics Saved for action 13" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
		}

	}
	private void reAgeApproveProcess(Inquiry inqObj, Long groupId,Date reAgeDate) throws CommunicatorException
	{
		resetAgeForWorkflow(inqObj.getWorkflows(), groupId,INQUIRY_DIRECTION_IN,reAgeDate);
		resetAgeForWorkflow(inqObj.getWorkflows(), groupId,INQUIRY_DIRECTION_OUT,reAgeDate);
		resetAgeForWorkflow(inqObj.getWorkflows(), groupId,INQUIRY_DIRECTION_PENDING_APPROVAL,reAgeDate);
		resetAgeForWorkflow(inqObj.getWorkflows(), groupId,INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE,reAgeDate);
	}

	private void resetAgeForWorkflow(List<Workflow> inquiryWorkflowList, Long groupId,String direction, Date reAgeDate)
	{
		Workflow workflow = getWorkflow(inquiryWorkflowList, groupId, direction);
		if (workflow != null)
		{
			workflow.setWorkflowStatus(WORKFLOW_STATUS_AP_RE_AGE);
			workflow.setReAgeDate(reAgeDate);
			workflow.setReAgeSentDate(null);
		}
	}

	private void setWorkflowStatus(List<Workflow> inquiryWorkflowList, Long groupId,String direction,String workflowStatus)
	{
		Workflow workflow = getWorkflow(inquiryWorkflowList, groupId, direction);
		if (workflow != null)
		{
			workflow.setWorkflowStatus(workflowStatus);
		}
	}

	private void reAgeRejectProcess( Inquiry inqObj, Long groupId,Workflow pendingWorkflow,String openGroups)
	{
		Workflow inWorkflow = getWorkflow(inqObj.getWorkflows(), groupId, INQUIRY_DIRECTION_IN);
		Workflow outWorkflow = getWorkflow(inqObj.getWorkflows(), groupId, INQUIRY_DIRECTION_OUT);
		if (outWorkflow != null)
		{
			outWorkflow.setWorkflowStatus(WORKFLOW_STATUS_RJ_RE_AGE);
			outWorkflow.setReAgeSentDate(null);		
		}
		if(inWorkflow !=null){
			inWorkflow.setWorkflowStatus(WORKFLOW_STATUS_RJ_RE_AGE);
			inWorkflow.setReAgeSentDate(null);	
			inqObj.getWorkflows().remove(pendingWorkflow);
		}else{
			pendingWorkflow.setDirection(INQUIRY_DIRECTION_IN);
			pendingWorkflow.setWorkflowStatus(WORKFLOW_STATUS_RJ_RE_AGE);
			pendingWorkflow.setReAgeSentDate(null);
			appendToOpenGroups(groupId, openGroups);
		}


	}

	private void appendToOpenGroups(Long groupId, String openGroups)
	{
		String groupCode = QMACacheFactory.getCache().getGroupIdToNameMap().get(groupId);
		if (openGroups != null)
		{
			openGroups = openGroups + ";" + groupCode;
		}
		else
		{
			openGroups = groupCode;
		}
	}
	// Find the reOpenDate for a group in the workflow list
	//
	/**
	 * @param workflowSet
	 * @param grpId
	 * @param uiFollowUpFlag
	 * @param fromGrpId
	 * @return
	 * This method is responsible for set/unset followup when user take (reply, reply all) action. 
	 * The followup flag will be always set on the From group, not on To or CC group.
	 * [C153176-1575] - *Issue*- Remove flag does not work for Reply all action.
	 * 
	 */
	private FollowUp getValidVersionFollowUp(List<Workflow> workflowSet, Long grpId, String uiFollowUpFlag, Long fromGrpId) {
		FollowUp followUp = null;
		for (Workflow version : workflowSet) {
			Long versionGrpId = version.getAssignedGroupId();
			boolean isGroupMatch = versionGrpId != null && versionGrpId.equals(grpId) && (version.getFollowUp() != null);
			// Sonar Fix -- remove useless parenthesis
			if (isGroupMatch) {
				// get existing reopen date for any group(IN/OUT will have same reopen date
				followUp = version.getFollowUp();

				if (null != fromGrpId && fromGrpId.equals(versionGrpId)) 
				{
					if ( null != uiFollowUpFlag)
					{
						followUp = version.getFollowUp();
						// if user is selecting followup while replying.
						if (null == followUp)
						{
							followUp = new FollowUp();
							followUp.setFlag(uiFollowUpFlag);
						}
					} 
					else 
					{
						followUp = null;
					}
				}

			}
		}
		return followUp;
	}


	/**
	 * This method accpets all data and sends inquiries for manual escalation
	 * @param soeId
	 * @param requestObject
	 * @param servletRequest 
	 * @return BasicDBObject
	 * @throws CommunicatorException
	 */
	public BasicDBObject manuallyEscalateInquiries(String soeId,BasicDBObject requestObject) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		try {
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(requestObject, INQUIRY_IDS);
			List<Inquiry> inquiryObjs = getInquiryList(inquiryIds);
			String action = requestObject.getString(ACTION);
			String manualEscReason = requestObject.getString(MANUAL_ESC_REASON_KEY);
			String commonGroupId = requestObject.getString(COMMON_GROUP_ID_KEY);
			if (inquiryObjs != null && ACTION_MANUAL_ESCALATE.equals(action))
			{
				response = escalateInquiries(inquiryObjs,manualEscReason,commonGroupId,action,soeId);
			}

		} catch (Exception e) {
			subLogger.error("Exception in InquiryDAO#manuallyEscalateInquiries() : ", e);
		}
		return response;
	}

	/**
	 * This method escalates inquiries
	 * @param inquiryObjs
	 * @param manualEscReason
	 * @param commonGroupId
	 * @return BasicDBObject
	 */
	private BasicDBObject escalateInquiries(List<Inquiry> inquiryObjs, final String manualEscReason, final String commonGroupId,String action,String soeId) {
		BasicDBObject result = new BasicDBObject();
		BasicDBList successResult = new BasicDBList();
		BasicDBList failureResult = new BasicDBList();
		try {

			for (Inquiry inqObj : inquiryObjs)
			{
				boolean resultFlag = false;
				if (inqObj.getWorkflows() != null && !inqObj.getWorkflows().isEmpty())
				{
					resultFlag = updateManualEscalation(inqObj, manualEscReason, commonGroupId,action,soeId);

				}
				if(resultFlag) {
					successResult.add(inqObj.getId());
				} else {
					failureResult.add(inqObj.getId());
				}
			}
			result.put("successResult", successResult);
			result.put("failureResult", failureResult);
			result.put(SUCCESS_KEY, Boolean.TRUE);
			return result;

		} catch (Exception e) {
			subLogger.error("Exception in InquiryDAO#escalateInquiries() : ", e);
			result.put(SUCCESS_KEY, Boolean.FALSE);
		}
		return result;
	}

	/**
	 * This method updates manual escalation for the selected inquiry workflow
	 * @param workflowList
	 * @param manualEscReason
	 * @param groupID
	 */
	private boolean updateManualEscalation(Inquiry inqObj, final String manualEscReason,final String groupID,String action,String soeId) {
		boolean successFlag = false;
		try {
			QMACache qmaCache =  QMACacheFactory.getCache();
			for ( Workflow workflow : inqObj.getWorkflows() ) {
				Long grpId = workflow.getAssignedGroupId();
				Long selectedGrpId = Long.parseLong(groupID);
				if( grpId.equals(selectedGrpId)) {
					workflow.setIsManualEscalation(AppserverConstants.Y);
					String escalationReason = AppserverConstants.MANUAL_ESC_REASON+ manualEscReason+".";
					workflow.setManualEscalationReason(escalationReason);
					User user = qmaCache.getUserInfoMap().get(soeId.toUpperCase());
					String userId = soeId;
					if (user != null && null != user.getName())
					{
						userId= user.getName();
					}
					WorkflowAudit workflowAudit = new WorkflowAudit(action, escalationReason, workflow.getAssignedGroupId(), soeId, new Date(), userId);
					workflowAudit.setGroupName(workflow.getAssignedGroupName());
					successFlag = updateManualEscalationInDb(inqObj,workflowAudit,soeId);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in InquiryDAO#updateManualEscalation() : ", e);
		}
		return successFlag;
	}

	/**
	 * This method updates inquiry workflow and workflow audit in database.
	 * @param inqObj
	 * @param workflowAudit
	 * @param soeId
	 * @return boolean
	 */
	private boolean updateManualEscalationInDb(Inquiry inqObj,WorkflowAudit workflowAudit,String soeId){
		boolean result = true;
		try {
			Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("id", inqObj.id);
			UpdateOperations<Inquiry> ops = mongoDatastore.createUpdateOperations(Inquiry.class).set(WORKFLOWS, inqObj.getWorkflows());
			mongoDatastore.update(query, ops);
			/*Update workflow audit*/
			User user = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase());
			if (user != null)
			{
				workflowAudit.setUserId(user.getName());
			}
			if (inqObj.getWorkflowAudit() == null)
			{
				inqObj.setWorkflowAudit(new ArrayList<WorkflowAudit>());
			}
			inqObj.getWorkflowAudit().add(workflowAudit);
			ops = ops.set(WORKFLOW_AUDIT, inqObj.getWorkflowAudit());
			mongoDatastore.update(query, ops);
		} catch (Exception e) {
			subLogger.error("Exception in InquiryDAO#updateManualEscalationInDb() : ", e);
			result = false;
		}
		return result;
	}


	private boolean bulkUnassignProcessingRegion(String soeId, Set<Long> assignGroupIds, List<Inquiry> inquiryObjects, Map<Long, ActionStatistics> inquiryInfoMap, String action)throws CommunicatorException// Sonar Fix -- Define
	{
		boolean success = Boolean.FALSE;
		Date currentTime = new Date();
		boolean isMultiGroupOperation = assignGroupIds != null && !assignGroupIds.isEmpty();// Sonar Fix -- remove useless parenthesis
		if (isMultiGroupOperation)
		{
			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, action);
			inquiryUpdateDBObj.put(WORKFLOWS_PROCESSING_REGION, "");
			success = bulkUnassignInquiry(inquiryUpdateDBObj, null, assignGroupIds, inquiryObjects, inquiryInfoMap, action, currentTime);
		}
		return success;
	}

	private boolean bulkUnassignOwner(String soeId, String groupName, Set<Long> assignedGroupIds, String assignUserId, List<Inquiry> inquiryObjects, Map<Long, ActionStatistics> inquiryInfoMap, String action)throws CommunicatorException// Sonar Fix -- Define
	{
		boolean success = Boolean.FALSE;
		if (assignedGroupIds != null && !assignedGroupIds.isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
		{
			Date currentTime = new Date();
			String assignUserName = getAssignUserName(assignUserId, groupName);
			boolean isMultiGroupOperation = assignedGroupIds != null && !assignedGroupIds.isEmpty();// Sonar Fix -- remove useless parenthesis
			if (isMultiGroupOperation)
			{
				// Prepare update fields
				DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, action);
				inquiryUpdateDBObj.put("workflows.$.assignedUserId", "");
				inquiryUpdateDBObj.put("workflows.$.assignedUserName", "");
				success = bulkUnassignInquiry(inquiryUpdateDBObj, assignUserName, assignedGroupIds, inquiryObjects, inquiryInfoMap, action, currentTime);
			}
		}
		return success;
	}
	private boolean bulkUnassignTag(String soeId, Set<Long> assignedGroupIds, List<Inquiry> inquiryObjects, Map<Long, ActionStatistics> inquiryInfoMap, String action)throws CommunicatorException// Sonar Fix -- Define
	{
		boolean success = Boolean.FALSE;
		Date currentTime = new Date();
		boolean isMultiGroupOperation = assignedGroupIds != null && !assignedGroupIds.isEmpty();// Sonar Fix -- remove useless parenthesis
		if (isMultiGroupOperation)
		{
			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, action);
			inquiryUpdateDBObj.put("workflows.$.tag", "");
			inquiryUpdateDBObj.put(WORKFLOWS_ACTION, AppserverConstants.ACTION_UNASSIGN_TAG);
			success = bulkUnassignInquiry(inquiryUpdateDBObj, null, assignedGroupIds, inquiryObjects, inquiryInfoMap, action, currentTime);
		}
		return success;
	}
	private boolean bulkUnassignInquiry(DBObject inquiryUpdateDBObj, String assignUserName, Set<Long> assignedGroupIds, List<Inquiry> inquiryObjects, Map<Long, ActionStatistics> inquiryInfoMap, String action, Date currentTime) throws CommunicatorException// Sonar Fix -- Define
	{
		boolean bSuccess;
		DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
		BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();
		DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
		BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();
		String soeId = (String) inquiryUpdateDBObj.get(WORKFLOWS_MODIFIED_BY);
		String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
		inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
		inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
		inquiryUpdateDBObj.put(WORKFLOWS_ACTION, action);

		boolean isBulkAction = null != inquiryObjects && inquiryObjects.size() > 1;
		Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
		Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
		for (Inquiry inquiry : inquiryObjects)
		{
			if(AppserverConstants.ACTION_UNASSIGN_OWNER.equals(action))
			{
				updateOpenUserDetails(assignUserName, inquiry, inquiryUpdateDBObj, assignedGroupIds);
			}
			for (Long assignToGroupId : assignedGroupIds)
			{
				DBObject workflowAudit;
				// groupId needs to be sent to take the group name and update in audit object
				workflowAudit = createWorkFlowsAuditJavaDriver(assignToGroupId, action, "", soeId, currentTime, groupIdToNameMap, userInfoMap);
				workflowAudit.put(INQUIRY_ID, inquiry.id);
				workflowAudit.put(GROUP_ID, assignToGroupId);
				ActionStatistics statsObj = inquiryInfoMap.get(inquiry.id + assignToGroupId);
				DBObject stats = getStatsObject(soeId, action, currentTime, inquiry, assignToGroupId, isBulkAction, statsObj, groupIdToNameMap, userInfoMap);
				DBObject updateDBFields = new BasicDBObject();
				// Update inquiry fields
				updateDBFields.put("$set", inquiryUpdateDBObj);
				// Create new Audit for the action
				DBObject updateWorkAuditFields = new BasicDBObject();
				updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));
				DBObject findINWorkflowQuery = prepareFindQuery(inquiry.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN, false);
				// C153176-368-Resolved Inquiry Cannot be found with OUT version
				DBObject findOUTWorkflowQuery = prepareFindQuery(inquiry.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_OUT, false);
				DBObject findWorkAuditflowQuery = prepareFindQuery(inquiry.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN_OR_OUT, false);
				bulkInquiryUpdOp.find(findINWorkflowQuery).update(updateDBFields);
				bulkInquiryUpdOp.find(findOUTWorkflowQuery).update(updateDBFields);
				bulkStatsInsertdOp.insert(stats);
				subLogger.info("ActionStatistics Saved for action 14" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
				bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);
			}
			iInquiryActionStat.bulkUpdateInquiryActionStats(inquiry, action, currentTime, assignedGroupIds);
		}
		// Execute
		if (null != inquiryObjects && !inquiryObjects.isEmpty())//<-- sonar fix null pointer
		{
			bulkInquiryUpdOp.execute();
			bulkStatsInsertdOp.execute();
		}
		bSuccess = Boolean.TRUE;
		return bSuccess;
	}

	/*
	 *  Synchronze all unapproved domanins with Inquiry approved domain list on Approval action
	 */

	private void addApprovedExternalDomain(Inquiry inqObj, Workflow pendingWorkflow)
	{
		if(pendingWorkflow!=null)
		{
			Set<String> domains = pendingWorkflow.getPendingExternalDomains();
			if(domains!=null && !domains.isEmpty())
			{
				Set<String> approvedDomains = inqObj.getApprovedExternalDomains();
				if(approvedDomains == null) approvedDomains = new HashSet<>();
				approvedDomains.addAll(domains);
				inqObj.setApprovedExternalDomains(approvedDomains);
			}
			pendingWorkflow.setPendingExternalDomains(null);
		}

	}

	//[C153176-1121]-Ability to link inquiry to exception from QMA	
	public boolean linkExceptionId(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {	
		
		
		boolean bSucess = Boolean.FALSE; 		
		Long exceptionId = GenericUtility.getIdFromRequest(inputJsonObj, "ExceptionId"); 
		try
		{				
			if (inputJsonObj == null)
			{
				subLogger.error("linkExceptionId inputJsonObj can't be null: " + inputJsonObj);
				throw new CommunicatorException("Exception in getting the inputJsonObj for user= " + soeId);
			}
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);		
			List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);

			List<String> inquiryIdGroupIdTuple = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			boolean isMultiGroupAction = inputJsonObj.getBoolean(IS_MULTI_GROUP_ACTION_KEY); 
			String action = LINK_EXCEPTION;	

			Map<Long, String> InquiryGroupIdMap = populateInquiryGrpMapForMultiGrpAction(action,inquiryIdGroupIdTuple,isMultiGroupAction);

			String commonGroupId = inputJsonObj.getString(COMMON_GROUP_ID_KEY);		 
			

			if (inquiryObjects == null || inquiryObjects.isEmpty() || exceptionId == null||inquiryIdGroupIdTuple.isEmpty()||commonGroupId.isEmpty()) 
			{
				subLogger.error("No Inquiries received for user={} as the inquiryObjs is null or empty {} " ,soeId, (null == inquiryObjects? inquiryObjects :inquiryObjects.size()));//<-- sonar fix null pointer
				throw new CommunicatorException("Exception in getting the inquiries for user= " + soeId);
			}
			else
			{
				Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
				Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
				Date currentTime = new Date();
				DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
				BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();

				for(Inquiry inqObj:inquiryObjects )
				{
					inqObj.setExceptionId(exceptionId);
					String groupIdsString = commonGroupId;

					if (isMultiGroupAction && InquiryGroupIdMap != null)
					{
						groupIdsString = InquiryGroupIdMap.get(inqObj.id);
					}

					if (StringUtils.isBlank(groupIdsString))
					{
						subLogger.info("Action-" + action + " by " + soeId + ". No groups sent for inquiryId - [" + inqObj.id + "].");
						break;
					}
					String[] groupIdsList = groupIdsString.split(",");
					QMACache qmaCache = QMACacheFactory.getCache();
					for (String groupId : groupIdsList)
					{
						if (!StringUtils.isBlank(groupId))
						{
							Long assignToGroupId = Long.valueOf(groupId);								
							User user = qmaCache.getUserInfoMap().get(soeId.toUpperCase());
							String userId = soeId;
							if (user != null && null != user.getName())
							{
								userId= user.getName();
							}
							List<WorkflowAudit> workflowAuditList = inqObj.getWorkflowAudit();
							WorkflowAudit workflowAudit = new WorkflowAudit(action, 
									action, assignToGroupId, soeId, currentTime, userId);
							workflowAuditList.add(workflowAudit);

							DBObject stats = getStatsObject(soeId, action, currentTime, inqObj, assignToGroupId, isMultiGroupAction, null, groupIdToNameMap, userInfoMap);
							bulkStatsInsertdOp.insert(stats);
							persist(inqObj);
						}
					}

				}

				if (!inquiryObjects.isEmpty())
				{
					bulkStatsInsertdOp.execute();
				}
				bSucess = true;
				for(Inquiry inqIds:inquiryObjects ){
					List<Conversation> convList = getAllConversations(inqIds.getId(), null, 1, true);
					GenericUtility.postInquiryDetailsToCSL(inqIds, convList.get(0), null);
				}
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception while Assigning ExceptionId  for user= " + soeId, e);
			throw new CommunicatorException("Exception while Assigning ExceptionId  for user= " + soeId, e);
		}

		return bSucess;

	}
	
	/**
	 * @param soeId
	 * @param inputJsonObj
	 * @param servletRequest 
	 * @return
	 * @throws CommunicatorException
	 * This method is responsible for Acknowledge Escalation functionality [C153176-1694].
	 */
	public boolean acknowledgeEscalation(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException
	{
		boolean bSucess = Boolean.FALSE;
		List<Long> inquiryIds = null;
		try
		{
			if (inputJsonObj == null || StringUtils.isBlank(inputJsonObj.getString(ACTION)))
			{
				subLogger.error("No acknowledgeEscalation Action received for user=" + soeId + "as the inputJsonObj" + inputJsonObj);
				throw new CommunicatorException("Exception in getting the acknowledgeEscalation action for user= " + soeId);
			}
			String ackEscalationAction = inputJsonObj.getString(ACTION);
			String isAckEscFlag = ACTION_ACKNOWLEDGE_ESCALATION.equalsIgnoreCase(ackEscalationAction) ? STRING_YES : "N";
			inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj,INQUIRY_IDS);
			List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);

			if (inquiryObjects == null || inquiryObjects.isEmpty())
			{
				subLogger.error("No Inquiries received for user={} as the inquiryObjs is null or empty {}",soeId,(null == inquiryObjects ? inquiryObjects : inquiryObjects.size())); //<-- sonar fix null pointer
				throw new CommunicatorException("Exception in getting the inquiries for user= " + soeId);
			}
			List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			boolean isMultiGroupAction = inputJsonObj.getBoolean(IS_MULTI_GROUP_ACTION_KEY);
			String commonGroupId = inputJsonObj.getString(COMMON_GROUP_ID_KEY);
			if (inquiryIds.size() != groupIds.size())
			{
				subLogger.info("Invalid Input for acknowledgeEscalation action -" +  " by " + soeId + ". InquiryIdList size and groupIdList size do not match.");
				throw new CommunicatorException("InquiryIdList size - [" + inquiryIds.size() + "] and groupIdList size - [" + groupIds.size() + "] do not match for acknowledge escalation.");
			}

			Map<Long, String> inquiryGroupIdMap =populateInquiryGrpMapForMultiGrpAction(ackEscalationAction, groupIds, isMultiGroupAction);
			Date currentTime = new Date();

			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, ackEscalationAction);

			DBObject inquiryUnsetDBObj=null;
			if (STRING_YES.equalsIgnoreCase(isAckEscFlag))
			{	
				String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
				inquiryUpdateDBObj.put(WORKFLOWS_ACK_ESCALATION, isAckEscFlag);
				inquiryUpdateDBObj.put(WORKFLOWS_ACK_ESCALATION_BY, userName);
				inquiryUpdateDBObj.put(WORKFLOWS_ACK_ESCALATION_TIME, currentTime);
				inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
				inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
				inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_ACKNOWLEDGE_ESCALATION);
			}
			else
			{
				inquiryUpdateDBObj.put(WORKFLOWS_ACK_ESCALATION, "");
				inquiryUpdateDBObj.put(WORKFLOWS_ACK_ESCALATION_BY, "");
				inquiryUpdateDBObj.put(WORKFLOWS_ACK_ESCALATION_TIME, "");
			}

			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfoMap =  populateInquiryInfoMap(dbObjs,null,null);

			bSucess = bulkMultiGroupAction(soeId, inquiryObjects, isMultiGroupAction, inquiryGroupIdMap, commonGroupId,ackEscalationAction,inquiryUpdateDBObj,inquiryUnsetDBObj, inquiryInfoMap);

		}
		catch (Exception e)
		{
			subLogger.error("Exception in acknowledge escalation Inquiry for user= " + soeId, e);
			throw new CommunicatorException("Exception in acknowledge escalation Inquiry for user= " + soeId, e);
		}
		return bSucess;
	}
	
	
	/**
	 * This method accepts ViewName and soeId and returns grid view data of provided 
	 * view name and user
	 * @param soeId
	 * @param inputJsonObj
	 * @return DBObject
	 * @throws CommunicatorException
	 */
	public DBObject getGroupLevelInquiryDataForView(String soeId,BasicDBObject inputJsonObj) throws CommunicatorException {
		DBObject gridViewTO = new BasicDBObject();
		try {
			if(inputJsonObj != null && StringUtils.isNotEmpty(soeId)){
				String viewName = inputJsonObj.getString(VIEW_NAME); 
				int maxRecentMsgCount = 10;
				if( StringUtils.isNotEmpty(viewName)  && viewName.equalsIgnoreCase(DEFAULT_VIEW_TYPE_ESCALATION_UI)){
					viewName =  DEFAULT_VIEW_TYPE_ESCALATION;
				}
				if( inputJsonObj.getInt(RECORD_COUNT) != 0 ) {
					maxRecentMsgCount= inputJsonObj.getInt(RECORD_COUNT);
				}
				DBObject defaultBoxCriteria = getFinalDefaultBoxCriteria(soeId, getDefaultBoxCriteriaStr(viewName), gridViewTO, inputJsonObj);
				if (defaultBoxCriteria == null || viewName ==null || StringUtils.isEmpty(viewName))
				{
					subLogger.error("InquiryDAO#getGroupLevelDataForView() - Invalid view name or configuration !");
				}
				else
				{
					BasicDBObject inputViewObj = new BasicDBObject();
					inputViewObj.put(VIEW_NAME, viewName);
					inputViewObj.put(VIEW_TYPE, 11);
					inputViewObj.put(RECORD_COUNT, maxRecentMsgCount);
					gridViewTO = getGroupLevelGridViewData(gridViewTO, soeId, defaultBoxCriteria, null, null, null, null,maxRecentMsgCount, viewName, false, false,inputViewObj, null);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in getRecentViewData for user " + soeId, e);
			throw new CommunicatorException("Exception in getRecentViewData for user " + soeId, e);
		}
		return gridViewTO;
	}
	
	/**
	 * @param soeId
	 * @param inputJsonObj
	 * @param servletRequest 
	 * @return
	 * @throws CommunicatorException 
	 */
	public boolean updateMemo(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {
			
		try
		{				
			if (inputJsonObj == null )
			{
				subLogger.error("updateMemo inputJsonObj can't be null: " + inputJsonObj);
				throw new CommunicatorException("Exception in getting the inputJsonObj for user= " + soeId);
			}
			
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);		
			List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);
			
			if (inquiryObjects == null || inquiryObjects.isEmpty())
			{
				subLogger.error("updateMemo - No Inquiries received for user=" + soeId + "as the inquiryObjs is null or empty " + inquiryObjects);
				throw new CommunicatorException(" updateMemo - Exception in getting the inquiries for user= " + soeId);
			}

			// Memo is single row update.

			Inquiry inquiry = inquiryObjects.get(0);
			List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			Date currentTime = new Date();
			String memo = inputJsonObj.getString(MEMO);
			
			if (null!=inquiry && !groupIds.isEmpty() )
			{
				Map<Long, String> inquiryGroupIdMap =populateInquiryGrpMapForMultiGrpAction(AppserverConstants.UPDATEMEMO, groupIds, true);
				// Inquiry Database Update
				UpdateOperations<Inquiry> ops = mongoDatastore.createUpdateOperations(Inquiry.class);
				// Prepare Find Query to find record
				Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("id", inquiry.id);
			
				String groupIdStr = inquiryGroupIdMap.get(inquiry.id);
				Long assignToGroupId = Long.valueOf(groupIdStr);
				Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
				Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
				WorkflowAudit workflowAudit = createWorkFlowsAudit(assignToGroupId, AppserverConstants.UPDATEMEMO, "Internal", soeId, currentTime, null, null, groupIdToNameMap, userInfoMap);
				
				setInquiryAudit(inquiry, workflowAudit, ops);
				
				if(!StringUtils.isBlank(memo))
					ops.set(MEMO,memo);
				else
					ops.unset(MEMO);
				
				mongoDatastore.update(query, ops);
				
				//update memo on COnversation table.
				updateConversationWithMemo(inquiry.id, memo);
			}
			
		} catch (Exception e) {
			subLogger.error("Exception in updateMemo for user " + soeId, e);
			throw new CommunicatorException("Exception in updateMemo for user = " + soeId);
		}
		
		return true;
	}
	
	/**
	 * @param inquiryId
	 * @param memo
	 * @param logger
	 */
	public void updateConversationWithMemo(Long inquiryId, String memo)
	{
		try
		{
			subLogger.info("inside updateConversationWithMemo method inputs are : inquiryid : " + inquiryId );
			
			// pick the latest conversation and update the memo with current time.
			Conversation conversation = mongoDatastore.find(Conversation.class, "inquiryId", inquiryId).order("-_id").limit(1).get();
			
			Query<Conversation> updateQuery = mongoDatastore.createQuery(Conversation.class).filter("_id", conversation.id);
			UpdateOperations<Conversation> convOps = mongoDatastore.createUpdateOperations(Conversation.class).set("memo", memo).set("modDate", new Date());
			mongoDatastore.update(updateQuery, convOps);
	
			subLogger.info("updateConversationWithMemo is successful for inquiryId :" + inquiryId + " , conv Id:" + conversation.id);		
		}catch (Exception e) {
			subLogger.error("Exception in updateConversationWithMemo for inquiryId " + inquiryId, e);
		}
		
			
	}

	public Long getLatestConvForInquiry(String inquiryId) {
		try
		{
			subLogger.info("inside getLatestConvForInquiry method inputs are : inquiryid : " + inquiryId );
			Conversation conversation = mongoDatastore.find(Conversation.class, "inquiryId", Long.parseLong(inquiryId)).order("-_id").limit(1).get();
			subLogger.info("getLatestConvForInquiry is successful for inquiryId :" + inquiryId + " , conv Id:" + conversation.id);
			return conversation.id;
		}catch (Exception e) {
			subLogger.error("Exception in getLatestConvForInquiry for inquiryId " + inquiryId, e);
		}
		return null;
	}
	

	/**
	 * This method used to download all attachment into zip for given inquiryId/ convId
	 * @param soeId
	 * @param request
	 * @return
	 * @throws CommunicatorException 
	 */
	public File downloadAllAttachments(String soeId, String request) {
		File zipFile = null;
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			Long inquiryId = GenericUtility.getIdFromRequest(inputJsonObj, "inquiryId");
			Long convId = GenericUtility.getIdFromRequest(inputJsonObj, "convId");
			Long groupId = GenericUtility.getIdFromRequest(inputJsonObj, "groupId");
			List<Long> grpIds = null;
			if( null != groupId ) {
				grpIds = new ArrayList<>();
				grpIds.add(groupId);
			}
			int convLimitCount = QMACacheFactory.getCache().getConvLimitCount();
			List<Conversation> convList = getAllConversations(inquiryId, grpIds, convLimitCount, true);
			zipFile = getFileListToZip(inquiryId, convId, convList);
        }catch (Exception ex) {
			subLogger.error("Exception while downloading all attachment: InquiryDAO.downloadAllAttachments" + ex);
		}
		return zipFile;
	}

	/**
	 * get no of file to added to zip file
	 * @param inquiryId
	 * @param convId
	 * @param convList
	 * @return
	 * @throws CommunicatorException
	 */
	private File getFileListToZip(Long inquiryId, Long convId, List<Conversation> convList) throws CommunicatorException {
		File zipFile = null;
		String fileExtn = ".zip";
		String fileNameZip = inquiryId + fileExtn;
		Map<String, File> fileMapToZip = new HashMap<>();
		Map<String, Integer> fileVersionMap = new HashMap<>();
		for (int i = convList.size(); i-- > 0;) {
			Conversation conv = convList.get(i);
			if (null != conv && null != conv.getAttachments()) {
				Map<String, File> filesMap = null;
				if (null != convId && conv.getId().equals(convId)) {
					fileNameZip = convId + fileExtn;
					List<Attachment> attachmentsByConvId = conv.getAttachments();
					fileMapToZip = fetchAttachmentFromDB(attachmentsByConvId,fileVersionMap);
					break;
				} else if (null == convId) {
					List<Attachment> attachmentsByInqId = conv.getAttachments();
					filesMap = fetchAttachmentFromDB(attachmentsByInqId,fileVersionMap);
				}
				if (null != filesMap) {
					fileMapToZip.putAll(filesMap);
				}
			}
		}
		if(!fileMapToZip.isEmpty()){
			subLogger.info("Creating zip file name :"+fileNameZip+ " from no of src files: "+fileMapToZip.size());
			zipFile = ZipUtil.createZipFile(fileNameZip, fileMapToZip);
			ZipUtil.deleteFileFromTemp(fileMapToZip);
		}
		return zipFile;
	}

	/**
	 * This method fetch file from DB
	 * @param attachmentsByInqId
	 * @param fileVersionMap 
	 * @return
	 * @throws CommunicatorException
	 */
	private Map<String, File> fetchAttachmentFromDB(List<Attachment> attachmentsByInqId, Map<String, Integer> fileVersionMap) throws CommunicatorException {
		Map<String, File> fileMap = new HashMap<>();
		for (Attachment attachment : attachmentsByInqId) {
			String docId = attachment.getId();
			String fileName;
			try {
				AttachmentDAO attachmentDao = new AttachmentDAO();
				subLogger.info("Reading file from Mongo DB for docId=" + docId);
				Map<String, Object> mongoDataMap = attachmentDao.getFile(docId);
				fileName = (String) mongoDataMap.get("name");
				File file = (File) mongoDataMap.get("fileObject");
				if(fileVersionMap.containsKey(fileName)){
					int fileVersion = fileVersionMap.get(fileName).intValue()+1;
					String fileNameWithoutExtn = fileName.substring(0, fileName.lastIndexOf(CHAR_DOT));
					String fileExtn =  (String) mongoDataMap.get("type");
					String fileNameWithVersion = fileNameWithoutExtn+"("+fileVersion+")."+fileExtn;
					fileVersionMap.put(fileName, fileVersion);
					fileName = fileNameWithVersion;
				}else{
					fileVersionMap.put(fileName,0);
				}
				fileMap.put(fileName, file);
				subLogger.info("Successfully Read file from Mongo DB for docId=" + docId + "fileName = "+ fileName);
				TimeUnit.MILLISECONDS.sleep(5);
			} catch(InterruptedException ex) {
				subLogger.error("An InterruptedException was caught: " + ex.getMessage());
				Thread.currentThread().interrupt();
			} catch (Exception e) {
				subLogger.error("Exception while reading file from Mongo DB for docId =" + docId, e);
				throw new CommunicatorException(e.getMessage());
			}
		}
		return fileMap;
	}

	/**
	 * Get client details by domain name or email id
	 * @param email
	 * @return
	 */
	public Response getClientDetails(String email) {
		Response response = null;
		try {
			if (!StringUtils.isEmpty(email)) {
				response = getResponseFromClientMapping(email);
			} else {
				return Response.status(400).entity("Bad request. Email is empty or null").build();
			}
		} catch (Exception e) {
			subLogger.error("Error while getClientDetails for email domain:"+email, e);
			return Response.status(400).entity("Exception while getClientDetails" + e).build();
		}
		return response;
	}

	/**
	 * Get client details from cache. If email provided get by emailId, if only domain provided get it using domain.
	 * @param email
	 * @return
	 * @throws IOException
	 */
	private Response getResponseFromClientMapping(String email) throws IOException {
		Response response;
		ClientMapping clientMapping = ClientMappingUtil.getClientMappingByEmail(email);
		if(null != clientMapping){
			subLogger.debug("Client mapping:"+clientMapping.toString());
			response = DataConversionUtil.sendJsonResponseForBean(clientMapping);
		}else{
			return Response.status(404).entity("{\"message\":\"Client not found\"}").build();
		}
		return response;
	}
	
	
	
	public void addNotesToInquiry(String soeId,String loginUserName, List<String> userNotes, Inquiry inquiryObj)// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			List<Note> noteList = inquiryObj.getUserNotes();
			if(noteList == null){
				noteList = new ArrayList<>();
			}
			
			for(String note : userNotes){
				Note userNote = new Note(soeId, loginUserName, new Date(), note);
				noteList.add(userNote);
			}
			inquiryObj.setUserNotes(noteList);
			inquiryObj.setNotesFlag("Y");
		}
		catch (Exception e)
		{
			subLogger.error("Exception in addNotesToInquiry for user= " + soeId, e);
			
		}
		
	}
	
	public void addNotesToDraft(String soeId,String loginUserName, List<String> userNotes, Draft draftObj)// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			List<Note> noteList = draftObj.getUserNotes();
			if(noteList == null){
				noteList = new ArrayList<>();
			}
			
			for(String note : userNotes){
				Note userNote = new Note(soeId, loginUserName, new Date(), note);
				noteList.add(userNote);
			}
			draftObj.setUserNotes(noteList);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in addNotesToDraft for user= " + soeId, e);
			
		}
		
	}
	/**
	 * get view filters by userID
	 * @param soeId
	 * @return
	 */
	private BasicDBList getViewFilters(String soeId) {
		BasicDBObject viewFilters = userDao.getViewFilters(soeId);
		if(null != viewFilters && viewFilters.getBoolean(AppserverConstants.SUCCESS_KEY)){
			return (BasicDBList) viewFilters.get(VIEW_FILTERS);
		}else{
			return new BasicDBList();
		}
		
	}

	/**
	 * @param inputJsonObj
	 * @param soeId
	 * @param servletRequest 
	 * @return
	 * @throws CommunicatorException
	 */
	public boolean snoozeInquiry(BasicDBObject inputJsonObj, String soeId) throws CommunicatorException {
		boolean bSucess = Boolean.FALSE;
		List<Long> inquiryIds = null;
		try
		{
			if (inputJsonObj != null && !StringUtils.isBlank(inputJsonObj.getString(ACTION))) {
				DBObject snoozeObj = (DBObject) inputJsonObj.get(SNOOZE);
				String snoozeAction = inputJsonObj.getString(ACTION);
				inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
				List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);
				bSucess = saveOrRemoveSnooze(inputJsonObj, soeId, inquiryIds, snoozeObj, snoozeAction, inquiryObjects);
			}else{
				subLogger.error("No Snooze/Un-Snooze Action received for user=" + soeId + "as the inputJsonObj" + inputJsonObj);
				throw new CommunicatorException("Exception in getting the Snooze Un-Snooze action for user= " + soeId);
			}

		}
		catch (Exception e)
		{
			subLogger.error("Exception in lockingInquiry for user= " + soeId, e);
			throw new CommunicatorException("Exception in lockingInquiry for user= " + soeId, e);
		}
		return bSucess;
	}

	/**
	 * This method will save snooze data
	 * @param inputJsonObj
	 * @param soeId
	 * @param bSucess
	 * @param inquiryIds
	 * @param snoozeObj
	 * @param snoozeAction
	 * @param inquiryObjects
	 * @param servletRequest 
	 * @return
	 * @throws CommunicatorException
	 */
	private boolean saveOrRemoveSnooze(BasicDBObject inputJsonObj, String soeId, List<Long> inquiryIds,
			DBObject snoozeObj, String snoozeAction, List<Inquiry> inquiryObjects) throws CommunicatorException {
		List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
		boolean isMultiGroupAction = inputJsonObj.getBoolean(IS_MULTI_GROUP_ACTION_KEY);
		String commonGroupId = inputJsonObj.getString(COMMON_GROUP_ID_KEY);
		if (inquiryIds.size() != groupIds.size()) {
			subLogger.info("Invalid Input for Snooze/Un-Snooze action -" + " by " + soeId+ ". InquiryIdList size and groupIdList size do not match.");
			throw new CommunicatorException("InquiryIdList size - [" + inquiryIds.size() + "] and groupIdList size - ["	+ groupIds.size() + "] do not match for Snooze/Un-Snooze.");
		}
		Map<Long, String> inquiryGroupIdMap = populateInquiryGrpMapForMultiGrpAction(snoozeAction, groupIds,isMultiGroupAction);
		Date currentTime = new Date();
		DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, snoozeAction);

		DBObject inquiryUnsetDBObj = null;
		boolean snoozeSuccess = false;
		boolean bSucess = false;
		List<InquirySnoozeDetails> listSnoozeDetails = new ArrayList();
		if(inquiryGroupIdMap.isEmpty()){
			for(String groupId: groupIds){
				String groupVsInquiryArr[] = groupId.split(":");
				Long inquiryId = Long.parseLong(groupVsInquiryArr[0]);
				Long assignedGroupId = Long.parseLong(groupVsInquiryArr[1]);
				InquirySnoozeDetails inquirySnoozeDetails = prepareSnoozeDetailsObject(soeId, snoozeObj, inquiryId,assignedGroupId);
				if(null != inquirySnoozeDetails){
					listSnoozeDetails.add(inquirySnoozeDetails);
				}
			}
		} else {
			for (Entry<Long, String> entries : inquiryGroupIdMap.entrySet()) {
				Long inquiryId = entries.getKey();
				Long assignedGroupId = Long.parseLong(entries.getValue());
				InquirySnoozeDetails inquirySnoozeDetails = prepareSnoozeDetailsObject(soeId, snoozeObj, inquiryId,assignedGroupId);
				if(null != inquirySnoozeDetails){
					listSnoozeDetails.add(inquirySnoozeDetails);
				}
			}
		}
		if (!listSnoozeDetails.isEmpty()) {
			inquiryUpdateDBObj.put(WORKFLOWS_ACTION, snoozeAction);
			boolean snoozeFlag = "Snooze".equalsIgnoreCase(snoozeAction);
			if(snoozeFlag){
				inquiryUpdateDBObj.put("workflows.$.snoozeAction", snoozeAction);
				inquiryUpdateDBObj.put("workflows.$.isWorkflowEverSnoozed","Y");  //C153176-6167 |flag for ever inquiry has been snoozed
			} else {
				inquiryUnsetDBObj = new BasicDBObject();
				inquiryUnsetDBObj.put("workflows.$.snoozeAction", null);
			}
			
			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfoMap = populateInquiryInfoMap(dbObjs, null, null);
			bSucess = bulkMultiGroupAction(soeId, inquiryObjects, isMultiGroupAction, inquiryGroupIdMap, commonGroupId,
					snoozeAction, inquiryUpdateDBObj, inquiryUnsetDBObj, inquiryInfoMap);
			//for un-snooze action calculate escalation response time
			if(!snoozeFlag){
				calculateAndSetResponseEscalationTime(listSnoozeDetails);
			}
		}
		return bSucess;
	}

	/**
	 * @param listSnoozeDetails
	 */
	private void calculateAndSetResponseEscalationTime(List<InquirySnoozeDetails> listSnoozeDetails) {
		subLogger.info("Inside calculateAndSetResponseEscalationTime ");
		try {
			DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
			
			String findInquiryQuery = "{'_id': #INQUIRYID#, 'workflows': {'$elemMatch': {'assignedGroupId': #ASSIGNEDGROUPID#, 'direction': 'IN', 'responseTimeEscalationFlag':'N'}}}";
			String findWorkflowQuery = "{'_id': #INQUIRYID#, 'workflows.assignedGroupId': #ASSIGNEDGROUPID#, 'workflows.direction': 'IN', 'workflows.responseTimeEscalationFlag':'N'}";
			
			
			for(InquirySnoozeDetails inqSnoozeDetail : listSnoozeDetails){
				findInquiryQuery = findInquiryQuery.replaceAll("#INQUIRYID#", inqSnoozeDetail.getInquiryId().toString());
				findInquiryQuery = findInquiryQuery.replaceAll("#ASSIGNEDGROUPID#", inqSnoozeDetail.getAssignedGroupId().toString());
				
				findWorkflowQuery = findWorkflowQuery.replaceAll("#INQUIRYID#", inqSnoozeDetail.getInquiryId().toString());
				findWorkflowQuery = findWorkflowQuery.replaceAll("#ASSIGNEDGROUPID#", inqSnoozeDetail.getAssignedGroupId().toString());
				
				String aggregateQueryWorkflow = "["+
						"{'$match':"+findInquiryQuery+"}"+
						", {'$unwind':'$workflows'}"+

						",{'$match':"+findWorkflowQuery+"}"+
						",{'$project':{'responseTimeNextEscalation':'$workflows.responseTimeNextEscalation'}}"+
						  "]";
				List<DBObject> query = (List<DBObject>) BasicDBObject.parse(aggregateQueryWorkflow);
				AggregationOptions options = AggregationOptions.builder().allowDiskUse(true).build();
				subLogger.info("query to get responseEscalationTime : "+query);
				Cursor cur = inquiryCollection.aggregate(query, options, ReadPreference.primary());
				Date responseTimeEscalation = null;
				while (cur.hasNext()) {
					BasicDBObject o = (BasicDBObject) cur.next();
					responseTimeEscalation = (Date) o.get("responseTimeNextEscalation");
					subLogger.info("inside cursor : "+responseTimeEscalation);
				}
				subLogger.info("response time for inquiry: "+inqSnoozeDetail.getInquiryId()+" and assigned group Id :"+inqSnoozeDetail.getAssignedGroupId()+" is : "+ responseTimeEscalation);
				if(null != responseTimeEscalation){
					Date snoozeResponseEscalationTime = calculateResponseEsacalationTime(responseTimeEscalation, inqSnoozeDetail);
					DBObject findINQuery = prepareFindQuery(inqSnoozeDetail.getInquiryId(), inqSnoozeDetail.getAssignedGroupId(), STATUS_OPEN, INQUIRY_DIRECTION_IN, false);
					DBObject inquiryUpdateDBObj = new BasicDBObject();
					DBObject updateDBFields = new BasicDBObject();
					inquiryUpdateDBObj.put(WORKFLOWS_RESPONSE_TIME_NEXT_ESACLATION, snoozeResponseEscalationTime);
					updateDBFields.put("$set", inquiryUpdateDBObj);
					BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();
					bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);
					bulkInquiryUpdOp.execute();
				}
				
			}
			
			
		} catch (Exception e) {
			subLogger.error("Exception in calculateAndSetResponseEscalationTime", e);
		}
		
	}

	/** calculate new response with snooze time
	 * @param responseTimeEscalation
	 * @param inqSnoozeDetail
	 * @return
	 */
	private Date calculateResponseEsacalationTime(Date responseTimeEscalation, InquirySnoozeDetails inqSnoozeDetail) {
		long total = 0;
		try {
			long snoozedTime = inqSnoozeDetail.getSnoozeEndTime().getTime() - inqSnoozeDetail.getCrtDate().getTime();
			total = responseTimeEscalation.getTime()+snoozedTime;
			long currentTime = new Date().getTime();
			if(total<currentTime){
				total = currentTime;
			}
		} catch (Exception e) {
			subLogger.error("error in calculateResponseEsacalationTime", e);
			return responseTimeEscalation;
		}
		return new Date(total);
	}

	private InquirySnoozeDetails prepareSnoozeDetailsObject(String soeId, DBObject snoozeObj, Long inquiryId, Long assignedGroupId)
			throws CommunicatorException {
		boolean snoozeSuccess ;
		InquirySnoozeDetails inquirySnoozeDetails = null;
		inquirySnoozeDetails = getInquirySnoozeDetails(inquiryId, assignedGroupId);
		if(inquirySnoozeDetails == null) {
			//create new record
			inquirySnoozeDetails = new InquirySnoozeDetails();
			inquirySnoozeDetails.setProcessedFlag(false);
			inquirySnoozeDetails.setInquiryId(inquiryId);
			inquirySnoozeDetails.setAssignedGroupId(assignedGroupId);
		}
		//snooze case
		if (null != snoozeObj && null != snoozeObj.get(SNOOZE_DURATION)) {
			String snoozeDuration = (String) snoozeObj.get(SNOOZE_DURATION);
			inquirySnoozeDetails.setSnoozeDuration(snoozeDuration);
			inquirySnoozeDetails.setSnoozedBy(soeId);
			calculateSnoozeDuration(inquirySnoozeDetails, snoozeDuration);
			//snoozeSuccess = saveSnoozeDetails(inquirySnoozeDetails);
			inquirySnoozeDetails = saveSnoozeDetails(inquirySnoozeDetails);
		} else {//unsnooze case
			inquirySnoozeDetails.setProcessedFlag(true);
			inquirySnoozeDetails.setSnoozeEndTime(new Date());
			//snoozeSuccess = saveSnoozeDetails(inquirySnoozeDetails);
			inquirySnoozeDetails = saveSnoozeDetails(inquirySnoozeDetails);
		}
		return inquirySnoozeDetails;
	}
	/**
	 * @param inquirySnoozeDetails
	 * @return
	 */
	private InquirySnoozeDetails saveSnoozeDetails(InquirySnoozeDetails inquirySnoozeDetails) {
		boolean success;
		try {
			Query<InquirySnoozeDetails> query = mongoDatastore.createQuery(InquirySnoozeDetails.class).filter("processedFlag", false)
					.filter("inquiryId", inquirySnoozeDetails.getInquiryId()).filter("assignedGroupId", inquirySnoozeDetails.getAssignedGroupId());
			InquirySnoozeDetails snoozeDetails = query.get();
			if(null != snoozeDetails){
				UpdateOperations<InquirySnoozeDetails> updateOps = mongoDatastore.createUpdateOperations(InquirySnoozeDetails.class);
				updateOps.set("processedFlag", inquirySnoozeDetails.isProcessedFlag());
				updateOps.set("snoozeDuration", inquirySnoozeDetails.getSnoozeDuration());
				updateOps.set("snoozeStartTime", inquirySnoozeDetails.getSnoozeStartTime());
				updateOps.set("snoozeEndTime", inquirySnoozeDetails.getSnoozeEndTime());
				updateOps.set("snoozedBy", inquirySnoozeDetails.getSnoozedBy());
				//updateOps.set("assignedGroupId", inquirySnoozeDetails.getAssignedGroupId());
				inquirySnoozeDetails.setModDate(new Date());
				inquirySnoozeDetails.setCrtDate(snoozeDetails.getCrtDate());
				updateOps.set("modDate",inquirySnoozeDetails.getModDate());
				mongoDatastore.update(query, updateOps);
			}else{
				inquirySnoozeDetails.setCrtDate(new Date());
				mongoDatastore.save(inquirySnoozeDetails);
			}
			success = true;
		} catch (Exception e) {
			success = false;
			inquirySnoozeDetails = null;
			subLogger.error("Exception while save/update snoozeDetails", e);
		}
		return inquirySnoozeDetails;
	}
	/**
	 * This method will calculate snooze endTime as per given input in min/hr/day/week/month/year
	 * @param modifiedSnoozeObj
	 * @param object 
	 * @throws CommunicatorException 
	 */
	private void calculateSnoozeDuration(InquirySnoozeDetails inquirySnoozeDetails, String snoozeDuration) throws CommunicatorException {
		Date startTime = new Date(); //now
		Date endTime = startTime;
		try {
			if (snoozeDuration.contains(TIME_IN_MIN) && snoozeDuration.contains(TIME_IN_HR) // for C153176-6167|custom snooze time
					&& snoozeDuration.contains(TIME_IN_DAY)) {
				String duration[] = snoozeDuration.split(":");
				if (duration.length == 3) {
					String dayTime = duration[0];
					String hourTime = duration[1];
					String minTime = duration[2];
					String addDayTime = dayTime.substring(0, dayTime.indexOf(TIME_IN_DAY));
					endTime = DateUtils.addDays(startTime, Integer.parseInt(addDayTime.trim()));
					String addHrsTime = hourTime.substring(0, hourTime.indexOf(TIME_IN_HR));
					endTime = DateUtils.addHours(endTime, Integer.parseInt(addHrsTime.trim()));
					String addMinuteTime = minTime.substring(0, minTime.indexOf(TIME_IN_MIN));
					endTime = DateUtils.addMinutes(endTime, Integer.parseInt(addMinuteTime.trim()));
				}
		  }else if(snoozeDuration.contains(TIME_IN_MIN)){
				String addMinuteTime = snoozeDuration.substring(0, snoozeDuration.indexOf(TIME_IN_MIN));
				endTime = DateUtils.addMinutes(startTime, Integer.parseInt(addMinuteTime.trim()));
			}else if(snoozeDuration.contains(TIME_IN_HR)){
				String addHrsTime = snoozeDuration.substring(0, snoozeDuration.indexOf(TIME_IN_HR));
				endTime = DateUtils.addHours(startTime, Integer.parseInt(addHrsTime.trim()));
			}else if(snoozeDuration.contains(TIME_IN_DAY)){
				String addDayTime = snoozeDuration.substring(0, snoozeDuration.indexOf(TIME_IN_DAY));
				endTime = DateUtils.addDays(startTime, Integer.parseInt(addDayTime.trim()));
			}else if(snoozeDuration.contains(TIME_IN_WEEK)){
				String addWeekTime = snoozeDuration.substring(0, snoozeDuration.indexOf(TIME_IN_WEEK));
				endTime = DateUtils.addWeeks(startTime, Integer.parseInt(addWeekTime.trim()));
			}else if(snoozeDuration.contains(TIME_IN_MONTH)){
				String addMonthTime = snoozeDuration.substring(0, snoozeDuration.indexOf(TIME_IN_MONTH));
				endTime = DateUtils.addMonths(startTime, Integer.parseInt(addMonthTime.trim()));
			}else if(snoozeDuration.contains(TIME_IN_YEAR)){
				String addYearTime = snoozeDuration.substring(0, snoozeDuration.indexOf(TIME_IN_YEAR));
				endTime = DateUtils.addYears(startTime, Integer.parseInt(addYearTime.trim()));
			}
			
			inquirySnoozeDetails.setSnoozeStartTime(startTime);
			inquirySnoozeDetails.setSnoozeEndTime(endTime);
		} catch (Exception e) {
			subLogger.error("Exception while calculating endTime. Please vallidate input :["+snoozeDuration+"] "+e);
			throw new CommunicatorException("Exception while calculating endTime. Please vallidate input :["+snoozeDuration+"] "+e);
		}
	}
	
	/** to get total record count for QMA2
	 * @param collectionName
	 * @param finalQuery
	 * @return
	 */
	int getViewDataCount(String collectionName, DBObject finalQuery)
	{
		long startTime = System.currentTimeMillis();
		int totalRecords = database.getCollection(collectionName).find(finalQuery).count();

		subLogger.info("Inside .getViewDataCount Time Diff-"
				+ (System.currentTimeMillis() - startTime)
				+ " in Milli Seconds");
		return totalRecords;
		
	}
	
	/** to user name if userId is available
	 * @param conversationTO
	 * @return
	 * @throws CommunicatorException
	 */
	public void getUserDisplayName(Conversation conv) throws CommunicatorException
	{
		try
		{
			if (null != conv && null != conv.getRecipients() && !conv.getRecipients().isEmpty()) {
                ConversationRecipient firstRecipient = conv.getRecipients().get(0);
				if (null != firstRecipient && null != firstRecipient.getUserId())
				{
					String userId = conv.getRecipients().get(0).getUserId();
					if (!StringUtils.isBlank(userId) && !userId.contains("@"))
					{
						User user = QMACacheFactory.getCache().getUserInfoMap().get(userId.toUpperCase());
						if(null != user && !StringUtils.isBlank(user.getLongDesc())) {
							conv.getRecipients().get(0).setDisplayUserName(user.getLongDesc());
						} else if(null != user && !StringUtils.isBlank(user.getName())) {
							conv.getRecipients().get(0).setDisplayUserName(user.getName());
						}
					}
				}
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getUserDisplayName", e);
			throw new CommunicatorException("Exception in getUserDisplayName for user");
		}
	}	
	
	
	/**
	 * Method to mark inquiry as non-inquiry or inquiry. 
	 * 
	 * @param soeId
	 * @param inputJsonObj
	 * @param servletRequest
	 * @return
	 * @throws CommunicatorException 
	 */
	public boolean markAsInquiryOrNonInquiry(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {
		boolean bSucess = Boolean.FALSE;
		List<Long> inquiryIds = null;
		try
		{
			if (inputJsonObj == null || StringUtils.isBlank(inputJsonObj.getString("action"))) {
				subLogger.error("No Mark Inquiry As Non-Inquiry/Inquiry Action received for user=" + soeId + "as the inputJsonObj" + inputJsonObj);
				throw new CommunicatorException("Exception in getting the Mark Inquiry As Non-Inquiry/Inquiry action for user= " + soeId);
			}
			DBObject nonInquiryObj = (DBObject) inputJsonObj.get("nonInquiry");
			String inquiryAction = inputJsonObj.getString("action");
			inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);
			
			if (inquiryObjects == null || inquiryObjects.isEmpty()) {
				subLogger.error("No Inquiries received for user=" + soeId + "as the inquiryObjs is null or empty " + inquiryObjects.size());
				throw new CommunicatorException("Exception in getting the inquiries for user= " + soeId);
			}
			
			List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			boolean isMultiGroupAction = inputJsonObj.getBoolean(IS_MULTI_GROUP_ACTION_KEY);
			String commonGroupId = inputJsonObj.getString(COMMON_GROUP_ID_KEY);
			if (inquiryIds.size() != groupIds.size()) {
				subLogger.info("Invalid Input for Mark Inquiry As Non-Inquiry/Inquiry action -" + " by " + soeId + ". InquiryIdList size and groupIdList size do not match.");
				throw new CommunicatorException("InquiryIdList size - [" + inquiryIds.size() + "] and groupIdList size - [" + groupIds.size() + "] do not match for Mark Inquiry As Non-Inquiry/Inquiry.");
			}

			Map<Long, String> inquiryGroupIdMap = populateInquiryGrpMapForMultiGrpAction(inquiryAction, groupIds, isMultiGroupAction);
			Date currentTime = new Date();
			
			// Prepare update fields
			DBObject inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, inquiryAction);
			
			DBObject inquiryUnsetDBObj = null;
			if (null != nonInquiryObj) {
				inquiryUpdateDBObj.put("workflows.$.rulesFlag", nonInquiryObj);
				inquiryUpdateDBObj.put(WORKFLOWS_ACTION, inquiryAction);
		}
			else
			{
				inquiryUpdateDBObj.put(WORKFLOWS_ACTION, inquiryAction);
				inquiryUnsetDBObj = new BasicDBObject("workflows.$.rulesFlag", null); // Set null instead of blank.
	}
	
			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfoMap =  populateInquiryInfoMap(dbObjs, null, null);
	
			bSucess = bulkMultiGroupAction(soeId, inquiryObjects, isMultiGroupAction, inquiryGroupIdMap, commonGroupId, inquiryAction, inquiryUpdateDBObj, inquiryUnsetDBObj, inquiryInfoMap);
			if (bSucess) {
				saveInquiriesToPublish(inquiryIds, inquiryAction, soeId);
			}
			}
		catch (Exception e)	{
			subLogger.error("Exception in Mark Inquiry As Non-Inquiry/Inquiry for user= " + soeId, e);
			throw new CommunicatorException("Exception in Mark Inquiry As Non-Inquiry/Inquiry for user= " + soeId, e);
		}
		return bSucess;
	}

	/**
	 * C153176-5653 for Update response time calculations logic in QMA
	 * 
	 * Method to update the Response time for the clients consecutive emails.
	 * 
	 * @param currentTime
	 * @param workflowList
	 * @param fromGroupId
	 * @param stats
	 */
	private void updateResponseTimeInStatistics(Date currentTime, List<Workflow> workflowList, Long fromGroupId, DBObject stats) {
		try {
			Date lastConvTime = null;

			Workflow inWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_IN);
			Workflow outWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_OUT);
			Workflow wf = null != inWorkflow ? inWorkflow : (null != outWorkflow ? outWorkflow : null);

			// 3. In case of client sending 2 x consecutive e-mails, 
			// QMA should measure the time from first client e-mail received or first client e-mail received after Citiâ€™s last action was â€œResolveâ€�
			if (null != wf && null != wf.getClientChaseCounter() && wf.getClientChaseCounter() > 0 	&& wf.getStatus().equalsIgnoreCase("open")) {
				lastConvTime = null != wf.getLatestConversationTime() ?  wf.getLatestConversationTime() : currentTime;
				
				// Latest Conversation Time was time when CITI perform last response. On reopen inquiry, the latest conversation tie not gets updated.
				// Latest Conversation Time always before than Reopen Date. We need to consider reopen date.
				if (null != wf.getReOpenDate() && lastConvTime.getTime() < wf.getReOpenDate().getTime()) {
					lastConvTime = wf.getReOpenDate();
					}
				}

			if (null != lastConvTime) {
				long responseTime = (currentTime.getTime() - lastConvTime.getTime()) / 60000;
				stats.put("responseTime", responseTime);
				stats.put("responseTimeInMinutes", calculateResponseTimeWrkShiftBased(currentTime, lastConvTime, fromGroupId));
			}
		} catch (Exception e) {
			subLogger.error("Invalid input for updateResponseTimeInStatistics for fromGroupId = " + fromGroupId);
		}
	}

	/**
	 * Method to calculate the time considering work shift timing of a group.
	 * 
	 * @param currentTime - Current Time.
	 * @param startDate - Start Date
	 * @param groupId - Group id
	 * 
	 * @return response time {@link long}
	 */
	private long calculateResponseTimeWrkShiftBased(Date currentTime, Date startDate, Long groupId) {
		long newResponseTimeInMins = 0;
		try {
			BasicDBObject resultObj = new BasicDBObject();
			AgeAndTimeUtils.getTimeDiffBasedOnAgeConfig(resultObj, groupId,	startDate, currentTime, AppserverConstants.TIME_UNIT_MINS);
			
			if (null != resultObj.get(AppserverConstants.TIME_DIFF)) {
				newResponseTimeInMins = resultObj.getLong(AppserverConstants.TIME_DIFF);
				subLogger.info("Response time in minutes considering working hours logic : " + newResponseTimeInMins);
			}
			else if (null != startDate) {
				newResponseTimeInMins = ((currentTime.getTime() - startDate.getTime()) / 60000);
				subLogger.info("Response time in minutes : " + newResponseTimeInMins);
			}
		} catch (Exception e) {
			subLogger.error("error calculating response time in minutes"+e);
		}
		return newResponseTimeInMins;
	}

	/**
	 * Method to calculate CITI response time.
	 * 
	 * @param workflowList
	 * @param fromGroupId
	 * @param currentTime
	 */
	private void calculateCitiResponseTime(List<Workflow> workflowList, Long fromGroupId, Date currentTime) {
		try {
			Workflow inWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_IN);
			Workflow outWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_OUT);
			Workflow paWorkflow = getWorkflow(workflowList, fromGroupId, INQUIRY_DIRECTION_PENDING_APPROVAL);

			Date firstNonChaserResponseTimeFromExternal = null != inWorkflow && null != inWorkflow.getFirstNonChaserResponseTimeByExternal() ? inWorkflow.getFirstNonChaserResponseTimeByExternal()	: currentTime;
			if (null != firstNonChaserResponseTimeFromExternal && null != outWorkflow && null != outWorkflow.getFirstNonChaserResponseTimeByExternal() && firstNonChaserResponseTimeFromExternal.getTime() > outWorkflow.getFirstNonChaserResponseTimeByExternal().getTime())
			{
				firstNonChaserResponseTimeFromExternal = outWorkflow.getFirstNonChaserResponseTimeByExternal();
			}
			if (null != firstNonChaserResponseTimeFromExternal && null != paWorkflow && paWorkflow.getFirstNonChaserResponseTimeByExternal() != null && firstNonChaserResponseTimeFromExternal.getTime() > paWorkflow.getFirstNonChaserResponseTimeByExternal().getTime())
			{
				firstNonChaserResponseTimeFromExternal = paWorkflow.getFirstNonChaserResponseTimeByExternal();
			}
			subLogger.info("Considered firstNonChaserResponseTimeFromExternal for response calculation = " + firstNonChaserResponseTimeFromExternal);
			// long newCitiResponseTime = (currentTime.getTime() - firstNonChaserResponseTimeFromExternal.getTime()) / 1000;

			// C153176-5891 | Considering Working hour logic.
			long newCitiResponseTime = this.calculateResponseTimeWrkShiftBased(currentTime, firstNonChaserResponseTimeFromExternal, fromGroupId);
			long totalCitiResponseTime = 0;
			totalCitiResponseTime = newCitiResponseTime;
			updateCitiQMAResponseTime(inWorkflow, currentTime, newCitiResponseTime, totalCitiResponseTime, firstNonChaserResponseTimeFromExternal);
			updateCitiQMAResponseTime(outWorkflow, currentTime, newCitiResponseTime, totalCitiResponseTime, firstNonChaserResponseTimeFromExternal);
			updateCitiQMAResponseTime(paWorkflow, currentTime, newCitiResponseTime, totalCitiResponseTime, firstNonChaserResponseTimeFromExternal);
			}
		catch (Exception ex) {
			subLogger.error("Failed to calculate CITI response Time in calculateCitiResponseTime(), due to :"+ ex.getMessage());
		}
	}

	/**
	 * Method to calculate and update the total CITI Response time.
	 * 
	 * @param workflow
	 * @param currentTime
	 * @param newResponseTimeQMA
	 * @param totalResponseTimeQMA
	 * @param firstNonChaserResponseTimeFromExternal
	 */
	private void updateCitiQMAResponseTime(Workflow workflow, Date currentTime, long newCitiResponseTime, long totalCitiResponseTime, Date firstNonChaserResponseTimeFromExternal) {
		try {
			if (null != workflow) {
				int citiReplyCountFromQMA = 1;
				Long previousCitiResponse = workflow.getCitiResponseTime();
				if (null != previousCitiResponse) {
					totalCitiResponseTime = previousCitiResponse + newCitiResponseTime;
				}

				// C153176-5891 | When we consider response time in minutes, if any response perform only in seconds, we are considering as 0 minutes
				// Still there is reply, so both response time and count should be incremented.
				if (totalCitiResponseTime >= 0) {
					workflow.setCitiResponseTime(totalCitiResponseTime);

					// Update citi reply count from QMA
					if (null != workflow.getCitiReplyCountFromQMA()) {
						citiReplyCountFromQMA = workflow.getCitiReplyCountFromQMA().intValue() + 1;
					}
					workflow.setCitiReplyCountFromQMA(citiReplyCountFromQMA);

					// C153176-5891 : Update the firstNonChaserResponseTimeByExternal to current time. It will calculate the correct time in case of consecutive reply action from QMA.
					workflow.setFirstNonChaserResponseTimeByExternal(currentTime);
				}
				
				// C153176-5354 - Update the response time for working hours
				// this.updateQMAResponseTimeInMins(workflow, currentTime, lastConvTime);
			}
		} catch (Exception ex) {
			subLogger.error("Failed to calculate and update CITI response Time in updateCitiQMAResponseTime(), due to :"+ ex.getMessage());
		}
	}

	public BasicDBObject sendEmailViaEWS(BasicDBObject inputJsonObj, String soeId, String content)
			throws CommunicatorException {
		BasicDBObject response = null;
		Long inquiryId = GenericUtility.getIdFromRequest(inputJsonObj, INQUIRY_ID);
		String inquiryAction = inputJsonObj.getString("inquiryAction");
		try {
			//String requestType = inputJsonObj.getString(REQUEST_TYPE);
			String to = inputJsonObj.getString(TO);
			String fromGroup = inputJsonObj.getString(FROM);
			List<Attachment> attachmentsList = getAttachmentsInfo(inputJsonObj);
			String parentConversationId = inputJsonObj.getString("parentConversation");
			Long fromGroupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(fromGroup.toUpperCase());
			String conversationContent = content;
			

			if (StringUtils.isBlank(inquiryAction) || StringUtils.isBlank(fromGroup) || StringUtils.isBlank(to)) {
				subLogger.info(
						"Invalid Input for sendEmailViaEWS" + inquiryAction + " for Id=" + inquiryId + " by " + soeId);
				throw new CommunicatorException("Invalid Data for sendEmailViaEWS.");
			}

			String exchItemId = null;
			if (QMAActionEnum.ACTION_REPLY.getName().equalsIgnoreCase(inquiryAction)
					|| QMAActionEnum.ACTION_REPLY_ALL.getName().equalsIgnoreCase(inquiryAction)
					|| QMAActionEnum.ACTION_FORWARD.getName().equalsIgnoreCase(inquiryAction)) {
				if (StringUtils.isBlank(parentConversationId)) {
					String errMsg = "For actions viz. Reply and ReplyAll, a valid parentConversationId must be provided";
					subLogger.info(errMsg);
					throw new CommunicatorException(errMsg);
				} else {
					Conversation conv = getConversationById(Long.parseLong(parentConversationId));
					if (conv != null) {
						exchItemId = getExchRecipientItemId(fromGroupId, soeId, conv.getExchangeRecipients());
						if (StringUtils.isBlank(exchItemId)) {
							subLogger.info("Invalid Exchange account setup  - " + inquiryAction + " for Id=" + inquiryId
									+ " by " + soeId);
							throw new CommunicatorException("Invalid Exchange account setup for " + fromGroup);
						}
					}
				}
			}
			Map<String, List<String>> recipientMap = InquiryUtil.getEWSEmailRecpMap(inputJsonObj, soeId);
			boolean bSuccess = InquiryUtil.sendEWSMail(soeId, inquiryAction, inputJsonObj.getString(SUBJECT),
					conversationContent, recipientMap, exchItemId,attachmentsList, attachDao);

			/// TODO: if(bSuccess){
			subLogger.info("sendEmailViaEWS- success -" + bSuccess);
			response = new BasicDBObject();
			response.put("inquiryId", "1");
			response.put("conversationId", "2");

		} catch (Exception e) {
			subLogger.error("Exception in saveInquiry for user= " + soeId + " , InquiryAction=" + inquiryAction
					+ ", inquiryId=" + inquiryId, e);
			throw new CommunicatorException("Exception in saveInquiry for user= " + soeId + " , InquiryAction="
					+ inquiryAction + ", inquiryId=" + inquiryId, e);
		}
		return response;
	}
	
	public Conversation getConversationById(Long conversationId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		return mongoDatastore.get(Conversation.class, conversationId);
		}
		
	public String getExchRecipientItemId(Long groupId,String userId,List<ExchangeRecipient> exchRecipients) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		for(ExchangeRecipient recp:exchRecipients){
			if(groupId.equals(recp.getGroupId())// && userId.equalsIgnoreCase(recp.getUserId())
					)
				return recp.getExchItemId();
	}
		return null;
	}
   /**
    * Method to delete the EWS Email by Exchange Item It.
    * 
    * @param soeId
    * @param ewsItemIdList
    * @return
    * @throws CommunicatorException
    */
	public Boolean deleteEWSEmailById(String soeId, List<Long> ewsItemIdList) throws CommunicatorException {
		Boolean isDeleted = Boolean.FALSE;
		if (ewsItemIdList == null) {
			subLogger.error("Invalid input deleteEWSEmailById for ewsItemId= " + ewsItemIdList);
			throw new CommunicatorException("Invalid input deleteEWSEmailById for ewsItemId= " + ewsItemIdList);
		}
		try {
			String action = QMAActionEnum.ACTION_DELETE_ITEM_EWS.getName();
			String deleteMode = DeleteMode.MoveToDeletedItems.name();
			String exchItemId = ewsItemIdList.get(0).toString();
			isDeleted = InquiryUtil.deleteItemUsingEWS(soeId, action, exchItemId, deleteMode);
		} catch (Exception e) {
			subLogger.error("Exception in deleteEWSEmailById for ewsItemId= " + ewsItemIdList.toString(), e);
			throw new CommunicatorException("Exception in deleteEWSEmailById for ewsItemId= " + ewsItemIdList.toString(), e);
		}
		return isDeleted;
	}
	
	//[C170665-1719] DCC Requirement: Add Case status field
	//Capturing changed value for Inquiry Sub-Status from ui
	private List<Workflow> setChangedInquirySubStatus(List<Workflow> workflowList,String newChangeStatusValue,Long fromGroupId,List<Long> toCCGrpIds, Long inquiryId, String isSubStatusPendingInternal, boolean isTaskizeInquiry){
		try {
			
			if(workflowList ==null || fromGroupId ==null || toCCGrpIds ==null  ) {
				return workflowList;
			}
				
			for(Workflow wf : workflowList) { 
				if(isInquirySubStatusEnabled(wf.getAssignedGroupId())) {
					//reply all 
					//any reply on new should remain New other than fromgroupId
					if(!wf.getAssignedGroupId().equals(fromGroupId) && (wf.getInquirySubStatus() == null || SUB_STATUS_NEW.equals(wf.getInquirySubStatus()))) {
						wf.setInquirySubStatus(SUB_STATUS_NEW);
					}else if(!wf.getAssignedGroupId().equals(fromGroupId) && SUB_STATUS_REOPEN.equals(wf.getInquirySubStatus())) { // to cc contains reopen workflow 
						continue;
					}else if(null != toCCGrpIds && toCCGrpIds.contains(wf.getAssignedGroupId())) {
						//Change sub Status of fromgroupId both in-out workflow
						if(wf.getAssignedGroupId().equals(fromGroupId)) {	
							// Update SubStatusPendingInternal from fromGroupID workflow
							if("Y".equalsIgnoreCase(isSubStatusPendingInternal)) {
								wf.setIsSubStatusPendingInternal(isSubStatusPendingInternal);
							}
							wf.setInquirySubStatus(newChangeStatusValue);
						//if it it not fromgroupId and inquiry sub status is not "Message to reviw" 
						}else if(!SUB_STATUS_MESSAGE_TO_REVIEW.equalsIgnoreCase(wf.getInquirySubStatus()) && !isTaskizeInquiry) {
							//then update setPrevInqSubStatus and inquiry sub status
								wf.setPrevInqSubStatus(wf.getInquirySubStatus());
								wf.setInquirySubStatus(SUB_STATUS_MESSAGE_TO_REVIEW);
							}
					}else {
						//Reply
						if(wf.getAssignedGroupId().equals(fromGroupId)) {
							// Update SubStatusPendingInternal from fromGroupID workflow
							if("Y".equalsIgnoreCase(isSubStatusPendingInternal)) {
								wf.setIsSubStatusPendingInternal(isSubStatusPendingInternal);
							}
							wf.setInquirySubStatus(newChangeStatusValue);	
						}
							
				}
			}else {
				if(userDao.getEnableInquirySubStatusFlag() && wf.getAssignedGroupId().equals(fromGroupId) && !SUB_STATUS_COMPLETED.equals(newChangeStatusValue)
						&& !SUB_STATUS_NEW.equals(newChangeStatusValue) 
						&& !SUB_STATUS_REOPEN.equals(newChangeStatusValue)) {
					wf.setInquirySubStatus(newChangeStatusValue);	
				}
			}
		}	
		}catch(Exception e) { 
			// Add a log.warn with details of failure, inquiryId, newChangeStatusValue, fromGroupId
			subLogger.warn("Exception while updating Inquiry sub-Status for inquiryId: {}, newChangeStatusValue: {}, fromGroupId: {}, {}",inquiryId,newChangeStatusValue,fromGroupId,e);
		}
		return workflowList;
	}
	
	//[C170665-1719] DCC Requirement: Add Case status field
	private boolean isInquirySubStatusEnabled(Long assignToGrpId) {
		subLogger.info("Looking for Inquiry Sub-Status config for groupId: {}",assignToGrpId);
		boolean isSubStatusEnabled = false;
		try {
			if(userDao.getEnableInquirySubStatusFlag() && assignToGrpId != null) { // it is DL mail
				if(QMACacheFactory.getCache() != null && QMACacheFactory.getCache().getGroupIdToOrgName() != null) {
					String orgName = QMACacheFactory.getCache().getGroupIdToOrgName().get(assignToGrpId);
					OrgPreferences orgPref = QMACacheFactory.getCache().getOrgNameToOrgPref().get(orgName);
					if(orgPref != null && orgPref.getEnableInquirySubStatus() != null && orgPref.getEnableInquirySubStatus().equals("true")) {
						subLogger.info("Org level EnableInquirySubStatus() is true");
						isSubStatusEnabled = true; 	
					}else {
						Group group = QMACacheFactory.getCache().getAllGroupsMap().get(assignToGrpId);
						if(null != group && null != group.getEnableInquirySubStatus() && group.getEnableInquirySubStatus()) {
							subLogger.info("group level EnableInquirySubStatus() is true");
							isSubStatusEnabled = true;
						}
				}
				}else {
					Group group = QMACacheFactory.getCache().getAllGroupsMap().get(assignToGrpId);
					if(null != group && null != group.getEnableInquirySubStatus() && group.getEnableInquirySubStatus()) {
						subLogger.info("group not associated with any org and group level EnableInquirySubStatus() is true");
						isSubStatusEnabled = true;
					}
				}
			}
		}catch(Exception e) {
			subLogger.warn("Exception while getting config for Inquiry Sub-Status: {}",e);
			
		}
		
		return isSubStatusEnabled;
	}
	
	public File downloadAllAttachmentsIndividual(String soeId, String request) {
		File zipFile = null;
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			Long inquiryId = GenericUtility.getIdFromRequest(inputJsonObj, "inquiryId");
			Long convId = GenericUtility.getIdFromRequest(inputJsonObj, "convId");
			Long groupId = GenericUtility.getIdFromRequest(inputJsonObj, "groupId");
			List<Long> grpIds = null;
			if( null != groupId) {
				grpIds = new ArrayList<>();
				grpIds.add(groupId);
			}
			int convLimitCount = QMACacheFactory.getCache().getConvLimitCount();
			List<Conversation> convList = getAllConversations(inquiryId, grpIds, convLimitCount, true);
			zipFile = getFileListToZipIndividual(inquiryId, convId, convList);
        }catch (Exception ex) {
			subLogger.error("Exception while downloading all individual attachment: InquiryDAO.downloadAllAttachments {}" ,ex);
		}
		return zipFile;
	}
	private File getFileListToZipIndividual(Long inquiryId, Long convId, List<Conversation> convList) throws CommunicatorException {
		File zipFile = null;
		String fileExtn = ".zip";
		String fileNameZip = inquiryId + fileExtn;
		Map<String, File> fileMapToZip = new HashMap<>();
		Map<String, Integer> fileVersionMap = new HashMap<>();
		for (int i = convList.size(); i-- > 0;) {
			Conversation conv = convList.get(i);
			if (null != conv && null != conv.getAttachments()) {
				Map<String, File> filesMap = null;
				if (null != convId && conv.getId().equals(convId)) {
					fileNameZip = convId + fileExtn;
					List<Attachment> attachmentsByConvId = conv.getAttachments();
					fileMapToZip = fetchAttachmentFromDBIndividual(attachmentsByConvId,fileVersionMap);
					break;
				} else if (null == convId) {
					List<Attachment> attachmentsByInqId = conv.getAttachments();
					filesMap = fetchAttachmentFromDBIndividual(attachmentsByInqId,fileVersionMap);
				}
				if (null != filesMap) {
					fileMapToZip.putAll(filesMap);
				}
			}
		}
		if(!fileMapToZip.isEmpty()){
			subLogger.info("Creating zip file name : {} from no of individual src files:{}",fileNameZip, fileMapToZip.size());
			zipFile = ZipUtil.createZipFile(fileNameZip, fileMapToZip);
			ZipUtil.deleteFileFromTemp(fileMapToZip);
		}
		return zipFile;
	}
	private Map<String, File> fetchAttachmentFromDBIndividual(List<Attachment> attachmentsByInqId, Map<String, Integer> fileVersionMap) throws CommunicatorException {
		Map<String, File> fileMap = new HashMap<>();
		for (Attachment attachment : attachmentsByInqId) {
			String docId = attachment.getId();
			String fileName;
			try {
				IndividualAttachmentDAO individualAttachmentDao = new IndividualAttachmentDAO();
				subLogger.info("Reading individual file from Mongo DB for docId {}",docId);
				Map<String, Object> mongoDataMap = individualAttachmentDao.getFileForIndividual(docId);
				fileName = (String) mongoDataMap.get("name");
				File file = (File) mongoDataMap.get("fileObject");
				if(fileVersionMap.containsKey(fileName)){
					int fileVersion = fileVersionMap.get(fileName).intValue()+1;
					String fileNameWithoutExtn = fileName.substring(0, fileName.lastIndexOf(CHAR_DOT));
					String fileExtn =  (String) mongoDataMap.get("type");
					String fileNameWithVersion = fileNameWithoutExtn+"("+fileVersion+")."+fileExtn;
					fileVersionMap.put(fileName, fileVersion);
					fileName = fileNameWithVersion;
				}else{
					fileVersionMap.put(fileName,0);
				}
				fileMap.put(fileName, file);
				subLogger.info("Successfully Read individual file from Mongo DB for docId {} fileName: {}", docId , fileName);
				TimeUnit.MILLISECONDS.sleep(5);
			} catch(InterruptedException ex) {
				subLogger.error("An InterruptedException was caught: ", ex.getMessage());
				Thread.currentThread().interrupt();
			} catch (Exception e) {
				subLogger.error("Exception while reading file from Mongo DB for docId :{} {}", docId, e);
				throw new CommunicatorException(e.getMessage());
			}
		}
		return fileMap;
	}

	private String createEmailFileName(Message message, String defaultFileName,int messageCount) throws MessagingException
	{
		String fileName = defaultFileName;
		if (message != null && message.getSubject() != null && message.getSubject().length() > 0)
		{
			fileName = message.getSubject().replaceAll("[^a-zA-Z0-9,-._~!@+#$%&(){}^`' ]+", " ") +"_"+messageCount+ ".eml";		
		}
		return fileName;
	}

	
	public String getEmailFileNameList(Map<String, Object> prepareDownloadMessageMap,int messageCount) throws MessagingException
	{ 
		String fileName = "";
		Message message = null;
		if (null != prepareDownloadMessageMap && null != prepareDownloadMessageMap.get("message"))
		{
			message=(Message)prepareDownloadMessageMap.get("message");
			fileName = createEmailFileName(message, "Untitled Draft Mail",messageCount);
		}
		return fileName;
	}
	
	public List<Conversation> getAllEmailConversations(Long inquiryId, int convLimitCount, boolean loadContentFromDb, List<Long> convIdList, Integer businessDays)
	{		
		List<Conversation> convList=null;
		if(!convIdList.isEmpty() || (businessDays != null && businessDays > 0)) {
			subLogger.info("Before getAllConversationsWithFilters");
			convList = getAllConversationsWithFilters(inquiryId, null, convLimitCount, loadContentFromDb, convIdList, businessDays);
		} else {
			convList = getAllConversations(inquiryId,null,convLimitCount,loadContentFromDb);
		}
				
		return convList;
	}
	

    public static String generateUUID() {
        return UUID.randomUUID().toString();
    }
    
    //publish message to messagebus
    public boolean linkDelinkEntityToInquiry(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException, QMAException{
		
		//validate input params
		validateRequest(inputJsonObj);
		BasicDBList entityDetails = (BasicDBList) inputJsonObj.get("inquiryIdConvIds");
		Map<Long, String> inquiryConvMap = new HashMap<>();
		ListIterator<Object> entityObjectListIterator = entityDetails.listIterator();
		while(entityObjectListIterator.hasNext()){
			String obj = (String) entityObjectListIterator.next();
			String[] arr = obj.split(":");
			inquiryConvMap.put(Long.valueOf(arr[0]),arr[1]);
		} 
		BasicDBObject jsonObj = new BasicDBObject(); 
		jsonObj.put(INQUIRY_IDS,new ArrayList<>(inquiryConvMap.keySet()));
		List<Long> inquiryIds = GenericUtility.getIdListFromRequest(jsonObj, INQUIRY_IDS);
		List<Inquiry> inquiryList = getInquiryList(inquiryIds);
		
		boolean published = publishEventsToMessageBus(soeId,inputJsonObj,inquiryList,inquiryConvMap);
		if (published) {
			subLogger.info("Link / delink message published to messagebus");
			return true;
		}
		return false;
	}
	
	private void validateRequest(BasicDBObject inputJsonObj) throws QMAException {
		
		if (StringUtils.isBlank(inputJsonObj.getString(ENTITY_TYPE_KEY))
				|| StringUtils.isBlank(inputJsonObj.getString("type"))
				|| null == inputJsonObj.get(ENTITY_DETAILS) || ((List<String>) inputJsonObj.get(ENTITY_DETAILS)).isEmpty()
				|| null == inputJsonObj.get(INQUIRY_IDS) || ((List<Long>)inputJsonObj.get(INQUIRY_IDS)).isEmpty() 
				|| null == (inputJsonObj.get("groupId"))
				|| ((List<Long>)inputJsonObj.get("groupId")).isEmpty()) {	
			
			throw new QMAException(INVALID_INPUT_KEY);
		}
	}
	
	//update Inquiry for entity Details depends on the ACK/NACK messages received from messagebus
	public void updateInquiryForLinkDelinkEntity(String soeId, Data data)
			throws CommunicatorException,QMAException {
		String eventType = data.getEventType();
		String clientId = "";
		Long inquiryId = null;
		
		String entityAction = "";
		if(eventType.contains(LINK_ENTITY_KEY)) {
			entityAction = "link";
		}else if(eventType.contains(DELINK_ENTITY_KEY)) {
			entityAction = "deLink";
		}
		subLogger.info("entityAction: {}",entityAction);
		try {
			List<Payload> payloads = Arrays.asList(data.getPayload()); 
			List<Long> inquiryList = new ArrayList<>();
			for (Payload eventPayload : payloads) {
				
				inquiryId = eventPayload.getInquiryId();
				subLogger.info("Performing {} Action on inquiryId: {}",entityAction,inquiryId);
				inquiryList.add(inquiryId);
				clientId = eventPayload.getClientId();
				List<EntityDetails> entityDetails = Arrays.asList(eventPayload.getEntityDetails());
				if(null == entityDetails || entityDetails.isEmpty()) {
					subLogger.info("Entity Details are null or empty for inquiryId: {} and eventID: {}, comment: {}",inquiryId,data.getEventId(),eventPayload.getComments());
					continue;
				}
				Map<Long, List<EntityRecord>> map = new HashMap<>();
				Query<QMALinkEntities> query = mongoDatastore.createQuery(QMALinkEntities.class).filter("inquiryId", inquiryId);

				QMALinkEntities qmaLinkEntitiesDBVersion = query.first();
				if (null == qmaLinkEntitiesDBVersion) {
					// add new entry for inquiryId
					subLogger.info("LinkEntities not present with id: {}, adding new entry",qmaLinkEntitiesDBVersion);
					addNewLinkEntitiesRecord(clientId, inquiryId, entityAction, entityDetails, map);
				} else {
					// update Linked entities present for given inquiryId
					
					subLogger.info("LinkEntities present with id: {}",qmaLinkEntitiesDBVersion.getId());
					updateLinkEntitiesRecord(clientId, inquiryId, entityAction, entityDetails, qmaLinkEntitiesDBVersion);
				}
				subLogger.info("updating UINotification for linkEntities with Id: {} inquiryID: {}",qmaLinkEntitiesDBVersion.getId(),inquiryId);
				saveInquiriesToPublish(new ArrayList<>(Arrays.asList(inquiryId)), "ACK/NACK from droid", soeId);
			}
		}catch(Exception e){
			throw new QMAException("Exception performing Link/ delink operation: " + e);
		}
		
	}
	//update existing link entity details for given inquiry
	private void updateLinkEntitiesRecord(String clientId, Long inquiryId, String entityAction,
			List<EntityDetails> entityDetails, QMALinkEntities qmaLinkEntitiesDBVersion) {
		String entityId;
		String entityStatus;
		String entityType;
		String entityProductFamily;
		for (EntityDetails entityDetail : entityDetails) {
			DBCollection qmaLinkEntitiesCollection = mongoDatastore.getCollection(QMALinkEntities.class);
			BulkWriteOperation bulkLinkEntitiesUpdOp = qmaLinkEntitiesCollection.initializeOrderedBulkOperation();
			
			entityId = entityDetail.getEntityId();
			entityStatus = entityDetail.getEntityStatus();
			entityType = entityDetail.getEntityType();
			entityProductFamily = entityDetail.getProductFamily();
			Long assigneGroupId = getGroupIdFromProductFamily(entityProductFamily);

			DBObject findEntityPullQuery = new BasicDBObject();
			findEntityPullQuery.put("inquiryId", inquiryId);

			DBObject findEntityPushQuery = new BasicDBObject();
			findEntityPushQuery.put("inquiryId", inquiryId);

			BasicDBObject groupDataCriteria = new BasicDBObject();
			groupDataCriteria.put("groupId", assigneGroupId);

			BasicDBObject entityRecordCriteria = new BasicDBObject();
			entityRecordCriteria.put(ENTITY_ID_KEY, entityId);

			DBObject pushUpdateDBFields = new BasicDBObject();
			DBObject pushUpdateDBObj = new BasicDBObject();

			DBObject pullEntityRecords = new BasicDBObject();
			DBObject pullUpdateDBFields = new BasicDBObject();

			List<EntityGroupData> dbVersionGroupDataList = qmaLinkEntitiesDBVersion.getEntityGroupData();
			List<Long> groupIds = null;
			if(null != dbVersionGroupDataList) {
				groupIds = dbVersionGroupDataList.stream()
						.map(QMALinkEntities.EntityGroupData::getGroupId).collect(Collectors.toList());
			}
			DBObject entityRecord = prepareDBObjectForEntityRecord(entityId, entityStatus, entityType,
					entityProductFamily, clientId, entityAction);

			if (null != groupIds && groupIds.contains(assigneGroupId)) {
				// entity records present for group ID update group data by adding entity record

				findEntityPullQuery.put(ENTITY_GROUP_DATA_KEY, new BasicDBObject("$elemMatch", groupDataCriteria));
				findEntityPullQuery.put("entityGroupData.entityRecords",new BasicDBObject("$elemMatch", entityRecordCriteria));

				findEntityPushQuery.put(ENTITY_GROUP_DATA_KEY,new BasicDBObject("$elemMatch", groupDataCriteria));

				// preparation for pull entity record
				pullEntityRecords.put(ENTITY_ID_KEY, entityId);
				DBObject pullUpdateDBObj = new BasicDBObject();
				pullUpdateDBObj.put("entityGroupData.$.entityRecords", pullEntityRecords);
				pullUpdateDBFields.put("$pull", pullUpdateDBObj);

				BasicDBList entityRecords = new BasicDBList();
				entityRecords.add(entityRecord);
				pushUpdateDBObj.put("entityGroupData.$.entityRecords", entityRecord);
				pushUpdateDBFields.put("$push", pushUpdateDBObj);

				bulkLinkEntitiesUpdOp.find(findEntityPullQuery).update(pullUpdateDBFields);
				bulkLinkEntitiesUpdOp.find(findEntityPushQuery).update(pushUpdateDBFields);
				
			} else {
				// EntityRecord not present for groupID
				BasicDBList entityRecords = new BasicDBList();
				entityRecords.add(entityRecord);

				DBObject groupData = new BasicDBObject();
				groupData.put("groupId", assigneGroupId);
				groupData.put("entityRecords", entityRecords);

				pushUpdateDBObj.put(ENTITY_GROUP_DATA_KEY, groupData);
				pushUpdateDBFields.put("$addToSet", pushUpdateDBObj);
				bulkLinkEntitiesUpdOp.find(findEntityPushQuery).update(pushUpdateDBFields);
				
			}
			bulkLinkEntitiesUpdOp.execute();
		}
	}
	private void addNewLinkEntitiesRecord(String clientId, Long inquiryId, String entityAction,
			List<EntityDetails> entityDetails, Map<Long, List<EntityRecord>> map) throws QMAException {
		try {
			String entityProductFamily;
			for (EntityDetails entityDetail : entityDetails) {
				entityProductFamily = entityDetail.getProductFamily();
				Long assigneGroupId = getGroupIdFromProductFamily(entityProductFamily);
				
				EntityRecord entityRecord = createEntityRecord(entityProductFamily, clientId, entityDetail, entityAction);

				if (map.containsKey(assigneGroupId)) {
					map.get(assigneGroupId).addAll(new ArrayList<>(Arrays.asList(entityRecord)));
				} else {
					map.put(assigneGroupId, new ArrayList<>(Arrays.asList(entityRecord)));
				}

			}
			QMALinkEntities entities = createEntityGroupData(inquiryId, map);
			mongoDatastore.save(entities);
		} catch (Exception e) {
			throw new QMAException("In InquiryDoa.addNewLinkEntitiesRecord() Exception performing Link/ delink operation: " + e);
		}
	}
	private DBObject prepareDBObjectForEntityRecord(String entityId, String entityStatus, String entityType,
			String entityProductFamily, String clientId, String entityAction) {
		DBObject entityRecord = new BasicDBObject();
		entityRecord.put(CLIENT_IDS_KEY, clientId);
		entityRecord.put(ENTITY_ID_KEY, entityId);
		entityRecord.put("entityStatus", entityStatus);
		entityRecord.put(ENTITY_TYPE_KEY, entityType);
		entityRecord.put("productFamily", entityProductFamily);
		entityRecord.put("processDate", new Date());
		entityRecord.put("entityAction", entityAction);
		entityRecord.put(PROCESS_FLAG, "N");
		return entityRecord;
	}
	private QMALinkEntities createEntityGroupData(Long inquiryId, Map<Long, List<EntityRecord>> map) {
		QMALinkEntities entities = new QMALinkEntities();
		entities.setInquiryId(inquiryId);
		List<QMALinkEntities.EntityGroupData> groupDataList = new ArrayList<>();
		for(Map.Entry<Long, List<EntityRecord>> entry: map.entrySet()) {
			EntityGroupData groupData = new EntityGroupData();
			groupData.setGroupId(entry.getKey());
			groupData.setEntityRecords(entry.getValue());
			groupDataList.add(groupData);
			
		}
		entities.setEntityGroupData(groupDataList);
		return entities;
	}
	private EntityRecord createEntityRecord(String entityProductFamily, String clientId, EntityDetails entityDetail, String entityAction) {
		String entityId;
		String entityStatus;
		String entityType;
		entityId = entityDetail.getEntityId();
		entityStatus = entityDetail.getEntityStatus();
		entityType = entityDetail.getEntityType();
		
		EntityRecord entityRecord = new EntityRecord();
		entityRecord.setClientId(clientId);
		entityRecord.setEntityId(entityId);
		entityRecord.setEntityStatus(entityStatus);
		entityRecord.setEntityType(entityType);
		entityRecord.setProcessDate(new Date());
		entityRecord.setProductFamily(entityProductFamily);
		entityRecord.setEntityAction(entityAction);
		entityRecord.setProcessFlag("N");
		return entityRecord;
	}
	
	private Long getGroupIdFromProductFamily(String productFamily) {
		Long groupId = null;
		Map<String, Long> productFamilyToGroupIdMap = getBrazilSenderDomainMapFromCache();
		if(productFamilyToGroupIdMap.containsKey(productFamily)) {
			groupId = productFamilyToGroupIdMap.get(productFamily);
		}
		return groupId;
	}
	
	private Map<String, Long> getBrazilSenderDomainMapFromCache() {
		Map<String, Long> productFamilyToGroupIdMap = new HashedMap<>();
		try {
			if (null != QMACacheFactory.getCache().getConfigById(BRAZIL_FX_CONFIG_KEY)) {
				Config configData = QMACacheFactory.getCache().getConfigById(BRAZIL_FX_CONFIG_KEY);
				if (null != configData) {
					productFamilyToGroupIdMap = configData.getProductFamilyGroupIdMap();
				}
			}
		} catch (Exception e) {
			subLogger.warn("Exception while retriving brazil config: ", e);
		}
		return productFamilyToGroupIdMap;
		
	}
	
	private boolean publishEventsToMessageBus(String soeId, BasicDBObject inputJsonObj,List<Inquiry> inquiryList,Map<Long, String> inquiryConvMap)
			throws CommunicatorException { 
		subLogger.info("Publishing event for soeId: {}", soeId);
		boolean isPublishedToKafka = false;
		try {
			int convLimitCount = QMACacheFactory.getCache().getConvLimitCount();
			String certPath = Thread.currentThread().getContextClassLoader().getResource("conf/").getPath();
			for (Inquiry inquiry : inquiryList) {
				
				Conversation conversation =null;
				String convId = inquiryConvMap.get(inquiry.getId());
				subLogger.info("InquiryId: {}, conversationId: {}",inquiry.getId(),convId);
				if("latestConvId".equalsIgnoreCase(convId)) {
					List<Conversation> convList = getAllConversations(inquiry.getId(),
							(List<Long>) inputJsonObj.get("groupId"), convLimitCount, false);
					if (null == convList || convList.isEmpty())
						throw new CommunicatorException("conversation list is empty for inquiry ID: " + inquiry.getId());
					conversation = convList.get(0);
				}else {
					conversation = getConversationById(Long.valueOf(convId));
				}
				subLogger.info("conversationId: {}",conversation.getId());
				String eventId = generateUUID();
				String eventType = "link".equalsIgnoreCase(inputJsonObj.getString("type")) ? LINK_ENTITY_KEY
						: DELINK_ENTITY_KEY;
				BasicDBList entityDetails = (BasicDBList) inputJsonObj.get(ENTITY_DETAILS);
				List<String> entityIds = new ArrayList<>();
				String clientId = "";
				ListIterator<Object> entityObjectListIterator = entityDetails.listIterator();
				while(entityObjectListIterator.hasNext()){
					BasicDBObject entityDetail = (BasicDBObject) entityObjectListIterator.next();
					entityIds.add((String) entityDetail.get(ENTITY_ID_KEY));
					clientId = (String) entityDetail.get(CLIENT_IDS_KEY);
				}
				 com.citi.icg.qma.common.messagebus.entity.Data dataToPublish = payload.prepareDataToPublish(inquiry, conversation, eventType, eventId,entityIds,clientId,inputJsonObj.getString(ENTITY_TYPE_KEY));

				isPublishedToKafka = MessageBusUtil.publishMessageToMessageBus(dataToPublish, eventId,
						dataToPublish.getPayload().getInquiryId().toString(), certPath);
			}
		} catch (Exception e) {
			throw new CommunicatorException("Error while publishing data to message bus: " + e);
		}
		subLogger.info("isPublishedToKafka: {}", isPublishedToKafka);
		return isPublishedToKafka;
	}
	/**
	 * 
	 */
	private Map<String, Object> getEmailThreadConfigFromCache() {
		Map<String, Object> emailThreadConfigMap = null;
		try {
			Config emailThreadConfig = QMACacheFactory.getCache().getConfigById(EMAIL_THREAD_CONFIG);
			if(null != emailThreadConfig) {
				emailThreadConfigMap = emailThreadConfig.getEmailThreadConfig();
			}
		} catch (Exception e) {
			subLogger.warn("Error while get emailThreadConfig from cache:", e);
		}
		return emailThreadConfigMap;
	}
	
	private boolean isUserActiveAndInOffice(String assignUserId) {
		boolean isUserActiveAndInOffice=true;
		User user  = StringUtils.isEmpty(assignUserId) ? null : QMACacheFactory.getCache().getUserInfoMap().get(assignUserId.toUpperCase());
		if( null == user || user.getOutOfOffice() || !(user.getActive())) {
			isUserActiveAndInOffice=false;
		} else {
			subLogger.info("User value is null    .........   {} " , user);
		}
		return isUserActiveAndInOffice;
	}
	
	public BasicDBObject saveExtInquiry(BasicDBObject inputJsonObj, String content, String soeId, UserActivities userActivity,String externalEmailId, boolean isCitiContact) throws CommunicatorException	{
		// Added new Method
		String inquiryAction = null;
		Long inquiryId = null;
		BasicDBObject response = null;
		try {
			Inquiry dbInquiry = null;
			boolean saveFlag = false;
			inquiryId = GenericUtility.getIdFromRequest(inputJsonObj, INQUIRY_ID);
			inquiryAction = inputJsonObj.getString("inquiryAction");
			String to = inputJsonObj.getString(TO);
			String fromGroup = inputJsonObj.getString(FROM);
			
			// For Outside Org, groupId should not be added
			Long fromGroupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(fromGroup.toUpperCase());
			String conversationContent = content;
			subLogger.info("saveExtInquiry-action-" + inquiryAction + " for Id=" + inquiryId + " by soeId=" + soeId + " Email="+externalEmailId);
			Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			boolean isExternalMail = isToCCHasEMail(inputJsonObj);

			Long queryCount = 1L;
			String inquirySource = inputJsonObj.getString(INQUIRY_SOURCE);
			String inquirySubStatus = inputJsonObj.getString(INQUIRY_SUB_STATUS);
			
			subLogger.info("saveExtInquiry with action =" + inquiryAction + " for soeId " + soeId + " , fromGroup= "
					+ fromGroup + " ,isExternalMail= " + isExternalMail + ", Email= "+ externalEmailId + " ,queryCount= " + queryCount);
			DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
			Date currentTime = new Date();

			if (inquiryId == null) {
				saveFlag = true;
			} else {
				dbInquiry = getInquiryById(inquiryId);
				if (dbInquiry == null) {
					subLogger.info("Invalid InquiryId sent for saveExtInquiry-action-" + inquiryAction + " for Id=" + inquiryId + " by " + soeId);
					saveFlag = true;
				}
			}
			DBObject stats;

			if (saveFlag) {
				subLogger.info("Save New External Inquiry");
				Inquiry inquiry = new Inquiry();
				if(isCitiContact) {
					updateInquiryDetailsDO(inputJsonObj, inquiry, saveFlag, soeId, currentTime);
				} else {
					updateExtInquiryDetailsDO(inputJsonObj, inquiry, saveFlag, externalEmailId, currentTime);
				}
				
				inquiryId = persist(inquiry);

				subLogger.info("INQUIRYID:" + inquiry.id);
				dbInquiry = inquiry;
				// Modified for requestType in Action Statistics - C153176-1155
//				 getInquiryActionStatistics(dbInquiry,conversation,makerCheckerRqd);
				stats = getStatsObject(soeId, inquiryAction, currentTime, dbInquiry, fromGroupId, false, null, groupIdToNameMap, userInfoMap);
			} else {
				updateTaskizeFields(inputJsonObj, dbInquiry);
				stats = getStatsObject(soeId, inquiryAction, currentTime, dbInquiry, fromGroupId, false, null, groupIdToNameMap, userInfoMap);
				// Reply,ReplyAll,ReplyResolve,ReplyAllResolve,Forward
				subLogger.info("Update External Inquiry-" + inquiryId);
				
				if(isCitiContact) {
					updateInquiryDetailsDO(inputJsonObj, dbInquiry, saveFlag, soeId, currentTime);
				} else {
					updateExtInquiryDetailsDO(inputJsonObj, dbInquiry, saveFlag, externalEmailId, currentTime);
				}
				dbInquiry.setAction(inquiryAction);

				try {
					persist(dbInquiry);
				} catch (Exception e) {
					subLogger.error("Retry case for inquiry update arises, check in next statement if rety was successful or not", e);
					Thread.sleep(5);
					// in case of concurrent issue, retry once again after 5 ms time
					persist(dbInquiry);
					subLogger.info("Retry case for inquiry update is successful");
				}
				subLogger.info("Inquiry Details Updated for action " + dbInquiry.getAction() + "-INQUIRYID:" + inquiryId);
			}

			Conversation conversation = createExtConversation(inputJsonObj, conversationContent, inquiryId, dbInquiry, soeId, currentTime, externalEmailId, isCitiContact);
			
			if (conversation.getAttachments() != null && !conversation.getAttachments().isEmpty()) {
				stats.put("hasAttachment", "Y");
			}
			
			boolean isEmailSentToExternal = isEmailSentToExternal(conversation.getRecipients());
			subLogger.info("saveExtInquiry: isEmailSentToExternal: [" + isEmailSentToExternal + "]");
			
			Workflow uiWorkflowData = new Workflow();// Workflow object copnatining data received from UI
			uiWorkflowData.setQueryCount(queryCount);
			uiWorkflowData.setInquirySource(inquirySource);
			String action = dbInquiry.getAction();
			if (isInquirySubStatusEnabled(dbInquiry.getLatestGroupId()) && action.equalsIgnoreCase(ACTION_NEW)) {
				uiWorkflowData.setInquirySubStatus(SUB_STATUS_NEW);
			} else if (isInquirySubStatusEnabled(dbInquiry.getLatestGroupId())
					&& (action.equalsIgnoreCase(ACTION_NEW_RESOLVE) || action.equalsIgnoreCase(ACTION_REPLY_RESOLVE)
							|| action.equalsIgnoreCase(ACTION_REPLYALL_RESOLVE)
							|| action.equalsIgnoreCase(ACTION_REPLY_RESOLVE_ALL)
							|| action.equalsIgnoreCase(ACTION_REPLYALL_RESOLVE_ALL))) {
				uiWorkflowData.setInquirySubStatus(SUB_STATUS_COMPLETED);
			} else {
				uiWorkflowData.setInquirySubStatus(inquirySubStatus);
				if (SUB_STATUS_PENDING_INTERNAL.equalsIgnoreCase(inquirySubStatus)) {
					uiWorkflowData.setIsSubStatusPendingInternal("Y");
				}
			}
			uiWorkflowData.setIsLastConvToExtEmail(isEmailSentToExternal ? "Y" : "N");

			List<ConversationRecipient> recipientsList = createExtRecipients(inputJsonObj, soeId, externalEmailId, isCitiContact);
			List<Workflow> workFlowList = createWorkFlowsForExtInquiries(dbInquiry, conversation, uiWorkflowData, false, soeId, dbInquiry.getAction(), currentTime, null, recipientsList, externalEmailId, isCitiContact);
			if (conversation == null || workFlowList == null || workFlowList.isEmpty()) {
				subLogger.info("Invalid Inquiry data, No Inquiry created for Action " + dbInquiry.getAction()
						+ "-INQUIRYID:" + inquiryId);
				throw new CommunicatorException("Invalid Inquiry data,Please contact support ");
			}
			// Sonar Fix - remove unused private variables
			// C170665-118 for time in queue
			workFlowList.forEach(wf -> {
				// we need to keep the same value of isLatestReplyFromCurrentWorkflowGrp for the
				// group which is not the form group
				// while it is part of recipient and workflow direction is not IN
				if (!wf.getDirection().equalsIgnoreCase(INQUIRY_DIRECTION_IN)
						&& !fromGroupId.equals(wf.getAssignedGroupId())) {
					wf.setIsLatestReplyFromCurrentWorkflowGrp("Y");
				} else {
					String flag = (fromGroupId.equals(wf.getAssignedGroupId())) ? "Y" : "N";
					wf.setIsLatestReplyFromCurrentWorkflowGrp(flag);
				}
				subLogger.info("SaveExtInquiry : Time IN Queue : Group: " + wf.getAssignedGroupName()
						+ ", IsLatestReplyFromCurrentWorkflow : " + wf.getIsLatestReplyFromCurrentWorkflowGrp());
			});

			// attachment flag at workflow level
			if (null != workFlowList && null != conversation) {
				InquiryExtendedDAO.getInstance().stampWorkflowAttachmentFlag(dbInquiry, workFlowList, conversation);
			}
			// Create new Audit for the inquiry
			updateExtInquiryDetailsDB(inputJsonObj, dbInquiry, conversation, workFlowList, recipientsList, currentTime, soeId, userActivity);
			// Stamp custom categories
			if (null != workFlowList) {
				stampCustomClientCategories(dbInquiry, workFlowList);
			}

			subLogger.info("saveExtInquiry successful for action " + dbInquiry.getAction() + "-INQUIRYID:" + inquiryId);
			response = new BasicDBObject();
			response.put("inquiryId", String.valueOf(inquiryId));
			response.put("conversationId", String.valueOf(conversation.getId()));
			userNotificationDAO.updateUserNotification(dbInquiry, dbInquiry.getAction(), soeId, userNotificationType,
					userActivity);

			// Publish To Panorama
			saveInquiryToPublish(inquiryId, dbInquiry.getAction(), soeId);

			// C153176-154-ActionStatistics Improvements
			updateStats(workFlowList, fromGroupId, stats, saveFlag ? INQUIRY_DIRECTION_IN : INQUIRY_DIRECTION_OUT,
					conversation, dbInquiry.getSubject());

			// save Stats
			statsCollection.save(stats);
			// save inquiry trend chart data
			if (stats != null) {
				subLogger.info(
						"trend chart data save started for action " + stats.get("action") + "-INQUIRYID:" + inquiryId);
				InquiryTrendDAO.getInstance().saveTrendChartData(stats, workFlowList);
			}

			if (saveFlag) {
				iInquiryActionStat.createInquiryActionStats(recipientsList, dbInquiry, workFlowList, currentTime, "",
						null);
			} else {
				iInquiryActionStat.updateInquiryActionStats(recipientsList, dbInquiry, workFlowList, currentTime, null);
			}

			subLogger.info("ActionStatistics Saved for action Test Pritam " + stats.get(ACTION) + "-INQUIRYID:"
					+ stats.get(INQUIRY_ID));

			// Update InquiryResponseTime Collection.
			// responseTimeUpdate.updateResponseTime(dbInquiry, inquiryAction, soeId,
			// currentTime, fromGroupId, mongoDatastore);

			// Update Ext Email Recipient
			updateExtEmailRecipients(fromGroupId, conversation.getRecipients());

			// Update User's Editor preferences if required
			if (inputJsonObj.getBoolean("isUserEditorPrefUpdated")) {
				userDao.saveUserEditorPreferences(soeId, inputJsonObj);
			}
			// Check whether exception id is present in json request and post message to CSL
			// accordingly.
			Long exceptionId = dbInquiry.getExceptionId();
			String xstreamReqId = inputJsonObj.getString("requestId");
			if (null != exceptionId) {
				GenericUtility.postInquiryDetailsToCSL(dbInquiry, conversation, xstreamReqId);
			}
			if (!saveFlag) {
				// Reply,ReplyALL,replyResolve.replyAllResolve,forward,sendTpPendingApprovalEmail
				ConversationCache.getInstance().removeEntriesWithKeySetIteration(inquiryId);
			}
			subLogger.info("Taskize Resolve "+inputJsonObj.getString("inquiryAction"));
			if(inputJsonObj.containsKey("inquiryAction") && ACTION_REOPEN.equalsIgnoreCase(inputJsonObj.getString("inquiryAction"))){
				reOpenResolvedInquiry(soeId,inputJsonObj,userActivity);
			}
			
		} catch (Exception e) {
			subLogger.error("Exception in saveExtInquiry for user= " + soeId + " , Email=" +externalEmailId+ " , InquiryAction=" + inquiryAction
					+ ", inquiryId=" + inquiryId, e);
			throw new CommunicatorException("Exception in saveExtInquiry for user= " + soeId + " , InquiryAction="
					+ inquiryAction + ", inquiryId=" + inquiryId, e);
		}
		return response;
	}
	
	private List<Workflow> createWorkFlowsForExtInquiries(Inquiry inquiry, Conversation conversation, Workflow uiWorkflowData, boolean isMakerCheckerEnabled, String soeId, String action, Date currentTime,
			List<Long> resolveAllGroupList, List<ConversationRecipient> recipientsList, String externalEmailId, boolean isCitiContact) throws CommunicatorException {
		List<Workflow> workflowList = new ArrayList<Workflow>(0);
		List<Long> toCcGroupIdList = new ArrayList<Long>();
		Map<Long, String> toCcGrpIdMap = getRecipientsUserIdMap(conversation.getRecipients(), toCcGroupIdList, TO_CATEGORY + CC_CATEGORY + BCC_CATEGORY);
		List<Long> ignoredQmaDlForTaskize = getIgnoredQmaDlForTaskizeFromCache();
		for(Long qmaDl : ignoredQmaDlForTaskize) {
			toCcGrpIdMap.remove(qmaDl);
		}
		Boolean isTaskizeInquiry = (null != inquiry.getBubbleId() ? true: false);
		Long fromGroupId = inquiry.getLatestGroupId();
		
		if (inquiry.getAction().equals(ACTION_NEW) || inquiry.getAction().equals(ACTION_NEW_RESOLVE)) {
			for (Long grpId : toCcGrpIdMap.keySet()) {
				Workflow verDO = createNewWorkflowForInquiry(grpId, INQUIRY_DIRECTION_IN, inquiry.getAction(), uiWorkflowData, soeId, currentTime, conversation.getRecipients(), inquiry.getLatestGroupId());

				 //C153176-1715 : New Inquiry : If external domain is present in the recipientList then make isLastConvToExtEmail = Y for all the recipients(groups).
				boolean isEmailSentToExternal = isEmailSentToExternal(recipientsList);
				verDO.setIsLastConvToExtEmail( isEmailSentToExternal ? "Y" : "N");
				uiWorkflowData.setIsLastConvToExtEmail(isEmailSentToExternal ? "Y" : "N");
				
				workflowList.add(verDO);

				// Inquiry to self
				if (grpId.equals(fromGroupId)) {
					if (StringUtils.isNotBlank(uiWorkflowData.getProcessingRegion())) {
						verDO.setProcessingRegion(uiWorkflowData.getProcessingRegion());
					}
					if (StringUtils.isNotBlank(uiWorkflowData.getRootCause())) {
						verDO.setRootCause(uiWorkflowData.getRootCause());
					}
					if (uiWorkflowData.getQueryCount() != null) {
						verDO.setQueryCount(uiWorkflowData.getQueryCount());
					}

					if (null != uiWorkflowData.getFollowUp()) {
						verDO.setFollowUp(uiWorkflowData.getFollowUp());
					}

					// C153176-5987 | Tag should be populating to work flow if same group
					if (StringUtils.isNotBlank(uiWorkflowData.getTag())) {
						verDO.setTag(uiWorkflowData.getTag());
					}
					// set resolve allocation
					if (null != uiWorkflowData && StringUtils.isNotBlank(uiWorkflowData.getResolveAllocation())) {
						verDO.setResolveAllocation(uiWorkflowData.getResolveAllocation());
					}
				}
			}

			// Pass reopen date as null in the below method for New Inquiry action
			if (uiWorkflowData != null){
				uiWorkflowData.setLatestConversationTime(currentTime);
			}
			
			if(isCitiContact) {
				createWorkflowsForNewInquiryEditActions(inquiry, workflowList, soeId, currentTime, uiWorkflowData, toCcGrpIdMap, fromGroupId, isMakerCheckerEnabled, action, resolveAllGroupList,recipientsList);
			}
			//return workflowList; 
		}else {
			// Reply,ReplyAll,ReplyResolve,ReplyAllResolve/Forward Flows
			workflowList = createWorkflowsForEditActions(inquiry, soeId, currentTime, uiWorkflowData, toCcGrpIdMap, fromGroupId, isMakerCheckerEnabled, action, resolveAllGroupList,recipientsList);
			
			
			
			if(!ACTION_NEW.equalsIgnoreCase(action)) {
				boolean autoAssigned = removeAutoAssignmentNonInquiryFlag(workflowList, fromGroupId, soeId, inquiry.getId());
				if(!autoAssigned) {
					inquiry.setAutoAssignmentAvailable(false);
				}
				//Revoke from AutoAssignInquiry collection
				revokeAutoAssign(inquiry.getId());
			}
		}
		setChangedInquirySubStatus(workflowList, uiWorkflowData.getInquirySubStatus() , fromGroupId, toCcGroupIdList,inquiry.getId(), uiWorkflowData.getIsSubStatusPendingInternal(),isTaskizeInquiry);
		return workflowList;

	}
	
	//Method is to update response time for the Taskize inquiry the method will only called for Taskize flow
	public void updateResponseTimeforExternalInquiry(Date currentTime, Inquiry inquiry, Long fromGroupId)
			throws CommunicatorException {
		UpdateOperations<Inquiry> ops = mongoDatastore.createUpdateOperations(Inquiry.class);
		Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("id", inquiry.id);
		List<Workflow> workflowList = inquiry.getWorkflows();
		List<Workflow> workflowListforGroup =  workflowList.stream().filter(w -> w.getAssignedGroupId().equals(fromGroupId)).collect(Collectors.toList());
		for (Workflow workflow : workflowListforGroup) {
			Long groupId = workflow.getAssignedGroupId();
			// [C153176-818]-Add 'Response Time'
			calculateResponseTime(workflowList, groupId, currentTime);

			// C153176-5891 | Calculate CITI response time based on new logic.
			calculateCitiResponseTime(workflowList, groupId, currentTime);

			// C153176-5354 - Add first response time for out workflow
			calculateAndUpdateFirstResponseTime(workflowList, groupId, currentTime);
		}
		ops.set(WORKFLOWS, workflowList);
		mongoDatastore.update(query, ops);
	}
	
	public Conversation createExtConversation(BasicDBObject inputJsonObj, String content, Long inquiryId, Inquiry dbInquiry , String soeId, Date currentTime, String externalEmailId, boolean isCitiContact) throws CommunicatorException {

		String action = dbInquiry.getAction();
		List<ConversationRecipient> recipientList = createExtRecipients(inputJsonObj, soeId, externalEmailId, isCitiContact);
		
		//C153176-1910:Add new DL for Global coverage : *ICG US Global Client Service (for ETF Settlements & Client Services)
		LinkedHashSet<ConversationRecipient> hSet = new LinkedHashSet<ConversationRecipient>(recipientList); 
        recipientList.addAll(GenericDAO.addAutoFwdRecipients(hSet));
       
		String urgentFlag = inputJsonObj.getString(URGENT_FLAG);
		String cntn = content;// Sonar Fix -- Introduce a new variable instead of reusing the parameter

		Conversation conversation = new Conversation();
		conversation.setInquiryId(inquiryId);
		conversation.setSubject(inputJsonObj.getString(SUBJECT));
		conversation.setRecipients(recipientList);

		cntn = GenericUtility.updateContentWithImages(cntn, soeId);

		conversation.setContent(cntn);
		conversation.setUrgentFlag(urgentFlag);
		conversation.setAction(action);

		conversation.setNLPDataStampedAtConv(true);
		conversation.setSuggestionAvailable(false);
		conversation.setAutoAssignmentAvailable(false);
		
		conversation.setAttachments(getAttachmentsInfo(inputJsonObj));

		conversation.setModBy(soeId);
		conversation.setModDate(currentTime);
		
		// C170665-3794
		if(inputJsonObj.containsKey(TASKIZE_CONTENT_ID) && StringUtils.isNotBlank(inputJsonObj.getString(TASKIZE_CONTENT_ID))) {
			conversation.setTaskizeContentId(inputJsonObj.getString(TASKIZE_CONTENT_ID));
		}

		// populate audFlag - audFlag can INTERNAL or EXTERNAL or BOTH
		boolean internalFlag = false;
		boolean enternalFlag = false;
		
		

		// sonar complies for this null check on recipientList, b'coz 'not null' check on recipientList always evaluates to true
		// recipientList never be null, so null check is not performed,
		for (ConversationRecipient recipient : recipientList) {
			if ("CC".equals(recipient.getToFrom()) || "TO".equals(recipient.getToFrom())
					|| "BCC".equals(recipient.getToFrom())) {
				if (null != recipient.getEmailAddr()
						&& !GenericUtility.isCitiDomainEmail(recipient.getEmailAddr().trim())) {
					enternalFlag = true;
				} else {
					internalFlag = true;
				}
			}
		}

		if (internalFlag && enternalFlag) {
			conversation.setAudFlag("BOTH");
		} else if (internalFlag) {
			conversation.setAudFlag("INTERNAL");
		} else {
			conversation.setAudFlag("EXTERNAL");
		}

		//add bubbleContent and parentConversationId
		addBubbleContentAndParentConvId(inputJsonObj, cntn, conversation);
		
		updateNominatedRecipients(conversation,dbInquiry);
		
		List<Long> groupIds = new ArrayList<Long>();
		for (ConversationRecipient recipient : recipientList) {
			if (!FROM_CATEGORY.equalsIgnoreCase(recipient.getToFrom())){
				Long groupId = recipient.getGroupId();
				groupIds.add(groupId);
			}
		}
		for(Long groupId : groupIds) {
			subLogger.info("Inside InquiryDao Create External conversation :" + groupId);
			InquiryExtendedDAO.getInstance()
			.updateConversationContentPreviewInTO(conversation,dbInquiry, groupId,false);
		}
		
		Long conversationId = persist(conversation);
		subLogger.info("conversationId" + conversationId);

		return conversation;

	}
	
	private List<ConversationRecipient> createExtRecipients(BasicDBObject inputJsonObj, String soeId, String externalEmailId, boolean isCitiContact) {
		List<ConversationRecipient> recipientList = new ArrayList<ConversationRecipient>();

		ArrayList<String> fromList = new ArrayList<String>();
		List<String> list = new ArrayList<String>();
		HashMap<String, ArrayList<String>> toCCGrpMap = null;

		String fromGroup = inputJsonObj.getString(FROM);
		fromList.add(fromGroup);
		setupExtRecipients(recipientList, fromList, "FROM", soeId, null, externalEmailId, isCitiContact);

		toCCGrpMap = getToCcList(inputJsonObj, TO);
		HashMap<String, String> toCCGrpMapIdName = getToCcListMapIdName(inputJsonObj, TO);
		if (toCCGrpMap != null && !toCCGrpMap.isEmpty()) {
			list = toCCGrpMap.get(LIST_BY_IDS);
		}
		setupExtRecipients(recipientList, list, "TO", soeId, toCCGrpMapIdName, externalEmailId, isCitiContact);

		toCCGrpMap = getToCcList(inputJsonObj, CC);
		toCCGrpMapIdName = getToCcListMapIdName(inputJsonObj, CC);
		if (toCCGrpMap != null && !toCCGrpMap.isEmpty()) {
			list = toCCGrpMap.get(LIST_BY_IDS);
		}
		setupExtRecipients(recipientList, list, "CC", soeId, toCCGrpMapIdName, externalEmailId, isCitiContact);

		// [C153176-1052] Ability to BCC when sending email
		toCCGrpMap = getToCcList(inputJsonObj, "bcc");
		toCCGrpMapIdName = getToCcListMapIdName(inputJsonObj, "bcc");
		if (toCCGrpMap != null && !toCCGrpMap.isEmpty()) {
			list = toCCGrpMap.get(LIST_BY_IDS);
		}
		setupExtRecipients(recipientList, list, "BCC", soeId, toCCGrpMapIdName, externalEmailId, isCitiContact);

		return recipientList;
	}
	
	private void setupExtRecipients(List<ConversationRecipient> recipientList, List<String> toccRecipients, String tofrom, String soeId, HashMap<String, String> toCCGrpMapIdName, String externalEmailId, boolean isCitiContact){
		if (toccRecipients != null)
		{
			QMACache qmaCache = QMACacheFactory.getCache();
			String grpCode = null;
			User user = null;
			if (tofrom.equalsIgnoreCase("FROM"))
			{
				String fromGroupCode = toccRecipients.get(0);
				// [C15176-347]- All inactive and active groups should be part of TO/CC recipients
				Long fromGroupId =  qmaCache.getGroupCodeToIdMapBothActiveInactive().get(fromGroupCode.toUpperCase());
				subLogger.debug("From Hazelcast fromGroupId:"+fromGroupId);
				ConversationRecipient conversationRecipient = new ConversationRecipient(externalEmailId, fromGroupId, soeId, externalEmailId, tofrom);
				recipientList.add(conversationRecipient);
			}
			else
			{
				for (String grpOrUserId : toccRecipients)
				{
					// [C15176-347]- All inactive and active groups should be part of TO/CC recipients
					//grpCode = CacheDAO.getInstance().getGroupIdToCodeMap().get(grpOrUserId.toUpperCase());
					grpCode = qmaCache.getGroupIdToDBCodeMap().get(grpOrUserId);
					String inActiveGrpCode = qmaCache.getGroupIdToCodeMapBothActiveInactive().get(grpOrUserId.toUpperCase());
					if( !isEmailAddress(grpOrUserId) && NumberUtils.isParsable(grpOrUserId) && qmaCache.getPersonalGroupIdList().contains(Long.valueOf(grpOrUserId))){
						subLogger.info("grpOrUserId : {} is identified as Individual group, hence ignoring identifying Group.",grpOrUserId);
						grpCode=null;
						inActiveGrpCode = null;
					}
					subLogger.debug("From Hazelcast inActiveGrpCode:"+inActiveGrpCode);
					// [C15176-347]- All inactive and active groups should be part of TO/CC recipients
					//user = CacheDAO.getInnce().getUserDetailsMapInactiveActive().get(grpOrUserId.toUpperCase());
					user = qmaCache.getUserInfoMap().get(grpOrUserId.toUpperCase());
					if (grpCode != null)
					{// [C15176-347]- All inactive and active groups should be part of TO/CC recipients
						Long groupId = qmaCache.getGroupCodeToIdMap().get(grpCode.toUpperCase());
						// [C153176-748] - to and cc fields enrichments
						String email = qmaCache.getGroupIdToEmailMap().get(groupId);
						ConversationRecipient conversationRecipient = new ConversationRecipient(email, groupId, null, grpCode, tofrom);
						recipientList.add(conversationRecipient);
					}
					else if (inActiveGrpCode != null)
					{
//						Long groupId = CacheDAO.getInstance().getGroupCodeToIdMapBothActiveInactive().get(inActiveGrpCode.toUpperCase());
//						ConversationRecipient conversationRecipient = new ConversationRecipient(CacheDAO.getInstance().getGroupIdToEmailMapBothActiveInactive().get(groupId.toString()), null, null, inActiveGrpCode,
//								tofrom);
						Long groupId = qmaCache.getGroupCodeToIdMapBothActiveInactive().get(inActiveGrpCode.toUpperCase());
						subLogger.debug("From Hazelcast GroupId:"+groupId);
						String groupEmail = qmaCache.getGroupIdToEmailMapBothActiveInactive().get(groupId.toString());
						subLogger.debug("From Hazelcast groupEmail:"+groupEmail);
						ConversationRecipient conversationRecipient = new ConversationRecipient(groupEmail, null, null, inActiveGrpCode,tofrom);
						recipientList.add(conversationRecipient);
					}
					else if (user != null)
					{
						String userLDesc = user.getName();
						if(null != user.getLongDesc() && StringUtils.isNotBlank(user.getLongDesc())) {
							userLDesc = user.getLongDesc();
						}
						ConversationRecipient conversationRecipient = new ConversationRecipient(user.getEmail(), null, user.getId(), userLDesc, tofrom);
						recipientList.add(conversationRecipient);
					}
					else if (isEmailAddress(grpOrUserId))
					{
						ConversationRecipient conversationRecipient = null;

						String groupEmailAlias = grpOrUserId.substring(0, grpOrUserId.indexOf('@'));
						grpCode = qmaCache.getGroupEmailToCodeMap().get(groupEmailAlias.toUpperCase());

						if(Objects.nonNull(grpCode) && Objects.nonNull(qmaCache.getGroupCodeToIdMap().get(grpCode.toUpperCase()))) {
							Long grpId = qmaCache.getGroupCodeToIdMap().get(grpCode.toUpperCase());
							if(qmaCache.getPersonalGroupIdList().contains(grpId)){
								subLogger.info("groupEmailAlias : {} is identified as Individual group, hence ignoring identifying Group.",groupEmailAlias);
								grpCode=null;
							}
						}
						// Set GroupID in recipient and create version for that group if email matches the groupEmail
						// Check for Group Email, then convert to groupId, also send email with groupEmail
						// Check for the external email - [C153176-891]
						if (GenericUtility.isCitiDomainEmail(grpOrUserId) && null != grpCode ){
							// [C15176-347]- All inactive and active groups should be part of TO/CC recipients
							Long groupId = qmaCache.getGroupCodeToIdMapBothActiveInactive().get(grpCode.toUpperCase());
							subLogger.info("Received group email : " + grpOrUserId + " , groupAlias before @ = " + groupEmailAlias + " ,groupCode = " + grpCode + " ,groupId = " + groupId);
							// Set group email , groupId, But display name as email address(displayed in conversation detail in UI
							
							//set display name as received from UI
							String displayName = null != toCCGrpMapIdName && StringUtils.isNotBlank(toCCGrpMapIdName.get(grpOrUserId))?(toCCGrpMapIdName.get(grpOrUserId)):grpOrUserId ;
							conversationRecipient = new ConversationRecipient(grpOrUserId, groupId, null, displayName, tofrom);
							
							recipientList.add(conversationRecipient);
						}
						//[C153176-1273]- Child group does not receive the mail in QMA for Mail sent from QMA to Parent. 
						//This is case of mail being sent to parentDL, which directly does not exists in group table. But exists as parenTDLAliases for all groups.
						else if (GenericUtility.isCitiDomainEmail(grpOrUserId) && null == grpCode) {
							Map<String, List<String>> parentToChild = qmaCache.getParentToChildDLsListMap();
							subLogger.debug("From Hazelcast parentToChild:"+parentToChild.size());
							String grpOrUserIdUpper  = grpOrUserId.toUpperCase();
							List<String> listofChildEmail = parentToChild.get(grpOrUserIdUpper);
							if (null != listofChildEmail && !listofChildEmail.isEmpty()) 
							{
								//set display name as received from UI
								String displayName = null != toCCGrpMapIdName && StringUtils.isNotBlank(toCCGrpMapIdName.get(grpOrUserId))?(toCCGrpMapIdName.get(grpOrUserId)):grpOrUserId ;
								conversationRecipient = new ConversationRecipient(grpOrUserId, null, null, displayName, tofrom);
								
								recipientList.add(conversationRecipient);
								for (String childDLEmailAddres : listofChildEmail) 
								{
									//childDLEmailAddres is already in caps in cache
									String emailAddress = childDLEmailAddres.substring(0,childDLEmailAddres.indexOf('@'));
									grpCode = qmaCache.getGroupEmailToCodeMap().get(emailAddress);
									if (null != grpCode)
									{
										Long groupId = qmaCache.getGroupCodeToIdMap().get(grpCode.toUpperCase());
										if(qmaCache.getPersonalGroupIdList().contains(groupId)){
											subLogger.info("groupId : {} is identified as Individual group in the group email flow, hence ignoring identifying Group.",groupEmailAlias);
											groupId= null;
										}
										subLogger.info("grpCode for Child Email ID: " + emailAddress + "is: " + grpCode + "and group ID::" + groupId);
										conversationRecipient = new ConversationRecipient(childDLEmailAddres, groupId, null, grpCode, tofrom);
										recipientList.add(conversationRecipient);
									}
								}
							}
							else
							{
								getConversationRecipientAliasFromMail(recipientList, tofrom, grpOrUserId); 
								String displayName = null != toCCGrpMapIdName && StringUtils.isNotBlank(toCCGrpMapIdName.get(grpOrUserId))?(toCCGrpMapIdName.get(grpOrUserId)):grpOrUserId ;
								conversationRecipient = new ConversationRecipient(grpOrUserId, null, null, displayName, tofrom);
								subLogger.info("Received group email : " + grpOrUserId);
								recipientList.add(conversationRecipient);
							}

						}
						// This is for External Email Address.
						else
						{
							String displayName = null != toCCGrpMapIdName && StringUtils.isNotBlank(toCCGrpMapIdName.get(grpOrUserId))?(toCCGrpMapIdName.get(grpOrUserId)):grpOrUserId ;
							conversationRecipient = new ConversationRecipient(grpOrUserId, null, null, displayName, tofrom);
							
							subLogger.info("Received group email : " + grpOrUserId);
							recipientList.add(conversationRecipient);
						}

					}

				}
			}
		}
	}
	private void updateExtInquiryDetailsDO(BasicDBObject inputJsonObj, Inquiry inquiryObj, boolean saveFlag, String externalEmailId, Date currentTime) {
		if (saveFlag) {
			inquiryObj.setStatus(STATUS_OPEN);
			inquiryObj.setAction(ACTION_NEW);
			inquiryObj.setOrigSubject(inputJsonObj.getString(SUBJECT));
			inquiryObj.setOrigUserId(externalEmailId);
			inquiryObj.setOrigUserName(externalEmailId);
			inquiryObj.setOrigType(EXTERNAL);
		}
		
		inquiryObj.setSubject(inputJsonObj.getString(SUBJECT));
		
		inquiryObj.setLatestUserId(externalEmailId);
		inquiryObj.setLatestUserName(externalEmailId);
		inquiryObj.setLatestEmail(externalEmailId);
		inquiryObj.setModBy(externalEmailId);
		inquiryObj.setModDate(currentTime);
		
		updateTaskizeFields(inputJsonObj, inquiryObj);
	}
	
	private void updateExtInquiryDetailsDB(BasicDBObject inputJsonObj, Inquiry inquiry, Conversation conversation, List<Workflow> workFlowList, List<ConversationRecipient> recipientsList, Date currentTime, String soeId, UserActivities userActivity) {
		String fromGroup = inputJsonObj.getString(FROM);
		String iRequestName = inputJsonObj.getString(REQUEST_TYPE);
		String forceUnlock = inputJsonObj.getString(FORCE_UNLOCK);
		String tag = inputJsonObj.getString(TAG);
		long startTime = System.currentTimeMillis(); 
		List<Long> allGroupIdList = getAllGroupsWithinEmailConversation(fromGroup, conversation);
		// Inquiry Database Update
		UpdateOperations<Inquiry> ops = mongoDatastore.createUpdateOperations(Inquiry.class);
		// Prepare Find Query to find record
		Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("id", inquiry.id);
		String allToCCGroups;
		String latestToCCGroups = getLatestToCCGroups(inputJsonObj);
		String userNote = inputJsonObj.getString("userNotes");
		if (null!= userNote && StringUtils.isNotBlank(userNote)){
			updateUserNotes(inputJsonObj, inquiry, currentTime, soeId, ops);
		}

		
		if ("NEW".equals(inquiry.getAction())) // For new Inq both are same.. otherwise existing db value by appending new groups involved. Do not override with workflows data
		{
			allToCCGroups = latestToCCGroups; // <-- sonar fix This conditional operation returns the same value whether the condition is "true" or "false"

		}
		else
		{
			// Clear read trace for Response Actions
			ops.unset(READ_BY);
			allToCCGroups = getAllToCCgroups(workFlowList, inquiry.getAllToCCGrps());
		}

		Map<String, String> openGroupsAndUserMap = getOpenGroups(workFlowList);
		setInquiryOpenUsers(openGroupsAndUserMap, ops, inquiry);
		
		// String openUsers = openGroupsAndUserMap.get(OPEN_USERS);
		if (!ACTION_NEW.equals(inquiry.getAction()))
		{
			String openUsers = openGroupsAndUserMap.get(OPEN_USERS);
			// Added null check for openUsers
			if (!StringUtils.isBlank(openUsers))
			{
				ops.set(OPEN_USERS, openUsers);
				inquiry.setOpenUsers(openUsers);
			}
		}

		setInquiryOpenUsersGroups(openGroupsAndUserMap, ops, inquiry);
		String latestToCCUsers = getLatestToCcUsersList(conversation.getRecipients());
		// ResolveInquiry If all workflows are already resolved, it also handles ReOpen case
		String inquiryStatus = STATUS_OPEN;
		if (isAllWorkflowResolved(workFlowList))
		{
			// mark as Resolved
			inquiryStatus = STATUS_RESOLVE;
		}
		if (workFlowList.size() == 1 && ACTION_NEW_RESOLVE.equalsIgnoreCase(inquiry.getAction())){
		                Workflow out = workFlowList.get(0);
		                if (out.getStatus().equalsIgnoreCase(STATUS_RESOLVE))
		                                inquiryStatus = STATUS_RESOLVE;
		}
		ops.set(STATUS, inquiryStatus);
		ops.set(ACTION, inquiry.getAction());
		Long fromGrpId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(fromGroup.toUpperCase());

		updateWorkflowRequesTypeAction(workFlowList, fromGrpId, iRequestName, inquiry.getAction(),allGroupIdList, inputJsonObj);

		String reqTypes = getSummaryReqTypeName(workFlowList);
		if (reqTypes != null)
		{
			ops.set(REQUEST_TYPE_STR, reqTypes);
			inquiry.setRequestTypeStr(reqTypes);
		}

		//[C153176-1072] - Escalate based on inquiry actions

		EscalationUtility escalationUtility = new EscalationUtility();
		escalationUtility.setAllGroupsEscalationCriteriaMap(groupDAO.getGroupEscalationDetailsById(allGroupIdList));
		escalationUtility.flagEscalations(allGroupIdList, workFlowList, inquiry, fromGrpId,QMACacheFactory.getCache().getConfigIdEscalationCriteriaMap());
		escalationUtility.setRespontimeEscalationForInternalMail(workFlowList, recipientsList, fromGrpId, inquiry, currentTime,inquiry.getAction());
		//[C153176-1270] - Add Escalation criteria for 'Pending Approval' emails
		escalationUtility.setEscalationTimeforPendingApproval(workFlowList, fromGrpId, currentTime);

		//EscalationUtility.allGroupsEscalationCriteriaMap = ;
		if (workFlowList != null){
			// Set each time because of workflow re-use & avoid multiple DB Updates considering workflow small workflow array size
			ops.set(WORKFLOWS, workFlowList);
		}
		
		{
			// Create workflow audit for inquiry action ex reply reply all forward etc.
			WorkflowAudit workflowAudit = null;
			Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			workflowAudit = createWorkFlowsAudit(fromGrpId, inquiry.getAction(), "Internal", inquiry.getModBy(), inquiry.getModDate(), forceUnlock, tag, groupIdToNameMap, userInfoMap);
			
			setInquiryAudit(inquiry, workflowAudit, ops);
		}
		
		if (conversation.getUrgentFlag() != null) {
			ops.set(URGENT_FLAG, conversation.getUrgentFlag());
		}
		if (conversation.getAttachments() != null && !conversation.getAttachments().isEmpty()) {
			ops.set(ATTACH_FLAG, 'Y');
		}
		
		updateInquiryEntityDetails(inputJsonObj, inquiry);
		mongoDatastore.update(query, ops);
	}
	
	public boolean assignExtInquirySubStatus(String soeId, BasicDBObject inputJsonObj, String externalEmailId, boolean isCitiContact) throws CommunicatorException {
		boolean bSuccess = false;

		try {
			List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS);
			// List<String> groupIds = (List<String>) inputJsonObj.get(GROUP_IDS_KEY);
			String inquirySubStatus = inputJsonObj.getString(INQUIRY_SUB_STATUS);
			inquirySubStatus = inquirySubStatus.replace("?", "-");
			boolean isMultiGroupAction = inputJsonObj.getBoolean(IS_MULTI_GROUP_ACTION_KEY);
			String commonGroupId = inputJsonObj.getString(COMMON_GROUP_ID_KEY);

			if (inquiryIds.size() != groupIds.size()) {
				subLogger.info("Invalid Input for assignInquirySubStatus - {} by {}, {}. InquiryIdList size and groupIdList size do not match.", inquirySubStatus, soeId, externalEmailId);
				throw new CommunicatorException("InquiryIdList size - [" + inquiryIds.size() + "] and groupIdList size - [" + groupIds.size() + "] do not match for assignInquirySource.");
			}
			if (StringUtils.isBlank(inquirySubStatus)) {
				subLogger.info("Invalid Input for assignInquirySubStatus - [{}] by {}, {}", inquirySubStatus, soeId, externalEmailId);
				throw new CommunicatorException("Invalid Inquiry Sub-Status for assignInquirySubStatus.");
			}
			List<Inquiry> inquiryObjects = getInquiryList(inquiryIds);
			Map<Long, String> inquiryGroupIdMap = populateInquiryGrpMapForMultiGrpAction(
					ACTION_ASSIGN_INQUIRY_SUB_STATUS, groupIds, isMultiGroupAction);

			Date currentTime = new Date();
			// Prepare update fields
			DBObject inquiryUpdateDBObj = null;
			String userName = "";
			if(isCitiContact) {
				inquiryUpdateDBObj = createAuditUpdateDBObj(soeId, currentTime, ACTION_ASSIGN_INQUIRY_SUB_STATUS);
				userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
			} else {
				inquiryUpdateDBObj = createAuditUpdateDBObj(externalEmailId, currentTime, ACTION_ASSIGN_INQUIRY_SUB_STATUS);
				userName = externalEmailId;
			}
			inquiryUpdateDBObj.put(WORKFLOWS_INQUIRY_SUB_STATUS, inquirySubStatus);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_BY, userName);
			inquiryUpdateDBObj.put(WORKFLOWS_LAST_ACTION_TIME, currentTime);
			inquiryUpdateDBObj.put(WORKFLOWS_ACTION, ACTION_ASSIGN_INQUIRY_SUB_STATUS);
			if (SUB_STATUS_PENDING_INTERNAL.equals(inquirySubStatus)) {
				inquiryUpdateDBObj.put(WORKFLOWS_INQUIRY_SUB_STATUS_PENDING_INTERNAL, "Y");
			}

			List<BasicDBObject> dbObjs = GenericUtility.getJsonObjFromRequest(inputJsonObj, "inquiryInfo");
			Map<Long, ActionStatistics> inquiryInfo = populateInquiryInfoMap(dbObjs, ACTION_ASSIGN_INQUIRY_SUB_STATUS,
					inquirySubStatus);

			bSuccess = bulkExtMultiGroupAction(soeId, inquiryObjects, isMultiGroupAction, inquiryGroupIdMap, commonGroupId,
					ACTION_ASSIGN_INQUIRY_SUB_STATUS, inquiryUpdateDBObj, null, inquiryInfo, externalEmailId, isCitiContact);

		} catch (Exception e) {
			subLogger.error("Exception in assignInquirySubStatus for user= {}, {}, {}", soeId, externalEmailId, e);
			throw new CommunicatorException("Exception in assignInquirySubStatus for user= " + soeId, e);
		}

		return bSuccess;
	}
	
	private boolean bulkExtMultiGroupAction(String soeId, List<Inquiry> inquiryObjects, boolean isMultiGroupAction, Map<Long, String> inquiryGroupIdMap, String commonGroupId,String action,DBObject inquiryUpdateDBObj,DBObject inquiryUnsetDBObj,Map<Long, ActionStatistics> inquiryInfoMap, String externalEmailId, boolean isCitiContact) throws CommunicatorException
	{
		boolean bSuccess = false;
		if (inquiryObjects != null)
		{
			subLogger.info("bulkAction for Ext Inquiries size=" + inquiryObjects.size() + " , action=" + action);

			DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
			BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();

			DBCollection statsCollection = mongoDatastore.getCollection(ActionStatistics.class);
			BulkWriteOperation bulkStatsInsertdOp = statsCollection.initializeOrderedBulkOperation();

			Date currentTime = new Date();
			boolean isBulkAction= inquiryObjects != null && inquiryObjects.size() > 1 ;
			Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			for (Inquiry inqObj : inquiryObjects)
			{
				if (inqObj == null)
				{
					break;
				}

				String groupIdsString = commonGroupId;
				if (isMultiGroupAction && inquiryGroupIdMap != null)
				{
					groupIdsString = inquiryGroupIdMap.get(inqObj.id);
				}

				if (StringUtils.isBlank(groupIdsString)){
					subLogger.info("bulk action -" + action + " by " + soeId + ". No groups sent for inquiryId - [" + inqObj.id + "].");
					break;
				}
				String[] groupIdsList = groupIdsString.split(",");
				for (String versionGroupId : groupIdsList)
				{
					if (!StringUtils.isBlank(versionGroupId))
					{
						Long assignToGroupId = Long.valueOf(versionGroupId);

						ActionStatistics statsObj = inquiryInfoMap.get(inqObj.id+assignToGroupId);
						bulkExtInquiryWorkflowUpdateOperationForAction(soeId,  isBulkAction, bulkInquiryUpdOp, bulkStatsInsertdOp, currentTime, inquiryUpdateDBObj,inquiryUnsetDBObj, inqObj,
								assignToGroupId,action, statsObj, externalEmailId, isCitiContact);
					}
				}
			}
			// Execute
			if (!inquiryObjects.isEmpty())
			{
				bulkInquiryUpdOp.execute();
				bulkStatsInsertdOp.execute();
			}
			bSuccess = Boolean.TRUE;
		}
		return bSuccess;
	}
	
	private void bulkExtInquiryWorkflowUpdateOperationForAction(String soeId,boolean isBulkAction, BulkWriteOperation bulkInquiryUpdOp,
			BulkWriteOperation bulkStatsInsertdOp,
			Date currentTime, DBObject inquiryUpdateDBObj,DBObject inquiryUnsetDBObj, Inquiry inqObj, Long assignToGroupId,String action, ActionStatistics statsObj, String externalEmailId, boolean isCitiContact) throws CommunicatorException {
		Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
		Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
		String actionDetails=action;
		//[C170665-1719] DCC Requirement: Add Case status field
		if("Assign Inquiry Sub-Status".equalsIgnoreCase(action)) {
			actionDetails=(String)inquiryUpdateDBObj.get(WORKFLOWS_INQUIRY_SUB_STATUS);
		}
		
		DBObject workflowAudit = createExtWorkFlowsAuditJavaDriver(assignToGroupId, action, actionDetails, soeId, currentTime, groupIdToNameMap, userInfoMap, externalEmailId, isCitiContact);
		workflowAudit.put(GROUP_ID, assignToGroupId);
		//Modified for requestType in Action Statistics - C153176-1155
		DBObject stats = getExtStatsObject(soeId, action, currentTime, inqObj, assignToGroupId, isBulkAction, statsObj, groupIdToNameMap, userInfoMap, externalEmailId, isCitiContact);

		DBObject updateDBFields = new BasicDBObject();
		// Update inquiry fields
		if(null != inquiryUpdateDBObj){
			updateDBFields.put("$set", inquiryUpdateDBObj);
		}
		if(null != inquiryUnsetDBObj){
			updateDBFields.put("$unset", inquiryUnsetDBObj);
		}
		// Create new Audit for the action
		DBObject updateWorkAuditFields = new BasicDBObject();
		updateWorkAuditFields.put("$push", new BasicDBObject(WORKFLOW_AUDIT, workflowAudit));

		DBObject findINQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN, false);
		DBObject findOUTQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_OUT, false);
		DBObject findPNDQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_PENDING_APPROVAL, false);

		DBObject findPNDREAGEQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_PENDING_APPROVAL_REAGE, false);
		DBObject findWorkAuditflowQuery = prepareFindQuery(inqObj.id, assignToGroupId, STATUS_OPEN, INQUIRY_DIRECTION_IN_OR_OUT_OR_PA, false);
		// Add to bulk
		if(StringUtils.isNotBlank(action) && action.equalsIgnoreCase(SNOOZE)){
			bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);
		} else {
		bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);
		bulkInquiryUpdOp.find(findOUTQuery).update(updateDBFields);
		bulkInquiryUpdOp.find(findPNDQuery).update(updateDBFields);
		bulkInquiryUpdOp.find(findPNDREAGEQuery).update(updateDBFields);
		}
		
		bulkStatsInsertdOp.insert(stats);
		subLogger.info("ActionStatistics Saved for action 10" + stats.get(ACTION) + "-INQUIRYID:" + stats.get(INQUIRY_ID));
		bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);
	}
	
	private DBObject createExtWorkFlowsAuditJavaDriver(Long groupId, String action, String actionDesc, String userId, Date currentTime, Map<Long, String> groupIdToNameMap, Map<String, User> userInfoMap, String externalEmailId, boolean isCitiContact){
		DBObject workflowAudit = new BasicDBObject();
		String userName = "";
		workflowAudit.put(ACTION, action);
		workflowAudit.put(ACTION_DETAILS, actionDesc);
		workflowAudit.put(GROUP_ID, groupId);

		// Get group name from group cache through id and include it in workflow audit object

		if (groupId != null)
			workflowAudit.put(GROUP_NAME, groupIdToNameMap.get(groupId));

		if (InquiryDAO.ACTION_REOPEN.equalsIgnoreCase(action))
		{
			workflowAudit.put(REOPEN_DATE, currentTime);
		}
		
		User user = null;
		if(isCitiContact) {
			user = userInfoMap.get(userId.toUpperCase());
			if (user != null){
				userName = user.getName();
			}
		} else {
			userName = externalEmailId;
		}
		
		workflowAudit.put(USER_ID, userName);
		workflowAudit.put(MODIFIED_BY, userName);
		workflowAudit.put(MODIFIED_DATE, currentTime);
		workflowAudit.put(LAST_ACTION_TIME, currentTime);
		workflowAudit.put(LAST_ACTION_BY, userName);

		// C153176-875 -- Logging the lockedBy , lockedDate, unlockedBy, unlockedDate in the workflow audit for the lock & unlock flow respt.
		if (InquiryDAO.ACTION_LOCK.equalsIgnoreCase(action))
		{
			workflowAudit.put(LOCKED_BY, userName);
			workflowAudit.put(LOCKED_TIME, currentTime);
		}

		if (InquiryDAO.ACTION_UNLOCK.equalsIgnoreCase(action))
		{
			workflowAudit.put(UNLOCKED_BY, userName);
			workflowAudit.put(UNLOCKED_TIME, currentTime);
		}
		return workflowAudit;
	}
	
	private DBObject getExtStatsObject(String soeId, String action,Date currentTime, Inquiry inquiry, Long assignToGroupId, boolean isBulkAction, ActionStatistics actstatsObj, Map<Long, String> groupIdToNameMap, Map<String, User> userInfoMap, String externalEmailId, boolean isCitiContact) throws CommunicatorException { // Sonar Fix -- Define and throw a dedicated exception instead of using a generic one

		DBObject stats = new BasicDBObject();
		String assignedUserName = null;
		String userName = "";
		
		stats.put(INQUIRY_ID, inquiry.id);
		
		if(isCitiContact) {
			stats.put(USER_ID, soeId);
			User user = userInfoMap.get(soeId.toUpperCase());
			if(null != user) {
				stats.put("emailId", user.getEmail());
			}
			userName = GenericUtility.getUserOrSystemName(soeId, userInfoMap);
			stats.put("userName", userName);
		} else {
			stats.put(USER_ID, externalEmailId);
			userName = externalEmailId;
		}
		
		

		stats.put(GROUP_ID, assignToGroupId);
		stats.put(GROUP_NAME, groupIdToNameMap.get(assignToGroupId));
		//Request type, Subject, Assigned user - C153176-1054
		//stats.put(REQUEST_TYPE, actstatsObj);

		stats.put(SUBJECT, inquiry.getSubject());
		stats.put("assignedUserName", inquiry.getLatestUserName());
		if (null != inquiry.getWorkflows()){
			Workflow inWorkFlow=getWorkflow(inquiry.getWorkflows(), assignToGroupId, INQUIRY_DIRECTION_IN);
			if(null != inWorkFlow && null != inWorkFlow.getAssignedGroupName()){
				if(isCitiContact) {
					assignedUserName = inquiry.getLatestUserName() + " (" +soeId + ")[" + inWorkFlow.getAssignedGroupName() + "]";
				} else {
					assignedUserName = inquiry.getLatestUserName() + " (" +externalEmailId + ")[" + inWorkFlow.getAssignedGroupName() + "]";
				}
				stats.put("assignedUserName", assignedUserName);
			}
		}
		if(isBulkAction )
		{
			stats.put("isBulkAction","Y");
		}
		if(ACTION_NEW.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_NEW);
		else if(ACTION_REPLY_RESOLVE.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_REPLY_RESOLVE);
		else if(ACTION_REPLYALL_RESOLVE.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_REPLYALL_RESOLVE);
		else if(ACTION_RESOLVE.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_RESOLVE);
		else if(ACTION_ASSIGN_TAG.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_ASSIGN_TAG);
		else if(ACTION_TAKE_OWNERSHIP.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_TAKE_OWNERSHIP);
		else if(ACTION_ACKNOWLEDGE_ESCALATION.equalsIgnoreCase(action))
			stats.put(ACTION, ACTION_ACKNOWLEDGE_ESCALATION);
		else
			stats.put(ACTION, action);

		stats.put("actionTime", currentTime);

		if(null!=actstatsObj)
		{
			setParamForActionStastics(actstatsObj, stats);
		}

		Workflow lastModifiedWorkflow = getLastModifiedWorkflow(inquiry.getWorkflows(), assignToGroupId,INQUIRY_DIRECTION_IN);
		String isLastConvToExtEmail = null;
		if(lastModifiedWorkflow != null)
		{
			stats.put("createdTime", lastModifiedWorkflow.getCrtDate());
			stats.put("lastModifiedTime", lastModifiedWorkflow.getModDate());
			// C153176-5653 :  QMA should not measure time between Citiâ€™s response to client with 2 x consecutive e-mails as Response time
			boolean resolveAction = action.equals(ACTION_REPLY_RESOLVE) || action.equals(ACTION_REPLYALL_RESOLVE) || action.equals(ACTION_RESOLVE);
			isLastConvToExtEmail = null != lastModifiedWorkflow.getIsLastConvToExtEmail() ?  lastModifiedWorkflow.getIsLastConvToExtEmail() : "N";
			if (!ACTION_RESOLVE.equalsIgnoreCase(action)) {
			stats.put("responseTime", (currentTime.getTime() - lastModifiedWorkflow.getModDate().getTime())/60000);
			}
			
			if (resolveAction) {
				Date lastModifiedTime = (Date) stats.get("lastModifiedTime");
				Date createdTime = (Date) stats.get("createdTime");

				stats.put("resolveTimeSinceLastResponse",(currentTime.getTime() - lastModifiedTime.getTime())/60000);
				stats.put("resolveTimeSinceCreation",(currentTime.getTime() - createdTime.getTime())/60000);
			}
			if (action.equals(ACTION_REPLY) || action.equals(ACTION_REPLY_ALL) || action.equals(ACTION_REPLY_RESOLVE) || action.equals(ACTION_REPLYALL_RESOLVE) || action.equals(ACTION_RESOLVE))
			{
				if(null != lastModifiedWorkflow.getIsClientChaseEscalation() && "Y".equalsIgnoreCase(lastModifiedWorkflow.getIsClientChaseEscalation())) {
					stats.put("isResponseToClientChaser", lastModifiedWorkflow.getIsClientChaseEscalation());
				}
			}
		}

		// C153176-5653 | Update the response time with first client email of consecutive email.
		this.updateResponseTimeInStatistics(currentTime, inquiry.getWorkflows(), assignToGroupId, stats);
		
		// C153176-5882 | Response time not captured for ReplyResolve action
		// We would not consider response for action activities when CITI replied consecutively and action is Reply Resolve or Reply All Resolve
		if((ACTION_REPLY_RESOLVE.equalsIgnoreCase(action) 
			|| ACTION_REPLYALL_RESOLVE.equalsIgnoreCase(action)
			|| ACTION_REPLY.equalsIgnoreCase(action)
			|| ACTION_REPLY_ALL.equalsIgnoreCase(action))) {
			if(null == stats.get("responseTimeInMinutes") && null != lastModifiedWorkflow) {//<-- sonar fix null pointer
				long responseTimeInMinutes = calculateResponseTimeWrkShiftBased(currentTime, lastModifiedWorkflow.getModDate(),assignToGroupId);
				stats.put("responseTimeInMinutes", responseTimeInMinutes);
			}
			if("Y".equalsIgnoreCase(isLastConvToExtEmail)) {
				stats.removeField("responseTime");
				stats.removeField("responseTimeInMinutes");
			}
		}
		
		if("Y".equalsIgnoreCase(inquiry.getIsTaskizeInquiry())){
			if(StringUtils.isNotEmpty(inquiry.getBubbleId())) {
				stats.put("bubbleId", inquiry.getBubbleId());
				stats.put("isTaskizeInquiry",inquiry.getIsTaskizeInquiry());
			}
			if(StringUtils.isNotEmpty(inquiry.getTaskizeInquiryId())) {
				stats.put("taskizeInquiryId", inquiry.getTaskizeInquiryId());
			}
		}
		
		return stats;
	}
	
	private void updateTaskizeFields(BasicDBObject inputJsonObj, Inquiry inquiryObj) {
		if(inputJsonObj.containsKey("isTaskizeInquiry") && "Y".equalsIgnoreCase(inputJsonObj.getString("isTaskizeInquiry"))){
			if(inputJsonObj.containsKey("bubbleId")) {
				inquiryObj.setBubbleId(inputJsonObj.getString("bubbleId"));
				inquiryObj.setIsTaskizeInquiry(inputJsonObj.getString("isTaskizeInquiry"));
			}
			if(inputJsonObj.containsKey("taskizeInquiryId")) {
				inquiryObj.setTaskizeInquiryId(inputJsonObj.getString("taskizeInquiryId"));
			}
		}
	}
	public List<Conversation> getAllConversationsForTaskizeInquiry(Long inquiryId) {
		List<Conversation> conversationList = new ArrayList<>();
		try {
			List<Conversation> conversations = getAllConversations(inquiryId, null, 0, true);
			if (conversations != null) {
				conversationList = conversations;
			}
		} catch (Exception e) {
			subLogger.error("Exception in getAllConversationsForTaskizeInquiry :: ",e);
		}
		return conversationList;
	}
}

