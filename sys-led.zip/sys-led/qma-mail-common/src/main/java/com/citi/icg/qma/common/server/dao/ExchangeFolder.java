package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.List;

import com.mongodb.BasicDBObject;
import dev.morphia.annotations.Embedded;
import dev.morphia.annotations.Transient;

@Embedded
public class ExchangeFolder implements Serializable {

	private String folderId;
	private String displayName;
	private String parentFolderId;
	private String parentDisplayName;
	private Integer totalCount;
	private Integer childFolderCount;
	private Integer unreadCount;
	private String syncState;
	private List<ExchangeFolder> children;
	@Transient
	private String workflowFolderName;
	@Transient
	private boolean isVisible=true;

	public ExchangeFolder() {
	}
	
	public ExchangeFolder(String folderId) {
		super();
		this.folderId = folderId;
	}

	public ExchangeFolder(String folderId, String displayName, String parentFolderId, Integer totalCount,
			Integer childFolderCount, Integer unreadCount) {
		super();
		this.folderId = folderId;
		this.displayName = displayName;
		this.parentFolderId = parentFolderId;
		this.totalCount = totalCount;
		this.childFolderCount = childFolderCount;
		this.unreadCount = unreadCount;
	}

	public String getFolderId() {
		return folderId;
	}

	public void setFolderId(String folderId) {
		this.folderId = folderId;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getParentFolderId() {
		return parentFolderId;
	}

	public void setParentFolderId(String parentFolderId) {
		this.parentFolderId = parentFolderId;
	}
	
	public String getParentDisplayName() {
		return parentDisplayName;
	}

	public void setParentDisplayName(String parentDisplayName) {
		this.parentDisplayName = parentDisplayName;
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	public Integer getChildFolderCount() {
		return childFolderCount;
	}

	public void setChildFolderCount(Integer childFolderCount) {
		this.childFolderCount = childFolderCount;
	}

	public Integer getUnreadCount() {
		return unreadCount;
	}

	public void setUnreadCount(Integer unreadCount) {
		this.unreadCount = unreadCount;
	}

	public String getSyncState() {
		return syncState;
	}

	public void setSyncState(String syncState) {
		this.syncState = syncState;
	}

	public List<ExchangeFolder> getChildren() {
		return children;
	}

	public void setChildren(List<ExchangeFolder> children) {
		this.children = children;
	}

	public String getWorkflowFolderName() {
		return workflowFolderName;
	}

	public void setWorkflowFolderName(String workflowFolderName) {
		this.workflowFolderName = workflowFolderName;
	}

	public boolean getIsVisible() {
		return isVisible;
	}

	public void setIsVisible(boolean isVisible) {
		this.isVisible = isVisible;
	}

	@Override
	public String toString() {
		BasicDBObject object = new BasicDBObject();
		object.put("folderId",this.folderId);
		object.put("displayName",this.displayName);
		object.put("parentFolderId",this.parentFolderId);
		object.put("parentDisplayName",this.parentDisplayName);
		object.put("totalCount",this.totalCount);
		object.put("childFolderCount",this.childFolderCount);
		object.put("unreadCount",this.unreadCount);
		object.put("syncState",this.syncState);
		object.put("children",this.children);
		object.put("workflowFolderName",this.workflowFolderName);
		return object.toJson();
	}
}
