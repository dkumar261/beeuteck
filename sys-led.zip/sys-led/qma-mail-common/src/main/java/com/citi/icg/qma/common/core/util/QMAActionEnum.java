package com.citi.icg.qma.common.core.util;

public enum QMAActionEnum
{
	ACTION_NEW("New Inquiry"),
	ACTION_NEW_RESOLVE("New Inquiry Resolve"),
	ACTION_REPLY("Reply"),
	ACTION_REPLY_ALL("ReplyAll"),
	ACTION_FORWARD("Forward"),
	ACTION_REPLY_RESOLVE("Reply Resolve"),
	ACTION_REPLYALL_RESOLVE("ReplyAll Resolve"),
	ACTION_REPLY_RESOLVE_ALL("Reply ResolveAll"),
	ACTION_REPLYALL_RESOLVE_ALL("ReplyAll ResolveAll"),
	ACTION_RESOLVE("Resolve"),
	ACTION_ASSIGN_TO_OWNER("Assign Owner"),
	ACTION_TAKE_OWNERSHIP("Take Ownership"),
	RESOLVE_ACTION_TAKE_OWNERSHIP("Resolve By Other Group Ownership"),
	ACTION_SELF_ASSIGN("Self Assign"),
	ACTION_ASSIGN_REQ_TYPE("Assign Request Type"),
	ACTION_ASSIGN_TAG("Assign Tag"),
	ACTION_REOPEN("ACTION_REOPEN"),
	ACTION_DELETE_ITEM_EWS("ACTION_DELETE_ITEM_EWS"),
	ACTION_DELETE_FOLDER_EWS("ACTION_DELETE_FOLDER_EWS");
	
	
	private String action;

    private QMAActionEnum(String action) {
        this.action = action;
    }

    public String getName() {
        return action;
    }
    
    public static QMAActionEnum fromString(String action) {
        for (QMAActionEnum b : QMAActionEnum.values()) {
          if (b.action.equalsIgnoreCase(action)) {
            return b;
          }
        }
        return null;
      }
    @Override
    public String toString() {
        return action;
    }

}
