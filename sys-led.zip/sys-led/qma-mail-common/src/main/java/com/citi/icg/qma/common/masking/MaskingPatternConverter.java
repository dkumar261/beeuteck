package com.citi.icg.qma.common.masking;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.RuntimeMXBean;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.appender.AsyncAppender;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.layout.PatternLayout;
import org.apache.logging.log4j.core.pattern.ConverterKeys;
import org.apache.logging.log4j.core.pattern.LogEventPatternConverter;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

@Plugin(name = "MaskingPatternConverter", category = "Converter")
@ConverterKeys({ "mask" })
public class MaskingPatternConverter extends LogEventPatternConverter {

	private final PatternLayout patternLayout;
	private boolean isLogMaskingEnabled = true;
	private static final String ASYNC = "Async";
	private static final int MAX_MESSAGE_LENGTH = 2000;

	private static final org.slf4j.Logger logger = LoggerFactory.getLogger(MaskingPatternConverter.class);

	protected MaskingPatternConverter(String[] options) {
		super("mask", "mask");
		this.patternLayout = createPatternLayout(options);
		checkMaskingFlagChange();
	}

	public static MaskingPatternConverter newInstance(String[] options) {
		return new MaskingPatternConverter(options);
	}

	private PatternLayout createPatternLayout(String[] options) {
		if (options == null || options.length == 0) {
			throw new IllegalArgumentException("Options for MaskingPatternConverter are missing.");
		}
		return PatternLayout.newBuilder().withPattern(options[0]).build();
	}

	@Override
	public void format(LogEvent event, StringBuilder toAppendTo) {
		String formattedMessage = patternLayout.toSerializable(event);
		String maskedMessage = maskPIIData(formattedMessage);
		toAppendTo.setLength(0);
		toAppendTo.append(maskedMessage);
	}

	private String maskPIIData(String message) {
		if (!isLogMaskingEnabled || StringUtils.length(message) > MAX_MESSAGE_LENGTH) {
			return message;
		}
		// Replace sensitive values with masked value
		message = message.replaceAll("subject:.*;", "subject: ***");
		message = message.replaceAll("client-name:.*;", "client-name: ***");
		message = message.replaceAll("BodyPart:.*", "BodyPart: ***");
		message = message.replaceAll("(?!.*@citi\\.com)(\\s[a-zA-Z0-9_\\.]+@.+\\.\\w+[\\s\\,])", " ***");
		return message;
	}

	public void checkMaskingFlagChange() {
		ScheduledExecutorService executorService = null;
		try {
			executorService = Executors.newSingleThreadScheduledExecutor();
			executorService.scheduleAtFixedRate(() -> {
				isLogMaskingEnabled = QMACacheFactory.getCache().getDefaultStaticData().isLogMaskingEnabled() == null
						? true
						: QMACacheFactory.getCache().getDefaultStaticData().isLogMaskingEnabled();
				
				logger.info("isLogMaskingEnabled: {}", isLogMaskingEnabled);
				printAsyncStats();
			}, 10, 5, TimeUnit.MINUTES);
		} catch (Exception ex) {
			logger.error("Exception thrown in checkMaskingFlagChange: ", ex);
			isLogMaskingEnabled = true;
			if (executorService != null) {
				executorService.shutdown();
			}
		}
	}

	private void printAsyncStats() {
		try {
			Logger coreLogger = (Logger) LogManager.getLogger();
			AsyncAppender async = (coreLogger != null) ? (AsyncAppender) coreLogger.getAppenders().get(ASYNC) : null;

			int queueCapacity = 0;
			int queueRemainingCapacity = 0;
			int queuesize = 0;
			if (async != null) {
				queueCapacity = async.getQueueCapacity();
				queueRemainingCapacity = async.getQueueRemainingCapacity();
				queuesize = async.getQueueSize();
			}

			MemoryMXBean mmxbean = ManagementFactory.getMemoryMXBean();
			long totalMemory = Runtime.getRuntime().totalMemory() / 1000000;
			long usedHeapMemory = mmxbean.getHeapMemoryUsage().getUsed() / 1000000;
			long percentageUsedHeap = (usedHeapMemory * 100) / totalMemory;
			long freeHeapMemory = Runtime.getRuntime().freeMemory() / 1000000;
			long percentageFreeHeap = (freeHeapMemory * 100) / totalMemory;
			long maxMemory = Runtime.getRuntime().maxMemory() / 1000000;

			RuntimeMXBean mxBean = ManagementFactory.getRuntimeMXBean();
			String jvmName = mxBean.getName();
			long pid = Long.parseLong(jvmName.split("@")[0]);
			logger.info(
					"Process id: {}, queuesize: {}, queueCapacity: {}, queueRemainingCapacity: {}, totalMemory: {}, usedHeapMemory: {}, percentageUsedHeap: {}, freeHeapMemory: {}, percentageFreeHeap: {}, maxMemory: {}",
					pid, queuesize, queueCapacity, queueRemainingCapacity, totalMemory, usedHeapMemory,
					percentageUsedHeap, freeHeapMemory, percentageFreeHeap, maxMemory);

		} catch (Exception e) {
			logger.error("Exception thrown in printAsyncStats: ", e);
		}
	}

}
