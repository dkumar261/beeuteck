package com.citi.icg.qma.common.core.util.encrypt;

public interface IDataEncryption {

	public String getDataKey() throws Exception;
	public String getBase64EncryptedRootKey() throws DataEncrpyptDecryptException;
	public String encryptData(String dataToBeEncrypted) throws Exception;
	public String decryptData(String dataToBeDecrypted) throws Exception;
	
}
