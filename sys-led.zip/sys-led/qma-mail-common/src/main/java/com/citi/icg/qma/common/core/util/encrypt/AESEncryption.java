package com.citi.icg.qma.common.core.util.encrypt;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.ShortBufferException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.ApplicationConstants;

/**
 * Class that encrypts using AES, supports CBC+HMAC 
 
 */
public class AESEncryption {
    private static final Logger logger = LoggerFactory.getLogger(AESEncryption.class);
    static {
        try {
            Security.setProperty("crypto.policy", "unlimited");
        } catch (Exception e) {
            logger.warn("Exception while setting AESEncryption property. ", e);
        }
    }

    public static final int CBC_IV_LENGTH = 16;
    public static final String AES_CBC_CIPHER_LBL = "AES/CBC/PKCS5Padding";
    private static final byte[] BYTES_ZERO = new byte[16];
	private static final byte DOUBLING_CONST = (byte) 0x87;

    public static final byte[] encryptCBC(String encMode,EncKey.ExpandedKey key, byte[] txt) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, NoSuchProviderException, ShortBufferException, IllegalStateException {
        return encryptCBC((byte) 0, key, txt,encMode);
    }


    /**
     * Performs a AES CBC encryption with HMAC
     * The result is a byte array with
     * [ version:byte, iv-len:byte, iv:byte-array[iv-len], mac-len:byte, mac:byte-array[mac-len], encrypted-text:byte-array ]
     *
     * @param version any custom version you want to add to the output array
     * @param key the key to use
     * @param txt the text to encrypt
     * @param encMode the encryption mode - DETERMINISTIC/RANDOMISED
     * @return the encrypted byte array
     * @throws NoSuchPaddingException
     * @throws NoSuchAlgorithmException
     * @throws InvalidAlgorithmParameterException
     * @throws InvalidKeyException
     * @throws BadPaddingException
     * @throws IllegalBlockSizeException
     * @throws NoSuchProviderException
     * @throws IllegalStateException 
     * @throws ShortBufferException 
     */
    public static final byte[] encryptCBC(byte version, EncKey.ExpandedKey key, byte[] txt,String encMode) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, NoSuchProviderException, ShortBufferException, IllegalStateException {
        return encryptCBC(version, null, key, txt,encMode);
    }

    /**
     *
     * This method allows to pass in a custom cipher provider.
     * By default please use {@link #encryptCBC(byte, EncKey.ExpandedKey, byte[])} which will use the default JCE provider.
     * @param version any custom version you want to add to the output array
     * @param key the key to use
     * @param txt the text to encrypt
     * @param encMode the encryption mode - DETERMINISTIC/RANDOMISED
     * @return the encrypted byte array
     *
     * @throws NoSuchAlgorithmException
     * @throws InvalidAlgorithmParameterException
     * @throws InvalidKeyException
     * @throws BadPaddingException
     * @throws IllegalBlockSizeException
     * @throws NoSuchPaddingException
     * @throws NoSuchProviderException
     * @throws IllegalStateException 
     * @throws ShortBufferException 
     */
    public static final byte[] encryptCBC(byte version, String cipherProviderName, EncKey.ExpandedKey key, byte[] txt,String encMode) throws NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException, NoSuchProviderException, ShortBufferException, IllegalStateException {

        byte[] iv = new byte[CBC_IV_LENGTH];
        SecureRandom random = new SecureRandom();
        random.nextBytes(iv);
        
		if (ApplicationConstants.DETERMINISTIC_ENCRYPTION_MODE.equals(encMode)) {
			// Synthetic IV using S2V for deterministic mode

			byte[] associateData = BYTES_ZERO;
			iv = s2v(key, txt, associateData);
		}
        Cipher cipher = cipherProviderName == null ? Cipher.getInstance(AES_CBC_CIPHER_LBL) : Cipher.getInstance(AES_CBC_CIPHER_LBL, cipherProviderName);

        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key.encKey, "AES"), new IvParameterSpec(iv));
        byte[] cipherText = cipher.doFinal(txt);

        // Step 2 MAC using auth key
        // HMAC output length:
        // 128 bits => 16
        // 256 bits => 32
        // 512 bits => 64
        SecretKey macKey = new SecretKeySpec(key.authKey, key.keySize.hmacLbl());
        Mac hmac = Mac.getInstance(key.keySize.hmacLbl());
        hmac.init(macKey);
        hmac.update(iv);
        hmac.update(cipherText);

        byte[] mac = hmac.doFinal();
        //Finally, all information is serialized into a single message
       // Attach build messages, IV, IV lengths, MAC lengths, Mac and encrypted data to a single byte array.
        byte[] output = new byte[1 + 1 + iv.length + 1 + mac.length + cipherText.length];
        int i = 0;

        output[i++] = version;
        output[i++] = (byte) iv.length;
        System.arraycopy(iv, 0, output, i, iv.length);
        i += iv.length;

        if (mac.length > Byte.MAX_VALUE) {
            throw new RuntimeException("Mac length " + mac.length + " is bigger than allowed range: " + Byte.MAX_VALUE);
        }

        output[i++] = (byte) mac.length;

        System.arraycopy(mac, 0, output, i, mac.length);
        i += mac.length;

        System.arraycopy(cipherText, 0, output, i, cipherText.length);

        return output;

    }

   
	
	public static final byte[] decryptCBC(EncKey.ExpandedKey key, byte[] encryptedMessage) throws NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, InvalidAlgorithmParameterException, NoSuchPaddingException, NoSuchProviderException {
        return decryptCBC((byte) 0, key, encryptedMessage);
    }

    /**
     * Decrypt a AES CBC message encrypted with {@link #encryptCBC}
     * The expected message is:
     * <p>
     * [ version:byte, iv-len:byte, iv:byte-array[iv-len],  mac-len:byte, mac:byte-array[mac-len],  encrypted-text:byte-array
     *
     * @param version any custom version you want to add to the output array
     * @param key the key used to encrypt the data
     * @param encryptedMessage the encrypted data
     * @return the decrypted data
     * @throws NoSuchAlgorithmException
     * @throws InvalidKeyException
     * @throws BadPaddingException
     * @throws IllegalBlockSizeException
     * @throws InvalidAlgorithmParameterException
     * @throws NoSuchPaddingException
     * @throws NoSuchProviderException
     */
    public static final byte[] decryptCBC(byte version, EncKey.ExpandedKey key, byte[] encryptedMessage) throws NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, InvalidAlgorithmParameterException, NoSuchPaddingException, NoSuchProviderException {
        return decryptCBC(version, null, key, encryptedMessage);
    }

    /**
     * This method allows to pass in a custom cipher.
     * By default please use {@link #decryptCBC(byte, EncKey.ExpandedKey, byte[])}} which will use the default JCE provider.
     *
     * @param version any custom version you want to add to the output array
     * @param cipherProvider a JCE encryption provider
     * @param key the key used to encrypt the data
     * @param encryptedMessage the encrypted data
     * @return the decrypted data
     * @throws NoSuchAlgorithmException
     * @throws InvalidKeyException
     * @throws BadPaddingException
     * @throws IllegalBlockSizeException
     * @throws InvalidAlgorithmParameterException
     * @throws NoSuchPaddingException
     * @throws NoSuchProviderException
     */
    public static final byte[] decryptCBC(byte version, String cipherProvider, EncKey.ExpandedKey key, byte[] encryptedMessage) throws NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, InvalidAlgorithmParameterException, NoSuchPaddingException, NoSuchProviderException {

        int i = 0;
        int cipherVersion = encryptedMessage[i++];
        if (cipherVersion != version) {
            throw new RuntimeException("Version " + version + " was expected but the cipher message has " + cipherVersion);
        }

        int ivLength = encryptedMessage[i++];

        if (ivLength != CBC_IV_LENGTH) { // check input parameter
            throw new IllegalArgumentException("invalid iv length");
        }

        int ivPos = i;
        i += ivLength;

        int macLength = encryptedMessage[i++];

        if (macLength != key.keySize.getHMacSizeBytes()) { // check input parameter
            throw new IllegalArgumentException("invalid mac length");
        }

        int macPos = i;
        i += macLength;

        byte[] mac = new byte[macLength];
        System.arraycopy(encryptedMessage, macPos, mac, 0, macLength);

        int cipherTextPos = i;
        int cipherTextLen = encryptedMessage.length - cipherTextPos;

        // Before we decrypt we must validate the HMAC
        SecretKey macKey = new SecretKeySpec(key.authKey, key.keySize.hmacLbl());
        Mac hmac = Mac.getInstance(key.keySize.hmacLbl());
        hmac.init(macKey);
        hmac.update(encryptedMessage, ivPos, ivLength);
        hmac.update(encryptedMessage, cipherTextPos, cipherTextLen);

        byte[] refMac = hmac.doFinal();

        // Important, we must use a constant time equals method like MessageDigest
        // to avoid side channel attacks.
        if (!MessageDigest.isEqual(refMac, mac)) {
            throw new SecurityException("could not authenticate");
        }

        Cipher cipher = cipherProvider == null ? Cipher.getInstance(AES_CBC_CIPHER_LBL) : Cipher.getInstance(AES_CBC_CIPHER_LBL, cipherProvider);
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key.encKey, "AES"), new IvParameterSpec(encryptedMessage, ivPos, ivLength));
        return cipher.doFinal(encryptedMessage, cipherTextPos, cipherTextLen);
    }
    
    //Construct Synthetic IV using S2V
    private static byte[] s2v(EncKey.ExpandedKey key, byte[] plaintext, byte[]... associatedData) throws NoSuchAlgorithmException, InvalidKeyException, ShortBufferException, IllegalStateException {
    	// Maximum permitted AD length is the block size in bits - 2
    			if (associatedData.length > 126) {
    				// SIV mode cannot be used safely with this many AD fields
    				throw new IllegalArgumentException("too many Associated Data fields");
    			}

    			
    			SecretKey macKey = new SecretKeySpec(key.authKey, key.keySize.hmacLbl());
    			 Mac hmac = Mac.getInstance(key.keySize.hmacLbl());
    		        hmac.init(macKey);
    		       int len=hmac.getMacLength();
    			
    			// RFC 5297 defines a n == 0 case here. Where n is the length of the input vector:
    			// S1 = associatedData1, S2 = associatedData2, ... Sn = plaintext
    			// Since this method is invoked only by encrypt/decrypt, we always have a plaintext.
    			// Thus n > 0

    			byte[] d = mac(hmac, BYTES_ZERO);

    			for (byte[] s : associatedData) {
    				d = xor(dbl(d), mac(hmac, s));
    			}

    			final byte[] t;
    			if (plaintext.length >= 16) {
    				t = xorend(plaintext, d);
    			} else {
    				t = xor(dbl(d), pad(plaintext));
    			}
    			return mac(hmac, t);
	}

    private static byte[] mac(Mac mac, byte[] in) throws ShortBufferException, IllegalStateException {
		byte[] result = new byte[CBC_IV_LENGTH];
		mac.update(in, 0, in.length);
		result=mac.doFinal();
		return Arrays.copyOf(result, CBC_IV_LENGTH);
	}
    
 // First bit 1, following bits 0.
 	private static byte[] pad(byte[] in) {
 		final byte[] result = Arrays.copyOf(in, 16);
 		// new ISO7816d4Padding().addPadding(result, in.length);   // [C170665-4549]  This line is commented as we are not using this file, bouncy castle bcprov-jdk18on
 		return result;
 	}
 // Code taken from {@link org.bouncycastle.crypto.macs.CMac}
 	static byte[] dbl(byte[] in) {
 		byte[] ret = new byte[in.length];
 		int carry = shiftLeft(in, ret);
 		int xor = 0xff & DOUBLING_CONST;

 		/*
 		 * NOTE: This construction is an attempt at a constant-time implementation.
 		 */
 		int mask = (-carry) & 0xff;
 		ret[in.length - 1] ^= xor & mask;

 		return ret;
 	}
 // Code taken from {@link org.bouncycastle.crypto.macs.CMac}
 	static int shiftLeft(byte[] block, byte[] output) {
 		int i = block.length;
 		int bit = 0;
 		while (--i >= 0) {
 			int b = block[i] & 0xff;
 			output[i] = (byte) ((b << 1) | bit);
 			bit = (b >>> 7) & 1;
 		}
 		return bit;
 	}
 	
 	static byte[] xor(byte[] in1, byte[] in2) {
		assert in1.length <= in2.length : "Length of first input must be <= length of second input.";
		final byte[] result = new byte[in1.length];
		for (int i = 0; i < result.length; i++) {
			result[i] = (byte) (in1[i] ^ in2[i]);
		}
		return result;
	}

	static byte[] xorend(byte[] in1, byte[] in2) {
		assert in1.length >= in2.length : "Length of first input must be >= length of second input.";
		final byte[] result = Arrays.copyOf(in1, in1.length);
		final int diff = in1.length - in2.length;
		for (int i = 0; i < in2.length; i++) {
			result[i + diff] = (byte) (result[i + diff] ^ in2[i]);
		}
		return result;
	}
}
