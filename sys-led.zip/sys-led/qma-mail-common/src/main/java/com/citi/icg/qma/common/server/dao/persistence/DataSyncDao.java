package com.citi.icg.qma.common.server.dao.persistence;

import com.mongodb.*;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class DataSyncDao {
	
	private static final String PERSONAL_MAILBOX_ID = "personalMailboxId";
	private static final String ERROR_PROCESSING_REQUEST = "Error processing request. Please pass correct soeId.";
	private static final String ID = "_id";
	private static final String GROUP ="Group";
	private static Logger logger = LoggerFactory.getLogger(DataSyncDao.class);
	public final DB primaryDb;
	public final DB secondaryDb;
	private static DataSyncDao instance = null;
	private static final List<String> collectionList = new ArrayList<>(Arrays.asList("User",GROUP,"MailBoxDLMapping"));
	
	private DataSyncDao() {
		primaryDb = MongoDB.instance().getDB();
		secondaryDb = SecondaryDB.instance().getDB();
	}

	public static synchronized DataSyncDao getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		if (instance == null) {
			instance = new DataSyncDao();
		}
		return instance;
	}


	/**
	 * @return
	 */
	public String syncDB() {
		String response = null;
		try {
			logger.info("SyncUp started");
			for (int i = 0; i < collectionList.size(); i++) {
				String collection = (String) collectionList.get(i);
				syncUpCollection(collection);
			}
		} catch (Exception ex) {
			response = ERROR_PROCESSING_REQUEST;
			logger.error("Error while syncing personal DB with shared DB:", ex);
		}
		response = "Success";
		return response;
	}

	/**
	 * @param id
	 * @return
	 */
	public String syncDBById(String id) {
		String response = null;
		try {
			logger.info("SyncUp started for id:{}",id);
			syncUpById(id);
			
		} catch (Exception ex) {
			response = ERROR_PROCESSING_REQUEST;
			logger.error("Error while syncing personal DB with shared DB:", ex);
		}
		response = "Success";
		return response;
	}
	/**
	 * This method used to sync up collection from shared DB to personal DB
	 * @param collection
	 */
	private void syncUpCollection(String collection) {
		Object docId = null;
		DBCursor sharedDBCursor = null;
		DBCursor personalDBCursor = null;
		List<Object> documentAddedList = new ArrayList<>();
		List<Object> documentUpdatedList = new ArrayList<>();
		try {
			DBCollection primaryDbCollection = primaryDb.getCollection(collection);
			BasicDBObject excludeFieldsObj = new BasicDBObject();
			excludeFieldsObj.put("previousDayBoxCount", 0);
			sharedDBCursor = primaryDbCollection.find(new BasicDBObject(), excludeFieldsObj);
			DBCollection secondaryDbCollection = secondaryDb.getCollection(collection);
			logger.info("DB sync started for collection:[{}]",collection);//sonar fix
			while (sharedDBCursor.hasNext()) {
				DBObject sharedObj = sharedDBCursor.next();
				docId = (Object) sharedObj.get(ID);
				DBObject query = new BasicDBObject(ID,docId);
				personalDBCursor = secondaryDbCollection.find(query, excludeFieldsObj);
				if(personalDBCursor.size() == 0) {
					addDocument(secondaryDbCollection,sharedObj, docId);
					documentAddedList.add(docId);
				}else {
					updateDocument(secondaryDbCollection, personalDBCursor, sharedObj, query, docId);
					documentUpdatedList.add(docId);
				}				
			}
			logger.info("DB sync completed for collection:[{}]", collection);
		} catch (Exception e) {
			logger.error("Error while add/update document ID:"+docId, e);
		}finally {
			closeCursors(sharedDBCursor, personalDBCursor);
		}
	}
	/**
	 * This method used to sync up collection from shared DB to personal DB
	 * @param id
	 */
	private void syncUpById(String id) {
		Object docId = null;
		DBCursor primaryDBCursor = null;
		DBCursor secondaryDBCursor = null;
		try {
			for (int i = 0; i < collectionList.size(); i++) {
				String collection = collectionList.get(i);
				DBCollection primaryDbCollection = primaryDb.getCollection(collection);
				BasicDBObject excludeFieldsObj = new BasicDBObject();
				excludeFieldsObj.put("previousDayBoxCount", 0);
				BasicDBObject findQuery = new BasicDBObject();
				if(GROUP.equalsIgnoreCase(collection)) {
					findQuery.put(PERSONAL_MAILBOX_ID, id);
				} else {
					findQuery.put(ID, id);
				}
				primaryDBCursor = primaryDbCollection.find(findQuery, excludeFieldsObj);
				DBCollection secondaryDbCollection = secondaryDb.getCollection(collection);
				logger.info("DB sync started for collection:[{}]",collection);
				while (primaryDBCursor.hasNext()) {
					DBObject sharedObj = primaryDBCursor.next();
					DBObject query = new BasicDBObject();
					if(GROUP.equalsIgnoreCase(collection)) {
						docId = (Object) sharedObj.get(PERSONAL_MAILBOX_ID);
						query.put(PERSONAL_MAILBOX_ID, docId);
					}else {
						docId = (Object) sharedObj.get(ID);
						query.put(ID, docId);
					}
					secondaryDBCursor = secondaryDbCollection.find(query, excludeFieldsObj);
					if(secondaryDBCursor.size() == 0) {
						addDocument(secondaryDbCollection,sharedObj, docId);
						logger.info("Document added:[{}]",id);
					}else {
						updateDocument(secondaryDbCollection, secondaryDBCursor, sharedObj, query, docId);
						logger.info("Document updated:[{}]",id);
					}				
				}
			}
		} catch (Exception e) {
			logger.error("Error while add/update document ID:"+docId, e);
		}finally {
			closeCursors(primaryDBCursor, secondaryDBCursor);
		}
	}

	
	private void addDocument(DBCollection collectionPersonal, DBObject sharedObj, Object docId) {
		try {
			collectionPersonal.save(sharedObj);
		}catch(Exception ex) {
			logger.error("Error while add document ID:"+docId, ex.getMessage());
		}
	}

	/**
	 * @param collectionPersonal
	 * @param personalDBCursor
	 * @param sharedObj
	 * @param query
	 * @param docId 
	 */
	private void updateDocument(DBCollection collectionPersonal, DBCursor personalDBCursor, DBObject sharedObj,
			DBObject query, Object docId) {
		try {
		DBObject personalObj = personalDBCursor.next();
		Map mapPersonal = personalObj.toMap();
		Map mapShared = sharedObj.toMap();
		mapPersonal.putAll(mapShared);
		DBObject finalObject = new BasicDBObject(mapPersonal);
		collectionPersonal.update(query, finalObject);
		}catch(Exception ex) {
			logger.error("Error while update document ID:"+docId, ex.getMessage());
		}
	}

	/**
	 * @param sharedDBCursor
	 * @param personalDBCursor
	 */
	private void closeCursors(DBCursor sharedDBCursor, DBCursor personalDBCursor) {
		if(null != sharedDBCursor) {
			sharedDBCursor.close();
		}
		if(null != personalDBCursor) {
			personalDBCursor.close();
		}
	}

	public static void main(String[] args) {
		DataSyncDao.getInstance().syncDBById("XXXXXX");
	}

}
