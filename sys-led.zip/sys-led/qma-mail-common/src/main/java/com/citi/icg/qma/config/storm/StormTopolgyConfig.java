package com.citi.icg.qma.config.storm;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.exception.QmaInitializationException;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

public class StormTopolgyConfig {

	private static final Logger logger = LoggerFactory.getLogger(StormTopolgyConfig.class);

	private Map<String, Object> qmaStormTopologyConfigMap;
	private Map<String, Object> qmaStormBoltConfigMap;
  	private Map<String, Object> qmaStormKafkaConfigMap;
	private int parallelismHint;
  
  	private String processingGuarantee;
	private long offsetCommitPeriodMs;
	private int maxUncommittedOffsets;
	
	private TopologyName topologyName;
	
	public enum TopologyName {
		CONTROLLER("Controller-Topology"), PROCESSOR("Processor-Topology"), SNAPSHOT("Snapshot-Topology"), 
		PERSONAL_CONTROLLER("Personal-Controller-Topology"), PERSONAL_PROCESSOR("Personal-Processor-Topology"), PERSONAL_SNAPSHOT("Personal-Snapshot-Topology");
		
		private final String displayName;
		TopologyName(String displayName) {
			this.displayName = displayName;
		}
		public String getDisplayName() {
			return displayName;
		}
	}
	
	public static StormTopolgyConfig load(TopologyName topologyName){
		StormTopolgyConfig config=new StormTopolgyConfig(topologyName);
		return config;
		
	}

	private StormTopolgyConfig(TopologyName topologyName) {
		if(topologyName==null){
			throw new QmaInitializationException(new IllegalArgumentException("Topology Name is null"));
		}
		this.topologyName=topologyName;
		Config config = QMACacheFactory.getCache().getConfigById("qmaStormConfig");
		Map<String, Object> map = config.getQmaStormConfig(); // map with all topologies config
		String nameInMap=getMapNameByTopologyName(topologyName);
		BasicDBObject topologyConfig = (BasicDBObject) map.get(nameInMap); //only required topology's config
		BasicDBList list=(BasicDBList) topologyConfig.get("keyValueList");
		this.qmaStormTopologyConfigMap = getGeneratedMap(list);
		this.parallelismHint = topologyConfig.getInt("parallelism_hint");
		logger.info("Topology config parallelismHint is {}", this.parallelismHint);
		logger.info("Topology config map is {}", this.qmaStormTopologyConfigMap);
		
		BasicDBList boltConfigList=(BasicDBList) topologyConfig.get("boltConfigList");
      	BasicDBList kafkaConfigList=(BasicDBList) topologyConfig.get("kafkaConfigList");
		this.qmaStormBoltConfigMap = getGeneratedMap(boltConfigList);
      	this.qmaStormKafkaConfigMap = getGeneratedMap(kafkaConfigList);
      
      this.processingGuarantee = topologyConfig.getString("processingGuarantee");
      this.offsetCommitPeriodMs = topologyConfig.getLong("offsetCommitPeriodMs");
      this.maxUncommittedOffsets = topologyConfig.getInt("maxUncommittedOffsets");
		logger.info("Topology config processingGuarantee is {},offsetCommitPeriodMs is {}, maxUncommittedOffsets is {} ", this.processingGuarantee, this.offsetCommitPeriodMs, this.maxUncommittedOffsets);

	}

	private Map<String, Object> getGeneratedMap(BasicDBList list) {
		Map<String, Object> map = new HashMap<String, Object>();
		if(null !=list){
			for (Object object : list) {
				String key = (String) ((BasicDBObject) object).get("key");
				Object value = ((BasicDBObject) object).get("value");
				map.put(key, value);
			}
		}
		return map;
	}

	private String getMapNameByTopologyName(TopologyName topologyName){
		String val=null;
		switch (topologyName) {
		case CONTROLLER:
			val="controllerTopologyConfig";
			break;
		case PROCESSOR:
			val="processorTopologyConfig";
			break;
		case SNAPSHOT:
			val="snapshotTopologyConfig";
			break;
		case PERSONAL_CONTROLLER:
			val="personalControllerTopologyConfig";
			break;
		case PERSONAL_PROCESSOR:
			val="personalProcessorTopologyConfig";
			break;
		case PERSONAL_SNAPSHOT:
			val="personalSnapshotTopologyConfig";
			break;

		}
		logger.info("Val is "+val);
		return val;

	}
	public Map<String, Object> getQmaStormTopologyConfigMap() {
		return qmaStormTopologyConfigMap;
	}

	public Map<String, Object> getQmaStormBoltConfigMap() {
		return qmaStormBoltConfigMap;
	}
  
  public Map<String, Object> getQmaStormKafkaConfigMap() {
		return qmaStormKafkaConfigMap;
	}

	public void setQmaStormBoltConfigMap(Map<String, Object> qmaStormBoltConfigMap) {
		this.qmaStormBoltConfigMap = qmaStormBoltConfigMap;
	}
  
  public void setQmaStormKafkaConfigMap(Map<String, Object> qmaStormKafkaConfigMap) {
		this.qmaStormKafkaConfigMap = qmaStormKafkaConfigMap;
	}

	public int getParallelismHint() {
		return parallelismHint;
	}
  
  public String getProcessingGuarantee() {
		return processingGuarantee;
	}
  public long getOffsetCommitPeriodMs() {
		return offsetCommitPeriodMs;
	}
  public int getMaxUncommittedOffsets() {
		return maxUncommittedOffsets;
	}

	public TopologyName getTopologyName() {
		return topologyName;
	}

}