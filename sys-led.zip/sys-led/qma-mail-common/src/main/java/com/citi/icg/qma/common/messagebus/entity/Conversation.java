package com.citi.icg.qma.common.messagebus.entity;

public class Conversation {


	private Long id;
	private Long inquiryId;
	private String content;
	private String subject;
	private String bubbleContent;
	private Recipient from;
	
	public Conversation() {
		super();
	}

	// C153176-5216 - Pass content as bubble content
	public Conversation(Long id, Long inquiryId, String content, String subject, String bubbleContent, Recipient from) {
		super();
		this.id = id;
		this.inquiryId = inquiryId;
		this.content = content;
		this.subject = subject;
		this.bubbleContent = bubbleContent;
		this.from = from;
	}

	public Conversation(Long id, Long inquiryId, String content, String subject, Recipient from) {
		super();
		this.id = id;
		this.inquiryId = inquiryId;
		this.content = content;
		this.subject = subject;
		this.from = from;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getInquiryId() {
		return inquiryId;
	}

	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBubbleContent() {
		return bubbleContent;
	}

	public void setBubbleContent(String bubbleContent) {
		this.bubbleContent = bubbleContent;
	}

	public Recipient getFrom() {
		return from;
	}

	public void setFrom(Recipient from) {
		this.from = from;
	}


}
