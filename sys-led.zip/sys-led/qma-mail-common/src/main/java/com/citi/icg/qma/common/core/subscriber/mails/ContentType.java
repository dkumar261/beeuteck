package com.citi.icg.qma.common.core.subscriber.mails;

public enum ContentType
{
	TEXT("text/plain"),
	HTML("text/html"),
	RTF("text/rtf");

	private String type;

	ContentType(String type)
	{
		this.type = type;
	}

	//Sonar fix -- use override annotation on overridden method
	@Override
	public String toString()
	{
		return type;
	}
}
