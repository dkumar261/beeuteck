package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

import dev.morphia.annotations.Embedded;

@Embedded
public class Signature implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 890093315880996206L;
	private String name;
	private String content;

	public Signature()
	{

	}

	public Signature(String name, String content)
	{
		super();
		this.name = name;
		this.content = content;
	}
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
