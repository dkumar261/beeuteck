package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Entity;

import java.util.List;

@Entity(value = "GroupRoutingAudit", noClassnameStored = true)
public class GroupRoutingAudit extends BaseEntity
{
    private Long groupId;
    private String groupName;
    private String groupEmail; 
    private List<RoutingCriteria> routesAudit;
	
	public GroupRoutingAudit()
	{
		super();
	}

    public GroupRoutingAudit(Long groupId, String groupName, String groupEmail, List<RoutingCriteria> routesAudit)
    {
        super();
        this.groupId = groupId;
        this.groupName = groupName;
        this.groupEmail = groupEmail;
        this.routesAudit = routesAudit;
    }

    /**
     * @return the groupId
     */
    public Long getGroupId()
    {
        return groupId;
    }

    /**
     * @param groupId the groupId to set
     */
    public void setGroupId(Long groupId)
    {
        this.groupId = groupId;
    }

    /**
     * @return the groupName
     */
    public String getGroupName()
    {
        return groupName;
    }

    /**
     * @param groupName the groupName to set
     */
    public void setGroupName(String groupName)
    {
        this.groupName = groupName;
    }

    /**
     * @return the groupEmail
     */
    public String getGroupEmail()
    {
        return groupEmail;
    }

    /**
     * @param groupEmail the groupEmail to set
     */
    public void setGroupEmail(String groupEmail)
    {
        this.groupEmail = groupEmail;
    }

    /**
     * @return the routesAudit
     */
    public List<RoutingCriteria> getRoutesAudit()
    {
        return routesAudit;
    }

    /**
     * @param routesAudit the routesAudit to set
     */
    public void setRoutesAudit(List<RoutingCriteria> routesAudit)
    {
        this.routesAudit = routesAudit;
    }

    
}
