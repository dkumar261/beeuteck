package com.citi.icg.qma.common.core.config;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;

/**
 * Provides a single reference to manager all configuration modules.
 */
public final class ConfigurationManager
{
	private static final String MODULE_NAME_POSTFIX = "]:";
	private static final String MODULE_NAME_PREFIX = "[";
	private static Map<String, Configuration> configModules = Collections.synchronizedMap(new HashMap<String, Configuration>());

	private ConfigurationManager()
	{
	}

	protected static void register(String name, Configuration configurationModule)
	{
		configModules.put(name, configurationModule);
	}

	public static Configuration getConfiguration(String name)
	{
		return configModules.get(name);
	}

	public static Map<String, Configuration> getConfigModules()
	{
		return configModules;
	}

	@SuppressWarnings("unchecked")
	public static Set<Entry<Object, Object>> getProperties()
	{
		Properties properties = new Properties();

		// synchronize access to the module map
		synchronized (configModules)
		{
			// copy module configuration to new list for returning back to the
			// requester
			// -- for each module
			for (Entry<String, Configuration> configModule : configModules.entrySet())
			{
				Configuration configurationModule = configModule.getValue();
				Iterator<String> keyEntries = configurationModule.getKeys();
				String configurationName = configModule.getKey();

				// -- for each existing key template ex: tables.table.width
				for (Iterator<String> entry = keyEntries; entry.hasNext();)
				{
					List<String> allKeys = configurationModule.geKeysForAllContainers(entry.next());

					// -- for each unique key ex: tables.table(0).width(1)
					for (String key : allKeys)
					{
						properties.setProperty(MODULE_NAME_PREFIX + configurationName + MODULE_NAME_POSTFIX + key, configurationModule
								.getString(key));
					}
				}
			}
		}

		return properties.entrySet();
	}

	public static void setProperty(String propertyNameWithModulePrefix, String propertyValue)
	{
		// extract module name and property name ex: [module]:propertyName
		String moduleName = StringUtils.substringBetween(propertyNameWithModulePrefix, MODULE_NAME_PREFIX, MODULE_NAME_POSTFIX);
		String propertyName = StringUtils.substringAfter(propertyNameWithModulePrefix, MODULE_NAME_POSTFIX);

		// get module name
		Configuration confiModule = configModules.get(moduleName);

		// set property
		confiModule.setProperty(propertyName, propertyValue);
	}

}
