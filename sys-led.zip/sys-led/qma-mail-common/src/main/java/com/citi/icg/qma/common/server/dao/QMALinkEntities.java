package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import dev.morphia.annotations.Entity;

@Entity(value = "QMALinkEntities", noClassnameStored = true)
public class QMALinkEntities extends BaseEntity{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4892387046780671819L;
	private Long inquiryId;
	
	private List<EntityGroupData> entityGroupData;
	
	public QMALinkEntities() {
		super();
	}

	public Long getInquiryId() {
		return inquiryId;
	}

	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}

	
	
	public List<EntityGroupData> getEntityGroupData() {
		return entityGroupData;
	}

	public void setEntityGroupData(List<EntityGroupData> entityGroupData) {
		this.entityGroupData = entityGroupData;
	}



	public static class EntityGroupData implements Serializable{
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 8613425866099786631L;

		private Long groupId;

		private List<EntityRecord> entityRecords;
		
		private Date crtDate;
		private Date modDate;
		
		public EntityGroupData() {
			super();
		}

		public Long getGroupId() {
			return groupId;
		}

		public void setGroupId(Long groupId) {
			this.groupId = groupId;
		}

		public List<EntityRecord> getEntityRecords() {
			return entityRecords;
		}

		public void setEntityRecords(List<EntityRecord> entityRecords) {
			this.entityRecords = entityRecords;
		}

		public Date getCrtDate() {
			return crtDate;
		}

		public void setCrtDate(Date crtDate) {
			this.crtDate = crtDate;
		}

		public Date getModDate() {
			return modDate;
		}

		public void setModDate(Date modDate) {
			this.modDate = modDate;
		}
		
	}
	
	public static class EntityRecord implements Serializable{
		
		/**
		 * 
		 */
		private static final long serialVersionUID = -3713529017638309644L;
		String clientId;
		String entityId;
		String entityType;
		String entityAction;
		String entityStatus;
		String productFamily;
		Date processDate;
		String entityOriginatorId;
		String processFlag;
		
		public EntityRecord() {
			super();
		}
		public String getClientId() {
			return clientId;
		}
		public void setClientId(String clientId) {
			this.clientId = clientId;
		}
		public String getEntityId() {
			return entityId;
		}
		public void setEntityId(String entityId) {
			this.entityId = entityId;
		}
		public String getEntityType() {
			return entityType;
		}
		public void setEntityType(String entityType) {
			this.entityType = entityType;
		}
		
		public String getEntityAction() {
			return entityAction;
		}
		public void setEntityAction(String entityAction) {
			this.entityAction = entityAction;
		}
		public String getEntityStatus() {
			return entityStatus;
		}
		public void setEntityStatus(String entityStatus) {
			this.entityStatus = entityStatus;
		}
		public String getProductFamily() {
			return productFamily;
		}
		public void setProductFamily(String productFamily) {
			this.productFamily = productFamily;
		}
		public Date getProcessDate() {
			return processDate;
		}
		public void setProcessDate(Date processDate) {
			this.processDate = processDate;
		}
		public String getEntityOriginatorId() {
			return entityOriginatorId;
		}
		public void setEntityOriginatorId(String entityOriginatorId) {
			this.entityOriginatorId = entityOriginatorId;
		}
		public String getProcessFlag() {
			return processFlag;
		}
		public void setProcessFlag(String processFlag) {
			this.processFlag = processFlag;
		}
		
	}
		

}

