package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "QmaAuthenticationLog", noClassnameStored = true)
public class QmaAuthenticationLog implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	private String appId;
	private String csiId;
	private String signKey;
	private long tokenExpirationInMillis;
	private String jwtToken;
	private String userId;
	
	
	public QmaAuthenticationLog() {
		// default constructor
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getCsiId() {
		return csiId;
	}
	public void setCsiId(String csiId) {
		this.csiId = csiId;
	}
	
	
	public String getSignKey() {
		return signKey;
	}
	public void setSignKey(String signKey) {
		this.signKey = signKey;
	}
	public long getTokenExpirationInMillis() {
		return tokenExpirationInMillis;
	}
	public void setTokenExpirationInMillis(long tokenExpirationInMillis) {
		this.tokenExpirationInMillis = tokenExpirationInMillis;
	}
	public String getJwtToken() {
		return jwtToken;
	}
	public void setJwtToken(String jwtToken) {
		this.jwtToken = jwtToken;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}