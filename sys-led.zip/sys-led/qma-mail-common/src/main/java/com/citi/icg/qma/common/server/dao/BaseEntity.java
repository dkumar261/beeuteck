package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

import dev.morphia.Datastore;
import dev.morphia.annotations.Id;
import dev.morphia.annotations.PrePersist;
import dev.morphia.annotations.Transient;
import dev.morphia.annotations.Version;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

import com.google.gson.annotations.SerializedName;

/**
 * Provide the BaseEntity implementation for all entities:
 * 
 * ID, creation and last change date, version, their getters and setters (including @PrePersist), and some abstract methods we'll require in the specific entities.
 */
public abstract class BaseEntity implements Serializable
{

	private static final long serialVersionUID = -501020007308859126L;

	@Transient
	private static Datastore mongoDatastore = null;

	@Id
	@SerializedName("_id")
	public Long id;

	/**
	 * We'll only provide getters for these attributes, setting is done in @PrePersist.
	 */

	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private Date crtDate;
	private Date modDate;

	/**
	 * No getters and setters required, the version is handled internally.
	 */
	@Version
	private Long version;

	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private String crtBy;
	private String modBy;

	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	public Date getCrtDate()
	{
		return crtDate;
	}

	public Date getModDate()
	{
		return modDate;
	}

	@PrePersist
	public void prePersist()
	{
		this.crtDate = (crtDate == null) ? new Date() : crtDate;
		this.modDate = (modDate == null) ? crtDate : modDate;
		if (this.id == null)
		{
			final String collName = mongoDatastore.getCollection(getClass()).getName();
			id = getNextSequenceId(collName);
		}
	}

	public void setCrtDate(Date crtDate)
	{
		this.crtDate = crtDate;
	}

	public void setModDate(Date modDate)
	{
		this.modDate = modDate;
	}

	public static void setMongoDatastore(Datastore mongoDatastore)
	{
		BaseEntity.mongoDatastore = mongoDatastore;
	}

	private Long getNextSequenceId(String collName)
	{
		//Sonar Fix 2 -- Rename "content" which hides the field declared and useless assignment
		final Query<SequenceId> q = mongoDatastore.find(SequenceId.class, "_id", collName);
		final UpdateOperations<SequenceId> uOps = mongoDatastore.createUpdateOperations(SequenceId.class).inc("value");
		SequenceId newId = mongoDatastore.findAndModify(q, uOps);

		if (newId == null)
		{
			newId = new SequenceId(collName);
			mongoDatastore.save(newId);
		}

		return newId.getValue();
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public String getModBy() {
		return modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	/**
	 * @return the version
	 */
	public Long getVersion()
	{
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(Long version)
	{
		this.version = version;
	}
	
}
