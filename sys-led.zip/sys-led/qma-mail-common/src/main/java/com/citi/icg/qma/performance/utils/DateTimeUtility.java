package com.citi.icg.qma.performance.utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dev.morphia.Datastore;
import dev.morphia.query.Query;

import com.citi.icg.qma.common.core.util.DateUtil;
import com.citi.icg.qma.dao.ComponentEvent;
import com.citi.icg.qma.dao.MessageSnapshot;
import com.citi.icg.qma.dao.persistence.MessageSnapshotDAO;
import com.opencsv.CSVWriter;


public class DateTimeUtility {
	private static Datastore mongoDatastore;
	static DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	private static final Logger logger = LoggerFactory.getLogger(DateTimeUtility.class);

	public static void main(String[] args) throws ParseException {

		MessageSnapshotDAO messageSnapshotDAO;
		messageSnapshotDAO=MessageSnapshotDAO.getInstance();
		List<MessageSnapshot> list= messageSnapshotDAO.getMessageSnapshotFromDBWithSubjectName("Performance-Testing");

		List<Long> ReaderDates = new ArrayList<Long>();
		List<Long> ControllerDates = new ArrayList<Long>();
		List<Long> ProcessorDates = new ArrayList<Long>();
		long processorTimePerMessage[]=new long[list.size()] ;
		List<String[]> BufferDataAllMsg = new ArrayList<String[]>(); 
		Long bufferDataPerMsg[] = new Long[9]; 

		int new_inquiry=0;
		int reply_inquiry=0;
		Boolean flag_inquiryType_noted;
		int mpbolt_count = 0;
		int i=0;

		if (list.isEmpty()){
			
			System.exit(0);
		}
		
		
		for (MessageSnapshot msg : list) {
			flag_inquiryType_noted = false;
			List<Long> processorTimeTempList = new ArrayList<Long>();
			for (ComponentEvent event: msg.getEvents()){
				if (event.getComponent().equalsIgnoreCase("READER")){
					ReaderDates.add(event.getTime().getTime());
				}
				else if (event.getComponent().equalsIgnoreCase("CONTROLLER")){
					ControllerDates.add(event.getTime().getTime());
				}
				else if (event.getComponent().equalsIgnoreCase("PROCESSOR")){
					ProcessorDates.add(event.getTime().getTime());
					processorTimeTempList.add(event.getTime().getTime());

					/*Code to find the number of times Processor has been replayed for messages*/
					if (event.getBlock().equalsIgnoreCase("MessageProcessorBolt") && event.getEvent().equalsIgnoreCase("STARTED")){
						mpbolt_count++;
					}
					
					/*Code to find number of new Inquiries and number of reply flows*/

					if (event.getEvent().equalsIgnoreCase("NEW_INQUIRY") && !flag_inquiryType_noted){
						new_inquiry++;
						flag_inquiryType_noted=true;
					}
					else if (event.getEvent().equalsIgnoreCase("REPLY_INQUIRY") && !flag_inquiryType_noted){
						reply_inquiry++;
						flag_inquiryType_noted=true;
					}
				}
				
				if (event.getComponent().equalsIgnoreCase("READER") && event.getBlock().equalsIgnoreCase("MongoMailReaderThread") &&
						event.getEvent().equalsIgnoreCase("FINISHED")){
					bufferDataPerMsg[0]=TimeUnit.MILLISECONDS.toMillis(event.getTime().getTime());					
				}
				if (event.getComponent().equalsIgnoreCase("CONTROLLER") && event.getBlock().equalsIgnoreCase("ReferenceParserBolt") &&
						event.getEvent().equalsIgnoreCase("STARTED")){
					bufferDataPerMsg[1]=TimeUnit.MILLISECONDS.toMillis(event.getTime().getTime());			
				}
				if (event.getComponent().equalsIgnoreCase("CONTROLLER") && event.getBlock().equalsIgnoreCase("ReferenceParserBolt") &&
						event.getEvent().equalsIgnoreCase("FINISHED")){
					bufferDataPerMsg[2]=TimeUnit.MILLISECONDS.toMillis(event.getTime().getTime());					
				}
				if (event.getComponent().equalsIgnoreCase("PROCESSOR") && event.getBlock().equalsIgnoreCase("MessageProcessorBolt") &&
						event.getEvent().equalsIgnoreCase("STARTED")){
					bufferDataPerMsg[3]=TimeUnit.MILLISECONDS.toMillis(event.getTime().getTime());				
				}
				if (event.getComponent().equalsIgnoreCase("PROCESSOR") && event.getBlock().equalsIgnoreCase("MessageProcessorBolt") &&
						event.getEvent().equalsIgnoreCase("FINISHED")){
					bufferDataPerMsg[4]=TimeUnit.MILLISECONDS.toMillis(event.getTime().getTime());				
				}
				if (event.getComponent().equalsIgnoreCase("PROCESSOR") && event.getBlock().equalsIgnoreCase("EmailActionStatisticsBolt") &&
						event.getEvent().equalsIgnoreCase("STARTED")){
					bufferDataPerMsg[5]=TimeUnit.MILLISECONDS.toMillis(event.getTime().getTime());				
				}
				if (event.getComponent().equalsIgnoreCase("PROCESSOR") && event.getBlock().equalsIgnoreCase("WebsocketPublisherBolt") &&
						event.getEvent().equalsIgnoreCase("STARTED")){
					bufferDataPerMsg[6]=TimeUnit.MILLISECONDS.toMillis(event.getTime().getTime());				
				}
				if (event.getComponent().equalsIgnoreCase("PROCESSOR") && event.getBlock().equalsIgnoreCase("XStreamExceptionLinkingBolt") &&
						event.getEvent().equalsIgnoreCase("STARTED")){
					bufferDataPerMsg[7]=TimeUnit.MILLISECONDS.toMillis(event.getTime().getTime());				
				}
				if (event.getComponent().equalsIgnoreCase("PROCESSOR") && event.getBlock().equalsIgnoreCase("NLPIntegrationBolt") &&
						event.getEvent().equalsIgnoreCase("STARTED")){
					bufferDataPerMsg[8]=TimeUnit.MILLISECONDS.toMillis(event.getTime().getTime());				
				}
			}	
			try {
				BufferDataAllMsg.add(new String[]{Long.toString(bufferDataPerMsg[1]-bufferDataPerMsg[0]),
						  Long.toString(bufferDataPerMsg[3]-bufferDataPerMsg[2]),
						  Long.toString(bufferDataPerMsg[5]-bufferDataPerMsg[4]),
						  Long.toString(bufferDataPerMsg[6]-bufferDataPerMsg[4]),
						  Long.toString(bufferDataPerMsg[7]-bufferDataPerMsg[4]),
						  Long.toString(bufferDataPerMsg[8]-bufferDataPerMsg[4])});
				long duration = TimeUnit.MILLISECONDS.toSeconds(Collections.max(processorTimeTempList)-Collections.min(processorTimeTempList));
				processorTimePerMessage[i++]=duration;
			} catch (Exception e) {
				
			}
			/*Stores time taken by processor component for all the messages*/
		
			
		}
		//writeDataOnFile(BufferDataAllMsg);
		Long minReaderDate = Collections.min(ReaderDates);
		Long maxReaderDate = Collections.max(ReaderDates);
		Long minControllerDate = Collections.min(ControllerDates);
		Long maxControllerDate = Collections.max(ControllerDates);
		Long minProcessorDate = Collections.min(ProcessorDates);
		Long maxProcessorDate = Collections.max(ProcessorDates);

		
		
		//FileWriter w=new FileWriter("xlist.txt");
		
		//w.write(xlist.stream().map(String::valueOf).collect(Collectors.joining(",")));
		
		//w.close();

		

		long Rdiff = TimeUnit.MILLISECONDS.toMillis(maxReaderDate-minReaderDate);	
		long Cdiff = TimeUnit.MILLISECONDS.toMillis(maxControllerDate-minControllerDate);
		long Pdiff = TimeUnit.MILLISECONDS.toMillis(maxProcessorDate-minProcessorDate);
		long Tdiff = TimeUnit.MILLISECONDS.toMillis(maxProcessorDate-minReaderDate);



		long processorTimeBrackets[]=new long[4] ;
		processorTimeBrackets[0]=0;
		processorTimeBrackets[1]=0;
		processorTimeBrackets[2]=0;
		processorTimeBrackets[3]=0;

		for (i=0;i<processorTimePerMessage.length;i++){
			if (processorTimePerMessage[i]==0)
				processorTimeBrackets[0]++;
			else if (processorTimePerMessage[i]==1)
				processorTimeBrackets[1]++;
			else if (processorTimePerMessage[i]==2)
				processorTimeBrackets[2]++;
			else
				processorTimeBrackets[3]++;

		}
		
	}
	
	public static void writeDataOnFile(List<String[]> data ){
		 // first create file object for file placed at location 
	    // specified by filepath 
	    File file = new File("C:\\Users\\XXXXXX\\Documents\\componentsTime.txt"); 
	  
	    try { 
	        // create FileWriter object with file as parameter 
	        FileWriter outputfile = new FileWriter(file); 
	  
	        // create CSVWriter object filewriter object as parameter 
	        CSVWriter writer = new CSVWriter(outputfile); 
	  
	        String[] header = { "(R)MongoMailReaderThread-(C)ReferenceParserBolt", 
	        					"(C)ReferenceParserBolt-(P)MessageProcessorBolt",
	        					"(P)MessageProcessorBolt-(P)EmailActionStatisticsBolt",
	        					"(P)MessageProcessorBolt-(P)WebsocketPublisherBolt",
	        					"(P)MessageProcessorBolt-(P)XStreamExceptionLinkingBolt",
	        					"(P)MessageProcessorBolt-(P)NLPIntegrationBolt"}; 
	        writer.writeNext(header); 
	        
	        writer.writeAll(data); 
	  
	        // closing writer connection 
	        writer.close(); 
	    } 
	    catch (IOException e) { 
		logger.warn("Exception in writeDataOnFile", e);
	    } 

	}
}
