package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "BrazilClientMapping", noClassnameStored = true)
public class BrazilClientMapping extends BaseEntity{

	private String baseNumber;
	private String clientId;
	private String clientName;
	private String searchKeywords;
	
	public BrazilClientMapping() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getBaseNumber() {
		return baseNumber;
	}

	public void setBaseNumber(String baseNumber) {
		this.baseNumber = baseNumber;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getSearchKeywords() {
		return searchKeywords;
	}

	public void setSearchKeywords(String searchKeywords) {
		this.searchKeywords = searchKeywords;
	}
	
}
