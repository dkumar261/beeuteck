package com.citi.icg.qma.common.core.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;

/**
 * App Helper routines.
 */
public final class DateUtil
{
	/** format string MM-dd HH:mm */
	public static final String SIMPLE_DATE_FORMAT = "MM-dd HH:mm";

	/** format string MM-dd HH:mm:ss */
	public static final String SIMPLE_DATE_FORMAT_SS = "MM-dd HH:mm:ss";

	/** format string MM-dd HH:mm:S */
	public static final String SIMPLE_DATE_FORMAT_SS_MMM = "MM-dd HH:mm:S";

	private DateUtil()
	{
	}

	public static Date getYesterday()
	{
		return getDayBefore(-1);
	}

	public static Date getDayBefore(int daysBefore)//Sonar Fix remove unused parameter
	{
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, daysBefore);
		return cal.getTime();
	}
	
	public static Date getBusinessDayBefore(int businessDaysBefore) {
		Date requiredDate;
		Date currentDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(currentDate);

		while (businessDaysBefore > 1) {
			calendar.add(Calendar.DAY_OF_MONTH, -1);
			int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
			if (dayOfWeek != Calendar.SATURDAY && dayOfWeek != Calendar.SUNDAY) {
				--businessDaysBefore;
			}
		}

		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		requiredDate = calendar.getTime();
		return requiredDate;
	}

	/**
	 * Convenience method to format time in ms
	 * 
	 * @param time
	 *            - time (in ms) to format
	 * @param format
	 *            - the format string to use
	 * @return the formated date string
	 */
	public static String formatDate(long time, String format)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(time);
	}

	/**
	 * Convenience method to format date object
	 * 
	 * @param date
	 *            - date object to format
	 * @param format
	 *            - the format string to use
	 * @return the formated date string
	 */
	public static String formatDate(Date date, String format)
	{
		if (date != null)
		{
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			return dateFormat.format(date);
		}

		return StringUtils.EMPTY;
	}

	public static String formaDuration(long durationInMilliseconds)
	{
		long days = durationInMilliseconds / DateUtils.MILLIS_PER_DAY;
		long hours = (durationInMilliseconds % DateUtils.MILLIS_PER_DAY) / DateUtils.MILLIS_PER_HOUR;
		long minutes = (durationInMilliseconds % DateUtils.MILLIS_PER_HOUR) / DateUtils.MILLIS_PER_MINUTE;
		long seconds = (durationInMilliseconds % DateUtils.MILLIS_PER_MINUTE) / DateUtils.MILLIS_PER_SECOND;
		long milliseconds = durationInMilliseconds % DateUtils.MILLIS_PER_SECOND;//Sonar Fix remove unused parenthesis

		// CHECKSTYLE:OFF
		StringBuilder duration = new StringBuilder();//Sonar Fix -- Replace the synchronized class "StringBuffer" by an unsynchronized one such as "StringBuilder"
		if (days > 0)
		{
			duration.append(days + " days ");
		}
		if (hours > 0)
		{
			duration.append(hours + " hours ");
		}
		if (minutes > 0)
		{
			duration.append(minutes + " min ");
		}
		if (seconds > 0)
		{
			duration.append(seconds + " sec ");
		}
		if (milliseconds > 0)
		{
			duration.append(milliseconds + " ms ");
		}
		// CHECKSTYLE:ON

		return duration.toString();
	}

	public static String formaDurationDayAndHours(long durationInMilliseconds)
	{
		long days = durationInMilliseconds / DateUtils.MILLIS_PER_DAY;
		long hours = (durationInMilliseconds % DateUtils.MILLIS_PER_DAY) / DateUtils.MILLIS_PER_HOUR;
		//Sonar Fix remove unused variable

		// CHECKSTYLE:OFF
		StringBuilder duration = new StringBuilder();//Sonar Fix -- Replace the synchronized class "StringBuffer" by an unsynchronized one such as "StringBuilder"
		if (days > 0)
		{
			duration.append(days);
		}
		else
		{
			duration.append(0);
		}

		if (hours > 0)
		{
			duration.append(CharConstants.DOT);
			duration.append(hours);
		}
		return duration.toString();
	}

}
