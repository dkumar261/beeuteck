/**
 * 
 */
package com.citi.icg.qma.common.server.util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.entity.ContentType;
import org.asynchttpclient.AsyncCompletionHandler;
import org.asynchttpclient.AsyncHttpClient;
import org.asynchttpclient.BoundRequestBuilder;
import org.asynchttpclient.HttpResponseStatus;
import org.asynchttpclient.Response;
import org.asynchttpclient.request.body.multipart.FilePart;
import org.asynchttpclient.request.body.multipart.StringPart;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.NLPConstants;
import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.persistence.NLPSuggestionDAO;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;

/**
 *  
 * This class is used to configure and connect to NLP Query engine 
 * and send synchronous or asynchronous request to the NLP host server.
 */
public class NLPAutoRoutingQueryEngine {

	private static Logger logger = LoggerFactory.getLogger(NLPAutoRoutingQueryEngine.class);
	private static NLPSuggestionDAO sugDao=new NLPSuggestionDAO();
	public static List<String> SUPPORTED_ATTACHMENTS = new ArrayList<>();	
	public static Map<String, Object> nlpConfig;
	private NLPAutoRoutingQueryEngine(){}
	
	static {
		//nlpConfig = staticData.getNlpConfiguration();
		nlpConfig = QMACacheFactory.getCache().getNlpConfiguration();
		NLPConstants.NLP_HOST_AUTHORIZATION = Base64.getEncoder()
				.encodeToString(((String)nlpConfig.get(NLPConstants.NLP_QMA_USERNAME_KEY) + ':' + (String)nlpConfig.get(NLPConstants.NLP_QMA_PASSDATA_KEY)).getBytes(StandardCharsets.UTF_8));
	}
	/**
	 * @param clientRequestId
	 * @param conversation
	 * @param attachments
	 * @param toCCValidGroupIds
	 * @param actionBy
	 * @param nlpRequestType
	 * @param inquiry
	 */
	public static void getAutoAssignmentSuggestion(String clientRequestId, Conversation conversation,
			List<Map<String, Object>> attachments, List<Long> toCCValidGroupIds, String actionBy, String nlpRequestType,Inquiry inquiry) {
		AsyncHttpClient client = null;
		try {
			if(StringUtils.isNotEmpty(NLPConstants.NLP_HOST_AUTHORIZATION)){
				logger.info("Auto-assignment NLP service called for clientRequestId : " + clientRequestId +" nlpRequestType : "+nlpRequestType+"actionBy : "+actionBy);
				client = NLPQueryEngineUtil.getAsyncHttpClient();
				if( client != null ) {
					BasicDBObject requestBody = NLPQueryEngineUtil.generateRequestBodyContents(clientRequestId, conversation,nlpRequestType,inquiry,actionBy, toCCValidGroupIds, null);
					List<FilePart> fileParts = NLPQueryEngineUtil.generateAttachmentBodyParts(attachments, requestBody);
					StringPart stringPart =NLPQueryEngineUtil.generateContentBodyPart(requestBody); 
					sugDao.createSuggestionRequestRecord(conversation, clientRequestId,requestBody, toCCValidGroupIds, new Date(),actionBy, nlpRequestType);
					Map<String,Object> httpRequestHeadersParamMap = new HashMap();
					buildAndExecuteAsyncRequest(client, clientRequestId,fileParts,stringPart,nlpRequestType,conversation,httpRequestHeadersParamMap);
					sugDao.updateHttpRequestHeaders(clientRequestId, httpRequestHeadersParamMap);
					logger.info("Asynch request processed for clientRequestId("+ clientRequestId + ") at : " + new Date());
					
				} else {
					logger.info("Failed to initialized async client for this request.");
				}
			} else {
				logger.info("Could not find authorization details for Auto assignment NLP Query Engine.");
				closeConnection(client, clientRequestId);
			}
		} catch (Exception e) {
			logger.error(" Error while sending asynch request for client id (" + clientRequestId + ") : ", e);
		}

	}
	
	public static void getIntentSuggestion(String clientRequestId, Conversation conversation,
			List<Map<String, Object>> attachments, List<Long> toCCValidGroupIds, String actionBy, String nlpRequestType,Inquiry inquiry) {
		AsyncHttpClient client = null;
		try {
				logger.info("Intent Suggestion NLP service called for clientRequestId : {},nlpRequestType : {}, actionBy : {}", clientRequestId,nlpRequestType, actionBy);
				client = NLPQueryEngineUtil.getAsyncHttpClient();
				if( client != null ) {
					BasicDBObject requestBody = NLPQueryEngineUtil.generateRequestBodyContents(clientRequestId, conversation,nlpRequestType,inquiry,actionBy, toCCValidGroupIds, null);
					List<FilePart> fileParts = NLPQueryEngineUtil.generateAttachmentBodyParts(attachments, requestBody);
					StringPart stringPart =NLPQueryEngineUtil.generateContentBodyPart(requestBody); 
					sugDao.createSuggestionRequestRecord(conversation, clientRequestId,requestBody, toCCValidGroupIds, new Date(),actionBy, nlpRequestType);
					Map<String,Object> httpRequestHeadersParamMap = new HashMap<>();
					buildAndExecuteAsyncRequest(client, clientRequestId,fileParts,stringPart,nlpRequestType,conversation,httpRequestHeadersParamMap);
					sugDao.updateHttpRequestHeaders(clientRequestId, httpRequestHeadersParamMap);
					logger.info("Asynch request processed for clientRequestId({}) at : {}" ,clientRequestId, new Date());
					
				} else {
					logger.info("Failed to initialized async client for this request.");
				}
			
		} catch (Exception e) {
			logger.error(" Error while sending asynch request for client id ({}) : ",clientRequestId, e);
		}

	}

	/**
	 * This method builds and executes asynchronous client request
	 * @param client
	 * @param clientReqId
	 * @param logger
	 * @param fileParts
	 * @param stringPart
	 * @param conversation 
	 * @param httpRequestHeadersParamMap 
	 * @param toCCValidGroupIds 
	 */
	private static void buildAndExecuteAsyncRequest(AsyncHttpClient client,String clientReqId,
			 List<FilePart> fileParts,StringPart stringPart, String nlpRequestType, Conversation conversation, Map<String, Object> httpRequestHeadersParamMap) {
		try {
			BoundRequestBuilder builder = client.preparePost(getAutoAssignmentHostURL(nlpRequestType));
	        builder.addHeader(HttpHeaders.AUTHORIZATION, "Basic " + NLPConstants.NLP_HOST_AUTHORIZATION);
	        builder.setHeader(HttpHeaders.CONTENT_TYPE, ContentType.MULTIPART_FORM_DATA.getMimeType());
	        builder.setHeader(NLPConstants.CALLBACK_URL_KEY, NLPQueryEngineUtil.getQMAServiceURL());
	        logger.info("New headers client secret key and client id are added");
	        //For Non Secure connection, Url should be configured with http and no client secret and client Id in config.
			String clientSecret = NLPQueryEngineUtil.getXIBMClientSecret();
			String clientId = NLPQueryEngineUtil.getXIBMClientId();
			if (StringUtils.isNotBlank(clientSecret) && StringUtils.isNotBlank(clientId)) {
				builder.setHeader(NLPConstants.X_IBM_Client_Secret_Key, clientSecret);
				builder.setHeader(NLPConstants.X_IBM_Client_id_Key, clientId);
			}
	        httpRequestHeadersParamMap.put(HttpHeaders.CONTENT_TYPE, ContentType.MULTIPART_FORM_DATA.getMimeType());
	        httpRequestHeadersParamMap.put(NLPConstants.CALLBACK_URL_KEY, NLPQueryEngineUtil.getQMAServiceURL());
	        NLPQueryEngineUtil.setAutoAssignedFwdHeader(builder, conversation, httpRequestHeadersParamMap);
	        /*Add String body parts*/
	        builder.addBodyPart(stringPart);
	        /*Add attachment body parts*/
	        for(FilePart filePart : fileParts){
	        	builder.addBodyPart(filePart);
	        }
			/*Execute the request*/
	        builder.execute(new AsyncCompletionHandler<Object>() {
				@Override
				public Object onCompleted(Response response) throws Exception {
					return response;
				}
				@Override
				public State onStatusReceived(HttpResponseStatus status) throws Exception {
					logger.info("Status Received : " + status);
					logger.info("Closing client connection onStatusReceived !");
					closeConnection(client,clientReqId);
					sugDao.updateSugReqStatus(clientReqId, status.getStatusCode(),status.getStatusText());
					return State.ABORT;
				}
				@Override
				public void onThrowable(Throwable t) {
					logger.error("Error while processing request to NLP query Engine for clientRequestId : "+ clientReqId , t );
					closeConnection(client,clientReqId);
				}
			});
		} catch (Exception e) {
			logger.error("Exception while executing client request for clientRequestId (" + clientReqId + "):", e);
		}
		
	}
	
	/**
	 * This method closes client connection
	 * @param client
	 * @param logger
	 */
	protected static void closeConnection(AsyncHttpClient client,String clientReqId) {
		try {
			if(client != null) {
				client.close();
			}
		} catch (IOException e) {
			logger.error("Error while closing asynch client connection for clientReqId : " + clientReqId, e );
		}
	}
		
	/**
	 * This method provides AUTO ASSIGNMENT host url
	 * @param logger
	 * @return
	 */
	private static String getAutoAssignmentHostURL(String nlpRequestType) {
		String autoAssignmentUrl = NLPConstants.HOST_BASE_URL_DEV.concat(":").concat(NLPConstants.HOST_PORT_DEV).concat(NLPConstants.AUTO_ASSIGNMENT_INTERNAL_URL); 
		if(NLPRequestType.I.name().equalsIgnoreCase(nlpRequestType) && NLPQueryEngineUtil.nlpConfig !=null && null != NLPQueryEngineUtil.nlpConfig.get(NLPConstants.INTENT_SUGGESTION_URL)){
			autoAssignmentUrl = (String)NLPQueryEngineUtil.nlpConfig.get(NLPConstants.INTENT_SUGGESTION_URL);
		}else if(NLPQueryEngineUtil.nlpConfig !=null && null != NLPQueryEngineUtil.nlpConfig.get(NLPConstants.AUTO_ASSIGNMENT_URL)){
			autoAssignmentUrl = (String)NLPQueryEngineUtil.nlpConfig.get(NLPConstants.AUTO_ASSIGNMENT_URL);
		}
		logger.info("Auto Assignment service URL is : {}", autoAssignmentUrl);
		return autoAssignmentUrl;
	}
}
