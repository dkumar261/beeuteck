package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.citi.icg.qma.common.transferobject.ColumnDefUI;

import dev.morphia.annotations.Embedded;
import dev.morphia.annotations.Entity;

@Entity(value = "StaticData", noClassnameStored = true)
public class StaticData extends BaseEntity implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4889856488726049132L;
	@Embedded
	private List<ColumnDef> masterColumnDef;
	@Embedded
	private List<ColumnDefUI> viewWorkFlowColumn;
	private List<ViewConfig> defaultViews;
	
	@Embedded
	private List<IncomingToCcDLAliasMapping> incomingToCcDLAliasMapping;
	// added below 3 variables as per discussion with sunil and prithpal dated 20 oct.
	private String mainWebsocketListenerHost;
	private String solrSearchEnable;
	private Long timoutMillis;
	private Long socketDataPollingInterval;
	private String solrURL;
	private String solrDeltaImportURL;
	private String solrCobDeltaImportURL;
	private Long solrDeltaRefreshInterval;// In Secs
	private List<String> queryAssignedGroup;
	// Below Field added for BCC Redirection. Made private and kept get/set methods to follow best practices.
	private List<Long> bccGroupIdList;

	private String enableGraphs;
	private String clipboardPaste;// For enabling and disabling the HTML conversion for rich text.

	private List<String> adminReportEmails;// List of Email Address which will be used to send Admin reports
	private List<String> xstreamStatEmails;// List of Email Address which will be used to receive XStream Comm Stat reports

	private Date groupLastModifiedTime = null;
	private Long chartDataReloadMaxCounter;
	private int chartDataRefreshInterval;

	private int nonInquiryAge = 0;// Inquiry Age in Days
	private int deletedInquiryAge = 0;// Inquiry Age in Days


	private String enableEmailBase64Encoding;// Enable base64encoding for email attachments(pdf) functionality


	private String enableInternalGroupEmailRouting;// Email Sent to Internal groups will be routed through exchangeServer if this flag is set to True

	private String disableOnBehalfOf;//Email Sender Group will be not be displayed as On behalf off in the Outlook, Only sender user is is shown and group will be displayed on reply. 
	
	//private String enableGrpBasedTopContact;// Enable new top contact version functionality if isNewTopContactsEnable='Y'.

	private List<Integer> errorCodeForWebsocketRestartList;// Enable websocket restart for error code list only.
	
	private List<String> internalGrpRoutingInclusionList ;// Email Sent to Internal groups listed in 'internalGrpRoutingInclusionList'  will be routed through exchangeServer if enableInternalGroupEmailRouting flag is set to True and alway's without on-behalf information.
	
	private String enableCustomStyleInConversation;// Enable custom style support in conversation
	
	private List<String> ignoreEmailListForProcessing; // This list when part of TO/CC, should be avoided to find group or parent group
	
	//Below property is used along with above mentioned 'disableOnBehalfOf'. if value of 'disableOnBehalfOf' is set to 'N' then it's applicable to all the DL's. 
	//Those DL's which doesn't want to use 'on behalf of' feature can opt not to use by adding entry in below disableOnBehalfOfGrpList.
	private List<String> disableOnBehalfOfGrpList;//Disable OnBehalfOff for the configured Grp here. It is not dependent on internal routing flag
	
	//Add list of groups to below property, if that particular DL want to show direct DL name in From field when the mail is received in outlook or external client
	private List<String> enableOnBehalfOfGroupNameList; 
	
	private String enableConvReferenceCheckAlways;//This will used to check reply emails coming from ex.server and used to check whether it is routed from internal
	
	private List<String> customStyleOverrideList;//List of Styles needs to be customized for the conversation details
	
	private String contentTypeJpeg = null;
	
	private String ping = null;
	//Collecting editor default  font style ,  font size  and list of font size and font style from static collection from static table C153176-142
	private List<String> editorFontStyle;
	private List<String> editorFontSize;
	private String defaultAppFontSize;
	private String defaultAppFontStyle;
	//[C153176-168] Changes for user preference date format  	 
	private String defaultDateFormate;
	private List<String> dateFormatterSelectItemList;
	
	//[	C153176-289] Flag to enable disable advanced solr search pop up screen.
	private String enableAdvancedSolrSearch;
	
	
	private Long bccRoutingGroup ;
	
	//[C153176-283] - Link collaborate urls
	private List<KeyValue> collaborateUrls;
	
	//[	C153176-578]-Rebranding XStream Communicator as Query Management App (QMA)
	private Date conversationCreatedBefore = null;
	private Long pubSubMonitorTimeMillis;
	private String pubSubMonitorEmail;
	private String enablePubSubMonitor;
	private String enableOptimizePubSub;
	private int convLimitCount;
	private String cslRestServerUrl;
	//[C153176-1032]-Make maker-checker mandatory
	private List<String> makerCheckerMandatoryOrgs;
	private List<String> makerCheckerExclusionGroups;
	private String enableHighcharts;
	private List<String> attachmentVerificationMandatoryOrgs; //[C153176-1026]
	private String enableCharacterEncoding; //[C153176-823]:Support for japanese language 
	private Integer highchartsReqTypeMaxLength;
	private Integer highchartsAssignedOwnerMaxLength;
	private String disableExtRecipients;
	private List<String>  qmaMailServers;
	private List<String> nlpSuggestionMandatoryGroups; //[C153176-1570]
	private Map<String, Object> nlpConfiguration;
	private String enableMakerCheckerForUnapprovedDomains; // [C153176-1549]
	private List<String> cmcConfiguration;
	private Date lastUpdatedHolidayMaster;
	private String auditEmailType;
	private String auditRelayAddr;
	private String auditRelayType;
	private String auditRelaySenderAddress;
	private String generateMISReportFromDB;
	private Long maxJobRetryCount;
	private Integer webSocketUpdateRows;
	private List<String> defaultClientCategories;
	private List<ClientCategory> clientCategories;
	private Long dashboardCountRefreshIntervalInMs;
	
	
	private boolean mailboxStatsExecutorFlag;
	
	private String applicationStatus;	//added to get application status for alerts
	
	private List<String> restrictedFileExtensions;

	private List<String> allowedFileExtensions;

	private List<String> allowedCertificateFileExtensions;

	private List<String> blockedFileNameCharacters;
	
	private List<String> custodyAccounts;

	private List<String>  allowedExtEmailDomains;
	
	//C170665-4075: PII data masking in logs and Admin UI
	private Boolean isLogMaskingEnabled;
	private Boolean isUIDataMaskingEnabled;
	private int refreshTimeMinutes;

	public StaticData()
	{
		super();
	}

	public List<Long> getBccGroupIdList()
	{
		return bccGroupIdList;
	}

	public void setBccGroupIdList(List<Long> bccGroupIdList)
	{
		this.bccGroupIdList = bccGroupIdList;
	}

	public List<String> getAdminReportEmails()
	{
		return adminReportEmails;
	}

	public void setAdminReportEmails(List<String> adminReportEmails)
	{
		this.adminReportEmails = adminReportEmails;
	}

	public Date getGroupLastModifiedTime()
	{
		return groupLastModifiedTime;
	}

	public void setGroupLastModifiedTime(Date groupLastModifiedTime)
	{
		this.groupLastModifiedTime = groupLastModifiedTime;
	}

	public int getNonInquiryAge()
	{
		return nonInquiryAge;
	}

	public void setNonInquiryAge(int nonInquiryAge)
	{
		this.nonInquiryAge = nonInquiryAge;
	}

	public int getDeletedInquiryAge()
	{
		return deletedInquiryAge;
	}

	public void setDeletedInquiryAge(int deletedInquiryAge)
	{
		this.deletedInquiryAge = deletedInquiryAge;
	}

	public List<String> getXstreamStatEmails()
	{
		return xstreamStatEmails;
	}

	public void setXstreamStatEmails(List<String> xstreamStatEmails)
	{
		this.xstreamStatEmails = xstreamStatEmails;
	}



	public String getEnableEmailBase64Encoding()
	{
		return enableEmailBase64Encoding;
	}

	public String getEnableInternalGroupEmailRouting()
	{
		return enableInternalGroupEmailRouting;
	}

	public void setEnableInternalGroupEmailRouting(String enableInternalGroupEmailRouting)
	{
		this.enableInternalGroupEmailRouting = enableInternalGroupEmailRouting;
	}

	public List<ViewConfig> getDefaultViews() {
		return defaultViews;
	}

	public void setDefaultViews(List<ViewConfig> defaultViews) {
		this.defaultViews = defaultViews;
	}

	public String getMainWebsocketListenerHost() {
		return mainWebsocketListenerHost;
	}

	public void setMainWebsocketListenerHost(String mainWebsocketListenerHost) {
		this.mainWebsocketListenerHost = mainWebsocketListenerHost;
	}

	public List<ColumnDef> getMasterColumnDef() {
		return masterColumnDef;
	}

	public void setMasterColumnDef(List<ColumnDef> masterColumnDef) {
		this.masterColumnDef = masterColumnDef;
	}

	public String getSolrDeltaImportURL() {
		return solrDeltaImportURL;
	}

	public void setSolrDeltaImportURL(String solrDeltaImportURL) {
		this.solrDeltaImportURL = solrDeltaImportURL;
	}

	public String getSolrCobDeltaImportURL() {
		return solrCobDeltaImportURL;
	}

	public void setSolrCobDeltaImportURL(String solrCobDeltaImportURL) {
		this.solrCobDeltaImportURL = solrCobDeltaImportURL;
	}

	public Long getSolrDeltaRefreshInterval() {
		return solrDeltaRefreshInterval;
	}

	public void setSolrDeltaRefreshInterval(Long solrDeltaRefreshInterval) {
		this.solrDeltaRefreshInterval = solrDeltaRefreshInterval;
	}

	public String getSolrURL() {
		return solrURL;
	}

	public void setSolrURL(String solrURL) {
		this.solrURL = solrURL;
	}

	public String getEnableGraphs() {
		return enableGraphs;
	}

	public void setEnableGraphs(String enableGraphs) {
		this.enableGraphs = enableGraphs;
	}
	public String getClipboardPaste() {
		return clipboardPaste;
	}

	public void setClipboardPaste(String clipboardPaste) {
		this.clipboardPaste = clipboardPaste;
	}

	public String getSolrSearchEnable() {
		return solrSearchEnable;
	}

	public void setSolrSearchEnable(String solrSearchEnable) {
		this.solrSearchEnable = solrSearchEnable;
	}

	public Long getTimoutMillis() {
		return timoutMillis;
	}

	public void setTimoutMillis(Long timoutMillis) {
		this.timoutMillis = timoutMillis;
	}

	public Long getSocketDataPollingInterval() {
		return socketDataPollingInterval;
	}

	public void setSocketDataPollingInterval(Long socketDataPollingInterval) {
		this.socketDataPollingInterval = socketDataPollingInterval;
	}

	public List<String> getQueryAssignedGroup() {
		return queryAssignedGroup;
	}

	public void setQueryAssignedGroup(List<String> queryAssignedGroup) {
		this.queryAssignedGroup = queryAssignedGroup;
	}
	


	
	public List<IncomingToCcDLAliasMapping> getIncomingToCcDLAliasMapping() {
		return incomingToCcDLAliasMapping;
	}

	public void setIncomingToCcDLAliasMapping(
			List<IncomingToCcDLAliasMapping> incomingToCcDLAliasMapping) {
		this.incomingToCcDLAliasMapping = incomingToCcDLAliasMapping;
	}



	public void setEnableEmailBase64Encoding(String enableEmailBase64Encoding)
	{
		this.enableEmailBase64Encoding = enableEmailBase64Encoding;
	}

	public String getEnableCustomStyleInConversation()
	{
		return enableCustomStyleInConversation;
	}

	public void setEnableCustomStyleInConversation(String enableCustomStyleInConversation)
	{
		this.enableCustomStyleInConversation = enableCustomStyleInConversation;
	}

	public List<String> getInternalGrpRoutingInclusionList()
	{
		return internalGrpRoutingInclusionList;
	}

	public void setInternalGrpRoutingInclusionList(List<String> internalGrpRoutingInclusionList)
	{
		this.internalGrpRoutingInclusionList = internalGrpRoutingInclusionList;
	}

	public List<Integer> getErrorCodeForWebsocketRestartList()
	{
		return errorCodeForWebsocketRestartList;
	}

	public void setErrorCodeForWebsocketRestartList(List<Integer> errorCodeForWebsocketRestartList)
	{
		this.errorCodeForWebsocketRestartList = errorCodeForWebsocketRestartList;
	}
	public List<String> getIgnoreEmailListForProcessing() {
		return ignoreEmailListForProcessing;
	}

	public void setIgnoreEmailListForProcessing(
			List<String> ignoreEmailListForProcessing) {
		this.ignoreEmailListForProcessing = ignoreEmailListForProcessing;
	}

	public List<String> getDisableOnBehalfOfGrpList()
	{
		return disableOnBehalfOfGrpList;
	}

	public void setDisableOnBehalfOfGrpList(List<String> disableOnBehalfOfGrpList)
	{
		this.disableOnBehalfOfGrpList = disableOnBehalfOfGrpList;
	}

	public String getEnableConvReferenceCheckAlways()
	{
		return enableConvReferenceCheckAlways;
	}

	public void setEnableConvReferenceCheckAlways(String enableConvReferenceCheckAlways)
	{
		this.enableConvReferenceCheckAlways = enableConvReferenceCheckAlways;
	}

	public List<String> getCustomStyleOverrideList()
	{
		return customStyleOverrideList;
	}

	public void setCustomStyleOverrideList(List<String> customStyleOverrideList)
	{
		this.customStyleOverrideList = customStyleOverrideList;
	}

	public String getDisableOnBehalfOf()
	{
		return disableOnBehalfOf;
	}

	public void setDisableOnBehalfOf(String disableOnBehalfOf)
	{
		this.disableOnBehalfOf = disableOnBehalfOf;
	}

	public List<String> getEnableOnBehalfOfGroupNameList() {
		return enableOnBehalfOfGroupNameList;
	}

	public void setEnableOnBehalfOfGroupNameList(List<String> enableOnBehalfOfGroupNameList) {
		this.enableOnBehalfOfGroupNameList = enableOnBehalfOfGroupNameList;
	}

	public Long getChartDataReloadMaxCounter()
	{
		return chartDataReloadMaxCounter;
	}

	public void setChartDataReloadMaxCounter(Long chartDataReloadMaxCounter)
	{
		this.chartDataReloadMaxCounter = chartDataReloadMaxCounter;
	}

	public int getChartDataRefreshInterval()
	{
		return chartDataRefreshInterval;
	}

	public void setChartDataRefreshInterval(int chartDataRefreshInterval)
	{
		this.chartDataRefreshInterval = chartDataRefreshInterval;
	}

	public String getContentTypeJpeg()
	{
		return contentTypeJpeg;
	}

	public void setContentTypeJpeg(String contentTypeJpeg)
	{
		this.contentTypeJpeg = contentTypeJpeg;
	}

	public String getPing() {
		return ping;
	}

	public void setPing(String ping) {
		this.ping = ping;
	}

	public List<String> getEditorFontStyle()
	{
		return editorFontStyle;
	}

	public void setEditorFontStyle(List<String> editorFontStyle)
	{
		this.editorFontStyle = editorFontStyle;
	}

	public List<String> getEditorFontSize()
	{
		return editorFontSize;
	}

	public void setEditorFontSize(List<String> editorFontSize)
	{
		this.editorFontSize = editorFontSize;
	}

	public String getDefaultAppFontSize()
	{
		return defaultAppFontSize;
	}

	public void setDefaultAppFontSize(String defaultAppFontSize)
	{
		this.defaultAppFontSize = defaultAppFontSize;
	}

	public String getDefaultAppFontStyle()
	{
		return defaultAppFontStyle;
	}

	public void setDefaultAppFontStyle(String defaultAppFontStyle)
	{
		this.defaultAppFontStyle = defaultAppFontStyle;
	}

	public String getDefaultDateFormate()
	{
		return defaultDateFormate;
	}

	public void setDefaultDateFormate(String defaultDateFormate)
	{
		this.defaultDateFormate = defaultDateFormate;
	}

	public List<String> getDateFormatterSelectItemList()
	{
		return dateFormatterSelectItemList;
	}

	public void setDateFormatterSelectItemList(List<String> dateFormatterSelectItemList)
	{
		this.dateFormatterSelectItemList = dateFormatterSelectItemList;
	}
	///[C153176-160] changes for saved search with work flow Criteria query
	public List<ColumnDefUI> getViewWorkFlowColumn()
	{
		return viewWorkFlowColumn;
	}

	public void setViewWorkFlowColumn(List<ColumnDefUI> viewWorkFlowColumn)
	{
		this.viewWorkFlowColumn = viewWorkFlowColumn;
	}

	public String getEnableAdvancedSolrSearch()
	{
		return enableAdvancedSolrSearch;
	}

	public void setEnableAdvancedSolrSearch(String enableAdvancedSolrSearch)
	{
		this.enableAdvancedSolrSearch = enableAdvancedSolrSearch;
	}


	public Long getBccRoutingGroup()
	{
		return bccRoutingGroup;
	}

	public void setBccRoutingGroup(Long bccRoutingGroup)
	{
		this.bccRoutingGroup = bccRoutingGroup;
	}

	//[C153176-283] - Link collaborate urls
	public List<KeyValue> getCollaborateUrls()
	{
		return collaborateUrls;
	}

	public void setCollaborateUrls(List<KeyValue> collaborateUrls)
	{
		this.collaborateUrls = collaborateUrls;
	}

	public Date getConversationCreatedBefore()
	{
		return conversationCreatedBefore;
	}

	public void setConversationCreatedBefore(Date conversationCreatedBefore)
	{
		this.conversationCreatedBefore = conversationCreatedBefore;
	}


	public Long getPubSubMonitorTimeMillis()
	{
		return pubSubMonitorTimeMillis;
	}



	public void setPubSubMonitorTimeMillis(Long pubSubMonitorTimeMillis)
	{
		this.pubSubMonitorTimeMillis = pubSubMonitorTimeMillis;
	}



	public String getPubSubMonitorEmail()
	{
		return pubSubMonitorEmail;
	}



	public void setPubSubMonitorEmail(String pubSubMonitorEmail)
	{
		this.pubSubMonitorEmail = pubSubMonitorEmail;
	}



	public String getEnablePubSubMonitor()
	{
		return enablePubSubMonitor;
	}



	public void setEnablePubSubMonitor(String enablePubSubMonitor)
	{
		this.enablePubSubMonitor = enablePubSubMonitor;
	}



	public String getEnableOptimizePubSub()
	{
		return enableOptimizePubSub;
	}


	public void setEnableOptimizePubSub(String enableOptimizePubSub)
	{
		this.enableOptimizePubSub = enableOptimizePubSub;
	}



	public int getConvLimitCount() {
		return convLimitCount;
	}



	public void setConvLimitCount(int convLimitCount) {
		this.convLimitCount = convLimitCount;
	}



	public String getCslRestServerUrl()
	{
		return cslRestServerUrl;
	}



	public void setCslRestServerUrl(String cslRestServerUrl)
	{
		this.cslRestServerUrl = cslRestServerUrl;
	}



	public List<String> getMakerCheckerMandatoryOrgs()
	{
		return makerCheckerMandatoryOrgs;
	}



	public void setMakerCheckerMandatoryOrgs(List<String> makerCheckerMandatoryOrgs)
	{
		this.makerCheckerMandatoryOrgs = makerCheckerMandatoryOrgs;
	}



	public List<String> getMakerCheckerExclusionGroups()
	{
		return makerCheckerExclusionGroups;
	}



	public void setMakerCheckerExclusionGroups(List<String> makerCheckerExclusionGroups)
	{
		this.makerCheckerExclusionGroups = makerCheckerExclusionGroups;
	}

	public String getEnableHighcharts()
	{
		return enableHighcharts;
	}
	
	public void setEnableHighcharts(String enableHighcharts)
	{
		this.enableHighcharts = enableHighcharts;
	}
	
	public List<String> getAttachmentVerificationMandatoryOrgs()
	{
		return attachmentVerificationMandatoryOrgs;
	}
	
	public void setAttachmentVerificationMandatoryOrgs(List<String> attachmentVerificationMandatoryOrgs)
	{
		this.attachmentVerificationMandatoryOrgs = attachmentVerificationMandatoryOrgs;
	}



	/**
	 * @return the enableCharacterEncoding
	 */
	public String getEnableCharacterEncoding() {
		return enableCharacterEncoding;
	}



	/**
	 * @param enableCharacterEncoding the enableCharacterEncoding to set
	 */
	public void setEnableCharacterEncoding(String enableCharacterEncoding) {
		this.enableCharacterEncoding = enableCharacterEncoding;
	}


	public Integer getHighchartsReqTypeMaxLength()
	{
		return highchartsReqTypeMaxLength;
	}



	public void setHighchartsReqTypeMaxLength(Integer highchartsReqTypeMaxLength)
	{
		this.highchartsReqTypeMaxLength = highchartsReqTypeMaxLength;
	}



	public Integer getHighchartsAssignedOwnerMaxLength()
	{
		return highchartsAssignedOwnerMaxLength;
	}



	public void setHighchartsAssignedOwnerMaxLength(Integer highchartsAssignedOwnerMaxLength)
	{
		this.highchartsAssignedOwnerMaxLength = highchartsAssignedOwnerMaxLength;
	}



	public String getDisableExtRecipients()
	{
		return disableExtRecipients;
	}



	public void setDisableExtRecipients(String disableExtRecipients)
	{
		this.disableExtRecipients = disableExtRecipients;
	}



	public List<String> getQmaMailServers()
	{
		return qmaMailServers;
	}



	public void setQmaMailServers(List<String> qmaMailServers)
	{
		this.qmaMailServers = qmaMailServers;
	}

	public String getEnableMakerCheckerForUnapprovedDomains()
	{
		return enableMakerCheckerForUnapprovedDomains;
	}


	public List<String> getNlpSuggestionMandatoryGroups(){
		return nlpSuggestionMandatoryGroups;
	}

	public void setNlpSuggestionMandatoryGroups(List<String> nlpSuggestionMandatoryGroups){
		this.nlpSuggestionMandatoryGroups = nlpSuggestionMandatoryGroups;

	}
	
	public void setEnableMakerCheckerForUnapprovedDomains(String enableMakerCheckerForUnapprovedDomains)
	{
		this.enableMakerCheckerForUnapprovedDomains = enableMakerCheckerForUnapprovedDomains;
	}

	public List<String> getCmcConfiguration() {
		return cmcConfiguration;
	}

	public void setCmcConfiguration(List<String> cmcConfiguration) {
		this.cmcConfiguration = cmcConfiguration;
	}
	
	public Date getLastUpdatedHolidayMaster() {
		return lastUpdatedHolidayMaster;
}

	public void setLastUpdatedHolidayMaster(Date lastUpdatedHolidayMaster) {
		this.lastUpdatedHolidayMaster = lastUpdatedHolidayMaster;
	}

	public String getAuditEmailType() {
		return auditEmailType;
	}

	public void setAuditEmailType(String auditEmailType) {
		this.auditEmailType = auditEmailType;
	}

	public String getAuditRelayAddr() {
		return auditRelayAddr;
	}

	public void setAuditRelayAddr(String auditRelayAddr) {
		this.auditRelayAddr = auditRelayAddr;
	}
	/**
	 * @return the generateMISReportFromDB
	 */
	public String getGenerateMISReportFromDB() {
		return generateMISReportFromDB;
	}

	/**
	 * @param generateMISReportFromDB the generateMISReportFromDB to set
	 */
	public void setGenerateMISReportFromDB(String generateMISReportFromDB) {
		this.generateMISReportFromDB = generateMISReportFromDB;
	}

	/**
	 * @return the maxJobRetryCount
	 */
	public Long getMaxJobRetryCount() {
		return maxJobRetryCount;
	}

	/**
	 * @param maxJobRetryCount the maxJobRetryCount to set
	 */
	public void setMaxJobRetryCount(Long maxJobRetryCount) {
		this.maxJobRetryCount = maxJobRetryCount;
	}
	
	public Integer getWebSocketUpdateRows() {
		return webSocketUpdateRows;
	}

	public void setWebSocketUpdateRows(Integer webSocketUpdateRows) {
		this.webSocketUpdateRows = webSocketUpdateRows;
	}

	public List<String> getDefaultClientCategories() {
		return defaultClientCategories;
	}

	public void setDefaultClientCategories(List<String> defaultClientCategories) {
		this.defaultClientCategories = defaultClientCategories;
	}

	public List<ClientCategory> getClientCategories() {
		return clientCategories;
	}

	public void setClientCategories(List<ClientCategory> clientCategories) {
		this.clientCategories = clientCategories;
	}

	/**
	 * @return the dashboardCountRefreshIntervalInMs
	 */
	public Long getDashboardCountRefreshIntervalInMs() {
		return dashboardCountRefreshIntervalInMs;
	}

	/**
	 * @param dashboardCountRefreshIntervalInMs the dashboardCountRefreshIntervalInMs to set
	 */
	public void setDashboardCountRefreshIntervalInMs(Long dashboardCountRefreshIntervalInMs) {
		this.dashboardCountRefreshIntervalInMs = dashboardCountRefreshIntervalInMs;
	}

	public boolean isMailboxStatsExecutorFlag() {
		return mailboxStatsExecutorFlag;
	}

	public void setMailboxStatsExecutorFlag(boolean mailboxStatsExecutorFlag) {
		this.mailboxStatsExecutorFlag = mailboxStatsExecutorFlag;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public List<String> getRestrictedFileExtensions() {
		return restrictedFileExtensions;
	}

	public void setRestrictedFileExtensions(List<String> restrictedFileExtensions) {
		this.restrictedFileExtensions = restrictedFileExtensions;
	}

	public List<String> getAllowedFileExtensions() {
		return allowedFileExtensions;
	}

	public void setAllowedFileExtensions(List<String> allowedFileExtensions) {
		this.allowedFileExtensions = allowedFileExtensions;
	}

	public List<String> getAllowedCertificateFileExtensions() {
		return allowedCertificateFileExtensions;
	}

	public void setAllowedCertificateFileExtensions(List<String> allowedCertificateFileExtensions) {
		this.allowedCertificateFileExtensions = allowedCertificateFileExtensions;
	}

	public List<String> getBlockedFileNameCharacters() {
		return blockedFileNameCharacters;
	}

	public void setBlockedFileNameCharacters(List<String> blockedFileNameCharacters) {
		this.blockedFileNameCharacters = blockedFileNameCharacters;
	}

	/**
	 * @return the custodyAccounts
	 */
	public List<String> getCustodyAccounts() {
		return custodyAccounts;
	}

	/**
	 * @param custodyAccounts the custodyAccounts to set
	 */
	public void setCustodyAccounts(List<String> custodyAccounts) {
		this.custodyAccounts = custodyAccounts;
	}

	public List<String> getAllowedExtEmailDomains() {
		return allowedExtEmailDomains;
	}

	public void setAllowedExtEmailDomains(List<String> allowedExtEmailDomains) {
		this.allowedExtEmailDomains = allowedExtEmailDomains;
	}

	public String getAuditRelayType() {
		return auditRelayType;
	}

	public void setAuditRelayType(String auditRelayType) {
		this.auditRelayType = auditRelayType;
	}

	public String getAuditRelaySenderAddress() {
		return auditRelaySenderAddress;
	}

	public void setAuditRelaySenderAddress(String auditRelaySenderAddress) {
		this.auditRelaySenderAddress = auditRelaySenderAddress;
	}

	public Boolean isLogMaskingEnabled() {
		return isLogMaskingEnabled;
	}

	public void setLogMaskingEnabled(Boolean isLogMaskingEnabled) {
		this.isLogMaskingEnabled = isLogMaskingEnabled;
	}

	public Boolean isUIDataMaskingEnabled() {
		return isUIDataMaskingEnabled;
	}

	public void setUIDataMaskingEnabled(Boolean isUIDataMaskingEnabled) {
		this.isUIDataMaskingEnabled = isUIDataMaskingEnabled;
	}

	public int getRefreshTimeMinutes() {
		return refreshTimeMinutes;
	}

	public void setRefreshTimeMinutes(int refreshTimeMinutes) {
		this.refreshTimeMinutes = refreshTimeMinutes;
	}
}

