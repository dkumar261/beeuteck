package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

public class MisReportConfig implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3357503827024207289L;
	private boolean enableReporting;
	private Date enableReportingFromDate;
	
	public boolean isEnableReporting() {
		return enableReporting;
	}
	public void setEnableReporting(boolean enableReporting) {
		this.enableReporting = enableReporting;
	}
	public Date getEnableReportingFromDate() {
		return enableReportingFromDate;
	}
	public void setEnableReportingFromDate(Date enableReportingFromDate) {
		this.enableReportingFromDate = enableReportingFromDate;
	}
}
