package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Entity;

@Entity(value = "UINotificationsAudit", noClassnameStored = true)
public class UINotificationsAudit extends BaseEntity
{
	private Long inquiryId;

	public UINotificationsAudit(Long inquiryId)
	{
		super();
		this.inquiryId = inquiryId;
	}
	
	public UINotificationsAudit()
	{
		super();
	}

	public Long getInquiryId() {
		return inquiryId;
	}

	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}
	
}
