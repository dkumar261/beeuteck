package com.citi.icg.qma.common.core.util.encrypt;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import org.apache.commons.io.IOUtils;

import com.citi.icg.qma.common.core.util.CryptoUtils;
import com.citi.icg.qma.common.exception.QMAException;


public final class AesEncryptionUtil {

    private static CoreConfiguration coreConfiguration = new CoreConfiguration();

     private static final String ENCRYPT_ALGO = "AES/GCM/PKCS5PADDING";
    private static final String ENCODE_INDICATOR_START = "ENC(";
    private static final int TAG_LENGTH_BIT = 128; //
    private static final int IV_LENGTH_BYTE = 8;
    private static final int SALT_LENGTH_BYTE = 16;
    private static final Charset UTF_8 = StandardCharsets.UTF_8;

    // return a base64 encoded AES encrypted text
    public static String encrypt(String plainText) {

    	fixKeyLength();
        // 16 bytes salt
        byte[] salt = CryptoUtils.getRandomNonce(SALT_LENGTH_BYTE);

        // GCM recommended 12 bytes iv?
        byte[] iv = CryptoUtils.getRandomNonce(IV_LENGTH_BYTE);

        // secret key from password
        String password = coreConfiguration.getKey();
        SecretKey aesKeyFromPassword = null;
        try {
            aesKeyFromPassword = CryptoUtils.getAESKeyFromPassword(password.toCharArray(), salt);


            Cipher cipher = Cipher.getInstance(ENCRYPT_ALGO);

            // ASE-GCM needs GCMParameterSpec
            cipher.init(Cipher.ENCRYPT_MODE, aesKeyFromPassword, new GCMParameterSpec(TAG_LENGTH_BIT, iv));

            byte[] cipherText = cipher.doFinal(plainText.getBytes());

            // prefix IV and Salt to cipher text
            byte[] cipherTextWithIvSalt = ByteBuffer.allocate(iv.length + salt.length + cipherText.length)
                    .put(iv)
                    .put(salt)
                    .put(cipherText)
                    .array();

            // string representation, base64, send this string to other for decryption.
            return java.util.Base64.getEncoder().encodeToString(cipherTextWithIvSalt);
        } catch (Exception e) {
            throw new RuntimeException("failed to encrypt text=[" + plainText
                    + "]", e);
        }
    }

    // we need the same password, salt and iv to decrypt it
    public static String decrypt(String encryptedText) {
    	
    	fixKeyLength();
        byte[] decode = Base64.getDecoder().decode(encryptedText.getBytes(UTF_8));

        // get back the iv and salt from the cipher text
        ByteBuffer bb = ByteBuffer.wrap(decode);

        byte[] iv = new byte[IV_LENGTH_BYTE];
        bb.get(iv);

        byte[] salt = new byte[SALT_LENGTH_BYTE];
        bb.get(salt);

        byte[] cipherText = new byte[bb.remaining()];
        bb.get(cipherText);

        // get back the aes key from the same password and salt
        String password = coreConfiguration.getKey();
        try {
            SecretKey aesKeyFromPassword = CryptoUtils.getAESKeyFromPassword(password.toCharArray(), salt);

            Cipher cipher = Cipher.getInstance(ENCRYPT_ALGO);

            cipher.init(Cipher.DECRYPT_MODE, aesKeyFromPassword, new GCMParameterSpec(TAG_LENGTH_BIT, iv));

            byte[] plainText = cipher.doFinal(cipherText);

            return new String(plainText, UTF_8);
        } catch (Exception e) {
            throw new RuntimeException("failed to decrypt text=["
                    + encryptedText + "]", e);
        }
    }

    public String decryptIfEncrypted(String encryptedString) {
        String decryptedString = encryptedString;

        try {
            if (encryptedString != null && encryptedString.startsWith(ENCODE_INDICATOR_START)) {
                decryptedString = encryptedString.substring(
                        ENCODE_INDICATOR_START.length(),
                        encryptedString.length() - 1);
                return decrypt(decryptedString);
            }
            return decryptedString;
        } catch (Exception ex) {
            throw new RuntimeException("failed to decrypt text", ex);
        }
    }
    
    public static void main(String args[]) {
    	
    	// fixKeyLength();
    	// String encrypted = encrypt(PRIVATE_KEY);
    	// System.out.println(encrypted);
    	// String decryptPwd = decrypt("");
    	// System.out.println(decryptPwd);
    }
    
    public static void fixKeyLength() {
        String errorString = "Failed manually overriding key-length permissions.";
        int newMaxKeyLength;
        try {
            if ((newMaxKeyLength = Cipher.getMaxAllowedKeyLength("AES")) < 256) {
                Class c = Class.forName("javax.crypto.CryptoAllPermissionCollection");
                Constructor con = c.getDeclaredConstructor();
                con.setAccessible(true);
                Object allPermissionCollection = con.newInstance();
                Field f = c.getDeclaredField("all_allowed");
                f.setAccessible(true);
                f.setBoolean(allPermissionCollection, true);

                c = Class.forName("javax.crypto.CryptoPermissions");
                con = c.getDeclaredConstructor();
                con.setAccessible(true);
                Object allPermissions = con.newInstance();
                f = c.getDeclaredField("perms");
                f.setAccessible(true);
                ((Map) f.get(allPermissions)).put("*", allPermissionCollection);

                c = Class.forName("javax.crypto.JceSecurityManager");
                f = c.getDeclaredField("defaultPolicy");
                f.setAccessible(true);
                Field mf = Field.class.getDeclaredField("modifiers");
                mf.setAccessible(true);
                mf.setInt(f, f.getModifiers() & ~Modifier.FINAL);
                f.set(null, allPermissions);

                newMaxKeyLength = Cipher.getMaxAllowedKeyLength("AES");
            }
        } catch (Exception e) {
            throw new RuntimeException(errorString, e);
        }
        if (newMaxKeyLength < 256)
            throw new RuntimeException(errorString); // hack failed
    }
}

class CoreConfiguration {

    String getKey() {
        try (InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("key.dat")) {
            StringWriter writer = new StringWriter();
            IOUtils.copy(inputStream, writer, "UTF-8");
            return writer.toString();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
