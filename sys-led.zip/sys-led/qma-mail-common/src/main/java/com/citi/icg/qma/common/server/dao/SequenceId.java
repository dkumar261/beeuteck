package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "ids", noClassnameStored = true)
public class SequenceId
{
	@Id
	private final String className;
	private final Long value = 1L;

	public SequenceId(final String name)
	{
		className = name;
	}

	protected SequenceId()
	{
		className = "";
	}

	public String getClassName()
	{
		return className;
	}

	public Long getValue()
	{
		return value;
	}
}
