package com.citi.icg.qma.common.core.util;

import java.text.SimpleDateFormat;

public final  class AppserverConstants//changes from class to interface as all psf variables....
{
	private AppserverConstants(){
		
	}

	
	public static final String ENV_PARAM_KEY = "icg.env";
	public static final String ENV_DEV = "dev";
	public static final String ENV_UAT = "uat";
	public static final String ENV_PROD = "prod";
	
	public static final String INQUIRY_DIRECTION_IN = "IN";
	public static final String CC_CATEGORY = "CC";
	public static final String STATUS_OPEN = "OPEN";
	public static final String STATUS_RESOLVE = "RESOLVED";
	public static final String ACTION_NEW = "NEW";
	public static final String ACTION_REPLY_RESOLVE = "REPLYRESOLVE";
	public static final String ACTION_REPLYALL_RESOLVE = "REPLYALLRESOLVE";
	public static final String ACTION_RESOLVE = "RESOLVE";
	public static final String ACTION_ASSIGN_TO_OWNER = "ASSIGN OWNER";
	public static final String ACTION_REOPEN = "ACTION_REOPEN";
	public static final String FILE_UPLOAD_ACTION = "FILE UPLOAD ACTION";
	public static final String CREATE_NEW_INQUIRY = "CREATE NEW INQUIRY ";
	public static final String MARK_AS_UNREAD = "MARK AS UNREAD ";
	public static final String MARK_AS_READ = "MARK AS READ ";
	public static final String RESOLVE_INQUIRY = "RESOLVE INQUIRY ";
	public static final String REOPEN_INQUIRY = "REOPEN INQUIRY ";
	public static final String ASSIGN_TO_USER = "ASSIGN TO USER";
	public static final String ASSIGN_TO_FOLDER = "ASSIGN TO FOLDER";
	public static final String ASSIGN_TO_TAG = "ASSIGN TO TAG";
	public static final String ASSIGN_REQUEST_TYPE = "ASSIGH REQUEST TYPE";
	public static final String ASSIGN_ROOT_CAUSE = "ASSIGH ROOT CAUSE";
	public static final String ADD_NOTE = "ADD NOTE";
	public static final String CREATE_VIEW = "SAVE USER VIEW";
	public static final String DELETE_VIEW = "USER DELETED A VIEW";
	public static final String OPEN_VIEW = "OPEN USER VIEW";
	public static final String SAVE_TOP_CONTACTS = "SAVE TOP CONTACTS";
	public static final String USER_LOG_IN_INFO = "LOGIN USER DETAIL";
	public static final String SAVE_FOLDER = "CREATE NEW FOLDER";
	public static final String GET_MENU_ITEM = "GET MENU ITEM FOR GRID ";
	public static final String SAVE_SIGNATURE = "SAVE SIGNATURE";
	public static final String INQUIRY_CONVERSATION = "Iquiry Conversation Detail";
	public static final String SAVE_USER_DEATIL = "Save User Profile Preference ";
	public static final String DELETE_FOLDER = "DELETE FOLDER";
	public static final String USER_TEMPLATE_DELETE = "USER_TEMPLATE_DELETE";
	public static final String USER_TEMPLATE_SAVE = "USER_TEMPLATE_SAVE";
	public static final String ATTACH_UPLOAD = "UPLOAD ATTACHMENT";
	public static final String ASSIGN_TO_SELF = "SELF ASSIGN";
	public static final String USER_DEFBOXCOLS_SAVE = "USER_DEFBOXCOLS_SAVE";
	public static final String CREATE_NEW_DRAFT = "CREATE NEW DRAFT ";
	public static final String DELETE_DRAFT = "USER DELETED A DRAFT";
	public static final String EDIT_FOLDER = "EDIT FOLDER";
	public static final String STRING_YES = "Y";
	public static final String LINK_INQUIRY = "Link Inquiry";
	public static final String DELINK_INQUIRY = "De-link Inquiry";
	//Changes to save User's Editor Style Preferences
	public static final String USER_FONT_NAME_PREF = "editorFontNameId";
	public static final String USER_FONT_SIZE_PREF = "editorFontSizeId";
	//[C153176-169] - Server-side export of inquiries
	public static final String INBOX = "Inbox";
	public static final String OUTBOX = "Outbox";
	public static final String RESOLVEDBOX = "Resolved";
	public static final String PENDINGAPPROVAL = "Pending Approval";
	public static final String ASSIGN_PROCESSING_REGION = "ASSIGN PROCESSING REGION";
	public static final String ASSIGN_INQUIRY_SOURCE = "ASSIGN INQUIRY SOURCE";
	public static final String ASSIGN_GFPID_GFCID = "ASSIGN GFPID/GFCID";
	public static final String ESCALATION_CRITERIA_CONFIG_ID = "EscalationCriteria";
	public static final String GROUP_CONFIG_ID = "Group";
	public static final String ELEMENT_MATCH ="$elemMatch";
	public static final String STRING_NO = "N";
	public static final String ACTION_TIME = "actionTime";
	public static final String TO_CATEGARY = "TO";
	public static final String PROFILE_PIC = "profilePicUpload";
	public static final String ESC_KEYWORD = "escKeywords";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String MANUAL_ESC_REASON = "Escalated Manually for : ";
	public static final String RECIPENT_FROM_KEY = "FROM";
	public static final String DEFAULT_IMAGE = "images/User_Gray.png";
	protected static final String[] VALID_CITI_EMAIL_DOMAINS = {"XXXX.com","XXXX.com","XXXX.com","XXXX.com","XXXX.com","XXXX.com"}; //<-- sonar fix made protected
	public static final String N_A = "Not Available";
	public static final String ACTION_UNASSIGN_OWNER = "Unassign Owner";
	public static final String ACTION_UNASSIGN_PROCESSING_REGION = "Unassign Processing Region";
	public static final String ACTION_UNASSIGN_TAG = "Unassign Tag";
	public static final String BLANK_STRING = "";
	public static final String SUCCESS_KEY = "success";
	public static final String MESSAGE_KEY = "message";
	public static final String REFRESH_TYPE = "refreshType";
	public static final String SERVICE_FAILURE_MESSAGE = "Service failed !";
	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
	public static final String INQUIRY_ID_KEY = "inquiryId";
	public static final String SUGGESTION_ACCEPT_ACTION = "accept";
	public static final String SUGGESTION_DECLINE_ACTION = "decline";
	public static final String SUGGESTION_DECLINED_DESC = "Suggestion Declined";
	public static final String SUGGESTION_STATUS_SENT = "Sent";
	public static final String SUGGESTION_STATUS_NOT_SENT = "Not Sent";
	public static final String MONGO_PK = "_id";
	//[C153176-1121]Ability to link inquiry to exception from QMA
	public static final String LINK_EXCEPTION = "Link Exception";
	public static final String UPDATEMEMO = "Update Memo";
	public static final String VERSION = "version";
	// [C153176-1694] - Acknowledge Escalation 
	public static final String ACKNOWLEDGE_ESCALATION = "ACKNOWLEDGE ESCALATION";
	public static final String CREATED_DATE = "crtDate";
	public static final String MONGO_UTC_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
	public static final String VALIDATE_DATE_EXMPL = "e.g: 2019-02-27T11:03:21.486";
	public static final String DATE_FORMAT_MM_DD_YYYY = "MM-dd-yyyy";
	public static final String DS_MAIL_BOX_STATS_KEY = "mailBoxStats";
	public static final String DS_MY_COVERSAGE_KEY ="myCoversage";
	public static final String DS_MESSAGES ="messages";
	public static final String DS_MY_VIEWS ="myViews";
	public static final String DS_MY_ASSIGNED_GROUPS ="assignedGroups";
	
	// C153176-5354 : Time Difference and Time Units
	public static final String TIME_DIFF = "timeDiff";
	public static final String TIME_UNIT_MINS = "minutes";
	public static final String TIME_UNIT_HRS = "hours";
	public static final String TIME_UNIT_DAYS = "days";
	
	// C153176-5849 | Email as chat feature adoption audit information
	public static final String VIEW_TYPE = "viewType";
	public static final String VIEW_NAME = "viewName";
	
	public static final String DELETE_EWS_MAIL = "USER DELETED PERSONAL MAIL";
	
	public static final String FUNCTION_CONTACT_SEARCH_CMC = "Contact Search CMC";
	public static final String MODULE_NEW_MESSAGE = "New Message";
	public static final String FUNCTION_CONTACT_SEARCH_CIMS = "Contact Search CIMS";
	public static final String FUNCTION_GFPID_GFCID_SEARCH = "GFPID/GFCID Search";
	public static final String FUNCTION_UPLOAD_ATTACHMENT = "Upload Attachment";
	public static final String FUNCTION_CONTACT_FAVORITE = "Favourites Contact";
	public static final String FUNCTION_CLC_CONFIG_UI = "CLC Config";
	public static final String FUNCTION_CLC_SEARCH = "CLC Search";
	public static final String FUNCTION_SAVE_DRAFT = "Save Draft";
	public static final String FUNCTION_SEND_INQUIRY = "Send Inquiry";
	public static final String FUNCTION_OPEN_INQUIRIES_BY_ASSIGNED_GROUP = "Open Inquiries by Assigned Group";
	public static final String FUNCTION_INQUIRY_TREND_CHART = "Inquiry Trend Chart";
	public static final String FUNCTION_DASHBOARD_SETTINGS = "Dashboard Settings";
	public static final String FUNCTION_DASHBOARD_SETTING_SAVE = "Save Dashboard Settings";
	public static final String FUNCTION_SAVE_USER_PROFILE = "Save User Profile";
	public static final String MODULE_DASHBOARD = "Dashboard";
	public static final String FUNCTION_GROUP_ADMIN = "Group Admin";
	public static final String FUNCTION_GROUP_ADMIN_SAVE = "Save Group";
	public static final String FUNCTION_GROUP_SETUP = "Group Setup";
	public static final String FUNCTION_USER_ADMIN = "User Admin";
	public static final String FUNCTION_USER_ADMIN_SAVE = "Save User";
	public static final String FUNCTION_SEND_NOTIFICATION = "Send Notification";
	public static final String FUNCTION_GET_ADMIN_DB_COLLECTION = "Get Admin DB Collection";
	public static final String FUNCTION_MAILBOX_ONBOARDING = "Mailbox Onboarding";
	public static final String FUNCTION_USER_GROUP_ASSIGNMENT = "User Group Assignment";
	public static final String FUNCTION_LOGOUT = "LOGOUT";
	//C170665-185 for hard code data point
	public static final String SAVE_ORG_ADMIN_DETAIL = "SAVE ORG ADMIN DETAIL";
	public static final String ASSIGN_INQUIRY_SUB_STATUS = "ASSIGN INQUIRY SUB-STATUS";
	
	public static final String MONGODB = "mongodb";
	public static final String MONGODB_SRV = "mongodb+srv";
}
