
package com.citi.icg.qma.common.server.dao.persistence;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import dev.morphia.Datastore;
import dev.morphia.Morphia;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.MailCommonUtil;
import com.citi.icg.qma.common.server.dao.BaseEntity;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.MongoClientURI;
import com.mongodb.ReadPreference;
import com.mongodb.WriteConcern;


/**
 * MongoDB providing the database connection.
 */
public class MongoDBReadSecondaryConnection
{
	//private static final Logger logger = Logger.getLogger(MongoDBReadSecondaryConnection.class.getName());
	private static Logger logger = LoggerFactory.getLogger(MongoDBReadSecondaryConnection.class);

	private static String DB_NAME = null;

	private static MongoDBReadSecondaryConnection INSTANCE = null;

	private static Datastore datastore;

	private static MongoClient mongoClient;

	private MongoDBReadSecondaryConnection()
	{
		InputStream inputStream = null;
		// TODO: IZ - Not seeing how to setup these parameters with MongoClientURI // (SUNIL: IMPLEMENTED ON 30TH OCT.)
		// MongoClientOptions mongoOptions = MongoClientOptions.builder().socketTimeout(60000)
		// .connectTimeout(1200000).build(); // SocketTimeout: 60s, ConnectionTimeout: 20min
		Builder builder = MongoClientOptions.builder();
		builder.socketTimeout(1600000);
		builder.connectTimeout(1200000);
		builder.writeConcern(WriteConcern.W1);
		try
		{

			String xmcEnvironment = System.getProperty("icg.env");
			String propFile = "db-" + xmcEnvironment + ".properties";
			logger.info(" Loading properties for " + xmcEnvironment + "file name is" + propFile);
			inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(propFile);
			Properties prop = new Properties();

			prop.load(inputStream);
			MongoDBReadSecondaryConnection.setDB_NAME(prop.getProperty("dbName"));
			String userName = prop.getProperty("userName");
			String pwdEnc = prop.getProperty("password");
			String pwdIVEnc = prop.getProperty("passwordIV");
			String password = MailCommonUtil.getDecryptedPassword(prop);
			String clusterServers = prop.getProperty("mongoCluster");
			logger.info("Connecting to " + DB_NAME + " db, at " + clusterServers);
			MongoClientURI mcURI = new MongoClientURI("mongodb://" + userName + ":" + password + "@" + clusterServers, builder);
			mongoClient = new MongoClient(mcURI);
			//mongoClient.setWriteConcern(WriteConcern.SAFE);
			//mongoClient.setReadPreference(ReadPreference.secondaryPreferred());

			Morphia morphia = new Morphia().mapPackage(BaseEntity.class.getPackage().getName());
			datastore = morphia.createDatastore(mongoClient, DB_NAME);
			BaseEntity.setMongoDatastore(datastore);

			// datastore.ensureIndexes(); //TODO: IZ - not sure if this should be here as it may take long time to startup tomcat.
			// i do not think we are specifing indexes in Entities anyways.
			// datastore.ensureCaps();

			logger.info("Connection to database '" + DB_NAME + "' initialized");
		}
		//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
		catch (IOException e)
		{
			logger.error(e.getMessage());
			throw new RuntimeException("Error initializing MongoDBReadSecondaryConnection", e);
		}
		finally
		{
			if (inputStream != null)
			{
				try
				{
					inputStream.close();
				}
				//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
				catch (IOException e)
				{
					//Sonar Fix -- Either log or rethrow this exception 
					logger.error("In MongoDBReadSecondaryConnection.....Error in closing inputStream", e);
				}
			}
		}

	}

	// Creating the mongo connection is expensive - we used a singleton for performance reasons
	// Both the underlying Java driver and Datastore are thread safe
	public static synchronized MongoDBReadSecondaryConnection instance()//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
	{
		if (INSTANCE == null) {
			INSTANCE = new MongoDBReadSecondaryConnection();

		}
		return INSTANCE;
	}

	// Use datastore for Morphia operations
	public Datastore getDataStore()
	{
		return datastore;
	}

	// get the DB for Mongo-JavaDriver operations.
	public DB getDB()
	{
		return mongoClient.getDB(DB_NAME);
	}
	
	
	public void closeDB()
	{
		try
		{
			if (mongoClient != null)
			{
				logger.info("Start Closing MongoClient Connections");
				
				mongoClient.close();
				INSTANCE = null;
				datastore = null;
				
				logger.info("End Closing MongoClient Connections");

			}
		}
		catch (Exception e)
		{
			logger.error("Issue in closing MongoClient Connection "+e);

		}
	}

	public static String getDB_NAME() {
		return DB_NAME;
	}

	public static void setDB_NAME(String dB_NAME) {
		DB_NAME = dB_NAME;
	}
}
