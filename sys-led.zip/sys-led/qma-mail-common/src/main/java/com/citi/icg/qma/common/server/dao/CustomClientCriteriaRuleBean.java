package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

public class CustomClientCriteriaRuleBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6820184361625604072L;
	private Long groupId;
	private String groupName;
	private String groupEmail;
	private String from;
	private String fromOperator;
		// Enhance inquiry rules to include the TO field.
	private String to;
	private String toOperator;
	private String subject;
	private String subjectOperator;
	private String categoryName;
	private String colorCode;
	
	public CustomClientCriteriaRuleBean() {
		super();
	}
	
	public CustomClientCriteriaRuleBean(Long groupId, String groupName, String groupEmail, String from,
			String fromOperator, String to, String toOperator, String subject, String subjectOperator,
			String categoryName, String colorCode) {
		super();
		this.groupId = groupId;
		this.groupName = groupName;
		this.groupEmail = groupEmail;
		this.from = from;
		this.fromOperator = fromOperator;
		this.to = to;
		this.toOperator = toOperator;
		this.subject = subject;
		this.subjectOperator = subjectOperator;
		this.categoryName = categoryName;
		this.colorCode = colorCode;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupEmail() {
		return groupEmail;
	}

	public void setGroupEmail(String groupEmail) {
		this.groupEmail = groupEmail;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getFromOperator() {
		return fromOperator;
	}

	public void setFromOperator(String fromOperator) {
		this.fromOperator = fromOperator;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getToOperator() {
		return toOperator;
	}

	public void setToOperator(String toOperator) {
		this.toOperator = toOperator;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getSubjectOperator() {
		return subjectOperator;
	}

	public void setSubjectOperator(String subjectOperator) {
		this.subjectOperator = subjectOperator;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getColorCode() {
		return colorCode;
	}

	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}
	
}
