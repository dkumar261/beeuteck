package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.List;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

import com.google.gson.annotations.SerializedName;

@Entity(value = "ManagementHeirarchy", noClassnameStored = true)
public class ManagementHeirarchy implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8834780301319072176L;
	//This is kind of a static collection used by BAs to add and update heirarchy data. Every group falls into some heirarchy identified by this class. 
	
	@Id
	@SerializedName("_id")
	private Long id;
	private List<String> organisation;
	private List<HierarchyUserDetail> firstLevelHeirarchy;
	private List<HierarchyUserDetail> secondLevelHeirarchy;
	private List<HierarchyUserDetail> thirdLevelHeirarchy;
	private List<String> gfcid;
	private List<com.citi.icg.qma.common.server.dao.HierarchyOrgDetails> orgHierarchy;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public List<String> getOrganisation() {
		return organisation;
	}
	public void setOrganisation(List<String> organisation) {
		this.organisation = organisation;
	}
	public List<HierarchyUserDetail> getFirstLevelHeirarchy() {
		return firstLevelHeirarchy;
	}
	public void setFirstLevelHeirarchy(List<HierarchyUserDetail> firstLevelHeirarchy) {
		this.firstLevelHeirarchy = firstLevelHeirarchy;
	}
	public List<HierarchyUserDetail> getSecondLevelHeirarchy() {
		return secondLevelHeirarchy;
	}
	public void setSecondLevelHeirarchy(List<HierarchyUserDetail> secondLevelHeirarchy) {
		this.secondLevelHeirarchy = secondLevelHeirarchy;
	}
	public List<HierarchyUserDetail> getThirdLevelHeirarchy() {
		return thirdLevelHeirarchy;
	}
	public void setThirdLevelHeirarchy(List<HierarchyUserDetail> thirdLevelHeirarchy) {
		this.thirdLevelHeirarchy = thirdLevelHeirarchy;
	}
	public List<String> getGfcid() {
		return gfcid;
	}
	public void setGfcid(List<String> gfcid) {
		this.gfcid = gfcid;
	}
	public List<com.citi.icg.qma.common.server.dao.HierarchyOrgDetails> getOrgHierarchy() {
		return orgHierarchy;
	}
	public void setOrgHierarchy(List<com.citi.icg.qma.common.server.dao.HierarchyOrgDetails> orgHierarchy) {
		this.orgHierarchy = orgHierarchy;
	}
	public static class HierarchyOrgDetails {

		private String level;
		private String orgName;
		
		public String getLevel() {
			return level;
		}
		public void setLevel(String level) {
			this.level = level;
		}
		public String getOrgName() {
			return orgName;
		}
		public void setOrgName(String orgName) {
			this.orgName = orgName;
		}
	}
	
}
