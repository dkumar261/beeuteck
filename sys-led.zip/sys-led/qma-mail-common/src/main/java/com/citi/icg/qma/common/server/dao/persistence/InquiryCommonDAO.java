package com.citi.icg.qma.common.server.dao.persistence;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;

import com.mongodb.*;
import dev.morphia.Datastore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.core.util.MailCommonUtil;
import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.GroupRole;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.UINotifications;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.common.transferobject.ConversationTO;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

import dev.morphia.Morphia;
import dev.morphia.mapping.Mapper;
import dev.morphia.query.Query;

public class InquiryCommonDAO extends MongoMorphiaDAO
{
	
	private static final Logger logger = LoggerFactory.getLogger(InquiryCommonDAO.class);

	public InquiryCommonDAO() {}

	public InquiryCommonDAO(Datastore datastore) {
		super(datastore);
	}

	//	private CacheDAO cacheDAO = CacheDAO.getInstance();
	// Method to get only one conversation by conversation id
	public ConversationTO getInquiryConversationById(Long conversationId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a																												// generic one
	{
		Query<Conversation> query;
		List<Conversation> convList = new ArrayList<>();
		if (conversationId == null)
		{
			logger.error("Invalid input getInquiryConversationById for InquconversationIdiryId= " + conversationId);
			throw new CommunicatorException("Invalid input getInquiryConversationById for conversationId= " + conversationId);
		}
		try
		{
			query = mongoDatastore.createQuery(Conversation.class);
			query.criteria("_id").equal(conversationId);
			query.useReadPreference(ReadPreference.secondary());

			Conversation conversation = query.get();
			if (null != conversation)
			{
				conversation.setContent(MailCommonUtil.replaceBaseTag(GenericUtility.checkAndFetchConvContent(conversation)));
				convList.add(conversation);
			}
			// Only conversation details required hence creating conversationTO by only passing conversation list.
			ConversationTO conversationTO = new ConversationTO(convList, null);
			return conversationTO;
		}
		catch (Exception e)
		{
			logger.error("Exception in getInquiryConversationById for ConversationId= " + conversationId, e);
			throw new CommunicatorException("Exception in getInquiryConversationById for ConversationId= " + conversationId, e);
		}
	}
	
	public Inquiry getInquiryById(Long inquiryId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		return mongoDatastore.get(Inquiry.class, inquiryId);
	}
	
	public List<Inquiry> getInquiryById(Set<Long> inquiryIds) {		
		Query<Inquiry> q = this.mongoDatastore.find(Inquiry.class);
		q.field("_id").in(inquiryIds);		
		q.order("_id");
		List<Inquiry> list = q.asList();
		return list;
	}
	
	public void saveInquiriesToPublish(List<Long> inquiryIds, String userAction, String userId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a
	// generic one
	{
		Morphia morphia = new Morphia();
		Mapper mapper = morphia.getMapper();
		List<DBObject> uiNotificationsDBObjectList = new ArrayList<DBObject>();
		DBCollection uiNotificationCollection = mongoDatastore.getCollection(UINotifications.class);

		extractDBCollection(uiNotificationCollection);

		for (int indx = 0; indx < inquiryIds.size(); indx++)
		{
			Long id = inquiryIds.get(indx);
			UINotifications uiNotifications = saveInquiryToPublishInBulk(id, userAction, userId);

			uiNotificationsDBObjectList.add(mapper.toDBObject(uiNotifications));

		}
		uiNotificationCollection.insert(uiNotificationsDBObjectList, WriteConcern.ACKNOWLEDGED);
	}
	
// This saves the inquiries into the collection UINotifications to publish
	public void saveInquiryToPublish(Long inquiryId, String userAction, String userId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic
	{
		try
		{
			DBCollection uiNotificationCollection = mongoDatastore.getCollection(UINotifications.class);
			extractDBCollection(uiNotificationCollection);
			UINotifications uiNotification = saveInquiryToPublishInBulk(inquiryId, userAction, userId);
			mongoDatastore.save(uiNotification);
		}
		catch (Exception e)
		{
			logger.error("Exception in getInquiriesToPublish", e);
			throw new CommunicatorException("Exception in getInquiriesToPublish", e);
		}
	}
		
	// create new method because above method is used for other action also.
	private UINotifications saveInquiryToPublishInBulk(Long inquiryId, String userAction, String userId) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of
	// using a generic one
	{
		UINotifications inquiryWebsocketData = null;
		try
		{
			inquiryWebsocketData = new UINotifications();

			inquiryWebsocketData.setInquiryId(inquiryId);
			inquiryWebsocketData.setAction(userAction);
			inquiryWebsocketData.setProcessFlag("N");
			inquiryWebsocketData.setCrtBy(userId);
			inquiryWebsocketData.setModBy(userId);
			inquiryWebsocketData.setModDate(new Date());
			return inquiryWebsocketData;
		}
		catch (Exception e)
		{
			logger.error("Exception in getInquiriesToPublish", e);
			throw new CommunicatorException("Exception in getInquiriesToPublish", e);
		}
	}

	
	/**
	 * @description: method used to fetch all conversation as per input parameters
	 * @param request
	 * @return response
	 */
	public BasicDBObject getChaserConversation(String request) throws CommunicatorException{
		BasicDBObject response = new BasicDBObject();
		long startTime = System.currentTimeMillis();
		BasicDBObject requestObj = BasicDBObject.parse(request);
		Long inquiryId = GenericUtility.getIdFromRequest(requestObj, AppserverConstants.INQUIRY_ID_KEY);
		if (null != inquiryId) {
			Date date = null;
			Long conversationId = null;
			if (null != requestObj.getString(AppserverConstants.CREATED_DATE)) {
				String crtDateStr = requestObj.getString(AppserverConstants.CREATED_DATE);
				date = getParsedDate(crtDateStr);
			}
			if(null != GenericUtility.getIdFromRequest(requestObj, "conversationId")){
				 conversationId = GenericUtility.getIdFromRequest(requestObj, "conversationId");
			}
			boolean isValid = getValidConversation(inquiryId, date, conversationId);
			if (isValid) {
				response.put(AppserverConstants.SUCCESS_KEY, isValid);
			} else {
				response.put(AppserverConstants.SUCCESS_KEY, isValid);
				response.put(AppserverConstants.MESSAGE_KEY, "No chaser data found");
			}
		}
		long estimatedTime = System.currentTimeMillis() - startTime;
		logger.info("Total time to fetch valid chaser (millis):"+estimatedTime);
		return response;
	}


	/**
	 * @description: method used to format date
	 * @param crtDateStr
	 * @return
	 */
	private Date getParsedDate(String crtDateStr) {
		Date date = null;
		try{
			SimpleDateFormat sDateFormat = new SimpleDateFormat(AppserverConstants.MONGO_UTC_FORMAT);
			sDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
			date = sDateFormat.parse(crtDateStr);
		}catch(ParseException e)
		{
			logger.error("Date parsing issue" +e);
		}
		return date;
	}

	/**
	 * @description: method used to fetch all valid conversation by date or by convId
	 * @param inquiryId
	 * @param crtDate
	 * @param convId
	 * @return
	 * @throws CommunicatorException
	 */
	private boolean getValidConversation(Long inquiryId, Date crtDate, Long convId) throws CommunicatorException {
		boolean isValid;
		if (inquiryId != null && convId != null ||  crtDate != null) {
			isValid = fetchConversationByInput(inquiryId, convId, crtDate);
		} else{
			isValid = fetchConversationByInquiryId(inquiryId);
		}
		return isValid;
	}
	
	private boolean fetchConversationByInquiryId(Long inquiryId) throws CommunicatorException {
		List<Conversation> conversationList = getConversationFromDB(inquiryId, null, null);
		List<ConversationRecipient> initialRecipientsList = new ArrayList<>();
		List<ConversationRecipient> chaserFromRecipientsList = new ArrayList<>();
		for(Conversation conversation : conversationList){
			if("New Inquiry".equals(conversation.getAction())){
				initialRecipientsList.addAll(conversation.getRecipients());
			}
			else{
				if(null == conversation.getAudFlag()){
					chaserFromRecipientsList.addAll(conversation.getRecipients());
				}
			}
		}
		
		return getChaser(chaserFromRecipientsList, initialRecipientsList);
		
	}

	/**
	 * @description: method used to fetch all valid conversation after date or by convId
	 * @param inquiryId
	 * @param convId
	 * @param crtDate
	 * @return
	 * @throws CommunicatorException
	 */
	private boolean fetchConversationByInput(Long inquiryId, Long convId, Date crtDate) throws CommunicatorException {
		List<Conversation> conversationList = getConversationFromDB(inquiryId, convId, crtDate);
		List<ConversationRecipient> initialRecipientsList = new ArrayList<>();
		List<ConversationRecipient> chaserFromRecipientsList = new ArrayList<>();
		
		for (Conversation conv : conversationList) {
			
				String formmattedDate;
				SimpleDateFormat sDateFormat = new SimpleDateFormat(AppserverConstants.MONGO_UTC_FORMAT);
				sDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
				formmattedDate = sDateFormat.format(conv.getCrtDate());
				Date initialConvDate = getParsedDate(formmattedDate);
				if(initialConvDate.equals(crtDate) || conv.getId().equals(convId))
				{
					initialRecipientsList.addAll(conv.getRecipients());
				}else{
					if(null == conv.getAudFlag()){
						chaserFromRecipientsList.addAll(conv.getRecipients());
					}
				}
			}
		
		
		return getChaser(chaserFromRecipientsList, initialRecipientsList);
	}

	/**
	 * @description: method used to get chaser
	 * @param chaserFromRecipientsList
	 * @param initialToRecipientsList
	 * @return
	 */
	private boolean getChaser(List<ConversationRecipient> chaserFromRecipientsList, List<ConversationRecipient> initialToRecipientsList) {
		boolean isFound = false;
		for (ConversationRecipient chaserFromRecpientObj : chaserFromRecipientsList) {
			if (chaserFromRecpientObj.getToFrom().equals(AppserverConstants.RECIPENT_FROM_KEY)) {
					isFound = compareChaser(initialToRecipientsList,chaserFromRecpientObj);
				}
			if (isFound)
				break;
			}			
		return isFound;
	}
	/**
	 * @description: method used to get chaser by comparing display name
	 * @param initialToRecipientsList
	 * @param chaserFromRecpientObj
	 * @return
	 */
	private boolean compareChaser(List<ConversationRecipient> initialToRecipientsList, ConversationRecipient chaserFromRecpientObj) {
		boolean isFound = false;
		for (ConversationRecipient initialToRecipients : initialToRecipientsList) {
			
			if (AppserverConstants.TO_CATEGARY.equalsIgnoreCase(initialToRecipients.getToFrom()) || AppserverConstants.CC_CATEGORY.equalsIgnoreCase(initialToRecipients.getToFrom())) {
				
				boolean detailedComparision = getDeatiledComparision(initialToRecipients,chaserFromRecpientObj);
				if (detailedComparision) {
					logger.info("Chaser conversation found for display name:" + initialToRecipients.getDisplayName());
					isFound = true;
					break;
				}
			}
		}
		return isFound;
	}

	/**
	 * This compares possible chaser
	 * @param initialToRecipients
	 * @param chaserFromRecpientObj
	 * @return
	 */
	private boolean getDeatiledComparision(ConversationRecipient initialToRecipients, ConversationRecipient chaserFromRecpientObj) {
		//compare emailId
		boolean compreEmail = initialToRecipients.getEmailAddr() != null && chaserFromRecpientObj.getEmailAddr() != null 
				&& initialToRecipients.getEmailAddr().equalsIgnoreCase(chaserFromRecpientObj.getEmailAddr());
		//Compare display name
		boolean compareDisplayName = initialToRecipients.getDisplayName().equalsIgnoreCase(chaserFromRecpientObj.getDisplayName())
				|| (null != initialToRecipients.getGroupId() && null != chaserFromRecpientObj.getGroupId() 
				&& chaserFromRecpientObj.getGroupId().equals(initialToRecipients.getGroupId())); 
		//compare reply from DL member
		boolean compareReplyFromDLMember = checkRepliedByDLMember(initialToRecipients, chaserFromRecpientObj);
		
		return compareDisplayName || compreEmail || compareReplyFromDLMember;
		
	}

	/**
	 * This method checks whether replied by one of the DL member
	 * @param initialToRecipients
	 * @param chaserFromRecpientObj
	 * @return
	 */
	private boolean checkRepliedByDLMember(ConversationRecipient initialToRecipients, ConversationRecipient chaserFromRecpientObj) {
		boolean isFound = false;
		if (null != chaserFromRecpientObj.getEmailAddr()) {
			isFound = checkIfChaserEmailPresent(initialToRecipients, chaserFromRecpientObj);
		}else if (null != chaserFromRecpientObj.getDisplayName()){
			isFound = checkIfOnlyDisplay(initialToRecipients, chaserFromRecpientObj);
		}	
		return isFound;	
	}

	/**
	 * This method check chaser if only display present in conversation recipient
	 * @param initialToRecipients
	 * @param chaserFromRecpientObj
	 * @return
	 */
	private boolean checkIfOnlyDisplay(ConversationRecipient initialToRecipients,
			ConversationRecipient chaserFromRecpientObj) {
		boolean isFound = false;
		QMACache qmaCache = QMACacheFactory.getCache();
		Long groupId = qmaCache.getGroupCodeToIdMap().get(chaserFromRecpientObj.getDisplayName().toUpperCase());
		List<String> userList = qmaCache.getGroupIdToUserListMap().get(groupId);
		Map<String, User> userMap = qmaCache.getUserInfoMap();
		for (Entry<String, User> userEntry : userMap.entrySet()) {
			User user = userEntry.getValue();
			String userEmail = null;
			if (null != user.getEmail()) {
				String[] userMailSplit = user.getEmail().split("@");
				userEmail = userMailSplit[0];
			}
			if (null != userEmail && initialToRecipients.getEmailAddr().toUpperCase().startsWith(userEmail.toUpperCase())
					|| initialToRecipients.getEmailAddr().toUpperCase().startsWith(user.getId().toUpperCase())) {

				if (userList.contains(user.getId())) {
					isFound = true;
					break;
				} else {
					isFound = false;
				}

			}
		}
		return isFound;
	}
	/**
	 * This method check chaser if email present in conversation recipient
	 * @param initialToRecipients
	 * @param chaserFromRecpientObj
	 * @return
	 */
	private boolean checkIfChaserEmailPresent(ConversationRecipient initialToRecipients, ConversationRecipient chaserFromRecpientObj) {
		boolean isFound = false;
		//CacheDAO cacheDAO = CacheDAO.getInstance();
		Map<String, User> userMap = QMACacheFactory.getCache().getUserInfoMap();
		for (Entry<String, User> userEntry : userMap.entrySet()) {
			User user = userEntry.getValue();
			if (null != user.getEmail() && (user.getEmail().equalsIgnoreCase(chaserFromRecpientObj.getEmailAddr()) || 
					chaserFromRecpientObj.getEmailAddr().toUpperCase().startsWith(user.getId().toUpperCase()))) {
				List<GroupRole> groupRoles = user.getGroupRoles();
				for (GroupRole role : groupRoles) {
					if (null != initialToRecipients.getGroupId() && initialToRecipients.getGroupId().equals(role.getGroupId())) {
						isFound = true;
						break;
					} else {
						isFound = false;
					}
				}
				if(isFound)
					break;
			}
			
		}
		return isFound;
	}

	/**
	 * @description: method used to fetch conversation from DB by input parameter
	 * @param inquiryId
	 * @param convId
	 * @param crtDate
	 * @return
	 * @throws CommunicatorException
	 */
	private List<Conversation> getConversationFromDB(Long inquiryId, Long convId, Date crtDate) throws CommunicatorException {
		Query<Conversation> query;
		query = mongoDatastore.createQuery(Conversation.class);
		query.criteria(AppserverConstants.INQUIRY_ID_KEY).equal(inquiryId);
		if (convId != null)
		{
			query.criteria(AppserverConstants.MONGO_PK).greaterThanOrEq(convId);
		}else if (crtDate != null)
		{
			query.criteria(AppserverConstants.CREATED_DATE).greaterThanOrEq(crtDate);
		}
		query.order("_id");
		return query.asList();
	}
	
}