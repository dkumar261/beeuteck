package com.citi.icg.qma.common.transferobject;

public class MISExclusionReportTO
{
	private String reportName;
	private boolean active;

	public MISExclusionReportTO(String reportName, boolean active)
	{
		super();
		this.reportName = reportName;
		this.active = active;
	}

	public String getReportName()
	{
		return reportName;
	}

	public void setReportName(String reportName)
	{
		this.reportName = reportName;
	}

	public boolean isActive()
	{
		return active;
	}

	public void setActive(boolean active)
	{
		this.active = active;
	}
}
