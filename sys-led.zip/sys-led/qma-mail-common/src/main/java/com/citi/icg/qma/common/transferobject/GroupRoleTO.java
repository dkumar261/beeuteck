package com.citi.icg.qma.common.transferobject;

import java.io.Serializable;


public class GroupRoleTO implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4017037846915101128L;
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private String groupName;
	private String groupRole;
	private Long groupId;

	public GroupRoleTO()
	{

	}

	public GroupRoleTO(String groupName, String groupRole)
	{
		super();
		this.groupName = groupName;
		this.groupRole = groupRole;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupRole() {
		return groupRole;
	}

	public void setGroupRole(String groupRole) {
		this.groupRole = groupRole;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		GroupRoleTO other = (GroupRoleTO) obj;
		// return true when group name are same
		if (this.groupName != null && this.groupName.equals(other.groupName))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	//Sonar Fix -- Override the hashcode if override the Equals.....
	@Override
	public int hashCode()
	{
		return Integer.parseInt(String.valueOf((groupName+groupRole).hashCode()));
	}

	public Long getGroupId()
	{
		return groupId;
	}

	public void setGroupId(Long groupId)
	{
		this.groupId = groupId;
	}
	
}
