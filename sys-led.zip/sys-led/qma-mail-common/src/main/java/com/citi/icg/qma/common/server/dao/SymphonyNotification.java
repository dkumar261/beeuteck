package com.citi.icg.qma.common.server.dao;

import java.util.Date;
import java.util.List;

import dev.morphia.annotations.CappedAt;
import dev.morphia.annotations.Entity;

@Entity(value = "SymphonyNotification", noClassnameStored = true, cap = @CappedAt(count = 5000, value = 500000))
public class SymphonyNotification extends BaseEntity
{
	private String conversationId;
	private String messageId;
	private Object fromUserProfile;
	private List<String> members;
	private Date sentTimestampUTC;
	private boolean isExternal; 
	private String originalMessage;
	private String markdownMessage;

	public SymphonyNotification()
	{
		super();
	}

	public String getConversationId() {
		return conversationId;
	}

	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public Object getFromUserProfile() {
		return fromUserProfile;
	}

	public void setFromUserProfile(Object fromUserProfile) {
		this.fromUserProfile = fromUserProfile;
	}

	public List<String> getMembers() {
		return members;
	}

	public void setMembers(List<String> members) {
		this.members = members;
	}

	public Date getSentTimestampUTC() {
		return sentTimestampUTC;
	}

	public void setSentTimestampUTC(Date sentTimestampUTC) {
		this.sentTimestampUTC = sentTimestampUTC;
	}

	public boolean isExternal() {
		return isExternal;
	}

	public void setExternal(boolean isExternal) {
		this.isExternal = isExternal;
	}

	public String getOriginalMessage() {
		return originalMessage;
	}

	public void setOriginalMessage(String originalMessage) {
		this.originalMessage = originalMessage;
	}

	public String getMarkdownMessage() {
		return markdownMessage;
	}

	public void setMarkdownMessage(String markdownMessage) {
		this.markdownMessage = markdownMessage;
	}
	
}
