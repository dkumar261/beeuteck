package com.citi.icg.qma.common.core.util;

public class StringUtil
{
	private StringUtil(){
		//As this class is Util, so added making private constructor.
		//Sonar Fix -- Utility classes should not have public constructors 
	}
	
  public static String getTrimmedData(String value, int dbColumnLength)
  {
    if ((value != null) && (value.length() > dbColumnLength))
    {
      String subStr = value.substring(0, dbColumnLength);
      
      return subStr;
    }
    return value;
  }
  
  public static String getTrimmedData(String value)
  {
    if (value != null)
    {
      String subStr = value.trim();
      
      return subStr;
    }
    return value;
  }
}
