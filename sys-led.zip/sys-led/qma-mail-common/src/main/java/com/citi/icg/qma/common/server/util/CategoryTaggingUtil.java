package com.citi.icg.qma.common.server.util;

import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.core.util.QueryConstants;
import com.citi.icg.qma.common.server.dao.*;
import com.citi.icg.qma.common.server.dao.persistence.MailboxModDateUtil;
import com.citi.icg.qma.common.server.dao.persistence.MongoDB;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.*;
import microsoft.exchange.webservices.data.core.enumeration.notification.EventType;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class CategoryTaggingUtil {


    private static final Logger logger = LoggerFactory.getLogger(CategoryTaggingUtil.class);
    private static CategoryTaggingUtil instance = null;

    //TODO : Below are Cache Candidate
    private static Map<String, String> folderDisplayNameMap;
    private static Map<String,String> smartCategorySequenceMap;

    public static final String RECIPIENT_FROM = "FROM";
    public static final String INTERNAL_ME_ONLY_CATEGORY = "Me Only";
    public static final String INTERNAL_MANAGER_CATEGORY = "Manager";
    public static final String USER_IMMEDIATE_MANAGER = "immediateManager";
    public static final String INTERNAL_SR_MANAGEMENT_CATEGORY = "Sr. Management";
    public static final String USER_SENIOR_MANAGEMENT = "seniorManagement";
    public static final String USER_PEER_GROUP = "peerGroup";
    public static final String INERNAL_PEER_GROUP_CATEGORY = "Peer Group";
    public static final String INTERNAL_DIRECT_REPORTS_CATEGORY = "Direct Reports";
    public static final String USER_DIRECT_REPORTS = "directReports";
    public static final String INTERNAL_MY_ORG_CATEGORY = "My Org";
    public static final String USER_ORG_DETAILS = "orgDetails";
    public static final String EXTERNAL_ME_ONLY_CATEGORY = "External Me Only";
    public static final String SENDER_DOMAIN_CITI = "(CITI)";
    public static final String INBOX_FOLDER = "Inbox";
    public static final String INDIVIDUAL_FOLDER = "Individual";


    public static synchronized CategoryTaggingUtil getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		if (instance == null) {
			instance = new CategoryTaggingUtil();
		}
        return instance;
    }

    public void readCategoryConfigAndStampCategories(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, String mailbox,
                                                     Group userGroup, Config qmaIndividualFolderConfig) {
        Map<String,String> smartCategoryMap = getSmartCategorySequence(qmaIndividualFolderConfig);
        if(Objects.nonNull(smartCategoryMap) && !smartCategoryMap.isEmpty()) {
            boolean stampAllCategories = getCategoryStampingConfig(qmaIndividualFolderConfig);
            stampAllCategories(personalFolders, recipients, inquiryID, convId, mailbox, userGroup,stampAllCategories,smartCategoryMap);
        } else {
            logger.warn("Smart category sequence is not available, hence skipping the stamping of inquriy : {} and conv : {} for mailbox : {}",inquiryID,convId,mailbox);
        }
    }

    public Map<String,String> getSmartCategorySequence(Config qmaIndividualFolderConfig) {
        if(Objects.isNull(smartCategorySequenceMap)) {
            logger.info("Loading 'smartCategorySequenceMap' for the first time");
            if(Objects.nonNull(qmaIndividualFolderConfig) && Objects.nonNull(qmaIndividualFolderConfig.getQmaIndividualFolderConfig())) {
                Map<String, Object> folderConfigMap = qmaIndividualFolderConfig.getQmaIndividualFolderConfig();
                if(Objects.nonNull(folderConfigMap.get("sequenceConfig"))) {
                    Map<String, Object> sequenceConfig = (Map<String, Object>) folderConfigMap.get("sequenceConfig");
                    Map<String, Object> folderDefinition = (Map<String, Object>) folderConfigMap.get("folderDefinition");
                    if(Objects.nonNull(sequenceConfig.get("smartCategorySequence")) && Objects.nonNull(folderDefinition) && !folderDefinition.isEmpty()) {
                        List<String> folderSequence = (List<String>) sequenceConfig.get("smartCategorySequence");
                        smartCategorySequenceMap = getFolderDisplayNameMap(folderDefinition,folderSequence);
                    }
                }
            }
        } else {
            logger.info("Returning existing 'smartCategorySequenceMap' which was loaded at the time of application start");
        }
        return smartCategorySequenceMap;
    }

    private Map<String,String> getFolderDisplayNameMap(Map<String, Object> folderDefinition, List<String> folderSequence) {
        Map<String,String> folderSequenceWithDisplayName = new LinkedHashMap<>();
        if(Objects.nonNull(folderDefinition) && Objects.nonNull(folderSequence) && !folderSequence.isEmpty()){
            for(String folderIndex : folderSequence) {
                if(Objects.nonNull(folderDefinition.get(folderIndex))) {
                    Map<String, Object> currentFolderDefinition = (Map<String, Object>) folderDefinition.get(folderIndex);
                    if(Objects.nonNull(currentFolderDefinition) && Objects.nonNull(currentFolderDefinition.get("displayName"))) {
                        String currentFolderDisplayName = (String) currentFolderDefinition.get("displayName");
                        folderSequenceWithDisplayName.put(folderIndex,currentFolderDisplayName);
                    } else {
                        logger.warn("No folder display name is available in ");
                    }
                } else {
                    logger.warn("No folder definition is available for index {}", folderIndex);
                }
            }
        }
        return folderSequenceWithDisplayName;
    }

    private Map<String,String> getFolderDisplayNameMap(Map<String, Object> folderDefinition) {
        Map<String,String> folderDisplayNameMap = new LinkedHashMap<>();
        if(Objects.nonNull(folderDefinition) && !folderDefinition.isEmpty()){
            for(String folderIndex : folderDefinition.keySet()){
                Map<String, Object> currentFolderDefinition = (Map<String, Object>) folderDefinition.get(folderIndex);
                if(Objects.nonNull(currentFolderDefinition) && Objects.nonNull(currentFolderDefinition.get("displayName"))) {
                    String currentFolderDisplayName = (String) currentFolderDefinition.get("displayName");
                    folderDisplayNameMap.put(currentFolderDisplayName,folderIndex);
                }
            }
        }
        return folderDisplayNameMap;
    }

    private boolean getCategoryStampingConfig(Config qmaIndividualFolderConfig) {
        boolean stampAllCategories = false;
        if(Objects.nonNull(qmaIndividualFolderConfig) && Objects.nonNull(qmaIndividualFolderConfig.getQmaIndividualFolderConfig())){
            Map<String, Object> folderConfigMap = qmaIndividualFolderConfig.getQmaIndividualFolderConfig();
            if(Objects.nonNull(folderConfigMap.get("stampAllSmartCategories"))) {
                stampAllCategories = (Boolean) folderConfigMap.get("stampAllSmartCategories");
            }
        }
        logger.info("'stampAllSmartCategories' is currently configured as {}", stampAllCategories);
        return  stampAllCategories;
    }


    /**
     * This method validates if the email events is received on the same mailbox as that of sender
     * @param recipients
     * @param mailbox
     * @param userGroup
     * @return boolean
     */
    public boolean checkIfEventReceivedOnSenderMailBox(List<ConversationRecipient> recipients, String mailbox, Group userGroup) {
        boolean isEventReceivedOnSenderMailBox = false;
        if( null != recipients && !recipients.isEmpty() && StringUtils.isNotEmpty(mailbox) ) {
            for(ConversationRecipient recipient : recipients){
                if(recipient.getToFrom().equalsIgnoreCase(RECIPIENT_FROM)){
                    logger.info("Sender identified as : [{},<{}>] ", recipient.getDisplayName(), recipient.getEmailAddr());
                    isEventReceivedOnSenderMailBox = validateUserByUserId(recipient.getUserId(), mailbox);
                    String userIdFromRecipientUserEmail = "";
                    if(!isEventReceivedOnSenderMailBox && recipient.getUserId().contains("@")) {
                        userIdFromRecipientUserEmail = recipient.getUserId().substring(0, recipient.getUserId().indexOf('@'));
                        isEventReceivedOnSenderMailBox = validateUserByUserId(userIdFromRecipientUserEmail,mailbox);
                    }
                    if(!isEventReceivedOnSenderMailBox && StringUtils.isNotEmpty(recipient.getEmailAddr()) && null != userGroup) {
                        isEventReceivedOnSenderMailBox = validateUserByEmail(mailbox, recipient.getEmailAddr(),userGroup);
                    }

                    if(!isEventReceivedOnSenderMailBox && null != userGroup) {
                        isEventReceivedOnSenderMailBox = validateUserByDisplayName(recipient.getDisplayName(),userGroup.getGroupName());
                    }
                    break;
                }
            }
        }
        if(isEventReceivedOnSenderMailBox) {
            logger.info("Event received on sender's mailbox : {}", mailbox);
        } else {
            logger.info("Event not received on the sender's mailbox : {}", mailbox);
        }
        return isEventReceivedOnSenderMailBox;
    }

    /**
     * This method identifies whether to stamp internal or external categories
     * @param personalFolders
     * @param recipients
     * @param inquiryID
     * @param convId
     * @param mailbox
     * @param userGroup
     */
    private void identifyAndStampInternalOrExternalCategory(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, String mailbox, Group userGroup) {
        boolean isInternalSender = false;
        String sender ="";
        for(ConversationRecipient recipient : recipients) {
            if(recipient.getToFrom().equalsIgnoreCase(RECIPIENT_FROM)){
                sender = recipient.getEmailAddr();
                if(GenericUtility.isCitiDomainEmail(recipient.getEmailAddr())) {
                    isInternalSender = true;
                    break;
                }
            }
        }
        if(isInternalSender) {
            logger.info("Identified internal sender : {} , updating internal folder category",sender);
            updateInternalFolders(personalFolders, recipients, inquiryID, convId, mailbox, userGroup);
        } else {
            logger.info("Identified external sender : {} , updating external folder category",sender);
            updateExternalFolders(personalFolders, recipients, inquiryID, convId, mailbox, userGroup);
        }
    }


    /**
     * This method stamps internal smart categories
     * @param personalFolders
     * @param recipients
     * @param inquiryID
     * @param convId
     * @param mailbox
     * @param userGroup
     */
    @Deprecated
    private void updateInternalFolders(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, String mailbox,Group userGroup) {

        updatedInternalMeOnlyFolder(personalFolders,recipients, inquiryID, convId,mailbox,userGroup,"");

        updateManagerFolder(personalFolders,recipients, inquiryID, convId,userGroup);

        updateSeniorManagementFolder(personalFolders, recipients, inquiryID, convId,userGroup,"");

        updatePeerGroupFolder(personalFolders,recipients, inquiryID, convId,userGroup,"");

        updateDirectReportsFolder(personalFolders,recipients, inquiryID, convId, userGroup,"");

        updateMyOrgFolder(personalFolders,recipients, inquiryID, convId, userGroup,"");
    }

    /**
     * This method stamps external smart categories
     * @param personalFolders
     * @param recipients
     * @param inquiryID
     * @param convId
     * @param mailbox
     * @param userGroup
     */
    @Deprecated
    private void updateExternalFolders(List<String> personalFolders, List<ConversationRecipient> recipients,Long inquiryID, Long convId, String mailbox,Group userGroup) {

        updateExternalMeOnlyFolder(personalFolders,recipients, inquiryID, convId,mailbox,userGroup);

        updateExternalClientsFolder(personalFolders,recipients, inquiryID, convId,"");

        updateExternalOthersFolder(personalFolders,recipients, inquiryID, convId,"");

    }


    private void stampAllCategories(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, String mailbox, Group userGroup,
                                    boolean stampAllCategories, Map<String,String> smartCategoryMap) {
        if(Objects.nonNull(smartCategoryMap) && !smartCategoryMap.isEmpty()) {
            logger.info("'stampAllSmartCategories' : {} and smartCategorySequenceMap : {}", stampAllCategories,smartCategoryMap);
            for(String categoryIndex : smartCategoryMap.keySet()){
               stampCategory(personalFolders, recipients, inquiryID, convId, mailbox,userGroup, smartCategoryMap.get(categoryIndex),categoryIndex);
               if(!stampAllCategories){
                   break;
               }
            }
        }
    }

    private void stampCategory(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, String mailbox, Group userGroup,
                               String categoryName, String categoryIndex) {
        switch (categoryIndex) {
            case "6" :
                updateExternalClientsFolder(personalFolders,recipients, inquiryID, convId,categoryIndex);
                break;
            case "7" :
                updateSeniorManagementFolder(personalFolders, recipients, inquiryID, convId,userGroup,categoryIndex);
                break;
            case "8" :
                updatedInternalMeOnlyFolder(personalFolders,recipients, inquiryID, convId,mailbox,userGroup,categoryIndex);
                break;
            case "9" :
                updateDirectReportsFolder(personalFolders,recipients, inquiryID, convId, userGroup,categoryIndex);
                break;
            case "10" :
                updatePeerGroupFolder(personalFolders,recipients, inquiryID, convId,userGroup,categoryIndex);
                break;
            case "11" :
                updateMyOrgFolder(personalFolders,recipients, inquiryID, convId, userGroup,categoryIndex);
                break;
            case "12" :
                updateFrequentContactsFolder(personalFolders,recipients, inquiryID, convId, userGroup,categoryIndex);
                break;
            case "13" :
                updateHotTopicsFolder(personalFolders,recipients, inquiryID, convId, userGroup,categoryIndex);
                break;
            case "14" :
                updateExternalOthersFolder(personalFolders,recipients, inquiryID, convId,categoryIndex);
                break;
            case "15" :
                updateCitiCommsFolder(personalFolders,recipients, inquiryID, convId,categoryIndex);
                break;
            default :
                logger.warn("Invalid category {} for stamping smart categories.",categoryName);
                break;
        }
    }


    /**
     * This method will update internal Me Only folder
     * @param personalFolders
     * @param recipients
     * @param inquiryID
     * @param convId
     * @param mailbox
     * @param userGroup
     */
    private void updatedInternalMeOnlyFolder(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, String mailbox,Group userGroup, String categoryIndex) {
        try {
            logger.info("Verifying internal 'Me Only' Category");
            if(!personalFolders.isEmpty() && personalFolders.contains(categoryIndex)){
                logger.info("This workflow is already processed for internal 'Me Only' folder for Inq : {} and Conv : {} and mailbox : {}. Skipping now.", inquiryID, convId, mailbox );
                return;
            }
            boolean isMeOnlyRecipient = false;
            int recipientCount = 0;
            for(ConversationRecipient recipient : recipients) {
                if(!recipient.getToFrom().equalsIgnoreCase(RECIPIENT_FROM)){
                    ++recipientCount;
                    if(recipientCount > 1) {
                        break;
                    }
                    isMeOnlyRecipient =  validateUserByUserId(mailbox, recipient.getUserId());
                    if(!isMeOnlyRecipient) {
                        isMeOnlyRecipient = validateUserByEmail(mailbox, recipient.getEmailAddr(),userGroup);
                    }
                    if(!isMeOnlyRecipient) {
                        isMeOnlyRecipient = validateUserByDisplayName(mailbox, recipient.getDisplayName(),userGroup);
                    }
                }
            }
            if(isMeOnlyRecipient && recipientCount == 1) {
                personalFolders.add(categoryIndex);
                logger.info("Email is sent to 'Me Only' category.");
            } else {
                logger.info("Email is not sent to 'Me Only' category.");
            }
        } catch (Exception e) {
            logger.warn("Exception while updating internal 'Me Only' folder for Inq : {} and Conv : {} : ", inquiryID, convId, e);
        }
    }

    /**
     * This method will update Manager folder
     * @param personalFolders
     * @param recipients
     * @param inquiryID
     * @param convId
     * @param userGroup
     */
    @Deprecated
    private void updateManagerFolder(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, Group userGroup) {
        try {
            if(!personalFolders.isEmpty() && personalFolders.contains(INTERNAL_MANAGER_CATEGORY)){
                logger.info("This workflow is already processed for internal 'Manager' folder for Inq : {} and Conv : {} and userGroup : {}. Skipping now.", inquiryID, convId, userGroup.getId() );
                return;
            }
            boolean isFromImmediateManager = false;
            if( null != userGroup && null != userGroup.getSmartCategoryMetaData() && null != userGroup.getSmartCategoryMetaData().get(USER_IMMEDIATE_MANAGER) &&
                    ! userGroup.getSmartCategoryMetaData().get(USER_IMMEDIATE_MANAGER).isEmpty() ) {
                for(ConversationRecipient recipient : recipients) {
                    if(recipient.getToFrom().equalsIgnoreCase(RECIPIENT_FROM)){
                        HierarchyUserDetail immediateManager = userGroup.getSmartCategoryMetaData().get(USER_IMMEDIATE_MANAGER).get(0);
                        isFromImmediateManager = isHierarchyUserMatchingRecipient(recipient,immediateManager, inquiryID, convId, userGroup);
                        break;
                    }
                }
                if(isFromImmediateManager) {
                    personalFolders.add(INTERNAL_MANAGER_CATEGORY);
                    logger.info("This email with inq : {} and conv : {} is from 'Manager'", inquiryID, convId);
                } else {
                    logger.info("This email with inq : {} and conv : {} is not from 'Manager'", inquiryID, convId);
                }
            } else {
                logger.info("Immediate manager details not found for user : {} in it's group : {} in cache while processing smart category for Inq: {} and convId :{} ",
                        (null == userGroup? userGroup : userGroup.getGroupName()), (null == userGroup? userGroup :userGroup.getId()),inquiryID,convId);
            }
        } catch (Exception e) {
            logger.warn("Exception while updating internal 'Manager' folder for Inq : {} and Conv : {} : ", inquiryID, convId, e);
        }
    }


    /**
     * This method will update Sr. Management folder
     * @param personalFolders
     * @param recipients
     * @param inquiryID
     * @param convId
     * @param userGroup
     */
    private void updateSeniorManagementFolder(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, Group userGroup, String categoryIndex) {
        try {
            if(!personalFolders.isEmpty() && personalFolders.contains(categoryIndex)){
                logger.info("This workflow is already processed for internal 'Sr. Management' folder for Inq : {} and Conv : {} and userGroup : {}. Skipping now.", inquiryID, convId, userGroup.getId() );
                return;
            }
            boolean isFromSeniorManagement = false;
            if( null != userGroup && null != userGroup.getSmartCategoryMetaData() && null != userGroup.getSmartCategoryMetaData().get(USER_SENIOR_MANAGEMENT) &&
                    ! userGroup.getSmartCategoryMetaData().get(USER_SENIOR_MANAGEMENT).isEmpty() ) {
                for(ConversationRecipient recipient : recipients) {
                    if(recipient.getToFrom().equalsIgnoreCase(RECIPIENT_FROM)){
                        List<HierarchyUserDetail> seniorManagementList = userGroup.getSmartCategoryMetaData().get(USER_SENIOR_MANAGEMENT);
                        for(HierarchyUserDetail seniorMgmt : seniorManagementList) {
                            isFromSeniorManagement = isHierarchyUserMatchingRecipient(recipient,seniorMgmt, inquiryID, convId, userGroup);
                            if(isFromSeniorManagement) {
                                break;
                            }
                        }
                        break;
                    }
                }
                if(isFromSeniorManagement) {
                    personalFolders.add(categoryIndex);
                    logger.info("This email with inq : {} and conv : {} is from 'Sr. Management'", inquiryID, convId);
                } else {
                    logger.info("This email with inq : {} and conv : {} is not from 'Sr. Management'", inquiryID, convId);
                }
            } else {
                logger.info("Senior Management details not found for user : {} in it's group : {} in cache while processing smart category for Inq: {} and convId :{} ",
                		(null == userGroup? userGroup : userGroup.getGroupName()), (null == userGroup? userGroup :userGroup.getId()),inquiryID,convId);
            }
        } catch (Exception e) {
            logger.warn("Exception while updating internal 'Senior Management' folder for Inq : {} and Conv : {} : ", inquiryID, convId, e);
        }
    }

    /**
     * This method will update Peer Group folder
     * @param personalFolders
     * @param recipients
     * @param inquiryID
     * @param convId
     * @param userGroup
     */
    private void updatePeerGroupFolder(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, Group userGroup, String categoryIndex) {
        try {
            if(!personalFolders.isEmpty() && personalFolders.contains(categoryIndex)){
                logger.info("This workflow is already processed for internal 'Peer Group' folder for Inq : {} and Conv : {} and userGroup : {}. Skipping now.", inquiryID, convId, userGroup.getId() );
                return;
            }
            boolean isFromPeerGroup = false;
            if( null != userGroup && null != userGroup.getSmartCategoryMetaData() && null != userGroup.getSmartCategoryMetaData().get(USER_PEER_GROUP) &&
                    ! userGroup.getSmartCategoryMetaData().get(USER_PEER_GROUP).isEmpty() ) {
                for(ConversationRecipient recipient : recipients) {
                    if(recipient.getToFrom().equalsIgnoreCase(RECIPIENT_FROM)){
                        List<HierarchyUserDetail> peerGroupList = userGroup.getSmartCategoryMetaData().get(USER_PEER_GROUP);
                        for(HierarchyUserDetail peerUser : peerGroupList) {
                            isFromPeerGroup = isHierarchyUserMatchingRecipient(recipient,peerUser, inquiryID, convId, userGroup);
                            if(isFromPeerGroup) {
                                break;
                            }
                        }
                        break;
                    }
                }
                if(isFromPeerGroup) {
                    personalFolders.add(categoryIndex);
                    logger.info("This email with inq : {} and conv : {} is from 'Peer Group'", inquiryID, convId);
                } else {
                    logger.info("This email with inq : {} and conv : {} is not from 'Peer Group'", inquiryID, convId);
                }
            } else {
                logger.info("Peer Group details not found for user : {} in it's group : {} in cache while processing smart category for Inq: {} and convId :{} ",
                		(null == userGroup? userGroup : userGroup.getGroupName()), (null == userGroup? userGroup :userGroup.getId()),inquiryID,convId);
            }
        } catch (Exception e) {
            logger.warn("Exception while updating internal 'Peer Group' folder for Inq : {} and Conv : {} : ", inquiryID, convId, e);
        }
    }

    /**
     * This method will update Direct Reports folder
     * @param personalFolders
     * @param recipients
     * @param inquiryID
     * @param convId
     * @param userGroup
     */
    private void updateDirectReportsFolder(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, Group userGroup,String categoryIndex) {
        try {
            if(!personalFolders.isEmpty() && personalFolders.contains(categoryIndex)){
                logger.info("This workflow is already processed for internal 'Direct Reports' folder for Inq : {} and Conv : {} and userGroup : {}. Skipping now.", inquiryID, convId, userGroup.getId() );
                return;
            }
            boolean isFromDirectReports = false;
            if( null != userGroup && null != userGroup.getSmartCategoryMetaData() && null != userGroup.getSmartCategoryMetaData().get(USER_DIRECT_REPORTS) &&
                    ! userGroup.getSmartCategoryMetaData().get(USER_DIRECT_REPORTS).isEmpty() ) {
                for(ConversationRecipient recipient : recipients) {
                    if(recipient.getToFrom().equalsIgnoreCase(RECIPIENT_FROM)){
                        List<HierarchyUserDetail> directReportsList = userGroup.getSmartCategoryMetaData().get(USER_DIRECT_REPORTS);
                        for(HierarchyUserDetail directReportUser : directReportsList) {
                            isFromDirectReports = isHierarchyUserMatchingRecipient(recipient,directReportUser, inquiryID, convId, userGroup);
                            if(isFromDirectReports) {
                                break;
                            }
                        }
                        break;
                    }
                }
                if(isFromDirectReports) {
                    personalFolders.add(categoryIndex);
                    logger.info("This email with inq : {} and conv : {} is from 'Direct Reports'", inquiryID, convId);
                } else {
                    logger.info("This email with inq : {} and conv : {} is not from 'Direct Reports'", inquiryID, convId);
                }
            } else {
                logger.info("Direct Reports details not found for user : {} in it's group : {} in cache while processing smart category for Inq: {} and convId :{} ",
                		(null == userGroup? userGroup : userGroup.getGroupName()), (null == userGroup? userGroup :userGroup.getId()),inquiryID,convId);
            }
        } catch (Exception e) {
            logger.warn("Exception while updating internal 'Direct Reports' folder for Inq : {} and Conv : {} : ", inquiryID, convId, e);
        }
    }

    /**
     * This method will update My Org folder
     * @param personalFolders
     * @param recipients
     * @param inquiryID
     * @param convId
     * @param userGroup
     */
    private void updateMyOrgFolder(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, Group userGroup, String categoryIndex ) {
        try {
            if(!personalFolders.isEmpty() && personalFolders.contains(categoryIndex)){
                logger.info("This workflow is already processed for internal 'My Org' folder for Inq : {} and Conv : {} and userGroup : {}. Skipping now.", inquiryID, convId, userGroup.getId() );
                return;
            }
            boolean isFromSameOrg = false;
            if( null != userGroup && null != userGroup.getSmartCategoryMetaData() && null != userGroup.getSmartCategoryMetaData().get(USER_ORG_DETAILS) &&
                    ! userGroup.getSmartCategoryMetaData().get(USER_ORG_DETAILS).isEmpty() ) {
                for(ConversationRecipient recipient : recipients) {
                    if(recipient.getToFrom().equalsIgnoreCase(RECIPIENT_FROM)){
                        List<HierarchyUserDetail> sameOrgUserList = userGroup.getSmartCategoryMetaData().get(USER_ORG_DETAILS);
                        for(HierarchyUserDetail sameOrgUser : sameOrgUserList) {
                            isFromSameOrg = isHierarchyUserMatchingRecipient(recipient,sameOrgUser, inquiryID, convId, userGroup);
                            if(isFromSameOrg) {
                                break;
                            }
                        }
                        break;
                    }
                }
                if(isFromSameOrg) {
                    personalFolders.add(categoryIndex);
                    logger.info("This email with inq : {} and conv : {} is from 'My Org'", inquiryID, convId);
                } else {
                    logger.info("This email with inq : {} and conv : {} is not from 'My Org'", inquiryID, convId);
                }
            } else {
                logger.info("Org details not found for user : {} in it's group : {} in cache while processing smart category for Inq: {} and convId :{} ",
                		(null == userGroup? userGroup : userGroup.getGroupName()), (null == userGroup? userGroup :userGroup.getId()),inquiryID,convId);
            }
        } catch (Exception e) {
            logger.warn("Exception while updating internal 'My Org' folder for Inq : {} and Conv : {} : ", inquiryID, convId, e);
        }
    }

    /**
     * This method will update external clients folder
     * @param personalFolders
     * @param recipients
     * @param inquiryID
     * @param convId
     */
    private void updateExternalClientsFolder(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, String categoryIndex) {
        try {

        } catch (Exception e) {
            logger.warn("Exception while updating external 'Clients' folder for Inq : {} and Conv : {} : ", inquiryID, convId, e);
        }
    }

    private void updateFrequentContactsFolder(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, Group userGroup, String categoryIndex) {
    }

    private void updateHotTopicsFolder(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, Group userGroup, String categoryIndex) {
    }

    /**
     * This method will update external others method
     * @param personalFolders
     * @param recipients
     * @param inquiryID
     * @param convId
     */
    private void updateExternalOthersFolder(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, String categoryIndex) {
        try {

        } catch (Exception e) {
            logger.warn("Exception while updating external 'Others' folder for Inq : {} and Conv : {} : ", inquiryID, convId, e);
        }
    }

    private void updateCitiCommsFolder(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId, String categoryIndex) {
    }


    /**
     * This method update external me only folder
     * @param personalFolders
     * @param recipients
     * @param inquiryID
     * @param convId
     * @param mailbox
     * @param userGroup
     */
    @Deprecated
    private void updateExternalMeOnlyFolder(List<String> personalFolders, List<ConversationRecipient> recipients, Long inquiryID, Long convId,String mailbox,Group userGroup) {
        try {
            if(!personalFolders.isEmpty() && personalFolders.contains(EXTERNAL_ME_ONLY_CATEGORY)){
                logger.info("This workflow is already processed for external 'Me Only' folder for Inq : {} and Conv : {} and mailbox : {}. Skipping now.", inquiryID, convId, mailbox );
                return;
            }
            boolean isMeOnlyRecipient = false;
            int recipientCount = 0;
            for(ConversationRecipient recipient : recipients) {
                if(!recipient.getToFrom().equalsIgnoreCase(RECIPIENT_FROM)){
                    ++recipientCount;
                    if(recipientCount > 1) {
                        break;
                    }
                    isMeOnlyRecipient =  validateUserByUserId(mailbox, recipient.getUserId());
                    if(!isMeOnlyRecipient) {
                        isMeOnlyRecipient = validateUserByEmail(mailbox, recipient.getEmailAddr(),userGroup);
                    }
                    if(!isMeOnlyRecipient) {
                        isMeOnlyRecipient = validateUserByDisplayName(mailbox, recipient.getDisplayName(),userGroup);
                    }
                }
            }
            if(isMeOnlyRecipient && recipientCount == 1) {
                personalFolders.add(EXTERNAL_ME_ONLY_CATEGORY);
                logger.info("This email with inq : {} and conv : {} is from 'External Me Only'", inquiryID, convId);
            } else {
                logger.info("This email with inq : {} and conv : {} is not from 'External Me Only'", inquiryID, convId);
            }
        } catch (Exception e) {
            logger.warn("Exception while updating external 'Me Only' folder for Inq : {} and Conv : {} : ", inquiryID, convId, e);
        }
    }

    /**
     * This method validates recipient with hierarchy user detail
     * @param senderRecipient
     * @param userToBeMatched
     * @param inquiryID
     * @param convId
     * @param userGroup
     * @return boolean
     */
    private boolean isHierarchyUserMatchingRecipient(ConversationRecipient senderRecipient, HierarchyUserDetail userToBeMatched, Long inquiryID, Long convId, Group userGroup) {
        boolean isUserMatchingRecipient = false;
        if(null != senderRecipient && null != userToBeMatched) {
            logger.info("Recipient data received for matching hierarchy user is userId : {}, emailAddr : {}, displayName : {}, groupId : {}",senderRecipient.getUserId(),
                    senderRecipient.getEmailAddr(), senderRecipient.getDisplayName(), senderRecipient.getGroupId());

            isUserMatchingRecipient = validateUserByUserId(senderRecipient.getUserId(), userToBeMatched.getUserId());

            String userIdFromRecipientUserEmail = "";
            if(!isUserMatchingRecipient && senderRecipient.getUserId().contains("@")) {
                userIdFromRecipientUserEmail = senderRecipient.getUserId().substring(0, senderRecipient.getUserId().indexOf('@'));
                isUserMatchingRecipient = validateUserByUserId(userIdFromRecipientUserEmail,userToBeMatched.getUserId());
            }

            if(!isUserMatchingRecipient && StringUtils.isNotEmpty(userIdFromRecipientUserEmail)) {
                isUserMatchingRecipient = validateUserByEmail(userIdFromRecipientUserEmail, userToBeMatched.getEmailId(),userGroup);
            }

            if(!isUserMatchingRecipient) {
                isUserMatchingRecipient = validateUserByEmail(senderRecipient.getEmailAddr(),userToBeMatched.getEmailId());
            }

            if(!isUserMatchingRecipient) {
                //If hierarchy user belongs to QMA
                Group hierarchyUserGroup = QMACacheFactory.getCache().getAllGroupsMap().get(userToBeMatched.getUserId().toUpperCase());
                if(null!= hierarchyUserGroup) {
                    isUserMatchingRecipient = validateUserByEmail(userIdFromRecipientUserEmail,senderRecipient.getEmailAddr(),hierarchyUserGroup);
                    if(!isUserMatchingRecipient) {
                        isUserMatchingRecipient = validateUserByDisplayName(userToBeMatched.getUserId(),senderRecipient.getEmailAddr(),hierarchyUserGroup);
                    }
                } else {
                    logger.info("Hierarchy user : {} is not a QMA user", userToBeMatched.getUserId());
                }
            }
            if(!isUserMatchingRecipient){
                isUserMatchingRecipient = validateUserByDisplayName(senderRecipient.getDisplayName(),userToBeMatched.getUserName());
            }
            logger.info(" isUserMatchingRecipient: {}", isUserMatchingRecipient);
        } else {
            logger.info("Either recipient or hierarchy user to be matched received null for the comparison for Inq : {} and conId : {}",inquiryID,convId);
        }
        return isUserMatchingRecipient;
    }

    /**
     * This method validates user by userId
     * @param userId
     * @param targetUserID
     * @return boolean
     */
    private boolean validateUserByUserId(String userId, String targetUserID) {
        boolean isSameUser = false;
        if(StringUtils.isNotEmpty(userId) && StringUtils.isNotEmpty(targetUserID) &&
                userId.equalsIgnoreCase(targetUserID)){
            logger.info("Match found for user : {} with recipient's userId : {}", userId, targetUserID);
            isSameUser = true;
        } else {
            logger.info("Match not found for user : {} with recipient's userId : {} ", userId, targetUserID);
        }
        return isSameUser;
    }

    /**
     * This method validates user by email address
     * @param sourceEmail
     * @param targetEmailAddress
     * @return boolean
     */
    private boolean validateUserByEmail(String sourceEmail, String targetEmailAddress) {
        boolean isSameUser = false;
        if(StringUtils.isNotEmpty(sourceEmail) && StringUtils.isNotEmpty(targetEmailAddress) &&
                sourceEmail.equalsIgnoreCase(targetEmailAddress)){
            logger.info("Match found for user email : {} with recipient's email {} ",sourceEmail, targetEmailAddress);
            isSameUser = true;
        } else {
            logger.info("Match not found for user email : {} with recipient's email {} ",sourceEmail, targetEmailAddress);
        }
        return isSameUser;
    }

    /**
     * This method validates user by email address
     * @param userId
     * @param targetEmailAddress
     * @param userGroup
     * @return boolean
     */
    private boolean validateUserByEmail(String userId, String targetEmailAddress, Group userGroup) {
        boolean isSameUser = false;
        if(StringUtils.isNotEmpty(userId) && StringUtils.isNotEmpty(targetEmailAddress) && null != userGroup){
            logger.info("Validating user by emailID with input attributes userID : {}, targetEmailAddress : {}, userGroupId : {}", userId, targetEmailAddress, userGroup.getId());
            if(targetEmailAddress.contains("@")) {
                String userIdFromEmail = targetEmailAddress.substring(0,targetEmailAddress.indexOf('@'));
                if(StringUtils.isNotEmpty(userIdFromEmail) && userId.equalsIgnoreCase(userIdFromEmail)) {
                    logger.info("Match found for user : {} with userId extracted from recipient email address : {}", userId,targetEmailAddress);
                    isSameUser = true;
                }
                if(!isSameUser && null != userGroup && StringUtils.isNotEmpty(userGroup.getGroupEmail()) && userGroup.getGroupEmail().equalsIgnoreCase(targetEmailAddress)){
                    logger.info("Match found for user : {} with recipient email address : {} and user's group email address : {}", userId,targetEmailAddress, userGroup.getGroupEmail());
                    isSameUser = true;
                }
                Group senderUserGroup = QMACacheFactory.getCache().getAllGroupsMap().get(userId.toUpperCase());
                if(!isSameUser && null != senderUserGroup && null != senderUserGroup.getManualGroupEmails() && !senderUserGroup.getManualGroupEmails().isEmpty()) {
                    for(String manualEmail : senderUserGroup.getManualGroupEmails()) {
                        if(targetEmailAddress.equalsIgnoreCase(manualEmail)) {
                            logger.info("Match found for user : {} with recipients email address : {} with user's manual group email address : {}", userId,targetEmailAddress,manualEmail);
                            isSameUser = true;
                            break;
                        }
                    }
                }
            } else {
                logger.info("Invalid target email address : {} for recipient.",targetEmailAddress);
            }
        } else {
            logger.warn("Invalid userId : {} and/or target email : {} received for verification", userId, targetEmailAddress);
        }
        return isSameUser;
    }

    /**
     * This method validates user by display name
     * @param sourceName
     * @param targetDisplayName
     * @return boolean
     */
    private boolean validateUserByDisplayName(String sourceName, String targetDisplayName) {
        boolean isSameUser = false;
        if(StringUtils.isNotEmpty(sourceName) && StringUtils.isNotEmpty(targetDisplayName) && sourceName.equalsIgnoreCase(targetDisplayName)) {
            logger.info("Match found for user : {} with display name ",targetDisplayName);
            isSameUser = true;
        }
        return isSameUser;
    }

    /**
     * This method validates user by display name
     * @param userId
     * @param targetDisplayName
     * @param userGroup
     * @return boolean
     */
    private boolean validateUserByDisplayName(String userId, String targetDisplayName, Group userGroup) {
        boolean isSameUser = false;
        if(StringUtils.isNotEmpty(userId) && StringUtils.isNotEmpty(targetDisplayName) && null != userGroup){
            if(StringUtils.isNotEmpty(userGroup.getGroupName()) && targetDisplayName.equalsIgnoreCase(userGroup.getGroupName())) {
                logger.info("Match found for user : {} with recipient's display name {} with user group's display name {}", userId,targetDisplayName,userGroup.getGroupName());
                isSameUser = true;
            }
        } else {
            logger.warn("Invalid userId {} and/or recipient's display name : {}", userId, targetDisplayName);
        }
        return isSameUser;
    }

    /**
     * This function will resolve the folder Id for specified folder name
     * @param folderName
     * @return
     */
    public String resolveFolderIdForName(String folderName) {
        String resolvedFolderId = null;
        try {
            if(StringUtils.isNotEmpty(folderName)) {
                Map<String,String> getFolderMapping = getFolderDisplayMap();
                if(Objects.nonNull(getFolderMapping) && !getFolderMapping.isEmpty() && getFolderMapping.containsKey(folderName)) {
                    resolvedFolderId = getFolderMapping.get(folderName);
                }
            }
        } catch (Exception e){
            logger.warn("Exception while resolving folder Id from folder name for folder : {}", folderName);
        }
        return resolvedFolderId;
    }

    private Map<String, String> getFolderDisplayMap() {
        if(Objects.isNull(folderDisplayNameMap)) {
            logger.info("Loading 'folderDisplayNameMap' for the first time");
            QMACache cache = QMACacheFactory.getCache();
            Config qmaIndividualFolderConfig = cache.getConfigById("qmaIndividualFolderConfig");
            if(Objects.nonNull(qmaIndividualFolderConfig) && Objects.nonNull(qmaIndividualFolderConfig.getQmaIndividualFolderConfig())) {
                Map<String, Object> folderConfigMap = qmaIndividualFolderConfig.getQmaIndividualFolderConfig();
                if(Objects.nonNull(folderConfigMap.get("folderDefinition"))) {
                    Map<String, Object> folderDefinition = (Map<String, Object>) folderConfigMap.get("folderDefinition");
                    if(Objects.nonNull(folderDefinition) && !folderDefinition.isEmpty()) {
                        folderDisplayNameMap = getFolderDisplayNameMap(folderDefinition);
                    }
                }
            }
        } else {
            logger.info("Returning existing 'folderDisplayNameMap' which was loaded at the time of application start ");
        }
        return folderDisplayNameMap;
    }

    public ExchangeFolder getExchangeUiFolder(String displayName) {
        ExchangeFolder folder = new ExchangeFolder();
        folder.setDisplayName(displayName);
        return folder;
    }

    public void updateAndPublishSmartCategoryFolder(List<String> personalFolders, String mailbox) {
        QMACache cache = QMACacheFactory.getCache();
        Long userGroupId = cache.getPersonalMailboxIdToGroupIdMap().get(mailbox);
        logger.info("Mailbox identified for processing webSocket for folder is {} and userGroupId {}", mailbox, userGroupId);
        Config qmaIndividualFolderConfig = cache.getConfigById("qmaIndividualFolderConfig");
        Map<String,String> smartCategoryMap = CategoryTaggingUtil.getInstance().getSmartCategorySequence(qmaIndividualFolderConfig);
        if(Objects.nonNull(smartCategoryMap) && !smartCategoryMap.isEmpty()){
            Set<String> categoryIndex = smartCategoryMap.keySet();
            for(String workFlowFolderIndex : personalFolders) {
                if(categoryIndex.contains(workFlowFolderIndex)){
                    String displayName = smartCategoryMap.get(workFlowFolderIndex);
                    ExchangeFolder exchangeFolderTo = CategoryTaggingUtil.getInstance().getExchangeUiFolder(displayName);
                    int unreadCount = getCategoryUnreadCountForUser(mailbox,userGroupId,workFlowFolderIndex);
                    exchangeFolderTo.setUnreadCount(unreadCount);
                    exchangeFolderTo.setFolderId(workFlowFolderIndex);
                    publishToIndividualFolderNotification(mailbox,exchangeFolderTo, IndividualFolderNotification.FolderAction.UPDATE,EventType.Modified);
                }
            }
        }
    }

    public int getCategoryUnreadCountForUser(String mailbox, Long userGroupId, String folderIndex) {
        int unreadCount = 0;
        try {
            logger.info("Calculating unread count for user : {} and folderIndex : {} with userGroupId : {}", mailbox,folderIndex,userGroupId);
            long start = System.currentTimeMillis();
            String query = QueryConstants.PERSONAL_SMART_CATEGORY_UNREAD_COUNT_QUERY;
            Set<Long> grpIds = new HashSet<>();
            grpIds.add(userGroupId);
            Date defaultDateForIndividual = MailboxModDateUtil.getModDateAsPerDateConfig(mailbox, null, "Individual",false);
            Long dateLong = defaultDateForIndividual.getTime();
            String category = "['" + folderIndex + "']";
            query = query.replaceAll(QueryConstants.IND_GROUP_ID_EXP,grpIds.toString());
            query = query.replaceAll(QueryConstants.MOD_DATE_EXP,dateLong.toString());
            query = query.replaceAll(QueryConstants.IND_USER_ID_EXP,mailbox);
            query = query.replaceAll(QueryConstants.CATEGORY_INDEX_EXP, category);
            List<BasicDBObject> finalQuery= DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(query));

            DBCollection col = MongoDB.instance().getDB().getCollection("Inquiry");
            AggregationOptions options = AggregationOptions.builder().allowDiskUse(true).build();
            Cursor cur = col.aggregate(finalQuery, options, ReadPreference.secondary());
            while (cur.hasNext()) {
                BasicDBObject outputResult = (BasicDBObject) cur.next();
                unreadCount = null!=outputResult && null!=outputResult.get("TOTAL_UNREAD") ? outputResult.getInt("TOTAL_UNREAD") : 0;
            }
            logger.info("Total time taken for getting unreadCount for user : {} for folderIndex : {} is :{} ms",mailbox,folderIndex, (System.currentTimeMillis()-start));
        } catch (Exception e){
            logger.warn("Exception while getting unread count for user : {} for folderIndex : {}", mailbox,folderIndex);
        }
        return unreadCount;
    }

    public void publishToIndividualFolderNotification(String userMailbox, ExchangeFolder folderTO, IndividualFolderNotification.FolderAction action, EventType eventType) {
        try {
            ExchangeFolder updatedFolder = updateFolderAttributes(folderTO);
            IndividualFolderNotification folderNotification = new IndividualFolderNotification();
            folderNotification.setUserId(userMailbox);
            folderNotification.setAction(action);
            folderNotification.setEventType(eventType);
            folderNotification.setFolder((null == updatedFolder? "" : updatedFolder.toString())); //sonar fix null pointer
            MongoDB.instance().getDataStore().save(folderNotification);
            logger.info("FOLDER with name : {} updated for notification to user : {}", folderTO.getDisplayName(), userMailbox);
        } catch (Exception e) {
            logger.warn("Issue while saving IndividualFolderNotification :", e);
        }
    }

    /**
     * This will update the default exchange folder attributes
     * @param folder
     * @return ExchangeFolder
     */
    private ExchangeFolder updateFolderAttributes(ExchangeFolder folder) {
        ExchangeFolder updatedFolder = folder;
        if(Objects.nonNull(updatedFolder) && Objects.nonNull(updatedFolder.getDisplayName())) {
            if(updatedFolder.getDisplayName().equalsIgnoreCase(INBOX_FOLDER) ) {
                updatedFolder.setDisplayName(INDIVIDUAL_FOLDER);
                updatedFolder.setWorkflowFolderName(INBOX_FOLDER);
            }
        }
        return updatedFolder;
    }
}
