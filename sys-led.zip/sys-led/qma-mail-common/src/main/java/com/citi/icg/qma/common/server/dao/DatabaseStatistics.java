/**
 * 
 */
package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

/**
 * 
 *
 */
@Entity(value = "DatabaseStatistics", noClassnameStored = true)
public class DatabaseStatistics implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	private String id;
	private String statsFor;
	private Long totalCount;
	private Long todaysCount;
	private Long dataSizeInMB;
	private Long storageSizeInMB;
	private Float avgObjSizeInKB;
	private Float percentWrtYesterday;
	private Float percentWrtLastWeek;
	private Float percentWrtLastMonth;
	private Float percentWrtLastYear;
	private Date crtDate;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getStatsFor() {
		return statsFor;
	}
	public void setStatsFor(String statsFor) {
		this.statsFor = statsFor;
	}
	public Long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}
	public Long getTodaysCount() {
		return todaysCount;
	}
	public void setTodaysCount(Long todaysCount) {
		this.todaysCount = todaysCount;
	}
	public Long getDataSizeInMB() {
		return dataSizeInMB;
	}
	public void setDataSizeInMB(Long dataSizeInMB) {
		this.dataSizeInMB = dataSizeInMB;
	}
	public Long getStorageSizeInMB() {
		return storageSizeInMB;
	}
	public void setStorageSizeInMB(Long storageSizeInMB) {
		this.storageSizeInMB = storageSizeInMB;
	}
	public Float getAvgObjSizeInKB() {
		return avgObjSizeInKB;
	}
	public void setAvgObjSizeInKB(Float avgObjSizeInKB) {
		this.avgObjSizeInKB = avgObjSizeInKB;
	}
	public Float getPercentWrtYesterday() {
		return percentWrtYesterday;
	}
	public void setPercentWrtYesterday(Float percentWrtYesterday) {
		this.percentWrtYesterday = percentWrtYesterday;
	}
	public Float getPercentWrtLastWeek() {
		return percentWrtLastWeek;
	}
	public void setPercentWrtLastWeek(Float percentWrtLastWeek) {
		this.percentWrtLastWeek = percentWrtLastWeek;
	}
	public Float getPercentWrtLastMonth() {
		return percentWrtLastMonth;
	}
	public void setPercentWrtLastMonth(Float percentWrtLastMonth) {
		this.percentWrtLastMonth = percentWrtLastMonth;
	}
	public Float getPercentWrtLastYear() {
		return percentWrtLastYear;
	}
	public void setPercentWrtLastYear(Float percentWrtLastYear) {
		this.percentWrtLastYear = percentWrtLastYear;
	}
	public Date getCrtDate() {
		return crtDate;
	}
	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}
	
}
