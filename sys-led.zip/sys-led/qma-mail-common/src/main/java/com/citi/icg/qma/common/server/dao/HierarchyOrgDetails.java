package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

public class HierarchyOrgDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6255406329874584223L;
	private String level;
	private String orgName;
	
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
}
