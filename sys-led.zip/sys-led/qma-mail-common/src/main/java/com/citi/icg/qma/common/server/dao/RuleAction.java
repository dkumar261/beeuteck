package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

import dev.morphia.annotations.Embedded;

@Embedded
public class RuleAction implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8070962626846494428L;
	//Variable changed to suit the input
	private String assignToUserId;
	private String assignRequestType;
	
	private Boolean markAsNonInquiry;
	private Boolean markForDeletion;
	private String assignToTag;
	private String assignGroup;
	private  String assignProcessingRegion;
	
	public RuleAction(){
		
	}
	public RuleAction(String assignToUserId, String assignRequestType, Boolean markAsNonInquiry, Boolean markForDeletion, String assignToTag, String assignGroup,String assignProcessingRegion)
	{
		super();
		this.assignToUserId = assignToUserId;
		this.assignRequestType = assignRequestType;
		this.markAsNonInquiry = markAsNonInquiry;
		this.markForDeletion = markForDeletion;
		this.assignToTag = assignToTag;
		this.assignGroup = assignGroup;
		this.assignProcessingRegion = assignProcessingRegion;
	}
	
	public String getAssignToUserId()
	{
		return assignToUserId;
	}
	public void setAssignToUserId(String assignToUserId)
	{
		this.assignToUserId = assignToUserId;
	}
	public String getAssignRequestType()
	{
		return assignRequestType;
	}
	public void setAssignRequestType(String assignRequestType)
	{
		this.assignRequestType = assignRequestType;
	}
	public Boolean getMarkAsNonInquiry()
	{
		return markAsNonInquiry;
	}
	public void setMarkAsNonInquiry(Boolean markAsNonInquiry)
	{
		this.markAsNonInquiry = markAsNonInquiry;
	}
	public Boolean getMarkForDeletion()
	{
		return markForDeletion;
	}
	public void setMarkForDeletion(Boolean markForDeletion)
	{
		this.markForDeletion = markForDeletion;
	}
	public String getAssignToTag()
	{
		return assignToTag;
	}
	public void setAssignToTag(String assignToTag)
	{
		this.assignToTag = assignToTag;
	}
	public String getAssignGroup()
	{
		return assignGroup;
	}
	public void setAssignGroup(String assignGroup)
	{
		this.assignGroup = assignGroup;
	}
	public String getAssignProcessingRegion() {
		return assignProcessingRegion;
	}
	public void setAssignProcessingRegion(String assignProcessingRegion) {
		this.assignProcessingRegion = assignProcessingRegion;
	}
}
