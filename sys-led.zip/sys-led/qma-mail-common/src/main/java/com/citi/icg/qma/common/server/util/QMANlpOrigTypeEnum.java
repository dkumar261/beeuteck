package com.citi.icg.qma.common.server.util;

public enum QMANlpOrigTypeEnum
{
	INTERNAL("INTERNAL"),
	EXTERNAL("EXTERNAL"),
	INTERNALEXTERNAL("INTERNALEXTERNAL");
	
	
	private String origType;

    private QMANlpOrigTypeEnum(String origType) {
        this.origType = origType;
    }

    public String getName() {
        return origType;
    }
    
    public static QMANlpOrigTypeEnum fromString(String origType) {
        for (QMANlpOrigTypeEnum b : QMANlpOrigTypeEnum.values()) {
          if (b.origType.equalsIgnoreCase(origType)) {
            return b;
          }
        }
        return null;
      }
    @Override
    public String toString() {
        return origType;
    }

}
