package com.citi.icg.qma.common.server.dao.persistence;

import java.util.List;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.transferobject.AssignedOwnersByAgeBandTO;
import com.citi.icg.qma.common.transferobject.OpenInquiryByGroup;
import com.citi.icg.qma.common.transferobject.RequestTypeByGroup;

public interface IGraph
{

	public abstract List<OpenInquiryByGroup> getOpenInquiryByGroupsOnFly(String soeId, boolean isQMA2Origin) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	;

	public abstract List<RequestTypeByGroup> getRequestTypesByGroupsOnFly(String soeId, boolean isQMA2Origin) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	;

	// Created ourselves..
	public abstract List<AssignedOwnersByAgeBandTO> getAssignedOwnersByAgeBandListOnFly(String soeId, Boolean includeGroupDetails, boolean isQMA2Origin) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	;

	public abstract String getMaxChartDataInsertTime() throws CommunicatorException;

}