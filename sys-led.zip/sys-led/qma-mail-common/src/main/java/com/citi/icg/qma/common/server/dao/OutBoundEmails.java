package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.CappedAt;
import dev.morphia.annotations.Entity;

//@Entity(value = "OutBoundEmails", noClassnameStored = true)
@Entity(value = "OutBoundEmails", noClassnameStored = true, cap = @CappedAt(count = 50000, value = 2000000000))
public class OutBoundEmails extends BaseEntity
{

	private String messageId;
	private String references;
	private Long inquiryId;
	private Long conversationId;
	private String importance;
	private String direction;
	private String processFlag;
//	public Date createdDate;
	private String mailContent; // sunil added 28 Oct
	
	private Long groupId;//Group Id which send this outBound email

	public Long getInquiryId() {
		return inquiryId;
	}

	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}

	public OutBoundEmails()
	{

	}

	//Sonar Fix -- Constructor has parameters, which is greater than 7 authorized..not called so commented
	/*public OutBoundEmails(String messageId, String references, Long inquiryId, Long conversationId, String importance, String direction, String processFlag, String mailContent,Long groupId)
	{
		super();
		this.setMessageId(messageId);
		this.setReferences(references);
		this.setInquiryId(inquiryId);
		this.setConversationId(conversationId);
		this.importance = importance;
		this.setDirection(direction);
		this.setProcessFlag(processFlag);
		this.mailContent = mailContent;
		this.groupId=groupId;
	}*/

	public Long getGroupId()
	{
		return groupId;
	}

	public void setGroupId(Long groupId)
	{
		this.groupId = groupId;
	}

	public Long getConversationId() {
		return conversationId;
	}

	public void setConversationId(Long conversationId) {
		this.conversationId = conversationId;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getProcessFlag() {
		return processFlag;
	}

	public void setProcessFlag(String processFlag) {
		this.processFlag = processFlag;
	}

	public String getReferences() {
		return references;
	}

	public void setReferences(String references) {
		this.references = references;
	}

	
}
