package com.citi.icg.qma.common.core.transformer;

import java.beans.Encoder;
import java.beans.Expression;
import java.beans.PersistenceDelegate;

public class EnumPersistenceDelegate extends PersistenceDelegate
{
	//Sonar fix -- use override annotation on overridden method
	@Override
	protected boolean mutatesTo(Object oldInstance, Object newInstance)
	{
		return oldInstance == newInstance;
	}

	//Sonar fix -- use override annotation on overridden method
	@Override
	protected Expression instantiate(Object oldInstance, Encoder out)
	{
		Enum e = (Enum) oldInstance;
		return new Expression(e, e.getClass(), "valueOf", new Object[]
		{ e.name() });
	}
}
