package com.citi.icg.qma.common.core.config;

import java.util.Properties;

import com.citi.icg.qma.common.core.exception.CommunicatorException;

/**
 * XM configuration utilities class.
 */
public final class XmConfigUtil
{
	private static final XmConfig XM_CONFIG = ConfigInstanceFactory
			.getRootConfiguration(XmConfig.class);

	private static final XmlConfigW3dom XML_DOM = ConfigInstanceFactory.getInstance("xm");

	private XmConfigUtil()
	{
	}

	public static XmConfig getConfig()
	{
		return XM_CONFIG;
	}

	public static XmlConfigW3dom getXmlDomObj()
	{
		return XML_DOM;
	}

	public static Properties getProperties(String name) throws CommunicatorException // Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Properties jmsProp = (Properties) getXmlDomObj().getValue(Properties.class, name, null);
		return jmsProp;
	}
}
