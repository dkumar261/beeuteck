package com.citi.icg.qma.common.server.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;

public class ISGCloudAmcarUtil {

	private static final Logger logger = LoggerFactory.getLogger(ISGCloudAmcarUtil.class);

	public static final String ISG_CLOUD_AMCAR_CONFIG = "isgCloudAmcarConfig";
	private static final Object SEARCH_PARAM = "searchParam";
	private static final String UTF_8_CHARACTERSET = "UTF-8";
	private static final String ERRORCODE = "ERRORCODE";
	private static final String BEARER = "Bearer ";
	private static final String AUTHORIZATION = "Authorization";
	private static final String GET = "GET";
	private static final Object API_URL = "apiUrl";
	private static final String PROJECTION = "projection";
	private static final String ROW_LIMIT = "rowLimit";
	public static final String TYPE = "type";
	public static final String ID = "_id";
	private static final String CUSTOMER_STATUS = "CustomerAccount.Status";
	private static final String ALTERNATE_NAME = "AlternateIdList.AlternateId.name";
	private static final String DATE_RANGE = "cloudTimestamp";
	public static final String LAST_UPDATE_DATE = "lastUpdatedDate";
	public static final String ISG_IS_FIRST_TIME_UPLOAD = "isgIsFirstTimeUpload";
	private static final Object BATCH_URL = "batchUrl";
	private static final String SFTP_FID = "sftp://xstream@HOST_NAME";
	private static final String DELIVERY_PATH = "INPUT_PATH/qma_amcar_response.json.gz";

	public static Integer PAGE_SIZE = 200;
	private static String responseToken = null;

	private ISGCloudAmcarUtil() {
	}

	/**
	 * Method used to get GFCID/GFPID details from ISG cloud
	 * 
	 * @param nextPageUrl
	 * @param logger
	 * 
	 * @return
	 * @throws IOException
	 */
	public static String getISGCloudAmcarResults(String nextPageUrl) throws IOException {
		String apiUrl = nextPageUrl;
		String apiResponse = null;
		if (null == apiUrl) {
			//CacheDAO cacheDAO = CacheDAO.getInstance();
			//Map<String, Config> configData = cacheDAO.getConfigIdMap();
			Map<String, Object> isgCloudAmcarConfigMap = QMACacheFactory.getCache().getConfigById(ISG_CLOUD_AMCAR_CONFIG).getIsgCloudAmcarConfig();
			responseToken = ISGCloudRestServiceClient.getAuthorizationToken(isgCloudAmcarConfigMap);
			apiUrl = buildUrl();
		}
		Map<String, String> authorizationHeader = new HashMap<>();
		if (null != responseToken && !responseToken.contains(ERRORCODE)) {
			authorizationHeader.put(AUTHORIZATION, BEARER + responseToken);
			apiResponse = ISGCloudRestServiceClient.doRequest(apiUrl, GET, null, authorizationHeader);
		}
		return apiResponse;
	}
	
	/**
	 * Method to get the AMCAR Request Cloud URL
	 * 
	 * @param hostName
	 * @param inputFilePath
	 * @return
	 */
	public static String getAmcarRequestURL(String hostName, String inputFilePath) {
		logger.debug("getAmcarRequestURL input :  hostname[{}], inputFilePath[{}]", hostName, inputFilePath);
		//CacheDAO cacheDAO = CacheDAO.getInstance();
		//Map<String, Config> configData = cacheDAO.getConfigIdMap();
		String amcarCloudUrl = buildUrl();
		logger.debug("getAmcarRequestURL : amcarCloudUrl = [{}]", amcarCloudUrl);
		if (StringUtils.isNotBlank(amcarCloudUrl)) {
			StringBuilder sb = new StringBuilder(amcarCloudUrl).append("&delivery=").append(SFTP_FID.replace("HOST_NAME", hostName)).append(DELIVERY_PATH.replace("INPUT_PATH", inputFilePath));
			amcarCloudUrl = sb.toString();
		}
		return amcarCloudUrl;
	}

	/**
	 * Method used to build URL for the given configuration
	 * 
	 * @param isgCloudGFpcIdConfigMap
	 * @param logger
	 * @return
	 */
	@SuppressWarnings({ "unchecked" })
	private static String buildUrl() {
		Map<String, Object> isgCloudAmcarConfigMap = QMACacheFactory.getCache().getConfigById(ISG_CLOUD_AMCAR_CONFIG).getIsgCloudAmcarConfig();
		String apiUrl = (String) isgCloudAmcarConfigMap.get(API_URL);
		String batchUrl = (String) isgCloudAmcarConfigMap.get(BATCH_URL);

		Map<String, String> searchParamMap = (Map<String, String>) isgCloudAmcarConfigMap.get(SEARCH_PARAM);
		String customerStatus = searchParamMap.get(CUSTOMER_STATUS);
		String alternateName = searchParamMap.get(ALTERNATE_NAME);

		List<BasicDBList> projection = (List<BasicDBList>) isgCloudAmcarConfigMap.get(PROJECTION);
		String isFirstTimeUpload = (String) isgCloudAmcarConfigMap.get(ISG_IS_FIRST_TIME_UPLOAD);

		String rowLimit = (String) isgCloudAmcarConfigMap.get(ROW_LIMIT);
		PAGE_SIZE = Integer.parseInt(rowLimit);

		Date startDate = null;
		if (("N").equalsIgnoreCase(isFirstTimeUpload)) {
			Date lastUpdatedDate = (Date) isgCloudAmcarConfigMap.get(LAST_UPDATE_DATE);
			LocalDate localDate = lastUpdatedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			startDate = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
		}
		LocalDate today = LocalDate.now();
		Date endDate = Date.from(today.atStartOfDay(ZoneId.systemDefault()).toInstant());
		logger.info("Fetching AMCAR data between date range :" + "[" + startDate + "] - " + "[" + endDate + "]");

		StringBuilder searchJson = new StringBuilder();
		searchJson.append("{\"");
		if ("N".equalsIgnoreCase(isFirstTimeUpload) && null != startDate) {
			searchJson.append(DATE_RANGE + "\":{\"$gt\":{\"$date\":\"" + getDate(startDate) + "\"},\"$lt\":{\"$date\":\"" + getDate(endDate) + "\"}},\"");
		}
		searchJson.append(CUSTOMER_STATUS + "\":\"" + customerStatus + "\",\"" + ALTERNATE_NAME + "\":\"" + alternateName);
		searchJson.append("\"}");

		StringBuilder finalProjection = new StringBuilder();
		finalProjection.append("&projection={");
		for (int i = 0; i < projection.size(); i++) {
			String lastProjection;
			if (i == projection.size() - 1) {
				lastProjection = "\":1";
			} else {
				lastProjection = "\":1,";
			}
			finalProjection.append("\"" + projection.get(i) + lastProjection);
		}

		logger.debug("ISG CLOUD AMCAR URL:" + apiUrl + searchJson + finalProjection + "}&limit=" + rowLimit);
//		String encodedQuery = apiUrl + getUrlEncodedString(searchJson.append(finalProjection) + "}&limit=" + rowLimit);
//		apiUrl = encodedQuery.replace("%24", "$").replace("%3A", ":").replace("%2C", ",").replace("%26", "&").replace("%3D", "=").replace("+", "");
// 		return apiUrl;
		
		StringBuilder batchRequestUrl = new StringBuilder(batchUrl).append(searchJson).append(finalProjection).append("}");
		return batchRequestUrl.toString();
	}

	/**
	 * Method to get the EncodedUrl of input string.
	 * 
	 * @param inputString
	 * @param logger
	 * 
	 * @return
	 */
	public static String getUrlEncodedString(String inputString) {
		String outputString = "";
		try {
			outputString = URLEncoder.encode(inputString, UTF_8_CHARACTERSET);
		} catch (UnsupportedEncodingException e) {
			logger.error("Unable to encode provided String :" + e);
			outputString = inputString;
		}
		return outputString;
	}

	/**
	 * Method to format the date to yyyy-MM-dd'T'HH:mm:ss.SSSZ
	 * 
	 * @param date
	 * 
	 * @return
	 */
	private static String getDate(Date date) {
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		String dateRet = df1.format(date);
		return dateRet + "Z";
	}
}
