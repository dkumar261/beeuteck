package com.citi.icg.qma.common.server.aws.util;

import java.io.IOException;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.s3.AmazonS3;
import com.citi.icg.qma.common.server.dao.MessageSnapshot;
import com.citi.icg.qma.common.server.dao.persistence.AttachmentDAO;
import com.citi.icg.qma.common.server.dao.persistence.MongoDB;
import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.ReadPreference;
import com.mongodb.gridfs.GridFS;

import dev.morphia.Datastore;

public class MongoToS3SnapshotWriter implements Runnable {

	private List<String> msgIdsChunkList;
	private static final Logger log = LoggerFactory.getLogger(MongoToS3SnapshotWriter.class);
	private static final DB database = MongoDB.instance().getDB();
	private static final Datastore mongoDatastore = MongoDB.instance().getDataStore();
	private static final GridFS snapShotFS = new GridFS(database, "messageSnapshot");

	public MongoToS3SnapshotWriter(List<String> msgIdsChunkList) throws IOException {

		this.msgIdsChunkList = msgIdsChunkList;

	}

	@Override
	public void run() {
		try {

			writeToObjectStore(msgIdsChunkList);

		} catch (Exception e) {
			log.error("Error : "+e);
		}

	}

	/**
	 * 
	 * @param msgIdsChunkList
	 *            -100
	 * @throws IOException
	 */
	private void writeToObjectStore(List<String> msgIdsChunkList) {

		AWSUtility awsUtility = new AWSUtility();
		AmazonS3 amazonS3 = awsUtility.getConnection();
		AttachmentDAO attachDao = new AttachmentDAO();
		Set<String> msgIdsMigrated = new HashSet<String>();

		String projectionQuery = "{ _id : 1, inquiryId :1, gridFSId : 1,conversationId:1}";
		BasicDBObject msgMatchQuery = new BasicDBObject("_id", new BasicDBObject("$in", msgIdsChunkList))
				.append("gridFSId", new BasicDBObject("$exists", true))
				//.append("storageType", new BasicDBObject("$exists", false))
				;
		DBObject projection = BasicDBObject.parse(projectionQuery);
		DBCursor dataCursor = database.getCollection("MessageSnapshot").find(msgMatchQuery, projection)
				.setReadPreference(ReadPreference.secondary());

		log.info("Msgsnap Match Query:" + msgMatchQuery);

		Long successfulMigration = 0L;
		Long failureMigration = 0L;

		while (dataCursor.hasNext()) {
			try {
				DBObject msnpObject = dataCursor.next();

				if (msnpObject != null) {
//					Long inquiryId = (Long) msnpObject.get("inquiryId");
//					Long conversationId = (Long) msnpObject.get("conversationId");
					String mId = (String) msnpObject.get("_id");
			String docId = (String) msnpObject.get("gridFSId");

					//Map<String, Object> downloadedFileMap = attachDao.getFile(docId,true, log,snapShotFS);
					//File file = (File) downloadedFileMap.get("fileObject");
					/*
					 * Date uploadOn = (Date) downloadedFileMap.get("uploadOn"); Long size = (Long)
					 * downloadedFileMap.get("size"); String md5 = (String)
					 * downloadedFileMap.get("md5"); String type = (String)
					 * downloadedFileMap.get("type"); String fileName = (String)
					 * downloadedFileMap.get("name");
					 */

					// write to object storage
					//boolean archived = awsUtility.writeObject_donotuse(amazonS3, docId, file);
					//log.info("Msgsnap object store archive result : " +archived+ " ,docId : "+docId + "  ,name is:" + fileName);
					//file.delete();// delete file always
					attachDao.deleteFile(docId,snapShotFS);
					successfulMigration++;
					msgIdsMigrated.add(mId);
					/*if (archived) {
						
						mongoDatastore.save(new S3MigratedDocs(inquiryId, conversationId, fileName, docId, uploadOn,
								md5, type, size)); // contained all migrated
													// data
						log.info("Msgsnap Entry saved to S3MigratedDocs, docId is: " + docId + "  name is:" + fileName);
						msgIdsMigrated.add(mId);
						attachDao.deleteFile(docId,snapShotFS);

						log.info("Msgsnap deleted file in mongdb and locally" + docId + "  name is:" + fileName);
						successfulMigration++;
					}else{
						failureMigration++;
					}*/

				}
			} catch (Exception e) {
				failureMigration++;
				log.error("Msgsnap Issue in data migration", e);
			}
		}

		log.info("Msgsnap successfulMigration docs: " + successfulMigration + "  , failureMigration Docs:" + failureMigration);

		updateMessageSnapshot(msgIdsMigrated);

		log.info("Msgsnap updated finsihed and their id's are: " + msgIdsMigrated.size());

	}

	/**
	 * update Message Snapshot with archieved = Y
	 */
	public void updateMessageSnapshot(Set<String> msgIdsMigrated) {

		log.info("Msgsnap Started updating MSGSNAP  Records " + msgIdsMigrated.size());
		if (!msgIdsMigrated.isEmpty()) {
			DBCollection msgSnapShotCol = mongoDatastore.getCollection(MessageSnapshot.class);
			BulkWriteOperation bulkInquiryEscalationUpdOp = msgSnapShotCol.initializeOrderedBulkOperation();
			DBObject findConvIdQuery = new BasicDBObject("_id", new BasicDBObject("$in", msgIdsMigrated));

			log.info("Msgsnap -Updating archived in Snapshot " + findConvIdQuery);

			DBObject updateArchiveFlag = new BasicDBObject();
			updateArchiveFlag.put("$set", new BasicDBObject("storageType", "P").append("storageActionTime", new Date()));

			bulkInquiryEscalationUpdOp.find(findConvIdQuery).update(updateArchiveFlag);
			bulkInquiryEscalationUpdOp.execute();

		}
		log.info("Msgsnap done updating MSGSNAP  Records " + msgIdsMigrated.size());

	}

}
