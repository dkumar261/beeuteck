package com.citi.icg.qma.personal.exception;

public class MandatoryConfigurationMissingException extends Exception {


	private static final long serialVersionUID = 2846543383470653769L;

	/**
	 * @param message
	 * @param cause
	 */
	public MandatoryConfigurationMissingException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public MandatoryConfigurationMissingException(String message) {
		super(message);
	}

}
