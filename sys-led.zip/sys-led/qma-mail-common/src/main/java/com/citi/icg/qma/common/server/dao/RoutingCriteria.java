package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

import dev.morphia.annotations.Embedded;

// It is combination of Routingcriteria and details
@Embedded
public class RoutingCriteria implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8225148566694532802L;
	private String from;
	private String fromOperator;
	private String subject;
	private String subjectOperator;
	private String to;
	private String toOperator;
	private Boolean attachment;
	//Moved to actions
	//public String requestType; // future place holder
	//Not a list of actions. Hence list is removed.
	private RuleAction actions;

	private Date createdTime;
	
	//[C153176-356] - Setting inquiry rules order
	private int ruleOrder;

	public RoutingCriteria()
	{
		super();
	}

	public RoutingCriteria(String from, String fromOperator,String subject, String subjectOperator,String to, String toOperator, RuleAction ruleActions, Date createdTime, int ruleOrder, Boolean attachment)
	{
		super();
		this.from = from;
		this.fromOperator = fromOperator;
		this.subject = subject;
		this.subjectOperator = subjectOperator;
		this.to = to;
		//Enhanced the routing criteria for TO field
		this.toOperator = toOperator;
		this.actions = ruleActions;
		this.createdTime = createdTime;
		this.ruleOrder = ruleOrder; 
		this.attachment = attachment;
	}

	//Maintaining code standards for methods.
	public String getFrom()
	{
		return from;
	}

	public void setFrom(String from)
	{
		this.from = from;
	}

	public String getSubject()
	{
		return subject;
	}

	public void setSubject(String subject)
	{
		this.subject = subject;
	}
	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getToOperator() {
		return toOperator;
	}

	public void setToOperator(String toOperator) {
		this.toOperator = toOperator;
	}

	public Date getCreatedTime()
	{
		return createdTime;
	}

	public void setCreatedTime(Date createdTime)
	{
		this.createdTime = createdTime;
	}

	public RuleAction getActions()
	{
		return actions;
	}

	public void setActions(RuleAction actions)
	{
		this.actions = actions;
	}

	public String getFromOperator()
	{
		return fromOperator;
	}

	public void setFromOperator(String fromOperator)
	{
		this.fromOperator = fromOperator;
	}

	public String getSubjectOperator()
	{
		return subjectOperator;
	}

	public void setSubjectOperator(String subjectOperator)
	{
		this.subjectOperator = subjectOperator;
	}

	//[C153176-356] - Setting inquiry rules order
	public int getRuleOrder()
	{
		return ruleOrder;
	}

	public void setRuleOrder(int ruleOrder)
	{
		this.ruleOrder = ruleOrder;
	}

	public Boolean getAttachment() {
		return attachment;
	}

	public void setAttachment(Boolean attachment) {
		this.attachment = attachment;
	}
	
	

}
