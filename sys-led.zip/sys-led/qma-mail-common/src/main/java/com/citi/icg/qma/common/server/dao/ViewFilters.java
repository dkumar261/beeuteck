/**
 * 
 */
package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 
 *
 */
public class ViewFilters implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String viewName;
	private String filterName;
	private Map<String, List<String>> filterParams;
	public String getViewName() {
		return viewName;
	}
	public void setViewName(String viewName) {
		this.viewName = viewName;
	}
	public String getFilterName() {
		return filterName;
	}
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}
	public Map<String, List<String>> getFilterParams() {
		return filterParams;
	}
	public void setFilterParams(Map<String, List<String>> filterParams) {
		this.filterParams = filterParams;
	}

}
