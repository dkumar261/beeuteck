package com.citi.icg.qma.common.server.util;

public class NlpAutoAssignmentValidationException extends Exception {

	private static final long serialVersionUID = -7957302242311062943L;

	public NlpAutoAssignmentValidationException(String message, Throwable e) {
		super(message, e);
	}

	public NlpAutoAssignmentValidationException(Throwable e) {
		super(e);
	}

	public NlpAutoAssignmentValidationException(String message) {
		super(message);
	}	
}