package com.citi.icg.qma.common.core.util.encrypt;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.ApplicationConstants;

public class AESUtil {
    private static final Logger logger = LoggerFactory.getLogger(AESUtil.class);

	public AESUtil() {
	}

	public String enc_aes128CbcHmacSha256WithEncodedKey(String encodedDataKey, String encMode,
			String stringTobeEncrypted) throws DataEncrpyptDecryptException {
		String encString = null;
		try{
		if (StringUtils.isNotBlank(stringTobeEncrypted) && StringUtils.isNotBlank(encodedDataKey)) {
			byte[] dataKey = Base64.decodeBase64(encodedDataKey);
			EncKey.ExpandedKey DATA_KEY_128 = EncKey.EncKeySize.AES_128.genKeysHmacSha(dataKey);

			byte[] encResult = AESEncryption.encryptCBC(encMode, DATA_KEY_128, stringTobeEncrypted.getBytes());
			encString = Base64.encodeBase64String(encResult);
		} else {
			throw new DataEncrpyptDecryptException("Key Not found or blank data");
		}
		}catch(Exception e){
			throw new DataEncrpyptDecryptException("Issue in encryption",e);
		}

		return encString;
	}

	public String enc_aes128CbcHmacSha256(String dataKey, String encMode, String stringTobeEncrypted) throws DataEncrpyptDecryptException {
		String encString = null;
		try{
		if (StringUtils.isNotBlank(stringTobeEncrypted) && StringUtils.isNotBlank(dataKey)) {
			EncKey.ExpandedKey DATA_KEY_128 = EncKey.EncKeySize.AES_128.genKeysHmacSha(dataKey.getBytes());

			byte[] encResult = AESEncryption.encryptCBC(encMode, DATA_KEY_128, stringTobeEncrypted.getBytes());
			encString = Base64.encodeBase64String(encResult);
		} else {
			throw new DataEncrpyptDecryptException("Key Not found or blank data");
		}
		}catch(Exception e){
			throw new DataEncrpyptDecryptException("Issue in encryption",e);
		}
		return encString;
	}

	/*
	 * @param CBC_128 encryptedMessage the encrypted data
	 * 
	 */

	public String dec_aes128CbcHmacSha256WithEncodedKey(String encodedDataKey, String encryptedMessage) throws DataEncrpyptDecryptException {

		String decryptedMessage = null;
		try{
		if (StringUtils.isNotBlank(encodedDataKey) && StringUtils.isNotBlank(encryptedMessage)) {

			byte[] dataKey = Base64.decodeBase64(encodedDataKey);
			EncKey.ExpandedKey DATA_KEY_128 = EncKey.EncKeySize.AES_128.genKeysHmacSha(dataKey);
			byte[] decryptionResult = AESEncryption.decryptCBC(DATA_KEY_128, Base64.decodeBase64(encryptedMessage));
			decryptedMessage = new String(decryptionResult, "UTF-8");
		} else {
			throw new DataEncrpyptDecryptException("Key Not found or blank encrypted data");
		}
		}catch(Exception e){
			throw new DataEncrpyptDecryptException("Issue in decryption",e);
		}
		return decryptedMessage;
	}
	
	/*
	 * @param CBC_128 encryptedMessage the encrypted data
	 * 
	 */

	public String dec_aes128CbcHmacSha256(String dataKey, String encryptedMessage) throws DataEncrpyptDecryptException {

		String decryptedMessage = null;
		try{
		if (StringUtils.isNotBlank(dataKey) && StringUtils.isNotBlank(encryptedMessage)) {

			EncKey.ExpandedKey DATA_KEY_128 = EncKey.EncKeySize.AES_128.genKeysHmacSha(dataKey.getBytes());
			byte[] decryptionResult = AESEncryption.decryptCBC(DATA_KEY_128, Base64.decodeBase64(encryptedMessage));
			decryptedMessage = new String(decryptionResult, "UTF-8");
		} else {
			throw new DataEncrpyptDecryptException("Key Not found or blank encrypted data");
		}
		}catch(Exception e){
			throw new DataEncrpyptDecryptException("Issue in decryption",e);
		}
		return decryptedMessage;
	}

	  public String enc_aes256CbcHmacSha512(String encodedDataKey,String
	  encMode,String stringTobeEncrypted) throws Exception {
		  String encString = null;
		  if (StringUtils.isNotBlank(stringTobeEncrypted) && StringUtils.isNotBlank(encodedDataKey)) {
			  byte[] dataKey = Base64.decodeBase64(encodedDataKey);
			  EncKey.ExpandedKey DATA_KEY_256 = EncKey.EncKeySize.AES_256.genKeysHmacSha(dataKey);
			  byte[] encResult = AESEncryption.encryptCBC(encMode, DATA_KEY_256, stringTobeEncrypted.getBytes());
			  encString = Base64.encodeBase64String(encResult);
		  } else {
			  throw new DataEncrpyptDecryptException("Key Not found or blank data");
		  }
		  return encString;
	  }
	/*
	 * @param CBC_256 encryptedMessage the encrypted data
	 * 
	 */
	public String dec_aes256CbcHmacSha512(String encodedDataKey, String encryptedMessage) throws Exception {

		String decryptedMessage = null;
		try {
			if (StringUtils.isNotBlank(encryptedMessage) && StringUtils.isNotBlank(encodedDataKey)) {
				byte[] dataKey = Base64.decodeBase64(encodedDataKey);
				EncKey.ExpandedKey DATA_KEY_256 = EncKey.EncKeySize.AES_256.genKeysHmacSha(dataKey);
				byte[] decryptionResult = AESEncryption.decryptCBC(DATA_KEY_256, Base64.decodeBase64(encryptedMessage));
				decryptedMessage = new String(decryptionResult, "UTF-8");
			} else {
				throw new DataEncrpyptDecryptException("Key Not found or blank encrypted data");
			}
		} catch (Exception e){
			throw new DataEncrpyptDecryptException("Issue in decryption",e);
		}
		return decryptedMessage;
	}

	public static void main(String[] args) {

		// 1. ROOT KEY
		// 2. DATA KEY --> KMSCONFIG MONGODB -- AES DETERMINISTIC
		// 3.AESUTIL Takes DATA KEY to encrypt/decypt plain test AES
		// DETERMINISTIC
		//
		AESUtil edUtil = new AESUtil();

		String output;
		try {
			output = edUtil.enc_aes256CbcHmacSha512("Base64EncodedRootKey",
					ApplicationConstants.RANDOMIZED_ENCRYPTION_MODE,
					"DataKey");
			// logger.info("encryptedStr : {}, IV : {} " + output[0],
			// output[1]);

			String origText = edUtil.dec_aes256CbcHmacSha512("Base64EncodedRootKey", output);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
		    logger.warn("Exception in AESUtil", e);
		}

	}

}
