package com.citi.icg.qma.common.server.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.QmaMailConstants;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.Workflow;
import com.citi.icg.qma.common.server.dao.WorkflowAudit;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;

public class EscalationUtility
{
	private static final Logger logger = LoggerFactory.getLogger(EscalationUtility.class);
	private static final String Y = "Y";
	private static final String CONV_COUNT_THRESHOLD = "CONV_COUNT_THRESHOLD";
	private static final String CHASE_COUNT_THRESHOLD = "CHASE_COUNT_THRESHOLD";
	private static final String SUBJECT_FLAGWORDS_FOUND = "SUBJECT_FLAGWORDS_FOUND";
	private static final String convCountEscalationReason = "Conversation count is > " + CONV_COUNT_THRESHOLD + ".";
	private static final String clientChaseEscalationReason = "Latest client chase count is > " + CHASE_COUNT_THRESHOLD + ".";
	private static final String subjectBasedEscalationReason = "Subject contains: " + SUBJECT_FLAGWORDS_FOUND + ".";

	private Integer conversationCountThreshold;
	private int clientChaseCounterThreshold;
	private List<String> subjectFlagwordList = new ArrayList<>();
	private Map<Long, Group> allGroupsEscalationCriteriaMap;
	private static final String PENDINGAPPROVAL = "PENDINGAPPROVAL"; 
	private static final String PENDINGAPPROVAL_REAGE = "PND_REAGE"; 
	
	
	/**
	 * @return the allGroupsEscalationCriteriaMap
	 */
	public Map<Long, Group> getAllGroupsEscalationCriteriaMap() {
		return allGroupsEscalationCriteriaMap;
	}

	/**
	 * @param allGroupsEscalationCriteriaMap the allGroupsEscalationCriteriaMap to set
	 */
	public void setAllGroupsEscalationCriteriaMap(Map<Long, Group> allGroupsEscalationCriteriaMap) {
		this.allGroupsEscalationCriteriaMap = allGroupsEscalationCriteriaMap;
	}


	private void getGlobalEscalationCriteria(Map<String,Config> configIdMap)
	{
		if(configIdMap != null && configIdMap.get(QmaMailConstants.ESCALATION_CRITERIA_CONFIG_ID)!=null)
		{
			Config escalationConfig = configIdMap.get(QmaMailConstants.ESCALATION_CRITERIA_CONFIG_ID);
			clientChaseCounterThreshold = escalationConfig.getClientChaseCounterThreshold();
			subjectFlagwordList = escalationConfig.getSubjectEscalationFlagWords();
		}
		else
		{
			clientChaseCounterThreshold = 1;
			subjectFlagwordList = new ArrayList<>();
		}
		
		logger.debug("Gloabl escalation criteria: clientChaseCounterThreshold - [" + clientChaseCounterThreshold	+ "], subjectFlagwordList - [" + subjectFlagwordList + "]");
	}

	private void getGroupEscalationCriteria(Long groupId)
	{
		
		if (allGroupsEscalationCriteriaMap != null && groupId != null)
		{
			Group group = allGroupsEscalationCriteriaMap.get(groupId);
			conversationCountThreshold = 0;
			if (group != null && group.getConvCountThresholdForEscalation() != null)
			{
				conversationCountThreshold = group.getConvCountThresholdForEscalation();
			}
		}
		logger.debug("GroupId: [" + groupId + "], escalation criteria: conversationCountThreshold - [" + conversationCountThreshold + "]");
	}

	public void flagEscalations(List<Long> groupIdList, List<Workflow> workflowList, Inquiry inquiry, Long fromGroupId, Map<String, Config> configIdMap)
	{
		try
		{
//			if (CollectionUtils.isNotEmpty(groupIdList) && CollectionUtils.isNotEmpty(workflowList) && inquiry != null)
			if (groupIdList != null && !groupIdList.isEmpty() && workflowList != null && !workflowList.isEmpty() && inquiry != null)
			{
				logger.info("EscalationUtility.flagEscalations - Started evaluating escalations");
				String inqSubject = inquiry.getSubject();

				getGlobalEscalationCriteria(configIdMap);
				//allGroupsEscalationCriteriaMap = groupDAO.getGroupEscalationDetailsById(groupIdList); //Fetching group details from DB
				Map<Long, Workflow> groupReferenceWorkflowMap = new HashMap<>();

				for (Workflow workflow : workflowList)
				{
					Long grpId = workflow.getAssignedGroupId();
					if (groupIdList.contains(grpId))
					{
						Workflow groupReferenceWorkflow = groupReferenceWorkflowMap.get(grpId);
						// workflow list will have in/out/pendingapproval workflow for same group. If same group comes again then don't need to evaluate escalation again, Just copy it (else loop).
						
						// first time evaluating escalation for group.
						if (groupReferenceWorkflow == null)
						{	
							String generalEscalationReason=workflow.getGeneralEscalationReason();
							getGroupEscalationCriteria(grpId);
							workflow.setGeneralEscalationReason(null);
							
							boolean isConvCountEscalationAuditNeeded =  evaluateConvCountEscalation(workflow);
							boolean isSubjectEscalationAuditNeeded =  evaluateSubjectBasedEscalation(inqSubject, fromGroupId, workflow);
							boolean isClientChaseEscalationAuditNeeded =  evaluateClientChaseEscalation(workflow);

							if(generalEscalationReason==null || workflow.getGeneralEscalationReason()==null || !generalEscalationReason.equalsIgnoreCase(workflow.getGeneralEscalationReason()) || inquiry.getAction().equalsIgnoreCase("Forward")){
								
								workflow.setIsAckEscalation("");
								workflow.setAckEscalationBy("");
								workflow.setAckEscalationTime(null);
							}
							
							groupReferenceWorkflowMap.put(workflow.getAssignedGroupId(), workflow);
							
							if(isConvCountEscalationAuditNeeded || isSubjectEscalationAuditNeeded || isClientChaseEscalationAuditNeeded)
							{
								createWorkflowAudit(inquiry,workflow,isConvCountEscalationAuditNeeded,isSubjectEscalationAuditNeeded,isClientChaseEscalationAuditNeeded);
							}
						}
						else
						{
							workflow.setIsConvCountEscalation(groupReferenceWorkflow.getIsConvCountEscalation());
							workflow.setIsSubjectEscalation(groupReferenceWorkflow.getIsSubjectEscalation());
							workflow.setIsClientChaseEscalation(groupReferenceWorkflow.getIsClientChaseEscalation());
							workflow.setLatestClientChaseCounter(groupReferenceWorkflow.getLatestClientChaseCounter());
							workflow.setGeneralEscalationReason(groupReferenceWorkflow.getGeneralEscalationReason());
							if (groupReferenceWorkflow.getGeneralEscalationReason()==null || inquiry.getAction().equalsIgnoreCase("Forward")){
								workflow.setIsAckEscalation("");
								workflow.setAckEscalationBy("");
								workflow.setAckEscalationTime(null);
							}
						}
					}

				}
				logger.info("Completed evaluating escalations");
			}
		}
		catch (Exception e)
		{
			logger.error("EscalationUtility.flagEscalations - Error for inquiryId: [" + inquiry.getId() + "], groupIdList: " + groupIdList, e);
		}
	}

	private void createWorkflowAudit(Inquiry inquiry, Workflow workflow,boolean isConvCountEscalationAuditNeeded, boolean isSubjectEscalationAuditNeeded,boolean isClientChaseEscalationAuditNeeded) 
	{
		WorkflowAudit workflowAudit = new WorkflowAudit();
		workflowAudit.setAction(inquiry.getAction());
		workflowAudit.setActionDetails(inquiry.getAction());
		workflowAudit.setModBy(inquiry.getModBy());
		workflowAudit.setModDate(inquiry.getModDate());
		workflowAudit.setGroupId(workflow.getAssignedGroupId());
		workflowAudit.setGroupName(workflow.getAssignedGroupName());
		
		if(null!=inquiry.getModBy() && StringUtils.isNotEmpty(inquiry.getModBy()))
		{
			//User user = CacheDAO.getInstance().getUserDetailsMap().get(inquiry.getModBy().toUpperCase());
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			User user=null;
			if (userInfoMap != null) {
				user =inquiry.getModBy()==null?null: userInfoMap.get(inquiry.getModBy().toUpperCase());
			}
			if (null != user)
			{
				workflowAudit.setUserId(user.getName());
			}
		}
		
		if(isConvCountEscalationAuditNeeded)
		{
			workflowAudit.setIsConvCountEscalation(workflow.getIsConvCountEscalation());
		}
		
		if(isSubjectEscalationAuditNeeded)
		{
			workflowAudit.setIsSubjectEscalation(workflow.getIsSubjectEscalation());
		}
		
		if(isClientChaseEscalationAuditNeeded)
		{
			workflowAudit.setIsClientChaseEscalation(workflow.getIsClientChaseEscalation());
		}
		
		workflowAudit.setGeneralEscalationReason(workflow.getGeneralEscalationReason());
		
		
		// set workflow Audit to inquiry.		
		if(inquiry.getWorkflowAudit() != null)
		{
			inquiry.getWorkflowAudit().add(workflowAudit);
		}else
		{
			List<WorkflowAudit> workflowAuditList = new ArrayList<WorkflowAudit>();
			workflowAuditList.add(workflowAudit);
			inquiry.setWorkflowAudit(workflowAuditList);
		}

	}

	private boolean evaluateClientChaseEscalation(Workflow workflow)
	{
		String workflowEscalatedOnLastConversation = workflow.getIsClientChaseEscalation();
		boolean isAuditNeeded = false;
		workflow.setIsClientChaseEscalation(null);
		// Don't escalate non-inquiries. Escalate only inquiries. 
		// Inquiry : : rulesFlag will be null for inquiries. 
		// NonInquiry : rulesFlag will not be null --> "rulesFlag" : {  "markAsNonInquiry" : true} 
		
		// Client Chase Escalation
		if (Y.equalsIgnoreCase(workflow.getIsLastConvToExtEmail()))
		{
			// Resetting latestClientChaseCounter when mail is sent to external client
			workflow.setLatestClientChaseCounter(null);
		}
		else if (workflow.getLatestClientChaseCounter() != null && workflow.getLatestClientChaseCounter() > clientChaseCounterThreshold && workflow.getRulesFlag() == null)
		{
			// isEscalated flag is used for add entry in workflowAudit.
			// If workflow is already escalated on last conversation then don't audit it.
			// if workflow is escalated in current conversation then audit it.
			if(null==workflowEscalatedOnLastConversation)
			{
				isAuditNeeded = true; 
			}
			
			// escalating if latestClientChaseCount > clientChaseCounterThreshold
			workflow.setIsClientChaseEscalation(Y);
			workflow.setGeneralEscalationReason(constructEscalationReason(workflow.getGeneralEscalationReason(), clientChaseEscalationReason, CHASE_COUNT_THRESHOLD, "" + clientChaseCounterThreshold));
		}
		logger.debug("LatestClientChaseCounter - [" + workflow.getLatestClientChaseCounter() + "], isClientChaseEscalation - [" + workflow.getIsClientChaseEscalation()
				+ "]");
		
		return isAuditNeeded;
	}

	private String constructEscalationReason(String escalationReason, String criteriaSpecificReason, String criteriaPlaceholder, String criteria)
	{// Method to construct escalation reason
		if (StringUtils.isNotBlank(escalationReason))
		{
			// appending existing reason with new line
			escalationReason = escalationReason + " ";
		}
		else
		{
			escalationReason = "";
		}
		// Appending criteria specific escalation reason
		escalationReason = escalationReason + criteriaSpecificReason.replace(criteriaPlaceholder, criteria);
		return escalationReason;
	}

	private boolean evaluateSubjectBasedEscalation(String inqSubject, Long fromGroupId, Workflow workflow)
	{
		String workflowEscalatedOnLastConversation = workflow.getIsSubjectEscalation();
		workflow.setIsSubjectEscalation(null);
		boolean isAuditNeeded = false;
		// Subject Based Escalation
		if (StringUtils.isNotBlank(inqSubject) && workflow.getAssignedGroupId() != null && !workflow.getAssignedGroupId().equals(fromGroupId))
		{// Subject escalation will be done only if the group is not the sender
			String flagwordsFound = "";
			List<String> subjectEscalationWords = getSubjectEscalationWords(workflow.getAssignedGroupId());
			
			for (String flagWord : subjectEscalationWords)
			{
				if (StringUtils.isNotBlank(flagWord) && (inqSubject.toLowerCase()).contains(flagWord.toLowerCase()))
				{
					// Constructing list of flagwords found, to place in the reason
					flagwordsFound = flagwordsFound + flagWord + ";";
				}
			}
			// Don't escalate non-inquiries. Escalate only inquiries. 
			// Inquiry : : rulesFlag will be null for inquiries. 
			// NonInquiry : rulesFlag will not be null --> "rulesFlag" : {  "markAsNonInquiry" : true} 
			if (StringUtils.isNotBlank(flagwordsFound) && workflow.getRulesFlag() == null)
			{
				// isEscalated flag is used for add entry in workflowAudit.
				// If workflow is already escalated on last conversation ( getIsSubjectEscalation = Y) then don't audit it.
				// if workflow is escalated in current conversation then audit it.
				if(null==workflowEscalatedOnLastConversation)
				{
					isAuditNeeded = true; 
				}
				
				workflow.setIsSubjectEscalation(Y);
				workflow.setGeneralEscalationReason(constructEscalationReason(workflow.getGeneralEscalationReason(), subjectBasedEscalationReason, SUBJECT_FLAGWORDS_FOUND,
						flagwordsFound.substring(0, flagwordsFound.length() - 1)));
			}
		}
		logger.debug("subject: " + inqSubject + ";, isSubjectEscalation - [" + workflow.getIsSubjectEscalation() + "]");
		
		return isAuditNeeded;
	}

	
	/**
	 * @param assignedGroupId
	 * @return
	 *  If Group has subjectEscalation then fetch from group. 
	 *  If Group doesn't have subjectEscalation then fetch from config (Application level words).
	 */
	private List<String> getSubjectEscalationWords(Long assignedGroupId)
	{
		List<String> groupLevelSubjectEscalationWords = getAllGroupsEscalationCriteriaMap().get(assignedGroupId).getSubjectEscalationList();
		if(null!=groupLevelSubjectEscalationWords && !groupLevelSubjectEscalationWords.isEmpty())
		{
			return groupLevelSubjectEscalationWords;
		}else
		{
			return subjectFlagwordList;
		}		
		
	}
	
	private boolean evaluateConvCountEscalation(Workflow workflow)
	{
		String workflowEscalatedOnLastConversation = workflow.getIsConvCountEscalation();
		workflow.setIsConvCountEscalation(null);
		boolean isAuditNeeded = false;
		// Conversation Count Escalation
		// Don't escalate non-inquiries. Escalate only inquiries. 
		// Inquiry : : rulesFlag will be null for inquiries. 
		// NonInquiry : rulesFlag will not be null --> "rulesFlag" : {  "markAsNonInquiry" : true} 
		if (conversationCountThreshold > 0 && workflow.getConvCount() > conversationCountThreshold && workflow.getRulesFlag() == null)
		{
			// isEscalated flag is used for add entry in workflowAudit.
			// If workflow is already escalated on last conversation then don't audit it.
			// if workflow is escalated in current conversation then audit it.
			if(null==workflowEscalatedOnLastConversation)
			{
				isAuditNeeded = true; 
			}
				
			workflow.setIsConvCountEscalation(Y);
			workflow.setGeneralEscalationReason(constructEscalationReason(workflow.getGeneralEscalationReason(), convCountEscalationReason, CONV_COUNT_THRESHOLD, "" + conversationCountThreshold));
			
		}
		logger.debug("ConvCount - [" + workflow.getConvCount() + "], isConvCountEscalation - [" + workflow.getIsConvCountEscalation() + "]");
		
		return isAuditNeeded;
	}

	public void setRespontimeEscalationForInternalMail(List<Workflow> workFlowList, List<ConversationRecipient> recipientsList, Long fromGrpId, Inquiry inquiry, Date currentTime, String action)
	{
		try
		{
//			if (CollectionUtils.isNotEmpty(workFlowList) && inquiry != null)
			if (workFlowList!= null && !workFlowList.isEmpty() && inquiry != null)
			{
				boolean otherParticipantsIncludedInConv = checkIfOtherParticipantsIncludedInConv(recipientsList,fromGrpId);	
				
				for (Workflow workflow : workFlowList)
				{
					Long grpId = workflow.getAssignedGroupId();
					if (null!= grpId && QmaMailConstants.STATUS_OPEN.equalsIgnoreCase(workflow.getStatus()) && QmaMailConstants.INQUIRY_DIRECTION_IN.equalsIgnoreCase(workflow.getDirection()))
					{
						setRsponseTimeNextEscalationForWorkflow(otherParticipantsIncludedInConv,workflow, grpId, currentTime, fromGrpId,  action);
					}

				}
			}
		}
		catch (Exception e)
		{
			logger.error("EscalationUtility.setRespontimeEscalationForInternalMail - Error for inquiryId: [" + inquiry.getId() + "]" ,e);
		}
		
	}
	
	public void setRsponseTimeNextEscalationForWorkflow(boolean otherParticipantsIncludedInConv, Workflow workflow, Long assignToGrpId, Date currentTime, Long fromGroupId, String inquiryAction)
	{
		// check if mail is sent ONLY to own group(NEW)	
		//1. If mail is sent only to own group then don't set escalationTime.
		//2. If sender is copied in the mail, then don't set escalationTime, Example QA1 sends mail to QA1,UAT1.
		//3. If mail is replied(forwarded) to own group, then don't reset escalationTime		
		
		try
		{
			if (null!= getAllGroupsEscalationCriteriaMap() && null != getAllGroupsEscalationCriteriaMap().get(assignToGrpId) && null!= fromGroupId)
			{
				if (otherParticipantsIncludedInConv && fromGroupId.longValue() != assignToGrpId.longValue())
				{
					setEscalationTime(assignToGrpId,workflow,currentTime);
				}else if(otherParticipantsIncludedInConv && fromGroupId.longValue() == assignToGrpId.longValue() && !"New Inquiry".equalsIgnoreCase(inquiryAction)) // reply/replyall/forward,etc
				{
					resetEscalationTime(assignToGrpId,workflow);
				} 
			}
		}catch(Exception e)
		{
			logger.error("EscalationUtility.setRsponseTimeNextEscalationForWorkflow, assignToGrpId:"+assignToGrpId, e);
		}

	}
	
	public void setEscalationTime(Long assignedGroupId, Workflow fromWorkflow, Date currentTime)
	{
		// set next escalation time based on threshold.
		if (null != fromWorkflow && null != getAllGroupsEscalationCriteriaMap() && null != getAllGroupsEscalationCriteriaMap().get(assignedGroupId))
		{
			Integer responseTimeThreshold = getAllGroupsEscalationCriteriaMap().get(assignedGroupId).getResponseTimeThresholdForEscalation();
			// Don't escalate non-inquiries. Escalate only inquiries. 
			// Inquiry : : rulesFlag will be null for inquiries. 
			// NonInquiry : rulesFlag will not be null --> "rulesFlag" : {  "markAsNonInquiry" : true} 
			if (null != responseTimeThreshold && responseTimeThreshold > 0 && null == fromWorkflow.getResponseTimeNextEscalation() && fromWorkflow.getRulesFlag() == null)
			{
				
				fromWorkflow.setResponseTimeNextEscalation(generateNextEscalationTime(assignedGroupId,currentTime, responseTimeThreshold));
				fromWorkflow.setResponseTimeEscalationFlag("N");
			}
		}
	}
	
	
	
	public void resetEscalationTime(Long assignedGroupId, Workflow fromWorkflow)
	{
		Integer responseTimeThreshold = getAllGroupsEscalationCriteriaMap().get(assignedGroupId).getResponseTimeThresholdForEscalation();

		if (null != responseTimeThreshold && responseTimeThreshold > 0)
		{
			fromWorkflow.setResponseTimeNextEscalation(null);
			fromWorkflow.setResponseTimeEscalationFlag(null);
			fromWorkflow.setResponseTimeEscalationReason(null);
			fromWorkflow.setIspendingApprovalEscalation(null);
		}
	}
	
	public boolean checkIfOtherParticipantsIncludedInConv(List<ConversationRecipient> recipientsList,Long assignedGroupId)
	{
		boolean otherParticipantsIncludedInConv = false;
		
		// check if other participants included in the reply/forward action. Check if recipientsList should have other participants as well.
		
		if(null!=recipientsList)
		{
			for (ConversationRecipient recipient : recipientsList)
			{
				// self check.
				boolean groupIdCheck = null!=assignedGroupId && null!=recipient.getGroupId() && recipient.getGroupId().longValue() == assignedGroupId.longValue();
				
				if (!groupIdCheck)
				{
					otherParticipantsIncludedInConv = true;
					break;
				}				
			}
		}
		
		return otherParticipantsIncludedInConv;
	}
	
	public Date generateNextEscalationTime(Long fromGroupId,Date currentTime, Integer responseTimeThreshold)
	{
		try{
			if(null!= currentTime)
			{
				return DateUtils.addMinutes(currentTime, responseTimeThreshold);
			}
		}catch (Exception e)
		{
			logger.error("EscalationUtility.generateNextEscalationTime - Error for groupId: " + fromGroupId , e);
		}
		return null;
	}

	public void setRespontimeEscalationForExternalMail(List<Long> groupIdList, List<Workflow> workflowList, Inquiry inquiry, Timestamp currentTime)
	{
		try
		{
			if (CollectionUtils.isNotEmpty(workflowList) && inquiry != null)
			{
				for (Workflow workflow : workflowList)
				{
					Long grpId = workflow.getAssignedGroupId();
					if (null!= grpId && QmaMailConstants.STATUS_OPEN.equalsIgnoreCase(workflow.getStatus()) && QmaMailConstants.INQUIRY_DIRECTION_IN.equalsIgnoreCase(workflow.getDirection()))
					{
						setEscalationTime(grpId, workflow, currentTime);
					}

				}
			}
		}
		catch (Exception e)
		{
			logger.error("EscalationUtility.setRespontimeEscalationForExternalMail - Error for inquiryId: [" + inquiry.getId() + "], groupIdList: " + groupIdList, e);
		}
	}
	
	//Method to determine if an inquiry is escalated for a group and return escalation reason.
	public String getInquiryEscalationReasonForGroup(BasicDBObject inquiry)
	{
		String escalationReason = "";
		if(inquiry != null && (Y.equalsIgnoreCase(inquiry.getString("isConvCountEscalation")) || Y.equalsIgnoreCase(inquiry.getString("isClientChaseEscalation"))
				|| Y.equalsIgnoreCase(inquiry.getString("isSubjectEscalation")) || Y.equalsIgnoreCase(inquiry.getString("responseTimeEscalationFlag"))
				|| Y.equalsIgnoreCase(inquiry.getString("isManualEscalation")) ))
		{
			String generalEscalationReason = inquiry.getString("generalEscalationReason");
			String responseTimeEscalationReason = inquiry.getString("responseTimeEscalationReason");
			
			if(StringUtils.isNotBlank(generalEscalationReason))
			{
				escalationReason = escalationReason + generalEscalationReason + " ";
			}
			if(StringUtils.isNotBlank(responseTimeEscalationReason))
			{
				escalationReason = escalationReason + responseTimeEscalationReason;
			}
			
		}
		
		return escalationReason;
	}
	
	
	
	/**
	 * @param workFlowList
	 * @param assignedGroupId
	 * @param currentTime
	 * @param logger
	 * [C153176-1270] - Add Escalation criteria for 'Pending Approval' emails
	 */
	public void setEscalationTimeforPendingApproval(List<Workflow> workFlowList,  Long assignedGroupId, Date currentTime)
	{
//		if (CollectionUtils.isNotEmpty(workFlowList)) {
		if (workFlowList!=null && !workFlowList.isEmpty()) {
			for (Workflow workflow : workFlowList) {

				if (null != workflow && null != getAllGroupsEscalationCriteriaMap()
						&& null != getAllGroupsEscalationCriteriaMap().get(assignedGroupId)
						&& (PENDINGAPPROVAL.equalsIgnoreCase(workflow.getDirection()) || 
								PENDINGAPPROVAL_REAGE.equalsIgnoreCase(workflow.getDirection()))) {
						Integer paResponseTimeThreshold = getAllGroupsEscalationCriteriaMap().get(assignedGroupId).getPaResponseTimeThresholdForEscalation();
						if (null != paResponseTimeThreshold && paResponseTimeThreshold > 0 && null == workflow.getResponseTimeNextEscalation()) {
							workflow.setResponseTimeNextEscalation(generateNextEscalationTime(assignedGroupId, currentTime, paResponseTimeThreshold));
							workflow.setResponseTimeEscalationFlag("N");
							workflow.setIspendingApprovalEscalation("N");
					}
				}
			}
		}
	}
	
}