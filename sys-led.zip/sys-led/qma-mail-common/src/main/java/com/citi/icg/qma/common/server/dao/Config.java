package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;
import dev.morphia.annotations.Transient;

@Entity(value = "Config", noClassnameStored = true)
public class Config implements Serializable// extends BaseEntity
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2556410196546466619L;
	@Id
	private String id;
	private List<KeyValue> queryList;
	// [C153176-725] - Admin Menu Enhancements for config role and other role
	// reviews
	private List<String> adminRoleList; // Default admin roles available to be displayed on UI
	private List<String> userAdmin; // UserIds with userAdmin role
	private List<String> groupSetupAdmin; // UserIds with groupSetupAdmin role
	private List<String> mgmtHierarchyAdmin;// UserIds with mgmtHierarchyAdmin role
	private List<String> dbAdmin;// UserIds with dbAdmin role

	private String template;// [C153176-544] - AutoResponse details
	private List<String> inquirySourceList;// [C153176-854] - Add new drop-down: Inquiry Source
	private List<String> inquirySubStatusList; //C170665-1719 DCC Requirement: Add Case status field
	private boolean enableInquirySubStatusFlag; //C170665-1719 DCC Requirement: Add Case status field
	private int clientChaseCounterThreshold; // [C153176-1014] - Add Escalation functionality
	private List<String> subjectEscalationFlagWords;
	private int responseTimeEscJobIntervalInSeconds;
	private int responseTimeEscJobThreadCount;
	private int maxRuleRouteCriteriaListLimit;
	private Date insertTime; // [C153176-1193] - Optimize Login user info , Chart refresh time data

	private String broadcastUserSpecificInquiry;

	private List<String> collectionList;

	// [C153176-1281] Show latest release notes on QMA UI.
	private String currentReleaseDocumentName;

	private List<String> domains;

	private int S3ThreadCount;

	private int S3InquiryBatchlimit;

	private int S3HandlingWeekOldData;

	private boolean isSmartRoutingRuleEnabled;

	private int wsMaxInquiryProcessLimit;
	private int wsMaxWorkflowIgnoreLimit;
	private long wsServerLatencyInMs;

	private int userNotificationMaxBatchSize;
	private Date netezzaJobUserActivitiesLastLoadTime;

	private Date netezzaJobActionStatisticsLastLoadTime;

	private String feedbackDlId;

	private List<String> citiDomains;

	private List<String> highlevelReqestTypes;

	private boolean highlevelRequestTypeFlag;

	private List<KeyValue> msExchangeServerConfigList;
	
	// created for STORM mail processor
	private List<KeyValue> msExchangeServerConfigParallel;
	
	//sbt:[C170665-1723] High CheckMark Findings
	private String fileNameRegex;
	
	private List<Character> invalidChars;
	
	private String fullRefreshUrl; // C170665-2332 Integrate Cache refresh in QMA2
	
	private Map<Long, String> brazilFxDlMap;
	
	private List<String> brazilSubscribedSenderDomains;
	
	private Map<String,String> brazilRequestType;
	
	private String qmaServiceURL;
	
	private Map<String,Long> productFamilyGroupIdMap;
	
	private String messageBusPublisherURL;
	
	private String enableBrazilFxIntegration;
		
	private Map<String, Object> brazilFxConfig;

	//PrematchMap
	private Map<String, Set<String>> searchKeywordToClientIdBaseNoMap;
	
	private Map<String, Set<String>> senderDomainToClientIdBaseNoMap;
	
	private Map<String, Set<String>> clientIdToSearchKeywordMap;
	
	private Map<String, String> clientIdToClientNameMap;
	
	private Map<String, Set<String>> clientIdToBaseNoMap;
	
	private boolean enableContentMatch;
	
	private Map<String,Object> messageBusConfigMap;
	
	private Integer searchInDays;
	
	private String enableManualDeLinkEntity;
	
	private String enableManualLinkEntity;

	private Integer s3ArchiveNoOfDays;
	
	private Integer s3ArchiveNoOfDaysRange;
	
	private Map<String, Object> authConfig; 

	private Map<String, Object> messageReplayConfig;
	
	private Map<String, Object> taskizeConfig;
	
	private List<TaskizeParticipantsContactMapping> taskizeParticipantsContactMapping;
	
	private Date actionStatisticsLoadEndTime;
	
	private Date messageSnapshotLoadEndDate;
	
	private Date userActivitiesLoadEndDate;
	
	private boolean isPastfeedLoadEnabled;

	private Map<String, Object> ssoOpsJobConfig;
	
	// C170665-4031 - Allow "Automated Response" for a DL to be more customizable by User
	private List<String> customKeywordsForAutoResponse;
	private boolean isCustomAutoResponseEnabledForInternalDomain;
	
	private boolean hazelcastSecondClusterConnectionConfig;
	
	private String nonInquiryAge;         //_id : inquiryResolveJob
	private String workFlowDirection;     //_id : inquiryResolveJob
	private List<Long> groupList; 	//_id : inquiryResolveJob	
	private Date  startDate;         //_id : inquiryResolveJob
	private Date  endDate;         //_id : inquiryResolveJob
	private String updatedMessage;  //_id : inquiryResolveJob
	
	private Long lastProcessedConvId;

	public String getFileNameRegex() {
		return fileNameRegex;
	}

	public void setFileNameRegex(String fileNameRegex) {
		this.fileNameRegex = fileNameRegex;
	}

	public List<Character> getInvalidChars() {
		return invalidChars;
	}

	public void setInvalidChars(List<Character> invalidChars) {
		this.invalidChars = invalidChars;
	}

	public String getIsgIsFirstTimeUpload() {
		return isgIsFirstTimeUpload;
	}

	public void setIsgIsFirstTimeUpload(String isgIsFirstTimeUpload) {
		this.isgIsFirstTimeUpload = isgIsFirstTimeUpload;
	}

	public boolean isEnableAgeBasedCalculation() {
		return enableAgeBasedCalculation;
	}

	public void setEnableAgeBasedCalculation(boolean enableAgeBasedCalculation) {
		this.enableAgeBasedCalculation = enableAgeBasedCalculation;
	}

	public List<Country> getCountryList() {
		return countryList;
	}

	public void setCountryList(List<Country> countryList) {
		this.countryList = countryList;
	}

	public boolean isAutoFwdEnabled() {
		return autoFwdEnabled;
	}

	public void setIsgCloudHolidaysConfig(Map<String, Object> isgCloudHolidaysConfig) {
		this.isgCloudHolidaysConfig = isgCloudHolidaysConfig;
	}

	private Map<String, Object> nlpConfiguration;
	private Map<String, List<String>> autoFwdDLsMappings;
	private boolean autoFwdEnabled;
	private Map<String, Object> clcConfiguration;
	private Map<String, Object> oasysPaymentProcessingConfig;
	private Map<String, Object> qmaStormConfig;

	private Map<String, Object> cmcConfiguration;
	
	private Map<String, Object> TCLConfiguration;

	private List<ClientAuthorization> appConfig;

	private Map<String, Object> registeredAPIConfig;

	private Map<String, Object> mongoToNetezaConfiguration;

	private Map<String, Object> isgCloudHolidaysConfig;

	private String isgIsFirstTimeUpload;

	private boolean enableAgeBasedCalculation;

	private List<Country> countryList;

	private List<TimeZone> timeZones;
	private String appServerContext;

	private List<String> misExclusionReports;

	private List<String> misExclusionReasons;

	private List<String> corsWhiteListedUrls;
	
	private List<String> whiteListedServers;
	
	private List<String> apiExclusionList;

	private String zipFileTempDownloadPath;

	private List<Map<String, Object>> masterColumnDefAgGrid;

	private List<Map<String, Object>> masterColumnDefIndividual;

	private List<String> defaultViewsForMailboxStats;

	private List<String> defaultViewNames;

	private String tinyMCEUrl;

	private Date netezzaJobMessageSnapshotLastLoadTime;

	private Map<String, Object> cvWebsocketConfig;


	private Map<String, Object> clientMappingOCRMConfig;

	private Map<String, Object> msgSnapshotConfig;

	private String msgSnapshotPurgeLimitInDays;

	private int msgBatchlimit;

	private int msgThreadCount;

	private Map<String, Object> globalDirectoryConfig;

	private Map<String, Object> smartOracleConnectionConfig;

	private Map<String, Object> qmaUI2Config;

	private Map<String, Object> inquiryScheduleConfig;

	private List<KeyValue> queryListOracle;

	private boolean disableUserOrgDisplay;

	private Date clientPriorityFromDate;

	private Map<String, Object> defaultViewPerformanceConfig;

	private boolean groupReportWithGlobalDirSync;

	private Map<String, Object> symphonyConfig;

	private Map<String, Object> archivalConfig;

	private Map<String, Object> gdprConfig;

	private Map<String, Object> attachmentPurgeConfig;

	private Map<String, Object> bccMailBoxConfig;

	private Map<String, Object> dedicatedMailBoxConfig;

	private Map<String, Object> qmaPersonalConfig;

	private Map<String, Object> qmaIndividualFolderConfig;

	private Map<String, Object> cimsConfig;

	private Map<String, Object> dbStatsConfig;
	
	private Map<String, Object> sessionConfig;
	
	private Map<String, Object> commUniFlowConfig;
	
	private Map<String, Object> qma2RedirectPopupConfig;

	private Map<String, Object> isgCloudAmcarConfig;
	
	private Map<String, Object> isgCloudAmcConfig;
	
	private Map<String, Object> wsSimulatorConfig;
	
	private Map<String, Object> isgCloudPmmConfig;
	
	private Map<String, Object> uiConsoleLogConfig;

	private Map<String, Object> qmaHazelcastCacheConfig;
	
	private Map<String, Object> encryptionConfig;

	private Map<String, Object> aimlProcessingConfig;

	private boolean pivotProConfigEnabled;

	private List <String> xmcExportDlConfigList;

	private String xmcExportDlPath;
	
	private String xmcLastBatchRunId;
	
	private String xmcLastBatchRunSuccess;
	
	private Date xmcLastRunStartDate;
	private Date xmcLastRunEndDate;

	private String qesKey;

	private List<Long> reportDLExclusionList;
	
	private List<String> stripHtmlStyleList;
	
	private Map<String, Object> s3ContentArchivalConfig;
	
	private Map<String, Object> s3BucketConfig;

	private List<String> whiteListedApps;

	private Map<String, Object> solrCertConfig;
	
	private Map<String, Object> smartSearchConfig;
	
	private Map<String, Object> emailThreadConfig;
	@Transient
	private Map<String, Object> ideationConfig;
	
	private Map<String, Object> downloadEmailAsAZipBusinessDaysConfig;
	
	private Map<String, Object> xssListConfig;
	
	public Map<String, Object> getDownloadEmailAsAZipBusinessDaysConfig() {
		return downloadEmailAsAZipBusinessDaysConfig;
	}
	
	public void setDownloadEmailAsAZipBusinessDaysConfig(Map<String, Object> downloadEmailAsAZipBusinessDaysConfig) {
		this.downloadEmailAsAZipBusinessDaysConfig = downloadEmailAsAZipBusinessDaysConfig;
	}

	public List<String> getWhiteListedApps() {
		return whiteListedApps;
	}

	public void setWhiteListedApps(List<String> whiteListedApps) {
		this.whiteListedApps = whiteListedApps;
	}

	public List<KeyValue> getQueryList() {
		return queryList;
	}

	public void setQueryList(List<KeyValue> queryList) {
		this.queryList = queryList;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<String> getAdminRoleList() {
		return adminRoleList;
	}

	public void setAdminRoleList(List<String> adminRoleList) {
		this.adminRoleList = adminRoleList;
	}

	public List<String> getUserAdmin() {
		return userAdmin;
	}

	public void setUserAdmin(List<String> userAdmin) {
		this.userAdmin = userAdmin;
	}

	public List<String> getGroupSetupAdmin() {
		return groupSetupAdmin;
	}

	public void setGroupSetupAdmin(List<String> groupSetupAdmin) {
		this.groupSetupAdmin = groupSetupAdmin;
	}

	public List<String> getMgmtHierarchyAdmin() {
		return mgmtHierarchyAdmin;
	}

	public void setMgmtHierarchyAdmin(List<String> mgmtHierarchyAdmin) {
		this.mgmtHierarchyAdmin = mgmtHierarchyAdmin;
	}

	public List<String> getDbAdmin() {
		return dbAdmin;
	}

	public void setDbAdmin(List<String> dbAdmin) {
		this.dbAdmin = dbAdmin;
	}

	public String getTemplate() {
		return template;
	}

	public void setTemplate(String template) {
		this.template = template;
	}

	public List<String> getInquirySourceList() {
		return inquirySourceList;
	}

	public void setInquirySourceList(List<String> inquirySourceList) {
		this.inquirySourceList = inquirySourceList;
	}

	public List<String> getSubjectEscalationFlagWords() {
		return subjectEscalationFlagWords;
	}

	public void setSubjectEscalationFlagWords(List<String> subjectEscalationFlagWords) {
		this.subjectEscalationFlagWords = subjectEscalationFlagWords;
	}

	public int getClientChaseCounterThreshold() {
		return clientChaseCounterThreshold;
	}

	public void setClientChaseCounterThreshold(int clientChaseCounterThreshold) {
		this.clientChaseCounterThreshold = clientChaseCounterThreshold;
	}

	public int getResponseTimeEscJobIntervalInSeconds() {
		return responseTimeEscJobIntervalInSeconds;
	}

	public void setResponseTimeEscJobIntervalInSeconds(int responseTimeEscJobIntervalInSeconds) {
		this.responseTimeEscJobIntervalInSeconds = responseTimeEscJobIntervalInSeconds;
	}

	public int getResponseTimeEscJobThreadCount() {
		return responseTimeEscJobThreadCount;
	}

	public void setResponseTimeEscJobThreadCount(int responseTimeEscJobThreadCount) {
		this.responseTimeEscJobThreadCount = responseTimeEscJobThreadCount;
	}

	public int getMaxRuleRouteCriteriaListLimit() {
		return maxRuleRouteCriteriaListLimit;
	}

	public void setMaxRuleRouteCriteriaListLimit(int maxRuleRouteCriteriaListLimit) {
		this.maxRuleRouteCriteriaListLimit = maxRuleRouteCriteriaListLimit;
	}

	public List<String> getCollectionList() {
		return collectionList;
	}

	public void setCollectionList(List<String> collectionList) {
		this.collectionList = collectionList;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public int getWsMaxInquiryProcessLimit() {
		return wsMaxInquiryProcessLimit;
	}

	public void setWsMaxInquiryProcessLimit(int wsMaxInquiryProcessLimit) {
		this.wsMaxInquiryProcessLimit = wsMaxInquiryProcessLimit;
	}

	public String getBroadcastUserSpecificInquiry() {
		return broadcastUserSpecificInquiry;
	}

	public void setBroadcastUserSpecificInquiry(String broadcastUserSpecificInquiry) {
		this.broadcastUserSpecificInquiry = broadcastUserSpecificInquiry;
	}

	public String getCurrentReleaseDocumentName() {
		return currentReleaseDocumentName;
	}

	public void setCurrentReleaseDocumentName(String currentReleaseDocumentName) {
		this.currentReleaseDocumentName = currentReleaseDocumentName;
	}

	public List<String> getDomains() {
		return domains;
	}

	public void setDomains(List<String> domains) {
		this.domains = domains;
	}

	public int getS3ThreadCount() {
		return S3ThreadCount;
	}

	public void setS3ThreadCount(int s3ThreadCount) {
		S3ThreadCount = s3ThreadCount;
	}

	public int getS3InquiryBatchlimit() {
		return S3InquiryBatchlimit;
	}

	public void setS3InquiryBatchlimit(int s3InquiryBatchlimit) {
		S3InquiryBatchlimit = s3InquiryBatchlimit;
	}

	public boolean isSmartRoutingRuleEnabled() {
		return isSmartRoutingRuleEnabled;
	}

	public void setSmartRoutingRuleEnabled(boolean isSmartRoutingRuleEnabled) {
		this.isSmartRoutingRuleEnabled = isSmartRoutingRuleEnabled;
	}

	public int getWsMaxWorkflowIgnoreLimit() {
		return wsMaxWorkflowIgnoreLimit;
	}

	public void setWsMaxWorkflowIgnoreLimit(int wsMaxWorkflowIgnoreLimit) {
		this.wsMaxWorkflowIgnoreLimit = wsMaxWorkflowIgnoreLimit;
	}

	public long getWsServerLatencyInMs() {
		return wsServerLatencyInMs;
	}

	public void setWsServerLatencyInMs(long wsServerLatencyInMs) {
		this.wsServerLatencyInMs = wsServerLatencyInMs;
	}

	/**
	 * @return the userNotificationMaxBatchSize
	 */
	public int getUserNotificationMaxBatchSize() {
		return userNotificationMaxBatchSize;
	}

	/**
	 * @param userNotificationMaxBatchSize the userNotificationMaxBatchSize to set
	 */
	public void setUserNotificationMaxBatchSize(int userNotificationMaxBatchSize) {
		this.userNotificationMaxBatchSize = userNotificationMaxBatchSize;
	}

	public int getS3HandlingWeekOldData() {
		return S3HandlingWeekOldData;
	}

	public void setS3HandlingWeekOldData(int s3HandlingWeekOldData) {
		S3HandlingWeekOldData = s3HandlingWeekOldData;
	}

	public Date getNetezzaJobUserActivitiesLastLoadTime() {
		return netezzaJobUserActivitiesLastLoadTime;
	}

	public void setNetezzaJobUserActivitiesLastLoadTime(Date netezzaJobUserActivitiesLastLoadTime) {
		this.netezzaJobUserActivitiesLastLoadTime = netezzaJobUserActivitiesLastLoadTime;
	}

	public Date getNetezzaJobActionStatisticsLastLoadTime() {
		return netezzaJobActionStatisticsLastLoadTime;
	}

	public void setNetezzaJobActionStatisticsLastLoadTime(Date netezzaJobActionStatisticsLastLoadTime) {
		this.netezzaJobActionStatisticsLastLoadTime = netezzaJobActionStatisticsLastLoadTime;
	}

	/**
	 * @return the feedbackDlId
	 */
	public String getFeedbackDlId() {
		return feedbackDlId;
	}

	/**
	 * @param feedbackDlId the feedbackDlId to set
	 */
	public void setFeedbackDlId(String feedbackDlId) {
		this.feedbackDlId = feedbackDlId;
	}

	public List<String> getCitiDomains() {
		return citiDomains;
	}

	/**
	 * @param citiDomains the citiDomains to set
	 */
	public void setCitiDomains(List<String> citiDomains) {
		this.citiDomains = citiDomains;
	}

	/**
	 * @return the highlevelReqestTypes
	 */
	public List<String> getHighlevelReqestTypes() {
		return highlevelReqestTypes;
	}

	/**
	 * @param highlevelReqestTypes the highlevelReqestTypes to set
	 */
	public void setHighlevelReqestTypes(List<String> highlevelReqestTypes) {
		this.highlevelReqestTypes = highlevelReqestTypes;
	}

	/**
	 * @return the highlevelRequestTypeFlag
	 */
	public boolean isHighlevelRequestTypeFlag() {
		return highlevelRequestTypeFlag;
	}

	/**
	 * @param highlevelRequestTypeFlag the highlevelRequestTypeFlag to set
	 */
	public void setHighlevelRequestTypeFlag(boolean highlevelRequestTypeFlag) {
		this.highlevelRequestTypeFlag = highlevelRequestTypeFlag;
	}

	public List<KeyValue> getMsExchangeServerConfigList() {
		return msExchangeServerConfigList;
	}

	public void setMsExchangeServerConfigList(List<KeyValue> msExchangeServerConfigList) {
		this.msExchangeServerConfigList = msExchangeServerConfigList;
	}

	/**
	 * @return the nlpConfiguration
	 */
	public Map<String, Object> getNlpConfiguration() {
		return nlpConfiguration;
	}

	/**
	 * @param nlpConfiguration the nlpConfiguration to set
	 */
	public void setNlpConfiguration(Map<String, Object> nlpConfiguration) {
		this.nlpConfiguration = nlpConfiguration;
	}

	/**
	 * Sets provided key value in current object
	 * 
	 * @param key
	 * @param value
	 */
	public void setNlpConfigurationField(String key, Object value) {
		this.getNlpConfiguration().put(key, value);
	}

	/**
	 * Gets value for the provided key
	 * 
	 * @param key
	 * @return
	 */
	public Object setNlpConfigurationField(String key) {
		return this.getNlpConfiguration().get(key);
	}

	public List<KeyValue> getMsExchangeServerConfigParallel() {
		return msExchangeServerConfigParallel;
	}

	public void setMsExchangeServerConfigParallel(List<KeyValue> msExchangeServerConfigParallel) {
		this.msExchangeServerConfigParallel = msExchangeServerConfigParallel;
	}

	/**
	 * @return
	 */
	public Map<String, List<String>> getAutoFwdDLsMappings() {
		return autoFwdDLsMappings;
	}

	/**
	 * @param autoFwdDLsMappings the autoFwdDLsMappings to set
	 */
	public void setAutoFwdDLsMappings(Map<String, List<String>> autoFwdDLsMappings) {
		this.autoFwdDLsMappings = autoFwdDLsMappings;
	}

	/**
	 * @return the cmcConfiguration
	 */
	public Map<String, Object> getCmcConfiguration() {
		return cmcConfiguration;
	}

	/**
	 * @param cmcConfiguration the cmcConfiguration to set
	 */
	public void setCmcConfiguration(Map<String, Object> cmcConfiguration) {
		this.cmcConfiguration = cmcConfiguration;
	}

	/**
	 * @return the appConfig
	 */
	public List<ClientAuthorization> getAppConfig() {
		return appConfig;
	}

	/**
	 * @param appConfig the appConfig to set
	 */
	public void setAppConfig(List<ClientAuthorization> appConfig) {
		this.appConfig = appConfig;
	}

	/**
	 * @return the registeredAPIConfig
	 */
	public Map<String, Object> getRegisteredAPIConfig() {
		return registeredAPIConfig;
	}

	/**
	 * @param registeredAPIConfig the registeredAPIConfig to set
	 */
	public void setRegisteredAPIConfig(Map<String, Object> registeredAPIConfig) {
		this.registeredAPIConfig = registeredAPIConfig;
	}

	public Map<String, Object> getMongoToNetezaConfiguration() {
		return mongoToNetezaConfiguration;
	}

	public void setMongoToNetezaConfiguration(Map<String, Object> mongoToNetezaConfiguration) {
		this.mongoToNetezaConfiguration = mongoToNetezaConfiguration;
	}

	public Map<String, Object> getIsgCloudHolidaysConfig() {
		return isgCloudHolidaysConfig;
	}

	public void setAutoFwdEnabled(boolean autoFwdEnabled) {
		this.autoFwdEnabled = autoFwdEnabled;
	}

	public Map<String, Object> getQmaStormConfig() {
		return qmaStormConfig;
	}

	public void setQmaStormConfig(Map<String, Object> qmaStormConfig) {
		this.qmaStormConfig = qmaStormConfig;
	}

	public Map<String, Object> getClcConfiguration() {
		return clcConfiguration;
	}

	public void setClcConfiguration(Map<String, Object> clcConfiguration) {
		this.clcConfiguration = clcConfiguration;
	}

	public Map<String, Object> getOasysPaymentProcessingConfig() {
		return oasysPaymentProcessingConfig;
	}

	public void setOasysPaymentProcessingConfig(Map<String, Object> oasysPaymentProcessingConfig) {
		this.oasysPaymentProcessingConfig = oasysPaymentProcessingConfig;
	}

	/**
	 * @return the timeZones
	 */
	public List<TimeZone> getTimeZones() {
		return timeZones;
	}

	/**
	 * @param timeZones the timeZones to set
	 */
	public void setTimeZones(List<TimeZone> timeZones) {
		this.timeZones = timeZones;
	}

	public List<String> getMisExclusionReports() {
		return misExclusionReports;
	}

	public void setMisExclusionReports(List<String> misExclusionReports) {
		this.misExclusionReports = misExclusionReports;
	}

	public List<String> getMisExclusionReasons() {
		return misExclusionReasons;
	}

	public void setMisExclusionReasons(List<String> misExclusionReasons) {
		this.misExclusionReasons = misExclusionReasons;
	}

	public List<String> getCorsWhiteListedUrls() {
		return corsWhiteListedUrls;
	}

	public void setCorsWhiteListedUrls(List<String> corsWhiteListedUrls) {
		this.corsWhiteListedUrls = corsWhiteListedUrls;
	}

	public List<String> getWhiteListedServers() {
		return whiteListedServers;
	}

	public void setWhiteListedServers(List<String> whiteListedServers) {
		this.whiteListedServers = whiteListedServers;
	}

	public List<String> getApiExclusionList() {
		return apiExclusionList;
	}

	public void setApiExclusionList(List<String> apiExclusionList) {
		this.apiExclusionList = apiExclusionList;
	}

	public String getZipFileTempDownloadPath() {
		return zipFileTempDownloadPath;
	}

	public void setZipFileTempDownloadPath(String zipFileTempDownloadPath) {
		this.zipFileTempDownloadPath = zipFileTempDownloadPath;
	}

	public List<Map<String, Object>> getMasterColumnDefAgGrid() {
		return masterColumnDefAgGrid;
	}

	public void setMasterColumnDefAgGrid(List<Map<String, Object>> masterColumnDefAgGrid) {
		this.masterColumnDefAgGrid = masterColumnDefAgGrid;
	}

	public List<Map<String, Object>> getMasterColumnDefIndividual() {
		return masterColumnDefIndividual;
	}

	public void setMasterColumnDefIndividual(List<Map<String, Object>> masterColumnDefIndividual) {
		this.masterColumnDefIndividual = masterColumnDefIndividual;
	}

	public List<String> getDefaultViewsForMailboxStats() {
		return defaultViewsForMailboxStats;
	}

	public void setDefaultViewsForMailboxStats(List<String> defaultViewsForMailboxStats) {
		this.defaultViewsForMailboxStats = defaultViewsForMailboxStats;
	}

	public List<String> getDefaultViewNames() {
		return defaultViewNames;
	}

	public void setDefaultViewNames(List<String> defaultViewNames) {
		this.defaultViewNames = defaultViewNames;
	}

	public String getTinyMCEUrl() {
		return tinyMCEUrl;
	}

	public void setTinyMCEUrl(String tinyMCEUrl) {
		this.tinyMCEUrl = tinyMCEUrl;
	}

	public Date getNetezzaJobMessageSnapshotLastLoadTime() {
		return netezzaJobMessageSnapshotLastLoadTime;
	}

	public void setNetezzaJobMessageSnapshotLastLoadTime(Date netezzaJobMessageSnapshotLastLoadTime) {
		this.netezzaJobMessageSnapshotLastLoadTime = netezzaJobMessageSnapshotLastLoadTime;
	}

	public Map<String, Object> getCvWebsocketConfig() {
		return cvWebsocketConfig;
	}

	public void setCvWebsocketConfig(Map<String, Object> cvWebsocketConfig) {
		this.cvWebsocketConfig = cvWebsocketConfig;
	}


	public Map<String, Object> getClientMappingOCRMConfig() {
		return clientMappingOCRMConfig;
	}

	public void setClientMappingOCRMConfig(Map<String, Object> clientMappingOCRMConfig) {
		this.clientMappingOCRMConfig = clientMappingOCRMConfig;
	}

	public Map<String, Object> getMsgSnapshotConfig() {
		return msgSnapshotConfig;
	}

	public void setMsgSnapshotConfig(Map<String, Object> msgSnapshotConfig) {
		this.msgSnapshotConfig = msgSnapshotConfig;
	}

	public String getMsgSnapshotPurgeLimitInDays() {
		return msgSnapshotPurgeLimitInDays;
	}

	public void setMsgSnapshotPurgeLimitInDays(String msgSnapshotPurgeLimitInDays) {
		this.msgSnapshotPurgeLimitInDays = msgSnapshotPurgeLimitInDays;
	}

	public int getMsgThreadCount() {
		return msgThreadCount;
	}

	public void setMsgThreadCount(int msgThreadCount) {
		this.msgThreadCount = msgThreadCount;
	}

	public int getMsgBatchlimit() {
		return msgBatchlimit;
	}

	public void setMsgBatchlimit(int msgBatchlimit) {
		this.msgBatchlimit = msgBatchlimit;
	}

	public Map<String, Object> getSmartOracleConnectionConfig() {
		return smartOracleConnectionConfig;
	}

	public void setSmartOracleConnectionConfig(Map<String, Object> smartOracleConnectionConfig) {
		this.smartOracleConnectionConfig = smartOracleConnectionConfig;
	}

	public Map<String, Object> getQmaUI2Config() {
		return qmaUI2Config;
	}

	public void setQmaUI2Config(Map<String, Object> qmaUI2Config) {
		this.qmaUI2Config = qmaUI2Config;
	}

	/**
	 * @return the inquiryScheduleConfig
	 */
	public Map<String, Object> getInquiryScheduleConfig() {
		return inquiryScheduleConfig;
	}

	/**
	 * @param inquiryScheduleConfig the inquiryScheduleConfig to set
	 */
	public void setInquiryScheduleConfig(Map<String, Object> inquiryScheduleConfig) {
		this.inquiryScheduleConfig = inquiryScheduleConfig;
	}

	public List<KeyValue> getQueryListOracle() {
		return queryListOracle;
	}

	public void setQueryListOracle(List<KeyValue> queryListOracle) {
		this.queryListOracle = queryListOracle;
	}

	public boolean isDisableUserOrgDisplay() {
		return disableUserOrgDisplay;
	}

	public void setDisableUserOrgDisplay(boolean disableUserOrgDisplay) {
		this.disableUserOrgDisplay = disableUserOrgDisplay;
	}

	public Date getClientPriorityFromDate() {
		return clientPriorityFromDate;
	}

	public void setClientPriorityFromDate(Date clientPriorityFromDate) {
		this.clientPriorityFromDate = clientPriorityFromDate;
	}

	public Map<String, Object> getDefaultViewPerformanceConfig() {
		return defaultViewPerformanceConfig;
	}

	public void setDefaultViewPerformanceConfig(Map<String, Object> defaultViewPerformanceConfig) {
		this.defaultViewPerformanceConfig = defaultViewPerformanceConfig;
	}

	public String getAppServerContext() {
		return appServerContext;
	}

	public void setAppServerContext(String appServerContext) {
		this.appServerContext = appServerContext;
	}

	public Map<String, Object> getGlobalDirectoryConfig() {
		return globalDirectoryConfig;
	}

	public void setGlobalDirectoryConfig(Map<String, Object> globalDirectoryConfig) {
		this.globalDirectoryConfig = globalDirectoryConfig;
	}

	public boolean isGroupReportWithGlobalDirSync() {
		return groupReportWithGlobalDirSync;
	}

	public void setGroupReportWithGlobalDirSync(boolean groupReportWithGlobalDirSync) {
		this.groupReportWithGlobalDirSync = groupReportWithGlobalDirSync;
	}

	public Map<String, Object> getSymphonyConfig() {
		return symphonyConfig;
	}

	public void setSymphonyConfig(Map<String, Object> symphonyConfig) {
		this.symphonyConfig = symphonyConfig;
	}

	public Map<String, Object> getArchivalConfig() {
		return archivalConfig;
	}

	public void setArchivalConfig(Map<String, Object> archivalConfig) {
		this.archivalConfig = archivalConfig;
	}

	public Map<String, Object> getGdprConfig() {
		return gdprConfig;
	}

	public void setGdprConfig(Map<String, Object> gdprConfig) {
		this.gdprConfig = gdprConfig;
	}

	public Map<String, Object> getAttachmentPurgeConfig() {
		return attachmentPurgeConfig;
	}

	public void setAttachmentPurgeConfig(Map<String, Object> attachmentPurgeConfig) {
		this.attachmentPurgeConfig = attachmentPurgeConfig;
	}

	public Map<String, Object> getBccMailBoxConfig() {
		return bccMailBoxConfig;
	}

	public void setBccMailBoxConfig(Map<String, Object> bccMailBoxConfig) {
		this.bccMailBoxConfig = bccMailBoxConfig;
	}

	public Map<String, Object> getDedicatedMailBoxConfig() {
		return dedicatedMailBoxConfig;
	}

	public void setDedicatedMailBoxConfig(Map<String, Object> dedicatedMailBoxConfig) {
		this.dedicatedMailBoxConfig = dedicatedMailBoxConfig;
	}

	public Map<String, Object> getQmaPersonalConfig() {
		return qmaPersonalConfig;
	}

	public void setQmaPersonalConfig(Map<String, Object> qmaPersonalConfig) {
		this.qmaPersonalConfig = qmaPersonalConfig;
	}

	public Map<String, Object> getQmaIndividualFolderConfig() {
		return qmaIndividualFolderConfig;
	}

	public void setQmaIndividualFolderConfig(Map<String, Object> qmaIndividualFolderConfig) {
		this.qmaIndividualFolderConfig = qmaIndividualFolderConfig;
	}

	public Map<String, Object> getCimsConfig() {
		return cimsConfig;
	}

	public void setCimsConfig(Map<String, Object> cimsConfig) {
		this.cimsConfig = cimsConfig;
	}

	public Map<String, Object> getDbStatsConfig() {
		return dbStatsConfig;
	}

	public void setDbStatsConfig(Map<String, Object> dbStatsConfig) {
		this.dbStatsConfig = dbStatsConfig;
	}

	public Map<String, Object> getSessionConfig() {
		return sessionConfig;
	}

	public void setSessionConfig(Map<String, Object> sessionConfig) {
		this.sessionConfig = sessionConfig;
	}

	public Map<String, Object> getCommUniFlowConfig() {
		return commUniFlowConfig;
	}

	public void setCommUniFlowConfig(Map<String, Object> commUniFlowConfig) {
		this.commUniFlowConfig = commUniFlowConfig;
	}
	/**
	 * @return the isgCloudAmcarConfig
	 */
	public Map<String, Object> getIsgCloudAmcarConfig() {
		return isgCloudAmcarConfig;
	}

	/**
	 * @param isgCloudAmcarConfig the isgCloudAmcarConfig to set
	 */
	public void setIsgCloudAmcarConfig(Map<String, Object> isgCloudAmcarConfig) {
		this.isgCloudAmcarConfig = isgCloudAmcarConfig;
	}

	/**
	 * @return the isgCloudAmcConfig
	 */
	public Map<String, Object> getIsgCloudAmcConfig() {
		return isgCloudAmcConfig;
	}

	/**
	 * @param isgCloudAmcConfig the isgCloudAmcConfig to set
	 */
	public void setIsgCloudAmcConfig(Map<String, Object> isgCloudAmcConfig) {
		this.isgCloudAmcConfig = isgCloudAmcConfig;
	}
	
	public Map<String, Object> getWsSimulatorConfig() {
		return wsSimulatorConfig;
	}

	public void setWsSimulatorConfig(Map<String, Object> wsSimulatorConfig) {
		this.wsSimulatorConfig = wsSimulatorConfig;
	}

	public Map<String, Object> getQma2RedirectPopupConfig() {
		return qma2RedirectPopupConfig;
	}

	public void setQma2RedirectPopupConfig(Map<String, Object> qma2RedirectPopupConfig) {
		this.qma2RedirectPopupConfig = qma2RedirectPopupConfig;
	}

	/**
	 * @return the isgCloudPmmConfig
	 */
	public Map<String, Object> getIsgCloudPmmConfig() {
		return isgCloudPmmConfig;
	}

	/**
	 * @param isgCloudPmmConfig the isgCloudPmmConfig to set
	 */
	public void setIsgCloudPmmConfig(Map<String, Object> isgCloudPmmConfig) {
		this.isgCloudPmmConfig = isgCloudPmmConfig;
	}

	public Map<String, Object> getUiConsoleLogConfig() {
		return uiConsoleLogConfig;
	}

	public void setUiConsoleLogConfig(Map<String, Object> uiConsoleLogConfig) {
		this.uiConsoleLogConfig = uiConsoleLogConfig;
	}

	public Map<String, Object> getQmaHazelcastCacheConfig() {
		return qmaHazelcastCacheConfig;
	}

	public void setQmaHazelcastCacheConfig(Map<String, Object> qmaHazelcastCacheConfig) {
		this.qmaHazelcastCacheConfig = qmaHazelcastCacheConfig;
	}

	public boolean isPivotProConfigEnabled() {
		return pivotProConfigEnabled;
	}

	public void setPivotProConfigEnabled(boolean pivotProConfigEnabled) {
		this.pivotProConfigEnabled = pivotProConfigEnabled;
	}

public List <String> getXmcExportDlConfigList() {
		return xmcExportDlConfigList;
	}

	public void setXmcExportDlConfigList(List <String> xmcExportDlConfigList) {
		this.xmcExportDlConfigList = xmcExportDlConfigList;
	}

	public String getXmcExportDlPath() {
		return xmcExportDlPath;
	}

	public void setXmcExportDlPath(String xmcExportDlPath) {
		this.xmcExportDlPath = xmcExportDlPath;
	}
	public String getQesKey() {
		return qesKey;
	}
	public Map<String, Object> getEncryptionConfig() {
		return encryptionConfig;
	}

	public void setEncryptionConfig(Map<String, Object> encryptionConfig) {
		this.encryptionConfig = encryptionConfig;
	}

	public Map<String, Object> getAimlProcessingConfig() {
		return aimlProcessingConfig;
	}

	public void setAimlProcessingConfig(Map<String, Object> aimlProcessingConfig) {
		this.aimlProcessingConfig = aimlProcessingConfig;
	}

	public String getXmcLastBatchRunId() {
		return xmcLastBatchRunId;
	}

	public void setXmcLastBatchRunId(String xmcLastBatchRunId) {
		this.xmcLastBatchRunId = xmcLastBatchRunId;
	}

	public String getXmcLastBatchRunSuccess() {
		return xmcLastBatchRunSuccess;
	}

	public void setXmcLastBatchRunSuccess(String xmcLastBatchRunSuccess) {
		this.xmcLastBatchRunSuccess = xmcLastBatchRunSuccess;
	}

	public Date getXmcLastRunStartDate() {
		return xmcLastRunStartDate;
	}

	public void setXmcLastRunStartDate(Date xmcLastRunStartDate) {
		this.xmcLastRunStartDate = xmcLastRunStartDate;
	}

	public Date getXmcLastRunEndDate() {
		return xmcLastRunEndDate;
	}

	public void setXmcLastRunEndDate(Date xmcLastRunEndDate) {
		this.xmcLastRunEndDate = xmcLastRunEndDate;
	}

	public List<Long> getReportDLExclusionList() {
		return reportDLExclusionList;
	}

	public void setReportDLExclusionList(List<Long> reportDLExclusionList) {
		this.reportDLExclusionList = reportDLExclusionList;
	}

	public List<String> getStripHtmlStyleList() {
		return stripHtmlStyleList;
	}

	public void setStripHtmlStyleList(List<String> stripHtmlStyleList) {
		this.stripHtmlStyleList = stripHtmlStyleList;
	}
	
	public Map<String, Object> getS3ContentArchivalConfig() {
		return s3ContentArchivalConfig;
	}

	public void setS3ContentArchivalConfig(Map<String, Object> s3ContentArchivalConfig) {
		this.s3ContentArchivalConfig = s3ContentArchivalConfig;
	}

	public Map<String, Object> getS3BucketConfig() {
		return s3BucketConfig;
	}

	public void setS3BucketConfig(Map<String, Object> s3BucketConfig) {
		this.s3BucketConfig = s3BucketConfig;
	}

	public List<String> getInquirySubStatusList() {
		return inquirySubStatusList;
	}

	public void setInquirySubStatusList(List<String> inquirySubStatusList) {
		this.inquirySubStatusList = inquirySubStatusList;
	}

	public boolean isEnableInquirySubStatusFlag() {
		return enableInquirySubStatusFlag;
	}

	public void setEnableInquirySubStatusFlag(boolean enableInquirySubStatusFlag) {
		this.enableInquirySubStatusFlag = enableInquirySubStatusFlag;
	}

	public String getFullRefreshUrl() {
		return fullRefreshUrl;
	}

	public void setFullRefreshUrl(String fullRefreshUrl) {
		this.fullRefreshUrl = fullRefreshUrl;
	}

	public Map<String, Object> getTCLConfiguration() {
		return TCLConfiguration;
	}

	public void setTCLConfiguration(Map<String, Object> tCLConfiguration) {
		TCLConfiguration = tCLConfiguration;
	}

	public Map<Long, String> getBrazilFxDlMap() {
		return brazilFxDlMap;
	}

	public void setBrazilFxDlMap(Map<Long, String> brazilFxDlMap) {
		this.brazilFxDlMap = brazilFxDlMap;
	}
	
	public List<String> getBrazilSubscribedSenderDomains() {
		return brazilSubscribedSenderDomains;
	}

	public void setBrazilSubscribedSenderDomains(List<String> brazilSubscribedSenderDomains) {
		this.brazilSubscribedSenderDomains = brazilSubscribedSenderDomains;
	}

	public Map<String, String> getBrazilRequestType() {
		return brazilRequestType;
	}

	public void setBrazilRequestType(Map<String, String> brazilRequestType) {
		this.brazilRequestType = brazilRequestType;
	}
	

	public Map<String, Object> getSolrCertConfig() {
		return solrCertConfig;
	}

	public void setSolrCertConfig(Map<String, Object> solrCertConfig) {
		this.solrCertConfig = solrCertConfig;
	}


	public Map<String, Object> getSmartSearchConfig() {
		return smartSearchConfig;
	}

	public void setSmartSearchConfig(Map<String, Object> smartSearchConfig) {
		this.smartSearchConfig = smartSearchConfig;
	}
	
	public Map<String, Object> getideationConfig() {
		return ideationConfig;
	}
	public void setideationConfig(Map<String, Object> ideationConfig) {
		this.ideationConfig = ideationConfig;
	}
	

	public Map<String, String> getClientIdToClientNameMap() {
		return clientIdToClientNameMap;
	}

	public void setClientIdToClientNameMap(Map<String, String> clientIdToClientNameMap) {
		this.clientIdToClientNameMap = clientIdToClientNameMap;
	}

	public String getQmaServiceURL() {
		return qmaServiceURL;
	}

	public void setQmaServiceURL(String qmaServiceURL) {
		this.qmaServiceURL = qmaServiceURL;
	}

	public Map<String, Long> getProductFamilyGroupIdMap() {
		return productFamilyGroupIdMap;
	}

	public void setProductFamilyGroupIdMap(Map<String, Long> productFamilyGroupIdMap) {
		this.productFamilyGroupIdMap = productFamilyGroupIdMap;
	}

	public Map<String, Object> getBrazilFxConfig() {
		return brazilFxConfig;
	}

	public void setBrazilFxConfig(Map<String, Object> brazilFxConfig) {
		this.brazilFxConfig = brazilFxConfig;
	}

	public String getMessageBusPublisherURL() {
		return messageBusPublisherURL;
	}

	public void setMessageBusPublisherURL(String messageBusPublisherURL) {
		this.messageBusPublisherURL = messageBusPublisherURL;
	}

	public String getEnableBrazilFxIntegration() {
		return enableBrazilFxIntegration;
	}

	public void setEnableBrazilFxIntegration(String enableBrazilFxIntegration) {
		this.enableBrazilFxIntegration = enableBrazilFxIntegration;
	}

	public Map<String, Set<String>> getSearchKeywordToClientIdBaseNoMap() {
		return searchKeywordToClientIdBaseNoMap;
	}

	public void setSearchKeywordToClientIdBaseNoMap(Map<String, Set<String>> searchKeywordToClientIdBaseNoMap) {
		this.searchKeywordToClientIdBaseNoMap = searchKeywordToClientIdBaseNoMap;
	}

	public Map<String, Set<String>> getSenderDomainToClientIdBaseNoMap() {
		return senderDomainToClientIdBaseNoMap;
	}

	public void setSenderDomainToClientIdBaseNoMap(Map<String, Set<String>> senderDomainToClientIdBaseNoMap) {
		this.senderDomainToClientIdBaseNoMap = senderDomainToClientIdBaseNoMap;
	}

	public Map<String, Set<String>> getClientIdToSearchKeywordMap() {
		return clientIdToSearchKeywordMap;
	}

	public void setClientIdToSearchKeywordMap(Map<String, Set<String>> clientIdToSearchKeywordMap) {
		this.clientIdToSearchKeywordMap = clientIdToSearchKeywordMap;
	}

	public Map<String, Set<String>> getClientIdToBaseNoMap() {
		return clientIdToBaseNoMap;
	}

	public void setClientIdToBaseNoMap(Map<String, Set<String>> clientIdToBaseNoMap) {
		this.clientIdToBaseNoMap = clientIdToBaseNoMap;
	}

	public boolean isEnableContentMatch() {
		return enableContentMatch;
	}

	public void setEnableContentMatch(boolean enableContentMatch) {
		this.enableContentMatch = enableContentMatch;
	}
	
	public Integer getS3ArchiveNoOfDays() {
		return s3ArchiveNoOfDays;
	}

	public void setS3ArchiveNoOfDays(Integer s3ArchiveNoOfDays) {
		this.s3ArchiveNoOfDays = s3ArchiveNoOfDays;
	}

	public Integer getS3ArchiveNoOfDaysRange() {
		return s3ArchiveNoOfDaysRange;
	}

	public void setS3ArchiveNoOfDaysRange(Integer s3ArchiveNoOfDaysRange) {
		this.s3ArchiveNoOfDaysRange = s3ArchiveNoOfDaysRange;
	}

	public Map<String, Object> getMessageBusConfigMap() {
		return messageBusConfigMap;
	}

	public void setMessageBusConfigMap(Map<String, Object> messageBusConfigMap) {
		this.messageBusConfigMap = messageBusConfigMap;
	}

	public String getEnableManualDeLinkEntity() {
		return enableManualDeLinkEntity;
	}

	public void setEnableManualDeLinkEntity(String enableManualDeLinkEntity) {
		this.enableManualDeLinkEntity = enableManualDeLinkEntity;
	}

	public String getEnableManualLinkEntity() {
		return enableManualLinkEntity;
	}

	public void setEnableManualLinkEntity(String enableManualLinkEntity) {
		this.enableManualLinkEntity = enableManualLinkEntity;
	}

	public Map<String, Object> getAuthConfig() {
		return authConfig;
	}

	public void setAuthConfig(Map<String, Object> authConfig) {
		this.authConfig = authConfig;
	}

	public Map<String, Object> getEmailThreadConfig() {
		return emailThreadConfig;
	}

	public void setEmailThreadConfig(Map<String, Object> emailThreadConfig) {
		this.emailThreadConfig = emailThreadConfig;
	}

	public Integer getSearchInDays() {
		return searchInDays;
	}

	public void setSearchInDays(Integer searchInDays) {
		this.searchInDays = searchInDays;
	}

	public Map<String, Object> getMessageReplayConfig() {
		return messageReplayConfig;
	}

	public void setMessageReplayConfig(Map<String, Object> messageReplayConfig) {
		this.messageReplayConfig = messageReplayConfig;
	}

	public Map<String, Object> getTaskizeConfig() {
		return taskizeConfig;
	}

	public void setTaskizeConfig(Map<String, Object> taskizeConfig) {
		this.taskizeConfig = taskizeConfig;
	}
	
	public List<TaskizeParticipantsContactMapping> getTaskizeParticipantsContactMapping() {
		return taskizeParticipantsContactMapping;
	}

	public void setTaskizeParticipantsContactMapping(
			List<TaskizeParticipantsContactMapping> taskizeParticipantsContactMapping) {
		this.taskizeParticipantsContactMapping = taskizeParticipantsContactMapping;
	}

	public Map<String, Object> getXssListConfig() {
		return xssListConfig;
	}

	public void setXssListConfig(Map<String, Object> xssListConfig) {
		this.xssListConfig = xssListConfig;
	}

	public Date getActionStatisticsLoadEndTime() {
		return actionStatisticsLoadEndTime;
	}

	public void setActionStatisticsLoadEndTime(Date actionStatisticsLoadEndTime) {
		this.actionStatisticsLoadEndTime = actionStatisticsLoadEndTime;
	}

	public Date getMessageSnapshotLoadEndDate() {
		return messageSnapshotLoadEndDate;
	}

	public void setMessageSnapshotLoadEndDate(Date messageSnapshotEndDate) {
		this.messageSnapshotLoadEndDate = messageSnapshotEndDate;
	}

	public Date getUserActivitiesLoadEndDate() {
		return userActivitiesLoadEndDate;
	}

	public void setUserActivitiesLoadEndDate(Date userActivitiesEndDate) {
		this.userActivitiesLoadEndDate = userActivitiesEndDate;
	}

	public boolean isPastfeedLoadEnabled() {
		return isPastfeedLoadEnabled;
	}

	public void setPastfeedLoadEnabled(boolean isPastfeedLoadEnabled) {
		this.isPastfeedLoadEnabled = isPastfeedLoadEnabled;
	}

	public Map<String, Object> getSsoOpsJobConfig() {
		return ssoOpsJobConfig;
	}

	public void setSsoOpsJobConfig(Map<String, Object> ssoOpsJobConfig) {
		this.ssoOpsJobConfig = ssoOpsJobConfig;
	}
	public List<String> getCustomKeywordsForAutoResponse() {
		return customKeywordsForAutoResponse;
	}

	public boolean isHazelcastSecondClusterConnectionConfig() {
		return hazelcastSecondClusterConnectionConfig;
	}

	public void setHazelcastSecondClusterConnectionConfig(boolean hazelcastSecondClusterConnectionConfig) {
		this.hazelcastSecondClusterConnectionConfig = hazelcastSecondClusterConnectionConfig;
	}	


	public String getNonInquiryAge() {
		return nonInquiryAge;
	}

	public void setNonInquiryAge(String nonInquiryAge) {
		this.nonInquiryAge = nonInquiryAge;
	}

	public String getWorkFlowDirection() {
		return workFlowDirection;
	}

	public void setWorkFlowDirection(String workFlowDirection) {
		this.workFlowDirection = workFlowDirection;
	}

	public List<Long> getGroupList() {
		return groupList;
	}

	public void setGroupList(List<Long> groupList) {
		this.groupList = groupList;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getUpdatedMessage() {
		return updatedMessage;
	}

	public void setUpdatedMessage(String updatedMessage) {
		this.updatedMessage = updatedMessage;
	}

	public void setCustomKeywordsForAutoResponse(List<String> customKeywordsForAutoResponse) {
		this.customKeywordsForAutoResponse = customKeywordsForAutoResponse;
	}

	public boolean isCustomAutoResponseEnabledForInternalDomain() {
		return isCustomAutoResponseEnabledForInternalDomain;
	}

	public void setCustomAutoResponseEnabledForInternalDomain(boolean isCustomAutoResponseEnabledForInternalDomain) {
		this.isCustomAutoResponseEnabledForInternalDomain = isCustomAutoResponseEnabledForInternalDomain;
	}

	public Long getLastProcessedConvId() {
		return lastProcessedConvId;
	}

	public void setLastProcessedConvId(Long lastProcessedConvId) {
		this.lastProcessedConvId = lastProcessedConvId;
	}
}
