package com.citi.icg.qma.common.core.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.persistence.CacheDAO;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

public class ZipUtil
{
	private static final Logger logger = LoggerFactory.getLogger(ZipUtil.class);

	private ZipUtil(){
		}
	
	// Zip File Name and List of files needs to be Zipped must be passed for this method.
	public static File createZipFile(String zipFileName, Map<String, File> fileMapToZip) throws CommunicatorException
	{
		File zipFile = null;
		FileOutputStream fos = null;
		ZipOutputStream zos = null;
		
		String filePath = getFilePath(zipFileName);
		try {
			zipFile = new File(filePath);
			if (!zipFile.exists()) {
				boolean isFileCreated = zipFile.createNewFile();
				if (isFileCreated) {
					logger.debug("New file created:" + filePath);
				}

				// create byte buffer
				byte[] buffer = new byte[1024];
				fos = getOutPutFile(filePath);
				zos = new ZipOutputStream(fos);
				for (Map.Entry<String,File> entry : fileMapToZip.entrySet()) {
					addToZip(buffer, zos, entry);
				}
				
				logger.info("Zip File " + filePath + " for src Files -" + fileMapToZip);
			}
		} catch (Exception e) {
			logger.error("Error while creating Zip File-" + filePath, e);
			throw new CommunicatorException("Error while creating Zip File-" + filePath, e);
		} finally {
			try {
				if (null != zos) {
					zos.close();
				}
				if (null != fos) {
					fos.close();
				}
			} catch (IOException e) {
				logger.error("Error while closing input/output stream:"+e);
			}

		}
		return zipFile;
	}
	public static File createZipFileForDownloadEmail(String zipFileName, Map<String, File> fileMapToZip) throws CommunicatorException
	{
		File zipFile = null;
		FileOutputStream fos = null;
		ZipOutputStream zos = null;
		
		try {
				
			zipFile = GenericUtility.createFile(zipFileName);
			if (!zipFile.exists()) {
				boolean isFileCreated = zipFile.createNewFile();
				if (isFileCreated) {
					logger.debug("New file created:" + zipFile.getAbsolutePath());
				}

				// create byte buffer
				byte[] buffer = new byte[1024];
				fos = getOutPutFile(zipFile.getAbsolutePath());
				zos = new ZipOutputStream(fos);
				for (Map.Entry<String,File> entry : fileMapToZip.entrySet()) {
					addToZip(buffer, zos, entry);
				}
				
				logger.info("Zip File " + zipFile.getAbsolutePath() + " for src Files -" + fileMapToZip);
			}
		} catch (Exception e) {
			logger.error("Error while creating Zip File - {}", (null == zipFile ? zipFile : zipFile.getAbsolutePath()), e);
			throw new CommunicatorException("Error while creating Zip File-" +(null == zipFile ? zipFile : zipFile.getAbsolutePath()), e);
		} finally {
			try {
				if (null != zos) {
					zos.close();
				}
				if (null != fos) {
					fos.close();
				}
			} catch (IOException e) {
				logger.warn("Error while closing input/output stream:"+e);
			}

		}
		return zipFile;
	}
	/**

	 * @param buffer
	 * @param zos
	 * @param entry
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 * Begin writing a new ZIP entry, positions the stream to the start of the entry data
	 */
	private static void addToZip(byte[] buffer, ZipOutputStream zos, Map.Entry<String, File> entry)
			throws IOException {
		logger.info("Start Method addToZip");
		try (FileInputStream fis = new FileInputStream(entry.getValue());) {
			zos.putNextEntry(new ZipEntry(entry.getKey()));
			int length;
			while ((length = fis.read(buffer)) > 0) {
				zos.write(buffer, 0, length);
			}
			zos.closeEntry();
			logger.info("End Method addToZip");
		}
	}

	/**
	 * @param filePath
	 * @return
	 * @throws FileNotFoundException
	 */
	private static FileOutputStream getOutPutFile(String filePath) throws FileNotFoundException {
		FileOutputStream fos;
		fos = new FileOutputStream(filePath);
		return fos;
	}

	/**
	 * get file path from config
	 * @param zipFileName
	 * @return
	 */
	private static String getFilePath(String zipFileName) {
		String filePath="";
		//CacheDAO cacheDAO = CacheDAO.getInstance();
		QMACache qmaCache = QMACacheFactory.getCache();
		if(null != qmaCache.getConfigById("zipFileTempDownloadPath")){
			filePath = qmaCache.getConfigById("zipFileTempDownloadPath").getZipFileTempDownloadPath();
			filePath = filePath + zipFileName;
		}
		return filePath;
	}

	/**
	 * This method will delete all temp downloaded files from server.
	 * @param fileMapToZip
	 * @param subLogger
	 */
	public static void deleteFileFromTemp(Map<String, File> fileMapToZip) {
		try {
			for (Map.Entry<String,File> entry : fileMapToZip.entrySet()) {
				entry.getValue().delete();
			}
			logger.info("File deleted from temp folder");
		} catch (Exception e) {
			logger.error("Error while deleting files from temp folder",e);
		}		
	}
	
	

}
