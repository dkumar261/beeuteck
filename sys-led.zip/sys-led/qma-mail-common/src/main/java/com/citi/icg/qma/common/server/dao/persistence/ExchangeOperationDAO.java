package com.citi.icg.qma.common.server.dao.persistence;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.ExchangeRecipient;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.dao.ExchangeEventType;
import com.citi.icg.qma.dao.MessageSnapshot;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class ExchangeOperationDAO {

    private static final Logger logger = LoggerFactory.getLogger(ExchangeOperationDAO.class);
    private static final InquiryDAO inquiryDao = new InquiryDAO();
    private static ExchangeOperationDAO instance = null;

    private static final String MARK_CURRENT_CONV_AS_READ_YES = "Y";
    private static final String MARK_CURRENT_CONV_AS_READ_NO = "N";
    public static final String RECIPIENT_FROM = "FROM";

    private ExchangeOperationDAO() {
    }

    public static synchronized ExchangeOperationDAO getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		if (instance == null) {
			instance = new ExchangeOperationDAO();
		}
        return instance;
    }


    public void updateConvReadUnreadTO(String readFlag, Inquiry inquiry, Conversation convToBeUpdated, String soeId, Long groupId,ExchangeEventType eventType) throws CommunicatorException {
        updateConvReadUnread(readFlag, inquiry, convToBeUpdated, soeId, groupId,eventType, false);
    }

    public void updateConvReadUnreadDB(String readFlag, Inquiry inquiry, Conversation convToBeUpdated, String soeId, Long groupId,ExchangeEventType eventType) throws CommunicatorException {
        updateConvReadUnread(readFlag, inquiry, convToBeUpdated, soeId, groupId,eventType, true);
    }


    public void updateInquiryReadUnreadTO(String readFlag, Inquiry inquiry, String soeId,ExchangeEventType eventType) throws CommunicatorException {
        updateInquiryReadUnread(readFlag, inquiry, soeId, eventType,false);
    }

    public void updateInquiryReadUnreadDB(String readFlag, Inquiry inquiry, String soeId,ExchangeEventType eventType) throws CommunicatorException {
        updateInquiryReadUnread(readFlag, inquiry, soeId, eventType,true);
    }

    private void updateConvReadUnread(String readFlag, Inquiry inquiry, Conversation convToBeUpdated, String soeId, Long groupId,ExchangeEventType eventType, boolean saveToDB) throws CommunicatorException {
        if (Objects.nonNull(inquiry) && Objects.nonNull(convToBeUpdated) && Objects.nonNull(groupId) && StringUtils.isNotEmpty(soeId)) {
            List<Long> groupIdList = new ArrayList<>();
            groupIdList.add(groupId);
            //int convLimitCount = QMACacheFactory.getCache().getConvLimitCountIndividual(); //TODO : implement conv count limit config in db for individual and remove below line
            int convLimitCount = 100;
            BasicDBObject inputObject = new BasicDBObject("hasNominatedOwnership", false);
            List<Conversation> convList = inquiryDao.getAllConversationsWithPaging(inquiry.getId(), groupIdList, convLimitCount, false, inputObject);
            if (null != convList && !convList.isEmpty()) {
                logger.info("Checking all the {} conversation(s) for the inquiry {} for user {} to mark as read/unread",convList.size(),inquiry.getId(),soeId);
            } else {
                logger.warn("No valid conversation(s) retrieved for Inq : {}, Group Id : {}, i.e. New inquiry getting created with new conversation ", inquiry.getId(), groupId);
            }
            updateConversationReadOrUnread(inquiry, convToBeUpdated, readFlag, soeId, convList,eventType, saveToDB);
        } else {
            logger.warn("Mandatory parameters required for marking inquiry conversation read/unread are not valid.");
        }
    }

    private void updateConversationReadOrUnread(Inquiry inquiry, Conversation convToBeUpdated, String readFlag, String readUnreadByUser,
                                                List<Conversation> dbConversationList,ExchangeEventType eventType,boolean saveToDB) {
        try {
            if (null != convToBeUpdated) {
                List<String> readBy = convToBeUpdated.getReadBy();
                if (null == readBy) {
                    readBy = new ArrayList<>();
                    convToBeUpdated.setReadBy(readBy);
                }
                if (MARK_CURRENT_CONV_AS_READ_YES.equalsIgnoreCase(readFlag) && !readBy.contains(readUnreadByUser)) {
                    readBy.add(readUnreadByUser);
                } else if (MARK_CURRENT_CONV_AS_READ_NO.equalsIgnoreCase(readFlag)) {
                    readBy.remove(readUnreadByUser);
                }
                logger.info("Conversation {} updated as read/unread ({}) by user {} for inquiry {}", convToBeUpdated.getId(),readFlag,readUnreadByUser,inquiry.getId());
                checkAndUpdateInquiry(readFlag, inquiry, convToBeUpdated, readUnreadByUser, dbConversationList,eventType, saveToDB);
            } else {
                logger.info("Conversation not available to be marked as read ({}) by user : {} ", readFlag, readUnreadByUser);
            }
        } catch (Exception e) {
            logger.warn("Exception while updating read ({}) for conv {} by user : {}", readFlag, convToBeUpdated, readUnreadByUser);
        }
    }


    private void updateInquiryReadUnread(String readFlag, Inquiry inquiry, String soeId,ExchangeEventType eventType, boolean saveToDB) {

        List<String> inquiryReadBy = inquiry.getReadBy();
        logger.info("Initial readyBy value for inquiry {} is : {} before updating it for user : {}", inquiry.getId(), inquiry.getReadBy(), soeId);
        if (Objects.isNull(inquiryReadBy)) {
            inquiryReadBy = new ArrayList<>();
            inquiry.setReadBy(inquiryReadBy);
        }
        logger.info("Updating current readBy : {}",inquiryReadBy);
        boolean isInquiryUpdateRequired = false;

        if (MARK_CURRENT_CONV_AS_READ_YES.equalsIgnoreCase(readFlag)) {
            if(!inquiryReadBy.contains(soeId)) {
                inquiryReadBy.add(soeId);
                isInquiryUpdateRequired=true;
            }
        } else if (MARK_CURRENT_CONV_AS_READ_NO.equalsIgnoreCase(readFlag)) {
            inquiryReadBy.remove(soeId);
            isInquiryUpdateRequired = true;
        }

        logger.info("Updated inquiryReadBy : {} for inquiry {} for user {} for event received : {}",inquiryReadBy,inquiry.getId(),soeId,eventType);
        inquiry.setReadBy(inquiryReadBy);
        if (saveToDB && isInquiryUpdateRequired ) {
            logger.info("Updating readBy as {} for inquiry : {} for user : {} for event : {} ", readFlag, inquiry.getId(),soeId,eventType);
            updateInquiryInDB(inquiry.getId(), inquiryReadBy);
        }
    }

    private void checkAndUpdateInquiry(String readFlag, Inquiry inquiry, Conversation convIdToBeUpdated, String readUnreadByUser,
                                       List<Conversation> dbConversationList,ExchangeEventType eventType, boolean saveToDB) {
        boolean isInquiryUpdateRequired = false;
        boolean isAnyConversationUnreadForInquiry = false;
        if(Objects.nonNull(dbConversationList) && !dbConversationList.isEmpty()) {
            for (Conversation conv : dbConversationList) {
                if(!conv.getId().equals(convIdToBeUpdated.getId())){
                    List<String> readBy = conv.getReadBy();
                    if (Objects.nonNull(readBy)) {
                        if (!readBy.contains(readUnreadByUser)) {
                            isAnyConversationUnreadForInquiry = true;
                            break;
                        }
                    } else {
                        logger.info("readBy does not exists for conversation : {} for inquiry : {}",conv.getId(),conv.getInquiryId());
                        isAnyConversationUnreadForInquiry = true;
                        break;
                    }
                } else {
                    logger.info("Skipping check for already updated actionConversation from processorTO and updating inquiry depending on read flag : {}", readFlag);
                    if (MARK_CURRENT_CONV_AS_READ_NO.equalsIgnoreCase(readFlag)) {
                        isAnyConversationUnreadForInquiry = true;
                        break;
                    }
                }

            }
        } else {
            logger.info("No conversation yet saved in database for current inquiry.");
            if (MARK_CURRENT_CONV_AS_READ_NO.equalsIgnoreCase(readFlag)) {
                isAnyConversationUnreadForInquiry = true;
            }
        }

        logger.info("isAnyConversationUnreadForInquiry : {} for user {} for inquiry : {} for event received : {} ",isAnyConversationUnreadForInquiry, readUnreadByUser,inquiry.getId(),eventType);

        List<String> inquiryReadBy = inquiry.getReadBy();
        logger.info("Initial readyBy value for inquiry : {} : {} before updating it for user : {} ", inquiry.getId(), inquiryReadBy, readUnreadByUser);
        if (Objects.isNull(inquiryReadBy)) {
            inquiryReadBy = new ArrayList<>();
            inquiry.setReadBy(inquiryReadBy);
        }
        if (Objects.nonNull(inquiryReadBy)) {
            logger.info("Updating current readBy : {}",inquiryReadBy);
            if (MARK_CURRENT_CONV_AS_READ_YES.equalsIgnoreCase(readFlag)) {
                //if conversation marked as read
                if(isAnyConversationUnreadForInquiry) {
                    //if any one of the conversation is unread and inquiry contains that user in readBy then remove the user from inquiry readBy
                    inquiryReadBy.remove(readUnreadByUser);
                    isInquiryUpdateRequired = true;
                    logger.info("One or more conversation(s) is unread by user : {} for inquiry : {}, hence updating inquiry unread by user.",readUnreadByUser,inquiry.getId());
                } else if (!inquiryReadBy.contains(readUnreadByUser)) {
                    //if all the conversations are read and inquiryReadBy does not contain that user then add it
                    inquiryReadBy.add(readUnreadByUser);
                    isInquiryUpdateRequired = true;
                    logger.info("All the conversations is read by user : {} for inquiry : {}, hence updating inquiry read by user.",readUnreadByUser,inquiry.getId());
                }
            } else if(MARK_CURRENT_CONV_AS_READ_NO.equalsIgnoreCase(readFlag)) {
                //if conversation is marked as unread, and if user present in inquiryReadBy, then remove the user.
                logger.info("Updating inquiry {} read/unread as : {} for user : {}",inquiry.getId(),readFlag,readUnreadByUser);
                inquiryReadBy.remove(readUnreadByUser);
                isInquiryUpdateRequired = true;
            }
            logger.info("Updated inquiryReadBy : {} for inquiry {} for user {} for event received : {}", inquiryReadBy,inquiry.getId(),readUnreadByUser,eventType);
            inquiry.setReadBy(inquiryReadBy);
        }

        if (saveToDB) {
            logger.info("Updating readBy for conversation : {}", convIdToBeUpdated.getId());
            updateConversationInDB(convIdToBeUpdated.getId(), convIdToBeUpdated.getReadBy());
            if (isInquiryUpdateRequired) {
                logger.info("Updating readBy for inquiry : {}", inquiry.getId());
                updateInquiryInDB(inquiry.getId(), inquiryReadBy);
            }
        }
    }

    /**
     * This method update conversation readBy in database.
     *
     * @param convId
     * @param readBy
     */
    private void updateConversationInDB(Long convId, List<String> readBy) {
        try {
            Query<Conversation> query = MongoDB.instance().getDataStore().createQuery(Conversation.class)
                    .filter("_id", convId);
            Conversation conv = query.first();
            if (null != conv) {
                UpdateOperations<Conversation> updateOps = MongoDB.instance().getDataStore().createUpdateOperations(Conversation.class);
                updateOps.set("readBy", readBy);
                MongoDB.instance().getDataStore().update(query, updateOps);
            }
        } catch (Exception e) {
            logger.warn("Exception while updating conversation readBy in db for conv : {} :", convId, e);
        }
    }

    /**
     * This method update inquiry readBy in database.
     *
     * @param inqId
     * @param readBy
     */
    private void updateInquiryInDB(Long inqId, List<String> readBy) {
        try {
            Query<Inquiry> query = MongoDB.instance().getDataStore().createQuery(Inquiry.class)
                    .filter("_id", inqId);
            Inquiry inq = query.first();
            if (null != inq) {
                UpdateOperations<Inquiry> updateOps = MongoDB.instance().getDataStore().createUpdateOperations(Inquiry.class);
                updateOps.set("readBy", readBy);
                MongoDB.instance().getDataStore().update(query, updateOps);
            }
        } catch (Exception e) {
            logger.warn("Exception while updating Inquiry readBy in db for inquiry : {} :", inqId, e);
        }
    }

    public void updateExchangeRecipients(Conversation actionConversation, MessageSnapshot messageSnapshot, String mailBox) {
        logger.info("Updating exchange metadata for Inquiry : {}, Conversation : {} for mailbox : {}", actionConversation.getInquiryId(), actionConversation.getId(), mailBox);
        List<Long> personalGrpIds = QMACacheFactory.getCache().getPersonalGroupIdList();

        Map<String, Long> personalMailboxIdToGroupIdMap = QMACacheFactory.getCache().getPersonalMailboxIdToGroupIdMap();

        // initialize exch recipients if not created
        List<ExchangeRecipient> exchRecipients = actionConversation.getExchangeRecipients();
        if (exchRecipients==null) {
            exchRecipients = new ArrayList<ExchangeRecipient>();
        }

        for (ConversationRecipient convRecipient : actionConversation.getRecipients()) {
            if (personalGrpIds.contains(convRecipient.getGroupId()) && !alreadyExistingExchangeRecipient(convRecipient.getGroupId(), exchRecipients)) {
                ExchangeRecipient exchRecipient = new ExchangeRecipient(convRecipient.getGroupId(), convRecipient.getUserId());
                exchRecipients.add(exchRecipient);
            }
        }
        actionConversation.setExchangeRecipients(exchRecipients);

        logger.info("Exchange recipients updated, currently contains {} exchange recipients ", exchRecipients.size());

        // update based on exchange event received
        // TODO : 1. handle permanent delete by personal conversation
        // TODO : 2: Use ConversationRecipient instead of ExchangeRecipient
        if (!exchRecipients.isEmpty()) {
            if (messageSnapshot.getExchEventType()!=null) {
                logger.info("Exchange Event Type : {}, Exchange folder : {}, Exchange Old Folder : {}",messageSnapshot.getExchEventType(), messageSnapshot.getExchFolder(),messageSnapshot.getExchOldFolder());
                if (ExchangeEventType.NewMail.equals(messageSnapshot.getExchEventType()) || ExchangeEventType.Created.equals(messageSnapshot.getExchEventType())
                        || ExchangeEventType.Moved.equals(messageSnapshot.getExchEventType())) {
                    String mailbox = messageSnapshot.getMailboxName();
                    Long groupId = personalMailboxIdToGroupIdMap.get(mailbox);

                    ExchangeRecipient exchRecipient = findExchangeRecipientEntry(exchRecipients, groupId);
                    if (exchRecipient!=null) {
                        String sentItemsFolderName = getSentItemFolderName();
                        logger.info("Found entry for mailbox {} and group {} in exchange recipients",mailbox, groupId);

                        logger.info("Current exchange folder is {}, new received folder is : {} and new received event is : {}", exchRecipient.getExchFolder(),
                                messageSnapshot.getExchFolder(),messageSnapshot.getExchEventType());

                        exchRecipient.setExchItemId(messageSnapshot.getExchItemId());
                        exchRecipient.setExchFolderId(messageSnapshot.getExchFolderId());
                        exchRecipient.setExchFolder(messageSnapshot.getExchFolder());

                        if(!messageSnapshot.getExchFolder().equalsIgnoreCase(sentItemsFolderName) && !messageSnapshot.getExchFolder().equalsIgnoreCase("Outbox")) {
                            logger.info("Saving folder {} data which can be retained later",messageSnapshot.getExchFolder());
                            exchRecipient.setRetainedExchItemId(messageSnapshot.getExchItemId());
                            exchRecipient.setRetainedExchFolderId(messageSnapshot.getExchFolderId());
                            exchRecipient.setRetainedExchFolder(messageSnapshot.getExchFolder());
                            exchRecipient.setRetainedOnEventType(messageSnapshot.getExchEventType());
                        } else {
                            logger.info("Skipping retaining folder values to be used later as folder getting updated is : {}",messageSnapshot.getExchFolder());
                        }

                        if(isSenderInReceivingRecipients(actionConversation,groupId) && Objects.nonNull(exchRecipient.getRetainedExchFolderId()) ){
                            logger.info("Restoring the retained folder and item id");
                            exchRecipient.setExchItemId(exchRecipient.getRetainedExchItemId());
                            exchRecipient.setExchFolderId(exchRecipient.getRetainedExchFolderId());
                            exchRecipient.setExchFolder(exchRecipient.getRetainedExchFolder());
                        } else {
                            logger.info("Sender is not receiving the copy of email he/she sent or received event not on sent but this folder {}",messageSnapshot.getExchFolder());
                        }
                    } else {
                        logger.info("Exchange recipient not found for mailbox : {}, groupId : {} for conv : {} and inq : {}", mailbox,groupId,actionConversation.getId(), actionConversation.getInquiryId());
                    }
                } else {
                    logger.info("Skipping stamping exchange recipient data for mailbox : {} and conv : {} and inq : {} as event received is : {}",
                            messageSnapshot.getMailboxName(),actionConversation.getId(), actionConversation.getInquiryId(),messageSnapshot.getExchEventType());
                }
            } else {
                logger.info("Exchange event type identified as null for mailbox : {} and conv : {}, inq : {}", messageSnapshot.getMailboxName(),actionConversation.getId(), actionConversation.getInquiryId());
            }
        } else {
            logger.info("Exchange recipients are empty, data not updated.");
        }
    }

    private boolean alreadyExistingExchangeRecipient(Long groupId, List<ExchangeRecipient> exchRecipients) {
        boolean exchangeRecipientExists = false;
        if(Objects.nonNull(groupId) && Objects.nonNull(exchRecipients) && !exchRecipients.isEmpty()){
            for(ExchangeRecipient recipient : exchRecipients){
                if(recipient.getGroupId().equals(groupId)){
                    exchangeRecipientExists = true;
                    break;
                }
            }
        }
        return  exchangeRecipientExists;
    }

    private ExchangeRecipient findExchangeRecipientEntry(List<ExchangeRecipient> exchRecipients, Long groupId) {
        ExchangeRecipient exchangeRecipient = null;
        for (ExchangeRecipient recipient : exchRecipients) {
            if (recipient.getGroupId().equals(groupId)) {
                exchangeRecipient = recipient;
                break;
            }
        }
        return exchangeRecipient;
    }

    private boolean isSenderInReceivingRecipients(Conversation actionConversation, Long receiverGroupId) {
        boolean senderInReceivingRecipients = false;
        try {
            if(Objects.nonNull(actionConversation) && Objects.nonNull(actionConversation.getRecipients()) && !actionConversation.getRecipients().isEmpty() && Objects.nonNull(receiverGroupId)) {
                for(ConversationRecipient recipient : actionConversation.getRecipients()){
                    if(Objects.nonNull(recipient.getToFrom()) && RECIPIENT_FROM.equalsIgnoreCase(recipient.getToFrom())
                            && Objects.nonNull(recipient.getGroupId()) && receiverGroupId.equals(recipient.getGroupId())){
                        senderInReceivingRecipients = true;
                        break;
                    }
                }
            } else {
                logger.info("Either actionConversation or receiverGroupId 'null'");
            }
            logger.info("senderInReceivingRecipients identified as : {} for receiverGroupId : {}", senderInReceivingRecipients,receiverGroupId);
        } catch (Exception e){
            logger.warn("Exception in isSenderInReceivingRecipients : ", e);
        }
        return senderInReceivingRecipients;
    }

    public String getSentItemFolderName() {

        String sentItemsFolderName = "Sent Items";
        try {
            Map<String, Object> qmaPersonalConfig = QMACacheFactory.getCache().getQmaPersonalConfig();
            if( Objects.nonNull(qmaPersonalConfig) && Objects.nonNull(qmaPersonalConfig.get("sentItemsFolderName"))) {
                sentItemsFolderName = (String)qmaPersonalConfig.get("sentItemsFolderName");
            }
        } catch (Exception e){
            logger.warn("Exception while getting sent items folder name : ",e);
            sentItemsFolderName = "Sent Items";
        }

        return sentItemsFolderName;
    }

    public String getDeletedItemsFolderName() {

        String deletedItemsFolderName = "Deleted Items";
        try {
            Map<String, Object> qmaPersonalConfig = QMACacheFactory.getCache().getQmaPersonalConfig();
            if( Objects.nonNull(qmaPersonalConfig) && Objects.nonNull(qmaPersonalConfig.get("deletedItemsFolderName"))) {
                deletedItemsFolderName = (String)qmaPersonalConfig.get("deletedItemsFolderName");
            }
        } catch (Exception e){
            logger.warn("Exception while getting deleted items folder name : ",e);
            deletedItemsFolderName = "Deleted Items";
        }

        return deletedItemsFolderName;
    }

}

