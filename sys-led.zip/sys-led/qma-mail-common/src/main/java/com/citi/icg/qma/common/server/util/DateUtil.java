package com.citi.icg.qma.common.server.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;
import org.slf4j.LoggerFactory;

import org.slf4j.Logger;

public class DateUtil
{
	private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);
	private static Long oneDay = 24*60*60*1000L;
	
	// Adding private constructor as this is an utility class and all methods are static
	// Sonar Fix for Utility classes should not have public constructors
	private DateUtil(){}

	public static Long getJulianDate(String dateStr)
	{

		Long julianDate = null;
		try
		{
			if (!StringUtils.isBlank(dateStr))
			{

				Integer YEAR = Integer.parseInt(dateStr.substring(1, 5));
				Integer DAY_OF_YEAR = Integer.parseInt(dateStr.substring(5));
				if (DAY_OF_YEAR < 0 || DAY_OF_YEAR > 365) //changed && to ||
				{
					logger.error("Error in JulianDate Conversion for julian string=[" + dateStr + "], day of year is outside the range");
					return julianDate;
				}
				Calendar cal = Calendar.getInstance();
				cal.set(Calendar.YEAR, YEAR);
				cal.set(Calendar.DAY_OF_YEAR, DAY_OF_YEAR);
				julianDate = cal.getTimeInMillis();
			}
		}
		catch (Exception e)
		{
			logger.error("Error in JulianDate Conversion for julian string=[" + dateStr + "]", e);
		}

		return julianDate;
	}

	//Sonar fix to remove unused parameter..
	public static Date convertJulianDate(Long date)
	{
		Date jDate = new Date(date);

		return jDate;
	}
	
		public static int calculateAgeExcludingWeekends(Date createdDate)
	{
		int nbrDaysInterval = 0;
		//Sonar fix to remove unused parameter //int nbrNonWorkDays = 0;
		int nbrWorkDays = 0;
		int nbrHolidays = 0;
		int breakAge = 0;

		Date startDate = getDateWithoutTime(createdDate);
		Date endDate = getDateWithoutTime(new Date());

		Calendar startCal = Calendar.getInstance();
		startCal.clear();
		startCal.setTime(startDate);

		Calendar endCal = Calendar.getInstance();
		endCal.clear();
		endCal.setTime(endDate);

		//Sonar fix to minimize the if condition as only 3 are allowed...
		if (startDate == null || endDate == null || startDate.after(endDate))
		{
			return breakAge;
		}
		if(startCal == null || endCal == null)
			return breakAge;

		// number of days between start and end dates
		// nbrDaysInterval = (int) TimeUnit.MILLISECONDS.toDays(endDate.getTime() - startDate.getTime());
		// Made changes to address DST issue
		nbrDaysInterval = (int) Math.round((double) (endDate.getTime() - startDate.getTime()) / 86400000);

		// exclude Holidays(no Sat/Sun) & NonWorkDays(All Sat/Sun) from nbrDaysInterval to get BrakeAge
		for (int dayIx = 0; dayIx < nbrDaysInterval; dayIx++)
		{
			if (startCal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || startCal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)
			{
				//Sonar fix to remove unused parameter //nbrNonWorkDays++;
			}
			else
			{
				nbrWorkDays++;
			}
			startCal.add(Calendar.DATE, 1);
		}

		// Note: If any holiday lies in Sat, Sun then don't insert in HOLIDAY_RULE table; However add where class to exclude SAT, SUN as it took care in calculation;
		try
		{
		//	nbrHolidays = MessageDAOV2.getHolidayCount(startDate, endDate, logger);

		}
		catch (Exception e)
		{
			logger.info("Error in Seg Business Break Age - Holiday Calculation - Break Date=[" + createdDate + "]" + e);// Sonar Fix Either log or rethrow this exception...
		}
		breakAge = nbrWorkDays - nbrHolidays;

	//	logger.info("Age Calculation - Break Date=[" + createdDate + "], Break Age=[" + breakAge + "], nbrWorkDays=[" + nbrWorkDays + "], nbrHolidays=[" + nbrHolidays
	//			+ "], nbrNonWorkDays(SAT,SUN)=[" + nbrNonWorkDays + "]");

		return breakAge;
	}

	public static Date getDateWithoutTime(Date date)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date dateWithoutTime = null;
		try
		{
			String dateValueStr = dateFormat.format(date);
			dateWithoutTime = dateFormat.parse(dateValueStr);
		}
		catch (ParseException e)
		{
			logger.info("Error in getDateWithoutTime for date=[" + date + "]" + e);// Sonar Fix Either log or rethrow this exception...
		}
		return dateWithoutTime;
		
	}
	
	public static String getStringDate(Date date, String format)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		String dateValueStr = null;
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		dateValueStr = dateFormat.format(date);

		return dateValueStr;
	}
	

	/*public static Date getPreviousWorkingDay(Date date)
	{
		Date lastBusinessDate = null;
		try
		{
			Calendar cal = Calendar.getInstance();
			if (date == null)
			{
				cal.setTime(new Date());

			}
			else
			{
				cal.setTime(date);
			}
			cal.add(Calendar.DAY_OF_MONTH, -1);// Consider Yesterday to for checking Last Business Day
			int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
			lastBusinessDate = cal.getTime();
			int holidayCnt = MessageDAOV2.getHolidayCount(lastBusinessDate, lastBusinessDate, logger);
			while (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY || holidayCnt != 0)
			{
				cal.add(Calendar.DAY_OF_MONTH, -1);
				dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
				lastBusinessDate = cal.getTime();
				holidayCnt = MessageDAOV2.getHolidayCount(lastBusinessDate, lastBusinessDate, logger);
			}

		}
		catch (Exception e)
		{
			logger.error("Error in getPreviousWorkingDay for Input Date=[" + date + "]", e);
			lastBusinessDate = null;
		}

		return lastBusinessDate;
	}*/

	/*public static int calculateCalenderBreakAge(Date breakDate)
	{
		int breakAge = 0;
		try
		{
			breakAge = MessageDAOV2.calculateCalBreakAge(breakDate, logger);
		}
		catch (Exception e)
		{
			logger.error("Error in calculateCalenderBreakAge for Input Date=[" + breakDate + "]", e);
		}
		return breakAge;
	}*/

	public static Date getDate(String dateStr, String strDateFormat)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		if (strDateFormat != null)
		{
			dateFormat.applyPattern(strDateFormat);
		}
		Date dateValue = null;
		try
		{
			dateValue = dateFormat.parse(dateStr);
		}
		catch (ParseException e)
		{
			logger.error("Error in getDate method while parsing dateStr=[" + dateStr + "]", e);
		}
		return dateValue;
	}
	
	// Gives local time for the "dateStr" given in a timeZone
	public static Date getDate(String dateStr, String strDateFormat, String timeZone)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
		if (strDateFormat != null)
		{
			dateFormat.applyPattern(strDateFormat);
		}
		Date dateValue = null;
		try
		{
			dateValue = dateFormat.parse(dateStr);
		}
		catch (ParseException e)
		{
			logger.error("Error in getDate method while parsing dateStr=[" + dateStr + "]", e);
		}
		return dateValue;
	}

	/*public static Date getDateWithoutTime(Date date)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date dateWithoutTime = null;
		try
		{
			String dateValueStr = dateFormat.format(date);
			dateWithoutTime = dateFormat.parse(dateValueStr);
		}
		catch (ParseException e)
		{
			logger.error("Error in getDateWithoutTime method while parsing date=[" + date + "]", e);
		}
		return dateWithoutTime;
	}*/
	
	public static String getStringDateWithoutTime(Date date, String format)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		String dateValueStr = null;

		dateValueStr = dateFormat.format(date);

		return dateValueStr;
	}
	
	public static String changeDateStringFormat(String dateStr, SimpleDateFormat sourceDateFormat, SimpleDateFormat targetDateFormat)
	{
		String formattedDate = null;
		try
		{
			Date date =  sourceDateFormat.parse(dateStr);
			formattedDate = targetDateFormat.format(date);
		}
		catch (ParseException e)
		{
			logger.error("Error in getDateWithGivenFormat method while parsing date=[" + dateStr + "]", e);
		}
		return formattedDate;
	}	

	public static int calculateCalendarDaysWithoutTime(Date endDate)
	{
		if (endDate == null)
			return 0;

		Date endDateWithoutTime = getDateWithoutTime(endDate);// Sonar Fix Introduce a new variable instead of reusing the parameter "endDate"...
		// yyyy-mm-dd
		Date now = getDateWithoutTime(new Date());// Long currentTimeMillis = System.currentTimeMillis();

		double differenceTimeMillis = now.getTime() - endDateWithoutTime.getTime();// Sonar Fix removed useless parenthesis...
		double f = differenceTimeMillis / (1000 * 60 * 60 * 24);

		long diffInDays = Math.round(f);
		int y = (int) diffInDays;

		return y;
	}
	
	public static int calculateCalendarDays24HR(Date endDate)
	{
		if (endDate == null)
			return 0;

		// yyyy-mm-dd
		Date now = new Date();
		double differenceTimeMillis = now.getTime() - endDate.getTime();// Sonar Fix removed useless parenthesis...
		double f = differenceTimeMillis / (1000 * 60 * 60 * 24);

		double diffInDays = Math.floor(f);
		int y = (int) diffInDays;

		return y;
	}

/*	public static Map<String, Object> calculateSegDefDueAgeDetails(Long exceptionTypeId, Date deficitDate)
	{
		int dueAge = 0;
		int deficitAge = 0;
		String ageType = null;
		String thresholdVal = null;
		int thresholdHr = 0;
		Boolean pastDue = false;

		Map<String, Object> dueDetails = new LinkedHashMap<String, Object>();

		if (exceptionTypeId != null)
		{
			try
			{
				XStreamDataCacheOwner dataCacheOwner = XStreamDataCacheOwner.getInstance(logger);
				SegDeficitDeskcode segDefDeskCode = dataCacheOwner.getSegDefExcpTypeIdDeskCodeMap().get(exceptionTypeId + "");
				if (deficitDate == null)
				{
					deficitDate = GemPositionUtil.getPreviousWorkingDay(getDateWithoutTime(new Date()));
				}
				ageType = segDefDeskCode.getAgingCriteria();
				deficitDate = getDateWithoutTime(deficitDate);
				if ("Business".equalsIgnoreCase(ageType))
				{
					deficitAge = GemPositionUtil.calculateBreakAge(deficitDate, logger);
				}
				else
				{
					deficitAge = GemPositionUtil.calculateCalenderBreakAge(deficitDate, logger);
				}

				// Calculate Due Age
				thresholdVal = segDefDeskCode.getThresholdValue();
				try
				{
					thresholdHr = Integer.valueOf(thresholdVal);
					dueAge = thresholdHr / 24;

					logger.info("Inside calculateSegDefDueAgeDetails calculator -> dueAge:" + dueAge + ", deficitAge:" + deficitAge + ", thresholdHr:" + thresholdHr);
					if (deficitAge <= dueAge)
					{
						dueAge = (dueAge - deficitAge) + 1;
					}
					else
					{
						pastDue = true;
					}

				}
				catch (Exception e)
				{
					logger.error("Error in calculation of seg def due age, exceptionType= " + exceptionTypeId);
					dueAge = 0;
				}

			}
			catch (Exception e)
			{
				logger.error("Error in calculation of seg def due age and deficit age, exceptionType= " + exceptionTypeId);
				dueAge = 0;
				deficitAge = 0;
				deficitDate = null;
			}

			dueDetails.put(AppServerConstants.SEG_DEF_DEFICIT_DATE, deficitDate);
			dueDetails.put(AppServerConstants.SEG_DEF_DEFICIT_AGE, deficitAge);
			dueDetails.put(AppServerConstants.SEG_DEF_DUE_AGE, dueAge);
			dueDetails.put(AppServerConstants.SEG_DEF_PAST_DUE, pastDue);
		}
		logger.info("calculateSegDefDueAgeDetails-->exceptionTypeId=[" + exceptionTypeId + "],deficitDate=[" + deficitDate + "],deficit_age=[" + deficitAge + "],dueAge=[" + dueAge + "],pastDue=["
				+ pastDue + "],thresholdVal=[" + thresholdVal + "]");
		return dueDetails;
	}

	public static List<Long> getLogIdList(List<Deficit> deficitList)
	{

		ArrayList<Long> logList = new ArrayList<Long>();
		for (Deficit deficit : deficitList)
		{
			String logIdStr = deficit.getLogId();
			Long logId = Long.valueOf(logIdStr);
			if (!logList.contains(logId))
			{
				logList.add(logId);
			}

		}
		return logList;
	}*/

/*	public static BigDecimal calculateSplitMarketValue(BigDecimal totalQty, BigDecimal totalMarketValue, BigDecimal splitQty) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		BigDecimal allocSplitMarketValue = null;
		try
		{
			if (totalQty == null || totalMarketValue == null || splitQty == null || totalQty.equals(BigDecimal.ZERO))
			{
				logger.error("Issue calculateSplitMarketValue-Invalid values for split ");
				return null;
				// throw new Exception("Issue calculateSplitMarketValue-Invalid values for split ");
			}

			allocSplitMarketValue = BigDecimal.valueOf((totalMarketValue.doubleValue() * (splitQty.doubleValue())) / (totalQty.doubleValue()));

		}
		catch (Exception ex)
		{
			logger.error("Issue calculateSplitMarketValue-Invalid values for split ", ex);
			// throw new Exception("Issue calculateSplitMarketValue ", ex);
		}
		return allocSplitMarketValue;
	}
*/
	/*public static void main(String[] args)
	{
		LogUtil.loadLog4j();
		AppTestEnv.initEnvAndConfig();
		Long d = 0L;
		try
		{
			Date breakDate = getDate("2014-09-01", null);
			Date prevWrkDay = getPreviousWorkingDay(breakDate);
			// calculateBreakAgeTest();
		}
		catch (Exception e)
		{
			logger.error("Error in DateUtil class-", e);
		}

	}*/

/*	public static void calculateBreakAgeTest() throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Date startDate = null;
		Date endDate = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss,sss"); // .parse("2015-11-03 00:46:04,652");

		// 8th March is DST start date and Nov 1st is DST end date

		// All Normal Date
		startDate = dateFormat.parse("2015-02-27");
		endDate = dateFormat1.parse("2015-03-03 00:46:04,652");
		ageCalFromBreakAgeTest(startDate, endDate);

		// All in DST Date
		startDate = dateFormat.parse("2015-11-06");
		endDate = dateFormat1.parse("2015-11-10 00:46:04,652");
		ageCalFromBreakAgeTest(startDate, endDate);

		// In between Normal to DST
		startDate = dateFormat.parse("2015-03-06");
		endDate = dateFormat1.parse("2015-03-10 00:46:04,652");
		ageCalFromBreakAgeTest(startDate, endDate);

		// In between DST to normal
		startDate = dateFormat.parse("2015-10-30");
		endDate = dateFormat1.parse("2015-11-03 00:46:04,652");
		ageCalFromBreakAgeTest(startDate, endDate);
	}*/

/*	private static int ageCalFromBreakAgeTest(Date startDate, Date endDate)
	{
		int nbrDaysInterval = 0;
		int nbrNonWorkDays = 0;
		int nbrWorkDays = 0;
		int nbrHolidays = 0;
		int breakAge = 0;

		startDate = getDateWithoutTime(startDate, logger);
		endDate = getDateWithoutTime(endDate, logger);

		Calendar startCal = Calendar.getInstance();
		startCal.clear();
		startCal.setTime(startDate);

		Calendar endCal = Calendar.getInstance();
		endCal.clear();
		endCal.setTime(endDate);

		if (startDate == null || endDate == null || startDate.after(endDate) || startCal == null || endCal == null)
		{
			return breakAge;
		}

		// number of days between start and end dates
		logger.info("nbrDaysInterval in Decimal --> " + (double) (endDate.getTime() - startDate.getTime()) / 86400000);
		nbrDaysInterval = (int) Math.round((double) (endDate.getTime() - startDate.getTime()) / 86400000);
		// nbrDaysInterval = GemPositionUtil.calculateCalenderBreakAge(startDate, logger);
		logger.info("nbrDaysInterval --> " + nbrDaysInterval);

		// exclude Holidays(no Sat/Sun) & NonWorkDays(All Sat/Sun) from nbrDaysInterval to get BrakeAge
		for (int dayIx = 0; dayIx < nbrDaysInterval; dayIx++)
		{
			if (startCal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || startCal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)
			{
				nbrNonWorkDays++;
			}
			else
			{
				nbrWorkDays++;
			}
			startCal.add(Calendar.DATE, 1);
		}

		// Note: If any holiday lies in Sat, Sun then don't insert in HOLIDAY_RULE table; However add where class to exclude SAT, SUN as it took care in calculation;
		try
		{
			nbrHolidays = MessageDAOV2.getHolidayCount(startDate, endDate, logger);

		}
		catch (Exception e)
		{
			logger.info("Error in Seg Break Age-Holiday Calculation-break date=[" + startDate + "]");
		}
		breakAge = nbrWorkDays - nbrHolidays;

		logger.info("Seg Break Age Calculation - Break Date=[" + startDate + "], Break Age=[" + breakAge + "], nbrWorkDays=[" + nbrWorkDays + "], nbrHolidays=[" + nbrHolidays
				+ "], nbrNonWorkDays(SAT,SUN)=[" + nbrNonWorkDays + "]");

		logger.info("breakAge : " + breakAge);
		return breakAge;
	}*/
	
	// method same as on client side for calculating age for graph data.
	public static double calculateAgeforGraphs(Date createdDate)
	{

		Date currentDate = new Date();
		double diffDays = Math.floor(Math.abs((currentDate.getTime() - createdDate.getTime()) / (oneDay)));
		//System.out.println("diffDays" + diffDays);

		return diffDays;
	}
		
	//[C153176-169] - Server-side export of inquiries
	//returns inquiry age in days - same method as on client side
	public static double getInquiryAge(long createdDateInMillis, long modifiedDateInMillis)
	{
		double age = Math.floor(Math.abs((modifiedDateInMillis - createdDateInMillis) / (oneDay)));
		return age;
	}

}
