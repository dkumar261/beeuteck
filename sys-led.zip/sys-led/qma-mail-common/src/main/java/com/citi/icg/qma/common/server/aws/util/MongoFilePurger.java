package com.citi.icg.qma.common.server.aws.util;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.persistence.AttachmentDAO;
import com.citi.icg.qma.common.server.dao.persistence.MongoDB;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.ReadPreference;
import com.mongodb.gridfs.GridFS;

import dev.morphia.Datastore;

public class MongoFilePurger implements Runnable {

	private List<String> msgIdsChunkList;
	private static final Logger log = LoggerFactory.getLogger(MongoFilePurger.class);
	private static final DB database = MongoDB.instance().getDB();
	private static final Datastore mongoDatastore = MongoDB.instance().getDataStore();
	private static final GridFS snapShotFS = new GridFS(database, "messageSnapshot");

	public MongoFilePurger(List<String> msgIdsChunkList) throws IOException {

		this.msgIdsChunkList = msgIdsChunkList;

	}

	@Override
	public void run() {
		try {

			writeToObjectStore(msgIdsChunkList);

		} catch (Exception e) {
			log.error("Error:"+e);
		}

	}

	/**
	 * 
	 * @param msgIdsChunkList
	 *            -100
	 * @throws IOException
	 */
	private void writeToObjectStore(List<String> msgIdsChunkList) {

		AWSUtility awsUtility = new AWSUtility();
		AttachmentDAO attachDao = new AttachmentDAO();
		Set<String> msgIdsMigrated = new HashSet<String>();

		String projectionQuery = "{ _id : 1, inquiryId :1, gridFSId : 1,conversationId:1}";
		BasicDBObject msgMatchQuery = new BasicDBObject("_id", new BasicDBObject("$in", msgIdsChunkList))
				.append("gridFSId", new BasicDBObject("$exists", true))
				.append("storageType",  "A");
		DBObject projection = BasicDBObject.parse(projectionQuery);
		DBCursor dataCursor = database.getCollection("MessageSnapshot").find(msgMatchQuery, projection)
				.setReadPreference(ReadPreference.secondary());

		log.info("Msgsnap Purge Match Query:" + msgMatchQuery);

		Long successfulMigration = 0L;
		Long failureMigration = 0L;

		while (dataCursor.hasNext()) {
			try {
				DBObject msnpObject = dataCursor.next();

				if (msnpObject != null) {
					String mId = (String) msnpObject.get("_id");
					String docId = (String) msnpObject.get("gridFSId");

					Map<String, Object> downloadedFileMap = attachDao.getFile(docId,true, log,snapShotFS);
					File file = (File) downloadedFileMap.get("fileObject");
					/*Date uploadOn = (Date) downloadedFileMap.get("uploadOn");
					Long size = (Long) downloadedFileMap.get("size");
					String md5 = (String) downloadedFileMap.get("md5");
					String type = (String) downloadedFileMap.get("type");*/
					String fileName = (String) downloadedFileMap.get("name");

					// write to object storage
					
					if (file !=null) {
						file.delete();// delete file always
						attachDao.deleteFile(docId,snapShotFS);
						//delete from S3 pending - TODO - based on rule
						msgIdsMigrated.add(mId);
						log.info("Msgsnap Purge file in mongdb and locally" + docId + "  name is:" + fileName);
						successfulMigration++;
					}else{
						failureMigration++;
					}

				}
			} catch (Exception e) {
				failureMigration++;
				log.error("Msgsnap Purge Issue in data migration", e);
			}
		}

		log.info("Msgsnap Purge successful docs: " + successfulMigration + "  , failurePurging Docs:" + failureMigration);

		updateMessageSnapshot(msgIdsMigrated);

		log.info("Msgsnap Purge updated finsihed and their id's are: " + msgIdsMigrated.size());

	}

	/**
	 * update Message Snapshot with archieved = Y
	 */
	public void updateMessageSnapshot(Set<String> msgIdsMigrated) {

		log.info("Msgsnap Purge Started updating MSGSNAP  Records " + msgIdsMigrated.size());
		/*if (!msgIdsMigrated.isEmpty()) {
			DBCollection msgSnapShotCol = mongoDatastore.getCollection(MessageSnapshot.class);
			BulkWriteOperation bulkInquiryEscalationUpdOp = msgSnapShotCol.initializeOrderedBulkOperation();
			DBObject findConvIdQuery = new BasicDBObject("_id", new BasicDBObject("$in", msgIdsMigrated)).append("storageType","A");
			log.info("Msgsnap  Purge Updating storageType in Snapshot " + findConvIdQuery);

			DBObject updateArchiveFlag = new BasicDBObject();
			updateArchiveFlag.put("$set", new BasicDBObject("storageType", "P").append("storageActionTime", new Date()));

			bulkInquiryEscalationUpdOp.find(findConvIdQuery).update(updateArchiveFlag);
			bulkInquiryEscalationUpdOp.execute();

		}
		log.info("Msgsnap Purge Done updating MSGSNAP  Records " + msgIdsMigrated.size());*/

	}

}
