package com.citi.icg.qma.common.core.subscriber.mails;

import java.util.Arrays;

import javax.naming.CommunicationException;

import dev.morphia.Key;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.MailServiceGenericUtil;
import com.citi.icg.qma.common.core.util.MsgSourceType;
import com.citi.icg.qma.common.server.dao.InquiryMessageRef;
import com.citi.icg.qma.common.server.dao.MessageIdDetails;
import com.citi.icg.qma.common.server.dao.persistence.MongoMorphiaDAO;

public class MongoExtInquiryMsgRefAuditManager extends MongoMorphiaDAO {
	private static Logger subLogger = LoggerFactory.getLogger(MongoExtInquiryMsgRefAuditManager.class);
	private static MongoExtInquiryDAO mongoExtInquiryDAO = new MongoExtInquiryDAO();

	public Long createExtInquiryMessageRef(String messageId, String references, Long inquiryId, MsgSourceType msgSourceType, String threadTopic)
			throws CommunicationException {
		Long msgRefGrpId = null;
		try {
			InquiryMessageRef inquiryMessageRef = new InquiryMessageRef();
			inquiryMessageRef.setLatestMessageId(messageId);
			inquiryMessageRef.setMessageId(messageId);
			inquiryMessageRef.setMsgSourceType(msgSourceType);
			if (references != null) {
				inquiryMessageRef.setReferences(references);
				inquiryMessageRef.setReferencesAudit(
						Arrays.asList(MailServiceGenericUtil.extractMailReferencesToRefArray(references)));
			} else {
				inquiryMessageRef.setReferences(messageId);
				inquiryMessageRef.setReferencesAudit(Arrays.asList(messageId));
			}
			inquiryMessageRef.setInquiryId(inquiryId);
			inquiryMessageRef.setThreadTopic(threadTopic);
			Key<InquiryMessageRef> inquiryMessageRefKey = MongoMorphiaDAO.saveWithRetry(mongoDatastore, inquiryMessageRef);
			subLogger.info("Id created :: {}", inquiryMessageRefKey.getId());
			msgRefGrpId = (Long) inquiryMessageRefKey.getId();
		} catch (Exception e) {
			throw new CommunicationException("Error in createExtInquiryMessageRef() ::" + e);
		}
		return msgRefGrpId;
	}

	public static void updateExtInquiryMessageRefGrpId(Long refGroupId, String latestMessageId, String references) {
		mongoExtInquiryDAO.updateExtInquiryMessageRefGrpId(refGroupId, latestMessageId, references);
	}
	
	public static void updateExtInquiryMessageRefGrpId(Long refGroupId, String latestMessageId, String references, String threadTopic) {
		mongoExtInquiryDAO.updateExtInquiryMessageRefGrpId(refGroupId, latestMessageId, references, threadTopic);
	}
	
	public static void updateExtInquiryMessageRefInquiryId(Long inquiryId, Long inquiryMessageRefId) {
		mongoExtInquiryDAO.updateExtInquiryMessageRefInquiryId(inquiryId, inquiryMessageRefId,null);

	}
	public static void updateExtInquiryMessageRefInquiryId(Long inquiryId, Long inquiryMessageRefId,String lobInfo) {
		mongoExtInquiryDAO.updateExtInquiryMessageRefInquiryId(inquiryId, inquiryMessageRefId,lobInfo);

	}
	public static boolean saveMessageId(String messageId, String mailbox) {
		boolean messageIdSavedFlag = true;
		try {

			MessageIdDetails messageDetails = new MessageIdDetails(messageId);
			Key<MessageIdDetails> key = new MongoMorphiaDAO().mongoDatastore.save(messageDetails);
			subLogger.info("In saveMessageId into MessageIdDetails,  mailbox is :{} ,message Id is:{} ,and Id is : {}",mailbox,messageId, key.getId());
		}catch(Exception e)
		{
			messageIdSavedFlag = false;
			//This is not an error
			subLogger.info("In saveMessageId into MessageIdDetails is failed, mailbox is :{} ,message Id is: {}",mailbox ,messageId );
		}
		
		
		return messageIdSavedFlag;
	}

}
