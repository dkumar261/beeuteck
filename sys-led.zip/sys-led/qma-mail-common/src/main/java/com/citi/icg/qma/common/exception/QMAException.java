package com.citi.icg.qma.common.exception;

import com.citi.icg.qma.common.server.util.GenericUtility;
import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

public class QMAException extends Exception {


    private static final Logger logger = LoggerFactory.getLogger(QMAException.class);
    private static final int ERROR_CODE = HttpStatus.SC_UNAUTHORIZED;
    private static final String ERROR_CODE_DESCRIPTION = "Unauthorized";
    public static final boolean SUCCESS_VALUE = false;

    public static final String ERROR_CODE_KEY = "errorCode";
    public static final String MESSAGE_KEY = "message";
    public static final String SUCCESS_KEY = "success";
    public static final String CAUSE_KEY = "cause";
    public static final String MESSAGE_DETAILS_KEY = "messageDetails";
    public static final String HOST_KEY = "host";
    public static final String DATE_KEY = "dateTime";

    private int errorCode;
    private String errorCodeDesc;
    private String message;
    private Throwable cause;
    private String messageDetails;
    private String host;
    private Date dateTime;


    public QMAException(String message) {
        super(message);
        this.errorCode = ERROR_CODE;
        this.errorCodeDesc = ERROR_CODE_DESCRIPTION;
        this.message = message;
        this.messageDetails = message;
        this.host = GenericUtility.getCurrentHost();
        this.dateTime = new Date();
    }

    public QMAException(Exception e) {
        super(e.getMessage());
    }

    public QMAException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = ERROR_CODE;
        this.errorCodeDesc = ERROR_CODE_DESCRIPTION;
        this.message = message;
        this.messageDetails = null != cause && null != cause.getMessage() ? cause.getMessage() : message;
        this.cause = cause;
        this.host = GenericUtility.getCurrentHost();
        this.dateTime = new Date();
    }

    public QMAException(String message, int errorCode, String errorCodeDesc) {
        this.errorCode=errorCode;
        this.errorCodeDesc = errorCodeDesc;
        this.message=message;
        this.messageDetails = message;
        this.host= GenericUtility.getCurrentHost();
        this.dateTime = new Date();
    }

    public QMAException(String message, Throwable cause, int errorCode, String errorCodeDesc) {
        this.errorCode=errorCode;
        this.errorCodeDesc = errorCodeDesc;
        this.message=message;
        this.cause = cause;
        this.messageDetails = null != cause && null != cause.getMessage() ? cause.getMessage() : message;
        this.host= GenericUtility.getCurrentHost();
        this.dateTime = new Date();
    }

    @Override
    public String toString() {
        JSONObject exception = new JSONObject();
        try {
            exception.put(QMAException.SUCCESS_KEY, SUCCESS_VALUE);
            exception.put(QMAException.ERROR_CODE_KEY, this.getErrorCode());
            exception.put(QMAException.MESSAGE_KEY, this.getErrorCodeDesc() + " : " + this.getMessage());
            exception.put(QMAException.MESSAGE_DETAILS_KEY, this.getMessageDetails());
            exception.put(QMAException.HOST_KEY, this.getHost());
            exception.put(QMAException.DATE_KEY, this.getDateTime());
            if (null != this.cause) {
                exception.put(QMAException.CAUSE_KEY, this.getCause());
            }
        } catch (JSONException e) {
            logger.warn("Exception while forming exception in JSON format : ", e);
        }
        return exception.toString();
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorCodeDesc() {
        return errorCodeDesc;
    }

    public void setErrorCodeDesc(String errorCodeDesc) {
        this.errorCodeDesc = errorCodeDesc;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public Throwable getCause() {
        return cause;
    }

    public void setCause(Throwable cause) {
        this.cause = cause;
    }

    public String getMessageDetails() {
        return messageDetails;
    }

    public void setMessageDetails(String messageDetails) {
        this.messageDetails = messageDetails;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public Date getDateTime() {
        return dateTime;
    }

    public void setDateTime(Date dateTime) {
        this.dateTime = dateTime;
    }
}
