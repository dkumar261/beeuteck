/**
 * 
 */
package com.citi.icg.qma.common.core.util;

/**
 * 
 *
 */
public final class QueryConstants {
	
	private QueryConstants(){}
	
	public static final String GROUP_ID_EXP = "[#groupId#]";
	public static final String ASSIGNED_USER_ID_EXP = "#assignedUserId#";
	public static final String SOEID_EXP = "[#SOEID#]";
	public static final String MOD_DATE_EXP = "#MOD_DATE#";
	public static final String CATEGORY_INDEX_EXP = "#CATEGORY_INDEX#";
	public static final String IND_GROUP_ID_EXP = "#GROUP_ID#";
	public static final String IND_USER_ID_EXP = "#USER_ID#";
	public static final String INBOX_QUERY_FOR_MAILBOX_STATS = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open','direction': 'IN', 'modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}}, "
			+"{ '$unwind': '$workflows'},"
			+ "{ '$match' : { 'workflows.status' : 'Open', 'workflows.direction' : 'IN' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "},'workflows.rulesFlag' : { '$exists' : false},'workflows.snoozeAction': {'$exists':false}}}]";
	
	public static final String OUTBOX_QUERY_FOR_MAILBOX_STATS = "[{ '$match' : { '$and' : [ { 'workflows' : { '$elemMatch' : { 'direction': 'OUT', 'modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}}, "
			+"{ '$unwind': '$workflows'},"
			+ " { '$match' : {  'workflows.direction' : 'OUT' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "},'workflows.rulesFlag': {'$exists': false}}}]";
	
	public static final String RESOLVED_BOX_QUERY_FOR_MAILBOX_STATS = "[{ '$match' : { '$and' : [ { 'workflows' : { '$elemMatch' : { 'status' : 'Resolved', 'direction': 'IN', 'modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}},"
			+" { '$unwind': '$workflows'},"
			+ "{ '$match' : { 'workflows.status' : 'Resolved','workflows.direction': 'IN','workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}]";
	
	public static final String PENDING_APPROVAL_QUERY_FOR_MAILBOX_STATS = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open','modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}},"
			+"{ '$unwind': '$workflows'},"
			+ " { '$match' : { 'workflows.status' : 'Open', 'workflows.direction' : { '$in' : ['PENDINGAPPROVAL','PND_REAGE','NOMINATE_OWNERSHIP']  },'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}} ,'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}},"
			+"{'$match': {'workflows.rulesFlag': {'$exists': false},'workflows.snoozeAction': {'$exists':false}}}]";
	
	public static final String POTENTIAL_ESCALATION_QUERY_FOR_MAILBOX_STATS = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open','modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}},"
			+"{ '$unwind': '$workflows'},"
			+ " { '$match' : { 'workflows.status' : 'Open', 'workflows.direction' : { '$in' : ['IN','PENDINGAPPROVAL','PND_REAGE','NOMINATE_OWNERSHIP']  },'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}} ,'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}, $or :[{'workflows.isConvCountEscalation' : 'Y'},{'workflows.isClientChaseEscalation'  : 'Y'},{'workflows.isSubjectEscalation' : 'Y'},{'workflows.responseTimeEscalationFlag' : 'Y'},{'workflows.ispendingApprovalEscalation' : 'Y'},{'workflows.isManualEscalation' : 'Y'}]}},"
			+"{'$match': {'workflows.rulesFlag': {'$exists': false}}}]";
	
	public static final String SNOOZED_QUERY_FOR_MAILBOX_STATS = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open','modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}},"
			+"{ '$unwind': '$workflows'},"
			+ " { '$match' : { 'workflows.status' : 'Open', 'workflows.direction' : 'IN' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "},'workflows.rulesFlag' : { '$exists' : false},'workflows.snoozeAction' : 'Snooze'}}]";
	
	public static final String ASSIGNED_TO_ME_QUERY_FOR_MAILBOX_STATS = "[{'$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open' , 'direction' : 'IN' ,'modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists':false} }}}]}} , "
			+ "{ '$unwind' : '$workflows'} ,"
			+" { '$match' : {'workflows.status' : 'Open' ,'workflows.direction' : 'IN' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}},"
			+" {'$match': {'workflows.rulesFlag': {'$exists': false},'workflows.snoozeAction': {'$exists':false}}} ,"
			+"{ '$match' : { 'workflows.assignedUserId' : '"+ ASSIGNED_USER_ID_EXP + "'}}]" ;
	
	public static final String UNASSIGNED_QUERY_FOR_MAILBOX_STATS = "[{'$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open' ,'modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'direction' : 'IN' , 'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists':false} }}}]}} , "
			+ "{ '$unwind' : '$workflows'} ,"
			+" { '$match' : {'workflows.status' : 'Open' ,'workflows.direction' : 'IN' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}, "
			+"{'$match': {'workflows.rulesFlag': {'$exists': false},'workflows.snoozeAction': {'$exists':false}}} ,"
			+"{ '$match' : { 'workflows.assignedUserId' : { '$exists' : false}}}]" ;
	
	public static final String NON_INQUIRY_QUERY_FOR_MAILBOX_STATS = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open','modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}},"
			+"{ '$unwind': '$workflows'},"
			+ " { '$match' : { 'workflows.status' : 'Open', 'workflows.direction' : 'IN' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "},'workflows.rulesFlag' : { '$exists' : true},'workflows.rulesFlag.markAsNonInquiry' : { '$exists' : true}}}]";
	
	public static final String DRAFTS_QUERY= "{ '$match' : { '$and' : [ { 'userId' : "+ ASSIGNED_USER_ID_EXP + " ]";
	
	public static final String TAG_VIEW_QUERY = "[{'$match': {'$and': [{'workflows': {'$elemMatch': {'tag': '#TAGNAME#','assignedGroupId': #GROUPID#}}}]}}" 
			+ ", {'$unwind': '$workflows'}"
			+", {'$match': {'workflows.tag': '#TAGNAME#','workflows.assignedGroupId': #GROUPID#}}]" ;
	public static final String OPEN_INQUIRIES_BY_GROUP = "[{'$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open' ,'direction' : 'IN' , 'assignedGroupId': #GROUPID#, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists':false} }}}]}} , "
			+ "{ '$unwind' : '$workflows'} ,"
			+" { '$match' : {'workflows.status' : 'Open' ,'workflows.direction' : 'IN' , 'workflows.assignedGroupId': #GROUPID#}},"
			+" {'$match': {'workflows.rulesFlag': {'$exists': false},'workflows.snoozeAction': {'$exists':false}}}]";
	
	public static final String OPEN_INQUIRIES_BY_REQUEST_TYPE = "[{'$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open' , 'direction' : 'IN' , 'assignedGroupId': #GROUPID#, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists':false} }}}]}} , "
			+ "{ '$unwind' : '$workflows'} ,"
			+" { '$match' : {'workflows.status' : 'Open' ,'workflows.direction' : 'IN' ,'workflows.assignedGroupId': #GROUPID#}},"
			+" {'$match': {'workflows.rulesFlag': {'$exists': false},'workflows.snoozeAction': {'$exists':false}}},"
			+ "{'$match': {'workflows.requestType': '#REQUESTTYPE#'}}]";
	
	public static final String OPEN_INQUIRIES_BY_ASSIGNED_OWNER = "[{'$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open' ,'direction' : 'IN' , 'assignedGroupId': { '$in' : #GROUPID#}, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists':false} }}}]}} , "
			+ "{ '$unwind' : '$workflows'} ,"
			+" { '$match' : {'workflows.status' : 'Open' ,'workflows.direction' : 'IN' ,'workflows.assignedGroupId': { '$in' : #GROUPID#}}},"
			+" {'$match': {'workflows.rulesFlag': {'$exists': false},'workflows.snoozeAction': {'$exists':false}}},"
			+ "{'$match': {'workflows.assignedUserId': '#ASSIGNEDOWNERID#'}}]";
	public static final String OPEN_INQUIRIES_BY_UNASSIGNED_OWNER = "[{'$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open' ,'direction' : 'IN' , 'assignedGroupId': { '$in' : #GROUPID#}, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists':false} }}}]}} , "
			+ "{ '$unwind' : '$workflows'} ,"
			+" { '$match' : {'workflows.status' : 'Open' ,'workflows.direction' : 'IN' ,'workflows.assignedGroupId': { '$in' : #GROUPID#}}},"
			+" {'$match': {'workflows.rulesFlag': {'$exists': false},'workflows.snoozeAction': {'$exists':false}}},"
			+ "{'$match': {'workflows.assignedUserId': {'$exists': false}#dateByAgeBand#}}]";
	
	public static final String COMBINED_VIEW_QUERY = "[{'$match': {'$and': [{'status': 'Open', 'workflows': {'$elemMatch': {'status': 'Open', 'direction': 'IN', 'assignedGroupId': {'$in': #GROUPID#}, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists': false}}}}]}}" + 
			", {'$unwind': '$workflows'}" + 
			", {'$match': {'workflows.status': 'Open', 'workflows.direction': 'IN','workflows.assignedGroupId': {'$in': #GROUPID#}}}" + 
			", {'$match': {'workflows.rulesFlag': {'$exists': false}, 'workflows.snoozeAction': {'$exists': false}}}" + 
			", {'$project': {'chatRoomMember': {'$cond': [{'$eq': [{'$ifNull': ['$symphonyChatRoomMember', null]}, null]}, ['#SOEID#'], '$symphonyChatRoomMember']}, 'id': 1, 'symphonyChatRoomMember': 1, 'readBy': 1}}" + 
			", {'$match': {'chatRoomMember': {'$in': ['#SOEID#']}}}" + 
			"]";
	
	public static final String CHAT_VIEW_QUERY = "[{'$match': {'$and': [{'status': 'Open', 'workflows': {'$elemMatch': {'status': 'Open', 'direction': 'IN','assignedGroupId': {'$in': #GROUPID#}, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists': false}}}}]}}" + 
			", {'$unwind': '$workflows'}" + 
			", {'$match': {'workflows.status': 'Open', 'workflows.direction': 'IN','workflows.assignedGroupId': {'$in': #GROUPID#}}}" + 
			", {'$match': {'workflows.rulesFlag': {'$exists': false}, 'workflows.snoozeAction': {'$exists': false}}}" + 
			", {'$match': {'isSymphonyChatroom': 'Y'}}" +
			", {'$project': {'chatRoomMember': {'$cond': [{'$eq': [{'$ifNull': ['$symphonyChatRoomMember', null]}, null]}, ['#SOEID#'], '$symphonyChatRoomMember']}, 'id': 1, 'symphonyChatRoomMember': 1, 'readBy': 1}}" + 
			", {'$match': {'chatRoomMember': {'$in': ['#SOEID#']}}}" + 
			"]";
	public static final String FYI_QUERY_FOR_MAILBOX_STATS = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open','modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}},"
			+"{ '$unwind': '$workflows'},"
			+ " { '$match' : { 'workflows.status' : 'Open', 'workflows.direction' : 'IN' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "},'workflows.rulesFlag' : { '$exists' : true},'workflows.rulesFlag.markAsNonInquiry' : { '$exists' : true}, 'workflows.rulesFlag.ruleType':'autoAssignmentRule'}}]";
	
	public static final String PERSONAL_MAIL_QUERY_FOR_MAILBOX_STATS = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open','direction': 'IN', 'modDate':{'$gte'"+ MOD_DATE_EXP +")},'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}}, "
			+"{ '$unwind': '$workflows'},"
			+ "{ '$match' : { 'workflows.status' : 'Open', 'workflows.direction' : 'IN' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "},'workflows.rulesFlag' : { '$exists' : false},'workflows.snoozeAction': {'$exists':false},'workflows.personalFolders':{'$exists':true}}}]";;
	
	public static final String QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD = "{'$project': {'readByUserId' : '#SOEID#','readBy':{'$cond': [ {$eq:[{ '$ifNull': [ '$readBy', null ] },null]},[],'$readBy']},'workflows':1 } },"
					+ "{'$group': {" + 
					"  	'_id': {'groupId':'$workflows.assignedGroupId', 'userId':'$readByUserId'}, " + 
					"  	'TOTAL': {'$sum': 1}," + 
					"  	'READ': {'$sum': {'$cond': [{'$and': [ {'$eq': ['$workflows.direction', 'IN']},{'$in': ['#SOEID#','$readBy']}]},1,0]}} }" + 
					"}," + 
					"{'$group': {" + 
					"	'_id' : '$_id.userId'," + 
					"	'TOTAL_COUNT' :  {'$sum': '$TOTAL'}," + 
					"	'TOTAL_READ_COUNT':{'$sum': '$READ'}" + 
					"	}" + 
					"}";
	public static final String QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD_OUT = "{'$project': {'readByUserId' : '#SOEID#','readBy':{'$cond': [ {$eq:[{ '$ifNull': [ '$readBy', null ] },null]},[],'$readBy']},'workflows':1 } },"
			+ "{'$group': {" + 
			"  	'_id': {'groupId':'$workflows.assignedGroupId', 'userId':'$readByUserId'}, " + 
			"  	'TOTAL': {'$sum': 1}," + 
			"  	'READ': {'$sum': {'$cond': [{'$and': [ {'$eq': ['$workflows.direction', 'OUT']},{'$in': ['#SOEID#','$readBy']}]},1,0]}} }" + 
			"}," + 
			"{'$group': {" + 
			"	'_id' : '$_id.userId'," + 
			"	'TOTAL_COUNT' :  {'$sum': '$TOTAL'}," + 
			"	'TOTAL_READ_COUNT':{'$sum': '$READ'}" + 
			"	}" + 
			"}";
	public static final String QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD_PENDING_APPROVAL = "{'$project': {'readByUserId' : '#SOEID#','readBy':{'$cond': [ {$eq:[{ '$ifNull': [ '$readBy', null ] },null]},[],'$readBy']},'workflows':1 } },"
			+ "{'$group': {" + 
			"  	'_id': {'groupId':'$workflows.assignedGroupId', 'userId':'$readByUserId'}, " + 
			"  	'TOTAL': {'$sum': 1}," + 
			"  	'READ': {'$sum': {'$cond': [{'$and': [ {'$in': ['$workflows.direction',['PENDINGAPPROVAL','PND_REAGE','NOMINATE_OWNERSHIP']]},{'$in': ['#SOEID#','$readBy']}]},1,0]}} }" + 
			"}," + 
			"{'$group': {" + 
			"	'_id' : '$_id.userId'," + 
			"	'TOTAL_COUNT' :  {'$sum': '$TOTAL'}," + 
			"	'TOTAL_READ_COUNT':{'$sum': '$READ'}" + 
			"	}" + 
			"}";
	public static final String QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD_ESCALATION = "{'$project': {'readByUserId' : '#SOEID#','readBy':{'$cond': [ {$eq:[{ '$ifNull': [ '$readBy', null ] },null]},[],'$readBy']},'workflows':1 } },"
			+ "{'$group': {" + 
			"  	'_id': {'groupId':'$workflows.assignedGroupId', 'userId':'$readByUserId'}, " + 
			"  	'TOTAL': {'$sum': 1}," + 
			"  	'READ': {'$sum': {'$cond': [{'$and': [ {'$in': ['$workflows.direction',['IN','PENDINGAPPROVAL','PND_REAGE','NOMINATE_OWNERSHIP']]},{'$in': ['#SOEID#','$readBy']}]},1,0]}} }" + 
			"}," + 
			"{'$group': {" + 
			"	'_id' : '$_id.userId'," + 
			"	'TOTAL_COUNT' :  {'$sum': '$TOTAL'}," + 
			"	'TOTAL_READ_COUNT':{'$sum': '$READ'}" + 
			"	}" + 
			"}";
	public static final String QUERY_GROUPING_FILTER_FOR_COUNT = "{'$project': {'workflows':1 }}," + 
			"{'$group': {" + 
			"	'_id': '$workflows.assignedGroupId'," + 
			"	'TOTAL_COUNT': {'$sum': 1}" +
				"}" + 
			"},{'$project': {" +
				"'_id': 1, 'TOTAL_COUNT' : '$TOTAL_COUNT' " +
				"}" +
			"},{'$group': {" +
				"'_id':null, 'TOTAL_COUNT': {'$sum': '$TOTAL_COUNT'}"+
				"}" +
			"}";
	
	public static final String INBOX_QUERY = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open','direction': 'IN', 'modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}}, "
			+"{ '$unwind': '$workflows'},"
			+ "{ '$match' : { 'workflows.status' : 'Open', 'workflows.direction' : 'IN' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "},'workflows.rulesFlag' : { '$exists' : false},'workflows.snoozeAction': {'$exists':false}}}]";
	
	public static final String OUTBOX_QUERY = "[{ '$match' : { '$and' : [ { 'workflows' : { '$elemMatch' : { 'direction': 'OUT','modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}}, "
			+"{ '$unwind': '$workflows'},"
			+ " { '$match' : {  'workflows.direction' : 'OUT' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "},'workflows.rulesFlag': {'$exists': false}}}]";
	
	public static final String RESOLVED_BOX_QUERY = "[{ '$match' : { '$and' : [ { 'workflows' : { '$elemMatch' : { 'status' : 'Resolved', 'direction': 'IN','modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}},"
			+" { '$unwind': '$workflows'},"
			+ "{ '$match' : { 'workflows.status' : 'Resolved','workflows.direction': 'IN','workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}]";
	
	public static final String PENDING_APPROVAL_QUERY = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open','modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}},"
			+"{ '$unwind': '$workflows'},"
			+ " { '$match' : { 'workflows.status' : 'Open','workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'workflows.direction' : { '$in' : ['PENDINGAPPROVAL','PND_REAGE','NOMINATE_OWNERSHIP']  } ,'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}},"
			+"{'$match': {'workflows.rulesFlag': {'$exists': false},'workflows.snoozeAction': {'$exists':false}}}]";
	
	public static final String POTENTIAL_ESCALATION_QUERY = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open', 'modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}},"
			+"{ '$unwind': '$workflows'},"
			+ " { '$match' : { 'workflows.status' : 'Open','workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'workflows.direction' : { '$in' : ['IN','PENDINGAPPROVAL','PND_REAGE','NOMINATE_OWNERSHIP']  } ,'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}, $or :[{'workflows.isConvCountEscalation' : 'Y'},{'workflows.isClientChaseEscalation'  : 'Y'},{'workflows.isSubjectEscalation' : 'Y'},{'workflows.responseTimeEscalationFlag' : 'Y'},{'workflows.ispendingApprovalEscalation' : 'Y'},{'workflows.isManualEscalation' : 'Y'}]}},"
			+"{'$match': {'workflows.rulesFlag': {'$exists': false}}}]";
	
	public static final String SNOOZED_QUERY = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open','modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}},"
			+"{ '$unwind': '$workflows'},"
			+ " { '$match' : { 'workflows.status' : 'Open', 'workflows.direction' : 'IN' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "},'workflows.rulesFlag' : { '$exists' : false},'workflows.snoozeAction' : 'Snooze'}}]";
	
	public static final String ASSIGNED_TO_ME_QUERY = "[{'$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open' , 'direction' : 'IN' , 'modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists':false} }}}]}} , "
			+ "{ '$unwind' : '$workflows'} ,"
			+" { '$match' : {'workflows.status' : 'Open' ,'workflows.direction' : 'IN' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}},"
			+" {'$match': {'workflows.rulesFlag': {'$exists': false},'workflows.snoozeAction': {'$exists':false}}} ,"
			+"{ '$match' : { 'workflows.assignedUserId' : '"+ ASSIGNED_USER_ID_EXP + "'}}]" ;
	
	public static final String UNASSIGNED_QUERY = "[{'$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open' , 'direction' : 'IN', 'modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}} , 'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists':false} }}}]}} , "
			+ "{ '$unwind' : '$workflows'} ,"
			+" { '$match' : {'workflows.status' : 'Open' ,'workflows.direction' : 'IN' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}}, 'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}, "
			+"{'$match': {'workflows.rulesFlag': {'$exists': false},'workflows.snoozeAction': {'$exists':false}}} ,"
			+"{ '$match' : { 'workflows.assignedUserId' : { '$exists' : false}}}]" ;
	
	public static final String NON_INQUIRY_QUERY = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open', 'modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}},"
			+"{ '$unwind': '$workflows'},"
			+ " { '$match' : { 'workflows.status' : 'Open', 'workflows.direction' : 'IN' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "},'workflows.rulesFlag' : { '$exists' : true},'workflows.rulesFlag.markAsNonInquiry' : { '$exists' : true}}}]";
	public static final String DRAFTS_QUERY_COUNT= "{ '$match' : { '$and' : [ { 'userId' : "+ ASSIGNED_USER_ID_EXP + " ]";
	
	public static final String TAG_VIEW_QUERY_COUNT = "[{'$match': {'$and': [{'workflows': {'$elemMatch': {'tag': '#TAGNAME#','assignedGroupId': #GROUPID#}}}]}}" 
			+ ", {'$unwind': '$workflows'}"
			+", {'$match': {'workflows.tag': '#TAGNAME#','workflows.assignedGroupId': #GROUPID#}}]" ;
	public static final String OPEN_INQUIRIES_BY_GROUP_COUNT = "[{'$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open' ,'direction' : 'IN' , 'assignedGroupId': #GROUPID#, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists':false} }}}]}} , "
			+ "{ '$unwind' : '$workflows'} ,"
			+" { '$match' : {'workflows.status' : 'Open' ,'workflows.direction' : 'IN' , 'workflows.assignedGroupId': #GROUPID#}},"
			+" {'$match': {'workflows.rulesFlag': {'$exists': false},'workflows.snoozeAction': {'$exists':false}}}]";
	
	public static final String OPEN_INQUIRIES_BY_REQUEST_TYPE_COUNT = "[{'$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open' , 'direction' : 'IN' , 'assignedGroupId': #GROUPID#, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists':false} }}}]}} , "
			+ "{ '$unwind' : '$workflows'} ,"
			+" { '$match' : {'workflows.status' : 'Open' ,'workflows.direction' : 'IN' ,'workflows.assignedGroupId': #GROUPID#}},"
			+" {'$match': {'workflows.rulesFlag': {'$exists': false},'workflows.snoozeAction': {'$exists':false}}},"
			+ "{'$match': {'workflows.requestType': '#REQUESTTYPE#'}}]";
	
	public static final String OPEN_INQUIRIES_BY_ASSIGNED_OWNER_COUNT = "[{'$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open' ,'direction' : 'IN' , 'assignedGroupId': { '$in' : #GROUPID#}, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists':false} }}}]}} , "
			+ "{ '$unwind' : '$workflows'} ,"
			+" { '$match' : {'workflows.status' : 'Open' ,'workflows.direction' : 'IN' ,'workflows.assignedGroupId': { '$in' : #GROUPID#}}},"
			+" {'$match': {'workflows.rulesFlag': {'$exists': false},'workflows.snoozeAction': {'$exists':false}}},"
			+ "{'$match': {'workflows.assignedUserId': '#ASSIGNEDOWNERID#'}}]";
	
	public static final String COMBINED_VIEW_QUERY_COUNT = "[{'$match': {'$and': [{'status': 'Open', 'workflows': {'$elemMatch': {'status': 'Open', 'direction': 'IN', 'assignedGroupId': {'$in': #GROUPID#}, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists': false}}}}]}}" + 
			", {'$unwind': '$workflows'}" + 
			", {'$match': {'workflows.status': 'Open', 'workflows.direction': 'IN','workflows.assignedGroupId': {'$in': #GROUPID#}}}" + 
			", {'$match': {'workflows.rulesFlag': {'$exists': false}, 'workflows.snoozeAction': {'$exists': false}}}" + 
			", {'$project': {'chatRoomMember': {'$cond': [{'$eq': [{'$ifNull': ['$symphonyChatRoomMember', null]}, null]}, ['#SOEID#'], '$symphonyChatRoomMember']}, 'id': 1, 'symphonyChatRoomMember': 1, 'readBy': 1}}" + 
			", {'$match': {'chatRoomMember': {'$in': ['#SOEID#']}}}" + 
			"]";
	
	public static final String CHAT_VIEW_QUERY_COUNT = "[{'$match': {'$and': [{'status': 'Open', 'workflows': {'$elemMatch': {'status': 'Open', 'direction': 'IN','assignedGroupId': {'$in': #GROUPID#}, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists': false}}}}]}}" + 
			", {'$unwind': '$workflows'}" + 
			", {'$match': {'workflows.status': 'Open', 'workflows.direction': 'IN','workflows.assignedGroupId': {'$in': #GROUPID#}}}" + 
			", {'$match': {'workflows.rulesFlag': {'$exists': false}, 'workflows.snoozeAction': {'$exists': false}}}" + 
			", {'$match': {'isSymphonyChatroom': 'Y'}}" +
			", {'$project': {'chatRoomMember': {'$cond': [{'$eq': [{'$ifNull': ['$symphonyChatRoomMember', null]}, null]}, ['#SOEID#'], '$symphonyChatRoomMember']}, 'id': 1, 'symphonyChatRoomMember': 1, 'readBy': 1}}" + 
			", {'$match': {'chatRoomMember': {'$in': ['#SOEID#']}}}" + 
			"]";
	public static final String FYI_QUERY_COUNT = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open', 'modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}},"
			+"{ '$unwind': '$workflows'},"
			+ " { '$match' : { 'workflows.status' : 'Open', 'workflows.direction' : 'IN' ,'workflows.modDate':{'$gte':{'$date':"+ MOD_DATE_EXP +"}},'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "},'workflows.rulesFlag' : { '$exists' : true},'workflows.rulesFlag.markAsNonInquiry' : { '$exists' : true}, 'workflows.rulesFlag.ruleType':'autoAssignmentRule'}}]";
	
	public static final String PERSONAL_MAIL_QUERY_COUNT = "[{ '$match' : { '$and' : [ { 'status' : 'Open' ,'workflows' : { '$elemMatch' : { 'status' : 'Open','direction': 'IN','personalFolders':{'$in':['#personalFolderName#']},'assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "}}}}]}}, "
			+"{ '$unwind': '$workflows'},"
			+ "{ '$match' : { 'workflows.status' : 'Open', 'workflows.direction' : 'IN' ,'workflows.assignedGroupId' : { '$in' : " + GROUP_ID_EXP + "},'workflows.rulesFlag' : { '$exists' : false},'workflows.snoozeAction': {'$exists':false},'workflows.personalFolders':{'$in':['#personalFolderName#']},'workflows.personalFolders':{'$exists':true}}}]";;

	public static final String PERSONAL_SMART_CATEGORY_UNREAD_COUNT_QUERY ="[{ '$match' : { 'status' : 'Open', 'workflows.status' : 'Open', 'workflows.direction' : 'IN', 'workflows.assignedGroupId' : { '$in' : " + IND_GROUP_ID_EXP + "}, 'workflows.modDate' : { '$gte' : { '$date' : "+ MOD_DATE_EXP + "}}}}," +
			"{ '$unwind' : '$workflows'}," +
			"{ '$match' : { 'workflows.status' : 'Open', 'workflows.direction' : 'IN', 'workflows.assignedGroupId' : { '$in' : " + IND_GROUP_ID_EXP + "}, 'workflows.modDate' : { '$gte' : { '$date' : " + MOD_DATE_EXP + "}}, 'workflows.personalFolders' : { '$all' : " + CATEGORY_INDEX_EXP + "}}}," +
			"{ '$project' : { '_id' : 1, 'workflows' : 1, 'readBy' : { '$ifNull' : ['$readBy', []]}}}," +
			"{ '$project' : { 'inquiryId' : '$_id', 'userId' : { '$literal' : '"+ IND_USER_ID_EXP + "'}, 'workflows' : 1, 'readBy' : 1, 'modDate' : '$workflows.modDate', 'readByUser' : { '$cond' : { 'if' : { '$in' : ['" + IND_USER_ID_EXP +"', '$readBy']}, 'then' : 1, 'else' : 0}}}}," +
			"{ '$group' : { '_id' : null, 'USER_ID' : { '$addToSet' : '$userId'}, 'TOTAL' : { '$sum' : 1}, 'TOTAL_READ' : { '$sum' : { '$cond' : { 'if' : { '$eq' : ['$readByUser', 1]}, 'then' : 1, 'else' : 0}}}, 'TOTAL_UNREAD' : { '$sum' : { '$cond' : { 'if' : { '$eq' : ['$readByUser', 0]}, 'then' : 1, 'else' : 0}}}}}]";


	/**Query Operators */
	
	public static final String AND_OPERATOR = "$and";
	public static final String MATCH_OPERATOR = "$match";
	public static final String SUM_OPERATOR = "$sum";
	public static final String GROUP_OPERATOR = "$group";

}