package com.citi.icg.qma.common.server.dao;

import java.util.Date;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "InquiryActionStatistics", noClassnameStored = true)
public class InquiryActionStatistics
{
	// C153176-1093- Enhance stats
	@Id
	private String id;
	private Long inquiryId;
	private Long groupId;
	private String firstGroupInTo;
	private String uiActionReply;
	private String uiActionResolveWithoutReply;
	private String uiActionResolveWithReply;
	private String uiActionForward;
	private String uiActionAssignReqType;
	private String uiActionAssignOwner;
	private String extSenderDomain;
	private String actionAutoAssignReqType;
	private String actionAutoAssignOwner;
	private String action;
	private Date actionTime;
	private String isInTo;
	private String isInCc;
	private String groupName;
	public InquiryActionStatistics()
	{
		super();
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public Long getInquiryId()
	{
		return inquiryId;
	}

	public void setInquiryId(Long inquiryId)
	{
		this.inquiryId = inquiryId;
	}

	public Long getGroupId()
	{
		return groupId;
	}

	public void setGroupId(Long groupId)
	{
		this.groupId = groupId;
	}

	public String getFirstGroupInTo()
	{
		return firstGroupInTo;
	}

	public void setFirstGroupInTo(String firstGroupInTo)
	{
		this.firstGroupInTo = firstGroupInTo;
	}

	public String getUiActionReply()
	{
		return uiActionReply;
	}

	public void setUiActionReply(String uiActionReply)
	{
		this.uiActionReply = uiActionReply;
	}

	public String getUiActionResolveWithoutReply()
	{
		return uiActionResolveWithoutReply;
	}

	public void setUiActionResolveWithoutReply(String uiActionResolveWithoutReply)
	{
		this.uiActionResolveWithoutReply = uiActionResolveWithoutReply;
	}

	public String getUiActionForward()
	{
		return uiActionForward;
	}

	public void setUiActionForward(String uiActionForward)
	{
		this.uiActionForward = uiActionForward;
	}

	public String getUiActionAssignReqType()
	{
		return uiActionAssignReqType;
	}

	public void setUiActionAssignReqType(String uiActionAssignReqType)
	{
		this.uiActionAssignReqType = uiActionAssignReqType;
	}

	public String getUiActionAssignOwner()
	{
		return uiActionAssignOwner;
	}

	public void setUiActionAssignOwner(String uiActionAssignOwner)
	{
		this.uiActionAssignOwner = uiActionAssignOwner;
	}

	public String getExtSenderDomain()
	{
		return extSenderDomain;
	}

	public void setExtSenderDomain(String extSenderDomain)
	{
		this.extSenderDomain = extSenderDomain;
	}

	public String getUiActionResolveWithReply()
	{
		return uiActionResolveWithReply;
	}

	public void setUiActionResolveWithReply(String uiActionResolveWithReply)
	{
		this.uiActionResolveWithReply = uiActionResolveWithReply;
	}

	public String getActionAutoAssignReqType()
	{
		return actionAutoAssignReqType;
	}

	public void setActionAutoAssignReqType(String actionAutoAssignReqType)
	{
		this.actionAutoAssignReqType = actionAutoAssignReqType;
	}

	public String getActionAutoAssignOwner()
	{
		return actionAutoAssignOwner;
	}

	public void setActionAutoAssignOwner(String actionAutoAssignOwner)
	{
		this.actionAutoAssignOwner = actionAutoAssignOwner;
	}

	public String getAction()
	{
		return action;
	}

	public void setAction(String action)
	{
		this.action = action;
	}

	public Date getActionTime()
	{
		return actionTime;
	}

	public void setActionTime(Date actionTime)
	{
		this.actionTime = actionTime;
	}

	public String getIsInTo()
	{
		return isInTo;
	}

	public void setIsInTo(String isInTo)
	{
		this.isInTo = isInTo;
	}

	public String getIsInCc()
	{
		return isInCc;
	}

	public void setIsInCc(String isInCc)
	{
		this.isInCc = isInCc;
	}
	
	public String getGroupName()
	{
		return groupName;
	}

	public void setGroupName(String groupName)
	{
		this.groupName = groupName;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((groupId == null) ? 0 : groupId.hashCode());
		result = prime * result + ((inquiryId == null) ? 0 : inquiryId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InquiryActionStatistics other = (InquiryActionStatistics) obj;
		if (groupId == null)
		{
			if (other.groupId != null)
				return false;
		}
		else if (!groupId.equals(other.groupId))
			return false;
		if (inquiryId == null)
		{
			if (other.inquiryId != null)
				return false;
		}
		else if (!inquiryId.equals(other.inquiryId))
			return false;
		return true;
	}
}
