package com.citi.icg.qma.common.core.config;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ConfigManager
{
	private static final String DEFAULT_ENV = "development";
	//Sonar fix - remove the unused variables
	private static String SITE_PROPS = "site.properties";
	private static String DEFAULT_SITE_PROPS = "site.development.properties";
	private static String HOSTS_PROPS = "hosts.properties";
	private static String MISSING_READER = "";
	private static String BAD_READER = "";
	public static final String ATAPS_HOME = "ATAPS_HOME";
	private static final String APP_NAME = "application.name";
	private static final String LOG_DIR = "log.dir";
	private static final String HOST_NAME = "host.name";
	
	private static ConfigManager self;
	private String atapsHome;
	private String environment;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigManager.class);//Sonar Fix -- Standard outputs should not be used directly to log anything
	
	private ConfigManager()
	{
		Properties props = null;
		atapsHome = System.getProperty(ATAPS_HOME);
		LOGGER.info( "{} = {}", ATAPS_HOME, atapsHome);
		String sitePropertyValue = System.getProperty(SITE_PROPS);
		environment = DEFAULT_ENV;
		if (sitePropertyValue == null)
		{
			sitePropertyValue = DEFAULT_SITE_PROPS;
			String hostsPropertyValue = System.getProperty(HOSTS_PROPS);
			if (hostsPropertyValue == null)
			{
				//Use ATAPS_HOME/etc/hosts.properties
				if (atapsHome != null)
				{
					hostsPropertyValue = atapsHome + "/etc/" + HOSTS_PROPS;
				}
				else
				{
					hostsPropertyValue = "/etc/" + HOSTS_PROPS;
				}
			}
			
			//1 read the host.properties
			props = PropertiesLoader.loadOurProperties(hostsPropertyValue);
			
			String hostname = null;
			try {
				hostname = InetAddress.getLocalHost().getCanonicalHostName();
			} catch (UnknownHostException e) {
				LOGGER.error("OS Level failure unable to get hostname of localhost : ", e);//Sonar fix - either log or rethrow the exception
				System.exit(-1);
			}
	        System.setProperty(HOST_NAME, hostname.substring(0, hostname.indexOf('.')));

			if (props.getProperty(hostname) != null) //By default all Unlisted Hosts are development
			{
				environment = props.getProperty(hostname);
				sitePropertyValue = "site." + environment + ".properties";
			}
		}
		else
		{
			environment = sitePropertyValue.substring(sitePropertyValue.indexOf('.')+1, sitePropertyValue.lastIndexOf('.'));
		}

		LOGGER.info("Site properties being used : {}" , sitePropertyValue);
		props = PropertiesLoader.loadOurProperties(sitePropertyValue);
		
        Enumeration<?> names = props.propertyNames();
        while(names.hasMoreElements())
        {
            String name = (String)names.nextElement();
            System.setProperty(name,props.getProperty(name));
        }
        
        System.setProperty("env.name", environment);
		InetAddress id = null;
		try
		{
			id = InetAddress.getLocalHost();
		}
		catch (UnknownHostException e)
		{
			LOGGER.error("UnknownHostException : ConfigManager contructor : ", e);//Sonar Fix -- Throwable.printStackTrace(...) should not be called
		}
		String hostName = null;
		if (id == null)
		{
			hostName = "Unknown";
		}
		else
		{
			hostName = id.getHostName();
		}
        System.setProperty(HOST_NAME, hostName);

        String appName = System.getProperty(APP_NAME);
		if (appName == null)
		{
			String username = System.getProperty("user.name");
			if (username == null)
			{
				username = "UnKnown";
			}
			appName = "StandAlone-[" + hostName +"/"+ username + "]";
			System.setProperty(APP_NAME, appName);
		}
		String logDir = System.getProperty(LOG_DIR);
		if (logDir == null)
		{
			logDir =  atapsHome + "/logs";
			System.setProperty(LOG_DIR, logDir);
		}
		
        
		System.getProperties().putAll(new PropertiesExpander(System.getProperties()).expandProperties());
	}
	
	public static ConfigManager getInstance()
	{
		if (self == null)
		{
			synchronized (ConfigManager.class)
			{
				self = new ConfigManager();
			}
		}
		return self;
	}

	public <T> T getConfiguration(String name) throws ConfigurationException
	{
		return (T)getConfiguration(name, null);
	}

	public <T> T getConfiguration(String name, Object input) throws ConfigurationException
	{
		//Sonar fix - remove the useless assignments
		
		String readerClassName = System.getProperty(name);
		if (readerClassName == null)
		{
			throw new ConfigurationException(MISSING_READER);
		}
		
		Object createdClass = null;
		try
		{
			createdClass = Class.forName(readerClassName).newInstance();
		}
		catch (Exception e)
		{
			throw new ConfigurationException(e.getMessage(), e);
		}
		
		if (!ConfigReader.class.isAssignableFrom(createdClass.getClass()))
		{
			throw new ConfigurationException(BAD_READER);			
		}
		ConfigReader<T> reader = (ConfigReader<T>)createdClass;
		
		return (T)reader.readConfiguration(input);
	}
	
	public Properties getProperties()
	{
		return System.getProperties();
	}
	
	public String getEnvironment()
	{
		return environment;
	}
	
	public String getATAPSHome()
	{
		return atapsHome;
	}
}
