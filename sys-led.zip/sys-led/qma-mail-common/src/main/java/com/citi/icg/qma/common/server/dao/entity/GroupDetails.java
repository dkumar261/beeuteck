package com.citi.icg.qma.common.server.dao.entity;

import java.io.Serializable;


public class GroupDetails implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7557861484028696675L;
	private Long id;
	private String name;
	private String groupEmail;
	private Boolean active;
	private String crtDate;
	private String modDate;
	private String crtBy;
	private String modBy;
	private Boolean makerCheckerRqd;
	private Boolean autoReplyEnable;
	private Boolean predictiveRecipients;
	private String organisation;
	private String firstLevelHeirarchy;
	private String secondLevelHeirarchy;
	private String thirdLevelHeirarchy;
	private String gfcid;
	private Boolean attachmentBasedMakerChecker;
	private Boolean isEmailSharingBlocked;
	private String managerSoeid;
	private String pipeWithQuotes = "\"|\"";
	
	private String hierarchyLevel1Name;
	private String hierarchyLevel1UserId;
	private String hierarchyLevel1Phone;
	private String hierarchyLevel1Department;
	private String hierarchyLevel1Email;
	
	private String hierarchyLevel2Name;
	private String hierarchyLevel2UserId;
	private String hierarchyLevel2Phone;
	private String hierarchyLevel2Department;
	private String hierarchyLevel2Email;

	private String hierarchyLevel3Name;
	private String hierarchyLevel3UserId;
	private String hierarchyLevel3Phone;
	private String hierarchyLevel3Department;
	private String hierarchyLevel3Email;
	
	private String hierarchyLevel4Name;
	private String hierarchyLevel4UserId;
	private String hierarchyLevel4Phone;
	private String hierarchyLevel4Department;
	private String hierarchyLevel4Email;
	
	private String hierarchyLevel5Name;
	private String hierarchyLevel5UserId;
	private String hierarchyLevel5Phone;
	private String hierarchyLevel5Department;
	private String hierarchyLevel5Email;
	
	private String hierarchyLevel6Name;
	private String hierarchyLevel6UserId;
	private String hierarchyLevel6Phone;
	private String hierarchyLevel6Department;
	private String hierarchyLevel6Email;
	
	private String hierarchyLevel7Name;
	private String hierarchyLevel7UserId;
	private String hierarchyLevel7Phone;
	private String hierarchyLevel7Department;
	private String hierarchyLevel7Email;
	
	private String hierarchyLevel8Name;
	private String hierarchyLevel8UserId;
	private String hierarchyLevel8Phone;
	private String hierarchyLevel8Department;
	private String hierarchyLevel8Email;
	
	private String hierarchyLevel9Name;
	private String hierarchyLevel9UserId;
	private String hierarchyLevel9Phone;
	private String hierarchyLevel9Department;
	private String hierarchyLevel9Email;
	
	private String hierarchyLevel10Name;
	private String hierarchyLevel10UserId;
	private String hierarchyLevel10Phone;
	private String hierarchyLevel10Department;
	private String hierarchyLevel10Email;
	
	private String hierarchyLevel11Name;
	private String hierarchyLevel11UserId;
	private String hierarchyLevel11Phone;
	private String hierarchyLevel11Department;
	private String hierarchyLevel11Email;
	
	private String hierarchyLevel12Name;
	private String hierarchyLevel12UserId;
	private String hierarchyLevel12Phone;
	private String hierarchyLevel12Department;
	private String hierarchyLevel12Email;
	
	private String hierarchyLevel13Name;
	private String hierarchyLevel13UserId;
	private String hierarchyLevel13Phone;
	private String hierarchyLevel13Department;
	private String hierarchyLevel13Email;
	
	private String hierarchyLevel14Name;
	private String hierarchyLevel14UserId;
	private String hierarchyLevel14Phone;
	private String hierarchyLevel14Department;
	private String hierarchyLevel14Email;
	
	private String hierarchyLevel15Name;
	private String hierarchyLevel15UserId;
	private String hierarchyLevel15Phone;
	private String hierarchyLevel15Department;
	private String hierarchyLevel15Email;
	private String isHolidayBasedAgeCalculation;
	private String orgHierarchyLevel1;
	private String orgHierarchyLevel2;
	private String orgHierarchyLevel3;
	private boolean enableAutoAssignment;
	private String escalationCriteriaSetup;
	private String convCountThreshold;
	private String responseTimeThreshold;
	private String peerReviewResponseTimeThreshold;
	private String workShiftTimeZone;
	private String shiftStartTime;
	private String shiftEndTime;
	private String nonWorkingDays;
	private Integer ruleCount;
	private Integer nonInqRuleCnt;
	private Integer reqRuleCnt;
	private Integer userRuleCnt;
	private Integer tagRuleCnt;
	private Integer processingRegionRuleCnt;
	private String peopleHierarchyL5;
	private String peopleHierarchyL6;
	private String peopleHierarchyL7;
	private String country;
	private Boolean enableInquirySubStatus;
	private Boolean isGfidMandatory;
	private Boolean isUINotificationPopupEnabled;
	private Boolean isInquirySourceMandatory;
	private Boolean isProcessingRegionMandatory;
	private Boolean isRootCauseMandatory;
	private Boolean isRootCauseMandatoryWOReply;
	private Boolean isTagMandatory;
	
	private String orgHierarchyLevel4;
	private String orgHierarchyLevel5;
	private String orgHierarchyLevel6;
	private String orgHierarchyLevel7;
	private String orgHierarchyLevel8;
	private Boolean includeMyGroupInCC;
	
	private Boolean isCustomizedAutoResponseEnabled;
	private Boolean isCustomizedAutoResponseEnabledForNewInquiry;
	private Boolean isCustomizedAutoResponseEnabledForUserAssignment;

	/**
	 * @return the id
	 */
	public Long getId()
	{
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id)
	{
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * @return the groupEmail
	 */
	public String getGroupEmail()
	{
		return groupEmail;
	}

	/**
	 * @param groupEmail
	 *            the groupEmail to set
	 */
	public void setGroupEmail(String groupEmail)
	{
		this.groupEmail = groupEmail;
	}

	/**
	 * @return the active
	 */
	public Boolean getActive()
	{
		return active;
	}

	/**
	 * @param active
	 *            the active to set
	 */
	public void setActive(Boolean active)
	{
		this.active = active;
	}

	/**
	 * @return the crtBy
	 */
	public String getCrtBy()
	{
		return crtBy;
	}

	/**
	 * @param crtBy
	 *            the crtBy to set
	 */
	public void setCrtBy(String crtBy)
	{
		this.crtBy = crtBy;
	}

	/**
	 * @return the modBy
	 */
	public String getModBy()
	{
		return modBy;
	}

	/**
	 * @param modBy
	 *            the modBy to set
	 */
	public void setModBy(String modBy)
	{
		this.modBy = modBy;
	}

	/**
	 * @return the makerCheckerRqd
	 */
	public Boolean getMakerCheckerRqd()
	{
		return makerCheckerRqd;
	}

	/**
	 * @param makerCheckerRqd
	 *            the makerCheckerRqd to set
	 */
	public void setMakerCheckerRqd(Boolean makerCheckerRqd)
	{
		this.makerCheckerRqd = makerCheckerRqd;
	}

	/**
	 * @return the predictiveRecipients
	 */
	public Boolean getPredictiveRecipients()
	{
		return predictiveRecipients;
	}

	/**
	 * @param predictiveRecipients
	 *            the predictiveRecipients to set
	 */
	public void setPredictiveRecipients(Boolean predictiveRecipients)
	{
		this.predictiveRecipients = predictiveRecipients;
	}

	/**
	 * @return the organisation
	 */
	public String getOrganisation()
	{
		return organisation;
	}

	/**
	 * @param organisation
	 *            the organisation to set
	 */
	public void setOrganisation(String organisation)
	{
		this.organisation = organisation;
	}

	/**
	 * @return the firstLevelHeirarchy
	 */
	public String getFirstLevelHeirarchy()
	{
		return firstLevelHeirarchy;
	}

	/**
	 * @param firstLevelHeirarchy
	 *            the firstLevelHeirarchy to set
	 */
	public void setFirstLevelHeirarchy(String firstLevelHeirarchy)
	{
		this.firstLevelHeirarchy = firstLevelHeirarchy;
	}

	/**
	 * @return the secondLevelHeirarchy
	 */
	public String getSecondLevelHeirarchy()
	{
		return secondLevelHeirarchy;
	}

	/**
	 * @param secondLevelHeirarchy
	 *            the secondLevelHeirarchy to set
	 */
	public void setSecondLevelHeirarchy(String secondLevelHeirarchy)
	{
		this.secondLevelHeirarchy = secondLevelHeirarchy;
	}

	/**
	 * @return the thirdLevelHeirarchy
	 */
	public String getThirdLevelHeirarchy()
	{
		return thirdLevelHeirarchy;
	}

	/**
	 * @param thirdLevelHeirarchy
	 *            the thirdLevelHeirarchy to set
	 */
	public void setThirdLevelHeirarchy(String thirdLevelHeirarchy)
	{
		this.thirdLevelHeirarchy = thirdLevelHeirarchy;
	}

	/**
	 * @return the gfcid
	 */
	public String getGfcid()
	{
		return gfcid;
	}

	/**
	 * @param gfcid
	 *            the gfcid to set
	 */
	public void setGfcid(String gfcid)
	{
		this.gfcid = gfcid;
	}

	/**
	 * @return the attachmentBasedMakerChecker
	 */
	public Boolean getAttachmentBasedMakerChecker()
	{
		return attachmentBasedMakerChecker;
	}

	/**
	 * @param attachmentBasedMakerChecker
	 *            the attachmentBasedMakerChecker to set
	 */
	public void setAttachmentBasedMakerChecker(Boolean attachmentBasedMakerChecker)
	{
		this.attachmentBasedMakerChecker = attachmentBasedMakerChecker;
	}
	
	

	/**
	 * @return the hierarchyLevel1Name
	 */
	public String getHierarchyLevel1Name()
	{
		return hierarchyLevel1Name;
	}

	/**
	 * @param hierarchyLevel1Name the hierarchyLevel1Name to set
	 */
	public void setHierarchyLevel1Name(String hierarchyLevel1Name)
	{
		this.hierarchyLevel1Name = hierarchyLevel1Name;
	}

	/**
	 * @return the hierarchyLevel1UserId
	 */
	public String getHierarchyLevel1UserId()
	{
		return hierarchyLevel1UserId;
	}

	/**
	 * @param hierarchyLevel1UserId the hierarchyLevel1UserId to set
	 */
	public void setHierarchyLevel1UserId(String hierarchyLevel1UserId)
	{
		this.hierarchyLevel1UserId = hierarchyLevel1UserId;
	}

	/**
	 * @return the hierarchyLevel1Phone
	 */
	public String getHierarchyLevel1Phone()
	{
		return hierarchyLevel1Phone;
	}

	/**
	 * @param hierarchyLevel1Phone the hierarchyLevel1Phone to set
	 */
	public void setHierarchyLevel1Phone(String hierarchyLevel1Phone)
	{
		this.hierarchyLevel1Phone = hierarchyLevel1Phone;
	}

	/**
	 * @return the hierarchyLevel1Department
	 */
	public String getHierarchyLevel1Department()
	{
		return hierarchyLevel1Department;
	}

	/**
	 * @param hierarchyLevel1Department the hierarchyLevel1Department to set
	 */
	public void setHierarchyLevel1Department(String hierarchyLevel1Department)
	{
		this.hierarchyLevel1Department = hierarchyLevel1Department;
	}

	/**
	 * @return the hierarchyLevel1Email
	 */
	public String getHierarchyLevel1Email()
	{
		return hierarchyLevel1Email;
	}

	/**
	 * @param hierarchyLevel1Email the hierarchyLevel1Email to set
	 */
	public void setHierarchyLevel1Email(String hierarchyLevel1Email)
	{
		this.hierarchyLevel1Email = hierarchyLevel1Email;
	}

	/**
	 * @return the hierarchyLevel2Name
	 */
	public String getHierarchyLevel2Name()
	{
		return hierarchyLevel2Name;
	}

	/**
	 * @param hierarchyLevel2Name the hierarchyLevel2Name to set
	 */
	public void setHierarchyLevel2Name(String hierarchyLevel2Name)
	{
		this.hierarchyLevel2Name = hierarchyLevel2Name;
	}

	/**
	 * @return the hierarchyLevel2UserId
	 */
	public String getHierarchyLevel2UserId()
	{
		return hierarchyLevel2UserId;
	}

	/**
	 * @param hierarchyLevel2UserId the hierarchyLevel2UserId to set
	 */
	public void setHierarchyLevel2UserId(String hierarchyLevel2UserId)
	{
		this.hierarchyLevel2UserId = hierarchyLevel2UserId;
	}

	/**
	 * @return the hierarchyLevel2Phone
	 */
	public String getHierarchyLevel2Phone()
	{
		return hierarchyLevel2Phone;
	}

	/**
	 * @param hierarchyLevel2Phone the hierarchyLevel2Phone to set
	 */
	public void setHierarchyLevel2Phone(String hierarchyLevel2Phone)
	{
		this.hierarchyLevel2Phone = hierarchyLevel2Phone;
	}

	/**
	 * @return the hierarchyLevel2Department
	 */
	public String getHierarchyLevel2Department()
	{
		return hierarchyLevel2Department;
	}

	/**
	 * @param hierarchyLevel2Department the hierarchyLevel2Department to set
	 */
	public void setHierarchyLevel2Department(String hierarchyLevel2Department)
	{
		this.hierarchyLevel2Department = hierarchyLevel2Department;
	}

	/**
	 * @return the hierarchyLevel2Email
	 */
	public String getHierarchyLevel2Email()
	{
		return hierarchyLevel2Email;
	}

	/**
	 * @param hierarchyLevel2Email the hierarchyLevel2Email to set
	 */
	public void setHierarchyLevel2Email(String hierarchyLevel2Email)
	{
		this.hierarchyLevel2Email = hierarchyLevel2Email;
	}

	/**
	 * @return the hierarchyLevel3Name
	 */
	public String getHierarchyLevel3Name()
	{
		return hierarchyLevel3Name;
	}

	/**
	 * @param hierarchyLevel3Name the hierarchyLevel3Name to set
	 */
	public void setHierarchyLevel3Name(String hierarchyLevel3Name)
	{
		this.hierarchyLevel3Name = hierarchyLevel3Name;
	}

	/**
	 * @return the hierarchyLevel3UserId
	 */
	public String getHierarchyLevel3UserId()
	{
		return hierarchyLevel3UserId;
	}

	/**
	 * @param hierarchyLevel3UserId the hierarchyLevel3UserId to set
	 */
	public void setHierarchyLevel3UserId(String hierarchyLevel3UserId)
	{
		this.hierarchyLevel3UserId = hierarchyLevel3UserId;
	}

	/**
	 * @return the hierarchyLevel3Phone
	 */
	public String getHierarchyLevel3Phone()
	{
		return hierarchyLevel3Phone;
	}

	/**
	 * @param hierarchyLevel3Phone the hierarchyLevel3Phone to set
	 */
	public void setHierarchyLevel3Phone(String hierarchyLevel3Phone)
	{
		this.hierarchyLevel3Phone = hierarchyLevel3Phone;
	}

	/**
	 * @return the hierarchyLevel3Department
	 */
	public String getHierarchyLevel3Department()
	{
		return hierarchyLevel3Department;
	}

	/**
	 * @param hierarchyLevel3Department the hierarchyLevel3Department to set
	 */
	public void setHierarchyLevel3Department(String hierarchyLevel3Department)
	{
		this.hierarchyLevel3Department = hierarchyLevel3Department;
	}

	/**
	 * @return the hierarchyLevel3Email
	 */
	public String getHierarchyLevel3Email()
	{
		return hierarchyLevel3Email;
	}

	/**
	 * @param hierarchyLevel3Email the hierarchyLevel3Email to set
	 */
	public void setHierarchyLevel3Email(String hierarchyLevel3Email)
	{
		this.hierarchyLevel3Email = hierarchyLevel3Email;
	}

	/**
	 * @return the hierarchyLevel4Name
	 */
	public String getHierarchyLevel4Name()
	{
		return hierarchyLevel4Name;
	}

	/**
	 * @param hierarchyLevel4Name the hierarchyLevel4Name to set
	 */
	public void setHierarchyLevel4Name(String hierarchyLevel4Name)
	{
		this.hierarchyLevel4Name = hierarchyLevel4Name;
	}

	/**
	 * @return the hierarchyLevel4UserId
	 */
	public String getHierarchyLevel4UserId()
	{
		return hierarchyLevel4UserId;
	}

	/**
	 * @param hierarchyLevel4UserId the hierarchyLevel4UserId to set
	 */
	public void setHierarchyLevel4UserId(String hierarchyLevel4UserId)
	{
		this.hierarchyLevel4UserId = hierarchyLevel4UserId;
	}

	/**
	 * @return the hierarchyLevel4Phone
	 */
	public String getHierarchyLevel4Phone()
	{
		return hierarchyLevel4Phone;
	}

	/**
	 * @param hierarchyLevel4Phone the hierarchyLevel4Phone to set
	 */
	public void setHierarchyLevel4Phone(String hierarchyLevel4Phone)
	{
		this.hierarchyLevel4Phone = hierarchyLevel4Phone;
	}

	/**
	 * @return the hierarchyLevel4Department
	 */
	public String getHierarchyLevel4Department()
	{
		return hierarchyLevel4Department;
	}

	/**
	 * @param hierarchyLevel4Department the hierarchyLevel4Department to set
	 */
	public void setHierarchyLevel4Department(String hierarchyLevel4Department)
	{
		this.hierarchyLevel4Department = hierarchyLevel4Department;
	}

	/**
	 * @return the hierarchyLevel4Email
	 */
	public String getHierarchyLevel4Email()
	{
		return hierarchyLevel4Email;
	}

	/**
	 * @param hierarchyLevel4Email the hierarchyLevel4Email to set
	 */
	public void setHierarchyLevel4Email(String hierarchyLevel4Email)
	{
		this.hierarchyLevel4Email = hierarchyLevel4Email;
	}

	/**
	 * @return the hierarchyLevel5Name
	 */
	public String getHierarchyLevel5Name()
	{
		return hierarchyLevel5Name;
	}

	/**
	 * @param hierarchyLevel5Name the hierarchyLevel5Name to set
	 */
	public void setHierarchyLevel5Name(String hierarchyLevel5Name)
	{
		this.hierarchyLevel5Name = hierarchyLevel5Name;
	}

	/**
	 * @return the hierarchyLevel5UserId
	 */
	public String getHierarchyLevel5UserId()
	{
		return hierarchyLevel5UserId;
	}

	/**
	 * @param hierarchyLevel5UserId the hierarchyLevel5UserId to set
	 */
	public void setHierarchyLevel5UserId(String hierarchyLevel5UserId)
	{
		this.hierarchyLevel5UserId = hierarchyLevel5UserId;
	}

	/**
	 * @return the hierarchyLevel5Phone
	 */
	public String getHierarchyLevel5Phone()
	{
		return hierarchyLevel5Phone;
	}

	/**
	 * @param hierarchyLevel5Phone the hierarchyLevel5Phone to set
	 */
	public void setHierarchyLevel5Phone(String hierarchyLevel5Phone)
	{
		this.hierarchyLevel5Phone = hierarchyLevel5Phone;
	}

	/**
	 * @return the hierarchyLevel5Department
	 */
	public String getHierarchyLevel5Department()
	{
		return hierarchyLevel5Department;
	}

	/**
	 * @param hierarchyLevel5Department the hierarchyLevel5Department to set
	 */
	public void setHierarchyLevel5Department(String hierarchyLevel5Department)
	{
		this.hierarchyLevel5Department = hierarchyLevel5Department;
	}

	/**
	 * @return the hierarchyLevel5Email
	 */
	public String getHierarchyLevel5Email()
	{
		return hierarchyLevel5Email;
	}

	/**
	 * @param hierarchyLevel5Email the hierarchyLevel5Email to set
	 */
	public void setHierarchyLevel5Email(String hierarchyLevel5Email)
	{
		this.hierarchyLevel5Email = hierarchyLevel5Email;
	}

	/**
	 * @return the hierarchyLevel6Name
	 */
	public String getHierarchyLevel6Name()
	{
		return hierarchyLevel6Name;
	}

	/**
	 * @param hierarchyLevel6Name the hierarchyLevel6Name to set
	 */
	public void setHierarchyLevel6Name(String hierarchyLevel6Name)
	{
		this.hierarchyLevel6Name = hierarchyLevel6Name;
	}

	/**
	 * @return the hierarchyLevel6UserId
	 */
	public String getHierarchyLevel6UserId()
	{
		return hierarchyLevel6UserId;
	}

	/**
	 * @param hierarchyLevel6UserId the hierarchyLevel6UserId to set
	 */
	public void setHierarchyLevel6UserId(String hierarchyLevel6UserId)
	{
		this.hierarchyLevel6UserId = hierarchyLevel6UserId;
	}

	/**
	 * @return the hierarchyLevel6Phone
	 */
	public String getHierarchyLevel6Phone()
	{
		return hierarchyLevel6Phone;
	}

	/**
	 * @param hierarchyLevel6Phone the hierarchyLevel6Phone to set
	 */
	public void setHierarchyLevel6Phone(String hierarchyLevel6Phone)
	{
		this.hierarchyLevel6Phone = hierarchyLevel6Phone;
	}

	/**
	 * @return the hierarchyLevel6Department
	 */
	public String getHierarchyLevel6Department()
	{
		return hierarchyLevel6Department;
	}

	/**
	 * @param hierarchyLevel6Department the hierarchyLevel6Department to set
	 */
	public void setHierarchyLevel6Department(String hierarchyLevel6Department)
	{
		this.hierarchyLevel6Department = hierarchyLevel6Department;
	}

	/**
	 * @return the hierarchyLevel6Email
	 */
	public String getHierarchyLevel6Email()
	{
		return hierarchyLevel6Email;
	}

	/**
	 * @param hierarchyLevel6Email the hierarchyLevel6Email to set
	 */
	public void setHierarchyLevel6Email(String hierarchyLevel6Email)
	{
		this.hierarchyLevel6Email = hierarchyLevel6Email;
	}

	/**
	 * @return the hierarchyLevel7Name
	 */
	public String getHierarchyLevel7Name()
	{
		return hierarchyLevel7Name;
	}

	/**
	 * @param hierarchyLevel7Name the hierarchyLevel7Name to set
	 */
	public void setHierarchyLevel7Name(String hierarchyLevel7Name)
	{
		this.hierarchyLevel7Name = hierarchyLevel7Name;
	}

	/**
	 * @return the hierarchyLevel7UserId
	 */
	public String getHierarchyLevel7UserId()
	{
		return hierarchyLevel7UserId;
	}

	/**
	 * @param hierarchyLevel7UserId the hierarchyLevel7UserId to set
	 */
	public void setHierarchyLevel7UserId(String hierarchyLevel7UserId)
	{
		this.hierarchyLevel7UserId = hierarchyLevel7UserId;
	}

	/**
	 * @return the hierarchyLevel7Phone
	 */
	public String getHierarchyLevel7Phone()
	{
		return hierarchyLevel7Phone;
	}

	/**
	 * @param hierarchyLevel7Phone the hierarchyLevel7Phone to set
	 */
	public void setHierarchyLevel7Phone(String hierarchyLevel7Phone)
	{
		this.hierarchyLevel7Phone = hierarchyLevel7Phone;
	}

	/**
	 * @return the hierarchyLevel7Department
	 */
	public String getHierarchyLevel7Department()
	{
		return hierarchyLevel7Department;
	}

	/**
	 * @param hierarchyLevel7Department the hierarchyLevel7Department to set
	 */
	public void setHierarchyLevel7Department(String hierarchyLevel7Department)
	{
		this.hierarchyLevel7Department = hierarchyLevel7Department;
	}

	/**
	 * @return the hierarchyLevel7Email
	 */
	public String getHierarchyLevel7Email()
	{
		return hierarchyLevel7Email;
	}

	/**
	 * @param hierarchyLevel7Email the hierarchyLevel7Email to set
	 */
	public void setHierarchyLevel7Email(String hierarchyLevel7Email)
	{
		this.hierarchyLevel7Email = hierarchyLevel7Email;
	}

	/**
	 * @return the hierarchyLevel8Name
	 */
	public String getHierarchyLevel8Name()
	{
		return hierarchyLevel8Name;
	}

	/**
	 * @param hierarchyLevel8Name the hierarchyLevel8Name to set
	 */
	public void setHierarchyLevel8Name(String hierarchyLevel8Name)
	{
		this.hierarchyLevel8Name = hierarchyLevel8Name;
	}

	/**
	 * @return the hierarchyLevel8UserId
	 */
	public String getHierarchyLevel8UserId()
	{
		return hierarchyLevel8UserId;
	}

	/**
	 * @param hierarchyLevel8UserId the hierarchyLevel8UserId to set
	 */
	public void setHierarchyLevel8UserId(String hierarchyLevel8UserId)
	{
		this.hierarchyLevel8UserId = hierarchyLevel8UserId;
	}

	/**
	 * @return the hierarchyLevel8Phone
	 */
	public String getHierarchyLevel8Phone()
	{
		return hierarchyLevel8Phone;
	}

	/**
	 * @param hierarchyLevel8Phone the hierarchyLevel8Phone to set
	 */
	public void setHierarchyLevel8Phone(String hierarchyLevel8Phone)
	{
		this.hierarchyLevel8Phone = hierarchyLevel8Phone;
	}

	/**
	 * @return the hierarchyLevel8Department
	 */
	public String getHierarchyLevel8Department()
	{
		return hierarchyLevel8Department;
	}

	/**
	 * @param hierarchyLevel8Department the hierarchyLevel8Department to set
	 */
	public void setHierarchyLevel8Department(String hierarchyLevel8Department)
	{
		this.hierarchyLevel8Department = hierarchyLevel8Department;
	}

	/**
	 * @return the hierarchyLevel8Email
	 */
	public String getHierarchyLevel8Email()
	{
		return hierarchyLevel8Email;
	}

	/**
	 * @param hierarchyLevel8Email the hierarchyLevel8Email to set
	 */
	public void setHierarchyLevel8Email(String hierarchyLevel8Email)
	{
		this.hierarchyLevel8Email = hierarchyLevel8Email;
	}

	/**
	 * @return the hierarchyLevel9Name
	 */
	public String getHierarchyLevel9Name()
	{
		return hierarchyLevel9Name;
	}

	/**
	 * @param hierarchyLevel9Name the hierarchyLevel9Name to set
	 */
	public void setHierarchyLevel9Name(String hierarchyLevel9Name)
	{
		this.hierarchyLevel9Name = hierarchyLevel9Name;
	}

	/**
	 * @return the hierarchyLevel9UserId
	 */
	public String getHierarchyLevel9UserId()
	{
		return hierarchyLevel9UserId;
	}

	/**
	 * @param hierarchyLevel9UserId the hierarchyLevel9UserId to set
	 */
	public void setHierarchyLevel9UserId(String hierarchyLevel9UserId)
	{
		this.hierarchyLevel9UserId = hierarchyLevel9UserId;
	}

	/**
	 * @return the hierarchyLevel9Phone
	 */
	public String getHierarchyLevel9Phone()
	{
		return hierarchyLevel9Phone;
	}

	/**
	 * @param hierarchyLevel9Phone the hierarchyLevel9Phone to set
	 */
	public void setHierarchyLevel9Phone(String hierarchyLevel9Phone)
	{
		this.hierarchyLevel9Phone = hierarchyLevel9Phone;
	}

	/**
	 * @return the hierarchyLevel9Department
	 */
	public String getHierarchyLevel9Department()
	{
		return hierarchyLevel9Department;
	}

	/**
	 * @param hierarchyLevel9Department the hierarchyLevel9Department to set
	 */
	public void setHierarchyLevel9Department(String hierarchyLevel9Department)
	{
		this.hierarchyLevel9Department = hierarchyLevel9Department;
	}

	/**
	 * @return the hierarchyLevel9Email
	 */
	public String getHierarchyLevel9Email()
	{
		return hierarchyLevel9Email;
	}

	/**
	 * @param hierarchyLevel9Email the hierarchyLevel9Email to set
	 */
	public void setHierarchyLevel9Email(String hierarchyLevel9Email)
	{
		this.hierarchyLevel9Email = hierarchyLevel9Email;
	}

	/**
	 * @return the hierarchyLevel10Name
	 */
	public String getHierarchyLevel10Name()
	{
		return hierarchyLevel10Name;
	}

	/**
	 * @param hierarchyLevel10Name the hierarchyLevel10Name to set
	 */
	public void setHierarchyLevel10Name(String hierarchyLevel10Name)
	{
		this.hierarchyLevel10Name = hierarchyLevel10Name;
	}

	/**
	 * @return the hierarchyLevel10UserId
	 */
	public String getHierarchyLevel10UserId()
	{
		return hierarchyLevel10UserId;
	}

	/**
	 * @param hierarchyLevel10UserId the hierarchyLevel10UserId to set
	 */
	public void setHierarchyLevel10UserId(String hierarchyLevel10UserId)
	{
		this.hierarchyLevel10UserId = hierarchyLevel10UserId;
	}

	/**
	 * @return the hierarchyLevel10Phone
	 */
	public String getHierarchyLevel10Phone()
	{
		return hierarchyLevel10Phone;
	}

	/**
	 * @param hierarchyLevel10Phone the hierarchyLevel10Phone to set
	 */
	public void setHierarchyLevel10Phone(String hierarchyLevel10Phone)
	{
		this.hierarchyLevel10Phone = hierarchyLevel10Phone;
	}

	/**
	 * @return the hierarchyLevel10Department
	 */
	public String getHierarchyLevel10Department()
	{
		return hierarchyLevel10Department;
	}

	/**
	 * @param hierarchyLevel10Department the hierarchyLevel10Department to set
	 */
	public void setHierarchyLevel10Department(String hierarchyLevel10Department)
	{
		this.hierarchyLevel10Department = hierarchyLevel10Department;
	}

	/**
	 * @return the hierarchyLevel10Email
	 */
	public String getHierarchyLevel10Email()
	{
		return hierarchyLevel10Email;
	}

	/**
	 * @param hierarchyLevel10Email the hierarchyLevel10Email to set
	 */
	public void setHierarchyLevel10Email(String hierarchyLevel10Email)
	{
		this.hierarchyLevel10Email = hierarchyLevel10Email;
	}

	/**
	 * @return the hierarchyLevel11Name
	 */
	public String getHierarchyLevel11Name()
	{
		return hierarchyLevel11Name;
	}

	/**
	 * @param hierarchyLevel11Name the hierarchyLevel11Name to set
	 */
	public void setHierarchyLevel11Name(String hierarchyLevel11Name)
	{
		this.hierarchyLevel11Name = hierarchyLevel11Name;
	}

	/**
	 * @return the hierarchyLevel11UserId
	 */
	public String getHierarchyLevel11UserId()
	{
		return hierarchyLevel11UserId;
	}

	/**
	 * @param hierarchyLevel11UserId the hierarchyLevel11UserId to set
	 */
	public void setHierarchyLevel11UserId(String hierarchyLevel11UserId)
	{
		this.hierarchyLevel11UserId = hierarchyLevel11UserId;
	}

	/**
	 * @return the hierarchyLevel11Phone
	 */
	public String getHierarchyLevel11Phone()
	{
		return hierarchyLevel11Phone;
	}

	/**
	 * @param hierarchyLevel11Phone the hierarchyLevel11Phone to set
	 */
	public void setHierarchyLevel11Phone(String hierarchyLevel11Phone)
	{
		this.hierarchyLevel11Phone = hierarchyLevel11Phone;
	}

	/**
	 * @return the hierarchyLevel11Department
	 */
	public String getHierarchyLevel11Department()
	{
		return hierarchyLevel11Department;
	}

	/**
	 * @param hierarchyLevel11Department the hierarchyLevel11Department to set
	 */
	public void setHierarchyLevel11Department(String hierarchyLevel11Department)
	{
		this.hierarchyLevel11Department = hierarchyLevel11Department;
	}

	/**
	 * @return the hierarchyLevel11Email
	 */
	public String getHierarchyLevel11Email()
	{
		return hierarchyLevel11Email;
	}

	/**
	 * @param hierarchyLevel11Email the hierarchyLevel11Email to set
	 */
	public void setHierarchyLevel11Email(String hierarchyLevel11Email)
	{
		this.hierarchyLevel11Email = hierarchyLevel11Email;
	}

	/**
	 * @return the hierarchyLevel12Name
	 */
	public String getHierarchyLevel12Name()
	{
		return hierarchyLevel12Name;
	}

	/**
	 * @param hierarchyLevel12Name the hierarchyLevel12Name to set
	 */
	public void setHierarchyLevel12Name(String hierarchyLevel12Name)
	{
		this.hierarchyLevel12Name = hierarchyLevel12Name;
	}

	/**
	 * @return the hierarchyLevel12UserId
	 */
	public String getHierarchyLevel12UserId()
	{
		return hierarchyLevel12UserId;
	}

	/**
	 * @param hierarchyLevel12UserId the hierarchyLevel12UserId to set
	 */
	public void setHierarchyLevel12UserId(String hierarchyLevel12UserId)
	{
		this.hierarchyLevel12UserId = hierarchyLevel12UserId;
	}

	/**
	 * @return the hierarchyLevel12Phone
	 */
	public String getHierarchyLevel12Phone()
	{
		return hierarchyLevel12Phone;
	}

	/**
	 * @param hierarchyLevel12Phone the hierarchyLevel12Phone to set
	 */
	public void setHierarchyLevel12Phone(String hierarchyLevel12Phone)
	{
		this.hierarchyLevel12Phone = hierarchyLevel12Phone;
	}

	/**
	 * @return the hierarchyLevel12Department
	 */
	public String getHierarchyLevel12Department()
	{
		return hierarchyLevel12Department;
	}

	/**
	 * @param hierarchyLevel12Department the hierarchyLevel12Department to set
	 */
	public void setHierarchyLevel12Department(String hierarchyLevel12Department)
	{
		this.hierarchyLevel12Department = hierarchyLevel12Department;
	}

	/**
	 * @return the hierarchyLevel12Email
	 */
	public String getHierarchyLevel12Email()
	{
		return hierarchyLevel12Email;
	}

	/**
	 * @param hierarchyLevel12Email the hierarchyLevel12Email to set
	 */
	public void setHierarchyLevel12Email(String hierarchyLevel12Email)
	{
		this.hierarchyLevel12Email = hierarchyLevel12Email;
	}

	/**
	 * @return the hierarchyLevel13Name
	 */
	public String getHierarchyLevel13Name()
	{
		return hierarchyLevel13Name;
	}

	/**
	 * @param hierarchyLevel13Name the hierarchyLevel13Name to set
	 */
	public void setHierarchyLevel13Name(String hierarchyLevel13Name)
	{
		this.hierarchyLevel13Name = hierarchyLevel13Name;
	}

	/**
	 * @return the hierarchyLevel13UserId
	 */
	public String getHierarchyLevel13UserId()
	{
		return hierarchyLevel13UserId;
	}

	/**
	 * @param hierarchyLevel13UserId the hierarchyLevel13UserId to set
	 */
	public void setHierarchyLevel13UserId(String hierarchyLevel13UserId)
	{
		this.hierarchyLevel13UserId = hierarchyLevel13UserId;
	}

	/**
	 * @return the hierarchyLevel13Phone
	 */
	public String getHierarchyLevel13Phone()
	{
		return hierarchyLevel13Phone;
	}

	/**
	 * @param hierarchyLevel13Phone the hierarchyLevel13Phone to set
	 */
	public void setHierarchyLevel13Phone(String hierarchyLevel13Phone)
	{
		this.hierarchyLevel13Phone = hierarchyLevel13Phone;
	}

	/**
	 * @return the hierarchyLevel13Department
	 */
	public String getHierarchyLevel13Department()
	{
		return hierarchyLevel13Department;
	}

	/**
	 * @param hierarchyLevel13Department the hierarchyLevel13Department to set
	 */
	public void setHierarchyLevel13Department(String hierarchyLevel13Department)
	{
		this.hierarchyLevel13Department = hierarchyLevel13Department;
	}

	/**
	 * @return the hierarchyLevel13Email
	 */
	public String getHierarchyLevel13Email()
	{
		return hierarchyLevel13Email;
	}

	/**
	 * @param hierarchyLevel13Email the hierarchyLevel13Email to set
	 */
	public void setHierarchyLevel13Email(String hierarchyLevel13Email)
	{
		this.hierarchyLevel13Email = hierarchyLevel13Email;
	}

	/**
	 * @return the hierarchyLevel14Name
	 */
	public String getHierarchyLevel14Name()
	{
		return hierarchyLevel14Name;
	}

	/**
	 * @param hierarchyLevel14Name the hierarchyLevel14Name to set
	 */
	public void setHierarchyLevel14Name(String hierarchyLevel14Name)
	{
		this.hierarchyLevel14Name = hierarchyLevel14Name;
	}

	/**
	 * @return the hierarchyLevel14UserId
	 */
	public String getHierarchyLevel14UserId()
	{
		return hierarchyLevel14UserId;
	}

	/**
	 * @param hierarchyLevel14UserId the hierarchyLevel14UserId to set
	 */
	public void setHierarchyLevel14UserId(String hierarchyLevel14UserId)
	{
		this.hierarchyLevel14UserId = hierarchyLevel14UserId;
	}

	/**
	 * @return the hierarchyLevel14Phone
	 */
	public String getHierarchyLevel14Phone()
	{
		return hierarchyLevel14Phone;
	}

	/**
	 * @param hierarchyLevel14Phone the hierarchyLevel14Phone to set
	 */
	public void setHierarchyLevel14Phone(String hierarchyLevel14Phone)
	{
		this.hierarchyLevel14Phone = hierarchyLevel14Phone;
	}

	/**
	 * @return the hierarchyLevel14Department
	 */
	public String getHierarchyLevel14Department()
	{
		return hierarchyLevel14Department;
	}

	/**
	 * @param hierarchyLevel14Department the hierarchyLevel14Department to set
	 */
	public void setHierarchyLevel14Department(String hierarchyLevel14Department)
	{
		this.hierarchyLevel14Department = hierarchyLevel14Department;
	}

	/**
	 * @return the hierarchyLevel14Email
	 */
	public String getHierarchyLevel14Email()
	{
		return hierarchyLevel14Email;
	}

	/**
	 * @param hierarchyLevel14Email the hierarchyLevel14Email to set
	 */
	public void setHierarchyLevel14Email(String hierarchyLevel14Email)
	{
		this.hierarchyLevel14Email = hierarchyLevel14Email;
	}

	/**
	 * @return the hierarchyLevel15Name
	 */
	public String getHierarchyLevel15Name()
	{
		return hierarchyLevel15Name;
	}

	/**
	 * @param hierarchyLevel15Name the hierarchyLevel15Name to set
	 */
	public void setHierarchyLevel15Name(String hierarchyLevel15Name)
	{
		this.hierarchyLevel15Name = hierarchyLevel15Name;
	}

	/**
	 * @return the hierarchyLevel15UserId
	 */
	public String getHierarchyLevel15UserId()
	{
		return hierarchyLevel15UserId;
	}

	/**
	 * @param hierarchyLevel15UserId the hierarchyLevel15UserId to set
	 */
	public void setHierarchyLevel15UserId(String hierarchyLevel15UserId)
	{
		this.hierarchyLevel15UserId = hierarchyLevel15UserId;
	}

	/**
	 * @return the hierarchyLevel15Phone
	 */
	public String getHierarchyLevel15Phone()
	{
		return hierarchyLevel15Phone;
	}

	/**
	 * @param hierarchyLevel15Phone the hierarchyLevel15Phone to set
	 */
	public void setHierarchyLevel15Phone(String hierarchyLevel15Phone)
	{
		this.hierarchyLevel15Phone = hierarchyLevel15Phone;
	}

	/**
	 * @return the hierarchyLevel15Department
	 */
	public String getHierarchyLevel15Department()
	{
		return hierarchyLevel15Department;
	}

	/**
	 * @param hierarchyLevel15Department the hierarchyLevel15Department to set
	 */
	public void setHierarchyLevel15Department(String hierarchyLevel15Department)
	{
		this.hierarchyLevel15Department = hierarchyLevel15Department;
	}

	/**
	 * @return the hierarchyLevel15Email
	 */
	public String getHierarchyLevel15Email()
	{
		return hierarchyLevel15Email;
	}

	/**
	 * @param hierarchyLevel15Email the hierarchyLevel15Email to set
	 */
	public void setHierarchyLevel15Email(String hierarchyLevel15Email)
	{
		this.hierarchyLevel15Email = hierarchyLevel15Email;
	}
	public String getEscalationCriteriaSetup() {
		return escalationCriteriaSetup;
	}

	public void setEscalationCriteriaSetup(String escalationCriteriaSetup) {
		this.escalationCriteriaSetup = escalationCriteriaSetup;
	}

	public String getConvCountThreshold() {
		return convCountThreshold;
	}

	public void setConvCountThreshold(String convCountThreshold) {
		this.convCountThreshold = convCountThreshold;
	}

	public String getResponseTimeThreshold() {
		return responseTimeThreshold;
	}

	public void setResponseTimeThreshold(String responseTimeThreshold) {
		this.responseTimeThreshold = responseTimeThreshold;
	}

	public String getPeerReviewResponseTimeThreshold() {
		return peerReviewResponseTimeThreshold;
	}

	public void setPeerReviewResponseTimeThreshold(String peerReviewResponseTimeThreshold) {
		this.peerReviewResponseTimeThreshold = peerReviewResponseTimeThreshold;
	}

	public String getWorkShiftTimeZone() {
		return workShiftTimeZone;
	}

	public void setWorkShiftTimeZone(String workShiftTimeZone) {
		this.workShiftTimeZone = workShiftTimeZone;
	}

	public String getShiftStartTime() {
		return shiftStartTime;
	}

	public void setShiftStartTime(String shiftStartTime) {
		this.shiftStartTime = shiftStartTime;
	}

	public String getShiftEndTime() {
		return shiftEndTime;
	}

	public void setShiftEndTime(String shiftEndTime) {
		this.shiftEndTime = shiftEndTime;
	}

	public String getNonWorkingDays() {
		return nonWorkingDays;
	}

	public void setNonWorkingDays(String nonWorkingDays) {
		this.nonWorkingDays = nonWorkingDays;
	}


	public Integer getRuleCount() {
		return ruleCount;
	}

	public void setRuleCount(Integer ruleCount) {
		this.ruleCount = ruleCount;
	}

	public Integer getNonInqRuleCnt() {
		return nonInqRuleCnt;
	}

	public void setNonInqRuleCnt(Integer nonInqRuleCnt) {
		this.nonInqRuleCnt = nonInqRuleCnt;
	}

	public Integer getReqRuleCnt() {
		return reqRuleCnt;
	}

	public void setReqRuleCnt(Integer reqRuleCnt) {
		this.reqRuleCnt = reqRuleCnt;
	}

	public Integer getUserRuleCnt() {
		return userRuleCnt;
	}

	public void setUserRuleCnt(Integer userRuleCnt) {
		this.userRuleCnt = userRuleCnt;
	}

	public Integer getTagRuleCnt() {
		return tagRuleCnt;
	}

	public void setTagRuleCnt(Integer tagRuleCnt) {
		this.tagRuleCnt = tagRuleCnt;
	}

	public Integer getProcessingRegionRuleCnt() {
		return processingRegionRuleCnt;
	}

	public void setProcessingRegionRuleCnt(Integer processingRegionRuleCnt) {
		this.processingRegionRuleCnt = processingRegionRuleCnt;
	}
	
	public Boolean getIncludeMyGroupInCC() {
		return includeMyGroupInCC;
	}

	public void setIncludeMyGroupInCC(Boolean includeMyGroupInCC) {
		this.includeMyGroupInCC = includeMyGroupInCC;
	}

	public Boolean getIsCustomizedAutoResponseEnabled() {
		return isCustomizedAutoResponseEnabled;
	}

	public void setIsCustomizedAutoResponseEnabled(Boolean isCustomizedAutoResponseEnabled) {
		this.isCustomizedAutoResponseEnabled = isCustomizedAutoResponseEnabled;
	}

	public Boolean getIsCustomizedAutoResponseEnabledForNewInquiry() {
		return isCustomizedAutoResponseEnabledForNewInquiry;
	}

	public void setIsCustomizedAutoResponseEnabledForNewInquiry(Boolean isCustomizedAutoResponseEnabledForNewInquiry) {
		this.isCustomizedAutoResponseEnabledForNewInquiry = isCustomizedAutoResponseEnabledForNewInquiry;
	}

	public Boolean getIsCustomizedAutoResponseEnabledForUserAssignment() {
		return isCustomizedAutoResponseEnabledForUserAssignment;
	}

	public void setIsCustomizedAutoResponseEnabledForUserAssignment(
			Boolean isCustomizedAutoResponseEnabledForUserAssignment) {
		this.isCustomizedAutoResponseEnabledForUserAssignment = isCustomizedAutoResponseEnabledForUserAssignment;
	}

	public GroupDetails(Long id, String name, String groupEmail, Boolean active, String crtDate, String modDate, String crtBy, String modBy, Boolean makerCheckerRqd, 
			Boolean predictiveRecipients, String organisation, String firstLevelHeirarchy, String secondLevelHeirarchy, String thirdLevelHeirarchy, String gfcid,
			Boolean attachmentBasedMakerChecker, Boolean isEmailSharingBlocked, String managerSoeid , Boolean autoReplyEnable, String isHolidayBasedAgeCalculation, String orgHierarchyLevel1, String orgHierarchyLevel2, String orgHierarchyLevel3, Boolean enableAutoAssignment,
			String escalationCriteriaSetup, String convCountThreshold, String responseTimeThreshold, String peerReviewResponseTimeThreshold, String workShiftTimeZone, String shiftStartTime, String shiftEndTime, String nonWorkingDays, Boolean enableInquirySubStatus,Boolean isGfidMandatory, Boolean isUINotificationPopupEnabled, Boolean isInquirySourceMandatory, Boolean isProcessingRegionMandatory,Boolean isRootCauseMandatory, Boolean isRootCauseMandatoryWOReply, Boolean isTagMandatory,
			String orgHierarchyLevel4,String orgHierarchyLevel5,String orgHierarchyLevel6,String orgHierarchyLevel7,String orgHierarchyLevel8,
			Boolean isCustomizedAutoResponseEnabled, Boolean isCustomizedAutoResponseEnabledForNewInquiry, Boolean isCustomizedAutoResponseEnabledForUserAssignment
			,Boolean includeMyGroupInCC)
	{
		super();
		this.id = id;
		this.name = name;
		this.groupEmail = groupEmail;
		this.active = active;
		this.crtDate = crtDate;
		this.modDate = modDate;
		this.crtBy = crtBy;
		this.modBy = modBy;
		this.makerCheckerRqd = makerCheckerRqd;
		this.autoReplyEnable = autoReplyEnable;
		this.predictiveRecipients = predictiveRecipients;
		this.organisation = organisation== null ? "" : organisation;
		this.firstLevelHeirarchy = firstLevelHeirarchy== null ? "" : firstLevelHeirarchy;
		this.secondLevelHeirarchy = secondLevelHeirarchy== null ? "" : secondLevelHeirarchy;
		this.thirdLevelHeirarchy = thirdLevelHeirarchy== null ? "" : thirdLevelHeirarchy;
		this.gfcid = gfcid== null ? "" : gfcid;
		this.attachmentBasedMakerChecker = attachmentBasedMakerChecker;
		this.isEmailSharingBlocked = isEmailSharingBlocked;
		this.managerSoeid = managerSoeid;
		this.isHolidayBasedAgeCalculation = isHolidayBasedAgeCalculation;
		this.orgHierarchyLevel1 = orgHierarchyLevel1;
		this.orgHierarchyLevel2 = orgHierarchyLevel2;
		this.orgHierarchyLevel3 = orgHierarchyLevel3;
		this.enableAutoAssignment = enableAutoAssignment;
		this.escalationCriteriaSetup = escalationCriteriaSetup;
		this.convCountThreshold = convCountThreshold;
		this.responseTimeThreshold = responseTimeThreshold;
		this.peerReviewResponseTimeThreshold = peerReviewResponseTimeThreshold;
		this.workShiftTimeZone = workShiftTimeZone;
		this.shiftStartTime = shiftStartTime;
		this.shiftEndTime = shiftEndTime;
		this.nonWorkingDays = nonWorkingDays;
		this.enableInquirySubStatus = enableInquirySubStatus;
		this.isGfidMandatory = isGfidMandatory;
		this.isUINotificationPopupEnabled = isUINotificationPopupEnabled;
		this.isInquirySourceMandatory = isInquirySourceMandatory;
		this.isProcessingRegionMandatory = isProcessingRegionMandatory;
		this.isRootCauseMandatory = isRootCauseMandatory;
		this.isRootCauseMandatoryWOReply = isRootCauseMandatoryWOReply;
		this.isTagMandatory = isTagMandatory;
		this.orgHierarchyLevel4 = orgHierarchyLevel4;
		this.orgHierarchyLevel5 = orgHierarchyLevel5;
		this.orgHierarchyLevel6 = orgHierarchyLevel6;
		this.orgHierarchyLevel7 = orgHierarchyLevel7;
		this.orgHierarchyLevel8 = orgHierarchyLevel8;
		this.isCustomizedAutoResponseEnabled = isCustomizedAutoResponseEnabled;
		this.isCustomizedAutoResponseEnabledForNewInquiry = isCustomizedAutoResponseEnabledForNewInquiry;
		this.isCustomizedAutoResponseEnabledForUserAssignment = isCustomizedAutoResponseEnabledForUserAssignment;
		this.includeMyGroupInCC = includeMyGroupInCC;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return  "\"" + id + pipeWithQuotes + name + pipeWithQuotes + groupEmail + pipeWithQuotes + active + "\"|" + crtDate + "|" + modDate + "|\"" + crtBy + pipeWithQuotes + modBy + pipeWithQuotes + makerCheckerRqd + pipeWithQuotes
                + predictiveRecipients + pipeWithQuotes + organisation + pipeWithQuotes + firstLevelHeirarchy + pipeWithQuotes + secondLevelHeirarchy + pipeWithQuotes + thirdLevelHeirarchy + pipeWithQuotes + gfcid
                + pipeWithQuotes + attachmentBasedMakerChecker + pipeWithQuotes + isEmailSharingBlocked + pipeWithQuotes + managerSoeid + pipeWithQuotes
                + hierarchyLevel1Name + pipeWithQuotes + hierarchyLevel1UserId + pipeWithQuotes + hierarchyLevel1Phone + pipeWithQuotes + hierarchyLevel1Department + pipeWithQuotes + hierarchyLevel1Email + pipeWithQuotes 
                + hierarchyLevel2Name + pipeWithQuotes + hierarchyLevel2UserId + pipeWithQuotes + hierarchyLevel2Phone + pipeWithQuotes + hierarchyLevel2Department + pipeWithQuotes + hierarchyLevel2Email + pipeWithQuotes   
                + hierarchyLevel3Name + pipeWithQuotes + hierarchyLevel3UserId + pipeWithQuotes + hierarchyLevel3Phone + pipeWithQuotes + hierarchyLevel3Department + pipeWithQuotes + hierarchyLevel3Email + pipeWithQuotes    
                + hierarchyLevel4Name + pipeWithQuotes + hierarchyLevel4UserId + pipeWithQuotes + hierarchyLevel4Phone + pipeWithQuotes + hierarchyLevel4Department + pipeWithQuotes + hierarchyLevel4Email + pipeWithQuotes 	
                + hierarchyLevel5Name + pipeWithQuotes + hierarchyLevel5UserId + pipeWithQuotes + hierarchyLevel5Phone + pipeWithQuotes + hierarchyLevel5Department + pipeWithQuotes + hierarchyLevel5Email + pipeWithQuotes 	 
                + hierarchyLevel6Name + pipeWithQuotes + hierarchyLevel6UserId + pipeWithQuotes + hierarchyLevel6Phone + pipeWithQuotes + hierarchyLevel6Department + pipeWithQuotes + hierarchyLevel6Email + pipeWithQuotes 	  
                + hierarchyLevel7Name + pipeWithQuotes + hierarchyLevel7UserId + pipeWithQuotes + hierarchyLevel7Phone + pipeWithQuotes + hierarchyLevel7Department + pipeWithQuotes + hierarchyLevel7Email + pipeWithQuotes 	   
				+ hierarchyLevel8Name + pipeWithQuotes + hierarchyLevel8UserId + pipeWithQuotes + hierarchyLevel8Phone + pipeWithQuotes + hierarchyLevel8Department + pipeWithQuotes + hierarchyLevel8Email + pipeWithQuotes 		
				+ hierarchyLevel9Name + pipeWithQuotes + hierarchyLevel9UserId + pipeWithQuotes + hierarchyLevel9Phone + pipeWithQuotes + hierarchyLevel9Department + pipeWithQuotes + hierarchyLevel9Email + pipeWithQuotes 		 
				+ hierarchyLevel10Name + pipeWithQuotes + hierarchyLevel10UserId + pipeWithQuotes + hierarchyLevel10Phone + pipeWithQuotes + hierarchyLevel10Department + pipeWithQuotes + hierarchyLevel10Email + pipeWithQuotes 		  
				+ hierarchyLevel11Name + pipeWithQuotes + hierarchyLevel11UserId + pipeWithQuotes + hierarchyLevel11Phone + pipeWithQuotes + hierarchyLevel11Department + pipeWithQuotes + hierarchyLevel11Email + pipeWithQuotes 		   
				+ hierarchyLevel12Name + pipeWithQuotes + hierarchyLevel12UserId + pipeWithQuotes + hierarchyLevel12Phone + pipeWithQuotes + hierarchyLevel12Department + pipeWithQuotes + hierarchyLevel12Email + pipeWithQuotes 		
				+ hierarchyLevel13Name + pipeWithQuotes + hierarchyLevel13UserId + pipeWithQuotes + hierarchyLevel13Phone + pipeWithQuotes + hierarchyLevel13Department + pipeWithQuotes + hierarchyLevel13Email + pipeWithQuotes 			 
				+ hierarchyLevel14Name + pipeWithQuotes + hierarchyLevel14UserId + pipeWithQuotes + hierarchyLevel14Phone + pipeWithQuotes + hierarchyLevel14Department + pipeWithQuotes + hierarchyLevel14Email + pipeWithQuotes 			 
				+ hierarchyLevel15Name + pipeWithQuotes + hierarchyLevel15UserId + pipeWithQuotes + hierarchyLevel15Phone + pipeWithQuotes + hierarchyLevel15Department + pipeWithQuotes + hierarchyLevel15Email + pipeWithQuotes + autoReplyEnable +pipeWithQuotes+ isHolidayBasedAgeCalculation+pipeWithQuotes+orgHierarchyLevel1+pipeWithQuotes+orgHierarchyLevel2+pipeWithQuotes+orgHierarchyLevel3+pipeWithQuotes+enableAutoAssignment 
				+ pipeWithQuotes +escalationCriteriaSetup + pipeWithQuotes + convCountThreshold + pipeWithQuotes + responseTimeThreshold + pipeWithQuotes + peerReviewResponseTimeThreshold + pipeWithQuotes + workShiftTimeZone + pipeWithQuotes + shiftStartTime + pipeWithQuotes + shiftEndTime + pipeWithQuotes + nonWorkingDays 
				+ pipeWithQuotes + ruleCount +pipeWithQuotes + nonInqRuleCnt+ pipeWithQuotes +reqRuleCnt+ pipeWithQuotes +userRuleCnt+ pipeWithQuotes +tagRuleCnt+ pipeWithQuotes +processingRegionRuleCnt 
				+ pipeWithQuotes + peopleHierarchyL5 + pipeWithQuotes + peopleHierarchyL6 + pipeWithQuotes + peopleHierarchyL7 + pipeWithQuotes + country + pipeWithQuotes + enableInquirySubStatus+ pipeWithQuotes + isGfidMandatory + isUINotificationPopupEnabled + pipeWithQuotes + isInquirySourceMandatory + pipeWithQuotes + isProcessingRegionMandatory+ pipeWithQuotes + isRootCauseMandatory + pipeWithQuotes + isRootCauseMandatoryWOReply + pipeWithQuotes + isTagMandatory+pipeWithQuotes+orgHierarchyLevel4+pipeWithQuotes+orgHierarchyLevel5+pipeWithQuotes+orgHierarchyLevel6+pipeWithQuotes+orgHierarchyLevel7+pipeWithQuotes+orgHierarchyLevel8 +pipeWithQuotes+ isCustomizedAutoResponseEnabled + pipeWithQuotes + isCustomizedAutoResponseEnabledForNewInquiry + pipeWithQuotes + isCustomizedAutoResponseEnabledForUserAssignment
				+ pipeWithQuotes + includeMyGroupInCC + "\"";
	}

	public Boolean getAutoReplyEnable()
	{
		return autoReplyEnable;
	}

	public void setAutoReplyEnable(Boolean autoReplyEnable)
	{
		this.autoReplyEnable = autoReplyEnable;
	}

	public String getIsHolidayBasedAgeCalculation() {
		return isHolidayBasedAgeCalculation;
	}

	public void setIsHolidayBasedAgeCalculation(String isHolidayBasedAgeCalculation) {
		this.isHolidayBasedAgeCalculation = isHolidayBasedAgeCalculation;
	}

	public String getOrgHierarchyLevel1() {
		return orgHierarchyLevel1;
	}

	public void setOrgHierarchyLevel1(String orgHierarchyLevel1) {
		this.orgHierarchyLevel1 = orgHierarchyLevel1;
	}

	public String getOrgHierarchyLevel2() {
		return orgHierarchyLevel2;
	}

	public void setOrgHierarchyLevel2(String orgHierarchyLevel2) {
		this.orgHierarchyLevel2 = orgHierarchyLevel2;
	}

	public String getOrgHierarchyLevel3() {
		return orgHierarchyLevel3;
	}

	public void setOrgHierarchyLevel3(String orgHierarchyLevel3) {
		this.orgHierarchyLevel3 = orgHierarchyLevel3;
	}

	public String getPeopleHierarchyL5() {
		return peopleHierarchyL5;
	}

	public void setPeopleHierarchyL5(String peopleHierarchyL5) {
		this.peopleHierarchyL5 = peopleHierarchyL5;
	}

	public String getPeopleHierarchyL6() {
		return peopleHierarchyL6;
	}

	public void setPeopleHierarchyL6(String peopleHierarchyL6) {
		this.peopleHierarchyL6 = peopleHierarchyL6;
	}

	public String getPeopleHierarchyL7() {
		return peopleHierarchyL7;
	}

	public void setPeopleHierarchyL7(String peopleHierarchyL7) {
		this.peopleHierarchyL7 = peopleHierarchyL7;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getOrgHierarchyLevel4() {
		return orgHierarchyLevel4;
	}

	public void setOrgHierarchyLevel4(String orgHierarchyLevel4) {
		this.orgHierarchyLevel4 = orgHierarchyLevel4;
	}

	public String getOrgHierarchyLevel5() {
		return orgHierarchyLevel5;
	}

	public void setOrgHierarchyLevel5(String orgHierarchyLevel5) {
		this.orgHierarchyLevel5 = orgHierarchyLevel5;
	}

	public String getOrgHierarchyLevel6() {
		return orgHierarchyLevel6;
	}

	public void setOrgHierarchyLevel6(String orgHierarchyLevel6) {
		this.orgHierarchyLevel6 = orgHierarchyLevel6;
	}

	public String getOrgHierarchyLevel7() {
		return orgHierarchyLevel7;
	}

	public void setOrgHierarchyLevel7(String orgHierarchyLevel7) {
		this.orgHierarchyLevel7 = orgHierarchyLevel7;
	}

	public String getOrgHierarchyLevel8() {
		return orgHierarchyLevel8;
	}

	public void setOrgHierarchyLevel8(String orgHierarchyLevel8) {
		this.orgHierarchyLevel8 = orgHierarchyLevel8;
	}

	

}
