/**
 * 
 */
package com.citi.icg.qma.common.server.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

//import javax.servlet.http.HttpServletRequest;
import jakarta.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.xmlbeans.impl.xb.xsdschema.impl.RestrictionDocumentImpl.RestrictionImpl;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.UserActivities;
import com.citi.icg.qma.common.server.dao.persistence.InquiryDAO;
import com.citi.icg.qma.common.server.dao.persistence.UserActivitiesDAO;


import com.citi.icg.qma.common.transferobject.ConversationTO;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

import org.slf4j.Logger;

/**
 * 
 *
 */
public class EndpointRequestUtil {
	private static final Logger subLogger = LoggerFactory.getLogger(EndpointRequestUtil.class);
	private static final InquiryDAO inquiryDao = new InquiryDAO();
	private static final UserActivitiesDAO user_Activities_Dao = new UserActivitiesDAO();
	public static final String RECIPIENT_TO = "to";
	public static final String RECIPIENT_CC = "cc";
	public static final String RECIPIENT_BCC = "bcc";
	private static final String VALUE = "value";
	private static final String TEXT = "text";
	private static final String ATTACHMENT = "attachment";
	private static final String EMAIL_CONTENT = "emailContents";
	private static final String INQUIRY_ACTION = "inquiryAction";
	private static final String CONVERSATION_ID = "conversationId";
	private static final String FROM = "from";
	private static final String SUBJECT = "subject";
	private static final String SUBJECT_PREFIX = "RE: ";
	private static String[] inquiryActionArray = {"Reply", "ReplyAll"};
	
	private EndpointRequestUtil(){}
	/**
	 * 
	 * @param requestJson
	 * @param soeId
	 * @param userActivity 
	 * @param servletRequest 
	 * @return
	 */
	public static Response saveInquiryWrapper(String requestJson, String soeId,String clientId, UserActivities userActivity) {
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(requestJson);
			if(StringUtils.isNotBlank(clientId)) {
				inputJsonObj.put("requesterId", clientId);
			}
			Inquiry dbInquiry;
			addGroupCodeInRequest(inputJsonObj);
			resolveFromGroupIfEmail(inputJsonObj);
			addEmptyAttachmentToJson(inputJsonObj);
			addEmptyEmailBodyToJson(inputJsonObj);
			Long inquiryId = GenericUtility.getIdFromRequest(inputJsonObj, AppserverConstants.INQUIRY_ID_KEY);
			InquiryDAO inquiryDAO = new InquiryDAO();
			dbInquiry = inquiryDAO.getInquiryById(inquiryId);
			List<Long> inquiryList = new ArrayList<>();
			if (inquiryId != null
					&& (("Resolved").contains(dbInquiry.getStatus()) || ("Resolve").contains(dbInquiry.getAction()))) {
				inquiryList.add(inquiryId);
				inquiryDAO.reOpenResolvedInquiry(requestJson, inquiryList, soeId, userActivity);
			}
			String inquiryAction = inputJsonObj.getString(INQUIRY_ACTION);
			String content = inputJsonObj.getString(EMAIL_CONTENT);
			BasicDBObject response = inquiryDao.saveInquiry(inputJsonObj, content, soeId, userActivity);
			response.put("action", inquiryAction);
			return DataConversionUtil.sendJsonResponseForString(response.toJson());
		} catch (Exception ex) {
			subLogger.error("Error while creating inquiry" + ex);
			return Response.status(400).entity(ex.getMessage()).build();
		}
	}

	/**
	 * This method resolves group name if group email id provided
	 * @param inputJsonObj
	 */
	private static void resolveFromGroupIfEmail(BasicDBObject inputJsonObj) {
		if (GenericUtility.isValidEmailAddress(inputJsonObj.getString(FROM))) {
			String groupEmail = inputJsonObj.getString(FROM);
			String[] emailSplit = groupEmail.split("@");
			String groupName = QMACacheFactory.getCache().getGroupEmailToCodeMap().get(emailSplit[0].toUpperCase());
			if (null != groupName) {
				inputJsonObj.put(FROM, groupName);
			}
		}
	}
	/**
	 * If email content variable is missing, add email empty body
	 * @param inputJsonObj
	 */
	private static void addEmptyEmailBodyToJson(BasicDBObject inputJsonObj) {
		boolean haveEmailContent = inputJsonObj.getString(EMAIL_CONTENT) == null;
		if(haveEmailContent)
		{
			String content = "";
			inputJsonObj.put(EMAIL_CONTENT, content);
		}
		
	}
	/**
	 * attach variable should be present and can be empty. Add empty attachment variable
	 * @param inputJsonObj
	 */
	private static void addEmptyAttachmentToJson(BasicDBObject inputJsonObj) {
		boolean haveAttachment = inputJsonObj.getString(ATTACHMENT) == null;
		if(haveAttachment)
		{
			BasicDBList basicBbList = new BasicDBList();
			inputJsonObj.put(ATTACHMENT, basicBbList);
		}
		
	}
	/**
	 * Group code Mandatory so add group code to request
	 * process each recipient to add group code into request
	 * @param inputJsonObj
	 */
	public static void addGroupCodeInRequest(BasicDBObject inputJsonObj) {
		String[] recipients = { RECIPIENT_TO, RECIPIENT_CC, RECIPIENT_BCC};
		for (String recipient : recipients) {
			BasicDBList basicBbList = new BasicDBList();
			if (inputJsonObj.getString(recipient) != null) {
				JSONArray jsArray = new JSONArray(inputJsonObj.getString(recipient));
				for (int i = 0; i < jsArray.length(); i++) {
					JSONObject jsonObj = jsArray.getJSONObject(i);
					BasicDBObject replcaeObj = addGroupCode(jsonObj);
					basicBbList.add(replcaeObj);
				}
				inputJsonObj.replace(recipient, basicBbList);
			}else{
				inputJsonObj.put(recipient, basicBbList);
			}
			
		}
	}

	/**
	 * get group code from cache getGroupCodeToIdMap
	 * @param jsonObj
	 */
	private static BasicDBObject addGroupCode(JSONObject jsonObj) {
		BasicDBObject replcaeObj = new BasicDBObject();
		if (null != jsonObj.getString(TEXT)) {
			Long groupCode = QMACacheFactory.getCache().getGroupCodeToIdMap().get(jsonObj.getString(TEXT).toUpperCase());
			if (groupCode != null) {
				replcaeObj.put(TEXT, jsonObj.getString(TEXT));
				replcaeObj.put(VALUE, String.valueOf(groupCode));
			} else if (GenericUtility.isValidEmailAddress(jsonObj.getString(TEXT))) {
				String email = jsonObj.getString(TEXT);
				String[] emailSplit = email.split("@");
				String groupName = QMACacheFactory.getCache().getGroupEmailToCodeMap().get(emailSplit[0].toUpperCase());
				if (null != groupName) {
					replcaeObj.put(TEXT, groupName);
					replcaeObj.put(VALUE, email);
				} else {
					replcaeObj.put(TEXT, email);
					replcaeObj.put(VALUE, email);
				}
				
			}
		}
		return replcaeObj;
	}

	/**
	 * This method get email contents for conversation id
	 * @param request
	 * @return
	 */
	public static String getEmailContents(String request) {
		try {
			String modifiedRequest;
			BasicDBObject requestObj = BasicDBObject.parse(request);
			Response validationResponse = EndpointRequestValidator.validateEmailBodyTarilReq(requestObj);
			if (validationResponse.getStatus() == 200) {
				String emailContents = requestObj.getString(EMAIL_CONTENT);
				Long convId;
				if (null != requestObj.get(CONVERSATION_ID)) {
					convId = GenericUtility.getIdFromRequest(requestObj, CONVERSATION_ID);
					ConversationTO conversationTO = inquiryDao.getInquiryConversationById(convId);
					if (null != conversationTO.getConversationList().get(0)) {
						StringBuilder builder = getModifiedContents(conversationTO, emailContents);
						requestObj.put(EMAIL_CONTENT, builder.toString());
						requestObj.put(SUBJECT, getSubject(requestObj));
						modifiedRequest = DataConversionUtil.convertJavaObjectToJson(requestObj);
						return modifiedRequest;
					}
				}
			}
			
		} catch (Exception e) {
			subLogger.error("Error in EndpointRequestUtil#getEmailContents",e);
		}
		return request;
	}

	/**
	 * This method prepend "RE: " in case of reply
	 * @param requestObj
	 * @return
	 */
	private static String getSubject(BasicDBObject requestObj) {
		if (null != requestObj.getString(SUBJECT)) {
			if (Arrays.asList(inquiryActionArray).contains(requestObj.getString(INQUIRY_ACTION)) && !requestObj.getString(SUBJECT).startsWith(SUBJECT_PREFIX)) {
				return SUBJECT_PREFIX + requestObj.getString(SUBJECT);
			} else {
				return requestObj.getString(SUBJECT);
			}
		}
		return "";
	}
	/**
	 * This method used to get modified email contents for trailing mails 
	 * @param conversationTO
	 * @param emailContents
	 * @return
	 */
	private static StringBuilder getModifiedContents(ConversationTO conversationTO, String emailContents) {
		Conversation conversation = conversationTO.getConversationList().get(0);
		String subject = conversation.getSubject();
		Date sentDate = conversation.getCrtDate();
		List<ConversationRecipient> recipients = conversationTO.getConversationList().get(0).getRecipients();
		StringBuilder builder = new StringBuilder();
		String from = "";
		String to = "";
		String cc = "";
		for (ConversationRecipient recipientsObj : recipients) {
			if (recipientsObj.getToFrom().equalsIgnoreCase(AppserverConstants.RECIPENT_FROM_KEY))
				from = "<strong>From: </strong>" + recipientsObj.getDisplayName() + "<br>";
			if (recipientsObj.getToFrom().equalsIgnoreCase(AppserverConstants.TO_CATEGARY))
				to = "<strong>To: </strong>" + recipientsObj.getDisplayName() + "<br>";
			if (recipientsObj.getToFrom().equalsIgnoreCase(AppserverConstants.CC_CATEGORY))
				cc = "<strong>Cc: </strong>" + recipientsObj.getDisplayName() + "<br>";
		}
		if(null != emailContents)
		{
			builder.append(emailContents);
		}
		builder.append("<br><br>");
		builder.append(from);
		builder.append("<strong>Sent: </strong>" + sentDate);
		builder.append("<br>");
		builder.append(to);
		builder.append(cc);
		builder.append("<strong> Subject: </strong>" + subject);
		builder.append("<br><br>");
		builder.append(GenericUtility.checkAndFetchConvContent(conversation));
		return builder;
	}
		
}
