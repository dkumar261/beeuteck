package com.citi.icg.qma.common.server.dao; 

import java.util.Date;

import dev.morphia.annotations.Entity;

@Entity(value = "JobStatus", noClassnameStored = true)
public class JobStatus extends BaseEntity
{
	
	private	String jobName;
	private Date jobStartTime;
	private Date jobEndTime;
	private String status;
	private long dataCount;
	private String exception;
	private long retryCount;
	

	public JobStatus()
	{
		super();
	}
	
	public JobStatus(String jobName, Date jobStartTime, Date jobEndTime, String status, long dataCount, String exception, long retryCount)
	{
		super();
		this.jobName = jobName;
		this.jobStartTime = jobStartTime;
		this.jobEndTime = jobEndTime;
		this.status = status;
		this.dataCount = dataCount;
		this.exception = exception;
		this.retryCount = retryCount;
	}
	
	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public Date getJobStartTime() {
		return jobStartTime;
	}

	public void setJobStartTime(Date jobStartTime) {
		this.jobStartTime = jobStartTime;
	}

	public Date getJobEndTime() {
		return jobEndTime;
	}

	public void setJobEndTime(Date jobEndTime) {
		this.jobEndTime = jobEndTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public long getDataCount() {
		return dataCount;
	}

	public void setDataCount(long dataCount) {
		this.dataCount = dataCount;
	}

	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}

	/**
	 * @return the retryCount
	 */
	public long getRetryCount() {
		return retryCount;
	}

	/**
	 * @param retryCount the retryCount to set
	 */
	public void setRetryCount(long retryCount) {
		this.retryCount = retryCount;
	}
	
}