package com.citi.icg.qma.common.core.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



/**
 * @DataTypeConverterUtil.java
 * 
 */
public final class DataTypeConverterUtil
{
	private static final Logger logger = LoggerFactory.getLogger(DataTypeConverterUtil.class);
	
	private static final String INCORRECT_VALUE = "Incorrect value ";
	private static final String SPECIFIED = " specified for ";
	private static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
	private static StringBuilder logBuffer = new StringBuilder();//Sonar Fix -- Replace the synchronized class "StringBuffer" by an unsynchronized one such as "StringBuilder"
	private DataTypeConverterUtil()
	{

	}

	public static BigDecimal getBigDecimalValue(Object obj)
	{
		if (obj instanceof String string)
		{
			return new BigDecimal(string);
		}
		else

		if (obj instanceof Integer integer)
		{
			return new BigDecimal(integer);
		}
		return null;
	}
	
	
	/**
	 * @param <T>
	 * @param dataType
	 * @param value
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T convertValueAsPerDataType(DataType dataType, String value)
	{
		if (dataType.equals(DataType.INTEGER))
		{
			return (T) Integer.valueOf(value);
		}
		if (dataType.equals(DataType.DATE))
		{
			String dateFormatter;
			if (value.contains("-"))
			{
				dateFormatter = "yyyy-mm-dd";
			}
			else
			{
				dateFormatter = "yyyymmdd";
			}
			SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormatter);
			try
			{
				return (T) dateFormat.parse(value);
			}
			catch (ParseException e)
			{
				logger.error(DataTypeConverterUtil.class+ "Error in converting Date " + e.getMessage(),e);
				return null;
			}
		}
		if (dataType.equals(DataType.FLOAT))
		{
			return (T) Float.valueOf(value);
		}
		if (dataType.equals(DataType.DOUBLE))
		{
			return (T) Double.valueOf(value);
		}
		return null;
	}
	
	public static BigDecimal toBigInteger(Object object, String fieldName)
	{
		try
		{
			return new BigDecimal((BigInteger) object);
		}
		catch (Exception e)
		{
			logBuffer.append(INCORRECT_VALUE + object.toString() + SPECIFIED + fieldName);
			logger.info(INCORRECT_VALUE + object.toString() + SPECIFIED + fieldName, e);
			return null;
		}
	}

	public static Date toDate(String inputDate, String fieldName)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
		Date date = null;
		try
		{
			date = dateFormat.parse(inputDate);

		}
		catch (ParseException e)
		{
			logBuffer.append(INCORRECT_VALUE + inputDate + SPECIFIED + fieldName);
			logger.info("{} {} {} {} ",INCORRECT_VALUE,inputDate,SPECIFIED ,fieldName);
			return null;
		}
		return date;
	}
	
	public static String dateToString(Date inputDate, String format)
	{
		String dateStr = null;
		try
		{
			if (inputDate != null)
			{
				SimpleDateFormat dateFormat = new SimpleDateFormat(format);
	
				dateStr = dateFormat.format(inputDate);
			}
		}
		catch (Exception e)
		{
			logger.info("Date is :" + inputDate + "Format is :" +  format, e);

		}

		return dateStr;
	}
	
	public static void printExceptionInConsole() {
		
		logger.info(logBuffer.toString());
	}
}
