/**
 * 
 */
package com.citi.icg.qma.common.server.dao.persistence;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

//import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.UserActivities;
import com.citi.icg.qma.common.server.dao.UserNotifications;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.common.transferobject.UserNotificationsTO;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;

import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

/**
 * 
 *
 */
public class UserNotificationDAO extends MongoMorphiaDAO{

	protected Logger subLogger = LoggerFactory.getLogger(UserNotificationDAO.class);
	private DB database = MongoDB.instance().getDB();
	private static UserNotificationDAO instance = null;
	private static final String MESSAGE = "message";
	private static final String STATUS = "status";
	private static final String INQUIRYID = "inquiryId";
	private static final String USERS = "users";
	private static final String USERID = "userId";
	private static final String ID_KEY = "_id";
	private static final String READ_FLAG = "isRead";
	private static final InquiryDAO inquiryDao = new InquiryDAO();
	private static final String USER_NOTIFICATON_ERROR_MSG = "Exception while updating user notification";
	private static final UserActivitiesDAO user_Activities_Dao = new UserActivitiesDAO();
	private static final String NOTIFY_KEY = "notify";
	private static final String REASON_KEY = "reason";
	
	public static synchronized UserNotificationDAO getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		if (instance == null) {
			instance = new UserNotificationDAO();
		}
		return instance;
	}

	/**
	 * @param request
	 * @param soeId
	 * @param servletRequest 
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBObject notifyUserInquiry(String request, String soeId, String description) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			if (null != inputJsonObj && null != inputJsonObj.get(INQUIRYID) && null != inputJsonObj.get(USERS)) {
				List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRYID);
				List<String> userIdList = GenericUtility.getCaseInsensitiveSortedList((List<String>)inputJsonObj.get(USERS));
				subLogger.info("Notify inquiry:"+inquiryIds.toString()+" to userIds:"+userIdList.toString());
				DBObject findQueryObj = new BasicDBObject("_id", new BasicDBObject("$in", inquiryIds));
				DBObject inquiryUpdateDBObj = new BasicDBObject();
				inquiryUpdateDBObj.put("$addToSet", new BasicDBObject(NOTIFY_KEY, new BasicDBObject("$each",userIdList)));
				DBCollection inquiryCollection = database.getCollection("Inquiry");
				inquiryCollection.updateMulti(findQueryObj, inquiryUpdateDBObj);
				saveUserActivities(soeId, NOTIFY_KEY, inputJsonObj, description);
				response.put(STATUS, true);
				response.put(MESSAGE, "notifyUserInquiry saved successfully");
			}
			
		} catch (Exception e) {
			response.put(STATUS, false);
			response.put(MESSAGE, "notifyUserInquiry save failed");
			throw new CommunicatorException("Exception while notifyUserInquiry in UserNotificationDAO.notifyUserInquiry : " + e);
		}
		return response;
	}

	/**
	 * Save user activities
	 * @param soeId
	 * @param action
	 * @param inputJsonObj
	 * @param servletRequest 
	 */
	private void saveUserActivities(String soeId, String action, BasicDBObject inputJsonObj, String description) {
		try {
			String reason= inputJsonObj.getString(REASON_KEY);
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRYID);
			List<String> userIdList = GenericUtility.getCaseInsensitiveSortedList((List<String>)inputJsonObj.get(USERS));
			description = "Notified "+userIdList.toString()+" about inquiry ids:"+inquiryIds.toString()+", Reason:"+reason;
		} catch (Exception e) {
			subLogger.error("Error while save user activities",e);
		}
		
	}

	/**
	 * This method is used to get all non-read notification for user
	 * @param soeId
	 * @return
	 * @throws CommunicatorException 
	 */
	public UserNotificationsTO getAllUserNotifications(String soeId) throws CommunicatorException {
		UserNotificationsTO newUserNotificationsTO;
		try {
			Query<UserNotifications> query = mongoDatastore.createQuery(UserNotifications.class).filter(USERID, soeId).filter(READ_FLAG, false);
			List<UserNotifications> usernotificationList = query.find().toList();
			newUserNotificationsTO = new UserNotificationsTO();
			newUserNotificationsTO.setUserNotificationsList(usernotificationList);
		} catch (Exception e) {
			subLogger.error("Exception while getAllUserNotifications in UserNotificationDAO.getAllUserNotifications : " + e);
			throw new CommunicatorException("Exception while getAllUserNotifications in UserNotificationDAO.getAllUserNotifications : " + e);
		}
        return newUserNotificationsTO;
	}

	/**
	 * This method is used to mark notification marked as read. 
	 * @param request
	 * @param soeId
	 * @param servletRequest 
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBObject updateUserNotification(String request, String soeId) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			if (null != inputJsonObj && null != inputJsonObj.get(ID_KEY) && null != inputJsonObj.get(USERID)) {
				Integer notificationId = (Integer) inputJsonObj.get(ID_KEY);
				subLogger.info("Update UserNotification:"+notificationId);
				Query<UserNotifications> query = mongoDatastore.createQuery(UserNotifications.class).filter(ID_KEY, notificationId);
				UpdateOperations<UserNotifications> userOps = mongoDatastore.createUpdateOperations(UserNotifications.class);
				userOps.set(READ_FLAG, true);
				userOps.set(USERID, soeId);
				mongoDatastore.update(query, userOps);
				response.put(STATUS, true);
				response.put(MESSAGE, "UserNotification updated successfully");
			}
			
		} catch (Exception e) {
			response.put(STATUS, false);
			response.put(MESSAGE, "UserNotification update failed");
			throw new CommunicatorException("Exception while updateUserNotification in UserNotificationDAO.updateUserNotification : " + e);
		}
		return response;
	}
	/**
	 * This method is used to save user notifications. 
	 * @param request
	 * @param soeId
	 * @param userNotificationType 
	 * @param servletRequest 
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBObject addUserNotification(Long inquiryId, String action, String soeId, String userNotificationType, UserActivities userActivity) {
		BasicDBObject response = new BasicDBObject();
		try {
			UserNotifications userNotification = new UserNotifications();
			userNotification.setInquiryId(inquiryId);
			userNotification.setRead(false);
			userNotification.setUserId(soeId);
			userNotification.setAction(action);
			userNotification.setType(userNotificationType);
			Long id = persist(userNotification);
			response.put("ID", id);
			String description = "Add user notification for user "+soeId+" for inquiry Id:"+inquiryId+" , action:"+action+" and notification type:"+userNotificationType;
			userActivity.setDescription(description);
			user_Activities_Dao.saveUserActivities(soeId, userActivity, System.currentTimeMillis() - userActivity.getResponseTimeInMills());
		} catch (Exception e) {
			response.put(STATUS, false);
			response.put(MESSAGE, "UserNotification save failed"+e);
			subLogger.error("Error while saving UserNotification:",e);
		}
		return response;
	}

	/**
	 *  This method is used to update user notification for inquiry.
	 * @param inquiry
	 * @param action
	 * @param servletRequest 
	 * @param servletRequest 
	 */
	public void updateUserNotification(Inquiry inquiry, String action, String soeId, String userNotificationType,UserActivities userActivity) {
		try {
			if (null != inquiry.getNotify() && inquiry.getNotify().size() > 0) {
				for (String notifyUser : inquiry.getNotify()) {
					subLogger.debug("Updating user notification. for inquiry :"+inquiry.getId()+" SoeId:"+soeId);
					addUserNotification(inquiry.getId(), action, notifyUser, userNotificationType, userActivity);
				}
			}
			addNotiFicationsForUserPreferences(inquiry, action, soeId, userNotificationType, userActivity);
		} catch (Exception e) {
			subLogger.error(USER_NOTIFICATON_ERROR_MSG + e);
		}
	}

	/**
	 * @param inquiry
	 * @param action
	 * @param soeId
	 * @param userNotificationType
	 * @param servletRequest 
	 */
	private void addNotiFicationsForUserPreferences(Inquiry inquiry, String action, String soeId,
			String userNotificationType, UserActivities userActivity) {
		try {
			Query<User> query = mongoDatastore.createQuery(User.class).filter(ID_KEY, soeId);
			subLogger.info("fetching data for query : " + query);
			List<User> user = query.asList();
			if (!user.isEmpty() && user.get(0) != null && user.get(0).getNotificationSettings() != null) {
				Map<String, Boolean> userNotifications = user.get(0).getNotificationSettings();
				for (Entry<String, Boolean> entry : userNotifications.entrySet()) {
					compareEntryForUserPreferences(inquiry, action, soeId, userNotificationType, entry, userActivity);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception while addNotiFicationsForUserPreferences", e);
		}
	}

	/**
	 * @param inquiry
	 * @param action
	 * @param soeId
	 * @param userNotificationType
	 * @param entry
	 * @param servletRequest 
	 */
	private void compareEntryForUserPreferences(Inquiry inquiry, String action, String soeId,
			String userNotificationType, Entry<String, Boolean> entry, UserActivities userActivity) {
		if (entry.getValue() && action.equalsIgnoreCase(entry.getKey())) {
			addUserNotification(inquiry.getId(), action, soeId, userNotificationType, userActivity);
		}
	}

	/**
	 *  This method is used to update user notification for given inquiry by id.
	 * @param inquiryId
	 * @param action
	 * @param soeId
	 * @param userNotificationType 
	 */
	public void updateUserNotification(Long inquiryId, String action, String soeId, String userNotificationType, UserActivities userActivity) {
		try {
			if (null != inquiryId && null != action) {
				Inquiry inquiry = inquiryDao.getInquiryById(inquiryId);
				updateUserNotification(inquiry, action, soeId, userNotificationType,userActivity);
			}
		} catch (Exception e) {
			subLogger.error(USER_NOTIFICATON_ERROR_MSG + e);
		}
	}

	/**
	 * This method is used to update user notification for multiple inquiries.
	 * @param inquiryIds
	 * @param action
	 * @param soeId
	 * @param userNotificationType 
	 */
	public void updateUserNotification(List<Long> inquiryIds, String action, String soeId, String userNotificationType, UserActivities userActivity) {
		try {
			for (Long inquiryId : inquiryIds) {
				if (null != inquiryId && null != action) {
					Inquiry inquiry = inquiryDao.getInquiryById(inquiryId);
					updateUserNotification(inquiry, action, soeId, userNotificationType, userActivity);
				}
			}
		} catch (Exception e) {
			subLogger.error(USER_NOTIFICATON_ERROR_MSG + e);
		}
	}
}
