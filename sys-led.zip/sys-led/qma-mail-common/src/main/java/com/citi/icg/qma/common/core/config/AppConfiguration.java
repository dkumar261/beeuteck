package com.citi.icg.qma.common.core.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;


/**
 * This class represents configuration for ICG Toolkit.
 */
public class AppConfiguration extends Configuration
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String ENC_KEY_FILE = "enc-key-file";
	private static final String FILE_UPLOAD_SAVE_LOCATION = "fileUploadSaveLocation";
	private static final String LOOKUP_DATA_LOADER = "lookupDataLoader";

	// --- Static Variables ---

	/** Singleton instance of this class. */
	private static AppConfiguration singleton = null;

	/** Period. */
	private static final String PERIOD = ".";

	/** application. */
	private static final String APPLICATION = "application";

	/** application. */
	private static final String APPLICATION_NAME = "name";
	private static final String APPLICATION_CONFIG_DIR = "applicationConfigDir";

	/** Configuration name. */
	private static final String CONFIGURATION_NAME = "icg-toolkit";

	/** Email server. */
	public static final String EMAIL_SERVER = "email.server";

	/** Support email id. */
	public static final String EMAIL_SUPPORT = "email.support";
	public static final String EMAIL_SUPPORT_DISABLED = "email.supportDisabled";

	/** Default XML encoding. */
	public static final String XML_DEEFAULT_ENCODING = "xml.default-encoding";

	/** Root directory of XSL files. */
	public static final String XSL_ROOT_DIRECTORY = "xsl.root-directory";

	/** XSL file for invalid input errors. */
	public static final String XSL_INVALID_INPUT_ERROR_FILE = "xsl.error.invalid-input";
	
	/** The security algorithm used for encryption/decryption */
	private static final String ENCRYPTION_ALGORITHM = "encryption-algorithm";
	
	private static Logger LOGGER = LoggerFactory.getLogger(AppConfiguration.class);

	// --- Static Methods ---

	/**
	 * Retrieves an instance of this configuration.
	 * 
	 * @exception IcgException
	 *                if an error occurs.
	 * @return an instance of IcgToolkitConfiguration.
	 */
	public static AppConfiguration getInstance() 
	{
		synchronized (AppConfiguration.class)
		{
			if (singleton == null)
			{
				AppConfiguration configuration = null;
				try
				{
					configuration = ConfigUtil.getInstance(AppConfiguration.class);
				}
				catch (CommunicatorException e)
				{
					LOGGER.error("Error in AppConfiguration getInstance() ", e);
				}
				singleton = configuration;
			}
		}

		return singleton;
	}

	// --- Instance Methods ---

	/**
	 * Retrieves the name of the configuration file.
	 * 
	 * @return the configuration name.
	 */
	@Override
	public String getConfigurationName()
	{
		return CONFIGURATION_NAME;
	}

	/**
	 * Retrieves the list of configuration entries that must exist and have a
	 * value.
	 * 
	 * @return the super users.
	 */
	@Override
	public String[] getRequiredEntries()
	{
		return new String[] {};
	}

	/**
	 * Retrieves the email server.
	 * 
	 * @return the email server.
	 */
	public String getEmailServer()
	{
		return getString(APPLICATION + PERIOD + CONFIGURATION_NAME + PERIOD + EMAIL_SERVER);
	}

	/**
	 * Retrieves the support email id.
	 * 
	 * @return the support email id.
	 */
	public String getSupportEmail()
	{
		return getString(APPLICATION + PERIOD + CONFIGURATION_NAME + PERIOD + EMAIL_SUPPORT);
	}

	/**
	 * Retrieves the support email id.
	 * 
	 * @return the support email id.
	 */
	public boolean getSupportEmailDisabled()
	{
		String flag = getString(APPLICATION + PERIOD + CONFIGURATION_NAME + PERIOD + EMAIL_SUPPORT_DISABLED);
		return flag != null && Boolean.parseBoolean(flag.trim());
	}

	/**
	 * Retrieves the encryption key file name.
	 * 
	 * @return the encryption key file name.
	 */
	public String getEnctyptionKeyFileName()
	{
		return getString(APPLICATION + PERIOD + CONFIGURATION_NAME + PERIOD + ENC_KEY_FILE);
	}

	/**
	 * Retrieves the Fileupload Save location as generic upload save function.
	 * 
	 * @return the encryption key file name.
	 */
	public String getFileUploadSaveLocation()
	{
		return getString(APPLICATION + PERIOD + CONFIGURATION_NAME + PERIOD + FILE_UPLOAD_SAVE_LOCATION);
	}

	/**
	 * Retrieves the default encoding for XML output.
	 * 
	 * @return the default encoding for XML output.
	 */
	public String getXmlDefaultEncoding()
	{
		return getString(XML_DEEFAULT_ENCODING);
	}

	/**
	 * Retrieves the root directory for XSL files.
	 * 
	 * @return the root directory for XSL files.
	 */
	public String getXslRootDirectory()
	{
		return getString(XSL_ROOT_DIRECTORY);
	}

	/**
	 * Retrieves the full path for the XSL file specified.
	 * 
	 * @param filename
	 *            full path of the XSL file
	 * @return the full path for the XSL file specified..
	 */
	public String toFullXslFilename(String filename)
	{
		return prependRootPath(getXslRootDirectory(), filename);
	}

	/**
	 * Retrieves the application name.
	 * 
	 * @return the application name.
	 */
	public String getApplicationName()
	{
		return getString(APPLICATION + PERIOD + APPLICATION_NAME);
	}

	public static String getApplicationConfigDir()
	{
		if (singleton == null)
		{
			return null;
		}
		return singleton.getString(APPLICATION + PERIOD + APPLICATION_CONFIG_DIR);
	}

	/**
	 * Retrieves the LookupData Loader class name.
	 * 
	 * @return the lookupDataLoader class name.
	 */
	public String getLookupDataLoader()
	{
		return getString(APPLICATION + PERIOD + CONFIGURATION_NAME + PERIOD + LOOKUP_DATA_LOADER);
	}
	
	/**
	 * Retrieves the algorithm used for encryption/decryption.
	 * 
	 * @return the encryption algorithm
	 */
	public String getEncryptionAlgorithm()
	{
		return getString(APPLICATION + PERIOD + CONFIGURATION_NAME + PERIOD + ENCRYPTION_ALGORITHM);
	}
}
