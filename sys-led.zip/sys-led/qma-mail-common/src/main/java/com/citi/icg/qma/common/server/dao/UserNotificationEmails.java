package com.citi.icg.qma.common.server.dao;

import java.util.List;

import dev.morphia.annotations.CappedAt;
import dev.morphia.annotations.Entity;

@Entity(value = "UserNotificationEmails", noClassnameStored = true, cap = @CappedAt(count = 50000, value = 2000000000))
public class UserNotificationEmails extends BaseEntity
{
	private Long inquiryId;
	private Long conversationId;
	private String processed; //[C153176-1292] - user notifications
	private String notificationSubject;
	private String notificationRecipient;
	private String notificationFrom;
	private String references;
	private String direction;
	private String messageId;
	private String notificationType;
	private String feedbackContent;
	private List<Attachment> attachments; 
	
	
	public UserNotificationEmails()
	{
		super();
	}
	/**
	 * @return the processed
	 */
	public String getProcessed()
	{
		return processed;
	}
	/**
	 * @param processed the processed to set
	 */
	public void setProcessed(String processed)
	{
		this.processed = processed;
	}
	/**
	 * @return the notificationSubject
	 */
	public String getNotificationSubject()
	{
		return notificationSubject;
	}
	/**
	 * @param notificationSubject the notificationSubject to set
	 */
	public void setNotificationSubject(String notificationSubject)
	{
		this.notificationSubject = notificationSubject;
	}
	
	/**
	 * @return the notificationRecipient
	 */
	public String getNotificationRecipient()
	{
		return notificationRecipient;
	}
	/**
	 * @param notificationRecipient the notificationRecipient to set
	 */
	public void setNotificationRecipient(String notificationRecipient)
	{
		this.notificationRecipient = notificationRecipient;
	}
	/**
	 * @return the notificationFrom
	 */
	public String getNotificationFrom()
	{
		return notificationFrom;
	}
	/**
	 * @param notificationFrom the notificationFrom to set
	 */
	public void setNotificationFrom(String notificationFrom)
	{
		this.notificationFrom = notificationFrom;
	}
	/**
	 * @return the inquiryId
	 */
	public Long getInquiryId()
	{
		return inquiryId;
	}
	/**
	 * @param inquiryId the inquiryId to set
	 */
	public void setInquiryId(Long inquiryId)
	{
		this.inquiryId = inquiryId;
	}
	/**
	 * @return the conversationId
	 */
	public Long getConversationId()
	{
		return conversationId;
	}
	/**
	 * @param conversationId the conversationId to set
	 */
	public void setConversationId(Long conversationId)
	{
		this.conversationId = conversationId;
	}
	/**
	 * @return the references
	 */
	public String getReferences()
	{
		return references;
	}
	/**
	 * @param references the references to set
	 */
	public void setReferences(String references)
	{
		this.references = references;
	}
	/**
	 * @return the direction
	 */
	public String getDirection()
	{
		return direction;
	}
	/**
	 * @param direction the direction to set
	 */
	public void setDirection(String direction)
	{
		this.direction = direction;
	}
	/**
	 * @return the messageId
	 */
	public String getMessageId()
	{
		return messageId;
	}
	/**
	 * @param messageId the messageId to set
	 */
	public void setMessageId(String messageId)
	{
		this.messageId = messageId;
	}
	
	/**
	 * @return the notificationType
	 */
	public String getNotificationType()
	{
		return notificationType;
	}
	/**
	 * @param notificationType the notificationType to set
	 */
	public void setNotificationType(String notificationType)
	{
		this.notificationType = notificationType;
	}
	/**
	 * @return the feedbackContent
	 */
	public String getFeedbackContent()
	{
		return feedbackContent;
	}
	/**
	 * @param feedbackContent the feedbackContent to set
	 */
	public void setFeedbackContent(String feedbackContent)
	{
		this.feedbackContent = feedbackContent;
	}
	/**
	 * @return the attachments
	 */
	public List<Attachment> getAttachments()
	{
		return attachments;
	}
	/**
	 * @param attachments the attachments to set
	 */
	public void setAttachments(List<Attachment> attachments)
	{
		this.attachments = attachments;
	}
	
}
