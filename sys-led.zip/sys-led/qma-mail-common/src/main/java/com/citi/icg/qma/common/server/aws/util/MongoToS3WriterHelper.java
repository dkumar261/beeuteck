package com.citi.icg.qma.common.server.aws.util;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.s3.AmazonS3;
import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.persistence.AttachmentDAO;
import com.citi.icg.qma.common.server.dao.persistence.MongoDB;
import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.ReadPreference;

import dev.morphia.Datastore;

public class MongoToS3WriterHelper implements Runnable
{

	private List<Long> inqIdsChunkList;
	private static Logger logger = LoggerFactory.getLogger(MongoToS3WriterHelper.class);
	private static final DB database = MongoDB.instance().getDB();
	private static final Datastore mongoDatastore = MongoDB.instance().getDataStore();
	//private static AtomicInteger totalDocumentCount = new AtomicInteger();

	public MongoToS3WriterHelper(List<Long> inqIdsChunkList) throws IOException
	{
		this.inqIdsChunkList = inqIdsChunkList;
	}

	@Override
	public void run()
	{
		try
		{

			fetchConversationforInquiryIds(inqIdsChunkList);
			//logger.info("******************  TOTAL DOCUMENTS :" + totalDocumentCount);

		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
		}

	}

	/**
	 * @param convbw2
	 * @param convbw2
	 * @param <T>
	 * @param inquiryIdsOf100
	 * @throws IOException
	 */
	private void fetchConversationforInquiryIds(List<Long> inqIdsChunkList)
	{

		AWSUtility awsUtility = new AWSUtility();
		AmazonS3 amazonS3 = awsUtility.getConnection();
		AttachmentDAO attachDao = new AttachmentDAO();
		Set<Long> convIdswithAttachments = new HashSet<Long>();
		
		// logger.info(" STARTED Thread Id : " + Thread.currentThread().getId());
		String projectionQuery = "{ _id : 1, inquiryId :1, attachments : 1}";
		BasicDBObject inquirIdMatchConvQuery = new BasicDBObject("inquiryId", new BasicDBObject("$in", inqIdsChunkList)).append("attachments", new BasicDBObject("$exists", true)).append("isS3Migrated",
				new BasicDBObject("$ne", "Y"));
		DBObject projection = BasicDBObject.parse(projectionQuery);
		DBCursor converCursor = database.getCollection("Conversation").find(inquirIdMatchConvQuery, projection).setReadPreference(ReadPreference.secondary());

		logger.info("inquirIdMatchConvQry:" + inquirIdMatchConvQuery);
		
		Long successfulMigration  = 0L;
		Long failureMigration  = 0L;
		

		while (converCursor.hasNext())
		{

			DBObject convObject = converCursor.next();

			if (convObject != null)
			{
				Long inquiryId = (Long) convObject.get("inquiryId");
				Long conversationId = (Long) convObject.get("_id");

				List<BasicDBObject> attachments = (List<BasicDBObject>) convObject.get("attachments");

				if (null != attachments && !attachments.isEmpty())
				{
					 logger.info("processing inquiry Id : " + inquiryId + ", conversation Id :" + conversationId);

					for (int i = 0; i < attachments.size(); i++)
					{
						try
						{
							// SUNIL : keep continue this process even if issue happens.
							BasicDBObject attachment = attachments.get(i);

							String mongoIdTemp = attachment.getString("mongoId");
							String docId = attachment.getString("id");// Now only thsi exists for documents, mongoId is only for old documents, so
							// mongoId is for old documents during documentum to mongo migration. Later mongoId does not exists only id is there and that is right id in Attachment.java class
							if (mongoIdTemp != null)
							{
								logger.info("mongoId is available, size is: " + mongoIdTemp.length());

								if (mongoIdTemp.length() == 24)
								{
									logger.info("mongoId is 24 character");

									docId = mongoIdTemp;
								}
							}

							// String name = attachment.getString("name");

							// uploadToS3(fileId, fileName);
							// TODO: ADD ENTRY IN MongoToS3MigratedDocumentDetails
							Map<String, Object> downloadedFileMap = attachDao.getFile(docId);
							File file = (File) downloadedFileMap.get("fileObject");
							Date uploadOn = (Date) downloadedFileMap.get("uploadOn");
							Long size = (Long) downloadedFileMap.get("size");
							String md5 = (String) downloadedFileMap.get("md5");
							String type = (String) downloadedFileMap.get("type");
							String fileName = (String) downloadedFileMap.get("name");

							
							

							//write to S3 storgae
							boolean writeS3Flag = awsUtility.writeObject_donotuse(amazonS3, docId, file);
							logger.info("Copied in S3 sotrage succesfully " + docId + "  name is:" + fileName );

							// deletefromMongoDb();
							file.delete();// delete file always
							if (writeS3Flag)
							{
								mongoDatastore.save(new S3MigratedDocs(inquiryId, conversationId, fileName, docId, uploadOn, md5, type, size)); //contained all migrated data
								logger.info("Entry saved to S3MigratedDocs, docId is: " + docId + "  name is:" + fileName );
								convIdswithAttachments.add(conversationId);
								attachDao.deleteFile(docId);
								
								logger.info("deleted file in mongdb and locally" + docId + "  name is:" + fileName );
								successfulMigration++;
							}
							
							//TODO:// update conversation ismigrated = Y  

							//totalDocumentCount.getAndIncrement();
						}
						catch (Exception e)
						{
							failureMigration ++;
							logger.error("Issue in data migration", e);
						}
					}
				}
			}
		}
		
		logger.info("successfulMigration docs: " + successfulMigration + "  , failureMigration Docs:" + failureMigration);

		updateConversation(convIdswithAttachments);
		
	    logger.info("Conversations updated finsihed and their id's are: " + convIdswithAttachments.size());

	}
	
	/**
	 *  update conversation with isS3Migrated = Y
	 */
	public void updateConversation(Set<Long> convIdswithAttachments) {		
		
		if(!convIdswithAttachments.isEmpty())
		{
			DBCollection convCollection = mongoDatastore.getCollection(Conversation.class);
			BulkWriteOperation bulkInquiryEscalationUpdOp = convCollection.initializeOrderedBulkOperation();	
			DBObject findConvIdQuery = new BasicDBObject("_id",new BasicDBObject("$in",convIdswithAttachments));
		
			logger.info("Updating S3 migration related Conversations: " + findConvIdQuery);
			
			DBObject updateS3Flag = new BasicDBObject();
			updateS3Flag.put("$set", new BasicDBObject("isS3Migrated","Y"));
			
			bulkInquiryEscalationUpdOp.find(findConvIdQuery).update(updateS3Flag);		
			bulkInquiryEscalationUpdOp.execute();	

		}
		
	}
	

}
