package com.citi.icg.qma.common.server.dao.persistence.oasys.payments;

import java.util.Date;
import java.util.List;

import com.citi.icg.qma.common.server.dao.BaseEntity;

import dev.morphia.annotations.Entity;

@Entity(value = "OasysPaymentRecord", noClassnameStored = true)
public class OasysPaymentRecord extends BaseEntity {

	private String qmaRequestId;
	private Long inquiryId;
	private Long conversationId;
	private String actionBy;

	private Integer nlpResponseCode;
	private Date nlpRequestSentDate;
	private Date nlpResponseReceivedDate;
	private ClcRequestPayload clcRequestPayload;
	
	private Date clcRequestSentDate;
	private Date clcResponseReceivedDate;
	private Integer clcResponseCode;
	private String clcProcessingStatus;
	private ClcOasysResponse clcResponse;
	List<Long> groupIdList;

	public Long getInquiryId() {
		return inquiryId;
	}

	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}

	public Long getConversationId() {
		return conversationId;
	}

	public void setConversationId(Long conversationId) {
		this.conversationId = conversationId;
	}

	public String getActionBy() {
		return actionBy;
	}

	public void setActionBy(String actionBy) {
		this.actionBy = actionBy;
	}

	public Integer getNlpResponseCode() {
		return nlpResponseCode;
	}

	public void setNlpResponseCode(Integer nlpResponseCode) {
		this.nlpResponseCode = nlpResponseCode;
	}

	public Date getNlpRequestSentDate() {
		return nlpRequestSentDate;
	}

	public void setNlpRequestSentDate(Date nlpRequestSentDate) {
		this.nlpRequestSentDate = nlpRequestSentDate;
	}

	public Date getNlpResponseReceivedDate() {
		return nlpResponseReceivedDate;
	}

	public void setNlpResponseReceivedDate(Date nlpResponseReceivedDate) {
		this.nlpResponseReceivedDate = nlpResponseReceivedDate;
	}

	public ClcRequestPayload getClcRequestPayload() {
		return clcRequestPayload;
	}

	public void setClcRequestPayload(ClcRequestPayload clcRequestPayload) {
		this.clcRequestPayload = clcRequestPayload;
	}

	public String getQmaRequestId() {
		return qmaRequestId;
	}

	public void setQmaRequestId(String qmaRequestId) {
		this.qmaRequestId = qmaRequestId;
	}

	public Date getClcRequestSentDate() {
		return clcRequestSentDate;
	}

	public void setClcRequestSentDate(Date clcRequestSentDate) {
		this.clcRequestSentDate = clcRequestSentDate;
	}

	public Date getClcResponseReceivedDate() {
		return clcResponseReceivedDate;
	}

	public void setClcResponseReceivedDate(Date clcResponseReceivedDate) {
		this.clcResponseReceivedDate = clcResponseReceivedDate;
	}

	public Integer getClcResponseCode() {
		return clcResponseCode;
	}

	public void setClcResponseCode(Integer clcResponseCode) {
		this.clcResponseCode = clcResponseCode;
	}

	public String getClcProcessingStatus() {
		return clcProcessingStatus;
	}

	public void setClcProcessingStatus(String clcProcessingStatus) {
		this.clcProcessingStatus = clcProcessingStatus;
	}

	public ClcOasysResponse getClcResponse() {
		return clcResponse;
	}

	public void setClcResponse(ClcOasysResponse clcResponse) {
		this.clcResponse = clcResponse;
	}

	public List<Long> getGroupIdList() {
		return groupIdList;
	}

	public void setGroupIdList(List<Long> groupIdList) {
		this.groupIdList = groupIdList;
	}

}
