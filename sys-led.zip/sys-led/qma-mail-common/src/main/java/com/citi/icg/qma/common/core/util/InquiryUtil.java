package com.citi.icg.qma.common.core.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.Attachment;
import com.citi.icg.qma.common.server.dao.ColumnDef;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.MailBoxDLMapping;
import com.citi.icg.qma.common.server.dao.RulesFlag;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.Workflow;
import com.citi.icg.qma.common.server.dao.persistence.AttachmentDAO;
import com.citi.icg.qma.common.server.util.DedicatedReaderUtility;
import com.citi.icg.qma.common.server.util.EscalationUtility;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.citi.icg.qma.personal.exception.MandatoryConfigurationMissingException;
import com.citi.icg.qma.personal.exchange.ExchangeAdapter;
import com.citi.icg.qma.personal.exchange.ExchangeOperationException;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.PropertySet;
import microsoft.exchange.webservices.data.core.enumeration.property.BasePropertySet;
import microsoft.exchange.webservices.data.core.enumeration.service.ConflictResolutionMode;
import microsoft.exchange.webservices.data.core.enumeration.service.DeleteMode;
import microsoft.exchange.webservices.data.core.service.folder.Folder;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.core.service.item.Item;
import microsoft.exchange.webservices.data.core.service.response.ResponseMessage;
import microsoft.exchange.webservices.data.core.service.schema.ItemSchema;
import microsoft.exchange.webservices.data.property.complex.FolderId;
import microsoft.exchange.webservices.data.property.complex.ItemId;
import microsoft.exchange.webservices.data.property.complex.MessageBody;

public class InquiryUtil
{
	private static final String TO_FROM = "toFrom";
	private static final String CC = "cc";
	private static final String TO = "to";
	private static final String FROM = "from";
	public static final String RECEPIENTS = "recipients";
	public static final String SEARCH = "Search";
	
	public static final String GROUP_RULE = "groupRule";
	
	public static final String SMART_RULE = "smartRule";
	
	public static final String SMARTWORKFLOWSTATUS = "Smart Routing Rule";
	
	public static final String SMART_ROUTING_CONFIG_FLAG_ID = "smartRoutingRule";
	
	public static final String COULMN_DISPLAY_TYPE_ICON = "icon";
	
	private static Logger logger = LoggerFactory.getLogger(InquiryUtil.class);
	
	private InquiryUtil(){
	
	}
	public static Workflow createWorkflowFromExisting(String soeId,Workflow existingWorkflow, EscalationUtility  escalationUtility, Long groupId, Date currentTime)
	{
		Workflow newWorkflow = new Workflow();
		try
 {
			newWorkflow.setDirection(existingWorkflow.getDirection());
			newWorkflow.setAction(existingWorkflow.getAction());
			newWorkflow.setStatus(existingWorkflow.getStatus());
			newWorkflow.setAssignedGroupId(existingWorkflow.getAssignedGroupId());
			newWorkflow.setAssignedGroupName(existingWorkflow.getAssignedGroupName());
			newWorkflow.setAssignedUserId(existingWorkflow.getAssignedUserId());
			newWorkflow.setAssignedUserName(existingWorkflow.getAssignedUserName());
			if(null != existingWorkflow.getUnassignedTimeInMins()){
				newWorkflow.setUnassignedTimeInMins(existingWorkflow.getUnassignedTimeInMins());
			}
			newWorkflow.setClientChaseCounter(existingWorkflow.getClientChaseCounter());
			newWorkflow.setTag(existingWorkflow.getTag());
			newWorkflow.setIsManualEscalation(existingWorkflow.getIsManualEscalation());
			newWorkflow.setManualEscalationReason(existingWorkflow.getManualEscalationReason());
			newWorkflow.setInquirySource(existingWorkflow.getInquirySource());
			newWorkflow.setInquiryRefSent(existingWorkflow.getInquiryRefSent());
			newWorkflow.setIsConvCountEscalation(null);
			newWorkflow.setIsClientChaseEscalation(null);
			newWorkflow.setGeneralEscalationReason(null);
			newWorkflow.setIsLastConvToExtEmail(existingWorkflow.getIsLastConvToExtEmail());
			newWorkflow.setIsMakerCheckerEnabled(existingWorkflow.getIsMakerCheckerEnabled());
			newWorkflow.setLastActionby(existingWorkflow.getLastActionby());
			newWorkflow.setLastActionTime(existingWorkflow.getLastActionTime());
			newWorkflow.setLatestClientChaseCounter(existingWorkflow.getLatestClientChaseCounter());
			newWorkflow.setLatestConversationTime(existingWorkflow.getLatestConversationTime());
			newWorkflow.setLinkId(existingWorkflow.getLinkId());
			newWorkflow.setLock(existingWorkflow.getLock());
			newWorkflow.setLockedBy(existingWorkflow.getLockedBy());
			newWorkflow.setLockedDate(existingWorkflow.getLockedDate());
			newWorkflow.setMaker(existingWorkflow.getMaker());
			newWorkflow.setOriginDate(existingWorkflow.getOriginDate());
			newWorkflow.setPrevConvCount(existingWorkflow.getPrevConvCount());
			newWorkflow.setPrevResponseCntr(existingWorkflow.getPrevResponseCntr());
			newWorkflow.setProcessingRegion(existingWorkflow.getProcessingRegion());
			newWorkflow.setQueryCount(existingWorkflow.getQueryCount());
			newWorkflow.setReOpenDate(existingWorkflow.getReOpenDate());
			newWorkflow.setReplyCountQMA(existingWorkflow.getReplyCountQMA());
			newWorkflow.setRequestType(existingWorkflow.getRequestType());
			newWorkflow.setResolver(existingWorkflow.getResolver());
			newWorkflow.setResolveTime(existingWorkflow.getResolveTime());
			newWorkflow.setSuggestionIndicator(existingWorkflow.getSuggestionIndicator());
			newWorkflow.setIntentSuggestionName(existingWorkflow.getIntentSuggestionName());
			newWorkflow.setUserIntentSuggestionName(existingWorkflow.getUserIntentSuggestionName());
			newWorkflow.setIntentTimeToVD(existingWorkflow.getIntentTimeToVD());
			//[C153176-1270] - Add Escalation criteria for 'Pending Approval' emails
			// for pending approval re-age we are setting the response time escalation 
			Integer paResponseTimeThreshold = escalationUtility.getAllGroupsEscalationCriteriaMap().get(groupId).getPaResponseTimeThresholdForEscalation();
			if (null != paResponseTimeThreshold && paResponseTimeThreshold > 0
					&& null == newWorkflow.getResponseTimeNextEscalation()) {
				newWorkflow.setResponseTimeNextEscalation(escalationUtility.generateNextEscalationTime(groupId,currentTime, paResponseTimeThreshold));
				newWorkflow.setResponseTimeEscalationFlag("N");
				newWorkflow.setIspendingApprovalEscalation("N");
			} else {
				newWorkflow.setIspendingApprovalEscalation(null);
				newWorkflow.setResponseTimeEscalationFlag(null);
				newWorkflow.setResponseTimeEscalationReason(null);
				newWorkflow.setResponseTimeNextEscalation(null);
			}
			newWorkflow.setResponseTimeQMA(existingWorkflow.getResponseTimeQMA());
			newWorkflow.setRootCause(existingWorkflow.getRootCause());
			newWorkflow.setRulesFlag(existingWorkflow.getRulesFlag());
			newWorkflow.setTotalResolveTimeQMA(existingWorkflow.getTotalResolveTimeQMA());
			newWorkflow.setWorkflowStatus(existingWorkflow.getWorkflowStatus());
			newWorkflow.setIsSubjectEscalation(existingWorkflow.getIsSubjectEscalation());
			newWorkflow.setCrtBy(existingWorkflow.getCrtBy());
			newWorkflow.setCrtDate(existingWorkflow.getCrtDate());
			newWorkflow.setModBy(soeId);
			newWorkflow.setModDate(new Date());
			newWorkflow.setConvCount(existingWorkflow.getConvCount());
			
			// C153176-5354 | Panorama feed
			newWorkflow.setFirstResponseTime(existingWorkflow.getFirstResponseTime());
			newWorkflow.setFirstResponseInMinutes(existingWorkflow.getFirstResponseInMinutes());
			newWorkflow.setResponseTimeInMinutes(existingWorkflow.getResponseTimeInMinutes());
			newWorkflow.setResolutionTimeInMinutes(existingWorkflow.getResolutionTimeInMinutes());
			
			// C153176-5891 | Average response time not calculated correctly
			newWorkflow.setIsLatestResponseFromNonQMA(existingWorkflow.getIsLatestResponseFromNonQMA());
			newWorkflow.setFirstNonChaserResponseTimeByExternal(existingWorkflow.getFirstNonChaserResponseTimeByExternal());
			newWorkflow.setCitiResponseTime(existingWorkflow.getCitiResponseTime());
			newWorkflow.setCitiReplyCountFromQMA(existingWorkflow.getCitiReplyCountFromQMA());
			
			// C153176-5977 | Nominate ownership : Resolution time getting considered from the time of ownership requested
			newWorkflow.setOwnershipAcceptedTime(existingWorkflow.getOwnershipAcceptedTime());
			
			//C153176-6167 | Custom snooze time
			newWorkflow.setIsWorkflowEverSnoozed(existingWorkflow.getIsWorkflowEverSnoozed());
			// C170665-118 for time in queue
			newWorkflow.setIsLatestReplyFromCurrentWorkflowGrp(existingWorkflow.getIsLatestReplyFromCurrentWorkflowGrp());
		}
		catch (Exception e)
		{
			logger.error("Issue in createWorkflowFromExisting {}",e);
			newWorkflow=null;
		}
		return newWorkflow;
	} 
	
	public static String replaceBaseTag(String content1)
	{
		String content = content1;
		// Sonar Fix -- Introduce a new variable instead of reusing the parameter
		if (!StringUtils.isBlank(content))
			// [C153176-661] - Replacing <base> tag with <custombase> to prevent application context being changed
			// [C153176-1668] - QMA screen is freezing when user is trying to open particular email 
			content = content1.replaceAll("<base", "<custombase").replaceAll("</base", "</custombase").replaceAll("!\r\n", "");
		return content;
	}
	
	public static Inquiry createInquiryFromExisting(String soeId,Inquiry existingInquiry)
	{
		Inquiry newInquiry = null;
		try
		{
			newInquiry=existingInquiry;
			newInquiry.setId(null);
			newInquiry.setWorkflows(null);
		}
		catch (Exception e)
		{
			logger.error("Issue in createInquiryFromExisting {}",e);
			newInquiry=null;
		}
		return newInquiry;
	} 
	
	/**
	 * @param saveFlag 
	 * @param recipientList 
	 * @param workflowList
	 * @param logger 
	 * @param newVersionList 
	 * @param allExtistingDBVersionList 

	 * Apply smart routing rule only for CC participants, and make them NON Inquiry. Once group's workflow is inquiry(means came in TO list first time or later) , it will never become Non-Inquiry using smart Routing. 
	 * 
	 */
	public static Set<Long> applySmartRoutingRules(boolean saveFlag, Set<ConversationRecipient> recipientList, List<Workflow> workflowList,  List<Long> newVersionListGroupIds) 
	{
		Set<Long> smartRoutingGroupIds = new HashSet<>();
		
		String toFromType = "CC";		
		List<Long> onlyCCGroupIdList = getGroupIdListByType(recipientList,toFromType);
		
		try
		{
			if(null !=workflowList && !onlyCCGroupIdList.isEmpty())
			{
				// workflowList contains all existingDbworkflowList and newVersionWorkflowList
				for(Workflow workflow : workflowList)
				{

					if(rulesCheck(saveFlag,onlyCCGroupIdList,workflow,newVersionListGroupIds))
					{
						applySmartRoutingToAllCCRecipients(onlyCCGroupIdList,smartRoutingGroupIds,workflow);
					}
				}
			}
			//reset workflow status for To recipients.
			resetWorkflowStatusForToRecipients(onlyCCGroupIdList, workflowList);
		}catch (Exception e)
		{
			logger.error("Issue in applySmartRoutingRules {}",e);
		}
		
		return smartRoutingGroupIds;
	}

	/**
	 * @param saveFlag 
	 * @param saveFlag
	 * @param onlyCCGroupIdList
	 * @param workflow
	 * @param newVersionListGroupIds
	 * @param logger
	 * @return
	 * 
	 *  if saveFalg = true, always apply smart routing for all CC groups.
	 *  if saveFalg = false and newVersionListGroupIds = null, Then No change in workflow.
	 *  if saveFlag = false and newVersionListGroupIds = not null, then apply smart Rules only for newly added CC groups. 
	 */
	private static boolean rulesCheck(boolean saveFlag, List<Long> onlyCCGroupIdList, Workflow workflow, List<Long> newVersionListGroupIds)
	{
		if(saveFlag)
		{
			return true;
		}
		// this is reply case (!saveFlag), 
		if(newVersionListGroupIds == null || newVersionListGroupIds.isEmpty())
		{
			return false;
		}
	
		// this is reply case (!saveFlag), newVersionGroupId is partOf CC list then apply smart routing rules. 
		if(onlyCCGroupIdList.contains(workflow.getAssignedGroupId()) && newVersionListGroupIds.contains(workflow.getAssignedGroupId()))
		{
			return true;
		}
		else
		{
			logger.info("InquiryUtil.applySmartRoutingRules - rulesCheck  - NOT Applied SMART Routing Rule for assignedGroupId is: {}", workflow.getAssignedGroupId());
		}
		
		
		return false;
		
	}
	/**
	 * @param onlyCCGroupIdList
	 * @param smartRoutingGroupIds 
	 * @param workflow
	 * @param logger
	 * 
	 * Apply Smart Rules for all CC participants and make them NON Inquiry.
	 * 
	 *  When this scenario will occur :
	 *  First email : UAT1 in TO list , QA1, QA2 in  CC list (apply smart routing and update workflow status =  Smart Routing Rule.)
	 *  on subsequent email, QA1 is coming in to TO list ( Don't apply smart routing and reset workflow status to null).
	 */	 
	private static void applySmartRoutingToAllCCRecipients(List<Long> onlyCCGroupIdList, Set<Long> smartRoutingGroupIds, Workflow workflow)
	{
		boolean isStatusINAndOpen = null!= workflow.getDirection() && null!= workflow.getStatus() &&  "IN".equals(workflow.getDirection()) &&  "Open".equals(workflow.getStatus());
		boolean groupIdCCCheck = null!= workflow.getAssignedGroupId() && onlyCCGroupIdList.contains(workflow.getAssignedGroupId());
		
		if(workflow.getRulesFlag()==null && isStatusINAndOpen && groupIdCCCheck)
		{
			RulesFlag rulesFlag = new RulesFlag();
			rulesFlag.setMarkAsNonInquiry(true);
			rulesFlag.setRuleType(SMART_RULE);
			workflow.setRulesFlag(rulesFlag);
			workflow.setWorkflowStatus(SMARTWORKFLOWSTATUS);
			smartRoutingGroupIds.add(workflow.getAssignedGroupId());
			
			logger.info("InquiryUtil.applySmartRoutingRules - Applied SMART Routing Rule for assignedGroupId is: {}", workflow.getAssignedGroupId());			
		}
		
	}
	
	/**
	 * @param ccGroupIdList 
	 * @param workflowList
	 * @param logger
	 * 
	 *  remove Worflow status only for INBOX. bcoz same group can have pending approval box as well. so Don't reset for pending box.
	 *  
	 *  When this scenario will occur :
	 *  First email : QA1 in CC list (apply smart routing and update workflow status =  Smart Routing Rule.
	 *  on subsequent email, QA1 is moved to TO list ( Don't apply smart routing and reset workflow status to null).
	 */	
	private static void resetWorkflowStatusForToRecipients(List<Long> ccGroupIdList, List<Workflow> workflowList)
	{
		
		if(null!=workflowList)
		{
			for(Workflow workflow : workflowList)
			{
				// non cc recipients , direction can be in or out.
				boolean directionCheck = ("IN".equals(workflow.getDirection()) || "OUT".equals(workflow.getDirection()) ) && null!= workflow.getAssignedGroupId() && !ccGroupIdList.contains(workflow.getAssignedGroupId());
				
				if(directionCheck)
				{
					resetSmarWorkflowStatus(workflow);
				}
			}
		}
	}
	
	/**
	 * @param workflowObj
	 */
	private static void resetSmarWorkflowStatus(Workflow workflowObj)
	{

		if(SMARTWORKFLOWSTATUS.equals(workflowObj.getWorkflowStatus()))
		{
			logger.info("InquiryUtil.applySmartRoutingRules - reset workflow status to null,  assignedGroupId is:{}, direction is : {}" ,workflowObj.getAssignedGroupId(), workflowObj.getDirection());
			workflowObj.setWorkflowStatus(null);
			
		}
	}
	
	/**
	 * @param recipientList
	 * @param toFromType
	 * @return cc recipients list
	 */
	public static List<Long> getGroupIdListByType (Set<ConversationRecipient> recipientList, String toFromType)
	{
		List<Long> ccGroupIdList = new ArrayList<>();
		
		if (recipientList != null)
		{
			for (ConversationRecipient recp : recipientList)
			{
				if (toFromType.equalsIgnoreCase(recp.getToFrom()) && recp.getGroupId() != null)
				{
					ccGroupIdList.add(recp.getGroupId());
				}
			}
		}

		return ccGroupIdList;
	}
	
	
	/**
	 * @param configIdMap
	 * @return
	 */
	public static boolean getSmartRoutingFlagFromConfig(Map<String, Config> configIdMap) 
	{
	
		if(configIdMap != null && configIdMap.get(SMART_ROUTING_CONFIG_FLAG_ID)!=null)
		{
			Config smartRoutingConfig = configIdMap.get(SMART_ROUTING_CONFIG_FLAG_ID);
			return smartRoutingConfig.isSmartRoutingRuleEnabled();			
		}
		
		return false;
	}
	
	public static List<ColumnDef> reArrangeColumnDef(List<ColumnDef> columnDef)
	{
		List<ColumnDef> iconColumnDef = new ArrayList<>();
		List<ColumnDef> nonIconColumnDef = new ArrayList<>();
		for(ColumnDef col : columnDef)
		{
			if(col!=null && COULMN_DISPLAY_TYPE_ICON.equalsIgnoreCase(col.getDisplayType()))
			{
				iconColumnDef.add(col);
			}
			else
			{
				nonIconColumnDef.add(col);
			}
		}		
		iconColumnDef.addAll(nonIconColumnDef);
		return iconColumnDef;
	}
	
	public static void updateApprovedExternalDomain(Inquiry inquiry, String fromAddress)
	{
		if (StringUtils.isNotBlank(fromAddress) && !GenericUtility.isCitiDomainEmail(fromAddress))
		{
			String fromAddressStr = fromAddress.trim();
			if (fromAddressStr.startsWith("'") && fromAddressStr.endsWith("'"))
			{
				fromAddressStr = fromAddressStr.substring(1, fromAddressStr.length() - 1);
			}
			String extSenderDomain = (fromAddressStr.indexOf('@') == -1) ? "" : fromAddressStr.substring(fromAddressStr.indexOf('@') + 1);
			if (StringUtils.isNotBlank(extSenderDomain) && null != inquiry)
			{
				Set<String> domains = inquiry.getApprovedExternalDomains();
				if (domains == null)
					domains = new HashSet<>();
				domains.add(extSenderDomain);
				inquiry.setApprovedExternalDomains(domains);
			}
		}

	}
	
	public static void updatePendingExternalDomainForWorkflow(Workflow verDO, Set<String> pendingExternalDomains)
	{
		if(pendingExternalDomains!=null && verDO!=null)
		{
			Set<String> domains = verDO.getPendingExternalDomains();
			if(domains == null){
				domains = new HashSet<>();
			}
			for(String emailAddr : pendingExternalDomains)
			{
				if(StringUtils.isNotBlank(emailAddr) && !GenericUtility.isCitiDomainEmail(emailAddr))
				{
					String extSenderDomain = (emailAddr.indexOf('@') == -1) ? "" : emailAddr.substring(emailAddr.indexOf('@') + 1);

					if(StringUtils.isNotBlank(extSenderDomain))
					{
						domains.add(extSenderDomain);
					}
				}
			}
			verDO.setPendingExternalDomains(domains);
		}

	}
	

	public static boolean sendEWSMail(String soeId, String action, String subject, String bodyContent,
			Map<String, List<String>> recipientMap, String exchItemId, List<Attachment> attachmentsList, AttachmentDAO attachmentDao) {
		Boolean bSuccess = false;
		try {
			ExchangeService service = getUserExchConnection(soeId, null);

			EmailMessage msg = null;
			if (QMAActionEnum.ACTION_REPLY.getName().equalsIgnoreCase(action) 
					|| QMAActionEnum.ACTION_REPLY_ALL.getName().equalsIgnoreCase(action) 
					|| QMAActionEnum.ACTION_FORWARD.getName().equalsIgnoreCase(action) ) {
				PropertySet propSet = new PropertySet(BasePropertySet.IdOnly, ItemSchema.LastModifiedTime);
				// Bind to the email message to reply to by using the ItemId.
				// This method call results in a GetItem call to EWS.
				ItemId itemId = new ItemId(exchItemId);
				msg = EmailMessage.bind(service, itemId, propSet);
				ResponseMessage responseMessage = msg.createReply(false);
				// Prepend the reply to the message body.
				// string myReply = "This is the message body of the email
				// reply.";
				responseMessage.setSubject(subject);
				responseMessage.setBody(MessageBody.getMessageBodyFromText(bodyContent));
				List<String> to = recipientMap.get("TO");
				if (to == null || to.size() == 0) {
					logger.warn("To distribution list is empty. Could not send the mail ");
				} else {
					for (String mailTo : to) {
						if (StringUtils.isNotBlank(mailTo)) {
							responseMessage.getToRecipients().add(mailTo);
						}
					}
					List<String> cc = recipientMap.get("CC");
					if (cc != null && !cc.isEmpty()) {
						for (String mailCc : cc) {
							if (StringUtils.isNotBlank(mailCc))
								responseMessage.getCcRecipients().add(mailCc);
						}
					}
				}
				//   Add external email attachments
				EmailMessage reply = responseMessage.save();
				addAttachmentsToEWSMsg(attachmentsList, reply,attachmentDao);
			    reply.update(ConflictResolutionMode.AutoResolve);
			    
				// Send the response message.
				// This method call results in a CreateItem call to EWS.
			    reply.sendAndSaveCopy();
				// Check that the response was sent by calling FindRecentlySent.
				bSuccess = true;
			} else if (QMAActionEnum.ACTION_NEW.getName().equalsIgnoreCase(action)) {
			msg = new EmailMessage(service);
			msg.setSubject(subject);
			msg.setBody(MessageBody.getMessageBodyFromText(bodyContent));
			//   Add external email attachments
			addAttachmentsToEWSMsg(attachmentsList, msg, attachmentDao);
			
			
				sendAndSaveCopy(msg, recipientMap);
				bSuccess = true;
				logger.info("This operation is not successful");
			}
		} catch (Exception e) {
			logger.error("Exception occurred while sending EWS Mail ", e);
			bSuccess = false;
		}
		return bSuccess;
	}
	private static void addAttachmentsToEWSMsg(List<Attachment> attachmentsList, EmailMessage msg, AttachmentDAO attachmentDao) throws IOException {
		FileInputStream in = null;
		try {
			if(null == attachmentsList || attachmentsList.isEmpty()) {
				logger.info("In InquiryUtil.addAttachmentsToEWSMsg AttachmentList is empty");
				return;
			}
			LinkedHashMap<File, String> fileMap = getFileMap(attachmentsList, attachmentDao);
			Set<Entry<File, String>> fileMapSet = fileMap.entrySet();
			for (Entry<File, String> attachment : fileMapSet)
			{
				String fileName = attachment.getValue();
				File file = attachment.getKey();
				in = new FileInputStream(file);
				msg.getAttachments().addFileAttachment(fileName, in);
			}
		} catch (Exception e ){
			logger.warn("Exception while processing attachments for EWS email in addAttachmentsToEWSMsg() : ",e);
		} finally {
			if(null != in) {
				in.close();
			}
			
		}

	}

	private static LinkedHashMap<File, String> getFileMap(List<Attachment> attachmentList, AttachmentDAO attachmentDao) throws CommunicatorException
	{
		LinkedHashMap<File, String> fileMap = new  LinkedHashMap<>();
		String key;
		if (attachmentList != null)
		{
			for (Attachment attachment : attachmentList)
			{
				key = attachment.getId();
				String name = attachment.getName();
				File f = getDocumentFile(key, attachmentDao);

				if(Objects.nonNull(f)){
					fileMap.put(f, name);
				}
			}
		}
		return fileMap;
	}
	
	private static File getDocumentFile(String docId, AttachmentDAO attachmentDao) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one, XmException
	{
		File file = null;
		try
		{ 
			if(null != attachmentDao) {
				Map<String, Object> mongoDataMap = attachmentDao.getFile(docId);
				file = (File) mongoDataMap.get("fileObject");
			}else {
				logger.info("In InquiryUtil.getDocumentFile, attachmentDao is null");
			}
			
		}
		catch (Exception e)
		{
			logger.error("Exception while reading file from Mongo DB. ", e);
		}
		return file;
	}
	public static ExchangeService getUserExchConnection(String soeId,MailBoxDLMapping mapping) throws ExchangeOperationException, MandatoryConfigurationMissingException {
		ExchangeService service = null;
		// Get the MailBoxDLMapping
		if( null == mapping) {
			mapping = DedicatedReaderUtility.getInstance().getMappingById(soeId);
		}
		if (null != mapping) {
			String loginSecret = DedicatedReaderUtility.getInstance().getSecret(mapping);
			service = ExchangeAdapter.getExchangeService(mapping.getId(), mapping.getId(), loginSecret,
					mapping.getConnectionURL(), mapping.getRegion());
		} else {
			throw new MandatoryConfigurationMissingException("mailbox configuration not found for user ["+soeId+"]");
		}
		return service;
	}

	private static void setupEWSEmailRecipients(List<String> recipientEmailList, List<String> toccRecipients,
			String tofrom, String soeId) {
		if (toccRecipients != null) {
			String grpCode = null;
			User user = null;
			QMACache qmaCache = QMACacheFactory.getCache();
			Map<String, String> groupIdToDBCodeMap = qmaCache.getGroupIdToDBCodeMap();
			Map<String, User> userInfoMap = qmaCache.getUserInfoMap();
			Map<String, Long> groupCodeToIdMap = qmaCache.getGroupCodeToIdMap();
			Map<Long, String> groupIdToEmailMap = qmaCache.getGroupIdToEmailMap();
			Map<String, Long> groupCodeToIdMapBothActiveInactive = qmaCache.getGroupCodeToIdMapBothActiveInactive();
			Map<String, String> groupIdToEmailMapBothActiveInactive = qmaCache.getGroupIdToEmailMapBothActiveInactive();
			Map<String, String> groupEmailToCodeMap = qmaCache.getGroupEmailToCodeMap();
			Map<String, String> groupIdToCodeMapBothActiveInactive = qmaCache.getGroupIdToCodeMapBothActiveInactive();
			for (String grpOrUserId : toccRecipients) {
				// [C15176-347]- All inactive and active groups should be part
				// of TO/CC recipients
				grpCode = groupIdToDBCodeMap.get(grpOrUserId);
				String inActiveGrpCode = groupIdToCodeMapBothActiveInactive.get(grpOrUserId.toUpperCase());
				logger.debug("From Hazelcast inActiveGrpCode: {}",inActiveGrpCode);
				// [C15176-347]- All inactive and active groups should be part
				// of TO/CC recipients
				user = userInfoMap.get(grpOrUserId.toUpperCase());
				if (grpCode != null) {// [C15176-347]- All inactive and active
										// groups should be part of TO/CC
										// recipients
					Long groupId = groupCodeToIdMap.get(grpCode.toUpperCase());
					// [C153176-748] - to and cc fields enrichments
					String email = groupIdToEmailMap.get(groupId);
					recipientEmailList.add(email);
				} else if (inActiveGrpCode != null) {
					Long groupId = groupCodeToIdMapBothActiveInactive.get(inActiveGrpCode.toUpperCase());
					logger.debug("From Hazelcast groupId: {}",groupId);
					String email = groupIdToEmailMapBothActiveInactive.get(groupId.toString());
					logger.debug("From Hazelcast Email: {}",email);
					recipientEmailList.add(email);

				} else if (user != null) {
					recipientEmailList.add(user.getEmail());
				} else if (isEmailAddress(grpOrUserId)) {

					String groupEmailAlias = grpOrUserId.substring(0, grpOrUserId.indexOf('@'));
					grpCode = groupEmailToCodeMap.get(groupEmailAlias.toUpperCase());
					// Set GroupID in recipient and create version for that
					// group if email matches the groupEmail
					// Check for Group Email, then convert to groupId, also send
					// email with groupEmail
					// Check for the external email - [C153176-891]
					if (GenericUtility.isCitiDomainEmail(grpOrUserId) && null != grpCode) {
						// [C15176-347]- All inactive and active groups should
						// be part of TO/CC recipients
						Long groupId = groupCodeToIdMapBothActiveInactive.get(grpCode.toUpperCase());
						logger.info("Received group email : {} , groupAlias before @ = {} ,groupCode = {} ,groupId = {}" ,grpOrUserId,groupEmailAlias,grpCode,groupId);
						// Set group email , groupId, But display name as email
						// address(displayed in conversation detail in UI
						recipientEmailList.add(grpOrUserId);
					}
					// [C153176-1273]- Child group does not receive the mail in
					// QMA for Mail sent from QMA to Parent.
					// This is case of mail being sent to parentDL, which
					// directly does not exists in group table. But exists as
					// parenTDLAliases for all groups.

					// This is for External Email Address.
					else {
						recipientEmailList.add(grpOrUserId);
					}

				}
			}

		}
	}

	public static Map<String, List<String>> getEWSEmailRecpMap(BasicDBObject inputJsonObj, String soeId) {
		Map<String, List<String>> recipientMap = new HashMap<>();

		List<String> list = new ArrayList<String>();
		list = getToCcList(inputJsonObj, "to");
		List<String> toEmailList = new ArrayList<String>();
		setupEWSEmailRecipients(toEmailList, list, "TO", soeId);
		recipientMap.put("TO", toEmailList);
		list = getToCcList(inputJsonObj, "cc");
		List<String> ccEmailList = new ArrayList<String>();
		setupEWSEmailRecipients(ccEmailList, list, "CC", soeId);
		recipientMap.put("CC", ccEmailList);
		list = getToCcList(inputJsonObj, "bcc");
		List<String> bccEmailList = new ArrayList<String>();
		setupEWSEmailRecipients(bccEmailList, list, "BCC", soeId);
		recipientMap.put("BCC", bccEmailList);

		return recipientMap;
	}

	private static boolean isEmailAddress(String grpStr) {
		if (grpStr.indexOf("@") == -1) {
			return false;
		}
		return true;
	}

	// Method can be moved to Util
	private static List<String> getToCcList(BasicDBObject inputJsonObj, String recipientCategory) {
		ArrayList<String> groupNameslist = null;

		if (inputJsonObj.getString(recipientCategory) != null) {
			groupNameslist = new ArrayList<>();

			JSONArray jsArray = new JSONArray(inputJsonObj.getString(recipientCategory));
			for (int i = 0; i < jsArray.length(); i++) {
				JSONObject jsonObj = jsArray.getJSONObject(i);

				groupNameslist.add(jsonObj.getString("value"));

			}

		}
		return groupNameslist;
	}

	private static void sendAndSaveCopy(EmailMessage msg, Map<String, List<String>> recipientMap) throws Exception {
		List<String> to = recipientMap.get("TO");
		if (to == null || to.isEmpty()) { // <<-- sonar fix Remove this call to "equals"; comparisons between unrelated types always return false
			logger.warn("To distribution list is empty. Could not send the mail ");
		} else {
			for (String mailTo : to) {
				if (mailTo != null && !mailTo.isEmpty()) {

					msg.getToRecipients().add(mailTo);
				}
			}
			List<String> cc = recipientMap.get("CC");
			if (cc != null && !cc.isEmpty()) {
				for (String mailCc : cc) {
					if (mailCc != null && !mailCc.equals(""))
						msg.getCcRecipients().add(mailCc);
				}
			}
			msg.sendAndSaveCopy();
		}
	}
	
	public static boolean deleteItemUsingEWS(String soeId, String action, String exchItemId,String deleteMode) {
		Boolean bSuccess = false;
		try {
			ExchangeService service = getUserExchConnection(soeId,null);

			EmailMessage msg = null;
			if (QMAActionEnum.ACTION_DELETE_ITEM_EWS.getName().equalsIgnoreCase(action)) {
				ItemId itemId = new ItemId(exchItemId);
				Item item = Item.bind(service, itemId);
				if(DeleteMode.MoveToDeletedItems.name().equalsIgnoreCase(deleteMode)||
						DeleteMode.HardDelete.name().equalsIgnoreCase(deleteMode)){
				// Delete the item by moving it to the Deleted Items folder.
				// This method call results in a DeleteItem call to EWS.
				item.delete(DeleteMode.valueOf(deleteMode));
				bSuccess=true;
			}
			}
		} catch (Exception e) {
			logger.error("Exception occurred while deleteItemUsingEWS ", e);
			bSuccess = false;
		}
		return bSuccess;
	}
	public static boolean deleteFolderUsingEWS(String soeId, String action, String exchFolderId,String deleteMode) {
		Boolean bSuccess = false;
		try {
			ExchangeService service = getUserExchConnection(soeId,null);
			if (QMAActionEnum.ACTION_DELETE_FOLDER_EWS.getName().equalsIgnoreCase(action)) {
				FolderId folderId = new FolderId(exchFolderId);
				Folder folder = Folder.bind(service, folderId);
				if(DeleteMode.MoveToDeletedItems.name().equalsIgnoreCase(deleteMode)||
						DeleteMode.HardDelete.name().equalsIgnoreCase(deleteMode)){
				// Delete the item by moving it to the Deleted Items folder.
				// This method call results in a DeleteItem call to EWS.
				folder.delete(DeleteMode.valueOf(deleteMode));
				bSuccess=true;
			}
			}
		} catch (Exception e) {
			logger.error("Exception occurred while deleteFolderUsingEWS ", e);
			bSuccess = false;
		}
		return bSuccess;
	}
	/**
	 * @param inputJsonObj
	 * @param match
	 * @param document
	 * @return
	 */
	public static boolean isToCcFromMatch(BasicDBObject inputJsonObj, boolean match, BasicDBObject document) {
		if(null != document.get(RECEPIENTS)) {
			Object recipientsObject = document.get(RECEPIENTS);
			if((inputJsonObj.containsKey(FROM)) && !SEARCH.equalsIgnoreCase(inputJsonObj.getString(FROM))) {
				match = getToFromFilteredInqId(recipientsObject, inputJsonObj);
			} else if(inputJsonObj.containsKey(TO) || inputJsonObj.containsKey(CC)) {
				match = getToFromFilteredInqId(recipientsObject, inputJsonObj);
			} else {
				match = true;
			}
		}
		return match;
	}
	/**
	 * @param recipientsObject
	 * @param inputJsonObj
	 * @return
	 */
	private static boolean getToFromFilteredInqId(Object recipientsObject, BasicDBObject inputJsonObj) {
		boolean match = false;
		try {
			BasicDBList recipientList = (BasicDBList) recipientsObject;
			boolean isFromSearch = inputJsonObj.containsKey(FROM) && !SEARCH.equalsIgnoreCase(inputJsonObj.getString(FROM));
			if (inputJsonObj.containsKey(TO) && isFromSearch) {
				String formValue = inputJsonObj.getString(FROM);
				String toValue = inputJsonObj.getString(TO);
				match = checkFromToMatching(recipientList, formValue, toValue, FROM, TO);
			} else if (isFromSearch && inputJsonObj.containsKey(CC)) {
				String formValue = inputJsonObj.getString(FROM);
				String ccValue = inputJsonObj.getString(CC);
				match = checkFromToMatching(recipientList, formValue, ccValue, FROM, CC);
			} else if (inputJsonObj.containsKey(TO) && inputJsonObj.containsKey(CC)) {
				String ccValue = inputJsonObj.getString(CC);
				String toValue = inputJsonObj.getString(TO);
				match = checkFromToMatching(recipientList, ccValue, toValue, TO, CC);
			} else if (isFromSearch) {
				String formValue = inputJsonObj.getString(FROM);
				match = checkRecipientMatching(recipientList, FROM, formValue);
			} else if (inputJsonObj.containsKey(TO)) {
				String toValue = inputJsonObj.getString(TO);
				match = checkRecipientMatching(recipientList, TO, toValue);
			} else if (inputJsonObj.containsKey(CC)) {
				String ccValue = inputJsonObj.getString(CC);
				match = checkRecipientMatching(recipientList, CC, ccValue);
			}
			 
		}catch(Exception ex) {
			logger.warn("Exception while match to/cc/from recipients",ex);
		}
		return match;
	}
	/**
	 * @param recipientList
	 * @param formValue
	 * @param toValue
	 * @param fromToCCVal1
	 * @param fromToCCVal2
	 * @return
	 */
	private static boolean checkFromToMatching(BasicDBList recipientList, String formValue, String toValue, String fromToCCVal1, String fromToCCVal2) {
		boolean fromToCCMatch1 = false;
		boolean fromToCCMatch2 = false;
		boolean match = false;
		for(Object object : recipientList) {
			BasicDBObject objectToFromCc = BasicDBObject.parse(object.toString());
			if(!fromToCCMatch1) {
				fromToCCMatch1 = matchFromToCC(formValue, fromToCCVal1, objectToFromCc);
			}
			if(!fromToCCMatch2) {
				fromToCCMatch2 = matchFromToCC(toValue, fromToCCVal2, objectToFromCc);
			}
		}
		if(fromToCCMatch1 && fromToCCMatch2) {
			match = true;
		}
		return match;
	}
	/**
	 * @param formValue
	 * @param fromToCCVal1
	 * @param objectToFromCc
	 * @return
	 */
	private static boolean matchFromToCC(String formValue, String fromToCCVal1, BasicDBObject objectToFromCc) {
		boolean match = false;
		String recipientsString = objectToFromCc.toString();
		if(null !=objectToFromCc.get(TO_FROM) && objectToFromCc.get(TO_FROM).toString().equalsIgnoreCase(fromToCCVal1)
				&& recipientsString.toLowerCase().contains(formValue.toLowerCase())){
				match = true;
		}
		return match;
	}
	/**
	 * @param recipientsObject
	 * @param toFromCcKey
	 * @param toFromCcValue
	 * @return
	 */
	private static boolean checkRecipientMatching(BasicDBList recipientsObject, String toFromCcKey, String toFromCcValue) {
		boolean match = false;
		for(Object object : recipientsObject) {
			BasicDBObject objectToFromCc = BasicDBObject.parse(object.toString());
			match = matchFromToCC(toFromCcValue, toFromCcKey, objectToFromCc);
			if(match) {
				break;
			}
		}
		return match;
	}
	public static void updateInquiryOriginSource(BasicDBObject inputJsonObj, Inquiry inquiry) {
		try {
			if(null != inputJsonObj.get("requesterId")) {
				inquiry.setOrigType("INTERNAL_SYS");
				inquiry.setOrigSrcSysId(inputJsonObj.getString("requesterId"));
			}
		}catch (Exception ex){
			logger.warn("Error while patching inquiry oriin source", ex);
		}
	}
}

