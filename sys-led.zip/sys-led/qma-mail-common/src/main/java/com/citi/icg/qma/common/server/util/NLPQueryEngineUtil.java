/**
 * 
 */
package com.citi.icg.qma.common.server.util;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.entity.ContentType;
import org.asynchttpclient.AsyncCompletionHandler;
import org.asynchttpclient.AsyncHttpClient;
import org.asynchttpclient.BoundRequestBuilder;
import org.asynchttpclient.DefaultAsyncHttpClientConfig;
import org.asynchttpclient.Dsl;
import org.asynchttpclient.HttpResponseStatus;
import org.asynchttpclient.Response;
import org.asynchttpclient.request.body.multipart.FilePart;
import org.asynchttpclient.request.body.multipart.StringPart;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.NLPConstants;
import com.citi.icg.qma.common.core.util.QmaMailConstants;
import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.persistence.GroupDAO;
import com.citi.icg.qma.common.server.dao.persistence.NLPSuggestionDAO;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

/**
 *  
 * This class is used to configure and connect to NLP Query engine 
 * and send synchronous or asynchronous request to the NLP host server.
 */
public class NLPQueryEngineUtil {

	private static Logger logger = LoggerFactory.getLogger(NLPQueryEngineUtil.class);
	private static NLPSuggestionDAO sugDao=new NLPSuggestionDAO();
	private static GroupDAO groupDao=new GroupDAO();
	public static Map<String, Object> nlpConfig;
	public static List<String> SUPPORTED_ATTACHMENTS = new ArrayList<>();	
	private NLPQueryEngineUtil(){}
	
	static {
		//nlpConfig = staticData.getNlpConfiguration();
		nlpConfig = QMACacheFactory.getCache().getNlpConfiguration();
		NLPConstants.NLP_HOST_AUTHORIZATION = Base64.getEncoder()
				.encodeToString(((String)nlpConfig.get(NLPConstants.NLP_QMA_USERNAME_KEY) + ':' + (String)nlpConfig.get(NLPConstants.NLP_QMA_PASSDATA_KEY)).getBytes(StandardCharsets.UTF_8));
	}
	
	/**
	 * Get QMA NLP Request Filter Type
	 * By Default only external emails sent to configured group/org will be sent to NLP Engine
	 * Phase 1: QMA supportes External originated emails and Internal Originated Emails outside of QMA
	 * @return
	 */
	public static String getQMANLPType(){
		return (null == nlpConfig.get(NLPConstants.NLP_ORIG_TYPE_KEY))?NLPConstants.DEFAULT_NLP_ORIG_TYPE:(String)nlpConfig.get(NLPConstants.NLP_ORIG_TYPE_KEY) ;
	}
	/**
	 * This method gathers all the necessary information prior sending request and 
	 * sends asynchronous request to NLP Query Engine for provided conversation
	 * @param clientRequestId
	 * @param conversation
	 * @param attachments
	 * @param tradeRefList 
	 * @param logger
	 */
	public static void getNLPSuggestionWithAttachments(String clientRequestId, Conversation conversation,
			List<Map<String, Object>> attachments, List<Long> toCCValidGroupIds, String actionBy, String nlpRequestType,Inquiry inquiry, List<String> tradeRefList) {
		AsyncHttpClient client = null;
		try {
			if(StringUtils.isNotEmpty(NLPConstants.NLP_HOST_AUTHORIZATION)){
				logger.info("NLPQueryEngineUtil#getNLPSuggestionWIthAttachments() called for clientRequestId : " + clientRequestId +" nlpRequestType : "+nlpRequestType+"actionBy : "+actionBy);
				client = getAsyncHttpClient();
				if( client != null ) {
					BasicDBObject requestBody = generateRequestBodyContents(clientRequestId, conversation,nlpRequestType,inquiry,actionBy, toCCValidGroupIds, tradeRefList);
					List<FilePart> fileParts = generateAttachmentBodyParts(attachments, requestBody);
					StringPart stringPart =generateContentBodyPart(requestBody); 
					sugDao.createSuggestionRequestRecord(conversation, clientRequestId,requestBody, toCCValidGroupIds, new Date(),actionBy, nlpRequestType);
					Map<String,Object> httpRequestHeadersParamMap = new HashMap();

					if(null != tradeRefList) {
						logger.info("Calling refresh API.");
						buildAndExecuteAsyncRequestForRefresh(client, clientRequestId,fileParts,requestBody,nlpRequestType,conversation, httpRequestHeadersParamMap, tradeRefList);
					}else {
						buildAndExecuteAsyncRequest(client, clientRequestId,fileParts,stringPart,nlpRequestType,conversation, httpRequestHeadersParamMap);
					}
					sugDao.updateHttpRequestHeaders(clientRequestId, httpRequestHeadersParamMap);
					logger.info("Asynch request processed for clientRequestId("+ clientRequestId + ") at : " + new Date());
					
				} else {
					logger.info("Failed to initialized async client for this request.");
				}
			} else {
				logger.info("Could not find authorization details for NLP Query Engine.");
				closeConnection(client, clientRequestId);
			}
			// call only if nlpRequestType C
			if(nlpRequestType.equals(NLPRequestType.C.toString())){
				sugDao.updateInquiry(conversation, nlpRequestType);
			}
		} catch (Exception e) {
			logger.error(" Error while sending asynch request for client id (" + clientRequestId + ") : ", e);
		}

	}

	/**
	 * This method generates basic request add basic details to the request 
	 * @param clientRequestId
	 * @param conversation
	 * @param toCCValidGroupIds 
	 * @param tradeRefList 
	 * @return BasicDBObject
	 */
	public static BasicDBObject generateRequestBodyContents(String clientRequestId, Conversation conversation,String nlpRequestType,Inquiry inquiry,String actionBy, List<Long> toCCValidGroupIds, List<String> tradeRefList) {
		BasicDBObject requestBody = new BasicDBObject();
		requestBody.put(NLPConstants.CLIENT_REQUEST_ID_KEY, clientRequestId);
		if(null != tradeRefList) {
			requestBody.put("tradeRefList", tradeRefList);
		} else {
			requestBody.put(NLPConstants.BODY_KEY, getUrlEncodedString(GenericUtility.checkAndFetchConvContent(conversation)));
			requestBody.put(NLPConstants.HEADER_KEY, getRequestBodyHeader(clientRequestId,conversation,nlpRequestType,inquiry,actionBy, toCCValidGroupIds));
		}
		return requestBody;
	}

	/**
	 * This method extract and sets conversation details to request body
	 * @param conversation
	 * @param toCCValidGroupIds 
	 * @return BasicDBObject
	 */
	private static BasicDBObject getRequestBodyHeader(String clientRequestId,Conversation conversation,String nlpRequestType,Inquiry inquiry,String actionBy, List<Long> toCCValidGroupIds) {
		BasicDBObject requestBodyHeader = new BasicDBObject();
		setMetaDataForAutoAssign(inquiry, conversation, requestBodyHeader, nlpRequestType, toCCValidGroupIds);
		if ( null != conversation.getRecipients() && !conversation.getRecipients().isEmpty()) {
			StringBuilder toValue = new StringBuilder();
			StringBuilder ccValue = new StringBuilder();
			for (ConversationRecipient currentRecipient : conversation.getRecipients()) {
				updateConversationRecepients(requestBodyHeader, currentRecipient, toValue, ccValue);
			}
		}
		String sender=(String)requestBodyHeader.get(NLPConstants.SENDER_KEY);
		if (NLPRequestType.S.name().equalsIgnoreCase(nlpRequestType) 
				&& StringUtils.isNotBlank(actionBy)
				&& StringUtils.isNotBlank(sender) 
				&& GenericUtility.isCitiDomainEmail(sender)
				&& !GenericUtility.isCitiDomainEmail(actionBy)){
			//String nonCitiSender=getFirstNonCitiFromClientDetails(clientRequestId,actionBy,conversation.getContent());
			//if (StringUtils.isNotBlank(nonCitiSender) &&StringUtils.isNotBlank(requestBodyHeader.getString(SENDER_KEY))) {
				requestBodyHeader.put(NLPConstants.SENDER_KEY, actionBy);
			//}
		}
		if (!StringUtils.isEmpty(conversation.getSubject())) {
			requestBodyHeader.put(NLPConstants.SUBJECT_KEY, getUrlEncodedString(conversation.getSubject()));
		} else {
			requestBodyHeader.put(NLPConstants.SUBJECT_KEY, "");
		}
		
		if (conversation.getCrtDate()!=null) {
			requestBodyHeader.put(NLPConstants.DATE_KEY, QmaMailConstants.DATE_FORMAT.format(conversation.getCrtDate()));
		}
		return requestBodyHeader;
	}
	/**
	 * Set metadata for auto assignment NLP request
	 * @param inquiry
	 * @param conversation
	 * @param requestBodyHeader
	 * @param nlpRequestType
	 * @param toCCValidGroupIds 
	 */
	private static void setMetaDataForAutoAssign(Inquiry inquiry, Conversation conversation, BasicDBObject requestBodyHeader, String nlpRequestType, List<Long> toCCValidGroupIds) {
		if(inquiry !=null && StringUtils.isNotBlank(inquiry.getGpNum())){
			BasicDBObject metadata = new BasicDBObject();
			BasicDBObject gpObject = new BasicDBObject();
			gpObject.put("gpId", inquiry.getGpNum());
			gpObject.put("name", inquiry.getGpName());
			metadata.put("senderOrganization", gpObject);
			metadata.put("LOB", getLOBHeaders(toCCValidGroupIds));
			requestBodyHeader.put("metadata", metadata);
		}
	}

	/**
	 * This method updates TO/CC/FROM details of a mail
	 * @param requestBodyHeader
	 * @param currentRecipient
	 * @param ccValue 
	 * @param toValue 
	 */
	private static void updateConversationRecepients(BasicDBObject requestBodyHeader,
			ConversationRecipient currentRecipient, StringBuilder toValue, StringBuilder ccValue) {
		if(!StringUtils.isEmpty(currentRecipient.getToFrom())){
			String value = currentRecipient.getEmailAddr();
			if(value == null && null != currentRecipient.getUserId()){
				//User user = CacheDAO.getInstance().getUserDetailsMap().get(currentRecipient.getUserId().toUpperCase());
				Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
				User user =null;
				if(userInfoMap!=null){
					user = currentRecipient.getUserId()==null?null:userInfoMap.get(currentRecipient.getUserId().toUpperCase());	
				}
				value = null != user ? user.getEmail() : "";
			}
			if(value == null){
				value = "";
			}
			if (NLPConstants.TO.equalsIgnoreCase(currentRecipient.getToFrom())) {
				if(null != toValue && toValue.length() > 0) {
					toValue = toValue.append(";").append(value);
				}else {
					toValue.append(value);
				}
				requestBodyHeader.put(NLPConstants.TO_KEY, toValue.toString());
			}
			if (NLPConstants.FROM.equalsIgnoreCase(currentRecipient.getToFrom())) {
				requestBodyHeader.put(NLPConstants.SENDER_KEY, value);
			}
			if (NLPConstants.CC.equalsIgnoreCase(currentRecipient.getToFrom())) {
				if(null != ccValue && ccValue.length() > 0) {
					ccValue = ccValue.append(";").append(value);
				}else {
					ccValue.append(value);
				}
				requestBodyHeader.put(NLPConstants.CC_KEY, ccValue.toString());
			}
		}
	}

	/**
	 * @param client
	 * @param clientReqId
	 * @param fileParts
	 * @param stringPart
	 * @param nlpRequestType
	 * @param conversation
	 * @param httpHeadersParamMap
	 * @param tradeRefList
	 */
	private static void buildAndExecuteAsyncRequestForRefresh(AsyncHttpClient client, String clientReqId,
			List<FilePart> fileParts, BasicDBObject stringPart, String nlpRequestType, Conversation conversation,
			Map<String, Object> httpHeadersParamMap, List<String> tradeRefList) {
		try {
			BoundRequestBuilder builder = client.preparePost(getNLPHostURL(nlpRequestType, tradeRefList));
			builder.addHeader(HttpHeaders.AUTHORIZATION, "Basic " + NLPConstants.NLP_HOST_AUTHORIZATION);
			builder.setHeader(HttpHeaders.CONTENT_TYPE, ContentType.APPLICATION_JSON.getMimeType());
			builder.setHeader(NLPConstants.CALLBACK_URL_KEY, getQMAServiceURL());
			httpHeadersParamMap.put(HttpHeaders.CONTENT_TYPE, ContentType.APPLICATION_JSON.getMimeType());
			httpHeadersParamMap.put(NLPConstants.CALLBACK_URL_KEY, getQMAServiceURL());
			String clientSecret = NLPQueryEngineUtil.getXIBMClientSecret();
			String clientId = NLPQueryEngineUtil.getXIBMClientId();
			if (StringUtils.isNotBlank(clientSecret) && StringUtils.isNotBlank(clientId)) {
				builder.setHeader(NLPConstants.X_IBM_Client_Secret_Key, clientSecret);
				builder.setHeader(NLPConstants.X_IBM_Client_id_Key, clientId);
			}
			setAutoAssignedFwdHeader(builder, conversation, httpHeadersParamMap);
			builder.setBody(stringPart.toJson());
			builder.execute(new AsyncCompletionHandler<Object>() {
				@Override
				public Object onCompleted(Response response) throws Exception {
					logger.info("!!! on refresh completed !!! ");
					return response;
				}
				@Override
				public State onStatusReceived(HttpResponseStatus status) throws Exception {
					logger.info("Status Received for refresh API: {}", status);
					logger.info("Closing client connection onStatusReceived !");
					closeConnection(client, clientReqId);
					sugDao.updateSugReqStatus(clientReqId, status.getStatusCode(), status.getStatusText());
					return State.ABORT;
				}
				@Override
				public void onThrowable(Throwable t) {
					logger.error("Error while processing refresh request to NLP query Engine for clientRequestId : {}, {}",
							clientReqId, t);
					closeConnection(client, clientReqId);
				}
			});
		} catch (Exception e) {
			logger.error("Exception while executing client refresh request for clientRequestId :{}",clientReqId , e);
		}
	}
	/**
	 * This method builds and executes asynchronous client request
	 * @param client
	 * @param clientReqId
	 * @param logger
	 * @param fileParts
	 * @param stringPart
	 * @param conversation 
	 * @param httpHeadersParamMap 
	 * @param tradeRefList 
	 */
	private static void buildAndExecuteAsyncRequest(AsyncHttpClient client, String clientReqId,
			List<FilePart> fileParts, StringPart stringPart, String nlpRequestType, Conversation conversation,
			Map<String, Object> httpHeadersParamMap) {
		try {
			BoundRequestBuilder builder = client.preparePost(getNLPHostURL(nlpRequestType, null));
			builder.addHeader(HttpHeaders.AUTHORIZATION, "Basic " + NLPConstants.NLP_HOST_AUTHORIZATION);
			builder.setHeader(HttpHeaders.CONTENT_TYPE, ContentType.MULTIPART_FORM_DATA.getMimeType());
			builder.setHeader(NLPConstants.CALLBACK_URL_KEY, getQMAServiceURL());
			httpHeadersParamMap.put(HttpHeaders.CONTENT_TYPE, ContentType.MULTIPART_FORM_DATA.getMimeType());
			httpHeadersParamMap.put(NLPConstants.CALLBACK_URL_KEY, getQMAServiceURL());
			// For Non Secure connection, Url should be configured with http and no client
			// secret and client Id in config.
			String clientSecret = NLPQueryEngineUtil.getXIBMClientSecret();
			String clientId = NLPQueryEngineUtil.getXIBMClientId();
			if (StringUtils.isNotBlank(clientSecret) && StringUtils.isNotBlank(clientId)) {
				builder.setHeader(NLPConstants.X_IBM_Client_Secret_Key, clientSecret);
				builder.setHeader(NLPConstants.X_IBM_Client_id_Key, clientId);
			}
			setAutoAssignedFwdHeader(builder, conversation, httpHeadersParamMap);
			/* Add String body parts */
			builder.addBodyPart(stringPart);
			/* Add attachment body parts */
			for (FilePart filePart : fileParts) {
				builder.addBodyPart(filePart);
			}
			/* Execute the request */
			builder.execute(new AsyncCompletionHandler<Object>() {
				@Override
				public Object onCompleted(Response response) throws Exception {
					return response;
				}
				@Override
				public State onStatusReceived(HttpResponseStatus status) throws Exception {
					logger.info("Status Received : " + status);
					logger.info("Closing client connection onStatusReceived !");
					closeConnection(client, clientReqId);
					sugDao.updateSugReqStatus(clientReqId, status.getStatusCode(), status.getStatusText());
					return State.ABORT;
				}
				@Override
				public void onThrowable(Throwable t) {
					logger.error(
							"Error while processing request to NLP query Engine for clientRequestId : " + clientReqId,
							t);
					closeConnection(client, clientReqId);
				}
			});
		} catch (Exception e) {
			logger.error("Exception while executing client request for clientRequestId (" + clientReqId + "):", e);
		}
	}

	/**
	 * This method provides AUTO ASSIGNMENT host url
	 * @param logger
	 * @return
	 */
	public static String getXIBMClientSecret() {
		logger.info("getXIBMClientSecret() starts ");
		String autoAssignmentClientSecret = null; 
		if(NLPQueryEngineUtil.nlpConfig !=null && null != NLPQueryEngineUtil.nlpConfig.get(NLPConstants.X_IBM_Client_Secret)){
			autoAssignmentClientSecret = (String)NLPQueryEngineUtil.nlpConfig.get(NLPConstants.X_IBM_Client_Secret);
		}
		logger.info("Auto Assignment service Client Secret is : " + autoAssignmentClientSecret);
		logger.info("getXIBMClientSecret() ends ");
		return autoAssignmentClientSecret;
	}
	
	/**
	 * This method provides AUTO ASSIGNMENT host url
	 * @param logger
	 * @return
	 */
	public static String getXIBMClientId() {
		logger.info("getXIBMClientId() starts ");
		String autoAssignmentClientId = null; 
		if(NLPQueryEngineUtil.nlpConfig !=null && null != NLPQueryEngineUtil.nlpConfig.get(NLPConstants.X_IBM_Client_id)){
			autoAssignmentClientId = (String)NLPQueryEngineUtil.nlpConfig.get(NLPConstants.X_IBM_Client_id);
		}
		logger.info("Auto Assignment service Client Id is : " + autoAssignmentClientId);
		logger.info("getXIBMClientId() ends ");
		return autoAssignmentClientId;
	}
	
	/**
	 * @param toCCValidGroupIds
	 * @return
	 */
	private static Set<String> getLOBHeaders(List<Long> toCCValidGroupIds) {
		Set<String> lobSet = new HashSet<>();
		Map<Long, Group> allGroupsFromCache = QMACacheFactory.getCache().getAllGroupsMap();
		for (Long groupId : toCCValidGroupIds) {
			Group group = allGroupsFromCache.get(groupId);
			if (null != group && null != group.getLob()) {
				lobSet.add(group.getLob());
			}
		}
		return lobSet;
	}
	/**
	 * Set httpHeaders for auto assignment NLP request
	 * @param builder
	 * @param conversation
	 * @param httpHeadersParamMap 
	 */
	public static void setAutoAssignedFwdHeader(BoundRequestBuilder builder, Conversation conversation, Map<String, Object> httpHeadersParamMap) {
		if (null != conversation) {
			if (("New Inquiry").equalsIgnoreCase(conversation.getAction())) {
				String action = "NEW";
				builder.setHeader(NLPConstants.NLP_CLIENT_CONVERSATION_TYPE, action);
				httpHeadersParamMap.put(NLPConstants.NLP_CLIENT_CONVERSATION_TYPE, action);
			} else if (null != conversation.getAction()) {
				String action = "REPLY";
				builder.setHeader(NLPConstants.NLP_CLIENT_CONVERSATION_TYPE, action);
				httpHeadersParamMap.put(NLPConstants.NLP_CLIENT_CONVERSATION_TYPE, action);
			}
			builder.setHeader(NLPConstants.NLP_CLIENT_CONVERSATION_ID, conversation.getId());
			builder.setHeader(NLPConstants.NLP_CLIENT_CASE_ID, conversation.getInquiryId());
			httpHeadersParamMap.put(NLPConstants.NLP_CLIENT_CONVERSATION_ID, conversation.getId());
			httpHeadersParamMap.put(NLPConstants.NLP_CLIENT_CASE_ID, conversation.getInquiryId());
		}
	}
	/**
	 * This method closes client connection
	 * @param client
	 * @param logger
	 */
	protected static void closeConnection(AsyncHttpClient client,String clientReqId) {
		try {
			if(client != null) {
				client.close();
			}
		} catch (IOException e) {
			logger.error("Error while closing asynch client connection for clientReqId : " + clientReqId, e );
		}
	}


	/**
	 * This creates StringPart for the request
	 * @param requestBodyContent
	 * @return StringPart
	 */
	public static StringPart generateContentBodyPart(BasicDBObject requestBodyContent) {
		StringPart part = null;
		if(requestBodyContent!=null && StringUtils.isNotEmpty(requestBodyContent.toJson())){
			part = new StringPart(NLPConstants.BODY_KEY, requestBodyContent.toJson(),ContentType.APPLICATION_JSON.getMimeType(), Charset.forName(NLPConstants.UTF_8_CHARACTERSET), NLPConstants.IGNORED_STRING_KEY);
		}
		return part;
	}

	/**
	 * This method collects all the attachment body part(s)
	 * @param attachments
	 * @param requestBodyContent
	 * @param logger
	 * @return List<FilePart>
	 */
	public static List<FilePart> generateAttachmentBodyParts(List<Map<String, Object>> attachments, BasicDBObject requestBodyContent) {
		BasicDBList excludedAttachment = new BasicDBList();
		BasicDBObject totalSize = new BasicDBObject();
		totalSize.put(NLPConstants.TOTAL_KEY, 0);
		List<FilePart> fileParts = new ArrayList<>();
		try {
			if (attachments != null && !attachments.isEmpty()) {
				processAttachments(attachments, excludedAttachment, totalSize, fileParts);
				if(!fileParts.isEmpty()) {
					logger.info("No of attachment added as a part along with request are : " + fileParts.size());
				}
			}
			if(!excludedAttachment.isEmpty()){
				requestBodyContent.put(NLPConstants.EXCLUDED_ATTACHMENTS_KEY, excludedAttachment);
				logger.info("Adding all excluded attachment to request body");
			}
		} catch (Exception e) {
			logger.error("Exception while processing attachments",e);
		}
		
		return fileParts;
	}

	/**
	 * This method iterates over each attachment and figure out if it's supported attachment. If attachment is 
	 * supported then it creates FilePart for that attachment and adds it to list of FileParts
	 * @param attachments
	 * @param excludedAttachment
	 * @param totalSize
	 * @param fileParts
	 * @param logger
	 */
	private static void processAttachments(List<Map<String, Object>> attachments, BasicDBList excludedAttachment,
			BasicDBObject totalSize, List<FilePart> fileParts) {
		for (Map<String, Object> attachment : attachments)  {
			String fileType = (String)attachment.get(NLPConstants.FILE_TYPE_KEY);
			Long fileSize = (Long)attachment.get(NLPConstants.FILE_SIZE_KEY);
			if(fileType!=null && fileSize!=null && isAttachmentSupported(attachment,totalSize,excludedAttachment) ) {
				File file = (File) attachment.get(NLPConstants.FILE_OBJECT_KEY);
				String fileName = (String)attachment.get(NLPConstants.FILE_NAME_KEY);
				if(fileName.contains("@")){
					fileName = fileName.substring(0, fileName.indexOf('@'));
				}
				FilePart filePart = new FilePart(NLPConstants.ATTACHMENTS_KEY, file, "*",  null, fileName);
				fileParts.add(filePart);
				logger.info("Attachment added as part in the list of all parts for file :" + fileName);
			}
		}
	}
	
	/**
	 * This method checks whether attachment is supported or not
	 * @param attachment
	 * @param totalSize
	 * @param excludedAttachment
	 * @param logger
	 * @return boolean
	 */
	private static boolean isAttachmentSupported(Map<String, Object> attachment, BasicDBObject totalSize, BasicDBList excludedAttachment) {
		boolean isAttachmentSupportedFlag = false;
		try {
			String fileType = (String)attachment.get(NLPConstants.FILE_TYPE_KEY);
			Long fileSize = (Long)attachment.get(NLPConstants.FILE_SIZE_KEY);
			int currentFileSize = fileSize.intValue();
			Integer allowedFileSizeObj = (Integer)nlpConfig.get(NLPConstants.NLP_MAX_SIZE_SINGLE_KEY);
			int allowedFileSize = 0;
			if(allowedFileSizeObj !=null){
				allowedFileSize = allowedFileSizeObj.intValue();
			}
			currentFileSize = currentFileSize/NLPConstants.BYTE_TO_KB;
			String fileName = (String)attachment.get(NLPConstants.FILE_NAME_KEY);
			/*FileType and fileName is corrected below because in MongoDB when in-line file is saved in database it's name gets saved 
			 * something as image001.png@01D41454.9D10F690 and it's file type something as 9D10F690 */
			if(SUPPORTED_ATTACHMENTS != null  && !SUPPORTED_ATTACHMENTS.contains(fileType.trim()) && ( fileName.indexOf('.') < fileName.indexOf('@') )){
				fileType = fileName.substring(fileName.indexOf('.')+1, fileName.indexOf('@'));
				fileName = fileName.substring(0,fileName.indexOf('@'));
			}
			int currentTotalSize = totalSize.getInt(NLPConstants.TOTAL_KEY);
			int newCurrentTotal = currentTotalSize + currentFileSize;
			totalSize.put(NLPConstants.TOTAL_KEY, newCurrentTotal);
			if( SUPPORTED_ATTACHMENTS != null && SUPPORTED_ATTACHMENTS.contains(fileType.trim()) &&  currentFileSize <= allowedFileSize ) {
				if(newCurrentTotal <= NLPConstants.MAX_ATTACHMENT_SIZE_TOTAL) {
					isAttachmentSupportedFlag = true;
					logger.info(" Filename :" + fileName + ", fileSize(KB) :" + currentFileSize + ", fileType :" + fileType + ":: Attachment Supported !!");
				} else {
					logger.info("Total size of all attachment(" + fileName + ") exceeded (" + newCurrentTotal + ") than allowed size ( " + NLPConstants.MAX_ATTACHMENT_SIZE_TOTAL + " ), hence excluding the attachment.");
					addExcludedAttachment(excludedAttachment, fileName, fileType, currentFileSize, NLPConstants.ATTACHMENT_SIZE_TOTAL_LARGE);
				}
			} else {
				checkExclusionForAttachment(excludedAttachment, fileType, currentFileSize,
						allowedFileSize, fileName);
			}
		} catch (Exception e) {
			logger.error("Exception while checking attachment supported or not :", e);
		}
		
		return isAttachmentSupportedFlag;
	}
	/**
	 * This method checks exclusion type for attachment
	 * @param excludedAttachment
	 * @param logger
	 * @param fileType
	 * @param fileSize
	 * @param currentFileSize
	 * @param allowedFileSize
	 * @param fileName
	 */
	private static void checkExclusionForAttachment(BasicDBList excludedAttachment, String fileType, 
			int currentFileSize, int allowedFileSize, String fileName) {
		String cause = "";
		if( SUPPORTED_ATTACHMENTS != null && !SUPPORTED_ATTACHMENTS.contains(fileType.trim()) ){
			cause = NLPConstants.ATTACHMENT_NOT_SUPPORTED;
		} else if(currentFileSize > allowedFileSize){
			cause = NLPConstants.ATTACHMENT_TOO_LARGE;
		}
		addExcludedAttachment(excludedAttachment,fileName, fileType, currentFileSize, cause);
	}
	/**
	 * This method adds excluded attachment to the excluded attachment list
	 * @param attachment
	 * @param excludedAttachment
	 * @param logger
	 * @param fileType
	 * @param fileSize
	 * @param currentFileSize
	 * @param allowedFileSize
	 */
	private static void addExcludedAttachment( BasicDBList excludedAttachment, String fileName,
			 String fileType, int fileSize, String cause) {
		BasicDBObject exAttachment = new BasicDBObject();
		exAttachment.put(NLPConstants.EX_FILE_NAME_KEY, fileName);
		exAttachment.put(NLPConstants.FILE_EXTENSION_KEY, fileType);
		exAttachment.put(NLPConstants.FILE_SIZE_KEY, fileSize);
		exAttachment.put(NLPConstants.EXCLUSION_CAUSE_KEY, cause);
		excludedAttachment.add(exAttachment);
		logger.info("Attachment Not Supported : " + fileName + "(" + cause + "). Added to exclusion list !!");
	}

	/**
	 * This method gets updated data for supported attachments from database
	 * @param logger
	 */
	private static void updateSupportedAttachments(){
		
		try {
			if( SUPPORTED_ATTACHMENTS == null || SUPPORTED_ATTACHMENTS.isEmpty()) {
				List<String> supportedAttachments = (List<String>)nlpConfig.get(NLPConstants.NLP_SUPPORTED_ATTACHMENTS_KEY);
				if(supportedAttachments!=null && !supportedAttachments.isEmpty()){
					SUPPORTED_ATTACHMENTS = supportedAttachments;
				}
			}
			
			if( NLPConstants.MAX_ATTACHMENT_SIZE_SINGLE == 0 ) {
				Integer maxAttachmentSizeSingle = (Integer)nlpConfig.get(NLPConstants.NLP_MAX_SIZE_SINGLE_KEY);
				if(maxAttachmentSizeSingle!=null && maxAttachmentSizeSingle > 0){
					NLPConstants.MAX_ATTACHMENT_SIZE_SINGLE = maxAttachmentSizeSingle.intValue();
				}
			}
			
			if( NLPConstants.MAX_ATTACHMENT_SIZE_TOTAL == 0 ) {
				Integer maxAttachmentSizeTotal = (Integer)nlpConfig.get(NLPConstants.NLP_MAX_SIZE_TOTAL_KEY);
				if(maxAttachmentSizeTotal!=null && maxAttachmentSizeTotal > 0 ){
					NLPConstants.MAX_ATTACHMENT_SIZE_TOTAL = maxAttachmentSizeTotal.intValue();
				}
			}
		} catch (Exception e) {
			logger.error("Error while initializing supported attachments : ",e);
		}
		
	}

	
	/**
	 * This method generates/provides asynchronous HTTP client for making asynchronous calls
	 * @param logger
	 * @return AsyncHttpClient
	 */
	public static AsyncHttpClient getAsyncHttpClient() {
		AsyncHttpClient httpAsyncHttpClient = null;
    	try {
    		DefaultAsyncHttpClientConfig.Builder clientBuilder = Dsl.config().setConnectTimeout(NLPConstants.TIMEOUT_IN_MILLI);
    		httpAsyncHttpClient = Dsl.asyncHttpClient(clientBuilder);
        	updateSupportedAttachments();
		} catch (Exception e) {
			logger.error("Error while initializing asynch-http-client : ", e);
		}
        return httpAsyncHttpClient;
    }

	/**
	 * This method provides nlp host url
	 * @param tradeRefList 
	 * @param logger
	 * @return
	 */
	private static String getNLPHostURL(String nlpRequestType, List<String> tradeRefList) {
		String nlpHostUrl = NLPConstants.HOST_BASE_URL_DEV.concat(":").concat(NLPConstants.HOST_PORT_DEV).concat(NLPConstants.INTERNAL_SERVICE_URL); 
		if(nlpConfig !=null && null != nlpConfig.get(NLPConstants.NLP_HOST_URL_CONFIG_KEY)){
			nlpHostUrl = (String)nlpConfig.get(NLPConstants.NLP_HOST_URL_CONFIG_KEY);
		}
		if(nlpConfig !=null && null != (NLPRequestType.C.name().equals(nlpRequestType)?nlpConfig.get(NLPConstants.NLP_HOST_URL_CONFIG_KEY):nlpConfig.get(NLPConstants.NLP_HOST_SETTS_URL_CONFIG_KEY))){
			nlpHostUrl = (String)(NLPRequestType.C.name().equals(nlpRequestType)?nlpConfig.get(NLPConstants.NLP_HOST_URL_CONFIG_KEY):nlpConfig.get(NLPConstants.NLP_HOST_SETTS_URL_CONFIG_KEY));
		}
		if(null != tradeRefList && nlpConfig !=null && null != nlpConfig.get(NLPConstants.NLP_HOST_URL_CONFIG_KEY_REFRESH_API)) {
			nlpHostUrl = (String)nlpConfig.get(NLPConstants.NLP_HOST_URL_CONFIG_KEY_REFRESH_API);
		}
		logger.info("NLP HOST URL is : " + nlpHostUrl);
		return nlpHostUrl;
	}

	/**
	 * This method provides qma callback url
	 * @param logger
	 * @return
	 */
	public static String getQMAServiceURL() {
		String qmaCallbackUrl = NLPConstants.QMA_BASE_URL_DEV.concat(":").concat(NLPConstants.QMA_PORT_DEV).concat(NLPConstants.QMA_INTERNAL_SERVICE_URL); 
		if(nlpConfig !=null && null != nlpConfig.get(NLPConstants.QMA_CALLBACK_URL_CONFIG_KEY)){
			qmaCallbackUrl = (String)nlpConfig.get(NLPConstants.QMA_CALLBACK_URL_CONFIG_KEY);
		}
		//qmaCallbackUrl = "http://10.108.144.179:8080/QMA/rest/qmanlp/sugessioncallback";
		logger.info("QMA Callback URL is : " + qmaCallbackUrl);
		return qmaCallbackUrl;
	}
	
	
	/**
	 * This method provides URL Encoded string for the given string
	 * @param inputString
	 * @param logger
	 * @return String
	 */
	public static String getUrlEncodedString(String inputString) {
		String outputString = "";
		try {
			outputString =  URLEncoder.encode(inputString,NLPConstants.UTF_8_CHARACTERSET);
		} catch (UnsupportedEncodingException e) {
			logger.error("Unable to encode provided String :" + e);
			outputString = inputString;
		}
		return outputString;
	}
	public static String getFirstNonCitiFromClientDetails(String clientRequestId, String actionBy, String content) {
		String nonCitiEmail = null;
		try {
			String end = StringUtils.substringBefore(content, "Sent:");
			String emailFromHeader = StringUtils.isNotBlank(end) ? StringUtils.substringAfter(end, "From:") : null;
			logger.info("getFirstNonCitiFromClientDetails for clientRequestId : " + clientRequestId
					+ " emailFromHeader " + emailFromHeader + " latestActionBy : " + " emailFromHeader " + actionBy);
			String firstEmail = null;
			if (StringUtils.isNotBlank(emailFromHeader)) {
				Pattern p = Pattern.compile("\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}\\b", Pattern.CASE_INSENSITIVE);
				Matcher matcher = p.matcher(emailFromHeader);

				if (matcher.find()) {
					firstEmail = matcher.group();

				}

				if (StringUtils.isNotBlank(firstEmail) && !GenericUtility.isCitiDomainEmail(firstEmail)) {
					nonCitiEmail = firstEmail;
				}
			}
			logger.info("getFirstNonCitiFromClientDetails for clientRequestId : " + clientRequestId
					+ " emailFromHeader " + emailFromHeader + " latestActionBy : " + " emailFromHeader " + actionBy
					+ " firstEmail : " + firstEmail + "nonCitiEmail :" + nonCitiEmail);
		} catch (Exception e) {
			logger.error(" Error while getFirstNonCitiFromClientDetails for client id (" + clientRequestId + ") : ", e);
		}
		return nonCitiEmail;
	}
	/**
	 * Get email domain from email
	 * @param email
	 * @return
	 */
	public static String getEmailDomain(String email)
	{
		String domain="";
		if(StringUtils.isNotBlank(email) && email.indexOf("@")>-1) {
			String[] parts = email.split("@");
			domain= parts[parts.length - 1].toUpperCase();
		}
		return domain;
	}
}
