package com.citi.icg.qma.common.server.utilCMCPayload;

public class Links
{
    private String srcSysId;

    private String srcSys;

    private String deleteReason;

    private String status;

    public String getSrcSysId ()
    {
        return srcSysId;
    }

    public void setSrcSysId (String srcSysId)
    {
        this.srcSysId = srcSysId;
    }

    public String getSrcSys ()
    {
        return srcSys;
    }

    public void setSrcSys (String srcSys)
    {
        this.srcSys = srcSys;
    }

    public String getDeleteReason ()
    {
        return deleteReason;
    }

    public void setDeleteReason (String deleteReason)
    {
        this.deleteReason = deleteReason;
    }

    public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }

    @Override
    public String toString()
    {
        return "InputForCMC [srcSysId = "+srcSysId+", srcSys = "+srcSys+", deleteReason = "+deleteReason+", status = "+status+"]";
    }
}
			
			