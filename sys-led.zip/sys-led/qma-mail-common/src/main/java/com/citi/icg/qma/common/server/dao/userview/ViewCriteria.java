package com.citi.icg.qma.common.server.dao.userview;

import java.util.ArrayList;
import java.util.List;

public class ViewCriteria
{

	private GroupOperator operator;
	private List<ViewCriteria> criterias = new ArrayList<ViewCriteria>();
	private List<CriteriaClause> clauses = new ArrayList<CriteriaClause>();

	public ViewCriteria(GroupOperator operator, List<ViewCriteria> criterias, List<CriteriaClause> clauses)
	{
		super();
		this.setOperator(operator);
		this.setCriterias(criterias);
		this.setClauses(clauses);
	}

	public List<CriteriaClause> getClauses() {
		return clauses;
	}

	public void setClauses(List<CriteriaClause> clauses) {
		this.clauses = clauses;
	}

	public List<ViewCriteria> getCriterias() {
		return criterias;
	}

	public void setCriterias(List<ViewCriteria> criterias) {
		this.criterias = criterias;
	}

	public GroupOperator getOperator() {
		return operator;
	}

	public void setOperator(GroupOperator operator) {
		this.operator = operator;
	}
	
}
