package com.citi.icg.qma.common.auth;

import com.citi.icg.qma.common.core.config.ConfigurationException;
import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.exception.InvalidInputException;
import com.citi.icg.qma.common.exception.QMAException;
import com.citi.icg.qma.common.exception.UnauthorizedException;
import com.citi.icg.qma.common.server.dao.*;
import com.citi.icg.qma.common.server.dao.persistence.InquiryDAO;
import com.citi.icg.qma.common.server.dao.persistence.UserDAO;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;
import dev.morphia.Datastore;
import dev.morphia.query.Query;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class AuthorizationUtility {
    private static final Logger logger = LoggerFactory.getLogger(AuthorizationUtility.class);
    private static final InquiryDAO inquiryDAO = new InquiryDAO();
    public static final UserDAO userDao = new UserDAO();

    private static final String GROUP_IDS_KEY = "groupIds";
    public static final String TYPE_GROUP_INQUIRY_ID = "1";
    public static final String TYPE_GROUP_NAME = "2";
    public static final String TYPE_GROUP_ID = "3";
    public static final String TYPE_INQUIRY_ID = "4";
    public static final String INVALID_INPUT_KEY = "Invalid Input";
    public static final String INQUIRY_ID_KEY = "inquiryId";
    public static final String GROUP_ID_KEY = "groupId";
    public static final String ACCESS_VALIDATED_MESSAGE_KEY = "User {} access validated for all groups provided.";
    public static final String UNAUTHORIZED_ACCESS_MESSAGE_KEY = "Unauthorized user access";
    private static final class InstanceHolder {
        static final AuthorizationUtility instance = new AuthorizationUtility();
    }

    public static AuthorizationUtility getInstance() {
        return InstanceHolder.instance;
    }

    private AuthorizationUtility() {
    }

    public void authorizeRequest(String soeId, String request, String paramType) throws QMAException {
        try {
            QMACache qmaCache = QMACacheFactory.getCache();
            if (Objects.nonNull(soeId) && (Objects.nonNull(qmaCache.getUserInfoMap()) && Objects.nonNull(qmaCache.getUserInfoMap().get(soeId.toUpperCase())))) {
                if (Objects.nonNull(request) && Objects.nonNull(paramType)) {
                    BasicDBObject requestObj = BasicDBObject.parse(request);
                    authorizeRequest(soeId, requestObj, paramType);
                } else {
                    throw new InvalidInputException(INVALID_INPUT_KEY);
                }
            } else {
                throw new UnauthorizedException("Invalid userId in request.");
            }
        }catch(QMAException e) {
       	 throw new QMAException(e.getMessageDetails(),e,e.getErrorCode(),e.getErrorCodeDesc());
       } 
       catch (Exception e) {
       	throw new QMAException(e);
       }
    }

    private void authorizeRequest(String soeId, BasicDBObject requestObj, String paramType) throws QMAException {
        if (TYPE_GROUP_INQUIRY_ID.equalsIgnoreCase(paramType)) {
            authorizeType1Request(soeId, requestObj);
        } else if (TYPE_GROUP_NAME.equalsIgnoreCase(paramType)) {
            authorizeType2Request(soeId, requestObj);
        } else if (TYPE_GROUP_ID.equalsIgnoreCase(paramType)) {
            authorizeType3Request(soeId, requestObj);
        } else if (TYPE_INQUIRY_ID.equalsIgnoreCase(paramType)) {
            authorizeType4Request(soeId, requestObj);
        } else {
            throw new InvalidInputException(INVALID_INPUT_KEY);
        }
    }


    /**
     * This method authorized soeId access to provided input groups in the request
     * and the input type pattern for group is : "groupIds":["18528326:53052,53051","18527830:25557"]
     * where 18528326 and 18527830 is inquiryId and  53052,53051,25557 are groups
     */
    private void authorizeType1Request(String soeId, BasicDBObject requestObj) throws QMAException {
        List<String> inputInqGrpIdList = null;

        if(requestObj.containsKey(GROUP_IDS_KEY)){
            inputInqGrpIdList =  (List<String>) requestObj.get(GROUP_IDS_KEY);
        } else  if(requestObj.containsKey("allInqGroupIds")){
            inputInqGrpIdList =  (List<String>) requestObj.get("allInqGroupIds");
        }

        Set<Long> userGroupsList = getUserGroups(soeId);

        if(Objects.nonNull(inputInqGrpIdList)){
            Map<Long, List<String>> inquiryGroupMap = getInquiryGroupMap(inputInqGrpIdList);
            if (!inquiryGroupMap.isEmpty()) {
                for (Map.Entry<Long, List<String>> inquiryList : inquiryGroupMap.entrySet()) {
                	Long inquiryId = inquiryList.getKey();
                    validateGroupIdAccessForUser(soeId, inquiryGroupMap.get(inquiryId),requestObj,userGroupsList);
                }
                logger.info(ACCESS_VALIDATED_MESSAGE_KEY, soeId);
            } else {
                throw new InvalidInputException(INVALID_INPUT_KEY);
            }
        } else {
            throw new InvalidInputException(INVALID_INPUT_KEY);
        }
    }

    /**
     * This method authorized soeId access to provided input groups in the request
     * and the input type pattern for group is : "groupName":"*ICG Global Client Inquiry UAT2"
     * where *ICG Global Client Inquiry UAT2 is user group
     */
    private void authorizeType2Request(String soeId, BasicDBObject requestObj) throws QMAException {
        List<String> fromGroupNameList;
        if (requestObj.containsKey("from")) {
            //currently, used only for /inquiry/resolveInquiry flow
            fromGroupNameList = (List<String>) requestObj.get("from");
        } else if (requestObj.containsKey("groupName")) {
            fromGroupNameList = new ArrayList<>();
            fromGroupNameList.add(requestObj.getString("groupName"));
        } else if (requestObj.containsKey("assignedGroupName")) {
            fromGroupNameList = new ArrayList<>();
            fromGroupNameList.add(requestObj.getString("assignedGroupName"));
        } else {
            throw new InvalidInputException(INVALID_INPUT_KEY);
        }

        Set<Long> userGroupsList = getUserGroups(soeId);

        if (Objects.nonNull(fromGroupNameList) && !fromGroupNameList.isEmpty()) {
            validateGroupNameAccessForUser(soeId, fromGroupNameList, requestObj, userGroupsList);
            logger.info(ACCESS_VALIDATED_MESSAGE_KEY, soeId);
        } else {
            throw new InvalidInputException(INVALID_INPUT_KEY);
        }
    }

    /**
     * This method authorized soeId access to provided input groups in the request
     * and the input type pattern for group is : "selectInqAssignedGroupId":[53051] or similar with different keys
     * where 53051 is user group
     */
    private void authorizeType3Request(String soeId, BasicDBObject requestObj) throws QMAException {
        List<Long> groupIdList;
        try {
            if (requestObj.containsKey("selectInqAssignedGroupId")) {
                // for /extInquiry/getAllInquiryConversations flow
                groupIdList = GenericUtility.getIdListFromRequest(requestObj, "selectInqAssignedGroupId");
            } else if (requestObj.containsKey(GROUP_ID_KEY)) {
                groupIdList = GenericUtility.getIdListFromRequest(requestObj, GROUP_ID_KEY);
                if(Objects.nonNull(groupIdList) && groupIdList.isEmpty()){
                    //downloadAllAttachments uses groupId=<grp_id> as params in request
                    Long grpId = requestObj.getLong(GROUP_ID_KEY);
                    if(Objects.nonNull(grpId)){
                        groupIdList.add(grpId);
                    } else {
                        throw new InvalidInputException(INVALID_INPUT_KEY);
                    }
                }
            } else {
                throw new InvalidInputException(INVALID_INPUT_KEY);
            }
        } catch (InvalidInputException e) {
            throw new QMAException(e.getMessage(),e,400,INVALID_INPUT_KEY);
        }catch (Exception e) {
            throw new QMAException(e);
        }

        Set<Long> userGroupsList = getUserGroups(soeId);

        if (null!= groupIdList && !groupIdList.isEmpty()) { //<- added null check sonar fix
            List<String> grpIdList = new ArrayList<>();
            groupIdList.forEach(item -> grpIdList.add(String.valueOf(item)));
            if (!grpIdList.isEmpty()) {
                validateGroupIdAccessForUser(soeId, grpIdList,requestObj,userGroupsList);
                logger.info(ACCESS_VALIDATED_MESSAGE_KEY, soeId);
            } else {
                throw new InvalidInputException(INVALID_INPUT_KEY);
            }
        } else {
            throw new InvalidInputException(INVALID_INPUT_KEY);
        }
    }

    private void authorizeType4Request(String soeId, BasicDBObject requestObj) throws QMAException {
        List<Long> inquiryIds = new ArrayList<>();
        try {
            if (requestObj.containsKey("id")) {
                //currently, used only for /inquiry/getWorkflowsById flow
                Long inqId = GenericUtility.getIdFromRequest(requestObj, "id");
                inquiryIds.add(inqId);
            } else if (requestObj.containsKey(INQUIRY_ID_KEY)) {
                //currently, used only for /extInquiry/notifyUserInquiry flow
                inquiryIds = GenericUtility.getIdListFromRequest(requestObj, INQUIRY_ID_KEY);
            } else {
                throw new InvalidInputException(INVALID_INPUT_KEY);
            }
        } catch (Exception e) {
            throw new QMAException(e);
        }

        Set<Long> userGroupsList = getUserGroups(soeId);

        if (!inquiryIds.isEmpty()) {
            validateUserAccessForInquiry(soeId, inquiryIds,userGroupsList);
            logger.info("User {} access validated for all inquiryId(s) provided.", soeId);
        } else {
            throw new InvalidInputException(INVALID_INPUT_KEY);
        }
    }


    private static void validateUserGroupInquiryAccess(String soeId, BasicDBObject requestObj, Set<Long> userGroupsList) throws QMAException {
        List<Long> inquiryIds = new ArrayList<>();
        try {
            if (requestObj.containsKey("id")) {
                Long inqId = GenericUtility.getIdFromRequest(requestObj, "id");
                inquiryIds.add(inqId);
            } else if (requestObj.containsKey(INQUIRY_ID_KEY)) {
                if(requestObj.get(INQUIRY_ID_KEY) instanceof List<?>) {
                    inquiryIds = GenericUtility.getIdListFromRequest(requestObj, INQUIRY_ID_KEY);
                } else {
                    Long inqId = GenericUtility.convertIdFromRequest(requestObj.get(INQUIRY_ID_KEY));
                    inquiryIds.add(inqId);
                }
            } else if (requestObj.containsKey("inquiryIds")) {
                inquiryIds = GenericUtility.getIdListFromRequest(requestObj, "inquiryIds");
            } else {
                logger.info("This request does not contains inquiry id validation");
                return;
            }
        } catch (Exception e) {
            throw new QMAException(e);
        }

        if (!inquiryIds.isEmpty()) {
            validateUserAccessForInquiry(soeId, inquiryIds,userGroupsList);
            logger.info("User {} access validated for all inquiryId(s) provided.", soeId);
        } else {
            throw new InvalidInputException(INVALID_INPUT_KEY);
        }
    }

    private static void validateUserAccessForInquiry(String soeId, List<Long> inquiryIds, Set<Long> userGroupsList) throws QMAException {
        Set<Long> userGroupsListLocal = userGroupsList;
        if(Objects.isNull(userGroupsListLocal) || userGroupsListLocal.isEmpty()){
            userGroupsListLocal = getUserGroups(soeId);
        }
        if (Objects.isNull(userGroupsListLocal) || userGroupsListLocal.isEmpty()) {
            throw new QMAException("User access can not be verified");
        }
        for (Long id : inquiryIds) {
            try {
                Inquiry inquiryObj = inquiryDAO.getInquiryById(id);
                if(Objects.nonNull(inquiryObj) && Objects.nonNull(inquiryObj.getWorkflows()) && !inquiryObj.getWorkflows().isEmpty()){
                    validateUserInquiryAccess(userGroupsListLocal,inquiryObj.getWorkflows());
                } else {
                    throw new InvalidInputException(INVALID_INPUT_KEY);
                }
            } catch (Exception e) {
                throw new QMAException(e);
            }
        }
    }

    private static Set<Long> getUserGroups(String soeId) throws QMAException {
        Set<Long> userGroupsList = null;
        User user = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase());
        if (null != user ) {
            try {
                /* Already existing function to get all assigned groups of user which fetches data from HazelCast Cache */
                userGroupsList = userDao.getUserGroupsList(user);
            } catch (Exception e) {
                throw new QMAException(e);
            }
        } else {
            logger.warn("User {} information can not be verified.",soeId);
        }
        return userGroupsList;
    }

    private static void validateUserInquiryAccess(Set<Long> userGroupsList, List<Workflow> workflows) throws QMAException {
        boolean userHaveWorkflowForInquiry = false;
        for(Workflow workflow : workflows){
            if(Objects.nonNull(workflow.getAssignedGroupId()) && userGroupsList.contains(workflow.getAssignedGroupId())){
                userHaveWorkflowForInquiry = true;
                break;
            }
        }
        if(!userHaveWorkflowForInquiry){
            throw new UnauthorizedException(UNAUTHORIZED_ACCESS_MESSAGE_KEY);
        }
    }

    private void validateGroupIdAccessForUser(String soeId, List<String> groups,BasicDBObject requestObj, Set<Long> userGroupsList) throws QMAException {
        for (String groupId : groups) {
            try {
                if (!isUserEntitledForGroupAndOrInquiry(soeId, groupId,requestObj,userGroupsList)) {
                    throw new UnauthorizedException(UNAUTHORIZED_ACCESS_MESSAGE_KEY);
                }
            } catch (Exception e) {
                throw new QMAException(e);
            }
        }
    }

    private void validateGroupNameAccessForUser(String soeId, List<String> groupNameList,BasicDBObject requestObj, Set<Long> userGroupList) throws QMAException {
        try {
            for(String groupName : groupNameList){
                Long groupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
                if (Objects.nonNull(groupId)) {
                    if (!isUserEntitledForGroupAndOrInquiry(soeId, String.valueOf(groupId),requestObj,userGroupList)) {
                        throw new UnauthorizedException(UNAUTHORIZED_ACCESS_MESSAGE_KEY);
                    }
                } else {
                    throw new InvalidInputException(INVALID_INPUT_KEY);
                }
            }
        } catch (Exception e) {
            throw new QMAException(e);
        }
    }

    private Map<Long, List<String>> getInquiryGroupMap(List<String> inputInqGrpIdList) throws QMAException {
        Map<Long, List<String>> inquiryGroupMap;
        if (Objects.nonNull(inputInqGrpIdList) && !inputInqGrpIdList.isEmpty()) {
            Map<Long, List<String>> updatedMap = new HashMap<>();
            inputInqGrpIdList.forEach(inqGrpString -> {
               
                    try {
						prepareInquiryGroupMap(updatedMap, inqGrpString);
					} catch (QMAException e) {
						throw new ConfigurationException(e);
					}
            });
            inquiryGroupMap = updatedMap;
        } else {
            throw new InvalidInputException(INVALID_INPUT_KEY);
        }
        return inquiryGroupMap;
    }

    private void prepareInquiryGroupMap(Map<Long, List<String>> updatedMap, String inqGrpString) throws QMAException {
        String[] inqGrpArr = inqGrpString.split(":");
        if (inqGrpArr.length == 2) {
            Long inqId = Long.parseLong(inqGrpArr[0]);
            List<String> grpIds = Arrays.asList(inqGrpArr[1].split(","));
            updatedMap.put(inqId, grpIds);
        } else {
            throw new InvalidInputException(INVALID_INPUT_KEY);
        }
    }

    public static boolean isUserEntitledForGroupAndOrInquiry(String soeId, String groupId, BasicDBObject requestObj, Set<Long> userGroupsList) throws QMAException {
        boolean userEntitled = false;
        if(StringUtils.isNotEmpty(soeId) && StringUtils.isNotEmpty(groupId)) {
            Long grpId = Long.parseLong(groupId);
            if( null != userGroupsList && !userGroupsList.isEmpty() && userGroupsList.contains(grpId) ) {
                if(Objects.nonNull(requestObj)){
                    validateUserGroupInquiryAccess(soeId,requestObj,userGroupsList);
                }
                userEntitled = true;
            } else {
                logger.warn("User ({}) does not belongs to the group ({}) ", soeId, groupId);
            }
        } else {
            logger.warn("Invalid soeId or group Id provided for validation");
        }

        return userEntitled;
    }

    public static boolean validateUserDownloadRequest(String soeId, String docId, String convId, String groupId, String ownershipNomination, Datastore dataStore) throws QMAException {
        boolean validDownloadRequest = false;
        try {
            if(StringUtils.isNotEmpty(groupId)){
                validDownloadRequest = isValidConvDownloadRequestInlineImage(soeId,  convId, groupId, ownershipNomination, dataStore);
            } else {
                validDownloadRequest = isValidDraftDownloadRequest(soeId,docId, convId,dataStore);
            }
        } catch (Exception e) {
            throw new QMAException(e);
        }
        return validDownloadRequest;
    }

    public static boolean validateUserDownloadRequest(String soeId, String docId, String convId, Datastore dataStore) throws QMAException {
        boolean validDownloadRequest = false;
        try {
            validDownloadRequest = isValidDraftDownloadRequest(soeId,docId, convId,dataStore);
        } catch (Exception e) {
            throw new QMAException(e);
        }
        return validDownloadRequest;
    }

    public static boolean validateUserDownloadRequestInlineImage(String soeId,String docId, String convId, String groupId, String ownershipNomination, Datastore dataStore) throws QMAException {
        boolean validDownloadRequest = false;
        try {
                validDownloadRequest = isValidConvDownloadRequestInlineImage( soeId, convId, groupId, ownershipNomination, dataStore);
        } catch (Exception e) {
            throw new QMAException(e);
        }
        return validDownloadRequest;
    }

    private static boolean isValidConvDownloadRequestInlineImage(String soeId, String convId, String groupId, String ownershipNomination, Datastore dataStore) throws QMAException, CommunicatorException {
        boolean validDownloadRequest = false;
            Boolean hasOwnerShipNomination = Boolean.parseBoolean(ownershipNomination);
            Set<Long> userGroupsList = getUserGroups(soeId);
            if (isUserEntitledForGroupAndOrInquiry(soeId, groupId,null,userGroupsList)) {
                logger.info("User-Group authentication successful. Checking Conversation.");
             
            Conversation conv = getConversationForUserGroupForInlineImage(dataStore, convId, groupId,hasOwnerShipNomination);
            if( null != conv ) {
                    validDownloadRequest = true;
            } 
          }
        return validDownloadRequest;
    }

    private static boolean isValidDraftDownloadRequest(String soeId, String docId, String draftIdStr, Datastore dataStore) throws QMAException {
        boolean validDownloadRequest = false;
        if(StringUtils.isNotEmpty(soeId) && StringUtils.isNotEmpty(draftIdStr) && null!= dataStore){
            Long draftId = Long.parseLong(draftIdStr);
            Query<Draft> draftQuery = dataStore.createQuery(Draft.class).filter("_id", draftId).filter("userId",soeId);
            Draft draft = draftQuery.first();
            if(draft != null){
                if(StringUtils.isNotEmpty(docId)){
                    validDownloadRequest = validateDocIdForDraft(docId,draft);
                } else {
                    validDownloadRequest=true;
                }

            }
        } else {
            throw  new InvalidInputException(INVALID_INPUT_KEY);
        }
        return validDownloadRequest;
    }

    private static boolean validateDocIdForConversation(String docId, Conversation conv) throws CommunicatorException  {
        boolean isDocIdExistsInConversation = false;
        try {
            if(Objects.nonNull(conv.getAttachments()) && !conv.getAttachments().isEmpty()) {
                for(Attachment attachment : conv.getAttachments()){
                    if(Objects.nonNull(attachment) && Objects.nonNull(attachment.getId()) && attachment.getId().equalsIgnoreCase(docId)){
                        isDocIdExistsInConversation = true;
                        break;
                    }
                }
                logger.info("'isDocIdExistsInConversation' identified as : {}",isDocIdExistsInConversation);
            } else {
                logger.info("No attachments for this conversation.");
            }
        } catch (Exception e){
          logger.warn("Exception while validating docId : {} for conversation : {} ", docId, conv.getId());
          throw new CommunicatorException("Exception while validating docId : "+docId + "for conversation : " + conv.getId());
        }
        if(!isDocIdExistsInConversation){
            throw new CommunicatorException("Invalid user download request");
        }
        return isDocIdExistsInConversation;
    }


    private static boolean validateDocIdForDraft(String docId, Draft draft) throws QMAException  {
        boolean isDocIdExistsInDraft = false;
        try {
            if(Objects.nonNull(draft.getAttachments()) && !draft.getAttachments().isEmpty()) {
                for(Attachment attachment : draft.getAttachments()){
                    if(Objects.nonNull(attachment) && Objects.nonNull(attachment.getId()) && attachment.getId().equalsIgnoreCase(docId)){
                        isDocIdExistsInDraft = true;
                        break;
                    }
                }
                logger.info("'isDocIdExistsInDraft' identified as : {}",isDocIdExistsInDraft);
            } else {
                logger.info("No attachments for this draft.");
            }
        } catch (Exception e){
            logger.warn("Exception while validating docId : {} for draft : {} ", docId, draft.getId());
            throw e;
        }
        if(!isDocIdExistsInDraft){
            throw new QMAException("Invalid user download request");
        }
        return isDocIdExistsInDraft;
    }


    private static Conversation getConversationForUserGroup(Datastore dataStore,String convIdStr, String groupIdStr, Boolean hasOwnerShipNomination) throws QMAException {
        Conversation conv = null;
        Long convId = Long.parseLong(convIdStr);
        Long groupId = Long.parseLong(groupIdStr);
        logger.info(" File Download for convId : {}, groupID : {}, hasOwnerShipNomination : {} ",convId,groupId, hasOwnerShipNomination);
        if( null != convId && null != groupId && null != hasOwnerShipNomination) {
            List<Long> grpIdList = new ArrayList<>();
            grpIdList.add(groupId);
            Query<Conversation> query = dataStore.createQuery(Conversation.class);
            query.criteria("_id").equal(convId);
            if(hasOwnerShipNomination){
                query.criteria("nominatedRecipients.groupId").in(grpIdList);
            } else {
                query.criteria("recipients.groupId").in(grpIdList);
            }
            query.project("attachments", true);
            conv = query.first();
        } else {
            throw new QMAException("Conversation not found for the download.");
        }
        return conv;
    }
    
    private static Conversation getConversationForUserGroupForInlineImage(Datastore dataStore,String convIdStr, String groupIdStr, Boolean hasOwnerShipNomination) throws QMAException {
        Conversation conv = null;
        Long convId = Long.parseLong(convIdStr);
        Long groupId = Long.parseLong(groupIdStr);
        logger.info(" File Download for convId : {}, groupID : {}, hasOwnerShipNomination : {} ",convId,groupId, hasOwnerShipNomination);
        if( null != convId && null != groupId && null != hasOwnerShipNomination) {
            List<Long> grpIdList = new ArrayList<>();
            grpIdList.add(groupId);
            Query<Conversation> query = dataStore.createQuery(Conversation.class);
            query.criteria("_id").equal(convId);
            if(hasOwnerShipNomination){
                query.criteria("nominatedRecipients.groupId").in(grpIdList);
            } else {
                query.criteria("recipients.groupId").in(grpIdList);
            }
            conv = query.first();
        } else {
            throw new QMAException("Conversation not found for the download.");
        }
        return conv;
    }
}
