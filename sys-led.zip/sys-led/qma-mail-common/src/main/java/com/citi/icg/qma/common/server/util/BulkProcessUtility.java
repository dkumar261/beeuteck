package com.citi.icg.qma.common.server.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.ResponseBuilder;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.GFCId;
import com.citi.icg.qma.common.server.dao.GFPIDMapping;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.HierarchyUserDetail;
import com.citi.icg.qma.common.server.dao.HighlevelRequestType;
import com.citi.icg.qma.common.server.dao.ManagementHeirarchy;
import com.citi.icg.qma.common.server.dao.persistence.GenericDAO;
import com.citi.icg.qma.common.server.dao.persistence.GroupDAO;
import com.citi.icg.qma.common.server.dao.persistence.MongoMorphiaDAO;
import com.citi.icg.qma.common.server.dao.persistence.UserDAO;
import com.citi.icg.qma.common.transferobject.UserTO;
import com.mongodb.AggregationOptions;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;

import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

/**
 * 
 *
 */
public class BulkProcessUtility extends MongoMorphiaDAO {

	private static final Logger subLogger = LoggerFactory.getLogger(BulkProcessUtility.class);
	private GroupDAO groupDAO = new GroupDAO();
	private UserDAO userDAO = new UserDAO();
	private GenericDAO genericDAO = new GenericDAO();

	public static final String EXCEL_COLUMN_SEPARATOR = "\\|";
	public static final String EXCEL_COLUMN_MULTI_VALUE_SEPARATOR = "~";
	private static final String VALID_GROUPS_KEY = "validGrps";
	private static final String INVALID_GROUPS_KEY = "invalidGrps";
	private static final String VALID_GFCID_KEY = "validGfcid";
	private static final String INVALID_GFCID_KEY = "invalidGfcid";
	private static final String VALID_RTM_KEY = "validRtm";
	private static final String INVALID_RTM_KEY = "invalidRtm";
	private static final String GROUP_NAME_KEY = "groupName";
	private static final String ONBOARDED_KEY = "onboarded";
	private static final String NON_ONBOARDED_KEY = "notOnboarded";
	private static final String ONBOARDING_RESULT_KEY = "onboardingResult";
	private static final String GROUP_EMAIL_KEY = "email";
	private static final String ADMIN_USER = "adminUser";
	private static final String GROUP_NEW_TO_ADD_KEY = "isNewlyAdded";
	private static final String GFCID_KEY = "gfcid";
	private static final String GFPID_KEY = "gfpid";
	private static final String GFCID_NAME_KEY = "gfcidName";
	private static final String GFPID_NAME_KEY = "gfpidName";
	private static final String BUSINESS_UNIT = "bu";
	private static final String FIRST_LEVEL_HRCHY = "flh";
	private static final String SECOND_LEVEL_HRCHY = "slh";
	private static final String ORGANIZATION_KEY = "organisation";
	private static final String USERNAME_KEY = "userName";
	private static final String USERID_KEY = "userId";
	private static final String FLH_KEY = "firstLevelHeirarchy";
	private static final String SLH_KEY = "secondLevelHeirarchy";
	private static final String TLH_KEY = "thirdLevelHeirarchy";
	private static final String HDATA_KEY = "heirarchyData";
	private static final String IS_INACTIVE_KEY = "isInactive";
	private static final String VALIDATION_FAILURE_KEY = "validationFailure";
	private static final String INVALID_MAIL_ID = "Invalid DL Email Address.";
	private static final String INVALID_ADMIN_USERS = "Invalid list of Group Admin user(s).";
	private static final String INVALID_ORG = "Invalid Organization.";
	private static final String INVALID_FLH_DATA = "Invalid Senior Manager (MD Level).";
	private static final String INVALID_SLH_DATA = "Invalid Senior Group Manager (Director Level).";
	private static final String INVALID_TLH_DATA = "Invalid Group Manager.";
	private static final String INCOMPLETE_GROUP_DETAILS = "Incomplete Group Details.";
	private static final String INCOMPLETE_GFCID_DETAILS = "Incomplete data at index ";
	private static final String INVALID_GFPID = "Invalid GFPID at line no ";
	private static final String INVALID_GFCID = "Invalid GFCID at line no ";
	private static final String INVALID_GFPID_NAME = "Invalid GFPID Name at line no ";
	private static final String INVALID_GFCID_NAME = "Invalid GFCID Name at line no ";
	private static final String UNKNOWN_GROUP_DETAILS = "Incomplete group data at line no ";
	private static final String GFPID_EXISTS = "GFPID already exists in database at line no ";
	private static final String GFCID_EXISTS = "GFCID already exists in database at line no ";
	private static final String NEW_INSERT_KEY = "newInsertedRecords";
	private static final String ALREADY_EXISTS_KEY = "recordsAlreadyExists";
	private static final String VALIDATION_DATALIST_KEY = "validationDataList";
	private static final String SUCCESS_KEY = "success";
	private static final String MESSAGE_KEY = "message";
	private static final String INVALID_FILE_CONTENTS_MESSAGE = "Invalid File Contents.";
	private static final String SUCCESS_MESSAGE = "File processed successfully.";
	private static final String GROUP_UPLOAD_TYPE = "groupData";
	private static final String GFCID_UPLOAD_TYPE = "gfcidData";
	private static final String RTM_UPLOAD_TYPE = "rtmData";
	private static final String GFCID_BACKUP_COLLECTION_NAME = "GFPIDMapping_backup";
	private static final String GFPC_ID_RECORD_ADDED = "Record Added/Updated in database at line no ";
	private static final String GFPC_ID_RECORD_EXISTS = "Record already present in database at line no ";
	private static final String INDEX_KEY = "index";
	private static final int NO_OF_COLS_FOR_GROUP_FILE = 7;
	private static final int NO_OF_COLS_FOR_GFCID_FILE = 4;
	private static final int NO_OF_COLS_FOR_RTM_FILE = 3;
	private static final int GROUP_NAME_INDEX = 0;
	private static final int GROUP_EMAIL_INDEX = 1;
	private static final int GROUP_ORG_INDEX = 2;
	private static final int GROUP_FLH_INDEX = 3;
	private static final int GROUP_SLH_INDEX = 4;
	private static final int GROUP_TLH_INDEX = 5;
	private static final int GROUP_ADMIN_INDEX = 6;
	private static final int GFPID_INDEX = 0;
	private static final int GFPID_NAME_INDEX = 1;
	private static final int GFCID_INDEX = 2;
	private static final int GFCID_NAME_INDEX = 3;
	private static final int RTM_GROUP_NAME_INDEX = 0;
	private static final int RTM_REQUEST_TYPE_INDEX = 1;
	private static final int RTM_HIGH_LEVEL_RT_INDEX = 2;
	private static final String TEMPLATE_TYPE_GROUP = "group";
	private static final String TEMPLATE_TYPE_GFPCID = "gfpcid";
	private static final String TEMPLATE_TYPE_RTM = "rtm";
	private static final String GROUP_TEMPLATE_FILENAME = "templates/Group_Setup_Template.csv";
	private static final String GFPCID_TEMPLATE_FILENAME = "templates/Gfpcid_Setup_Template.csv";
	private static final String RTM_TEMPLATE_FILENAME = "templates/Rtm_Setup_Template.csv";
	private static final String DEFAULT_FILE_NAME = "Template.csv";
	private static final String GFPID_FILE_HEADER = "GFPID";
	private static final String GFPID_NAME_FILE_HEADER = "GFPID NAME";
	private static final String GFCID_FILE_HEADER = "GFCID";
	private static final String GFCID_NAME_FILE_HEADER = "GFCID NAME";
	private static final String RTM_GROUP_NAME_FILE_HEADER = "Group Name";
	private static final String RTM_HIGH_LEVEL_RT_FILE_HEADER = "High Level Request Type";
	private static final String RTM_REQUEST_TYPE_FILE_HEADER = "Request Type";
	private static final String RTM_HIGH_LEVEL_RT_KEY = "highLevelRequestType";
	private static final String RTM_REQUEST_TYPE_KEY = "requestType";
	private static final String INVALID_MAPPING_NAME = "Invalid request type mapping at line no ";
	
	// C170665-10 | Group Bulk upload for Request Type - Root Cause Mapping.
	private static final int NO_OF_COLS_FOR_RTRCM_FILE = 3;
	private static final int RTRCM_GROUP_NAME_INDEX = 0;
	private static final int RTRCM_REQUEST_TYPE_INDEX = 1;
	private static final int RTRCM_ROOT_CAUSE_INDEX = 2;
	private static final String RTRCM_UPLOAD_TYPE = "rtrcmData";
	private static final String VALID_RTRCM_KEY = "validRtRcm";
	private static final String INVALID_RTRCM_KEY = "invalidRtRcm";
	private static final String RTRCM_GROUP_NAME_FILE_HEADER = "Group Name";
	private static final String RTRCM_REQUEST_TYPE_FILE_HEADER = "Request Type";
	private static final String RTRCM_ROOT_CAUSE_FILE_HEADER = "Root Cause";
	private static final String RTRCM_ROOT_CAUSE_KEY = "rootCause";
	private static final String INVALID_REQUEST_TYPE = "Invalid request type at line no ";
	private static final String INVALID_ROOT_CAUSE = "Invalid root cause at line no ";
	private static final String RTCRCM_RESULT_KEY = "reqTypeRootCauseMappingResult";

	/**
	 * This method dispatches bulk processing request depending on request type
	 * 
	 * @param fileInputStream
	 * @param fileInfo
	 * @param type
	 * @param partialUpload
	 * @param soeId
	 * @return BasicDBObject
	 * @throws CommunicatorException
	 */
	public BasicDBObject processBulkUploadRequest(InputStream fileInputStream, String fileInfo, String type,
			boolean partialUpload, String soeId) throws CommunicatorException {
		BasicDBObject dataMap = new BasicDBObject();
		try {
			if (GROUP_UPLOAD_TYPE.equalsIgnoreCase(type)) {
				subLogger.info("User: " + soeId + " uploaded file: " + fileInfo + " for group bulk upload.");
				dataMap = generateGroupList(fileInputStream, soeId, type);
			} else if (GFCID_UPLOAD_TYPE.equalsIgnoreCase(type)) {
				subLogger.info("User : " + soeId + " uploaded file : " + fileInfo + " for GFCID/GFPID bulk uplaod.");
				dataMap = generateGFCIDList(fileInputStream, type);
			} else if (RTM_UPLOAD_TYPE.equalsIgnoreCase(type)) {
				subLogger.info("User : " + soeId + " uploaded file : " + fileInfo + " for request type mapping bulk upload.");
				dataMap = generateRTMList(fileInputStream, type);
			} else if (RTRCM_UPLOAD_TYPE.equalsIgnoreCase(type)) {
				subLogger.info("User : " + soeId + " uploaded file : " + fileInfo + " for request type root cause mapping bulk upload.");
				dataMap = generateRTRCMList(fileInputStream, type);
			}
			initiateBulkUpload(fileInfo, partialUpload, soeId, dataMap, type);
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#processBulkUploadRequest() : " + e);
			throw new CommunicatorException("Exception in BulkProcessUtility#processBulkUploadRequest() : " + e);
		}
		return dataMap;
	}


	/**
	 * This method starts bulk upload process
	 * @param fileInfo
	 * @param partialUpload
	 * @param soeId
	 * @param dataMap
	 */
	private void initiateBulkUpload(String fileInfo, boolean partialUpload, String soeId, BasicDBObject dataMap, String type) {
		if (dataMap.containsField(SUCCESS_KEY) && dataMap.getBoolean(SUCCESS_KEY)) {
			if (GROUP_UPLOAD_TYPE.equalsIgnoreCase(type)) {
				initiateGroupOnboarding(dataMap, soeId, fileInfo, partialUpload);
			} else if (GFCID_UPLOAD_TYPE.equalsIgnoreCase(type)) {
				initiateGfpcIdOnboarding(dataMap, soeId, fileInfo, partialUpload);
			} else if (RTM_UPLOAD_TYPE.equalsIgnoreCase(type)) {
				initiateRtmOnboarding(dataMap, soeId, fileInfo, partialUpload);
			} else if (RTRCM_UPLOAD_TYPE.equalsIgnoreCase(type)) {
				initiateRtRcmOnboarding(dataMap, soeId, fileInfo, partialUpload);
			}
		}
	}


	/**
	 * This method initiates group onboarding
	 * 
	 * @param groupMap
	 * @param soeId
	 * @param partialUpload
	 * @return String
	 */
	public void initiateGroupOnboarding(BasicDBObject groupMap, String soeId, String fileInfo, boolean partialUpload) {
		try {
			List<BasicDBObject> validGrpList = (List<BasicDBObject>) groupMap.get(VALID_GROUPS_KEY);
			List<BasicDBObject> invalidGrpList = (List<BasicDBObject>) groupMap.get(INVALID_GROUPS_KEY);
			if (!groupMap.isEmpty() && !validGrpList.isEmpty() && (invalidGrpList.isEmpty() || partialUpload)) {
				subLogger.info("User[" + soeId + "] initiated automatic group onboarding by uploading file : " + fileInfo);
				BasicDBObject onboardingResult = uploadValidGroups(validGrpList, soeId);
				groupMap.put(ONBOARDING_RESULT_KEY, onboardingResult);
			}
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#initiateGroupOnboarding() : " + e);
		}
	}

	/**
	 * This method initiates gfcid/gfpid onboarding
	 * 
	 * @param dataMap
	 * @param soeId
	 * @param partialUpload
	 * @return String
	 */
	public void initiateGfpcIdOnboarding(BasicDBObject dataMap, String soeId, String fileInfo, boolean partialUpload) {
		try {
			List<BasicDBObject> validGfpcIdList = (List<BasicDBObject>) dataMap.get(VALID_GFCID_KEY);
			List<BasicDBObject> invalidGfpcIdList = (List<BasicDBObject>) dataMap.get(INVALID_GFCID_KEY);
			if (!dataMap.isEmpty() && !validGfpcIdList.isEmpty() && (invalidGfpcIdList.isEmpty() || partialUpload)) {
				subLogger.info("User [" + soeId + "] initiated bulk gfpid upload by uploading file : " + fileInfo);
				createGfpIdBackup();
				BasicDBObject gfcidUploadResult = uploadValidGfpcId(validGfpcIdList, soeId);
				dataMap.put(ONBOARDING_RESULT_KEY, gfcidUploadResult);
			}
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#initiateGfpcIdOnboarding() : " + e);
		}
	}
	
	/**
	 * This method initiates on-boarding of valid request type mappings
	 * @param dataMap
	 * @param soeId
	 * @param fileInfo
	 * @param partialUpload
	 */
	public void initiateRtmOnboarding(BasicDBObject dataMap, String soeId, String fileInfo, boolean partialUpload) {
		try {
			List<BasicDBObject> validRtmList = (List<BasicDBObject>) dataMap.get(VALID_RTM_KEY);
			List<BasicDBObject> invalidRtmList = (List<BasicDBObject>) dataMap.get(INVALID_RTM_KEY);
			if (!dataMap.isEmpty() && !validRtmList.isEmpty() && (invalidRtmList.isEmpty() || partialUpload)) {
				subLogger.info("User [" + soeId + " ] initiated bulk request type mapping upload by uploading file : " + fileInfo);
				BasicDBObject rtmUploadResult = uploadValidRtm(validRtmList, soeId);
				dataMap.put(ONBOARDING_RESULT_KEY, rtmUploadResult);
			}
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#initiateRtmOnboarding() : " + e);
		}
	}

	/**
	 * This method is used to onboard validated groups into application
	 * 
	 * @param groupListToBeOnboarded
	 * @param soeId
	 * @return BasicDBObject
	 * @throws CommunicatorException
	 */
	private BasicDBObject uploadValidGroups(List<BasicDBObject> groupListToBeOnboarded, String soeId)
			throws CommunicatorException {
		BasicDBObject onboardingResultList = new BasicDBObject();
		BasicDBList successOnboardList = new BasicDBList();
		BasicDBList failureOnboardList = new BasicDBList();
		try {
			for (BasicDBObject grpToBeOnboarded : groupListToBeOnboarded) {
				Map<String, Object> returnObject = groupDAO.saveGroupAdminInfo(soeId, grpToBeOnboarded);
				Boolean success = (Boolean) returnObject.get(SUCCESS_KEY);
				
				BasicDBObject grpObj = new BasicDBObject();
				grpObj.put(GROUP_NAME_KEY, grpToBeOnboarded.get(GROUP_NAME_KEY));
				grpObj.put(SUCCESS_KEY, success);
				if (success) {
					subLogger.info("Group " + grpToBeOnboarded.get(GROUP_NAME_KEY) + " Onboarded Successfully !!");
					successOnboardList.add(grpObj);
				} else {
					subLogger.info("Group " + grpToBeOnboarded.get(GROUP_NAME_KEY) + " Already Exists !!");
					failureOnboardList.add(grpObj);
				}
			}
			onboardingResultList.put(ONBOARDED_KEY, successOnboardList);
			onboardingResultList.put(NON_ONBOARDED_KEY, failureOnboardList);
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#uploadValidGroups() : " + e);
			throw new CommunicatorException("Exception in BulkProcessUtility#uploadValidGroups() : " + e);
		}
		return onboardingResultList;
	}

	/**
	 * This method is used to onboard validated gfcid/gfpid into application
	 * 
	 * @param gfpcIdListToBeOnboarded
	 * @param soeId
	 * @return BasicDBObject
	 * @throws CommunicatorException
	 */
	private BasicDBObject uploadValidGfpcId(List<BasicDBObject> gfpcIdListToBeOnboarded, String soeId)
			throws CommunicatorException {
		BasicDBObject onboardingResultList = new BasicDBObject();
		BasicDBList successOnboardList = new BasicDBList();
		BasicDBList alreadyExistsList = new BasicDBList();
		int newInsertCounter = 0;
		int alreadyExistsCounter = 0;
		try {
			subLogger.info("User " + soeId + " Initiated bulk upload GFPD/GFCID.");
			for (BasicDBObject gfpcIdToBeUploaded : gfpcIdListToBeOnboarded) {
				BasicDBObject saveResult = saveGfcIdData(gfpcIdToBeUploaded);
				BasicDBObject gfcidObj = new BasicDBObject();
				gfcidObj.put(GFPID_KEY, gfpcIdToBeUploaded.get(GFPID_KEY));
				gfcidObj.put(MESSAGE_KEY, saveResult.getString(MESSAGE_KEY));
				if (saveResult.getBoolean(SUCCESS_KEY)) {
					subLogger.info("GFPID : " + gfpcIdToBeUploaded.get(GFPID_KEY) + " : GFCID : "
							+ gfpcIdToBeUploaded.get(GFCID_KEY) + " Imported Successfully !!");
					successOnboardList.add(gfcidObj);
					newInsertCounter++;
				} else {
					subLogger.info("GFPID : " + gfpcIdToBeUploaded.get(GFPID_KEY) + " : GFCID : "
							+ gfpcIdToBeUploaded.get(GFCID_KEY) + " Already exists!!");
					alreadyExistsList.add(gfcidObj);
					alreadyExistsCounter++;
				}
			}
			onboardingResultList.put(ONBOARDED_KEY, successOnboardList);
			onboardingResultList.put(NON_ONBOARDED_KEY, alreadyExistsList);
			onboardingResultList.put(NEW_INSERT_KEY, newInsertCounter);
			onboardingResultList.put(ALREADY_EXISTS_KEY, alreadyExistsCounter);
		} catch (Exception e) {
			subLogger.error("Exception in BulkProcessUtility#uploadValidGfpcId() : " + e);
			throw new CommunicatorException("Exception in BulkProcessUtility#uploadValidGfpcId() : " + e);
		}
		return onboardingResultList;
	}
	
	
	/**
	 * This method on-boards request mappings for group
	 * @param rtmListToBeOnboarded
	 * @param soeId
	 * @return
	 * @throws CommunicatorException
	 */
	private BasicDBObject uploadValidRtm(List<BasicDBObject> rtmListToBeOnboarded, String soeId)
			throws CommunicatorException {
		BasicDBObject onboardingResult = new BasicDBObject();
		BasicDBList successOnboardList = new BasicDBList();
		BasicDBList alreadyExistsList = new BasicDBList();
		int newInsertCounter = 0;
		int alreadyExistsCounter = 0;
		try {
			subLogger.info("User " + soeId + " Initiated bulk upload for request type mapping.");
			String groupName = "";
			for (BasicDBObject rtmToBeUploaded : rtmListToBeOnboarded) {
				BasicDBObject saveResult = saveRtmData(rtmToBeUploaded);
				BasicDBObject rtmObj = new BasicDBObject();
				/* TODO : below code is added in order to add missing request type mappings 
				 * with empty values for high level request type if not provided. 
				 * Please remove the same in next release and correct the code */
				groupName = checkIfGroupNameChanged(rtmToBeUploaded.getString(GROUP_NAME_KEY), groupName);
				/* Please remove above code in next release January 2019 */
				rtmObj.put(GROUP_NAME_KEY, rtmToBeUploaded.getString(GROUP_NAME_KEY));
				rtmObj.put(MESSAGE_KEY, saveResult.getString(MESSAGE_KEY));
				if (saveResult.getBoolean(SUCCESS_KEY)) {
					subLogger.info("Request mapping for group : " + rtmToBeUploaded.get(GROUP_NAME_KEY) + " Imported Successfully !!");
					successOnboardList.add(rtmObj);
					newInsertCounter++;
				} else {
					subLogger.info("Request mapping for group : " + rtmToBeUploaded.get(GROUP_NAME_KEY) + " Already exists or Invalida group Data");
					alreadyExistsList.add(rtmObj);
					alreadyExistsCounter++;
				}
			}
			updateGroupForMissingMappings(groupName);
			onboardingResult.put(ONBOARDED_KEY, successOnboardList);
			onboardingResult.put(NON_ONBOARDED_KEY, alreadyExistsList);
			onboardingResult.put(NEW_INSERT_KEY, newInsertCounter);
			onboardingResult.put(ALREADY_EXISTS_KEY, alreadyExistsCounter);
		} catch (Exception e) {
			subLogger.error("Exception in BulkProcessUtility#uploadValidRtm() : " + e);
			throw new CommunicatorException("Exception in BulkProcessUtility#uploadValidRtm() : " + e);
		}
		return onboardingResult;
	}

	/**
	 * This method is used to create a backup of a GFPID collection
	 * 
	 * @throws CommunicatorException
	 */
	private void createGfpIdBackup() throws CommunicatorException {
		try {
			genericDAO.dropCollection(GFCID_BACKUP_COLLECTION_NAME);
			subLogger.info("Creating backup collection: " + GFCID_BACKUP_COLLECTION_NAME);
			DBCollection source = mongoDatastore.getCollection(GFPIDMapping.class);
			AggregationOptions aggregationOptions = AggregationOptions.builder()
					.build();
			source.aggregate(Arrays.asList((DBObject) new BasicDBObject("$out", GFCID_BACKUP_COLLECTION_NAME)), aggregationOptions);
		} catch (Exception e) {
			subLogger.error("Exception occurred in creating backup of a collection " + GFCID_BACKUP_COLLECTION_NAME, e);
			throw new CommunicatorException("Exception in BulkProcessUtility#createGfpIdBackup() : " + e);
		}
	}

	/**
	 * 
	 * @param mappingToBeSaved
	 * @return BasicDBObject
	 * @throws CommunicatorException
	 */
	private BasicDBObject saveGfcIdData(BasicDBObject mappingToBeSaved) {
		BasicDBObject processingStatus = new BasicDBObject();
		try {
			String gfpId = mappingToBeSaved.getString(GFPID_KEY);
			String gfpName = mappingToBeSaved.getString(GFPID_NAME_KEY);
			String gfcId = mappingToBeSaved.getString(GFCID_KEY);
			String gfcName = mappingToBeSaved.getString(GFCID_NAME_KEY);
			int index = mappingToBeSaved.getInt(INDEX_KEY);
			GFPIDMapping gfpidMapping = mongoDatastore.get(GFPIDMapping.class, gfpId);
			GFCId gfcidObj = null;
			List<GFCId> gfcidList = null;

			if (gfpidMapping != null) {
				gfcidList = gfpidMapping.getGfcIds();
				if (CollectionUtils.isNotEmpty(gfcidList)) {
					for (GFCId gfcidReq : gfcidList) {
						if (gfcId.equalsIgnoreCase(gfcidReq.getGfcId())) {
							gfcidObj = gfcidReq;
							break;
						}
					}
				}
			} else if (StringUtils.isNotBlank(gfpId) && StringUtils.isNotBlank(gfpName)) {
				subLogger.info("Creating entry for GFPID: " + gfpId);
				gfpidMapping = new GFPIDMapping();
				gfpidMapping.setId(gfpId);
				gfpidMapping.setGfpName(gfpName);
				if (gfcidList == null) {
					gfcidList = new ArrayList<GFCId>();
					gfpidMapping.setGfcIds(gfcidList);
				}

			}

			if (gfcidObj == null && gfpidMapping != null) {
				if (StringUtils.isBlank(gfcName)) {
					subLogger.info("Invalid entry- Blank names for GFPID: " + gfpId + " --- GFCID: " + gfcId);
				} else {
					gfcidObj = new GFCId();
					gfcidObj.setGfcId(gfcId);
					gfcidObj.setGfcName(gfcName);
					subLogger.info("Adding entry for GFPID: " + gfpId + " --- GFCID: " + gfcId);
					gfcidList.add(gfcidObj);
					gfpidMapping.setModDate(new Date());
					mongoDatastore.save(gfpidMapping);
					processingStatus.put(MESSAGE_KEY, GFPC_ID_RECORD_ADDED + index);
					processingStatus.put(SUCCESS_KEY, true);
				}
			} else {
				processingStatus.put(MESSAGE_KEY, GFPC_ID_RECORD_EXISTS + index);
				processingStatus.put(SUCCESS_KEY, false);
			}

		} catch (Exception e) {
			subLogger.error("Exception is thrown while inserting gfpid mapping for gfpid: "
					+ String.valueOf(mappingToBeSaved.getString(GFPID_KEY)) + " " + e);
		}
		return processingStatus;

	}
	
	
	/**
	 * This method saves group level request type mappings
	 * @param mappingToBeSaved
	 * @return BasicDBObject
	 */
	private BasicDBObject saveRtmData(BasicDBObject mappingToBeSaved) {
		BasicDBObject result = new BasicDBObject();
		try {
			String groupName = mappingToBeSaved.getString(GROUP_NAME_KEY);
			UpdateOperations<Group> ops = mongoDatastore.createUpdateOperations(Group.class);
			Query<Group> updateQuery =  mongoDatastore.createQuery(Group.class).filter(GROUP_NAME_KEY, groupName);
			Group group = updateQuery.get();
			String requestType = mappingToBeSaved.getString(RTM_REQUEST_TYPE_KEY);
			String highLevelRT = mappingToBeSaved.getString(RTM_HIGH_LEVEL_RT_KEY);
			if(group != null && StringUtils.isNotEmpty(requestType)  && StringUtils.isNotEmpty(highLevelRT)) {
				List<HighlevelRequestType> requestTypeMappings = getGroupRequestTypeMappings(group, requestType,
						highLevelRT);
				ops.set("requestTypeMappings", requestTypeMappings);
				mongoDatastore.update(updateQuery, ops);
				result.put(MESSAGE_KEY, "Group mapping updated successfully.");
				result.put(SUCCESS_KEY, true);
			} else {
				result.put(MESSAGE_KEY, "Group not found in database.");
				result.put(SUCCESS_KEY, false);
			}
		} catch (Exception e) {
			result.put(MESSAGE_KEY, "Group not found in database.");
			result.put(SUCCESS_KEY, false);
			subLogger.error("Error while saving request type mapping data BulkProcessUtility#saveRtmData():", e);
		}
		return result;
	}

	/**
	 * This method identifies group level request type mappings
	 * @param group
	 * @param requestType
	 * @param highLevelRT
	 * @return List<HighlevelRequestType>
	 */
	private List<HighlevelRequestType> getGroupRequestTypeMappings(Group group, String requestType,
			String highLevelRT) {
		List<HighlevelRequestType> requestTypeMappings = group.getRequestTypeMappings();
		if(requestTypeMappings==null){
			requestTypeMappings = new ArrayList<>();
		}
		boolean mappingEntryFound = false;
		for(HighlevelRequestType currentMapping : requestTypeMappings){
			if(currentMapping.getRequestType().equalsIgnoreCase(requestType)){
				currentMapping.setHighlevelRequestType(highLevelRT);
				mappingEntryFound = true;
				break;
			}	
		}	
		if(!mappingEntryFound){
			HighlevelRequestType mapping = new  HighlevelRequestType(requestType,highLevelRT);
			requestTypeMappings.add(mapping);
		}
		return requestTypeMappings;
	}

	/**
	 * This function processes each row of a file and identifies between valid
	 * and invalid groups
	 * 
	 * @param fileInputStream
	 * @param groupMap
	 * @param soeId
	 * @param type
	 * @return BasicDBObject
	 * @throws CommunicatorException
	 */
	public BasicDBObject generateGroupList(InputStream fileInputStream, String soeId, String type)
			throws CommunicatorException {
		BasicDBObject groupMap = new BasicDBObject();
		List<BasicDBObject> validGroupList = new ArrayList<>();
		List<BasicDBObject> invalidGroupList = new ArrayList<>();
		String groupDataStr = "";
		try (Scanner scanner = new Scanner(fileInputStream)) {
			ManagementHeirarchy managementHeirarchyDB = groupDAO.getManagementHeirarchy(soeId);
			// first row is header of a file
			if (isValidFileContent(scanner.nextLine(), type)) { 
				int index = 1;
				while (scanner.hasNextLine()) {
					groupDataStr = scanner.nextLine();
					validateGroupInfo(groupDataStr, managementHeirarchyDB, validGroupList, invalidGroupList, soeId,
							index);
					index++;
				}
				groupMap.put(VALID_GROUPS_KEY, validGroupList);
				groupMap.put(INVALID_GROUPS_KEY, invalidGroupList);
				groupMap.put(SUCCESS_KEY, true);
				groupMap.put(MESSAGE_KEY, SUCCESS_MESSAGE);
			} else {
				groupMap.put(MESSAGE_KEY, INVALID_FILE_CONTENTS_MESSAGE);
				groupMap.put(SUCCESS_KEY, false);
			}

		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#generateGroupList() : ", e);
			throw new CommunicatorException("Exception in BulkProcessUtility#generateGroupList() :", e);
		}
		return groupMap;
	}

	/**
	 * This function processes each row of a file and identifies between valid
	 * and invalid gfcid/gfpid
	 * 
	 * @param fileInputStream
	 * @param soeId
	 * @param type
	 * @return BasicDBObject
	 * @throws CommunicatorException
	 */
	private BasicDBObject generateGFCIDList(InputStream fileInputStream, String type) throws CommunicatorException {
		BasicDBObject gfpcIdObjMap = new BasicDBObject();
		List<BasicDBObject> validGfcidList = new ArrayList<>();
		List<BasicDBObject> invalidGfcidList = new ArrayList<>();
		String gfcidDataStr = "";
		try (Scanner scanner = new Scanner(fileInputStream)) {
			// first row is header of a file
			if (isValidFileContent(scanner.nextLine(), type)) { 
				int index = 1;
				while (scanner.hasNextLine()) {
					gfcidDataStr = scanner.nextLine();
					validateGfcidInfo(gfcidDataStr, validGfcidList, invalidGfcidList, ++index);
				}
				gfpcIdObjMap.put(VALID_GFCID_KEY, validGfcidList);
				gfpcIdObjMap.put(INVALID_GFCID_KEY, invalidGfcidList);
				gfpcIdObjMap.put(SUCCESS_KEY, true);
				gfpcIdObjMap.put(MESSAGE_KEY, SUCCESS_MESSAGE);
			} else {
				gfpcIdObjMap.put(MESSAGE_KEY, INVALID_FILE_CONTENTS_MESSAGE);
				gfpcIdObjMap.put(SUCCESS_KEY, false);
			}

		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#generateGFCIDList() : ", e);
			throw new CommunicatorException("Exception in BulkProcessUtility#generateGFCIDList() :", e);
		}
		return gfpcIdObjMap;
	}
	
	/**
	 * This function processes each row of a file and identifies between valid
	 * and invalid request type mappings
	 * 
	 * @param fileInputStream
	 * @param type
	 * @return BasicDBObject
	 * @throws CommunicatorException
	 */
	private BasicDBObject generateRTMList(InputStream fileInputStream, String type) throws CommunicatorException {
		BasicDBObject rtmObjMap = new BasicDBObject();
		List<BasicDBObject> validRtmList = new ArrayList<>();
		List<BasicDBObject> invalidRtmList = new ArrayList<>();
		String rtmDataStr = "";
		try (Scanner scanner = new Scanner(fileInputStream)) {
			List<String> highLevelRequestTypes = getHighLevelRequestTypes();
			// first row is header of a file
			if (isValidFileContent(scanner.nextLine(), type) && null != highLevelRequestTypes
					&& !highLevelRequestTypes.isEmpty()) {
				int index = 1;
				while (scanner.hasNextLine()) {
					rtmDataStr = scanner.nextLine();
					validateRtmInfo(rtmDataStr, validRtmList, invalidRtmList, ++index,highLevelRequestTypes);
				}
				rtmObjMap.put(VALID_RTM_KEY, validRtmList);
				rtmObjMap.put(INVALID_RTM_KEY, invalidRtmList);
				rtmObjMap.put(SUCCESS_KEY, true);
				rtmObjMap.put(MESSAGE_KEY, SUCCESS_MESSAGE);
			} else {
				rtmObjMap.put(MESSAGE_KEY, INVALID_FILE_CONTENTS_MESSAGE);
				rtmObjMap.put(SUCCESS_KEY, false);
			}

		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#generateRTMList() : ", e);
			throw new CommunicatorException("Exception in BulkProcessUtility#generateRTMList() :", e);
		}
		return rtmObjMap;
	}


	/**
	 * This method identifies whether group name has changed on new line in file or not
	 * @param rtmDataStr
	 * @param groupName
	 * @return String
	 */
	protected String checkIfGroupNameChanged(String rtmDataStr, String groupName) {
		String newGroupName = groupName;
		String newLineGrpName = getGroupNameForMapping(rtmDataStr);
		if(!groupName.equalsIgnoreCase(newLineGrpName)){
			updateGroupForMissingMappings(groupName);
			newGroupName = getGroupNameForMapping(rtmDataStr);
		}
		return newGroupName;
	}

	/**
	 * This method updates group with missing request type mappings
	 * @param groupName
	 */
	private void updateGroupForMissingMappings(String groupName) {
		try {
			UpdateOperations<Group> ops = mongoDatastore.createUpdateOperations(Group.class);
			Query<Group> updateQuery =  mongoDatastore.createQuery(Group.class).filter(GROUP_NAME_KEY, groupName.trim());
			Group group = updateQuery.get();
			if( group != null && null != group.getRequestTypes() && null != group.getRequestTypeMappings() ){
				List<String> requestTypes = group.getRequestTypes();
				List<HighlevelRequestType> requestTypeMappings = group.getRequestTypeMappings();
				for(String currentRequestType : requestTypes){
					checkMissingRequestType(requestTypeMappings, currentRequestType);
				}
				ops.set("requestTypeMappings", requestTypeMappings);
				mongoDatastore.update(updateQuery, ops);
			}
		} catch (Exception e) {
			subLogger.error("Error while updating missing entries in file :",e);
		}
		
	}


	/**
	 * This method identifies mapping exists for current request type or not 
	 * 
	 * @param requestTypeMappings
	 * @param currentRequestType
	 */
	private void checkMissingRequestType(List<HighlevelRequestType> requestTypeMappings, String currentRequestType) {
		if( currentRequestType != null ){
			boolean isCurrentRequestTypeMapped = false;
			for(HighlevelRequestType hlRequestType : requestTypeMappings){
				if(currentRequestType.equalsIgnoreCase(hlRequestType.getRequestType())){
					isCurrentRequestTypeMapped = true;
					break;
				}
			}
			if(!isCurrentRequestTypeMapped) {
				HighlevelRequestType hlrt = new HighlevelRequestType(currentRequestType, "");
				requestTypeMappings.add(hlrt);
			}
		}
	}


	/**
	 * This method identifies new group name from the file
	 * @param rtmDataStr
	 * @return
	 */
	private String getGroupNameForMapping(String rtmDataStr) {
		String dataString = rtmDataStr;
		String[] columns = dataString.split(EXCEL_COLUMN_SEPARATOR);
		return columns[RTM_GROUP_NAME_INDEX].trim();
	}


	/**
	 *  This method returns list of high level request types from Config
	 * @return List<String>
	 */
	private List<String> getHighLevelRequestTypes() {
		List<String> mappingList = null;
		Query<Config> dbQuery = mongoDatastore.createQuery(Config.class);
		dbQuery.filter("id", "highlevelReqestType").limit(1);
		Config configData = dbQuery.asList().get(0);
		if( configData != null ) {
			mappingList = configData.getHighlevelReqestTypes();
		}
		return mappingList;
	}

	/**
	 * This function validates group info string before processing.
	 * 
	 * @param groupDataStr
	 * @param managementHeirarchyDB
	 * @param validGroupList
	 * @param invalidGroupList
	 * @param soeId
	 * @param index
	 * @throws CommunicatorException
	 */
	public void validateGroupInfo(String groupDataStr, ManagementHeirarchy managementHeirarchyDB,
			List<BasicDBObject> validGroupList, List<BasicDBObject> invalidGroupList, String soeId, int index)
			throws CommunicatorException {
		if (StringUtils.isNotBlank(groupDataStr)) {
			try {
				createGroupObject(groupDataStr, managementHeirarchyDB, validGroupList, invalidGroupList, soeId, index);
			} catch (CommunicatorException e) {
				subLogger.error("Exception in BulkProcessUtility#validateGroupInfo() : ", e);
				throw new CommunicatorException("Exception in BulkProcessUtility#validateGroupInfo() :", e);
			}
		}
	}

	/**
	 * This method validates gfcid string from the file and sends further for
	 * processing
	 * 
	 * @param gfcidDataStr
	 * @param validGfcidList
	 * @param invalidGfcidList
	 * @param index
	 * @throws CommunicatorException
	 */
	private void validateGfcidInfo(String gfcidDataStr, List<BasicDBObject> validGfcidList,
			List<BasicDBObject> invalidGfcidList, int index) throws CommunicatorException {
		if (StringUtils.isNotBlank(gfcidDataStr)) {
			try {
				createGfpcIdObject(gfcidDataStr, validGfcidList, invalidGfcidList, index);
			} catch (CommunicatorException e) {
				subLogger.error("Exception in BulkProcessUtility#validateGfcidInfo() : ", e);
				throw new CommunicatorException("Exception in BulkProcessUtility#validateGfcidInfo() :", e);
			}
		}
	}
	
	/**
	 * This method validates request type mapping string 
	 * from file and sends further for processing
	 * 
	 * @param rtmDataStr
	 * @param validRtmList
	 * @param invalidRtmList
	 * @param index
	 * @throws CommunicatorException
	 */
	private void validateRtmInfo(String rtmDataStr, List<BasicDBObject> validRtmList,
			List<BasicDBObject> invalidRtmList, int index,List<String> highLevelRequestTypes) throws CommunicatorException {
		if (StringUtils.isNotBlank(rtmDataStr)) {
			try {
				createRtmObject(rtmDataStr, validRtmList, invalidRtmList, index, highLevelRequestTypes);
			} catch (CommunicatorException e) {
				subLogger.error("Exception in BulkProcessUtility#validateRtmInfo() : ", e);
				throw new CommunicatorException("Exception in BulkProcessUtility#validateRtmInfo() :", e);
			}
		}
	}

	/**
	 * This function is used to validate whether the file is in correct format
	 * or not
	 * 
	 * @param rowDataStr
	 * @param type
	 * @return boolean
	 */
	private boolean isValidFileContent(String rowDataStr, String type) {
		boolean validFile = true;
		String[] columns = rowDataStr.split(EXCEL_COLUMN_SEPARATOR);
		if (GROUP_UPLOAD_TYPE.equalsIgnoreCase(type)) {
			validFile = validateGroupFileContents(columns);
		} else if (GFCID_UPLOAD_TYPE.equalsIgnoreCase(type)) {
			validFile = validateGfcidFileContents(columns);
		} else if (RTM_UPLOAD_TYPE.equalsIgnoreCase(type)) {
			validFile = validateRtmFileContents(columns);
		} else if (RTRCM_UPLOAD_TYPE.equalsIgnoreCase(type)) {
			validFile = validateRtRcmFileContents(columns);
		}
		return validFile;
	}

	/**
	 * Validate column count for group upload file
	 * 
	 * @param columns
	 * @return boolean
	 */
	private boolean validateGroupFileContents(String[] columns) {
		if (columns.length == 0 || columns.length != NO_OF_COLS_FOR_GROUP_FILE) {
			return false;
		}
		return true;
	}

	/**
	 * Validate column count for gfcid upload file
	 * 
	 * @param columns
	 * @return
	 */
	private boolean validateGfcidFileContents(String[] columns) {
		if (columns.length == 0 || columns.length != NO_OF_COLS_FOR_GFCID_FILE || !validateGfpidFileHeaders(columns)) {
			return false;
		}
		return true;
	}
	
	/**
	 * This method validates column count for request type mapping file
	 * @param columns
	 * @return boolean
	 */ 
	private boolean validateRtmFileContents(String[] columns) {
		if (columns.length == 0 || columns.length != NO_OF_COLS_FOR_RTM_FILE || !validateRtmFileHeaders(columns)) {
			return false;
		}
		return true;
	}

	/**
	 * This function validates GFPID file headers
	 * @param columns
	 * @return Boolean
	 */
	private boolean validateGfpidFileHeaders(String[] columns) {
		boolean validHeaders = true;
		if( !columns[GFPID_INDEX].trim().equalsIgnoreCase(GFPID_FILE_HEADER)) 
			return false;
		if( !columns[GFPID_NAME_INDEX].trim().equalsIgnoreCase(GFPID_NAME_FILE_HEADER)) 
			return false;
		if( !columns[GFCID_INDEX].trim().equalsIgnoreCase(GFCID_FILE_HEADER)) 
			return false;
		if( !columns[GFCID_NAME_INDEX].trim().equalsIgnoreCase(GFCID_NAME_FILE_HEADER)) 
			return false;
		return validHeaders;
	}
	
	/**
	 * This function validates request type mapping file headers
	 * @param columns
	 * @return boolean
	 */
	private boolean validateRtmFileHeaders(String[] columns) {
		boolean validHeaders = true;
		if( !columns[RTM_GROUP_NAME_INDEX].trim().equalsIgnoreCase(RTM_GROUP_NAME_FILE_HEADER)) 
			return false;
		if( !columns[RTM_HIGH_LEVEL_RT_INDEX].trim().equalsIgnoreCase(RTM_HIGH_LEVEL_RT_FILE_HEADER)) 
			return false;
		if( !columns[RTM_REQUEST_TYPE_INDEX].trim().equalsIgnoreCase(RTM_REQUEST_TYPE_FILE_HEADER)) 
			return false;
		return validHeaders;
	}

	/**
	 * This function accepts a row data from file and converts it into group
	 * data. Data will be received in following format Outlook DL | DL Email
	 * Address* | Organization | Senior Manager (MD Level) | Senior Group
	 * Manager(Director Level) | Group Manager | Group Admin (csv file with
	 * columns separated by '|'(pipe) operator and multiple values in columns is
	 * separated by '~' operator)
	 * 
	 * @param grpData
	 * @param managementHeirarchyDB
	 * @param validGroupList
	 * @param invalidGroupList
	 * @param soeId
	 * @param index
	 * @throws CommunicatorException
	 */
	private void createGroupObject(String grpData, ManagementHeirarchy managementHeirarchyDB,
			List<BasicDBObject> validGroupList, List<BasicDBObject> invalidGroupList, String soeId, int index)
			throws CommunicatorException {
		BasicDBObject group = new BasicDBObject();
		BasicDBList invalidDataList = new BasicDBList();

		try {
			String[] columns = grpData.split(EXCEL_COLUMN_SEPARATOR);
			if (columns.length != 0 && columns.length >= NO_OF_COLS_FOR_GROUP_FILE) {
				/* First column is group name */
				group.put(GROUP_NAME_KEY, columns[GROUP_NAME_INDEX].trim());
				/* Second column is group mail */
				if (GenericUtility.isValidEmailAddress(columns[GROUP_EMAIL_INDEX].trim())) {
					group.put(GROUP_EMAIL_KEY, columns[GROUP_EMAIL_INDEX].trim());
				} else {
					invalidDataList.add(INVALID_MAIL_ID);
				}
				/*
				 * Seventh column is list of group admin users separated by '~'
				 */
				if (StringUtils.isNotBlank(columns[GROUP_ADMIN_INDEX]) && validateAdminUsers(
						columns[GROUP_ADMIN_INDEX].split(EXCEL_COLUMN_MULTI_VALUE_SEPARATOR), soeId)) {
					BasicDBList adminlist = getDBList(
							columns[GROUP_ADMIN_INDEX].split(EXCEL_COLUMN_MULTI_VALUE_SEPARATOR));
					group.put(ADMIN_USER, adminlist);
				} else {
					invalidDataList.add(INVALID_ADMIN_USERS);
				}
				/* Added following parameter in order to comply with code changes for 
				 * group on-boarding in GroupDAO#saveGroupAdminInfo() method */
				group.put(GROUP_NEW_TO_ADD_KEY, true);
				validateHierarchyData(columns, managementHeirarchyDB, soeId, group, invalidDataList);

				group.put(IS_INACTIVE_KEY, false);

				if (invalidDataList.isEmpty()) {
					validGroupList.add(group);
				} else {
					group.put(VALIDATION_FAILURE_KEY, invalidDataList);
					invalidGroupList.add(group);
				}

			} else {
				addToInvalidGroupList(columns[GROUP_NAME_INDEX], group, invalidDataList, invalidGroupList, index);
			}
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#createGroupObject()", e);
			throw new CommunicatorException("Exception in BulkProcessUtility#createGroupObject(): ", e);
		}
	}

	/**
	 * This method generates GFCID/GFPID object
	 * 
	 * @param gfcidDataStr
	 * @param validGfcidList
	 * @param invalidGfcidList
	 * @param index
	 * @throws CommunicatorException
	 */
	private void createGfpcIdObject(String gfcidDataStr, List<BasicDBObject> validGfcidList,
			List<BasicDBObject> invalidGfcidList, int index) throws CommunicatorException {
		BasicDBObject gfpcObj = new BasicDBObject();
		BasicDBList invalidDataList = new BasicDBList();
		BasicDBList validationDataList = new BasicDBList();
		String dataString = gfcidDataStr;
		if (dataString.contains("'")) {
			dataString = dataString.replaceAll("'", "");
		}
		gfpcObj.put(INDEX_KEY, index);
		String[] columns = dataString.split(EXCEL_COLUMN_SEPARATOR);
		if (columns.length == NO_OF_COLS_FOR_GFCID_FILE) {
			String gfpID = columns[GFPID_INDEX].trim();

			if (StringUtils.isNotBlank(gfpID)) {
				validateGfpIdData(columns, gfpcObj, validationDataList, invalidDataList, index);
			} else {
				invalidDataList.add(INVALID_GFPID + index);
			}
			if (invalidDataList.isEmpty()) {
				gfpcObj.put(VALIDATION_DATALIST_KEY, validationDataList);
				validGfcidList.add(gfpcObj);
			} else {
				gfpcObj.put(VALIDATION_FAILURE_KEY, invalidDataList);
				invalidGfcidList.add(gfpcObj);
			}
		} else {
			addToInvalidGfcidList(gfpcObj, invalidDataList, invalidGfcidList, index);
		}
	}
	
	
	/**
	 * This method generates request type mapping object.
	 * 
	 * @param rtmDataStr
	 * @param validRtmList
	 * @param invalidRtmList
	 * @param index
	 * @throws CommunicatorException
	 */
	private void createRtmObject(String rtmDataStr, List<BasicDBObject> validRtmList,
			List<BasicDBObject> invalidRtmList, int index,List<String> highLevelRequestTypes) throws CommunicatorException {
		BasicDBObject rtmObj = new BasicDBObject();
		BasicDBList invalidDataList = new BasicDBList();
		BasicDBList validationDataList = new BasicDBList();
		String dataString = rtmDataStr;
		if (dataString.contains("'")) {
			dataString = dataString.replaceAll("'", "");
		}
		rtmObj.put(INDEX_KEY, index);
		String[] columns = dataString.split(EXCEL_COLUMN_SEPARATOR);
		if (columns.length == NO_OF_COLS_FOR_RTM_FILE) {
			String groupName = columns[RTM_GROUP_NAME_INDEX].trim();

			if (StringUtils.isNotBlank(groupName)) {
				validateRtmData(columns, rtmObj, validationDataList, invalidDataList, index, highLevelRequestTypes);
			} else {
				invalidDataList.add(INVALID_GFPID + index);
			}
			if (invalidDataList.isEmpty()) {
				rtmObj.put(VALIDATION_DATALIST_KEY, validationDataList);
				validRtmList.add(rtmObj);
			} else {
				rtmObj.put(VALIDATION_FAILURE_KEY, invalidDataList);
				invalidRtmList.add(rtmObj);
			}
		} else {
			addToInvalidRtmList(rtmObj, invalidDataList, invalidRtmList, index);
		}
	}

	
	/**
	 * This method validates GFPID data
	 * @param columns
	 * @param gfpcObj
	 * @param validationDataList
	 * @param invalidDataList
	 * @param index
	 */
	private void validateGfpIdData(String[] columns, BasicDBObject gfpcObj, BasicDBList validationDataList,
			BasicDBList invalidDataList, int index) {

		String gfpID = columns[GFPID_INDEX].trim();
		String gfpIdName = columns[GFPID_NAME_INDEX].trim();
		String gfcID = columns[GFCID_INDEX].trim();
		String gfcIdName = columns[GFCID_NAME_INDEX].trim();

		gfpcObj.put(GFPID_KEY, gfpID);
		GFPIDMapping gfpidMapping = mongoDatastore.get(GFPIDMapping.class, gfpID);
		if (gfpidMapping != null) {
			gfpcObj.put(GFPID_NAME_KEY, gfpidMapping.getGfpName());
			validationDataList.add(GFPID_EXISTS + index);
			validateGfcIdData(columns, gfpcObj, gfpidMapping, invalidDataList, validationDataList, index);
		} else {
			validateNewGfpIdData(gfpIdName, gfcID, gfcIdName, gfpcObj, invalidDataList, index);
		}
	}
	
	/**
	 * This method validates request type mapping data
	 * @param columns
	 * @param rtmObj
	 * @param validationDataList
	 * @param invalidDataList
	 * @param index
	 */
	private void validateRtmData(String[] columns, BasicDBObject rtmObj, BasicDBList validationDataList,
			BasicDBList invalidDataList, int index,List<String> highLevelRequestTypes) {
		String groupName = columns[RTM_GROUP_NAME_INDEX].trim();
		rtmObj.put(GROUP_NAME_KEY, groupName);
		try {
			Group group = groupDAO.getGroupDataById(rtmObj);
			String highLevelRT = columns[RTM_HIGH_LEVEL_RT_INDEX].trim();
			String requestType = columns[RTM_REQUEST_TYPE_INDEX].trim();
			if( group != null && validateRequestTypeMapping(group, highLevelRT, requestType,highLevelRequestTypes)) {
				rtmObj.put(RTM_HIGH_LEVEL_RT_KEY, highLevelRT);
				rtmObj.put(RTM_REQUEST_TYPE_KEY, requestType);
				validationDataList.add("Valid data found for mapping");
			} else {
				invalidDataList.add(INVALID_MAPPING_NAME + index);
			}
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#validateRtmData() while retrieveing group object for :" + groupName, e);
		}
	}

	/**
	 * This method validates data for new GPFID entry
	 * @param gfpIdName
	 * @param gfcID
	 * @param gfcIdName
	 * @param gfpcObj
	 * @param invalidDataList
	 * @param index
	 */
	private void validateNewGfpIdData(String gfpIdName, String gfcID, String gfcIdName, BasicDBObject gfpcObj,
			BasicDBList invalidDataList, int index) {

		if (StringUtils.isNotBlank(gfpIdName)) {
			gfpcObj.put(GFPID_NAME_KEY, gfpIdName);

			if (StringUtils.isNotBlank(gfcID)) {
				gfpcObj.put(GFCID_KEY, gfcID);

				if (StringUtils.isNotBlank(gfcIdName)) {
					gfpcObj.put(GFCID_NAME_KEY, gfcIdName);
				} else {
					invalidDataList.add(INVALID_GFCID_NAME + index);
				}
			} else {
				invalidDataList.add(INVALID_GFCID + index);
			}

		} else {
			invalidDataList.add(INVALID_GFPID_NAME + index);
		}

	}

	/**
	 * This method validates GFCID against provided GFPID object
	 * 
	 * @param columns
	 * @param gfpcObj
	 * @param gfpidMapping
	 * @param invalidDataList
	 * @param validationDataList
	 * @param index
	 * @return boolean
	 */
	private void validateGfcIdData(String[] columns, BasicDBObject gfpcObj, GFPIDMapping gfpidMapping,
			BasicDBList invalidDataList, BasicDBList validationDataList, int index) {

		try {
			String gfcId = columns[GFCID_INDEX].trim();
			if (StringUtils.isNotBlank(gfcId)) {
				validateNewGfcIdData(gfcId, columns, gfpcObj, gfpidMapping, validationDataList, invalidDataList, index);
			} else {
				invalidDataList.add(INVALID_GFCID + index);
			}

		} catch (Exception e) {
			subLogger.error("Exception in BulkProcessUtility#validateGfcIdData()", e);
		}
	}

	/**
	 * This method validates data provided for new GFCID entry
	 * @param gfcId
	 * @param columns
	 * @param gfpcObj
	 * @param gfpidMapping
	 * @param validationDataList
	 * @param invalidDataList
	 * @param index
	 */
	private void validateNewGfcIdData(String gfcId, String[] columns, BasicDBObject gfpcObj, GFPIDMapping gfpidMapping,
			BasicDBList validationDataList, BasicDBList invalidDataList, int index) {
		boolean gfcIdExists = false;
		gfpcObj.put(GFCID_KEY, gfcId);
		String gfcIdName = columns[GFCID_NAME_INDEX].trim();
		List<GFCId> gfcidList = gfpidMapping.getGfcIds();
		if (CollectionUtils.isNotEmpty(gfcidList)) {
			for (GFCId currentGfcidObj : gfcidList) {
				if (gfcId.equalsIgnoreCase(currentGfcidObj.getGfcId())) {
					gfcIdName = currentGfcidObj.getGfcName();
					gfcIdExists = true;
					break;
				}
			}
		}
		gfpcObj.put(GFCID_NAME_KEY, gfcIdName);
		if (gfcIdExists) {
			validationDataList.add(GFCID_EXISTS + index);
		} else if (StringUtils.isBlank(gfcIdName)) {
			invalidDataList.add(INVALID_GFCID_NAME + index);
		}

	}
	
	/**
	 * This method validates data for request type mapping
	 * @param group
	 * @param highLevelRT
	 * @param groupRequestType
	 * @param highLevelRequestTypes
	 * @return boolean
	 */
	private boolean validateRequestTypeMapping(Group group, String highLevelRT, String groupRequestType,
			List<String> highLevelRequestTypes) {
		boolean isValidMapping = false;
		try {
			if(null != group.getRequestTypes() && StringUtils.isNotEmpty(highLevelRT) &&
					StringUtils.isNotEmpty(groupRequestType)){
				List<String> groupRequestTypes = group.getRequestTypes();
				if(!groupRequestTypes.isEmpty() && highLevelRequestTypes.contains(highLevelRT)) {
					if(!groupRequestTypes.contains(groupRequestType)){
						UpdateOperations<Group> ops1 = mongoDatastore.createUpdateOperations(Group.class);
						Query<Group> updateQuery1 =  mongoDatastore.createQuery(Group.class).filter(GROUP_NAME_KEY, group.getGroupName());
						groupRequestTypes.add(groupRequestType);
						group.setRequestTypes(groupRequestTypes);
						ops1.set("requestTypes",groupRequestTypes);
						mongoDatastore.update(updateQuery1, ops1);
						
					}
					isValidMapping = true;
				}
			}
		} catch (Exception e) {
			subLogger.error("Error while validating request type mappings in BulkProcessUtility#validateRequestTypeMapping():" , e);
		}
		return isValidMapping;
	}

	/**
	 * This method used to add group to invalid list of groups if data is
	 * incomplete
	 * 
	 * @param grpName
	 * @param group
	 * @param invalidDataList
	 * @param invalidGroupList
	 * @param index
	 */
	private void addToInvalidGroupList(String grpName, BasicDBObject group, BasicDBList invalidDataList,
			List<BasicDBObject> invalidGroupList, int index) {
		if (grpName != null && StringUtils.isNotBlank(grpName.trim())) {
			group.put(GROUP_NAME_KEY, grpName.trim());
		} else {
			group.put(GROUP_NAME_KEY, UNKNOWN_GROUP_DETAILS + index);
		}
		invalidDataList.add(INCOMPLETE_GROUP_DETAILS);
		group.put(VALIDATION_FAILURE_KEY, invalidDataList);
		invalidGroupList.add(group);
	}

	/**
	 * This method add gfcid to invalid list of gfcid if data is incomplete
	 * 
	 * @param gfcid
	 * @param invalidDataList
	 * @param invalidGfcidList
	 * @param index
	 */
	private void addToInvalidGfcidList(BasicDBObject gfcid, BasicDBList invalidDataList,
			List<BasicDBObject> invalidGfcidList, int index) {
		invalidDataList.add(INCOMPLETE_GFCID_DETAILS + index);
		gfcid.put(VALIDATION_FAILURE_KEY, invalidDataList);
		invalidGfcidList.add(gfcid);
	}
	
	/**
	 * This method adds invalid mappings to invalid data list 
	 * @param rtmObj
	 * @param invalidDataList
	 * @param invalidRtmList
	 * @param index
	 */
	private void addToInvalidRtmList(BasicDBObject rtmObj, BasicDBList invalidDataList,
			List<BasicDBObject> invalidRtmList, int index) {
		invalidDataList.add(INCOMPLETE_GFCID_DETAILS + index);
		rtmObj.put(VALIDATION_FAILURE_KEY, invalidDataList);
		invalidRtmList.add(rtmObj);
	}

	/**
	 * This method is used to validate admin users
	 * 
	 * @param adminUserList
	 * @param soeId
	 * @return boolean
	 * @throws CommunicatorException
	 */
	private boolean validateAdminUsers(String[] adminUserList, String soeId) throws CommunicatorException {
		try {
			for (String currentAdminUser : adminUserList) {
				UserTO userData = validateUser(currentAdminUser.trim(), soeId);
				if (userData == null) {
					return false;
				}
			}
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#validateAdminUsers()", e);
			throw new CommunicatorException("Exception in BulkProcessUtility#validateAdminUsers(): ", e);
		}
		return true;
	}

	/**
	 * This method validates user hierarchy details data
	 * 
	 * @param columns
	 * @param managementHeirarchyDB
	 * @param soeId
	 * @param group
	 * @param invalidDataList
	 * @throws CommunicatorException
	 */
	private void validateHierarchyData(String[] columns, ManagementHeirarchy managementHeirarchyDB, String soeId,
			BasicDBObject group, BasicDBList invalidDataList) throws CommunicatorException {
		try {
			BasicDBObject hierarchy = new BasicDBObject();
			validateHierarchyDetails(columns, managementHeirarchyDB, hierarchy, invalidDataList);
			validateGrpManager(columns, hierarchy, soeId, invalidDataList);
			group.put(HDATA_KEY, hierarchy);
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#validateHierarchyData()", e);
			throw new CommunicatorException("Exception in BulkProcessUtility#validateHierarchyData()", e);
		}
	}

	/**
	 * This method validate hierarchy details
	 * 
	 * @param columns
	 * @param managementHeirarchyDB
	 * @param hierarchy
	 * @param invalidDataList
	 * @throws CommunicatorException
	 */
	private void validateHierarchyDetails(String[] columns, ManagementHeirarchy managementHeirarchyDB,
			BasicDBObject hierarchy, BasicDBList invalidDataList) throws CommunicatorException {
		try {
			/* Third column is organization */
			if (validateManagementHeirarchyWithDB(BUSINESS_UNIT, columns[GROUP_ORG_INDEX].trim(),
					managementHeirarchyDB)) {
				BasicDBList organization = new BasicDBList();
				organization.add(columns[GROUP_ORG_INDEX].trim());
				hierarchy.put(ORGANIZATION_KEY, organization);
			} else {
				if (StringUtils.isNotBlank(columns[GROUP_ORG_INDEX].trim())) {
					invalidDataList.add(INVALID_ORG);
				}
			}

			/* Fourth column is first level hierarchy */
			if (validateManagementHeirarchyWithDB(FIRST_LEVEL_HRCHY, columns[GROUP_FLH_INDEX].trim(),
					managementHeirarchyDB)) {
				BasicDBList firstLevelHierarchyArr = new BasicDBList();
				BasicDBObject hud1 = new BasicDBObject();
				hud1.put(USERNAME_KEY, columns[GROUP_FLH_INDEX].trim());
				firstLevelHierarchyArr.add(hud1);
				hierarchy.put(FLH_KEY, firstLevelHierarchyArr);
			} else {
				if (StringUtils.isNotBlank(columns[GROUP_FLH_INDEX].trim())) {
					invalidDataList.add(INVALID_FLH_DATA);
				}
			}

			/* Fifth column is second level hierarchy */
			if (validateManagementHeirarchyWithDB(SECOND_LEVEL_HRCHY, columns[GROUP_SLH_INDEX].trim(),
					managementHeirarchyDB)) {
				BasicDBList secondLevelHierarchyArr = new BasicDBList();
				BasicDBObject hud2 = new BasicDBObject();
				hud2.put(USERNAME_KEY, columns[GROUP_SLH_INDEX].trim());
				secondLevelHierarchyArr.add(hud2);
				hierarchy.put(SLH_KEY, secondLevelHierarchyArr);
			} else {
				if (StringUtils.isNotBlank(columns[GROUP_SLH_INDEX].trim())) {
					invalidDataList.add(INVALID_SLH_DATA);
				}
			}
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#validateHierarchyDetails()", e);
			throw new CommunicatorException("Exception in BulkProcessUtility#validateHierarchyDetails()", e);
		}
	}

	/**
	 * This method is used validates user data
	 * 
	 * @param columns
	 * @param hierarchy
	 * @param soeId
	 * @param invalidDataList
	 * @throws CommunicatorException
	 */
	private void validateGrpManager(String[] columns, BasicDBObject hierarchy, String soeId,
			BasicDBList invalidDataList) throws CommunicatorException {
		try {

			/* Sixth column is third level hierarchy */
			UserTO userDetails = validateUser(columns[GROUP_TLH_INDEX].trim(), soeId);
			if (userDetails != null) {
				BasicDBList thirdLevelHierarchyArr = new BasicDBList();
				BasicDBObject hud3 = new BasicDBObject();
				hud3.put(USERID_KEY, userDetails.getUserId());
				hud3.put(USERNAME_KEY, userDetails.getUserName());
				thirdLevelHierarchyArr.add(hud3);
				hierarchy.put(TLH_KEY, thirdLevelHierarchyArr);
			} else {
				if (StringUtils.isNotBlank(columns[GROUP_TLH_INDEX].trim())) {
					invalidDataList.add(INVALID_TLH_DATA);
				}
			}
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#validateGrpManager()", e);
			throw new CommunicatorException("Exception in BulkProcessUtility#validateGrpManager()", e);
		}
	}

	/**
	 * This method us used to validate user
	 * 
	 * @param userId
	 * @param soeId
	 * @return UserTo
	 * @throws CommunicatorException
	 */
	private UserTO validateUser(String userId, String soeId) throws CommunicatorException {
		UserTO userDetails = null;
		try {
			if (StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(soeId)) {
				BasicDBObject inputJsonObj = BasicDBObject.parse("{\"userId\":\"" + userId + "\"}");
				userDetails = userDAO.getUserData(soeId, inputJsonObj);
			}
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#validateUser()", e);
			throw new CommunicatorException("Exception in BulkProcessUtility#validateUser()", e);
		}
		return userDetails;
	}

	/**
	 * This method validates management hierarchy input from file with database
	 * 
	 * @param validationType
	 * @param value
	 * @param managementHeirarchyDB
	 * @return boolean
	 * @throws CommunicatorException
	 */
	private boolean validateManagementHeirarchyWithDB(String validationType, String value,
			ManagementHeirarchy managementHeirarchyDB) throws CommunicatorException {
		boolean flag = false;
		if (StringUtils.isNotBlank(validationType) && StringUtils.isNotBlank(value) && managementHeirarchyDB != null) {

			switch (validationType) {
			case BUSINESS_UNIT:
				flag = validateData(managementHeirarchyDB.getOrganisation(), value);
				break;
			case FIRST_LEVEL_HRCHY:
				flag = validateHierarchyData(managementHeirarchyDB.getFirstLevelHeirarchy(), value);
				break;
			case SECOND_LEVEL_HRCHY:
				flag = validateHierarchyData(managementHeirarchyDB.getSecondLevelHeirarchy(), value);
				break;
			case GFCID_KEY:
				flag = validateData(managementHeirarchyDB.getGfcid(), value);
				break;
			default:
				flag = false;
				break;
			}
		}
		return flag;
	}

	/**
	 * This method validates data from list of string
	 * 
	 * @param inputData
	 * @param value
	 * @return boolean
	 */
	boolean validateData(List<String> inputData, String value) throws CommunicatorException {
		if (inputData != null && !inputData.isEmpty() && StringUtils.isNotBlank(value)) {
			return processStrList(inputData, value);
		}
		return false;
	}

	/**
	 * This method finds value in a list of string
	 * 
	 * @param strList
	 * @param value
	 * @return boolean
	 */
	private boolean processStrList(List<String> strList, String value) {
		for (String currentStr : strList) {
			if (currentStr.equalsIgnoreCase(value)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * This method validates hierarchy data with given value
	 * 
	 * @param hudInputData
	 * @param value
	 * @return boolean
	 */
	boolean validateHierarchyData(List<HierarchyUserDetail> hudInputData, String value)
			throws CommunicatorException {
		if (hudInputData != null && !hudInputData.isEmpty() && StringUtils.isNotBlank(value)) {
			return processHUDList(hudInputData, value);
		}
		return false;
	}

	/**
	 * This method finds value in a list of HierarchyUserDetail
	 * 
	 * @param hudInputData
	 * @param value
	 * @return boolean
	 */
	private boolean processHUDList(List<HierarchyUserDetail> hudInputData, String value) {
		for (HierarchyUserDetail currentData : hudInputData) {
			if (currentData.getUserName().equalsIgnoreCase(value)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * This method creates BasicDBList from string array
	 * 
	 * @param strArr
	 * @return BasicDBList
	 */
	private BasicDBList getDBList(String[] strArr) {
		BasicDBList dbList = new BasicDBList();
		try {
			for (String currentStrItem : strArr) {
				dbList.add(currentStrItem.trim().toLowerCase());
			}
		} catch (Exception e) {
			subLogger.error("Exception in BulkProcessUtility#getDBList()", e);
		}
		return dbList;
	}

	/**
	 * This method is used to return the file response of provided
	 * file template type
	 * @param templateType
	 * @param soeId
	 * @return
	 * @throws CommunicatorException
	 * @throws IOException
	 */
	public ResponseBuilder getTemplateFile(String templateType, String soeId)
			throws CommunicatorException, IOException {
		File file = null;
		String fileName = "";
		try {
			subLogger.error("User :" + soeId + " requested for " + templateType + " template file.");
			if (TEMPLATE_TYPE_GROUP.equalsIgnoreCase(templateType)) {
				fileName = GROUP_TEMPLATE_FILENAME;
			} else if (TEMPLATE_TYPE_GFPCID.equalsIgnoreCase(templateType)) {
				fileName = GFPCID_TEMPLATE_FILENAME;
			} else if (TEMPLATE_TYPE_RTM.equalsIgnoreCase(templateType)) {
				fileName = RTM_TEMPLATE_FILENAME;
			}
			if (StringUtils.isNotBlank(fileName)) {
				file = new File(Thread.currentThread().getContextClassLoader().getResource(fileName).getFile());
				fileName = fileName.substring(fileName.indexOf('/')+1, fileName.length() );
			}
		} catch (Exception e) {
			subLogger.error("Exception while returning file template in BulkProcessUtility#getTemplateFile() : " + e);
			file = new File(DEFAULT_FILE_NAME);
		}
		return Response.ok((Object) file).header("Content-Disposition", "attachment; filename=" + fileName);
	}
	
	
	/**
	 * Main method used to upload request type mapping 
	 * @param args
	 */
	public static void main(String[] args) {
		boolean partialUpload = true;
		try {
			//processRTMFromMain(soeId, partialUpload, file);
		} catch (Exception e) {
			subLogger.error("ERROR :",e);
		} 
	}

	/**
	 * @param soeId
	 * @param partialUpload
	 * @param file
	 * @return
	 * @throws FileNotFoundException
	 * @throws CommunicatorException
	 */
	private static void processRTMFromMain(String soeId, boolean partialUpload, File file)
			throws FileNotFoundException, CommunicatorException {
		BasicDBObject dataMap = new BasicDBObject();
		try(FileInputStream fileInputStream = new FileInputStream(file);) {
			String fileInfo = file.getName();
			
			BulkProcessUtility utils = new BulkProcessUtility();
			dataMap = utils.generateRTMList(fileInputStream, RTM_UPLOAD_TYPE);
			if (dataMap.containsField(SUCCESS_KEY) && dataMap.getBoolean(SUCCESS_KEY)) {
				
				utils.initiateRtmOnboarding(dataMap, soeId, fileInfo, partialUpload);
				
				BasicDBObject rtmUploadResult = (BasicDBObject) dataMap.get(ONBOARDING_RESULT_KEY);
				BasicDBList successResult = (BasicDBList) rtmUploadResult.get(ONBOARDED_KEY);
				BasicDBList failureResult = (BasicDBList) rtmUploadResult.get(NON_ONBOARDED_KEY);
				subLogger.info("***************** SUCCESS RESULT *********************");
				for( int i=0;i < successResult.size(); i++){
					BasicDBObject obj = (BasicDBObject) successResult.get(i);
					subLogger.info(obj.getString(GROUP_NAME_KEY) + " : " + obj.getString(MESSAGE_KEY) );
				}
				
				subLogger.info("***************** FAILURE RESULT *********************");
				for( int i=0;i < failureResult.size(); i++){
					BasicDBObject obj = (BasicDBObject) failureResult.get(i);
					subLogger.info(obj.getString(GROUP_NAME_KEY) + " : " + obj.getString(MESSAGE_KEY) );
				}
				subLogger.info("***************** INVALID ENTRIES*********************");
				List<BasicDBObject> invalidRtmList = (List<BasicDBObject>) dataMap.get(INVALID_RTM_KEY);
				for( int i=0;i < invalidRtmList.size(); i++){
					BasicDBObject obj = (BasicDBObject) invalidRtmList.get(i);
					subLogger.info(obj.getString(INDEX_KEY)  + " : " + obj.getString(GROUP_NAME_KEY) + " : " + obj.getString(VALIDATION_FAILURE_KEY) );
				}
			}
		} catch (Exception e) {
			subLogger.error("Error :",e);
		} 
	}
	
	/**
	 * This function processes each row of a file and identifies between valid
	 * and invalid request type root cause mappings
	 * 
	 * @param fileInputStream
	 * @param type
	 * @return BasicDBObject
	 * @throws CommunicatorException
	 */
	private BasicDBObject generateRTRCMList(InputStream fileInputStream, String type) throws CommunicatorException {
		BasicDBObject rtrcmObjMap = new BasicDBObject();
		List<BasicDBObject> validRtRcmList = new ArrayList<>();
		List<BasicDBObject> invalidRtRcmList = new ArrayList<>();
		String rtrcmDataStr = "";
		try (Scanner scanner = new Scanner(fileInputStream)) {
			// first row is header of a file
			if (isValidFileContent(scanner.nextLine(), type)) {
				int index = 1;
				while (scanner.hasNextLine()) {
					rtrcmDataStr = scanner.nextLine();
					validateRtRcmInfo(rtrcmDataStr, validRtRcmList, invalidRtRcmList, ++index);
				}
				rtrcmObjMap.put(VALID_RTRCM_KEY, validRtRcmList);
				rtrcmObjMap.put(INVALID_RTRCM_KEY, invalidRtRcmList);
				rtrcmObjMap.put(SUCCESS_KEY, true);
				rtrcmObjMap.put(MESSAGE_KEY, SUCCESS_MESSAGE);
			} else {
				rtrcmObjMap.put(MESSAGE_KEY, INVALID_FILE_CONTENTS_MESSAGE);
				rtrcmObjMap.put(SUCCESS_KEY, false);
			}

		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#generateRTRCMList() : ", e);
			throw new CommunicatorException("Exception in BulkProcessUtility#generateRTRCMList() :", e);
		}
		return rtrcmObjMap;
	}
	
	/**
	 * This method validates column count for request type root cause mapping file
	 * @param columns
	 * @return boolean
	 */ 
	private boolean validateRtRcmFileContents(String[] columns) {
		if (columns.length == 0 || columns.length != NO_OF_COLS_FOR_RTRCM_FILE || !validateRtRcmFileHeaders(columns)) {
			return false;
		}
		return true;
	}
	
	/**
	 * This function validates request type root cause mapping file headers
	 * @param columns
	 * @return boolean
	 */
	private boolean validateRtRcmFileHeaders(String[] columns) {
		boolean validHeaders = true;
		if( !columns[RTRCM_GROUP_NAME_INDEX].trim().equalsIgnoreCase(RTRCM_GROUP_NAME_FILE_HEADER)) 
			return false;
		if( !columns[RTRCM_REQUEST_TYPE_INDEX].trim().equalsIgnoreCase(RTRCM_REQUEST_TYPE_FILE_HEADER)) 
			return false;
		if( !columns[RTRCM_ROOT_CAUSE_INDEX].trim().equalsIgnoreCase(RTRCM_ROOT_CAUSE_FILE_HEADER)) 
			return false;
		return validHeaders;
	}
	
	/**
	 * This method validates request type root cause mapping string from file and sends further for processing
	 * 
	 * @param rtrcmDataStr
	 * @param validRtRcmList
	 * @param invalidRtRcmList
	 * @param index
	 * @throws CommunicatorException
	 */
	private void validateRtRcmInfo(String rtrcmDataStr, List<BasicDBObject> validRtRcmList, List<BasicDBObject> invalidRtRcmList, int index) throws CommunicatorException {
		if (StringUtils.isNotBlank(rtrcmDataStr)) {
			try {
				createRtRcmObject(rtrcmDataStr, validRtRcmList, invalidRtRcmList, index);
			} catch (CommunicatorException e) {
				subLogger.error("Exception in BulkProcessUtility#validateRtRcmInfo() : ", e);
				throw new CommunicatorException("Exception in BulkProcessUtility#validateRtRcmInfo() :", e);
			}
		}
	}
	
	/**
	 * This method generates request type - root cause mapping object.
	 * 
	 * @param rtrcmDataStr
	 * @param validRtRcmList
	 * @param invalidRtRcmList
	 * @param index
	 * @throws CommunicatorException
	 */
	private void createRtRcmObject(String rtrcmDataStr, List<BasicDBObject> validRtRcmList,	List<BasicDBObject> invalidRtRcmList, int index) throws CommunicatorException {
		BasicDBObject rtrcmObj = new BasicDBObject();
		BasicDBList invalidDataList = new BasicDBList();
		BasicDBList validationDataList = new BasicDBList();
		String dataString = rtrcmDataStr;
		if (dataString.contains("'")) {
			dataString = dataString.replaceAll("'", "");
		}
		rtrcmObj.put(INDEX_KEY, index);
		String[] columns = dataString.split(EXCEL_COLUMN_SEPARATOR);
		if (columns.length == NO_OF_COLS_FOR_RTRCM_FILE) {
			String groupName = columns[RTRCM_GROUP_NAME_INDEX].trim();

			if (StringUtils.isNotBlank(groupName)) {
				validateRtRcmData(columns, rtrcmObj, validationDataList, invalidDataList, index);
			} else {
				invalidDataList.add(UNKNOWN_GROUP_DETAILS + index);
			}
			
			if (invalidDataList.isEmpty()) {
				rtrcmObj.put(VALIDATION_DATALIST_KEY, validationDataList);
				validRtRcmList.add(rtrcmObj);
			} else {
				rtrcmObj.put(VALIDATION_FAILURE_KEY, invalidDataList);
				invalidRtRcmList.add(rtrcmObj);
			}
		} else {
			addToInvalidRtRcmList(rtrcmObj, invalidDataList, invalidRtRcmList, index);
		}
	}
	
	/**
	 * This method adds invalid mappings to invalid data list 
	 * @param rtrcmObj
	 * @param invalidDataList
	 * @param invalidRtRcmList
	 * @param index
	 */
	private void addToInvalidRtRcmList(BasicDBObject rtrcmObj, BasicDBList invalidDataList,	List<BasicDBObject> invalidRtRcmList, int index) {
		invalidDataList.add(INCOMPLETE_GFCID_DETAILS + index);
		rtrcmObj.put(VALIDATION_FAILURE_KEY, invalidDataList);
		invalidRtRcmList.add(rtrcmObj);
	}
	
	/**
	 * This method validates request type - root cause mapping data
	 * 
	 * @param columns
	 * @param rtrcmObj
	 * @param validationDataList
	 * @param invalidDataList
	 * @param index
	 */
	private void validateRtRcmData(String[] columns, BasicDBObject rtrcmObj, BasicDBList validationDataList, BasicDBList invalidDataList, int index) {
		String groupName = columns[RTRCM_GROUP_NAME_INDEX].trim();
		rtrcmObj.put(GROUP_NAME_KEY, groupName);
		try {
			Group group = groupDAO.getGroupDataById(rtrcmObj);
			List<HighlevelRequestType> requestTypeMappings = group.getRequestTypeMappings();
			
			String requestType = columns[RTRCM_REQUEST_TYPE_INDEX].trim();
			String rootCauses = columns[RTRCM_ROOT_CAUSE_INDEX].trim();
			boolean validRequestType = validateRequestType(group, requestType, requestTypeMappings);
			boolean validRootCause = validateRootCause(group, rootCauses);
			
			if (group != null && validRequestType && validRootCause) {
				rtrcmObj.put(RTM_REQUEST_TYPE_KEY, requestType);
				rtrcmObj.put(RTRCM_ROOT_CAUSE_KEY, rootCauses);
				validationDataList.add("Valid data found");
			} else if (!validRequestType) {
				invalidDataList.add(INVALID_REQUEST_TYPE + index);
			} else if (!validRootCause) {
				invalidDataList.add(INVALID_ROOT_CAUSE + index);
			}
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#validateRtRcmData() while retrieveing group object for :" + groupName, e);
		}
	}

	/**
	 * Method to validate the request type has a mapping exist with high level request types.
	 * 
	 * @param group
	 * @param groupRequestType
	 * @param requestTypeMappings
	 * @return
	 */
	private boolean validateRequestType(Group group, String groupRequestType, List<HighlevelRequestType> requestTypeMappings) {
		boolean isValidRequestType = false;
		try {
			List<String> groupRequestTypes = group.getRequestTypes();
			if (null != groupRequestTypes && !groupRequestTypes.isEmpty() && StringUtils.isNotEmpty(groupRequestType)) {
				HighlevelRequestType highLevelRequestType = requestTypeMappings.stream()
						.filter(hlRequestType -> groupRequestType.equalsIgnoreCase(hlRequestType.getRequestType())).findAny()
						.orElse(null);
				if (null != highLevelRequestType && groupRequestTypes.contains(groupRequestType)) {
					isValidRequestType = true;
				}
			}
		} catch (Exception e) {
			subLogger.error("Error while validating request type with high level request type mapping in BulkProcessUtility#validateRequestType():" , e);
		}
		return isValidRequestType;
	}
	
	/**
	 * Method to validate the root cause with group root cause list.
	 * 
	 * @param group
	 * @param rootCauses
	 * @return
	 */
	private boolean validateRootCause(Group group, String rootCauses) {
		boolean isValidRootCause = false;
		try {
			List<String> groupRootCauses = group.getRootCauseList();
			if (null != groupRootCauses && !groupRootCauses.isEmpty() && StringUtils.isNotEmpty(rootCauses)) {
				List<String> rootCausesList = Arrays.stream(rootCauses.split(",")).collect(Collectors.toList());
				if (groupRootCauses.containsAll(rootCausesList)) {
					isValidRootCause = true;
				}
			}
		} catch (Exception e) {
			subLogger.error("Error while validating root cuase with group root cause list in BulkProcessUtility#validateRootCause():",	e);
		}
		return isValidRootCause;
	}
	
	/**
	 * This method initiates on-boarding of valid request type and root cause mapping
	 * @param dataMap
	 * @param soeId
	 * @param fileInfo
	 * @param partialUpload
	 */
	public void initiateRtRcmOnboarding(BasicDBObject dataMap, String soeId, String fileInfo, boolean partialUpload) {
		try {
			List<BasicDBObject> validRtRcmList = (List<BasicDBObject>) dataMap.get(VALID_RTRCM_KEY);
			List<BasicDBObject> invalidRtRcmList = (List<BasicDBObject>) dataMap.get(INVALID_RTRCM_KEY);
			if (!dataMap.isEmpty() && !validRtRcmList.isEmpty() && (validRtRcmList.isEmpty() || partialUpload)) {
				subLogger.info("User [" + soeId + " ] initiated bulk request type root cause mapping upload by uploading file : "+ fileInfo);
				BasicDBObject rtrcmUploadResult = uploadValidRtRcm(validRtRcmList, soeId);
				dataMap.put(RTCRCM_RESULT_KEY, rtrcmUploadResult);
			}
		} catch (CommunicatorException e) {
			subLogger.error("Exception in BulkProcessUtility#initiateRtRcmOnboarding() : " + e);
		}
	}
	
	/**
	 * This method on-boards request type root cause mappings for group.
	 * 
	 * @param rtrcmListToBeOnboarded
	 * @param soeId
	 * @return
	 * @throws CommunicatorException
	 */
	private BasicDBObject uploadValidRtRcm(List<BasicDBObject> rtrcmListToBeOnboarded, String soeId) throws CommunicatorException {
		BasicDBObject onboardingResult = new BasicDBObject();
		BasicDBList successOnboardList = new BasicDBList();
		BasicDBList alreadyExistsList = new BasicDBList();
		int newInsertCounter = 0;
		int alreadyExistsCounter = 0;
		try {
			subLogger.info("User " + soeId + " Initiated bulk upload for request type - root cause mapping.");
			String groupName = "";
			for (BasicDBObject rtrcmToBeUploaded : rtrcmListToBeOnboarded) {
				BasicDBObject saveResult = saveRtRcmData(rtrcmToBeUploaded);
				BasicDBObject rtrcmObj = new BasicDBObject();
				rtrcmObj.put(GROUP_NAME_KEY, rtrcmToBeUploaded.getString(GROUP_NAME_KEY));
				rtrcmObj.put(MESSAGE_KEY, saveResult.getString(MESSAGE_KEY));
				if (saveResult.getBoolean(SUCCESS_KEY)) {
					subLogger.info("Request type - Root cause mapping for group : " + rtrcmToBeUploaded.get(GROUP_NAME_KEY) + " Imported Successfully !!");
					successOnboardList.add(rtrcmObj);
					newInsertCounter++;
				} else {
					subLogger.info("Request type - Root cause mapping for group : " + rtrcmToBeUploaded.get(GROUP_NAME_KEY) + " Already exists or Invalid group Data");
					alreadyExistsList.add(rtrcmObj);
					alreadyExistsCounter++;
				}
			}
			onboardingResult.put(ONBOARDED_KEY, successOnboardList);
			onboardingResult.put(NON_ONBOARDED_KEY, alreadyExistsList);
			onboardingResult.put(NEW_INSERT_KEY, newInsertCounter);
			onboardingResult.put(ALREADY_EXISTS_KEY, alreadyExistsCounter);
		} catch (Exception e) {
			subLogger.error("Exception in BulkProcessUtility#uploadValidRtRcm() : " + e);
			throw new CommunicatorException("Exception in BulkProcessUtility#uploadValidRtRcm() : " + e);
		}
		return onboardingResult;
	}

	/**
	 * This method saves group level request type - root cause mappings.
	 * 
	 * @param mappingToBeSaved
	 * @return BasicDBObject
	 */
	private BasicDBObject saveRtRcmData(BasicDBObject mappingToBeSaved) {
		BasicDBObject result = new BasicDBObject();
		try {
			String groupName = mappingToBeSaved.getString(GROUP_NAME_KEY);
			UpdateOperations<Group> ops = mongoDatastore.createUpdateOperations(Group.class);
			Query<Group> updateQuery =  mongoDatastore.createQuery(Group.class).filter(GROUP_NAME_KEY, groupName);
			Group group = updateQuery.get();
			String requestType = mappingToBeSaved.getString(RTM_REQUEST_TYPE_KEY);
			String rootCauses = mappingToBeSaved.getString(RTRCM_ROOT_CAUSE_KEY);
			if (group != null && StringUtils.isNotEmpty(requestType) && StringUtils.isNotEmpty(rootCauses)) {	
				Map<String, List<String>> requestTypeRootCauseMapping = getGroupReqTypeRootCauseMappings(group,	requestType, rootCauses);
				ops.set("requestTypeRootCauseMapping", requestTypeRootCauseMapping);
				mongoDatastore.update(updateQuery, ops);
				result.put(MESSAGE_KEY, "Group request type - root cause mapping updated successfully.");
				result.put(SUCCESS_KEY, true);
			} else {
				result.put(MESSAGE_KEY, "Group not found in database.");
				result.put(SUCCESS_KEY, false);
			}
		} catch (Exception e) {
			result.put(MESSAGE_KEY, "Group not found in database.");
			result.put(SUCCESS_KEY, false);
			subLogger.error("Error while saving request type - root cause mapping data BulkProcessUtility#saveRtRcmData():", e);
		}
		return result;
	}

	/**
	 * Method to identifies the request type - root cause mapping.
	 * 
	 * @param group
	 * @param requestType
	 * @param rootCauses
	 * @return
	 */
	private Map<String, List<String>> getGroupReqTypeRootCauseMappings(Group group, String requestType,	String rootCauses) {
		Map<String, List<String>> requestTypeRootCauseMapping = group.getRequestTypeRootCauseMapping();
		List<String> rootCausesList = Arrays.stream(rootCauses.split(",")).collect(Collectors.toList());

		if (requestTypeRootCauseMapping == null) {
			requestTypeRootCauseMapping = new LinkedHashMap<>();
		}

		boolean mappingEntryFound = false;
		for (Map.Entry<String, List<String>> entry : requestTypeRootCauseMapping.entrySet()) {
			if (entry.getKey().equalsIgnoreCase(requestType) && entry.getValue().containsAll(rootCausesList)) {
				mappingEntryFound = true;
				break;
			}
		}

		if (!mappingEntryFound) {
			requestTypeRootCauseMapping.put(requestType, rootCausesList);
		}
		return requestTypeRootCauseMapping;
	}
	
	/**
	 * @param soeId
	 * @param partialUpload
	 * @param file
	 * @return
	 * @throws FileNotFoundException
	 * @throws CommunicatorException
	 */
	private static void processRTRCMFromMain(String soeId, boolean partialUpload, File file) throws FileNotFoundException, CommunicatorException {
		BasicDBObject dataMap = new BasicDBObject();
		try (FileInputStream fileInputStream = new FileInputStream(file);) {
			String fileInfo = file.getName();

			BulkProcessUtility utils = new BulkProcessUtility();
			dataMap = utils.generateRTRCMList(fileInputStream, RTRCM_UPLOAD_TYPE);
			if (dataMap.containsField(SUCCESS_KEY) && dataMap.getBoolean(SUCCESS_KEY)) {
				utils.initiateRtRcmOnboarding(dataMap, soeId, fileInfo, partialUpload);
				BasicDBObject rtrcmUploadResult = (BasicDBObject) dataMap.get(ONBOARDING_RESULT_KEY);
				BasicDBList successResult = (BasicDBList) rtrcmUploadResult.get(ONBOARDED_KEY);
				BasicDBList failureResult = (BasicDBList) rtrcmUploadResult.get(NON_ONBOARDED_KEY);
				
				subLogger.info("***************** SUCCESS RESULT *********************");
				for (int i = 0; i < successResult.size(); i++) {
					BasicDBObject obj = (BasicDBObject) successResult.get(i);
					subLogger.info(obj.getString(GROUP_NAME_KEY) + " : " + obj.getString(MESSAGE_KEY));
				}

				subLogger.info("***************** FAILURE RESULT *********************");
				for (int i = 0; i < failureResult.size(); i++) {
					BasicDBObject obj = (BasicDBObject) failureResult.get(i);
					subLogger.info(obj.getString(GROUP_NAME_KEY) + " : " + obj.getString(MESSAGE_KEY));
				}
				subLogger.info("***************** INVALID ENTRIES*********************");
				List<BasicDBObject> invalidRtRcmList = (List<BasicDBObject>) dataMap.get(INVALID_RTRCM_KEY);
				for (int i = 0; i < invalidRtRcmList.size(); i++) {
					BasicDBObject obj = (BasicDBObject) invalidRtRcmList.get(i);
					subLogger.info(obj.getString(INDEX_KEY) + " : " + obj.getString(GROUP_NAME_KEY) + " : "	+ obj.getString(VALIDATION_FAILURE_KEY));
				}
			}
		} catch (Exception e) {
			subLogger.error("Error :",e);
		} 
	}
}
