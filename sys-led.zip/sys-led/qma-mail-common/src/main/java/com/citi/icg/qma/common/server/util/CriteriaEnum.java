package com.citi.icg.qma.common.server.util;

public enum CriteriaEnum
{
	EQUALS("equals"), CONTAINS("contains"), BEGINSWITH("beginsWith"), ENDSWITH("endsWith");

	private String filterCriteria;

	private CriteriaEnum(String filterCriteria)
	{
		this.filterCriteria = filterCriteria;
	}

	public static CriteriaEnum fromString(String filterCriteria)
	{
		CriteriaEnum criteria = null;
		for (CriteriaEnum b : CriteriaEnum.values())
		{
			if (b.filterCriteria.equalsIgnoreCase(filterCriteria))
			{
				criteria = b;
				break;
			}
		}
		return criteria;
	}

	@Override
	public String toString()
	{
		return filterCriteria;
	}

}
