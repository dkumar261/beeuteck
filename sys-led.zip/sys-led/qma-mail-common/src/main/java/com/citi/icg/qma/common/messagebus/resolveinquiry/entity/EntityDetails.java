package com.citi.icg.qma.common.messagebus.resolveinquiry.entity;

public class EntityDetails {

	private String entityType;
	private String entityId;
	private String entityStatus;
	private String productFamily;
	private String description;
	
	public EntityDetails() {
		super();
		// Auto-generated constructor stub
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String getEntityId() {
		return entityId;
	}
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}
	public String getEntityStatus() {
		return entityStatus;
	}
	public void setEntityStatus(String entityStatus) {
		this.entityStatus = entityStatus;
	}
	public String getProductFamily() {
		return productFamily;
	}
	public void setProductFamily(String productFamily) {
		this.productFamily = productFamily;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "EntityDetails [entityType=" + entityType + ", entityId=" + entityId + ", entityStatus=" + entityStatus
				+ "]";
	}
	
}
