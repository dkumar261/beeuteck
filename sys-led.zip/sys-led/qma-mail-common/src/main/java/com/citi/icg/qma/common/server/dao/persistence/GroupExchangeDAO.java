package com.citi.icg.qma.common.server.dao.persistence;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.combine;
import static com.mongodb.client.model.Updates.set;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.ExchangeFolder;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.hazelcast.cache.client.HazelCastCacheIncrementalLoad;
import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.UpdateResult;

import dev.morphia.UpdateOptions;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;
import dev.morphia.query.UpdateResults;

public class GroupExchangeDAO extends MongoMorphiaDAO {

	private static final Logger logger = LoggerFactory.getLogger(GroupExchangeDAO.class);

	private static GroupExchangeDAO instance = null;

	private GroupExchangeDAO() { }

	public static synchronized GroupExchangeDAO getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		if (instance == null) {
			instance = new GroupExchangeDAO();
		}
		return instance;
	}

	public void saveExchangeFolders(String personalMailboxId, List<ExchangeFolder> folders, String rootFolderSyncState)
			throws CommunicatorException {
		try {
			Query<Group> query = mongoDatastore.createQuery(Group.class).filter("personalMailboxId", personalMailboxId);
			UpdateOperations<Group> ops = mongoDatastore.createUpdateOperations(Group.class).set("exchFolders",
					folders);
			if (StringUtils.isNotEmpty(rootFolderSyncState)) {
				ops.set("exchFolderHierarchySyncState", rootFolderSyncState);
			}
			UpdateResults result = mongoDatastore.update(query, ops);
			logger.info("update result : Updated[{}]", result.getUpdatedCount());
			logger.info("exchange folders replaced in Group of personalMailboxId[={}]", personalMailboxId);
			List<String> topLevelFolderNames = getTopLevelFolderNames(folders);
			updateTags(personalMailboxId, topLevelFolderNames);
		} catch (Exception e) {
			logger.error("Exception while replacing exchange groups in personal Group ", e);
			throw new CommunicatorException("Exception while replacing exchange groups in personal Group");
		}
	}

	public void updateTags(String personalMailboxId, List<String> topLevelFolderNames) {
		Query<Group> query = mongoDatastore.createQuery(Group.class).filter("personalMailboxId", personalMailboxId);
		UpdateOperations<Group> ops = mongoDatastore.createUpdateOperations(Group.class);
		ops.addToSet("tags", topLevelFolderNames);
		UpdateResults result = mongoDatastore.update(query, ops);
		logger.info("update result : Updated[{"+result.getUpdatedCount()+"}]");
	}
	
	public void updateEmailSyncState(String personalMailboxId, String exchEmailSyncState) {
		if (StringUtils.isNotEmpty(exchEmailSyncState)) {
			Query<Group> query = mongoDatastore.createQuery(Group.class).filter("personalMailboxId", personalMailboxId);
			UpdateOperations<Group> ops = mongoDatastore.createUpdateOperations(Group.class);
			ops.set("exchEmailSyncState", exchEmailSyncState);
			UpdateResults result = mongoDatastore.update(query, ops);
			if (result.getUpdatedCount()>0) {
				logger.info("For account[{}], updated the emailSyncState[{}]", personalMailboxId, exchEmailSyncState);				
			} else {
				logger.warn("No record found for account[{}]", personalMailboxId);
			}
		} else {
			logger.warn("The provided emailSyncState[{}] is invalid, please proivde correct value", exchEmailSyncState);
			
		}
		
	}

	private List<String> getTopLevelFolderNames(List<ExchangeFolder> folders) {
		List<String> tags = new ArrayList<String>();
		String inboxParentFolderId = null;
		for (ExchangeFolder folder : folders) {
			if ("Inbox".equalsIgnoreCase(folder.getDisplayName())) {
				inboxParentFolderId = folder.getParentFolderId();
				break;
			}
		}
		
		for (ExchangeFolder folder : folders) {
			if (inboxParentFolderId.equalsIgnoreCase(folder.getParentFolderId())) {
				tags.add(folder.getDisplayName());				
			}
		}
		return tags;
	}

//	public void saveExchangeFoldersUsingJavaDriver(String personalMailboxId, List<ExchangeFolder> folders, String rootFolderSyncState)
//			throws CommunicatorException {
//		try {
//			MongoCollection<Document> groupCollection = mongoDatastore.getDatabase().getCollection("Group");
//			Bson filter = eq("personalMailboxId", personalMailboxId);
//			//TODO: will have to convert each item into document or BSON compatble value to use this.  
//			//Can't find a codec for class com.citi.icg.qma.common.server.dao.ExchangeFolder.
//			Bson update = combine(set("exchFolders", folders), set("exchFolderHierarchySyncState", rootFolderSyncState));			
//			UpdateResult result = groupCollection.updateOne(filter, update);
//			logger.info("update result : Matched[{}], Updated[{}]", result.getMatchedCount(), result.getModifiedCount());
//			logger.info("exchange folders replaced in Group with personalMailboxId[={}]", personalMailboxId);
//		} catch (Exception e) {
//			logger.error("Exception while replacing exchange groups in personal Group ", e);
//			throw new CommunicatorException(e.getMessage());
//		}
//	}

	public Group getPersonalGroup(String personalMailboxId) {
		Query<Group> query = mongoDatastore.createQuery(Group.class).filter("personalMailboxId", personalMailboxId);
		Group group = query.get();
		return group;
	}

	public void addExchangeFolder(String personalMailboxId, ExchangeFolder folder) {
		try {
			Group group = getPersonalGroup(personalMailboxId);
			List<ExchangeFolder> folders = group.getExchFolders();
			if (Objects.isNull(folders)) {
				folders = new ArrayList<ExchangeFolder>();
				group.setExchFolders(folders);
			}
			Boolean isAlreadyPresent = false;
			for (ExchangeFolder exchangeFolder : folders) {
				if (exchangeFolder.getFolderId().equalsIgnoreCase(folder.getFolderId())) {
					isAlreadyPresent = true;
					break;
				}
			}
			if (!isAlreadyPresent) {
				folders.add(folder);
			}
			mongoDatastore.save(group);
			//addExchangeFolder
			HazelCastCacheIncrementalLoad.refreshGroupInCache(group.getId());
		} catch (Exception e) {
			logger.error(
					"Error in while updating inquiry workflow audit for decline in NLPSuggestionDAO#updateInquiryWorkFlowAuditInDB() : ",
					e);
		}
	}

//	db.Group.updateOne({"personalMailboxId" : "XXXXXX", "exchFolders.displayName" : "all-oasys"}, {$set : {"exchFolders.$.folderId" : "X1"}});
	public void updateFolder(String personalMailboxId, ExchangeFolder folderTO) {
		Query<Group> query = mongoDatastore.createQuery(Group.class).filter("personalMailboxId", personalMailboxId)
				.filter("exchFolders.folderId", folderTO.getFolderId());
		UpdateOperations<Group> ops = mongoDatastore.createUpdateOperations(Group.class);
//		ops.set("exchFolders.$", folderTO);
		if(null != folderTO.getDisplayName()) {
			ops.set("exchFolders.$.displayName", folderTO.getDisplayName());
		}
		if(null != folderTO.getParentFolderId()) {
			ops.set("exchFolders.$.parentFolderId", folderTO.getParentFolderId());
		}
		if(null != folderTO.getParentDisplayName()) {
			ops.set("exchFolders.$.parentDisplayName", folderTO.getParentDisplayName());
		}
		if(null != folderTO.getTotalCount()) {
			ops.set("exchFolders.$.totalCount", folderTO.getTotalCount());
		}
		if(null != folderTO.getUnreadCount()) {
			ops.set("exchFolders.$.unreadCount", folderTO.getUnreadCount());
		}
		if(null != folderTO.getChildFolderCount()) {
			ops.set("exchFolders.$.childFolderCount", folderTO.getChildFolderCount());
		}
		if(null != folderTO.getSyncState()) {
			ops.set("exchFolders.$.syncState", folderTO.getSyncState());
		}
		
		UpdateResults result = mongoDatastore.update(query, ops);
//		UpdateResults result = mongoDatastore.update(query, ops, new UpdateOptions().upsert(true));
		logger.info("FOLDER : Updated[{}] folder [{}] in database group collection for user : {}",result.getUpdatedCount(),folderTO.getDisplayName(),personalMailboxId);
	}

	public void updateFolderJD(String personalMailboxId, String folderId) {
		MongoCollection<Document> groupCollection = mongoDatastore.getDatabase().getCollection("Group");
		Bson filter = and(eq("personalMailboxId", personalMailboxId), eq("exchFolders.folderId", folderId));
		Bson update = Updates.set("exchFolders.$.displayName", "X2");
		UpdateResult result = groupCollection.updateOne(filter, update);
		logger.info("update result : Matched[{}], Updated[{}]", result.getMatchedCount(), result.getModifiedCount());
	}

//	db.Group.updateOne({"personalMailboxId": "XXXXXX"}, {$pull : { "exchFolders" : {"displayName" : "all-oasys"} } } );
	public void deleteFolder(String personalMailboxId, String folderId) {
		Query<Group> query = mongoDatastore.createQuery(Group.class).filter("personalMailboxId", personalMailboxId)
				.filter("exchFolders.folderId", folderId);
		UpdateOperations<Group> ops = mongoDatastore.createUpdateOperations(Group.class).removeAll("exchFolders",
				new BasicDBObject("folderId", folderId));
		
		UpdateResults result = mongoDatastore.update(query, ops);
		logger.info("update result : Updated[{"+result.getUpdatedCount()+"}]");
		logger.info("delete folderID:[{}] from group with personalMailboxId:[{}]", folderId, personalMailboxId);
	}

	// delete many
//	db.Group.updateOne({"personalMailboxId": "XXXXXX"}, {$pull : { "exchFolders" : {"displayName" : {$in: ["all-desktop-migration","sample messages"]}} } } );
	public void deleteFolders(String personalMailboxId, List<String> folderIdList) {
		Query<Group> query = mongoDatastore.createQuery(Group.class).filter("personalMailboxId", personalMailboxId);				
		BasicDBObject selectionCriteriaForFolders = new BasicDBObject("$in", folderIdList);
		UpdateOperations<Group> ops = mongoDatastore.createUpdateOperations(Group.class).removeAll("exchFolders",
				new BasicDBObject("displayName", selectionCriteriaForFolders));
		UpdateResults result = mongoDatastore.update(query, ops);
		logger.info("update result : Updated[{"+result.getUpdatedCount()+"}]");
		logger.info("delete folderID:[{}] from group with personalMailboxId:[{}]", folderIdList, personalMailboxId);
	}

	public static void main(String[] args) {

		try {
			GroupExchangeDAO dao = GroupExchangeDAO.getInstance();
			String personalMailboxId = "XXXXXX";

			String folderId = "all-workers";
//			dao.updateFolder(personalMailboxId , folderId );
//			dao.deleteFolder(personalMailboxId, folderId);

//			List<String> folderIdList = Arrays.asList("all-workers", "awards");
//			dao.deleteFolders(personalMailboxId, folderIdList);

//			dao.updateFolderJD(personalMailboxId, folderId);
			
			ExchangeFolder folderTO = new ExchangeFolder("AAMkAGZjZTMzZjlhLTExNzktNDI2My1iNDY1LTg3NGU0OTEyODEwNwAuAAAAAADcfDm1IUJUQpuW4bT/MYbfAQCoOtZssbfMS7WDTCDollCoAAAne7ktAAA=");
			folderTO.setDisplayName("James Reference");
			folderTO.setTotalCount(333);
			folderTO.setUnreadCount(44);
			folderTO.setParentFolderId("CCC");
			folderTO.setParentDisplayName("Creative");
			folderTO.setChildFolderCount(2);
			dao.updateFolder(personalMailboxId, folderTO);
			
			
		} catch (Exception e) {
			logger.error("App crashed", e);
		}
	}
	
	
}
