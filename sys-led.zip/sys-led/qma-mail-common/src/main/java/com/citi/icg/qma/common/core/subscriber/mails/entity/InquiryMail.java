package com.citi.icg.qma.common.core.subscriber.mails.entity;

import java.util.ArrayList;
import java.util.List;

import com.citi.icg.qma.common.core.subscriber.mails.InquiryAction;
import com.citi.icg.qma.common.core.subscriber.mails.InquiryState;

public final class InquiryMail
{
	private static final String SEPERATOR_KEY = "+++++++++++++++++++++++++++++++++++";

	private InquiryState state;
	private InquiryAction action;

	// Envelope elements
	private Envelope envelope;

	// Contents
	private List<Content> contents;

	// Attachments
	private List<Attachment> attachments;
	
	// Inline Attachments
	private List<Attachment> inLineAttachments;
	
	//Mail from YUDO
	private boolean isMailFromYudo;
	
	private Exception emailParsingException; 

	public InquiryMail()
	{
		contents = new ArrayList<>();
		attachments = new ArrayList<>();
		inLineAttachments = new ArrayList<>();
		envelope = new Envelope();
		isMailFromYudo = false;
	}

	public Envelope getEnvelope()
	{
		return envelope;
	}

	public List<Content> getContents()
	{
		return contents;
	}

	public List<Attachment> getAttachments()
	{
		return attachments;
	}

	public void setEnvelope(Envelope envelope)
	{
		this.envelope = envelope;
	}

	public void addContent(Content content)
	{
		contents.add(content);
	}

	public void addAttachment(Attachment attachment)
	{
		if(attachment != null)
		{
			attachments.add(attachment);
		}
	}
	
	public void addInLineAttachment(Attachment attachment)
	{
		if(attachment != null)
		{
			inLineAttachments.add(attachment);
		}
	}

	public InquiryState getState()
	{
		return state;
	}

	public void setState(InquiryState state)
	{
		this.state = state;
	}

	public InquiryAction getAction()
	{
		return action;
	}

	public void setAction(InquiryAction action)
	{
		this.action = action;
	}

	public boolean isNewMail()
	{
		boolean flag = false;
		List<String> referenceList = envelope.getReferenceIds();
		if (referenceList == null || referenceList.isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
		{
			flag = true;
		}
		return flag;
	}

	public boolean isMailFromYudo()
	{
		return isMailFromYudo;
	}

	public void setMailFromYudo(boolean isMailFromYudo)
	{
		this.isMailFromYudo = isMailFromYudo;
	}
	
	public List<Attachment> getInLineAttachments()
	{
		return inLineAttachments;
	}

	public void setInLineAttachments(List<Attachment> inLineAttachments)
	{
		this.inLineAttachments = inLineAttachments;
	}

	public Exception getEmailParsingException() {
		return emailParsingException;
	}

	public void setEmailParsingException(Exception emailParsingException) {
		this.emailParsingException = emailParsingException;
	}

}
