package com.citi.icg.qma.kafka;

import java.io.IOException;
import java.util.Properties;

import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.Session;
import jakarta.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

public class QmaEmailMessageKryoCodecForStorm extends com.esotericsoftware.kryo.Serializer<QmaEmailMessage> {
	
	private static final Logger log = LoggerFactory.getLogger(QmaEmailMessageKryoCodecForStorm.class);
			
	@Override
	public void write(Kryo kryo, Output output, QmaEmailMessage qmaEmailMessage) {
		try {
			output.writeString(qmaEmailMessage.getGuid());
			Message email = qmaEmailMessage.getMessage();				
			email.writeTo(output);
		} catch (IOException e) {
			log.error("Error while Serializing ", e);
		} catch (MessagingException e) {
			log.error("Error while Serializing ", e);
		}
	}

	@Override
	public QmaEmailMessage read(Kryo kryo, Input input, Class<? extends QmaEmailMessage> type) {
		QmaEmailMessage qmaEmailMessage = new QmaEmailMessage();
		String guid = input.readString();
		qmaEmailMessage.setGuid(guid);
		MimeMessage message = null;
		try {
			Properties props = new Properties();
			props.setProperty("mail.mime.address.strict", "false");
			props.setProperty("mail.mime.decodetext.strict", "false");
			Session session = Session.getDefaultInstance(props);				
			message = new MimeMessage(session, input);
			qmaEmailMessage.setMessage(message);
		} catch (Exception e) {
			log.error("Error while Serializing ", e);
		}
		return qmaEmailMessage;
	}





}
