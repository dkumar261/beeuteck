/**
 * 
 */
package com.citi.icg.qma.common.server.dao.persistence;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;

/**
 * 
 * @description: class manages all the service calls related to user
 *               entitlements
 */
public class UserEntitlementDAO extends MongoMorphiaDAO {

	private static final Logger log = LoggerFactory.getLogger(UserEntitlementDAO.class);
	private static final String FAILURE_MESSAGE ="Failed to retrieve user entitlements.";

	/**
	 * This method retrieves all the requested user entitlements for all groups
	 * 
	 * @param request
	 * @param soeId
	 * @return BasicDBObject
	 */
	public BasicDBObject getUserEntitlements(String soeId) {
		BasicDBObject responseObj  = new BasicDBObject();
		if(soeId != null) {
			responseObj = getAllUserEntitlements();
		} else {
			responseObj.put(AppserverConstants.SUCCESS_KEY, false);
			responseObj.put(AppserverConstants.MESSAGE_KEY, FAILURE_MESSAGE);
		}
		return responseObj;
	}

	private BasicDBObject getAllUserEntitlements() {
		BasicDBObject resultObj  = new BasicDBObject();
		try {
			Map<Long,List<String>> groupUserMap =  QMACacheFactory.getCache().getGroupIdToUserListMap();
		
		} catch (Exception e) {
			log.error("Error : "+e);
		}
		return resultObj;
	}

	public static void main(String[] args) {
		UserEntitlementDAO test = new UserEntitlementDAO();
		test.getAllUserEntitlements();
	}
}
