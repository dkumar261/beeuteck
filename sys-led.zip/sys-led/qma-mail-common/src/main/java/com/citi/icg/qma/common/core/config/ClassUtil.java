package com.citi.icg.qma.common.core.config;

import org.apache.commons.lang.ClassUtils;

import com.citi.icg.qma.common.core.exception.CommunicatorException;

/**
 * Generic Class lookup and instantiation unitl methods.
 */
public final class ClassUtil
{
	
	private ClassUtil(){
		//As this class is Util, so added making private constructor.
		//Sonar Fix -- Utility classes should not have public constructors 
	}
	/*
	 * Creates and instance of a class, and re-throwing checked
	 * class.newInstance exceptions as runtime Error.
	 */
	public static <T> T getInstance(Class<T> classToCreate) throws CommunicatorException // Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{		
		T instance = null;
		try
		{
			instance = classToCreate.newInstance();
		}
		catch (InstantiationException | IllegalAccessException e)
		{
			throw new CommunicatorException("Error creating instance of [" + classToCreate.getCanonicalName() + "]", e);
		}
		return instance;
	}

	/**
	 * Creates an instance of the class.
	 * 
	 * @param className
	 *            string representing the the class whose instance is to be
	 *            created.
	 * @return object representing the instance of the class.
	 */
	public static <T> T getInstanceFromName(String className, Class<T> baseType) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Class<?> clazzInstance = getClass(className);
		if (!baseType.isAssignableFrom(clazzInstance))
		{
			throw new CommunicatorException("Type [" + className + "] does not implement base type " + baseType.getClass().getName());
		}
		return (T) getInstance(clazzInstance);

	}

	/**
	 * Creates an instance of the class.
	 * 
	 * @param className
	 *            string representing the the class whose instance is to be
	 *            created.
	 * @return object representing the instance of the class.
	 */
	public static <T> T getInstanceFromName(String className) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Class<?> clazzInstance = getClass(className);
		return (T) getInstance(clazzInstance);	
	}

	/**
	 * Creates class.
	 * 
	 * @param className
	 *            string representing the the class to be created.
	 * @return generated class.
	 * @throws CommunicatorException 
	 */
	public static <T> Class<T> getClass(String className) throws CommunicatorException
	{
		try
		{
			return ClassUtils.getClass(className);
		}
		catch (ClassNotFoundException e)
		{
			throw new CommunicatorException("Error loading class name [" + className + "]", e);
		}
	}
}
