package com.citi.icg.qma.common.server.dao;

public enum InquiryFormMode
{
	NEW, READ, REPLY, REPLYALL, REASSIGN, REPLYRESOLVE, REPLYALLRESOLVE, MULTIACTION
}
