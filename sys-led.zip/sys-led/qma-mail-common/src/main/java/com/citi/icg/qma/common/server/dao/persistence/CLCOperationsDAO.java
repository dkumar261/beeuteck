
package com.citi.icg.qma.common.server.dao.persistence;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;


import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.core.util.CLCSocketFactory;
import com.citi.icg.qma.common.server.dao.CLCLinkedTrades;
import com.citi.icg.qma.common.server.dao.CLCLinkedTrades.CLCGroupData;
import com.citi.icg.qma.common.server.dao.CLCLinkedTrades.QMATradeRecord;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.UserActivities;
import com.citi.icg.qma.common.transferobject.ConversationTO;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

import dev.morphia.query.Query;


/**
 *  
 * DAO class to serve all data access operations for CLC
 * operations
 */
public class CLCOperationsDAO  extends MongoMorphiaDAO{


	private static final Logger subLogger = LoggerFactory.getLogger(CLCOperationsDAO.class);
	
	private static final String CLC_BODY_PARAM_FILTER_PARAMS = "filter_params";
	private static final String SEARCH_CRITERIA_CONTAINS_KEY = "contains";
	private static final String SEARCH_CRITERIA_IN_KEY = "in";
	private static final String SEARCH_CRITERIA_EQUALS_KEY = "equals";
	private static final String SEARCH_ID_KEY = "id";
	private static final String SEARCH_VALUE_KEY = "value";
	private static final String SEARCH_CONDITION_KEY = "condition";


	private static final String CLC_SETT_SEARCH_KEY = "clcSettDate";
	private static final String CLC_AMOUNT_KEY = "clcAmount";
	private static final String CLC_SOURCE_SEARCH_KEY = "clcSource";
	private static final String CLC_CLIENT_KEY = "clcClient";
	private static final String CLC_TRADE_DATE_SEARCH_KEY = "clcTradeDate";
	private static final String CLC_QUANTITY_KEY = "clcQuantity";
	private static final String CLC_SECURITY_KEY = "clcSecurity";
	private static final String TRADE_ID_KEY = "tradeId";
	private static final String CLC_TRADE_REF_OPTIONS_KEY = "tradeRefClcOption";
	private static final String CLC_SECURITY_OPTIONS_KEY= "securityClcOption";
	private static final String CLC_SEARCH_SID_OPTIONS_KEY = "sdiClcOption";
	private static final String CLC_SEARCH_SDI_KEY = "clcSdi";
	private static final String CLC_SEARCH_STATUS_KEY = "clcSearchStatus";
	private static final String CLC_RESULT_ROW_LIMIT_KEY= "clcResultRowLimit";
	private static final String CLC_GRID_PAGE_SIZE_LIMIT_KEY= "clcGridPageRecordCount";
	private static final String CLC_SEARCH_CLIENT_ID_KEY = "clientId";
	private static final String CLC_SEARCH_CLIENT_ID_OPTIONS_KEY = "clientIdOptions";
	
	private static final String COLUMN_FAIL_REASON = "Fail Reason";
	private static final String COLUMN_QTY_CON = "Qty Con";
	private static final String COLUMN_AMT_CON = "Amt Con";
	private static final String COLUMN_STATUS = "Status";
	private static final String COLUMN_BUY_SELL = "Buy/Sell";
	private static final String COLUMN_SETT_DATE = "Sett date";
	private static final String COLUMN_DATE_FORMAT = "{0:dd/MMM/yy h:mm:ss tt}";
	private static final String COLUMN_TRADE_DATE = "Trade Date";
	private static final String COLUMN_QTY_REMAINING = "Qty Remaining";
	private static final String COLUMN_AMT_REMAINING = "Amt Remaining";
	private static final String COLUMN_ISIN = "ISIN Code";
	private static final String COLUMN_CUSIP = "CUSIP Code";
	private static final String COLUMN_SEDOL = "SEDOL Code";
	private static final String COLUMN_SECURITY_NAME = "Security Name";
	private static final String COLUMN_SOURCE_SYSTEM = "Source System";
	private static final String COLUMN_TRADE_REF = "Trade Ref";
	private static final String COLUMN_CITI_TRADE_REF = "Citi Trade ID";
	private static final String COLUMN_ACCOUNT_NAME = "Account Name";
	private static final String COLUMN_SDI_LINE_1 = "SDI Line 1";
	private static final String COLUMN_SDI_LINE_2 = "SDI Line 2";
	private static final String COLUMN_SDI_LINE_3 = "SDI Line 3";
	private static final String COLUMN_GP_NAME = "GP name";
	private static final String COLUMN_GP_ID = "GPID";
	private static final String COLUMN_MG_ID = "MGID";
	private static final String COLUMN_COMMENTARY = "Commentary";
	private static final String COLUMN_TRAN_TYP = "Tran Type";
	private static final String COLUMN_IMS_NUMBER = "IMS number";
	private static final String COLUMN_CLIENT_MNEMONIC = "Client mnemonic";
	private static final String COLUMN_MCLE_ID = "MCLE id";
	private static final String COLUMN_ALERT_ACRONYM = "Alert acronym";
	
	private static final String COLUMN_TYPE_STRING = "string";
	private static final String SPACE_CHAR = "&nbsp;";

	private static final String CLC_SRNO_KEY = "srNo";
	private static final String CLC_ACCOUNT_NAME_KEY = "Acct Nm";
	private static final String CLC_SOURCE_KEY = "Src Sys";
	private static final String CLC_TRADE_REF_KEY = "Ops Trd Ref";
	private static final String CLC_CITI_TRADE_REF_KEY = "Ops Setl Trd Ref";
	private static final String CLC_SECURITY_NAME_KEY = "Issue Desc";
	private static final String CLC_CUSIP_CODE_KEY = "Cusip Code";
	private static final String CLC_ISIN_CODE_KEY = "Isin Code";
	private static final String CLC_SEDOL_CODE_KEY = "Sedol Code";
	private static final String CLC_AMOUNT_REMAINING_KEY = "Amt Remn";
	private static final String CLC_QUANTITY_REMAINING_KEY = "Qty Remn";
	private static final String CLC_TRADE_DATE_KEY = "Trd Dt";
	private static final String CLC_SETT_DATE_KEY = "Con_Setl_Dt";
	private static final String CLC_BUY_SELL_KEY = "Buy Sell";
	private static final String CLC_STATUS_KEY = COLUMN_STATUS;
	private static final String CLC_AMOUNT_CON_KEY = "Con Amt";
	private static final String CLC_QUANTITY_CON_KEY = "Con Qty";
	private static final String CLC_FAIL_REASON_KEY = "Fail Evnt Typ";
	private static final String CLC_SECURITY_OPTION_CUSIP_KEY = "CUSIP";
	private static final String CLC_SECURITY_OPTION_ISIN_KEY = "ISIN";
	private static final String CLC_SECURITY_OPTION_SEDOL_KEY = "SEDOL";
	private static final String CLC_SDI_LINE_1_KEY = "Sdi Line 1";
	private static final String CLC_SDI_LINE_2_KEY = "Sdi Line 2";
	private static final String CLC_SDI_LINE_3_KEY = "Sdi Line 3";
	private static final String CLC_GP_NAME_KEY = "Grand Parent Name";
	private static final String CLC_GP_ID_KEY = "Gp Number";
	private static final String CLC_MG_ID_KEY = "Mg Number";
	private static final String CLC_COMMENTARY_KEY = "Comm";
	private static final String CLC_TRAN_TYP_KEY = "Tran Typ";
	
	private static final String CLC_ACCOUNT_NAME_UI_KEY = "accountName";
	private static final String CLC_TRADE_REF_UI_KEY = "tradeRef";
	private static final String CLC_CITI_TRADE_REF_UI_KEY = "citiTradeRef";
	private static final String CLC_SECURITY_NAME_UI_KEY = "securityName";
	private static final String CLC_SOURCE_SYSTEM_UI_KEY = "sourceSystem";
	private static final String CLC_CUSIP_CODE_UI_KEY = "cusip";
	private static final String CLC_ISIN_CODE_UI_KEY = "isin";
	private static final String CLC_SEDOL_CODE_UI_KEY = "sedol";
	private static final String CLC_AMOUNT_REMAINING_UI_KEY = "amtRemaining";
	private static final String CLC_QUANTITY_REMAINING_UI_KEY = "qtyRemaining";
	private static final String CLC_TRADE_DATE_UI_KEY = "tradeDate";
	private static final String CLC_SETT_DATE_UI_KEY = "settDate"; 
	private static final String CLC_BUY_SELL_UI_KEY = "buySell";
	private static final String CLC_STATUS_UI_KEY = "status";
	private static final String CLC_AMOUNT_CON_UI_KEY = "conAmount";
	private static final String CLC_QUANTITY_CON_UI_KEY = "conQuantity";
	private static final String CLC_FAIL_REASON_UI_KEY = "failReason";
	private static final String CLC_SDI1_UI_KEY = "sdi1";
	private static final String CLC_SDI2_UI_KEY = "sdi2";
	private static final String CLC_SDI3_UI_KEY = "sdi3";
	private static final String CLC_GP_NAME_UI_KEY = "gpName";
	private static final String CLC_GP_ID_UI_KEY = "gpId";
	private static final String CLC_MG_ID_UI_KEY = "mgId";
	private static final String CLC_COMMENTARY_UI_KEY = "commentary";
	private static final String CLC_TRAN_TYP_UI_KEY = "tranType";
	private static final String CLIENT_ID_OPTION_IMS_NUMBER_UI_KEY = "imsNumber";
	private static final String CLIENT_ID_OPTION_CLIENT_MNEM_UI_KEY = "clntMnem";
	private static final String CLIENT_ID_OPTION_MCLEID_UI_KEY = "mcleId";
	private static final String CLIENT_ID_OPTION_ALERT_UI_KEY = "alertAcronym";
	
	private static final String CT_APPLICATION_JSON_KEY = "application/json";
	private static final String CONTENT_TYPE_KEY = "Content-Type";
	private static final String USER_TYPE_KEY = "userType";
	private static final String REPORT_TYPE_ID_KEY = "report_type_id";
	private static final String PAGE_SIZE_KEY = "page_size";
	private static final String PAGE_INDEX_KEY = "page_index";
	private static final String REQUEST_KEY = "request";
	private static final String QMA_USER_PASS_KEY = "qmaUserPassword";
	private static final String QMA_USER_ID_KEY = "qmaUserId";
	private static final String USER_ID_KEY = "userId";
	private static final String USER_PASS_KEY = "userPassword";
	private static final String AUTH_PARAMS_KEY = "authParams";
	private static final String SERVICE_ID_KEY = "serviceId";
	private static final String COLUMN_DEF_KEY = "columnDef";
	private static final String CLC_SEARCH_ENDPOINT_URL_KEY = "clcSearchEndpointUrl";
	private static final String REQUEST_PARAMS_KEY = "requestParams";
	private static final String CERT_CONF_KEY = "certConf";
	private static final String CERT_FILENAME_KEY = "certFileName";
	private static final String SELECTABLE_KEY = "selectable";
	private static final String CLIENT_KEY = "client";
	private static final String SECURITY_KEY = "security";
	private static final String CONFIG_CLC_CONFIGURATION_KEY = "clcConfiguration";
	private static final String ROW_RESULT_ZERO = "0";
	
	private static final String STATUS_OPTIONS_KEY = "statusOptions";
	private static final String SDI_OPTIONS_KEY = "sdiOptions";
	private static final String SECURITY_OPTIONS_KEY = "securityOptions";
	private static final String SOURCE_OPTIONS_KEY = "sourceOptions";
	private static final String TRADE_REF_OPTIONS_KEY = "tradeRefOptions";

	private static final String WIDTH_KEY = "width";
	private static final String TEMPLATE_KEY = "template";
	private static final String TYPE_KEY = "type";
	private static final String TITLE_KEY = "title";
	private static final String FORMAT_KEY = "format";
	private static final String FIELD_KEY = "field";
	
	private static final String CLC_SEARCH_FAILURE = "Failed to make CLC search request";
	private static final String CLC_SEARCH_SUCCESS = "CLC Search result retrieved successfully";

	private static final String CLC_RESULT_DATA_KEY = "data";
	private static final String CLC_RESULT_TOTAL_ROWS_KEY = "totalRows";
	private static final String GROUP_ID_KEY = "groupId";
	private static final String INQUIRY_ID_KEY = "inquiryId";
	
	private static final UserActivitiesDAO user_Activities_Dao = new UserActivitiesDAO();

	private static final String CLIENT_ID_OPTION_IMS_NUMBER_KEY = "Ctp Acct Nbr Ims";

	private static final String CLIENT_ID_OPTION_CLIENT_MNEM_KEY = "Clnt Mnem";

	private static final String CLIENT_ID_OPTION_GPID_KEY = "Gp Number";

	private static final String CLIENT_ID_OPTION_MGID_KEY = "Mg Number";

	private static final String CLIENT_ID_OPTION_MCLEID_KEY = "MCLE";

	private static final String CLIENT_ID_OPTION_ALERT_KEY = "Alert Acronym";

	private static final String CLIENTID_OPTIONS_KEY = "clientIdOptions";
	private static final String SOE_ID="soeId";
	private static final String ACTION_SOURCE="actionSource";
	private static final String ACTION="action";
	private static final String SERVICE_NOT_AVAILABLE="Service not available at the moment, Please contact Support.";
	/**
	 * This function validates search parameters and initiates CLC search
	 * @param request
	 * @param soeId
	 * @return BasicDBObject
	 */
	public BasicDBObject clcSearchAll(String request, String soeId) {
		BasicDBObject response = new BasicDBObject();
		try {
			subLogger.info("User :{} initiated CLC search with data :{}", soeId, request);
			BasicDBObject inputSearchObj = BasicDBObject.parse(request);
			validateSearchParams(inputSearchObj);
			response = initiateCLCSearchResult(inputSearchObj, soeId);
		} catch (Exception e) {
			subLogger.error("Error in GenericDAO#performCLCSearch() : ", e);
			response.put(AppserverConstants.MESSAGE_KEY, CLC_SEARCH_FAILURE);
			response.put(AppserverConstants.SUCCESS_KEY, false);
		}
		return response;
	}

	/**
	 * This method validates search parameters
	 * @param inputSearchObj
	 */
	private void validateSearchParams(BasicDBObject inputSearchObj) {
		inputSearchObj.put(TRADE_ID_KEY,
				null != inputSearchObj.get(TRADE_ID_KEY) ? inputSearchObj.get(TRADE_ID_KEY) : "");
		inputSearchObj.put(CLC_SECURITY_KEY,
				null != inputSearchObj.get(CLC_SECURITY_KEY) ? inputSearchObj.get(CLC_SECURITY_KEY) : "");
		inputSearchObj.put(CLC_QUANTITY_KEY,
				null != inputSearchObj.get(CLC_QUANTITY_KEY) ? inputSearchObj.get(CLC_QUANTITY_KEY) : "");
		inputSearchObj.put(CLC_TRADE_DATE_SEARCH_KEY, null != inputSearchObj.get(CLC_TRADE_DATE_SEARCH_KEY)
				? inputSearchObj.get(CLC_TRADE_DATE_SEARCH_KEY) : "");
		inputSearchObj.put(CLC_CLIENT_KEY,
				null != inputSearchObj.get(CLC_CLIENT_KEY) ? inputSearchObj.get(CLC_CLIENT_KEY) : "");
		inputSearchObj.put(CLC_SOURCE_SEARCH_KEY,
				null != inputSearchObj.get(CLC_SOURCE_SEARCH_KEY) ? inputSearchObj.get(CLC_SOURCE_SEARCH_KEY) : "");
		inputSearchObj.put(CLC_AMOUNT_KEY,
				null != inputSearchObj.get(CLC_AMOUNT_KEY) ? inputSearchObj.get(CLC_AMOUNT_KEY) : "");
		inputSearchObj.put(CLC_SETT_SEARCH_KEY,
				null != inputSearchObj.get(CLC_SETT_SEARCH_KEY) ? inputSearchObj.get(CLC_SETT_SEARCH_KEY) : "");
		inputSearchObj.put(CLC_TRADE_REF_OPTIONS_KEY,
				null != inputSearchObj.get(CLC_TRADE_REF_OPTIONS_KEY) ? inputSearchObj.get(CLC_TRADE_REF_OPTIONS_KEY) : "");
		inputSearchObj.put(CLC_SECURITY_OPTIONS_KEY,
				null != inputSearchObj.get(CLC_SECURITY_OPTIONS_KEY) ? inputSearchObj.get(CLC_SECURITY_OPTIONS_KEY) : "");
		inputSearchObj.put(CLC_SEARCH_STATUS_KEY,
				null != inputSearchObj.get(CLC_SEARCH_STATUS_KEY) ? inputSearchObj.get(CLC_SEARCH_STATUS_KEY) : "");
		inputSearchObj.put(CLC_RESULT_ROW_LIMIT_KEY,
				null != inputSearchObj.get(CLC_RESULT_ROW_LIMIT_KEY) ? inputSearchObj.get(CLC_RESULT_ROW_LIMIT_KEY) : "");
		inputSearchObj.put(CLC_SEARCH_SID_OPTIONS_KEY,
				null != inputSearchObj.get(CLC_SEARCH_SID_OPTIONS_KEY) ? inputSearchObj.get(CLC_SEARCH_SID_OPTIONS_KEY) : "");
		inputSearchObj.put(CLC_SEARCH_SDI_KEY,
				null != inputSearchObj.get(CLC_SEARCH_SDI_KEY) ? inputSearchObj.get(CLC_SEARCH_SDI_KEY) : "");
		
		subLogger.info("Validated all search parameters accepted from UI");
	}

	
	/**
	 * This method initiates a web service call to CLC end-point
	 * @param inputSearchObj
	 * @return BasicDBObject
	 */
	private BasicDBObject initiateCLCSearchResult(BasicDBObject inputSearchObj, String soeId) {
		BasicDBObject response = new BasicDBObject();
		try {
			response = getSearchData(inputSearchObj, soeId);
		} catch (Exception e) {
			subLogger.error("Error in GenericDAO#initiateCLCSearchResult() : ", e);
			response.put(AppserverConstants.MESSAGE_KEY, CLC_SEARCH_FAILURE);
			response.put(AppserverConstants.SUCCESS_KEY, false);
		}
		return response;
	}

	/**
	 * This method adds search result and column definition for CLC in result
	 * @param inputSearchObj
	 * @return BasicDBObject
	 */
	private BasicDBObject getSearchData(BasicDBObject inputSearchObj, String soeId) {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBList resultList = getCLCSearchResult(inputSearchObj, soeId);
			if(!resultList.isEmpty()) {
				BasicDBObject obj = (BasicDBObject) resultList.get(0);
				if(null==obj.getString(AppserverConstants.MESSAGE_KEY)){
					BasicDBList columnList = getCLCSearchColumnList();
					response.put("clcGridData", resultList);
					response.put("clcColumnDef", columnList);
					response.put(AppserverConstants.MESSAGE_KEY, CLC_SEARCH_SUCCESS);
					response.put(AppserverConstants.SUCCESS_KEY, true);
				} else {
					response.put(AppserverConstants.MESSAGE_KEY, obj.getString(AppserverConstants.MESSAGE_KEY));
					response.put(AppserverConstants.SUCCESS_KEY, false);
				}
			} else {
				response.put(AppserverConstants.MESSAGE_KEY, CLC_SEARCH_FAILURE);
				response.put(AppserverConstants.SUCCESS_KEY, false);
			}
			
		} catch (Exception e) {
			subLogger.error("Error in CLCOperationsDAO#getSearchData() : ", e);
			response.put(AppserverConstants.MESSAGE_KEY, CLC_SEARCH_FAILURE);
			response.put(AppserverConstants.SUCCESS_KEY, false);
		}
		return response;
	}


	/**
	 * This method calls a method to get CLC search result and process the result.
	 * @param inputSearchObj
	 * @return BasicDBList
	 * @throws CommunicatorException
	 */
	private BasicDBList getCLCSearchResult(BasicDBObject inputSearchObj, String soeId) throws CommunicatorException {
		BasicDBList clcSearchResult = new BasicDBList();
		try {
			BasicDBList searchParams = buildSearchParams(inputSearchObj);
			String pageSize = inputSearchObj.getString(CLC_RESULT_ROW_LIMIT_KEY);
			String actionSource = inputSearchObj.getString(ACTION_SOURCE);
			String inquiryId = inputSearchObj.getString(INQUIRY_ID_KEY);
			String groupId = inputSearchObj.getString(GROUP_ID_KEY);
			BasicDBObject userActivityObj = new BasicDBObject();
			if(!StringUtils.isEmpty(actionSource)){
				userActivityObj.put(ACTION_SOURCE, actionSource);
			} else {
				userActivityObj.put(ACTION_SOURCE, "CLC Search");
			}			
			userActivityObj.put(INQUIRY_ID_KEY, inquiryId);
			userActivityObj.put(GROUP_ID_KEY, groupId);
			String clcData = getCLCSearchData(searchParams,pageSize, soeId, userActivityObj);
			if(!StringUtils.isEmpty(clcData)) {
				processSearchResult(clcSearchResult, clcData);
			} else {
				BasicDBObject object = BasicDBObject.parse(clcData);
				clcSearchResult.add(object);
				subLogger.info("CLC Search retrieved is empty or null");
			}
		} catch (Exception e) {
			subLogger.error("Error in CLCOperationsDAO#getCLCSearchResult():",e);
		}
		return clcSearchResult;
	}

	/**
	 * This method processes search result
	 * @param clcSearchResult
	 * @param clcData
	 */
	private void processSearchResult(BasicDBList clcSearchResult, String clcData) {
		BasicDBObject resultObj = BasicDBObject.parse(clcData);
		BasicDBList dataList = (BasicDBList) resultObj.get(CLC_RESULT_DATA_KEY);
		if (null != dataList && !dataList.isEmpty()) {
			mapSearchResult(clcSearchResult, dataList);
		} else if(dataList == null && resultObj.getBoolean(AppserverConstants.SUCCESS_KEY)){
			subLogger.info("Response from CLC");
		} else if(dataList != null  && dataList.isEmpty() && resultObj.containsField(CLC_RESULT_TOTAL_ROWS_KEY) 
				&& ROW_RESULT_ZERO.equalsIgnoreCase(resultObj.getString(CLC_RESULT_TOTAL_ROWS_KEY))) {
			resultObj.put(AppserverConstants.MESSAGE_KEY, "No data found for provided search parameters");
		}
		if(null != resultObj.getString(AppserverConstants.MESSAGE_KEY)) {
			clcSearchResult.add(resultObj);
		}
	}

	/**
	 * This method extracts and maps search results.
	 * @param clcSearchResult
	 * @param dataList
	 */
	private void mapSearchResult(BasicDBList clcSearchResult, BasicDBList dataList) {
		try {
			int counter = 0;
			for (int i = 0; i < dataList.size(); i++) {
				BasicDBObject currentObj = (BasicDBObject) dataList.get(i);
				if (currentObj != null) {
					BasicDBObject obj = new BasicDBObject();
					obj.put(CLC_SRNO_KEY, counter++);
					obj.put(CLC_ACCOUNT_NAME_UI_KEY, processResponseDataString(currentObj.getString(CLC_ACCOUNT_NAME_KEY)));
					obj.put(CLC_CITI_TRADE_REF_UI_KEY, processResponseDataString(currentObj.getString(CLC_CITI_TRADE_REF_KEY)));
					obj.put(CLC_SOURCE_SYSTEM_UI_KEY, processResponseDataString(currentObj.getString(CLC_SOURCE_KEY)));
					obj.put(CLC_SEDOL_CODE_UI_KEY, processResponseDataString(currentObj.getString(CLC_SEDOL_CODE_KEY)));
					obj.put(CLC_TRADE_REF_UI_KEY, processResponseDataString(currentObj.getString(CLC_TRADE_REF_KEY)));
					obj.put(CLC_SECURITY_NAME_UI_KEY, processResponseDataString(currentObj.getString(CLC_SECURITY_NAME_KEY)));
					obj.put(CLC_CUSIP_CODE_UI_KEY, processResponseDataString(currentObj.getString(CLC_CUSIP_CODE_KEY)));
					obj.put(CLC_ISIN_CODE_UI_KEY, processResponseDataString(currentObj.getString(CLC_ISIN_CODE_KEY)));
					obj.put(CLC_SDI1_UI_KEY, processResponseDataString(currentObj.getString(CLC_SDI_LINE_1_KEY)));
					obj.put(CLC_SDI2_UI_KEY, processResponseDataString(currentObj.getString(CLC_SDI_LINE_2_KEY)));
					obj.put(CLC_SDI3_UI_KEY, processResponseDataString(currentObj.getString(CLC_SDI_LINE_3_KEY)));
					obj.put(CLC_GP_NAME_UI_KEY, processResponseDataString(currentObj.getString(CLC_GP_NAME_KEY)));
					obj.put(CLC_GP_ID_UI_KEY, processResponseDataString(currentObj.getString(CLC_GP_ID_KEY)));
					obj.put(CLC_MG_ID_UI_KEY, processResponseDataString(currentObj.getString(CLC_MG_ID_KEY)));
					obj.put(CLC_COMMENTARY_UI_KEY, processResponseDataString(currentObj.getString(CLC_COMMENTARY_KEY)));
					obj.put(CLC_AMOUNT_REMAINING_UI_KEY, parseExponentialValueToString(processResponseDataString(currentObj.getString(CLC_AMOUNT_REMAINING_KEY))));
					obj.put(CLC_QUANTITY_REMAINING_UI_KEY, parseExponentialValueToString(processResponseDataString(currentObj.getString(CLC_QUANTITY_REMAINING_KEY))));
					obj.put(CLC_TRADE_DATE_UI_KEY, processResponseDataString(currentObj.getString(CLC_TRADE_DATE_KEY)));
					obj.put(CLC_SETT_DATE_UI_KEY, processResponseDataString(currentObj.getString(CLC_SETT_DATE_KEY)));
					obj.put(CLC_BUY_SELL_UI_KEY, processResponseDataString(currentObj.getString(CLC_BUY_SELL_KEY)));
					obj.put(CLC_STATUS_UI_KEY, processResponseDataString(currentObj.getString(CLC_STATUS_KEY)));
					obj.put(CLC_AMOUNT_CON_UI_KEY, parseExponentialValueToString(processResponseDataString(currentObj.getString(CLC_AMOUNT_CON_KEY))));
					obj.put(CLC_QUANTITY_CON_UI_KEY, parseExponentialValueToString(processResponseDataString(currentObj.getString(CLC_QUANTITY_CON_KEY))));
					obj.put(CLC_FAIL_REASON_UI_KEY, processResponseDataString(currentObj.getString(CLC_FAIL_REASON_KEY)));
					obj.put(CLC_TRAN_TYP_UI_KEY, processResponseDataString(currentObj.getString(CLC_TRAN_TYP_KEY)));
					obj.put(CLIENT_ID_OPTION_IMS_NUMBER_UI_KEY, processResponseDataString(currentObj.getString(CLIENT_ID_OPTION_IMS_NUMBER_KEY)));
					obj.put(CLIENT_ID_OPTION_CLIENT_MNEM_UI_KEY, processResponseDataString(currentObj.getString(CLIENT_ID_OPTION_CLIENT_MNEM_KEY)));
					obj.put(CLIENT_ID_OPTION_MCLEID_UI_KEY, processResponseDataString(currentObj.getString(CLIENT_ID_OPTION_MCLEID_KEY)));
					obj.put(CLIENT_ID_OPTION_ALERT_UI_KEY, processResponseDataString(currentObj.getString(CLIENT_ID_OPTION_ALERT_KEY)));
					clcSearchResult.add(obj);
				}
			}
			subLogger.info("CLC result data mapped to columns for UI");
		} catch (Exception e) {
			subLogger.error("Error while mapping CLC search data to UI columns in CLCOperationsDAO:mapSearchResult() :", e);
		}
	}
	
	/**
	 * This method parses response data 
	 * @param data
	 * @return
	 */
	String processResponseDataString(String data){
		String processedData = data;
		if(!StringUtils.isEmpty(data)){
			processedData = processedData.replaceAll("<mark>", "").replaceAll("</mark>", "");
		}
		if(StringUtils.isEmpty(processedData)){
			processedData = "";
		}
		return processedData;
	}
	
	String parseExponentialValueToString( String value){
		String result = value;
		try {
			if(StringUtils.isNotEmpty(value)) {
				Double temp = Double.valueOf(value);
				DecimalFormat formatter = new DecimalFormat("0.00");
				result = formatter.format(temp);
			}
		} catch (Exception e) {
			subLogger.error("Error while parsing big decimal value :",e);
		}
		return result;
	}

	/**
	 * This method builds search parameter array for CLC search
	 * @param inputSearchObj
	 * @return BasicDBList
	 */
	private BasicDBList buildSearchParams(BasicDBObject inputSearchObj) {
		BasicDBList searchCriteria = new BasicDBList();
		if ( !StringUtils.isEmpty(inputSearchObj.getString(TRADE_ID_KEY)) && !StringUtils.isEmpty(inputSearchObj.getString(CLC_TRADE_REF_OPTIONS_KEY))) {
			if(COLUMN_CITI_TRADE_REF.equalsIgnoreCase(inputSearchObj.getString(CLC_TRADE_REF_OPTIONS_KEY))){
				searchCriteria.add(getSearchObj(CLC_CITI_TRADE_REF_KEY, inputSearchObj.getString(TRADE_ID_KEY),
						SEARCH_CRITERIA_CONTAINS_KEY));
			} else if(COLUMN_TRADE_REF.equalsIgnoreCase(inputSearchObj.getString(CLC_TRADE_REF_OPTIONS_KEY))){
				searchCriteria.add(getSearchObj(CLC_TRADE_REF_KEY, inputSearchObj.getString(TRADE_ID_KEY),
						SEARCH_CRITERIA_IN_KEY));
			}
		}

		if (!StringUtils.isEmpty(inputSearchObj.getString(CLC_SECURITY_KEY)) && !StringUtils.isEmpty(inputSearchObj.getString(CLC_SECURITY_OPTIONS_KEY))) {
			if(CLC_SECURITY_OPTION_CUSIP_KEY.equalsIgnoreCase(inputSearchObj.getString(CLC_SECURITY_OPTIONS_KEY))) {
				searchCriteria.add(getSearchObj(CLC_CUSIP_CODE_KEY, inputSearchObj.getString(CLC_SECURITY_KEY),
						SEARCH_CRITERIA_CONTAINS_KEY));
			} else if(CLC_SECURITY_OPTION_ISIN_KEY.equalsIgnoreCase(inputSearchObj.getString(CLC_SECURITY_OPTIONS_KEY))) {
				searchCriteria.add(getSearchObj(CLC_ISIN_CODE_KEY, inputSearchObj.getString(CLC_SECURITY_KEY),
						SEARCH_CRITERIA_CONTAINS_KEY));
			} else if(CLC_SECURITY_OPTION_SEDOL_KEY.equalsIgnoreCase(inputSearchObj.getString(CLC_SECURITY_OPTIONS_KEY))) {
				searchCriteria.add(getSearchObj(CLC_SEDOL_CODE_KEY, inputSearchObj.getString(CLC_SECURITY_KEY),
						SEARCH_CRITERIA_CONTAINS_KEY));
			}  
		}
		
		if (!StringUtils.isEmpty(inputSearchObj.getString(CLC_SEARCH_SDI_KEY)) && !StringUtils.isEmpty(inputSearchObj.getString(CLC_SEARCH_SID_OPTIONS_KEY))) {
			if(COLUMN_SDI_LINE_1.equalsIgnoreCase(inputSearchObj.getString(CLC_SEARCH_SID_OPTIONS_KEY))) {
				searchCriteria.add(getSearchObj(CLC_SDI_LINE_1_KEY, inputSearchObj.getString(CLC_SEARCH_SDI_KEY),
						SEARCH_CRITERIA_CONTAINS_KEY));
			} else if(COLUMN_SDI_LINE_2.equalsIgnoreCase(inputSearchObj.getString(CLC_SEARCH_SID_OPTIONS_KEY))) {
				searchCriteria.add(getSearchObj(CLC_SDI_LINE_2_KEY, inputSearchObj.getString(CLC_SEARCH_SDI_KEY),
						SEARCH_CRITERIA_CONTAINS_KEY));
			}  else if(COLUMN_SDI_LINE_3.equalsIgnoreCase(inputSearchObj.getString(CLC_SEARCH_SID_OPTIONS_KEY))) {
				searchCriteria.add(getSearchObj(CLC_SDI_LINE_3_KEY, inputSearchObj.getString(CLC_SEARCH_SDI_KEY),
						SEARCH_CRITERIA_CONTAINS_KEY));
			}
		}
		
		if (!StringUtils.isEmpty(inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_KEY)) && !StringUtils.isEmpty(inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_OPTIONS_KEY))) {
			if(COLUMN_IMS_NUMBER.equalsIgnoreCase(inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_OPTIONS_KEY))) {
				searchCriteria.add(getSearchObj(CLIENT_ID_OPTION_IMS_NUMBER_KEY, inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_KEY),
						SEARCH_CRITERIA_CONTAINS_KEY));
			} else if(COLUMN_CLIENT_MNEMONIC.equalsIgnoreCase(inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_OPTIONS_KEY))) {
				searchCriteria.add(getSearchObj(CLIENT_ID_OPTION_CLIENT_MNEM_KEY, inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_KEY),
						SEARCH_CRITERIA_CONTAINS_KEY));
			}  else if(COLUMN_GP_ID.equalsIgnoreCase(inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_OPTIONS_KEY))) {
				searchCriteria.add(getSearchObj(CLIENT_ID_OPTION_GPID_KEY, inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_KEY),
						SEARCH_CRITERIA_CONTAINS_KEY));
			}  else if(COLUMN_MG_ID.equalsIgnoreCase(inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_OPTIONS_KEY))) {
				searchCriteria.add(getSearchObj(CLIENT_ID_OPTION_MGID_KEY, inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_KEY),
						SEARCH_CRITERIA_CONTAINS_KEY));
			} else if(COLUMN_MCLE_ID.equalsIgnoreCase(inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_OPTIONS_KEY))) {
				searchCriteria.add(getSearchObj(CLIENT_ID_OPTION_MCLEID_KEY, inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_KEY),
						SEARCH_CRITERIA_CONTAINS_KEY));
			} else if(COLUMN_ALERT_ACRONYM.equalsIgnoreCase(inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_OPTIONS_KEY))) {
				searchCriteria.add(getSearchObj(CLIENT_ID_OPTION_ALERT_KEY, inputSearchObj.getString(CLC_SEARCH_CLIENT_ID_KEY),
						SEARCH_CRITERIA_CONTAINS_KEY));
			}
		}
		
		
		if (!StringUtils.isEmpty(inputSearchObj.getString(CLC_QUANTITY_KEY))) {
			searchCriteria.add(getSearchObj(CLC_QUANTITY_REMAINING_KEY, inputSearchObj.getString(CLC_QUANTITY_KEY),
					SEARCH_CRITERIA_EQUALS_KEY));
		}

		if (!StringUtils.isEmpty(inputSearchObj.getString(CLC_TRADE_DATE_SEARCH_KEY))) {
			searchCriteria.add(getSearchObj(CLC_TRADE_DATE_KEY, inputSearchObj.getString(CLC_TRADE_DATE_SEARCH_KEY),
					SEARCH_CRITERIA_EQUALS_KEY));
		}
		if (!StringUtils.isEmpty(inputSearchObj.getString(CLC_CLIENT_KEY))) {
			searchCriteria.add(getSearchObj(CLC_ACCOUNT_NAME_KEY, inputSearchObj.getString(CLC_CLIENT_KEY),
					SEARCH_CRITERIA_CONTAINS_KEY));
		}
		if (!StringUtils.isEmpty(inputSearchObj.getString(CLC_SOURCE_SEARCH_KEY))) {
			searchCriteria.add(getSearchObj(CLC_SOURCE_KEY, inputSearchObj.getString(CLC_SOURCE_SEARCH_KEY),
					SEARCH_CRITERIA_CONTAINS_KEY));
		}
		if (!StringUtils.isEmpty(inputSearchObj.getString(CLC_AMOUNT_KEY))) {
			searchCriteria.add(getSearchObj(CLC_AMOUNT_CON_KEY, inputSearchObj.getString(CLC_AMOUNT_KEY),
					SEARCH_CRITERIA_EQUALS_KEY));
		}
		if (!StringUtils.isEmpty(inputSearchObj.getString(CLC_SETT_SEARCH_KEY))) {
			searchCriteria.add(getSearchObj(CLC_SETT_DATE_KEY, inputSearchObj.getString(CLC_SETT_SEARCH_KEY),
					SEARCH_CRITERIA_EQUALS_KEY));
		}
		
		if (!StringUtils.isEmpty(inputSearchObj.getString(CLC_SEARCH_STATUS_KEY))) {
			searchCriteria.add(getSearchObj(CLC_STATUS_KEY, inputSearchObj.getString(CLC_SEARCH_STATUS_KEY),
					SEARCH_CRITERIA_EQUALS_KEY));
		}
		
		subLogger.info("Search parameters for CLC : {}", searchCriteria.toString());
		
		return searchCriteria;
	}

	/**
	 * This method creates an individual search parameter
	 * @param field
	 * @param value
	 * @param criteria
	 * @return
	 */
	BasicDBObject getSearchObj(String field, String value, String criteria) {
		BasicDBObject obj = new BasicDBObject();
		obj.put(SEARCH_ID_KEY, field);
		if(value != null) {
			String[] values = value.split(",");
			if(CLC_TRADE_REF_KEY.equalsIgnoreCase(field)){
				obj.put(SEARCH_VALUE_KEY, values);
				obj.put(SEARCH_CONDITION_KEY, SEARCH_CRITERIA_IN_KEY);
			} else {
				obj.put(SEARCH_VALUE_KEY, value);
				obj.put(SEARCH_CONDITION_KEY, criteria);
			}
		} else {
			obj.put(SEARCH_VALUE_KEY, value);
			obj.put(SEARCH_CONDITION_KEY, criteria);
		}
		return obj;
	}

	/**
	 * This method makes a synchronous rest call to searchAll service hosted by
	 * CLC and extract the response from it.
	 * @param searchParams
	 * @return String
	 */
	private String getCLCSearchData(BasicDBList searchParams, String pageSize, String soeId, BasicDBObject userActivityObj) {
		StringBuilder content = new StringBuilder();
		BasicDBObject responseResult = new BasicDBObject();
		try {
			HttpClient httpClient = getHttpClientForCLC();
			if( httpClient != null ) {
				HttpPost postRequest = new HttpPost(getClcConfigStringValues(CLC_SEARCH_ENDPOINT_URL_KEY));
				postRequest.addHeader(CONTENT_TYPE_KEY, CT_APPLICATION_JSON_KEY);
				StringEntity input = buildStringEntity(searchParams,pageSize);
				postRequest.setEntity(input);

				HttpResponse response = httpClient.execute(postRequest);
				
				if (response.getStatusLine().getStatusCode() != 200) {
					responseResult  = processResponseResult(response.getStatusLine().getStatusCode());
					content.append(responseResult.toJson());
				} else {
					HttpEntity entity = response.getEntity();
					content = extractSearchResponse(entity);
				}
			} else {
				responseResult.put(AppserverConstants.MESSAGE_KEY, SERVICE_NOT_AVAILABLE);
				responseResult.put(AppserverConstants.SUCCESS_KEY, false);
				content.append(responseResult.toJson());
			}
		} catch (Exception e) {
			subLogger.error("Error while making a call to CLC endpoint in CLCOperationsDAO#getCLCSearchData() :", e);
			responseResult.put(AppserverConstants.MESSAGE_KEY, SERVICE_NOT_AVAILABLE);
			responseResult.put(AppserverConstants.SUCCESS_KEY, false);
			content.append(responseResult.toJson());
		}
		return content.toString();
	}

	
	
	/**
	 * This method gets HTTP client for CLC
	 * @return
	 * @throws KeyStoreException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 */
	private HttpClient getHttpClientForCLC()
			throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
		
		HttpClient httpClient = null ;
		try {
			String certFileName = getCLCCertConfig(CERT_FILENAME_KEY);
			
			String xmcEnvironment = System.getProperty(AppserverConstants.ENV_PARAM_KEY);
			
			if(StringUtils.isNotEmpty(certFileName)) {
				SSLConnectionSocketFactory socketFactory = CLCSocketFactory.getInstance();
				if(null!= socketFactory) {
					httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).disableCookieManagement().build();
					subLogger.info("CLC :: Environment is :{} using two-way SSL enabled HttpClient.", xmcEnvironment);
				} 
			} else {
				subLogger.info("CLC :: Environment is :{} Not able to identify certificate paramteres from database.", xmcEnvironment);
				httpClient = HttpClientBuilder.create().build();
			} 
			 
		} catch (Exception e) {
			subLogger.error("CLC :: Error while creating http client in CLCOperationsDAO#getHttpClientSSLEnabled() : ",e);
		}
		return httpClient;
	}
	
	
	/**
	 * This method processes response code and specifies response message
	 * @param statusCode
	 * @return
	 * @throws CommunicatorException
	 */
	BasicDBObject processResponseResult(int statusCode) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		response.put(AppserverConstants.SUCCESS_KEY, true);
		if(statusCode == HttpStatus.SC_BAD_REQUEST) {
			/* Bad request */
			response.put(AppserverConstants.MESSAGE_KEY, "Please provide correct request parameters and try again.");
		} else if(statusCode == HttpStatus.SC_INTERNAL_SERVER_ERROR) {
			/* Bad request */
			response.put(AppserverConstants.MESSAGE_KEY, "Service is not available at the moment, Please try again later.");
		}  else if(statusCode == HttpStatus.SC_UNAUTHORIZED) {
			/* Bad request */
			response.put(AppserverConstants.MESSAGE_KEY, "Not authorized to make request, Please try again later.");
		} else {
			response.put(AppserverConstants.MESSAGE_KEY, "Service is not available at the moment, Please contact Support.");
		}
		return response;
	}
	/**
	 * This method processes response code and specifies response message
	 * @param statusCode
	 * @return
	 * @throws CommunicatorException
	 */
	BasicDBObject processResponseResultUsageStats(int statusCode) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		response.put(AppserverConstants.SUCCESS_KEY, false);
		if(statusCode == HttpStatus.SC_BAD_REQUEST) {
			/* Bad request */
			response.put(AppserverConstants.MESSAGE_KEY, "Please provide correct request parameters and try again.");
		} else if(statusCode == HttpStatus.SC_INTERNAL_SERVER_ERROR) {
			/* Bad request */
			response.put(AppserverConstants.MESSAGE_KEY, "Service is not available at the moment, Please try again later.");
		}  else if(statusCode == HttpStatus.SC_UNAUTHORIZED) {
			/* Bad request */
			response.put(AppserverConstants.MESSAGE_KEY, "Not authorized to make request, Please try again later.");
		} else {
			response.put(AppserverConstants.MESSAGE_KEY, "Service is not available at the moment, Please contact Support.");
		}
		return response;
	}
	/**
	 * This method builds a string entity in order to set parameters in method body
	 * @param searchParams
	 * @return StringEntity
	 * @throws UnsupportedEncodingException
	 */
	private StringEntity buildStringEntity(BasicDBList searchParams, String pageSize) throws UnsupportedEncodingException {
		
		BasicDBObject inputParams= new BasicDBObject();
		
		BasicDBObject request = new BasicDBObject();
		request.put(CLC_BODY_PARAM_FILTER_PARAMS, searchParams);
		request.put(PAGE_INDEX_KEY, getCLCRequestParams(PAGE_INDEX_KEY));
		if(!StringUtils.isEmpty(pageSize)) {
			request.put(PAGE_SIZE_KEY,pageSize);
		} else {
			request.put(PAGE_SIZE_KEY,getCLCRequestParams(PAGE_SIZE_KEY));
		}
		
		request.put(REPORT_TYPE_ID_KEY, getCLCRequestParams(REPORT_TYPE_ID_KEY));
		request.put(USER_TYPE_KEY, getCLCRequestParams(USER_TYPE_KEY));
		inputParams.put(REQUEST_KEY,request);

		BasicDBObject authParams = new BasicDBObject();
		authParams.put(USER_ID_KEY, getClcConfigStringValues(QMA_USER_ID_KEY));
		authParams.put(USER_PASS_KEY, getClcConfigStringValues(QMA_USER_PASS_KEY));
		
		inputParams.put(AUTH_PARAMS_KEY,authParams);
		
		inputParams.put(SERVICE_ID_KEY,getClcConfigStringValues(SERVICE_ID_KEY));
		
		
		return new StringEntity(inputParams.toJson());
	}

	/**
	 * This method extract the response received from the CLC search service
	 * @param content
	 * @param entity
	 * @throws IOException
	 */
	private StringBuilder extractSearchResponse( HttpEntity entity) throws IOException {
		StringBuilder content = new StringBuilder();
		byte[] buffer = new byte[1024];
		if (entity != null) {
			InputStream inputStream = entity.getContent();
			try(BufferedInputStream bis = new BufferedInputStream(inputStream)){
				int bytesRead = 0;
				while ((bytesRead = bis.read(buffer)) != -1) {
					String chunk = new String(buffer, 0, bytesRead);
					content.append(chunk);
				}
			} catch (Exception e) {
				subLogger.error(" Error in CLCOperationsDAO#extractSearchResponse() :", e);
			}
		}
		return content;
	}
	
	
	/**
	 * This method defines the column definition for CLC search grid on UI.
	 * @return BasicDBList
	 */
	private BasicDBList getCLCSearchColumnList() {
		BasicDBList columnList = new BasicDBList();
		BasicDBObject col1 = new BasicDBObject();
		col1.put(FIELD_KEY, CLC_SRNO_KEY);
		col1.put(FORMAT_KEY, null);
		col1.put(TITLE_KEY, SPACE_CHAR);
		col1.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col1.put(WIDTH_KEY, 30);
		col1.put(TEMPLATE_KEY, "");
		col1.put(SELECTABLE_KEY, true);
		columnList.add(col1);
		BasicDBObject col2 = new BasicDBObject();
		col2.put(FIELD_KEY, CLC_ACCOUNT_NAME_UI_KEY);
		col2.put(FORMAT_KEY, null);
		col2.put(TITLE_KEY, COLUMN_ACCOUNT_NAME);
		col2.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col2.put(WIDTH_KEY, 150);
		columnList.add(col2);
		BasicDBObject col3 = new BasicDBObject();
		col3.put(FIELD_KEY, CLC_TRADE_REF_UI_KEY);
		col3.put(FORMAT_KEY, null);
		col3.put(TITLE_KEY, COLUMN_TRADE_REF);
		col3.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col3.put(WIDTH_KEY, 120);
		columnList.add(col3);
		BasicDBObject col4 = new BasicDBObject();
		col4.put(FIELD_KEY, CLC_CITI_TRADE_REF_UI_KEY);
		col4.put(FORMAT_KEY, null);
		col4.put(TITLE_KEY, COLUMN_CITI_TRADE_REF);
		col4.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col4.put(WIDTH_KEY, 120);
		columnList.add(col4);
		BasicDBObject col5 = new BasicDBObject();
		col5.put(FIELD_KEY, CLC_SECURITY_NAME_UI_KEY);
		col5.put(FORMAT_KEY, null);
		col5.put(TITLE_KEY, COLUMN_SECURITY_NAME);
		col5.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col5.put(WIDTH_KEY, 160);
		columnList.add(col5);
		BasicDBObject col6 = new BasicDBObject();
		col6.put(FIELD_KEY, CLC_SOURCE_SYSTEM_UI_KEY);
		col6.put(FORMAT_KEY, null);
		col6.put(TITLE_KEY, COLUMN_SOURCE_SYSTEM);
		col6.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col6.put(WIDTH_KEY, 100);
		columnList.add(col6);
		BasicDBObject col7 = new BasicDBObject();
		col7.put(FIELD_KEY, CLC_CUSIP_CODE_UI_KEY);
		col7.put(FORMAT_KEY, null);
		col7.put(TITLE_KEY, COLUMN_CUSIP);
		col7.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col7.put(WIDTH_KEY, 100);
		columnList.add(col7);
		BasicDBObject col8 = new BasicDBObject();
		col8.put(FIELD_KEY, CLC_ISIN_CODE_UI_KEY);
		col8.put(FORMAT_KEY, null);
		col8.put(TITLE_KEY, COLUMN_ISIN);
		col8.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col8.put(WIDTH_KEY, 100);
		columnList.add(col8);
		BasicDBObject col9 = new BasicDBObject();
		col9.put(FIELD_KEY, CLC_SEDOL_CODE_UI_KEY);
		col9.put(FORMAT_KEY, null);
		col9.put(TITLE_KEY, COLUMN_SEDOL);
		col9.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col9.put(WIDTH_KEY, 100);
		columnList.add(col9);
		BasicDBObject col10 = new BasicDBObject();
		col10.put(FIELD_KEY, CLC_SDI1_UI_KEY);
		col10.put(FORMAT_KEY, null);
		col10.put(TITLE_KEY, COLUMN_SDI_LINE_1);
		col10.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col10.put(WIDTH_KEY, 120);
		columnList.add(col10);
		BasicDBObject col11 = new BasicDBObject();
		col11.put(FIELD_KEY, CLC_SDI2_UI_KEY);
		col11.put(FORMAT_KEY, null);
		col11.put(TITLE_KEY, COLUMN_SDI_LINE_2);
		col11.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col11.put(WIDTH_KEY, 120);
		columnList.add(col11);
		BasicDBObject col12 = new BasicDBObject();
		col12.put(FIELD_KEY, CLC_SDI3_UI_KEY);
		col12.put(FORMAT_KEY, null);
		col12.put(TITLE_KEY, COLUMN_SDI_LINE_3);
		col12.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col12.put(WIDTH_KEY, 120);
		columnList.add(col12);
		BasicDBObject col13 = new BasicDBObject();
		col13.put(FIELD_KEY, CLC_GP_NAME_UI_KEY);
		col13.put(FORMAT_KEY, null);
		col13.put(TITLE_KEY, COLUMN_GP_NAME);
		col13.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col13.put(WIDTH_KEY, 120);
		columnList.add(col13);
		BasicDBObject col14 = new BasicDBObject();
		col14.put(FIELD_KEY, CLC_GP_ID_UI_KEY);
		col14.put(FORMAT_KEY, null);
		col14.put(TITLE_KEY, COLUMN_GP_ID);
		col14.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col14.put(WIDTH_KEY, 100);
		columnList.add(col14);
		BasicDBObject col15 = new BasicDBObject();
		col15.put(FIELD_KEY, CLC_MG_ID_UI_KEY);
		col15.put(FORMAT_KEY, null);
		col15.put(TITLE_KEY, COLUMN_MG_ID);
		col15.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col15.put(WIDTH_KEY, 100);
		columnList.add(col15);
		BasicDBObject col16 = new BasicDBObject();
		col16.put(FIELD_KEY, CLC_COMMENTARY_UI_KEY);
		col16.put(FORMAT_KEY, null);
		col16.put(TITLE_KEY, COLUMN_COMMENTARY);
		col16.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col16.put(WIDTH_KEY, 150);
		columnList.add(col16);
		BasicDBObject col17 = new BasicDBObject();
		col17.put(FIELD_KEY, CLC_AMOUNT_REMAINING_UI_KEY);
		col17.put(FORMAT_KEY, null);
		col17.put(TITLE_KEY, COLUMN_AMT_REMAINING);
		col17.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col17.put(WIDTH_KEY, 100);
		columnList.add(col17);
		BasicDBObject col18 = new BasicDBObject();
		col18.put(FIELD_KEY, CLC_QUANTITY_REMAINING_UI_KEY);
		col18.put(FORMAT_KEY, null);
		col18.put(TITLE_KEY, COLUMN_QTY_REMAINING);
		col18.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col18.put(WIDTH_KEY, 100);
		columnList.add(col18);
		BasicDBObject col19 = new BasicDBObject();
		col19.put(FIELD_KEY, CLC_TRADE_DATE_UI_KEY);
		col19.put(FORMAT_KEY, COLUMN_DATE_FORMAT);
		col19.put(TITLE_KEY, COLUMN_TRADE_DATE);
		col19.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col19.put(WIDTH_KEY, 100);
		columnList.add(col19);
		BasicDBObject col20 = new BasicDBObject();
		col20.put(FIELD_KEY, CLC_SETT_DATE_UI_KEY);
		col20.put(FORMAT_KEY, COLUMN_DATE_FORMAT);
		col20.put(TITLE_KEY, COLUMN_SETT_DATE);
		col20.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col20.put(WIDTH_KEY, 100);
		columnList.add(col20);
		BasicDBObject col21 = new BasicDBObject();
		col21.put(FIELD_KEY, CLC_BUY_SELL_UI_KEY);
		col21.put(FORMAT_KEY, null);
		col21.put(TITLE_KEY, COLUMN_BUY_SELL);
		col21.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col21.put(WIDTH_KEY, 100);
		columnList.add(col21);
		BasicDBObject col22 = new BasicDBObject();
		col22.put(FIELD_KEY, CLC_STATUS_UI_KEY);
		col22.put(FORMAT_KEY, null);
		col22.put(TITLE_KEY, COLUMN_STATUS);
		col22.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col22.put(WIDTH_KEY, 100);
		columnList.add(col22);
		BasicDBObject col23 = new BasicDBObject();
		col23.put(FIELD_KEY, CLC_AMOUNT_CON_UI_KEY);
		col23.put(FORMAT_KEY, null);
		col23.put(TITLE_KEY, COLUMN_AMT_CON);
		col23.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col23.put(WIDTH_KEY, 100);
		columnList.add(col23);
		BasicDBObject col24 = new BasicDBObject();
		col24.put(FIELD_KEY, CLC_QUANTITY_CON_UI_KEY);
		col24.put(FORMAT_KEY, null);
		col24.put(TITLE_KEY, COLUMN_QTY_CON);
		col24.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col24.put(WIDTH_KEY, 100);
		columnList.add(col24);
		BasicDBObject col25 = new BasicDBObject();
		col25.put(FIELD_KEY, CLC_FAIL_REASON_UI_KEY);
		col25.put(FORMAT_KEY, null);
		col25.put(TITLE_KEY, COLUMN_FAIL_REASON);
		col25.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col25.put(WIDTH_KEY, 150);
		columnList.add(col25);
		BasicDBObject col26 = new BasicDBObject();
		col26.put(FIELD_KEY, CLC_TRAN_TYP_UI_KEY);
		col26.put(FORMAT_KEY, null);
		col26.put(TITLE_KEY, COLUMN_TRAN_TYP);
		col26.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col26.put(WIDTH_KEY, 100);
		columnList.add(col26);
		BasicDBObject col27 = new BasicDBObject();
		col27.put(FIELD_KEY, CLIENT_ID_OPTION_IMS_NUMBER_UI_KEY);
		col27.put(FORMAT_KEY, null);
		col27.put(TITLE_KEY, COLUMN_IMS_NUMBER);
		col27.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col27.put(WIDTH_KEY, 100);
		columnList.add(col27);
		BasicDBObject col28 = new BasicDBObject();
		col28.put(FIELD_KEY, CLIENT_ID_OPTION_CLIENT_MNEM_UI_KEY);
		col28.put(FORMAT_KEY, null);
		col28.put(TITLE_KEY, COLUMN_CLIENT_MNEMONIC);
		col28.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col28.put(WIDTH_KEY, 120);
		columnList.add(col28);
		BasicDBObject col29 = new BasicDBObject();
		col29.put(FIELD_KEY, CLIENT_ID_OPTION_MCLEID_UI_KEY);
		col29.put(FORMAT_KEY, null);
		col29.put(TITLE_KEY, COLUMN_MCLE_ID);
		col29.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col29.put(WIDTH_KEY, 120);
		columnList.add(col29);
		BasicDBObject col30 = new BasicDBObject();
		col30.put(FIELD_KEY, CLIENT_ID_OPTION_ALERT_UI_KEY);
		col30.put(FORMAT_KEY, null);
		col30.put(TITLE_KEY, COLUMN_ALERT_ACRONYM);
		col30.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col30.put(WIDTH_KEY, 120);
		columnList.add(col30);
		subLogger.info("CLC Search grid column list retrieved.");

		return columnList;
	}
	
	
	/**
	 * This method initiates linking of selected trades to an inquiry
	 * @param request
	 * @param soeId
	 * @param startTime 
	 * @return BasicDBObject
	 */
	public BasicDBObject initiateTradesLinkingToInquiry(String request, String soeId, long startTime) {
		BasicDBObject resultObj = new BasicDBObject();
		String actionSource = "Linked CLC Trades";
		try {
			BasicDBObject requestObj = BasicDBObject.parse(request);
			if( null != requestObj.get("selectedCLCTrades") && null != requestObj.get(INQUIRY_ID_KEY) && null != requestObj.get(GROUP_ID_KEY) ) {
				Long inquiryId = requestObj.getLong(INQUIRY_ID_KEY);
				Long groupId = requestObj.getLong(GROUP_ID_KEY);
				BasicDBList selectedTradesList = (BasicDBList) requestObj.get("selectedCLCTrades");
				if( inquiryId != null && groupId != null && selectedTradesList != null && !selectedTradesList.isEmpty() ) {
					BasicDBObject linkResult = linkTradeToInquiry(inquiryId, groupId, selectedTradesList, soeId, actionSource, startTime);
					resultObj = processResult(request, soeId, linkResult);
					resultObj.put(AppserverConstants.MESSAGE_KEY, "Trade Linking performed for InquiryId: "+ inquiryId + ", groupId :" + groupId + ", for trades :" + selectedTradesList);
					resultObj.put(AppserverConstants.SUCCESS_KEY, true);
				}
			} else {
				resultObj.put(AppserverConstants.MESSAGE_KEY, "Invalid request parameter parameters");
				resultObj.put(AppserverConstants.SUCCESS_KEY, false);
			}
		} catch (Exception e) {
			subLogger.error("Exception in CLCOperationsDAO#initiateTradesLinkingToInquiry() : ", e);
			resultObj.put(AppserverConstants.MESSAGE_KEY, "Failed to Link trades to an inquiry");
			resultObj.put(AppserverConstants.SUCCESS_KEY, false);
		}
		return resultObj;
	}

	/**
	 * This method processed result after linking trades to an inquiry
	 * @param request
	 * @param soeId
	 * @param resultObj
	 * @param linkResult
	 * @return
	 */
	private BasicDBObject processResult(String request, String soeId, BasicDBObject linkResult) {
		BasicDBObject resultObj = new BasicDBObject();
		if(linkResult.getBoolean(AppserverConstants.SUCCESS_KEY)) {
			subLogger.info("Trade links updated successfully. Refreshing UI linked Trades");
			resultObj = extractLinkedTradesToInquiry(request, soeId);
		} else {
			subLogger.info("Trade links not updated due to some issue. UI linked trades not refreshed");
			resultObj.put(AppserverConstants.MESSAGE_KEY, "Invalid request parameter parameters");
			resultObj.put(AppserverConstants.SUCCESS_KEY, false);
		}
		return resultObj;
	}


	/**
	 * This method links trades to an inquiry
	 * @param inquiryId
	 * @param groupId
	 * @param selectedTrades
	 * @param soeId
	 * @param startTime 
	 * @return BasicDBObject
	 */
	private BasicDBObject linkTradeToInquiry(Long inquiryId, Long groupId, BasicDBList selectedTrades, String soeId, String actionSource, long startTime ) {
		BasicDBObject resultObj = new BasicDBObject();
		try {
			CLCLinkedTrades tradeLink = getCLCLinkedTradesForInquiryId(inquiryId);
			Date date = new Date();
			if( tradeLink == null ) {
				subLogger.info("No record found in CLCLinkedTrades for Inquiry :{}, creating a new record", inquiryId);
				tradeLink = createNewRecordForTradeLinks(inquiryId, groupId, selectedTrades, soeId, date);
				resultObj.put(AppserverConstants.MESSAGE_KEY, "Added new record in database.");
				resultObj.put(AppserverConstants.SUCCESS_KEY, true);
			} else {
				subLogger.info("Updating existing CLCLinkedTrades record for Inquiry :{}", inquiryId);
				updateGroupDataForRecod(groupId, selectedTrades, soeId, tradeLink, date);
				resultObj.put(AppserverConstants.MESSAGE_KEY, "Updated existing record in database.");
				resultObj.put(AppserverConstants.SUCCESS_KEY, true);
			}
			BasicDBObject activityObj = new BasicDBObject();
			activityObj.put(SOE_ID, soeId);
			activityObj.put(INQUIRY_ID_KEY, inquiryId);
			activityObj.put(GROUP_ID_KEY, groupId);
			activityObj.put(ACTION, "Linked CLC Trades");
			activityObj.put(ACTION_SOURCE, actionSource);
			updateDatabseRecord(tradeLink, activityObj, startTime);
		} catch (Exception e) {
			subLogger.error("Error while linking trade to an inquiry in CLCOperationsDAO#linkTradeToInquiry() : ", e);
			resultObj.put(AppserverConstants.MESSAGE_KEY, "Error while linking trades to an inquiry");
			resultObj.put(AppserverConstants.SUCCESS_KEY, false);
		}
		return resultObj;
	}

	/**
	 * @param groupId
	 * @param selectedTrades
	 * @param soeId
	 * @param tradeLink
	 * @param date
	 */
	private void updateGroupDataForRecod(Long groupId, BasicDBList selectedTrades, String soeId,
			CLCLinkedTrades tradeLink, Date date) {
		
		if( tradeLink != null ){
			tradeLink.setModDate(date);
			tradeLink.setModBy(soeId);
			List<CLCGroupData> grpDataList = tradeLink.getGroupData();
			if( grpDataList != null && !grpDataList.isEmpty()) {
				CLCGroupData groupData =getGroupDataFromRecord(groupId, grpDataList);
				if(groupData != null ) {
					subLogger.info("Group Data for groupId {} exists in CLCLinkedTrades for inquiry : {}", groupId, tradeLink.getInquiryId());
					updateTradeLinks(selectedTrades, soeId, date, groupData);
				} else {
					subLogger.info("Group Data for groupId {} does not exists in CLCLinkedTrades for inquiry : {}", groupId, tradeLink.getInquiryId());
					createNewGroupDataRecord(groupId, selectedTrades, soeId, tradeLink, date, grpDataList);
				}
			} else {
				grpDataList = new ArrayList<>();
				subLogger.info("Group Data List does not exists in CLCLinkedTrades for inquiry : {}", tradeLink.getInquiryId());
				createNewGroupDataRecord(groupId, selectedTrades, soeId, tradeLink, date, grpDataList);
			}
		}
	}

	/**
	 * @param selectedTrades
	 * @param soeId
	 * @param date
	 * @param groupData
	 */
	private void updateTradeLinks(BasicDBList selectedTrades, String soeId, Date date, CLCGroupData groupData) {
		List<QMATradeRecord> existingLinkedTrades = groupData.getTradeRefs();
		if(existingLinkedTrades==null) {
			existingLinkedTrades = new ArrayList<>();
			groupData.setTradeRefs(existingLinkedTrades);
		}
		if(selectedTrades!=null && !selectedTrades.isEmpty()){
			subLogger.info("Updating trade links for group id :{}", groupData.getGroupId());
			for(int i=0;i<selectedTrades.size();i++) {
				BasicDBObject currentTradeRecord = (BasicDBObject) selectedTrades.get(i);
				String currentTradeRef = currentTradeRecord.getString(CLC_TRADE_REF_UI_KEY);
				
				if( !StringUtils.isEmpty(currentTradeRef) && !checkIfTradeRecordExists(existingLinkedTrades, currentTradeRef) ){
					QMATradeRecord newTradeRecord = new QMATradeRecord();
					newTradeRecord.setTradeRef(currentTradeRecord.getString(CLC_TRADE_REF_UI_KEY));
					newTradeRecord.setClient(currentTradeRecord.getString(CLC_ACCOUNT_NAME_UI_KEY));
					newTradeRecord.setSecurity(currentTradeRecord.getString(CLC_SECURITY_NAME_UI_KEY));
					newTradeRecord.setCusip(currentTradeRecord.getString(CLC_CUSIP_CODE_UI_KEY));
					existingLinkedTrades.add(newTradeRecord);
				}
			}
		}
		groupData.setModDate(date);
		groupData.setModifiedBy(soeId);
	}
	
	
	/**
	 * This method checks if trade record exists or not
	 * @param existingLinkedTrades
	 * @param tradeRef
	 * @return
	 */
	private boolean checkIfTradeRecordExists(List<QMATradeRecord> existingLinkedTrades, String tradeRef){
		boolean recordExists = false;
		if(existingLinkedTrades!=null && !existingLinkedTrades.isEmpty() && !StringUtils.isEmpty(tradeRef)) {
			for(QMATradeRecord currentRecord : existingLinkedTrades) {
				if(currentRecord.getTradeRef().equalsIgnoreCase(tradeRef)){
					recordExists = true;
					break;
				}
			}
		}
		return recordExists;
	}

	/**
	 * This method creates a new record for groupData and add it to CLCLinkedTrades record
	 * @param groupId
	 * @param selectedTrades
	 * @param soeId
	 * @param tradeLink
	 * @param date
	 * @param grpDataList
	 */
	private void createNewGroupDataRecord(Long groupId, BasicDBList selectedTrades, String soeId,
			CLCLinkedTrades tradeLink, Date date, List<CLCGroupData> grpDataList) {
		CLCGroupData newGrpData = new CLCGroupData();
		newGrpData.setGroupId(groupId);
		List<QMATradeRecord> tradeList = new ArrayList<>();
		for( int i=0; i < selectedTrades.size(); i++ ) {
			BasicDBObject currentTradeRecord = (BasicDBObject) selectedTrades.get(i);
			if(null != currentTradeRecord){
				QMATradeRecord currentRecord = new QMATradeRecord();
				currentRecord.setTradeRef(currentTradeRecord.getString(CLC_TRADE_REF_UI_KEY));
				currentRecord.setClient(currentTradeRecord.getString(CLC_ACCOUNT_NAME_UI_KEY));
				currentRecord.setSecurity(currentTradeRecord.getString(CLC_SECURITY_NAME_UI_KEY));
				currentRecord.setCusip(currentTradeRecord.getString(CLC_CUSIP_CODE_UI_KEY));
				tradeList.add(currentRecord);
			}
		}
		newGrpData.setTradeRefs(tradeList);
		newGrpData.setCrtDate(date);
		newGrpData.setModDate(date);
		newGrpData.setCreatedBy(soeId);
		newGrpData.setModifiedBy(soeId);
		grpDataList.add(newGrpData);
		tradeLink.setGroupData(grpDataList);
		subLogger.info("Created new group data for groupId {} in record for inquiryId :{}", groupId, tradeLink.getInquiryId());
	}

	/**
	 * This method creates a new record for trade links
	 * @param inquiryId
	 * @param groupId
	 * @param selectedTrades
	 * @param soeId
	 * @param date
	 * @return CLCLinkedTrades
	 */
	private CLCLinkedTrades createNewRecordForTradeLinks(Long inquiryId, Long groupId, BasicDBList selectedTrades,
			String soeId, Date date) {
		CLCLinkedTrades tradeLink = new CLCLinkedTrades();
		tradeLink.setInquiryId(inquiryId);
		tradeLink.setCrtDate(date);
		tradeLink.setModDate(date);
		tradeLink.setCrtBy(soeId);
		List<CLCGroupData> grpDataList = new ArrayList<>();
		createNewGroupDataRecord(groupId, selectedTrades, soeId, tradeLink, date, grpDataList);
		return tradeLink;
	}
	
	/**
	 * This function extracts CLCLinkedTrades record from database for given inquiryId
	 * @param inquiryId
	 * @return CLCLinkedTrades
	 */
	private CLCLinkedTrades getCLCLinkedTradesForInquiryId( Long inquiryId ) {
		Query<CLCLinkedTrades> query = null;
		CLCLinkedTrades clcLinkedTradesRecords = null;
		try {
			query = mongoDatastore.createQuery(CLCLinkedTrades.class).filter(INQUIRY_ID_KEY, inquiryId).limit(1);
			query.order("-crtDate");
			clcLinkedTradesRecords = query.get();
			if (clcLinkedTradesRecords == null) {
				subLogger.info("No record found in CLCLinkedTrades for InquiryId : {}", inquiryId);
			}
		} catch (Exception e) {
			subLogger.error("Exception while retrieving record in CLCOperationsDAO#etCLCLinkedTradesForInquiryId() for InquiryId : " + inquiryId , e);
		}
		return clcLinkedTradesRecords;
	}
	
	
	/**
	 * This function identifies groupData in a CLCLinkedTrades record for given inquiryId and groupId 
	 * @param inquiryId
	 * @param groupId
	 * @return
	 */
	private CLCGroupData getGroupDataForInquiryID(Long inquiryId, Long groupId){
		CLCLinkedTrades clcLinkedTrades = getCLCLinkedTradesForInquiryId(inquiryId);
		CLCGroupData grpData = null;
		if( clcLinkedTrades != null ) {
			List<CLCGroupData> grpDataList = clcLinkedTrades.getGroupData();
			if( grpDataList != null && !grpDataList.isEmpty() ){
				grpData = getGroupDataFromRecord(groupId, grpDataList);
			}
		}
		return grpData;
	}

	/**
	 * This function identifies groupData for given group id in the list of groupData
	 * @param groupId
	 * @param grpDataList
	 * @return CLCGroupData
	 */
	private CLCGroupData getGroupDataFromRecord(Long groupId, List<CLCGroupData> grpDataList) {
		 CLCGroupData groupData =null;
		if(grpDataList!=null && !grpDataList.isEmpty() && groupId != null ) {
			for(CLCGroupData currentGrpData : grpDataList){
				if(currentGrpData.getGroupId().equals(groupId)) {
					groupData = currentGrpData;
					break;
				}
			}
		}
		return groupData;
	}
	
	/**
	 * This method updates CLCLinkedTrades record in database
	 * @param tradeLink
	 * @param startTime 
	 */
	private void updateDatabseRecord(CLCLinkedTrades tradeLink, BasicDBObject activityObj, long startTime) {
		if(tradeLink !=null) {
			mongoDatastore.save(tradeLink);
			if(activityObj != null){
				try{
					String soeId = activityObj.getString(SOE_ID);
					String action = activityObj.getString(ACTION);
					final Date actionTime = new Date();
					if(!StringUtils.isEmpty(activityObj.getString(ACTION_SOURCE))) {
						String actionDescription = activityObj.getString(ACTION_SOURCE)+" performed for InquiryId: "+activityObj.getString(INQUIRY_ID_KEY)+" and groupId: "+activityObj.getString(GROUP_ID_KEY);
						UserActivities userActivity = new UserActivities(soeId, action, actionDescription, actionTime);
						user_Activities_Dao.saveUserActivities(soeId, userActivity, System.currentTimeMillis() - startTime);
					} else {
						String actionDescription = activityObj.getString(ACTION)+" performed for InquiryId: "+activityObj.getString(INQUIRY_ID_KEY)+" and groupId: "+activityObj.getString(GROUP_ID_KEY);
						UserActivities userActivity = new UserActivities(soeId, action, actionDescription, actionTime);
						user_Activities_Dao.saveUserActivities(soeId, userActivity, System.currentTimeMillis() - startTime);
					}
					
				} catch(Exception e) {
					subLogger.error("Error while logging in user activity", e);
				}
			}
			
		}
	}

	/**
	 * This function links trades to an inquiry on replyAll action
	 * @param inquiry
	 * @param groupId
	 * @param selectedTradeList
	 */
	public void linkTradesToInquiryOnReply(Inquiry inquiry, Long groupId, BasicDBList selectedTradeList) {
		Long inquiryId = inquiry.getId();
		long startTime = System.currentTimeMillis();
		String lastActionBy = inquiry.getModBy();
		String actionSource = "Linked/Updated CLC Trades on Reply";
		BasicDBObject resultObj = linkTradeToInquiry(inquiryId, groupId, selectedTradeList, lastActionBy, actionSource, startTime);
		if(resultObj.getBoolean(AppserverConstants.SUCCESS_KEY)){
			subLogger.info("Trades linked successfully on ReplyAll action to inquiry :{} for group : {}", inquiryId, groupId);
		} else {
			subLogger.info("There was a problem on linking trades on ReplyAll action to inquiry :{} for group : {}", inquiryId, groupId);
		}
	}
	
	
	
	public BasicDBObject initiateTradesUnLinkingFromInquiry(String request, String soeId, long startTime) {
		BasicDBObject resultObj = new BasicDBObject();
		try {
			BasicDBObject requestObj = BasicDBObject.parse(request);
			if( null != requestObj.get("selectedTradeToUnlink") && null != requestObj.get(INQUIRY_ID_KEY) && null != requestObj.get(GROUP_ID_KEY) ) {
				Long inquiryId = requestObj.getLong(INQUIRY_ID_KEY);
				Long groupId = requestObj.getLong(GROUP_ID_KEY);
				BasicDBList selectedTradeToUnlink = (BasicDBList) requestObj.get("selectedTradeToUnlink");
				resultObj = unlinkAndProcessResult(request, soeId, inquiryId, groupId, selectedTradeToUnlink, startTime);
				resultObj.put(AppserverConstants.MESSAGE_KEY, "Trade Linking performed for InquiryId: "+ inquiryId + ", groupId :" + groupId + ", for trades :" + selectedTradeToUnlink);
				resultObj.put(AppserverConstants.SUCCESS_KEY, true);
			}
		} catch (Exception e) {
			resultObj.put(AppserverConstants.MESSAGE_KEY, "Failed to unlink trade for inquiry");
			resultObj.put(AppserverConstants.SUCCESS_KEY, false);
			subLogger.error("Exception in CLCOperationsDAO#initiateTradesUnLinkingFromInquiry() : ", e);
		}
		return resultObj;
	}

	/**
	 * This method unlink trades and process result
	 * @param request
	 * @param soeId
	 * @param resultObj
	 * @param inquiryId
	 * @param groupId
	 * @param selectedTradeToUnlink
	 * @param startTime 
	 * @return BasicDBObject
	 */
	private BasicDBObject unlinkAndProcessResult(String request, String soeId, Long inquiryId,
			Long groupId, BasicDBList selectedTradeToUnlink, long startTime) {
		BasicDBObject resultObj = new BasicDBObject();
		if( inquiryId != null && groupId != null ) {
			BasicDBObject unlinkResult =  unLinkTradeFromInquiry(inquiryId, groupId, selectedTradeToUnlink, soeId, startTime);
			if(unlinkResult.getBoolean(AppserverConstants.SUCCESS_KEY)){
				subLogger.info("Unlinking of trades from inquiry {} for group :{} successful. Updating UI result for linked trades.", inquiryId, groupId);
				resultObj = extractLinkedTradesToInquiry(request, soeId);
			} else {
				subLogger.info("Unlinking of trades from inquiry {} for group :{} unsuccessful.", inquiryId, groupId);
			}
		}
		return resultObj;
	}
	
	
	private BasicDBObject unLinkTradeFromInquiry(Long inquiryId, Long groupId, BasicDBList selectedTradeToUnlink, String soeId, long startTime) {
		BasicDBObject result = new BasicDBObject();
		CLCLinkedTrades tradeLink = getCLCLinkedTradesForInquiryId(inquiryId);
		CLCGroupData grpData=null;
		if(null!=tradeLink) {// sonar fix for NullPointer exception
		grpData = getGroupDataFromRecord(groupId,tradeLink.getGroupData());
		}
		if( grpData != null ) {
			List<QMATradeRecord> linkedTradeList = grpData.getTradeRefs();
			boolean isRecordUpdated = unlinkTrades(selectedTradeToUnlink, linkedTradeList);
			if(isRecordUpdated) {
				Date date = new Date();
				grpData.setModifiedBy(soeId);
				grpData.setModDate(date);
				tradeLink.setModBy(soeId);
				tradeLink.setModDate(date);
			}
			BasicDBObject activityObj = new BasicDBObject();
			activityObj.put(SOE_ID, soeId);
			activityObj.put(INQUIRY_ID_KEY, inquiryId);
			activityObj.put(GROUP_ID_KEY, groupId);
			activityObj.put(ACTION, "Unlinked CLC Trades");
			updateDatabseRecord(tradeLink, activityObj, startTime);
			result.put(AppserverConstants.MESSAGE_KEY, "Trades unliked successfully");
			result.put(AppserverConstants.SUCCESS_KEY, true);
		} else {
			result.put(AppserverConstants.MESSAGE_KEY, "No group data found");
			result.put(AppserverConstants.SUCCESS_KEY, false);
		}
		
		return result;
	}

	/**
	 * @param selectedTradeToUnlink
	 * @param linkedTradeList
	 */
	private boolean unlinkTrades(BasicDBList selectedTradeToUnlink, List<QMATradeRecord> linkedTradeList) {
		boolean isRecordUpdated = false;
		if( linkedTradeList != null && !linkedTradeList.isEmpty() && selectedTradeToUnlink!=null && !selectedTradeToUnlink.isEmpty() ) {
			for(int i=0;i<selectedTradeToUnlink.size();i++){
				String currentTradeToUnlink = (String) selectedTradeToUnlink.get(i);
				if(!StringUtils.isEmpty(currentTradeToUnlink) && checkIfTradeRecordExists(linkedTradeList,currentTradeToUnlink)) {
					removeLinkedTradeRecordFromList(linkedTradeList,currentTradeToUnlink);
					isRecordUpdated= true;
				}
			}
		}
		return isRecordUpdated;
	}

	/**
	 * This method removes trade record to be unlinked
	 * @param linkedTradeList
	 * @param currentTradeToUnlink
	 */
	private void removeLinkedTradeRecordFromList(List<QMATradeRecord> linkedTradeList, String currentTradeToUnlink) {
		if(linkedTradeList!=null && !linkedTradeList.isEmpty() && !StringUtils.isEmpty(currentTradeToUnlink)) {
			ListIterator<QMATradeRecord> recordItr = linkedTradeList.listIterator();
			while(recordItr.hasNext()){
			    if(recordItr.next().getTradeRef().equalsIgnoreCase(currentTradeToUnlink)){
			    	recordItr.remove();
			    }
			}
		}
	}

	/**
	 * This function extracts result for linked trades for an inquiry 
	 * @param request
	 * @param soeId
	 * @return BasicDBObject
	 */
	public BasicDBObject extractLinkedTradesToInquiry(String request, String soeId) {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBObject requestObj = BasicDBObject.parse(request);
			if( !StringUtils.isEmpty(requestObj.getString(INQUIRY_ID_KEY)) && !StringUtils.isEmpty(requestObj.getString(GROUP_ID_KEY)) ){
				Long inquiryId = requestObj.getLong(INQUIRY_ID_KEY);
				Long groupId = requestObj.getLong(GROUP_ID_KEY);
				if(inquiryId != null && groupId != null ){
					extractLinkedTrades(response, inquiryId, groupId);
				} else {
					response.put(AppserverConstants.SUCCESS_KEY, false);
					response.put(AppserverConstants.MESSAGE_KEY, "No trades linked");
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in extractLinkedTradesToInquiry : ", e);
		}
		return response;
	}

	/**
	 * This method extracts linked trades for inquiryId and groupId
	 * @param response
	 * @param inquiryId
	 * @param groupId
	 */
	private void extractLinkedTrades(BasicDBObject response, Long inquiryId, Long groupId) {
		CLCGroupData grpData = getGroupDataForInquiryID(inquiryId, groupId);
		if(grpData!=null && grpData.getTradeRefs()!=null && !grpData.getTradeRefs().isEmpty()){
			List<QMATradeRecord> clcLinkedTrades = grpData.getTradeRefs();
			if(clcLinkedTrades!=null && !clcLinkedTrades.isEmpty()){
				BasicDBList linkedTradeList = new BasicDBList();
				for ( QMATradeRecord cLinkedTrade : clcLinkedTrades ) {
					BasicDBObject obj = new BasicDBObject();
					obj.put(CLC_TRADE_REF_UI_KEY, cLinkedTrade.getTradeRef());
					obj.put(SECURITY_KEY, cLinkedTrade.getSecurity());
					obj.put(CLIENT_KEY, cLinkedTrade.getClient());
					obj.put(CLC_CUSIP_CODE_UI_KEY, cLinkedTrade.getCusip());
					linkedTradeList.add(obj);
				}
				response.put(CLC_RESULT_DATA_KEY, linkedTradeList);
				BasicDBList columnList = getLinkedTradeColumnList();
				response.put(COLUMN_DEF_KEY, columnList);
				response.put(AppserverConstants.MESSAGE_KEY, "Trades extracted successfully");
				response.put(AppserverConstants.SUCCESS_KEY, true);
			}else {
				response.put(AppserverConstants.MESSAGE_KEY, "No linked Trades present");
				response.put(AppserverConstants.SUCCESS_KEY, false); 
			}
		} else {
			response.put(AppserverConstants.MESSAGE_KEY, "No record exists");
			response.put(AppserverConstants.SUCCESS_KEY, false); 
		}
	}
	
	
	/**
	 * This function returns the list of column definition for linked trades data
	 * @return BasicDBList
	 */
	private BasicDBList getLinkedTradeColumnList(){
		BasicDBList columnList = new BasicDBList();
		BasicDBObject col1 = new BasicDBObject();
		col1.put(FIELD_KEY, "srNo1");
		col1.put(FORMAT_KEY, null);
		col1.put(TITLE_KEY, SPACE_CHAR);
		col1.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col1.put(WIDTH_KEY, 30);
		col1.put(TEMPLATE_KEY, "");
		col1.put(SELECTABLE_KEY, true);
		columnList.add(col1);
		BasicDBObject col2 = new BasicDBObject();
		col2.put(FIELD_KEY, CLC_TRADE_REF_UI_KEY);
		col2.put(FORMAT_KEY, null);
		col2.put(TITLE_KEY, COLUMN_TRADE_REF);
		col2.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col2.put(WIDTH_KEY, 150);
		columnList.add(col2);
		BasicDBObject col3 = new BasicDBObject();
		col3.put(FIELD_KEY, CLIENT_KEY);
		col3.put(FORMAT_KEY, null);
		col3.put(TITLE_KEY, COLUMN_ACCOUNT_NAME);
		col3.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col3.put(WIDTH_KEY, 150);
		columnList.add(col3);
		BasicDBObject col4 = new BasicDBObject();
		col4.put(FIELD_KEY, SECURITY_KEY);
		col4.put(FORMAT_KEY, null);
		col4.put(TITLE_KEY, COLUMN_SECURITY_NAME);
		col4.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col4.put(WIDTH_KEY, 150);
		columnList.add(col4);
		BasicDBObject col5 = new BasicDBObject();
		col5.put(FIELD_KEY, CLC_CUSIP_CODE_UI_KEY);
		col5.put(FORMAT_KEY, null);
		col5.put(TITLE_KEY, COLUMN_CUSIP);
		col5.put(TYPE_KEY, COLUMN_TYPE_STRING);
		col5.put(WIDTH_KEY, 100);
		columnList.add(col5);
		return columnList;
	}
	
	
	/**
	 * This function provide value from CLC config for requested key
	 * @param key
	 * @return Object
	 */
	private Object getCLCConfigForKey(String key) {
		Object value = null;
		Map<String, Object> clcConfig = null;
		try {
			if(null != QMACacheFactory.getCache().getConfigById(CONFIG_CLC_CONFIGURATION_KEY)) {
				Config configData = QMACacheFactory.getCache().getConfigById(CONFIG_CLC_CONFIGURATION_KEY);
				if(null != configData) {
					clcConfig = configData.getClcConfiguration();
				}
				if( clcConfig != null && !StringUtils.isEmpty(key) ) {
					value = clcConfig.get(key);
				}
			}
		} catch (Exception e) {
			subLogger.error("Error while retrieving value from CLC config :" , e );
		}
		return value;
	}
	
	/**
	 * This function returns CLC search end-point URL
	 * @return String
	 */
	private String getClcConfigStringValues( String key) {
		String value = (String) getCLCConfigForKey(key);
		if(CLC_SEARCH_ENDPOINT_URL_KEY.equalsIgnoreCase(key)){
			subLogger.info("CLC Search endpoint URL is : {}", value);
		}
		if(CLC_GRID_PAGE_SIZE_LIMIT_KEY.equalsIgnoreCase(key)){
			subLogger.info("Maximun record limit on page in CLC grid :{}", value);
		}
		return value;
	}
	
	/**
	 * This method provides static value list configured for CLC
	 * @param key
	 * @return BasicDBList
	 */
	private BasicDBList getClcOptionValues( String key) {
		BasicDBList value = (BasicDBList) getCLCConfigForKey(key);
		if(value == null) {
			subLogger.info("Options value list retrieved for key :{} in clc config is either not defined in database or null.", key);
		}
		return value;
	}
	
	/**
	 * This function retrieves request params from config 
	 * @param key
	 * @return String
	 */
	private String getCLCRequestParams(String key) {
		String value = "";
		Map<String, String> requestParams = (Map<String, String>) getCLCConfigForKey(REQUEST_PARAMS_KEY);
		if(requestParams!=null && !requestParams.isEmpty() && requestParams.containsKey(key)){
			value = requestParams.get(key);
		}
		return value;
	}
	
	/**
	 * 
	 * This method retrieves certificate configuration params
	 * @param key
	 * @return
	 */
	private String getCLCCertConfig(String key) {
		String value = "";
		Map<String, String> certConfig = (Map<String, String>) getCLCConfigForKey(CERT_CONF_KEY);
		if(certConfig!=null && !certConfig.isEmpty() && certConfig.containsKey(key)){
			value = certConfig.get(key);
		}
		return value;
	}
	
	/**
	 * This method provides CLC config data for UI
	 * @param soeId
	 * @return
	 */
	public BasicDBObject getClcConfigForUI(String soeId) {
		BasicDBObject response = new BasicDBObject();
		try {
			response.put(PAGE_SIZE_KEY, getCLCRequestParams(PAGE_SIZE_KEY));
			response.put(TRADE_REF_OPTIONS_KEY, getClcOptionValues(TRADE_REF_OPTIONS_KEY));
			response.put(SOURCE_OPTIONS_KEY, getClcOptionValues(SOURCE_OPTIONS_KEY));
			response.put(SECURITY_OPTIONS_KEY, getClcOptionValues(SECURITY_OPTIONS_KEY));
			response.put(STATUS_OPTIONS_KEY, getClcOptionValues(STATUS_OPTIONS_KEY));
			response.put(SDI_OPTIONS_KEY, getClcOptionValues(SDI_OPTIONS_KEY));
			response.put(CLIENTID_OPTIONS_KEY, getClcOptionValues(CLIENTID_OPTIONS_KEY));
			response.put(CLC_GRID_PAGE_SIZE_LIMIT_KEY, getClcConfigStringValues(CLC_GRID_PAGE_SIZE_LIMIT_KEY));
		} catch (Exception e) {
			subLogger.error("Error while reading UI config for CLC in CLCOperationsDAO#getClcConfigForUI() :" ,e);
		}
		return response;
	}
	
	/**
	 * Mail method for testing SSL handshake
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			CLCOperationsDAO dao = new CLCOperationsDAO();
			String soeId  ="XXXXXX";
			BasicDBObject request = new BasicDBObject();
			BasicDBObject response = dao.clcSearchAll(request.toJson(), soeId);
		} catch (Exception e) {
			subLogger.error("Error :", e);
		}
	}
	
	/**
	 * This function extracts result for linked trades for an inquiry 
	 * @param inquiryId
	 * @param selectInqAssignedGroupId
	 * @param soeId
	 * @param conversationTO
	 * @return BasicDBObject
	 */
	public BasicDBObject getClcSuggestionList(Long inquiryId, List<Long>selectInqAssignedGroupId, ConversationTO conversationTO, String soeId) {		
		BasicDBObject response = new BasicDBObject();
		try {
			subLogger.info("Inside getClcSuggestionList for soeid={}", soeId);
			BasicDBObject  clcresponse = null;
			if(inquiryId!=null && selectInqAssignedGroupId!=null && !selectInqAssignedGroupId.isEmpty()){
				BasicDBObject inputClcObj = new BasicDBObject(); 
				inputClcObj.put(INQUIRY_ID_KEY,inquiryId);
				inputClcObj.put(GROUP_ID_KEY,selectInqAssignedGroupId.get(0));
				clcresponse =  extractLinkedTradesToInquiry(inputClcObj.toJson(),soeId);
			}
			setClcSugListToConversation(conversationTO, clcresponse);
		} catch (Exception e) {
			subLogger.error("Exception in extractLinkedTradesToInquiry : ", e);
		}
		return response;
	}

	private void setClcSugListToConversation(ConversationTO conversationTO, BasicDBObject clcresponse) {
		if(clcresponse!=null){
			BasicDBList clcresponseObjList =(BasicDBList) clcresponse.get("data");
			if(clcresponseObjList!=null){
				List<String> res = new ArrayList<>();
				for(Object el: clcresponseObjList) {
					BasicDBObject currentObj = (BasicDBObject)el;
					String tradeRef = currentObj.getString(CLC_TRADE_REF_UI_KEY);
					if(StringUtils.isNotEmpty(tradeRef)){
						res.add(tradeRef);
					}
				}
				if(!res.isEmpty()){
					conversationTO.setClcSuggestionRecords(res);
					conversationTO.setClcSuggestionAvailable(true);
				}
			}
		}
	}

	public BasicDBObject postUsageStats(String request) {
		BasicDBObject responseResult = new BasicDBObject();
		try {
			HttpClient httpClient = getClcHttpClientForScheduler();
			if (httpClient != null) {
				HttpPost postRequest = new HttpPost(getClcConfigStringValues("clcPopulateUsageStatsEndpointUrl"));
				postRequest.addHeader(CONTENT_TYPE_KEY, CT_APPLICATION_JSON_KEY);
				StringEntity input = new StringEntity(request);
				postRequest.setEntity(input);
				HttpResponse response = httpClient.execute(postRequest);
				if (response.getStatusLine().getStatusCode() != 200) {
					responseResult = processResponseResultUsageStats(response.getStatusLine().getStatusCode());
				} else {
					HttpEntity entity = response.getEntity();
					responseResult.put("data", entity.toString());
					responseResult.put(AppserverConstants.MESSAGE_KEY, "Data processed successfully!");
					responseResult.put(AppserverConstants.SUCCESS_KEY, true);
				}
			} else {
				responseResult.put(AppserverConstants.MESSAGE_KEY, SERVICE_NOT_AVAILABLE);
				responseResult.put(AppserverConstants.SUCCESS_KEY, false);

			}
		} catch (Exception e) {
			subLogger.error("Error while making a call to CLC endpoint in postUsageStats() :", e);
			responseResult.put(AppserverConstants.MESSAGE_KEY,SERVICE_NOT_AVAILABLE);
			responseResult.put(AppserverConstants.SUCCESS_KEY, false);

		}
		return responseResult;

	}
	/**
	 * This method gets HTTP client for CLC
	 * @return
	 * @throws KeyStoreException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 */
	private HttpClient getClcHttpClientForScheduler() throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
		
		HttpClient httpClient = null ;
		try {
			String certFileName = getCLCCertConfig(CERT_FILENAME_KEY);
			
			String xmcEnvironment = System.getProperty(AppserverConstants.ENV_PARAM_KEY);
			
			if(StringUtils.isNotEmpty(certFileName)) {
				SSLConnectionSocketFactory socketFactory = CLCSocketFactory.getInstanceForScheduler();
				if(null!= socketFactory) {
					httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).disableCookieManagement().build();
					subLogger.info("CLC :: Environment is :{} using two-way SSL enabled HttpClient.", xmcEnvironment);
				} 
			} else {
				subLogger.info("CLC :: Environment is :{} Not able to identify certificate paramteres from database.", xmcEnvironment);
				httpClient = HttpClientBuilder.create().build();
			} 
			 
		} catch (Exception e) {
			subLogger.error("CLC :: Error while creating http client in CLCOperationsDAO#getHttpClientSSLEnabled() : ",e);
		}
		return httpClient;
	}

}