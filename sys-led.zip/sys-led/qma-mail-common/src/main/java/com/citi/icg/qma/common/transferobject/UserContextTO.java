package com.citi.icg.qma.common.transferobject;

import java.util.List;

public class UserContextTO
{
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private List<UserGroupTO> assignOwnerList;
	private List<String> assignRequestList;
	private Long groupId;

	public UserContextTO()
	{

	}

	public UserContextTO(List<UserGroupTO> assignOwnerList, List<String> assignRequestList,Long groupId)
	{
		super();
		this.assignOwnerList = assignOwnerList;
		this.assignRequestList = assignRequestList;
		this.groupId=groupId;
	}

	public List<UserGroupTO> getAssignOwnerList() {
		return assignOwnerList;
	}

	public void setAssignOwnerList(List<UserGroupTO> assignOwnerList) {
		this.assignOwnerList = assignOwnerList;
	}

	public List<String> getAssignRequestList() {
		return assignRequestList;
	}

	public void setAssignRequestList(List<String> assignRequestList) {
		this.assignRequestList = assignRequestList;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

}
