package com.citi.icg.qma.common.core.util;
/**
 * 
 */

import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

/**
 * 
 *
 */
public class RequestSanitizationUtility {
	
	private static final Logger logger = LoggerFactory.getLogger(RequestSanitizationUtility.class);
	private static final String XSS_CONFIG_KEY = "xssListConfig";
	static Map<String, Object> xssConfig;
	static boolean xssValidationFlag;
	
	private RequestSanitizationUtility() {
		
	}

	static {

		try {

			QMACache qmaCache = QMACacheFactory.getCache();
			if (null != qmaCache.getConfigById(XSS_CONFIG_KEY)) {
				xssConfig = qmaCache.getConfigById(XSS_CONFIG_KEY).getXssListConfig();
				if (null != xssConfig) {
					xssValidationFlag = (boolean) xssConfig.get("xssValidationFlag");	
				}
			}
			
			

		} catch (Exception e) {

			logger.debug("!!Cache is down!!");

		}

	}
	
	public static String sanitizeRequest(String inputValue) {
		logger.info("!!!! Validiaton flag value is !! {} " , xssValidationFlag);
		
			String value = inputValue;
	        try {
	        	if (xssValidationFlag) {
	        		value = stripXSS(value);
	        		logger.info("Sanitized Input is : {}",value);
	        	}
			} catch (Exception e) {
				logger.warn("Exception while sanitizing request parameters : ",e);
			}	
	        return value;
    }

	private static String stripXSS(String value) {
		if (StringUtils.isNotEmpty(value)) {
            // NOTE: It's highly recommended using the ESAPI library and uncomment the following line to avoid encoded attacks.
            // But current version available in Artifactory is 2.0.1.0 which is highly vulnerable. Hence, Once 2.5.0.0 is available we will use it.

            // Avoid null/empty characters

            // Avoid anything between script tags
			if(xssConfig!=null  && xssConfig.get("scriptTag")!=null) {
            Pattern scriptPattern = Pattern.compile(((String) xssConfig.get("scriptTag")).replaceAll("\\\\\\\\", "\\\\"), Pattern.CASE_INSENSITIVE);
            value = scriptPattern.matcher(value).replaceAll("");
            }
			
			 if (xssConfig!=null  && xssConfig.get("srcTag")!=null  && xssConfig.get("imgAndSrcTag")!=null) {
					// Avoid anything in a src='...' type of expression
					Pattern srcScriptPattern = Pattern.compile(((String) xssConfig.get("imgAndSrcTag")).replaceAll("\\\\\\\\", "\\\\"));
					if (!srcScriptPattern.matcher(value).find()) {
						Pattern scriptPattern = Pattern.compile(((String) xssConfig.get("srcTag")).replaceAll("\\\\\\\\", "\\\\"),
								Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
						value = scriptPattern.matcher(value).replaceAll("");
					} 
				}
            
			// Remove any lonesome </script> tag
            if (xssConfig!=null  && xssConfig.get("scriptClosingTag")!=null ) {
				
				Pattern scriptPattern = Pattern.compile(((String) xssConfig.get("scriptClosingTag")).replaceAll("\\\\\\\\", "\\\\"),Pattern.CASE_INSENSITIVE);
				value = scriptPattern.matcher(value).replaceAll("");
			}
			// Remove any lonesome <script ...> tag
          
           if (xssConfig!=null  && xssConfig.get("scriptOpeningTag")!=null) {
				Pattern scriptPattern = Pattern.compile(((String) xssConfig.get("scriptOpeningTag")).replaceAll("\\\\\\\\", "\\\\"),
						Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
				value = scriptPattern.matcher(value).replaceAll("");
			}
			// Avoid eval(...) expressions
          
           if (xssConfig!=null  && xssConfig.get("evalRegex")!=null) {
				Pattern scriptPattern = Pattern.compile(((String) xssConfig.get("evalRegex")).replaceAll("\\\\\\\\", "\\\\"),
						Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
				value = scriptPattern.matcher(value).replaceAll("");
			}
			// Avoid expression(...) expressions
            if (xssConfig!=null  && xssConfig.get("expressionRegex")!=null) {
				Pattern scriptPattern = Pattern.compile(((String) xssConfig.get("expressionRegex")).replaceAll("\\\\\\\\", "\\\\"),
						Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
				value = scriptPattern.matcher(value).replaceAll("");
			}
         // Avoid javascript:... expressions
			if (xssConfig!=null  && xssConfig.get("javascriptRegex")!=null) {
				Pattern scriptPattern = Pattern.compile(((String) xssConfig.get("javascriptRegex")).replaceAll("\\\\\\\\", "\\\\"),
						Pattern.CASE_INSENSITIVE);
				value = scriptPattern.matcher(value).replaceAll("");
			}
			// Avoid vbscript:... expressions
			if (xssConfig!=null  && xssConfig.get("vbscriptRegex")!=null) {
				Pattern scriptPattern = Pattern.compile(((String) xssConfig.get("vbscriptRegex")).replaceAll("\\\\\\\\", "\\\\"),
						Pattern.CASE_INSENSITIVE);
				value = scriptPattern.matcher(value).replaceAll("");
			}
			// Avoid onload= expressions
            if (xssConfig!=null  && xssConfig.get("onloadRegex")!=null) {
				Pattern scriptPattern = Pattern.compile(((String) xssConfig.get("onloadRegex")).replaceAll("\\\\\\\\", "\\\\"),
						Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
				value = scriptPattern.matcher(value).replaceAll("");
			}

            //logger.debug("Request parameters are validated"); //This line generates too many loggers so use it locally only for debugging.
        }
		return value;
	}
}