/**
 * 
 */
package com.citi.icg.qma.common.server.dao.entity;

import java.io.Serializable;

/**
 * 
 *
 */
public class UserEntitlement implements Serializable
{
	private static final long serialVersionUID = -7614107042195316406L;
	private String appId;
	private String lastName;
	private String firstName;
	private String loginId;
	private String ritsId;
	private String geId;
	private String functionCode;
	private String functionDesc;
	private String soeId;
	private String entitlement;
	private String drillDownCd;
	private String seqField;
	private String isaContactId;
	private String productId;
	private String functionIdInd;
	private String attributeCd;
	
	/**
	 * @param appId
	 * @param lastName
	 * @param firstName
	 * @param loginId
	 * @param ritsId
	 * @param geId
	 * @param functionCode
	 * @param functionDesc
	 * @param soeId
	 * @param entitlement
	 * @param drillDownCd
	 * @param seqField
	 * @param isaContactId
	 * @param productId
	 * @param functionIdInd
	 * @param attributeCd
	 */
	public UserEntitlement(String appId, String lastName, String firstName, String loginId, String ritsId, String geId, String functionCode, String functionDesc, String soeId, String entitlement,
			String drillDownCd, String seqField, String isaContactId, String productId, String functionIdInd, String attributeCd)
	{
		super();
		this.appId = appId;
		this.lastName = lastName == null ? "": lastName;
		this.firstName = firstName == null ? "": firstName;
		this.loginId = loginId == null ? "": loginId;
		this.ritsId = ritsId == null ? "": ritsId;
		this.geId = geId == null ? "": geId;
		this.functionCode = functionCode == null ? "": functionCode;
		this.functionDesc = functionDesc == null ? "": functionDesc;
		this.soeId = soeId == null ? "": soeId;
		this.entitlement = entitlement == null ? "": entitlement;
		this.drillDownCd = drillDownCd== null ? "": drillDownCd; 
		this.seqField = seqField == null ? "": seqField;
		this.isaContactId = isaContactId == null ? "": isaContactId;
		this.productId = productId == null ? "": productId;
		this.functionIdInd = functionIdInd == null ? "": functionIdInd;
		this.attributeCd = attributeCd == null ? "": attributeCd;
	}
	
	/**
	 * @return the appId
	 */
	public String getAppId()
	{
		return appId;
	}
	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId)
	{
		this.appId = appId;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName()
	{
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName()
	{
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}
	/**
	 * @return the loginId
	 */
	public String getLoginId()
	{
		return loginId;
	}
	/**
	 * @param loginId the loginId to set
	 */
	public void setLoginId(String loginId)
	{
		this.loginId = loginId;
	}
	/**
	 * @return the ritsId
	 */
	public String getRitsId()
	{
		return ritsId;
	}
	/**
	 * @param ritsId the ritsId to set
	 */
	public void setRitsId(String ritsId)
	{
		this.ritsId = ritsId;
	}
	/**
	 * @return the geId
	 */
	public String getGeId()
	{
		return geId;
	}
	/**
	 * @param geId the geId to set
	 */
	public void setGeId(String geId)
	{
		this.geId = geId;
	}
	/**
	 * @return the functionCode
	 */
	public String getFunctionCode()
	{
		return functionCode;
	}
	/**
	 * @param functionCode the functionCode to set
	 */
	public void setFunctionCode(String functionCode)
	{
		this.functionCode = functionCode;
	}
	/**
	 * @return the functionDesc
	 */
	public String getFunctionDesc()
	{
		return functionDesc;
	}
	/**
	 * @param functionDesc the functionDesc to set
	 */
	public void setFunctionDesc(String functionDesc)
	{
		this.functionDesc = functionDesc;
	}
	
	/**
	 * @return the soeId
	 */
	public String getSoeId()
	{
		return soeId;
	}

	/**
	 * @param soeId the soeId to set
	 */
	public void setSoeId(String soeId)
	{
		this.soeId = soeId;
	}

	/**
	 * @return the entitlement
	 */
	public String getEntitlement()
	{
		return entitlement;
	}
	/**
	 * @param entitlement the entitlement to set
	 */
	public void setEntitlement(String entitlement)
	{
		this.entitlement = entitlement;
	}
	/**
	 * @return the drillDownCd
	 */
	public String getDrillDownCd()
	{
		return drillDownCd;
	}
	/**
	 * @param drillDownCd the drillDownCd to set
	 */
	public void setDrillDownCd(String drillDownCd)
	{
		this.drillDownCd = drillDownCd;
	}
	/**
	 * @return the seqField
	 */
	public String getSeqField()
	{
		return seqField;
	}
	/**
	 * @param seqField the seqField to set
	 */
	public void setSeqField(String seqField)
	{
		this.seqField = seqField;
	}
	/**
	 * @return the isaContactId
	 */
	public String getIsaContactId()
	{
		return isaContactId;
	}
	/**
	 * @param isaContactId the isaContactId to set
	 */
	public void setIsaContactId(String isaContactId)
	{
		this.isaContactId = isaContactId;
	}
	/**
	 * @return the productId
	 */
	public String getProductId()
	{
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId)
	{
		this.productId = productId;
	}
	/**
	 * @return the functionIdInd
	 */
	public String getFunctionIdInd()
	{
		return functionIdInd;
	}
	/**
	 * @param functionIdInd the functionIdInd to set
	 */
	public void setFunctionIdInd(String functionIdInd)
	{
		this.functionIdInd = functionIdInd;
	}
	/**
	 * @return the attributeCd
	 */
	public String getAttributeCd()
	{
		return attributeCd;
	}
	/**
	 * @param attributeCd the attributeCd to set
	 */
	public void setAttributeCd(String attributeCd)
	{
		this.attributeCd = attributeCd;
	}
	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid()
	{
		return serialVersionUID;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return appId + "\t" + lastName + "\t" + firstName + "\t" + loginId + "\t" + ritsId + "\t" + geId + "\t"+ functionCode + "\t" + functionDesc + "\t" + soeId + "\t"+ entitlement + "\t" + drillDownCd + "\t" + seqField + "\t"	+ isaContactId + "\t" + productId + "\t" + functionIdInd + "\t" + attributeCd;
	}

}
