package com.citi.icg.qma.common.messagebus.entity;

import java.util.List;

public class InquiryDetails {
	
	private Long inquiryId;
	private String conversationId;
	private List<EntityDetails> entityDetails;
	private String taxId;
	
	public InquiryDetails() {
		super();
	}
	public Long getInquiryId() {
		return inquiryId;
	}
	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}
	
	public String getTaxId() {
		return taxId;
	}
	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}
	public String getConversationId() {
		return conversationId;
	}
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}
	public List<EntityDetails> getEntityDetails() {
		return entityDetails;
	}
	public void setEntityDetails(List<EntityDetails> entityDetails) {
		this.entityDetails = entityDetails;
	}
	
	
}
