package com.citi.icg.qma.common.core.config;

public interface ConfigReader<T>
{
	public T readConfiguration(Object input) throws ConfigurationException;
}
