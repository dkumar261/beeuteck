package com.citi.icg.qma.common.core.transformer;

import org.apache.commons.collections4.Transformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class GenericXMLToObjectTransformer implements Transformer
{
    private DefaultMarshaller defMrshaller;
    private boolean validate;
    private Logger log;
    
    public GenericXMLToObjectTransformer(Class<?> classType, boolean validate)
    {
    	
        this.defMrshaller = new DefaultMarshaller(classType);
        this.validate = validate;
        
    	log = LoggerFactory.getLogger(getClass());
    	log.debug("GenericXMLToObjectTransformer created for class : {}" ,classType.getName());
    }

    public GenericXMLToObjectTransformer(Class<?> classType)
    {
    	this(classType, false);
    }

    public Object transform(Object object) throws TransformationExcept
    {
        Object javaObject = null;
        String xml = (String) object;
        log.debug("GenericXMLToObjectTransformer.transform(Object) xml {}", xml);

        javaObject = defMrshaller.genericUnmarshal(xml, validate);

        log.debug("Unmarshalled Object {}", object);
        return javaObject;
    }
}
