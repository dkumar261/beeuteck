/**
 * 
 */
package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.List;

/**
 * 
 *
 */
import dev.morphia.annotations.Embedded;

@Embedded
public class GroupHolidayDetails implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 9025430671189809189L;
	private boolean isHolidayBasedAgeCalculation;
	private String timeZone;
	private String shiftStartTime;
	private String shiftEndTime;
	private List<String> weeklyOffDays;
	private List<HolidayMaster> holidays;
	
	/**
	 * @return the isHolidayBasedAgeCalculation
	 */
	public boolean isHolidayBasedAgeCalculation() {
		return isHolidayBasedAgeCalculation;
	}

	/**
	 * @param isHolidayBasedAgeCalculation the isHolidayBasedAgeCalculation to set
	 */
	public void setHolidayBasedAgeCalculation(boolean isHolidayBasedAgeCalculation) {
		this.isHolidayBasedAgeCalculation = isHolidayBasedAgeCalculation;
	}

	/**
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return timeZone;
	}

	/**
	 * @param timeZone the timeZone to set
	 */
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	/**
	 * @return the shiftStartTime
	 */
	public String getShiftStartTime() {
		return shiftStartTime;
	}

	/**
	 * @param shiftStartTime the shiftStartTime to set
	 */
	public void setShiftStartTime(String shiftStartTime) {
		this.shiftStartTime = shiftStartTime;
	}

	/**
	 * @return the shiftEndTime
	 */
	public String getShiftEndTime() {
		return shiftEndTime;
	}

	/**
	 * @param shiftEndTime the shiftEndTime to set
	 */
	public void setShiftEndTime(String shiftEndTime) {
		this.shiftEndTime = shiftEndTime;
	}

	/**
	 * @return the weeklyOffDays
	 */
	public List<String> getWeeklyOffDays() {
		return weeklyOffDays;
	}

	/**
	 * @param weeklyOffDays the weeklyOffDays to set
	 */
	public void setWeeklyOffDays(List<String> weeklyOffDays) {
		this.weeklyOffDays = weeklyOffDays;
	}

	/**
	 * @return the holidays
	 */
	public List<HolidayMaster> getHolidays() {
		return holidays;
	}

	/**
	 * @param holidays the holidays to set
	 */
	public void setHolidays(List<HolidayMaster> holidays) {
		this.holidays = holidays;
	}
}
