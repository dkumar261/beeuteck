package com.citi.icg.qma.common.transferobject;

public class GFCIDTO
{
	private String gfcId;
	private String gfcName;
	private String gfpId;
	private String gfpName;
	private String skAccountNo;
	private String branch;
	
	public GFCIDTO(){
		
	}

	public String getGfcId()
	{
		return gfcId;
	}

	public void setGfcId(String gfcId)
	{
		this.gfcId = gfcId;
	}

	public String getGfpId()
	{
		return gfpId;
	}

	public void setGfpId(String gfpId)
	{
		this.gfpId = gfpId;
	}

	public String getGfcName()
	{
		return gfcName;
	}

	public void setGfcName(String gfcName)
	{
		this.gfcName = gfcName;
	}

	public String getGfpName()
	{
		return gfpName;
	}

	public void setGfpName(String gfpName)
	{
		this.gfpName = gfpName;
	}

	/**
	 * @return the skAccountNo
	 */
	public String getSkAccountNo() {
		return skAccountNo;
	}

	/**
	 * @param skAccountNo the skAccountNo to set
	 */
	public void setSkAccountNo(String skAccountNo) {
		this.skAccountNo = skAccountNo;
	}

	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}

	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}
}
