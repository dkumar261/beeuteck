package com.citi.icg.qma.hazelcast.cache.client;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;

import com.citi.icg.qma.common.server.dao.ClientMapping;
import com.citi.icg.qma.common.server.dao.ColumnDef;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.CustomClientCriteriaRuleBean;
import com.citi.icg.qma.common.server.dao.EmailAlias;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.HolidayMaster;
import com.citi.icg.qma.common.server.dao.IncomingToCcDLAliasMapping;
import com.citi.icg.qma.common.server.dao.MailBoxDLMapping;
import com.citi.icg.qma.common.server.dao.ManagementHeirarchy;
import com.citi.icg.qma.common.server.dao.OrgPreferences;
import com.citi.icg.qma.common.server.dao.OrganizationAuditTrail;
import com.citi.icg.qma.common.server.dao.RoutingCriteriaBean;
import com.citi.icg.qma.common.server.dao.StaticData;
import com.citi.icg.qma.common.server.dao.TimeZone;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.ViewConfig;
import com.citi.icg.qma.common.server.util.AgeAndTimeUtils.GroupShiftConfig;
import com.citi.icg.qma.common.transferobject.SymphonyUserMapTO;


public interface QMACache {

	//ClientMapping
	Map<String, ClientMapping> getClientMappingMap();

	//MailBoxDLMapping
	Map<String, MailBoxDLMapping> getMailBoxDLMappingMap();
	
	//Config
	Map<String, String> getMsExchangeServerMap();
	Map<String, String> getMsExchangeServerMapParallel();
	Map<String, Config> getConfigIdEscalationCriteriaMap();
	boolean getSmartRoutingFlagFromConfig();
	List<String> getCitiDomainsList();
	Config getConfigById(String configId);
	Map<String, List<String>> getAutoFwdConfigMap();
	List<TimeZone> getTimeZonesConfig();
	
	//Group
	Map<String, List<String>> getParentToChildDLsListMap();
	Map<Long, List<RoutingCriteriaBean>> getDbRoutingCriteriaList();
	Map<String, String> getGroupCodeToEmailMap();
	Map<String, Group> getEmailWithDomaintoGroupMap();
	Map<Long, Boolean> getGroupIdToActiveMap();
	List<Group> getGroupList();
	Map<Long, List<String>> getGroupIdToCIMSEmailList();
	Map<Long, List<String>> getGroupIdToManualEmailList();
	Map<Long, String> getGroupIdToNameMap();
	Map<String, String> getIncomingToCcDLAliasMappingEmailsMap();
	Map<Long, Group> getAllGroupsMap();
	Map<Long, List<String>> getGroupIdToTagMap();
	Map<Long, List<String>> getGroupIdToRequestTypeMap();
	Map<Long, List<String>> getGroupIdToProcessingRegionMap();
	Map<String, Long> getGroupCodeToIdMap();
	Map<String, Long> getGroupEmailToIdMap();
	Map<Long, String> getGroupIdToEmailMap();
	Map<Long, String> getGroupIdToDisclaimerMap();
	Map<Long, String> getGroupIdToCodeMap();
	Map<Long, String> getGroupIdToGrpCrtDateMap();
	Map<Long, ManagementHeirarchy> getGroupIdToHierarchyMap();
	Map<Long, List<EmailAlias>> getGroupIdToParentDLEmailAliasListMap();
	Map<String,List<HolidayMaster>> getHolidayMasterMap();
	Map<Long,GroupShiftConfig> getGroupAgeConfigMap();
	//StaticData
	List<IncomingToCcDLAliasMapping> getIncomingToCcDLAliasMapping();
	List<String> getIgnoreEmailListForProcessing();
	Long getBccRoutingGroup();
	String getEnableConvReferenceCheckAlways();
	String getEnableInternalGroupEmailRouting();
	List<String> getInternalGrpRoutingInclusionList();
	String getDisableOnBehalfOf();
	List<String> getDisableOnBehalfOfGrpList();
	List<String> getQmaMailServers();
	Map<Long, List<CustomClientCriteriaRuleBean>> getDbCustomClientCriteriaList();
	Map<Long, List<String>> getGroupIdToUserListMap();
	String getEnableMakerCheckerForUnapprovedDomains();
	int getConvLimitCount();
	List<ColumnDef> getMasterColumnDef();
	String getDefaultDateFormate();
	/**
	 * @return
	 * This API gives the NLPSuggestionMandatoryGroupsList in UPPERCASE 
	 */
	//Map<String, List<String>> getNlpSubsciptionGroups();
	List<String> getNlpSubsciptionGroups(String catetory);
	Map<String, Object> getNlpConfiguration();
	
	List<Long> getBccGroupIdList();
	String getEnableCharacterEncoding();
	String getCslRestServerUrl();

	int getRefreshTimeMinutes();
	

	
	//User
	Map<String, User> getUserInfoMap();

	Map<String, Object> getClcConfiguration();

	Map<String, Object> getOasysPaymentProcessingConfig();

	// APIs For Personal Inbox 
	List<Long> getPersonalGroupIdList();
	Map<String, Long> getPersonalMailboxIdToGroupIdMap();
	Map<Long, Boolean> getPersonalIdToActiveMap();
    Map<Long, String> getPersonalIdToEmailMap();
    Map<Long, String> getPersonalIdToCodeMap();
    Map<Long, String> getPersonalIdToNameMap();

    Map<String, Long> getPersonalCodeToIdMap();
    Map<String, Long> getPersonalEmailToIdMap();
    Map<String, String> getPersonalEmailToCodeMap();
    Map<String, String> getPersonalCodeToEmailMap();
    Map<Long, List<String>> getPersonalIdToCIMSEmailList();
    Map<Long, List<String>> getPersonalIdToManualEmailList();
    
	boolean isMailboxStatsExecutorFlag();
	Boolean isLogMaskingEnabled();
	Boolean isUIDataMaskingEnabled();
	int getReRefreshTimeMinutes();
	Map<String, Object> getQmaPersonalConfig();
	
	//Missing maps for UI
	 Map<String, Long> getGroupCodeToIdMapBothActiveInactive();
	 Map<String, String> getGroupIdToCodeMapBothActiveInactive();
	 Map<String, String> getGroupIdToEmailMapBothActiveInactive();
	 Map<String, SymphonyUserMapTO> getUserSymphonyIdToUserMap();
	 Map<String, String> getGroupIdToDBCodeMap();
	 Map<String, String> getGroupEmailToCodeMap();
	 
	 Map<Long, String> getAutoAssignmentEnabledGroupMap();
	 List<String> getAutoReplySuggestionEnabledGroupList();
	 List<String> getCustodySuggestionEnabledGroupList();
	 void preload();
	 
	 //C170665-185 for hard code data point
	 Map<String,List<Group>> getOrgGroupMap();
	 List<OrganizationAuditTrail>getOrgRequestsList();
	 
	 enum CATEGORY {
		 ORG_REQUESTS("orgRequests", " Org Requests Data "),
		 SYMPHONY_CONFIG("userSymphonyIdToUserMap", " Symphony Config data "),
		 NLP_SUBSCRIPTION_CONFIG("nlpSubscriptionGroupsMap", " NLP config data "),
		 CONFIG_MAP("configMap", " config data "),
		 MAILBOX_CONFIG("mailBoxDLMappingMap"," mailbox config "),
		 USER_INFO_MAP("userInfoMap", " user data "),
		 CLIENT_MAPPING("clientMappingMap", " client mapping data "),		 
		 GROUP_DATA("groupDataMap", " group data "),
		 STATIC_DATA("staticDataMap", " static config datat ");
		 
		 public String name;
		 public String description;
		 
		 private CATEGORY(String name, String description) {
			 this.name = name;
			 this.description = description;
		 }
		 
	 }

	Long getPubSubMonitorTimeMillis();

	String getPubSubMonitorEmail();

	String getEnableOptimizePubSub();

	String getEnablePubSubMonitor();

	String getEnableGraphs();

	Long getMaxJobRetryCount();

	String getSolrURL();

	Map<String,Map<String, Integer>> getUserHighestDateConfiguredViewMap();
	String getDefaultInboxName();

	Map<String, ViewConfig> getDefaultViewMap();

	StaticData getDefaultStaticData();

	List<String> getDefaultViewNameList();
	
	Config getXmcExportDlConfig();
	
	//[C170665-1719] DCC Requirement: Add Case status field
	Map<String, OrgPreferences> getOrgNameToOrgPref();
	HashMap<Long, String>  getGroupIdToOrgName();
	
	//[C170665-3742] Added this in cache to fix delay issue for taskize in prod
	Map<String, String> getUserSoeIdToEmailIdMap();

	List<String> getIntentSuggestionEnabledGroupList();
}
