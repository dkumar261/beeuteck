package com.citi.icg.qma.common.server.dao;

import java.util.List;

import com.citi.icg.qma.common.core.util.MsgSourceType;

import dev.morphia.annotations.Entity;

@Entity(value = "InquiryMessageRef", noClassnameStored = true)
public class InquiryMessageRef extends BaseEntity
{

	private String messageId;
	private String references;
	private Long inquiryId;

	private String latestMessageId;
	
	private String secondRef;
	private String thirdRef;
	private List<String> referencesAudit;
	private MsgSourceType msgSourceType;
	private String threadTopic;
	/*Line of business tag for email */
	private String lob;
	
	
	public String getThreadTopic() {
		return threadTopic;
	}

	public void setThreadTopic(String threadTopic) {
		this.threadTopic = threadTopic;
	}

	public InquiryMessageRef()
	{
		super();
	}

	public InquiryMessageRef(String messageId, String references,
			Long inquiryId, String latestMessageId, String secondRef, String thirdRef)
	{
		super();
		this.messageId = messageId;
		this.references = references;
		this.inquiryId = inquiryId;
		// this.createdBy = createdBy;
		// this.createdDate = createdDate;
		this.latestMessageId = latestMessageId;
		this.secondRef = secondRef;
		this.thirdRef = thirdRef;
	}

	public String getMessageId()
	{
		return messageId;
	}

	public void setMessageId(String messageId)
	{
		this.messageId = messageId;
	}

	public String getReferences()
	{
		return references;
	}

	public void setReferences(String references)
	{
		this.references = references;
	}

	public Long getInquiryId()
	{
		return inquiryId;
	}

	public void setInquiryId(Long inquiryId)
	{
		this.inquiryId = inquiryId;
	}

	public String getLatestMessageId()
	{
		return latestMessageId;
	}

	public void setLatestMessageId(String latestMessageId)
	{
		this.latestMessageId = latestMessageId;
	}
	public String getSecondRef()
	{
		return secondRef;
	}

	public void setSecondRef(String secondRef)
	{
		this.secondRef = secondRef;
	}

	public String getThirdRef()
	{
		return thirdRef;
	}

	public void setThirdRef(String thirdRef)
	{
		this.thirdRef = thirdRef;
	}

	public List<String> getReferencesAudit()
	{
		return referencesAudit;
	}

	public void setReferencesAudit(List<String> referencesAudit)
	{
		this.referencesAudit = referencesAudit;
	}

	public MsgSourceType getMsgSourceType() {
		return msgSourceType;
	}

	public void setMsgSourceType(MsgSourceType msgSourceType) {
		this.msgSourceType = msgSourceType;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}
	
	
	
}
