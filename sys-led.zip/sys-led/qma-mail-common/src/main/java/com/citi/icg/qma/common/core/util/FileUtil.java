package com.citi.icg.qma.common.core.util;

public class FileUtil
{
	
	private FileUtil(){
		//As this class is Util, so added making private constructor.
		//Sonar Fix -- Utility classes should not have public constructors 
	}
	
	/**
	 * @param instId
	 * @return
	 */
	public static String getFileNameOnly(String fileName)
	{
		int idx = 0;
		int length = 0;
		if (fileName != null && fileName.length() > 0)
		{
			idx = fileName.lastIndexOf("\\");
			idx += 1;
			length = fileName.length();

		}
		return fileName.substring(idx, length);
	}
}
