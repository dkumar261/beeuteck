/**
 * 
 */
package com.citi.icg.qma.common.server.dao.persistence;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.core.util.MailCommonUtil;
import com.citi.icg.qma.common.core.util.NLPConstants;
import com.citi.icg.qma.common.core.util.QmaMailConstants;
import com.citi.icg.qma.common.server.cache.ConversationCache;
import com.citi.icg.qma.common.server.dao.AutoAssignedInquiry;
import com.citi.icg.qma.common.server.dao.AutoRouting;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.Intents;
import com.citi.icg.qma.common.server.dao.NLPSuggestionRecord;
import com.citi.icg.qma.common.server.dao.NLPSuggestionRecord.GroupData;
import com.citi.icg.qma.common.server.dao.NLPSuggestionRecord.IntentFeedback;
import com.citi.icg.qma.common.server.dao.RulesFlag;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.Workflow;
import com.citi.icg.qma.common.server.dao.WorkflowAudit;
import com.citi.icg.qma.common.server.util.AutoRoutingUtil;
import com.citi.icg.qma.common.server.util.DateUtil;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.common.server.util.NLPQueryEngineUtil;
import com.citi.icg.qma.common.server.util.NLPRequestType;
import com.citi.icg.qma.common.server.util.NlpAutoAssignmentValidationException;
import com.citi.icg.qma.common.server.util.SuggestionStatusIndicator;
import com.citi.icg.qma.common.transferobject.ConversationTO;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.hazelcast.internal.util.collection.Object2LongHashMap.EntrySet;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

import dev.morphia.query.FindOptions;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

/**
 *  DAO class to serve all data access operations for NLP
 *         suggestion
 */
public class NLPSuggestionDAO extends MongoMorphiaDAO {

	private static final String AUTO_ASSIGNMENT_AVAILABLE_FLAG = "autoAssignmentAvailable";
	private static final Logger logger = LoggerFactory.getLogger(NLPSuggestionDAO.class);
	private static final InquiryCommonDAO inquiryCommonDAO = new InquiryCommonDAO();
	private static final String WORKFLOWS = "workflows";
	private static final String WORKFLOW_AUDIT = "workflowAudit";
	public static final String ACTION_NEW = "New Inquiry";
	public static final InquiryDAO inquiryDoa = new InquiryDAO();

	/**
	 * This method updates suggestion response in in database for suggestion
	 * received from NLP server
	 * 
	 * @param inputJsonObj
	 */
	public NLPSuggestionRecord updateSuggestionWithResponse(BasicDBObject inputJsonObj) {
		logger.info("NLP Engine updating inquiry conversation.");
		Date currentDate = new Date();
		String sugResponse = inputJsonObj.getString(NLPConstants.SUGGESTED_REPLY_KEY);
		String clientReqId = inputJsonObj.getString(NLPConstants.CLIENT_REQUEST_ID_KEY);
		String nlpRequestId = inputJsonObj.getString(NLPConstants.NLP_REQUEST_ID);
		logger.info("NLP Response Received at : " + currentDate + " for QMA RequestId -" + clientReqId
				+ " with NLPRequestId -" + nlpRequestId);
		NLPSuggestionRecord sugRecord = getSuggestionRecordForClientRequestId(clientReqId);
		if (sugRecord != null) {
			extractNLPResponseAPIIntermediateData(inputJsonObj, sugRecord);
			sugRecord.setSuggestedResponse(sugResponse);
			sugRecord.setNlpRequestId(nlpRequestId);
			sugRecord.setModDate(currentDate);
			sugRecord.setNlpResponseReceivedDate(currentDate);
			setNlpReponseTime(currentDate, sugRecord);
			if (getAutoAssignmentSubscriptionEnable(sugRecord.getNlpRequestType())) {
				AutoRoutingUtil.setAutoRoutingFromNLPResponse(inputJsonObj, sugRecord);
			}
			if(NLPRequestType.I.name().equalsIgnoreCase(sugRecord.getNlpRequestType()) 
					&& null != inputJsonObj.getString(NLPConstants.INTENT_WORKFLOW_KEY)
					&& NLPConstants.INTENT_KEYWORD.equalsIgnoreCase(inputJsonObj.getString(NLPConstants.INTENT_WORKFLOW_KEY))) {
				AutoRoutingUtil.setIntentsFromNlpResponse(inputJsonObj, sugRecord);
			}
			if (null != inputJsonObj.get(NLPConstants.SUGGESTED_RESPONSE_TRADE_DETAILS)) {
				List<Object> suggestedResponseTradeDetails = (List<Object>) inputJsonObj
						.get(NLPConstants.SUGGESTED_RESPONSE_TRADE_DETAILS);
				sugRecord.setSuggestedResponseTradeDetails(suggestedResponseTradeDetails);
			}
			if (null != inputJsonObj.get(NLPConstants.RESPONSE_LEVEL_INDICATOR)) {
				int responseLevelIndicator = inputJsonObj.getInt(NLPConstants.RESPONSE_LEVEL_INDICATOR);
				sugRecord.setResponseLevelIndicator(responseLevelIndicator);
			}
			extractNLPResponseAPITradesInfo(inputJsonObj, sugRecord);
			extractNLPResponseAPIStatitics(inputJsonObj, sugRecord);
			
			mongoDatastore.save(sugRecord);
			if (checkIfAutoRoutingIsEnabled()) {
				logger.info("Autorouting is enabled, processing request RequestId [{}] with NLPRequestId [{}]",
						clientReqId, nlpRequestId);
				if (null != sugRecord.getAutoRouting() && (null == sugRecord.getAutoRouting().getWorkflowQueueRouted()
						|| (null != sugRecord.getAutoRouting().getWorkflowQueueRouted() && !NLPConstants.YES
								.equalsIgnoreCase(sugRecord.getAutoRouting().getWorkflowQueueRouted()))))
					applyAutoRoutingToWorkflows(sugRecord, sugRecord.getAutoRouting());
			} else {
				logger.info(
						"Autorouting is disabled, so no processing will be done for RequestId [{}] with NLPRequestId [{}]",
						clientReqId, nlpRequestId);
			}
			updateConversationForSuggestion(sugRecord);
		} else {
			logger.info("No Suggestion request record found for requestId -" + clientReqId + " , ignore the request.");
		}
		return sugRecord;
	}
	/**
	 * @param inputJsonObj
	 * @param sugRecord
	 */
	private void extractNLPResponseAPIStatitics(BasicDBObject inputJsonObj, NLPSuggestionRecord sugRecord) {
		if (null != inputJsonObj.get(NLPConstants.STATISTICS)
				&& !inputJsonObj.getString(NLPConstants.STATISTICS).isEmpty() && !NLPRequestType.I.name().equalsIgnoreCase(sugRecord.getNlpRequestType())) {
			Map<String, Object> statistics = (Map<String, Object>) inputJsonObj.get(NLPConstants.STATISTICS);
			sugRecord.setStatistics(statistics);
			
		}
	}

	/**
	 * @param inputJsonObj
	 * @param sugRecord
	 */
	private void extractNLPResponseAPITradesInfo(BasicDBObject inputJsonObj, NLPSuggestionRecord sugRecord) {
		if (null != inputJsonObj.get(NLPConstants.TRADESINFO)
				&& !inputJsonObj.getString(NLPConstants.TRADESINFO).isEmpty()) {
			sugRecord.setTradesInfo(inputJsonObj.getString(NLPConstants.TRADESINFO));
		}
	}
	/**
	 * @param inputJsonObj
	 * @param sugRecord
	 */
	private void extractNLPResponseAPIIntermediateData(BasicDBObject inputJsonObj, NLPSuggestionRecord sugRecord) {

		try {
			// New fields
			if (null != inputJsonObj.get(NLPConstants.REPLY_COMMENT_KEY)
					&& !inputJsonObj.getString(NLPConstants.REPLY_COMMENT_KEY).isEmpty()) {
				String replyComment = inputJsonObj.getString(NLPConstants.REPLY_COMMENT_KEY);
				sugRecord.setReplyComment(replyComment);
			}
			if (null != inputJsonObj.get(NLPConstants.INTERMEDIATEDATA_KEY)
					&& !inputJsonObj.getString(NLPConstants.INTERMEDIATEDATA_KEY).isEmpty()) {
				sugRecord.setIntermediateData(inputJsonObj.getString(NLPConstants.INTERMEDIATEDATA_KEY));
			}
			if (null != inputJsonObj.get(NLPConstants.NLP_RESP_MEG_ATTR_KEY)
					&& !inputJsonObj.getString(NLPConstants.NLP_RESP_MEG_ATTR_KEY).isEmpty() 
					&& !NLPRequestType.I.name().equals(sugRecord.getNlpRequestType())) {
				sugRecord.setMessage(inputJsonObj.getString(NLPConstants.NLP_RESP_MEG_ATTR_KEY));
			}
		} catch (Exception e) {
			logger.warn("No parsable intermediate data for NLP response requestId:" + sugRecord.getNlpRequestId(), e);
		}
	}

	private boolean checkIfAutoRoutingIsEnabled() {
		boolean isAutoRoutingEnabled = false;
		try {
			Map<String, Object> nlpConfig = QMACacheFactory.getCache().getNlpConfiguration();
			if (null != nlpConfig && null != nlpConfig.get("enableAutoRouting")
					&& "Y".equalsIgnoreCase(nlpConfig.get("enableAutoRouting").toString())) {
				isAutoRoutingEnabled = true;
			}
		} catch (Exception e) {
			logger.error("Exception occurred while checking if auto routing is enabled", e);
		}
		return isAutoRoutingEnabled;
	}

	/*
	 * Set NLP Response Time in seconds
	 */
	private void setNlpReponseTime(Date currentDate, NLPSuggestionRecord sugRecord) {
		String nlpRespTimeInSecs = null;
		if (null != sugRecord.getNlpRequestSentDate()) {
			double differenceTimeMillis = currentDate.getTime() - sugRecord.getNlpRequestSentDate().getTime();
			nlpRespTimeInSecs = "%.3f".formatted(differenceTimeMillis / (1000));
		}
		sugRecord.setNlpRespTimeInSecs(nlpRespTimeInSecs);
	}

	/**
	 * This method updates the response status for the sent request.
	 * 
	 * @param clientRequestId
	 * @param reqStatusInd
	 * @param statusText
	 */
	public void updateSugReqStatus(String clientRequestId, Integer reqStatusInd, String statusText) {
		logger.info("NLP Engine updating inquiry conversation.");
		Date currentDate = new Date();
		logger.info(
				" NLP Engine updateSugReqStatus Received at : " + currentDate + " for requestId -" + clientRequestId);

		NLPSuggestionRecord sugRecord = getSuggestionRecordForClientRequestId(clientRequestId);
		if (sugRecord != null) {
			sugRecord.setSuggestionReqStatusCode(reqStatusInd);
			sugRecord.setSuggestionReqStatusDesc(statusText);
			if (reqStatusInd == HttpStatus.SC_ACCEPTED) {
				sugRecord.setProcessingStatus(NLPConstants.PROCESSING_STATUS_SUCCESSFUL);
			} else if (reqStatusInd == HttpStatus.SC_BAD_REQUEST) {
				sugRecord.setProcessingStatus(NLPConstants.PROCESSING_STATUS_RESOURCE_ERROR);
			}
			mongoDatastore.save(sugRecord);
		} else {
			logger.info(
					"No Suggestion request record found for requestId -" + clientRequestId + " , ignore the request.");
		}
	}

	/**
	 * This method updates saved suggestion record once we get the reply back from
	 * NLP query engine
	 * 
	 * @param actionConversation
	 * @param clientRequestId
	 * @param sugRequestBody
	 * @param toCCValidGroupIds
	 * @param currentTime
	 * @param actionBy
	 */
	public void createSuggestionRequestRecord(Conversation actionConversation, String clientRequestId,
			BasicDBObject sugRequestBody, List<Long> toCCValidGroupIds, Date currentTime, String actionBy,
			String nlpRequestType) {
		try {
			NLPSuggestionRecord sugRecord = new NLPSuggestionRecord();
			sugRecord.setQmaRequestId(clientRequestId);
			sugRecord.setCrtDate(currentTime);
			sugRecord.setInquiryid(actionConversation.getInquiryId());
			sugRecord.setConversationId(actionConversation.getId());
			sugRecord.setNlpRequestSentDate(currentTime);
			sugRecord.setSuggestionReqBody(sugRequestBody != null ? sugRequestBody.toJson() : null);
			sugRecord.setActionBy(actionBy);
			sugRecord.setNlpRequestType(nlpRequestType);
			if (toCCValidGroupIds != null && !toCCValidGroupIds.isEmpty()) {
				sugRecord.setValidToCcGroupIds(toCCValidGroupIds);
				setGroupData(sugRecord, toCCValidGroupIds, actionConversation.getInquiryId(), nlpRequestType);
			}
			mongoDatastore.save(sugRecord);
		} catch (Exception e) {
			logger.error("Error while creating NLPSuggestionRecord in createSuggestionRequestRecord() :", e);
		}
	}

	/**
	 * This method removed external non QMA email ids/DLs
	 * 
	 * @param toCCValidGroupIds
	 * @return
	 */
	private List<Long> getValidGroups(List<Long> toCCValidGroupIds) {
		List<Long> validGroupList = new ArrayList<>();
		QMACache qmaCache = QMACacheFactory.getCache();
		Map<Long, String> groupIdToNameMap = qmaCache.getGroupIdToNameMap();
		for (Long grpId : toCCValidGroupIds) {
			String groupCode = grpId == null ? null : groupIdToNameMap.get(grpId);
			if (null != groupCode && !groupCode.isEmpty()) {
				validGroupList.add(grpId);
			}
		}
		return validGroupList;
	}

	/**
	 * This method sets group data for new request.
	 * 
	 * @param sugRecord
	 * @param toCCValidGroupIds
	 * @param inquiryId
	 */
	void setGroupData(NLPSuggestionRecord sugRecord, List<Long> toCCValidGroupIds, Long inquiryId,
			String nlpRequestType) {
		try {
			if (sugRecord != null && toCCValidGroupIds != null && !toCCValidGroupIds.isEmpty()) {
				QMACache qmaCache = QMACacheFactory.getCache();
				Map<Long, String> getGroupIdToCodeMap = qmaCache.getGroupIdToCodeMap();
				// List<String> nlpCommonSubGrps =
				// qmaCache.getNlpSubsciptionGroups("nlpSuggestionMandatoryGroups");
				List<String> nlpCommonSubGrps = qmaCache.getCustodySuggestionEnabledGroupList();
				// List<String> nlpSettsGrps =
				// qmaCache.getNlpSubsciptionGroups("nlpSettsMandatoryGroups");
				List<String> nlpSettsGrps = qmaCache.getAutoReplySuggestionEnabledGroupList();
				// List<String> grpNlpSuggestionInclusionList =
				// QMACacheFactory.getCache().getNlpSuggestionMandatoryGroups();
				
				List<String> nlpIntentsGrps = qmaCache.getIntentSuggestionEnabledGroupList();
				for (Long grpId : toCCValidGroupIds) {
					String groupCode = grpId == null ? null : getGroupIdToCodeMap.get(grpId);
					if (nlpCommonSubGrps != null && groupCode != null && nlpCommonSubGrps.contains(groupCode)
							&& nlpRequestType.equals(NLPRequestType.C.toString())) {
						updateGroupData(sugRecord, grpId, inquiryId);
					} else if (nlpSettsGrps != null && groupCode != null
							&& nlpSettsGrps.contains(groupCode.toUpperCase())
							&& nlpRequestType.equals(NLPRequestType.S.toString())) {
						updateGroupData(sugRecord, grpId, inquiryId);
					} else if(null != nlpIntentsGrps && groupCode != null
							&& nlpIntentsGrps.contains(groupCode.toUpperCase())
							&& NLPRequestType.I.name().equals(nlpRequestType)) {
						sugRecord.addToEligibleGroupIdList(grpId);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while retrieving group data for record :", e);
		}
	}

	/**
	 * This method identifies all the qualified groups and update group data for NLP
	 * record
	 * 
	 * @param sugRecord
	 * @param grpNlpSuggestionInclusionList
	 * @param groupId
	 * @param inquiryId
	 */
	private void updateGroupData(NLPSuggestionRecord sugRecord, Long groupId, Long inquiryId) {

		sugRecord.addToEligibleGroupIdList(groupId);
		GroupData grpData = new GroupData(groupId);
		if (null != sugRecord.getGroupData()) {
			sugRecord.getGroupData().add(grpData);
		} else {
			List<GroupData> groupData = new ArrayList<>();
			groupData.add(grpData);
			sugRecord.setGroupData(groupData);
		}
		/* Also update status in inquiry WorkFlow */
		// updateSuggestionIndicatorForInquiry(inquiryId, groupId,
		// SuggestionStatusIndicator.O);
		// updateConversationAsAwaitingResponse(sugRecord, SuggestionStatusIndicator.O);
	}

	/**
	 * This method identifies all the qualified groups and update group data for NLP
	 * record
	 * 
	 * @param sugRecord
	 * @param grpNlpSuggestionInclusionList
	 * @param groupId
	 * @param inquiryId
	 */
	private void updateGroupData(NLPSuggestionRecord record, BasicDBObject activityObj) {
		try {
			Query<NLPSuggestionRecord> query = mongoDatastore.createQuery(NLPSuggestionRecord.class).filter("id",
					record.getId());
			UpdateOperations<NLPSuggestionRecord> ops = mongoDatastore.createUpdateOperations(NLPSuggestionRecord.class)
					.set("groupData", record.getGroupData());
			mongoDatastore.update(query, ops);

		} catch (Exception e) {
			logger.error("Error while updating suggestion record into database for inquiry(" + record.getInquiryid()
					+ ") : convId(" + record.getConversationId() + ")", e);
		}
	}

	/**
	 * This method returns NLPSuggestionRecord for provided clientRequestId
	 * 
	 * @param clientRequestId
	 * @return NLPSuggestionRecord
	 */
	private NLPSuggestionRecord getSuggestionRecordForClientRequestId(String clientRequestId) {
		Query<NLPSuggestionRecord> query = null;
		NLPSuggestionRecord sugRecord = null;
		try {
			query = mongoDatastore.createQuery(NLPSuggestionRecord.class)
					.filter(NLPConstants.QMA_REQUEST_ID_KEY, clientRequestId).limit(1);
			query.order("-crtDate");
			sugRecord = query.get();
			if (sugRecord == null) {
				logger.error("No Active User data found for clientRequestId=" + clientRequestId);
			}
		} catch (Exception e) {
			logger.error("Exception in getSuggestionRecordForClientRequestId for  clientRequestId=" + clientRequestId,
					e);
		}
		return sugRecord;
	}

	/**
	 * This method fetches suggestions provided by NLP Query Engine and provide it
	 * back to caller.
	 * 
	 * @param soeId
	 * @param request
	 * @return BasicDBObject
	 * @throws CommunicatorException
	 */
	public BasicDBObject fetchConvSuggestions(String soeId, String request) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBObject reqObj = BasicDBObject.parse(request);
			final Long inquiryId = reqObj.getLong(NLPConstants.INQUIRY_ID_KEY);
			final Long convId = reqObj.getLong(NLPConstants.CONV_ID_KEY);
			final String nlpReqType = reqObj.getString(NLPConstants.NLP_REQUEST_TYPE_KEY);
			logger.info(soeId + " requested suggestion for (inquiryId : " + inquiryId + ", convId : " + convId + ")");
			if (null != inquiryId && null != convId) {
				final Long assignedGroupId = reqObj.getLong("groupId");
				
				NLPRequestType nlpRequestType;
				if(NLPRequestType.I.name().equals(nlpReqType)) {
					nlpRequestType = NLPRequestType.I;
				}else {
					nlpRequestType = getNlpRequestTypebyGroupId(assignedGroupId.toString());
				}
				NLPSuggestionRecord suggestionRecord = getSuggestionRecordForInqAndConvId(inquiryId, convId,
						nlpRequestType);
				if (suggestionRecord != null && !StringUtils.isBlank(suggestionRecord.getSuggestedResponse())) {
					response.put(NLPConstants.SUGGESTIONS_KEY, suggestionRecord.getSuggestedResponse());
					response.put(NLPConstants.SUGGESTIONS_RECEIVED_TIME_KEY,
							suggestionRecord.getNlpResponseReceivedDate());
					response.put(QmaMailConstants.SUCCESS_KEY, true);
					response.put(QmaMailConstants.MESSAGE_KEY, NLPConstants.SUGG_FOUND_MESSAGE);
				} else if (suggestionRecord != null && StringUtils.isBlank(suggestionRecord.getSuggestedResponse())) {
					response.put(NLPConstants.SUGGESTIONS_RECEIVED_TIME_KEY,
							suggestionRecord.getNlpResponseReceivedDate());
					response.put(QmaMailConstants.SUCCESS_KEY, false);
					response.put(QmaMailConstants.MESSAGE_KEY, NLPConstants.SUGG_NOT_FOUND_MESSAGE);
				} else {
					response.put(QmaMailConstants.SUCCESS_KEY, false);
					response.put(QmaMailConstants.MESSAGE_KEY, NLPConstants.SUGG_NOT_FOUND_MESSAGE);
				}

				if (null != suggestionRecord && null != suggestionRecord.getReplyComment()) {
					response.put(NLPConstants.REPLY_COMMENT_KEY, suggestionRecord.getReplyComment());
				}
				if (null != suggestionRecord && null != suggestionRecord.getIntermediateData()) {
					String intermediateData = suggestionRecord.getIntermediateData();
					response.put(NLPConstants.INTERMEDIATEDATA_KEY, intermediateData);
				}
				if (null != suggestionRecord && null != suggestionRecord.getSuggestedResponseTradeDetails()) {
					List<Object> suggestedResponseTradeDetails = suggestionRecord.getSuggestedResponseTradeDetails();
					response.put(NLPConstants.SUGGESTED_RESPONSE_TRADE_DETAILS, suggestedResponseTradeDetails);
				}
				// Added new
				if (null != suggestionRecord && null != suggestionRecord.getMessage()) {
					response.put(NLPConstants.API_RESPONSE_MESSAGE_KEY, suggestionRecord.getMessage());
				}
				if (null != suggestionRecord && null != suggestionRecord.getTradesInfo()) {
					String tradesInfo = suggestionRecord.getTradesInfo();
					response.put(NLPConstants.TRADESINFO, tradesInfo);
				}
				if(null != suggestionRecord && null != suggestionRecord.getIntentList() && !suggestionRecord.getIntentList().isEmpty()) {
					response.put(QmaMailConstants.SUCCESS_KEY, true);
					BasicDBList dblist = new BasicDBList();
					dblist.addAll(suggestionRecord.getIntentList());
					response.put(NLPConstants.INTENTS, dblist);
				}
			} else {
				response.put(QmaMailConstants.SUCCESS_KEY, false);
				response.put(QmaMailConstants.MESSAGE_KEY, NLPConstants.INVALID_INQID_OR_CONVID);
			}

		} catch (Exception e) {
			logger.error("Error in NLPSuggestionDAO#fetchConvSuggestions() : ", e);
			response.put(QmaMailConstants.SUCCESS_KEY, false);
			response.put(QmaMailConstants.MESSAGE_KEY, QmaMailConstants.SERVICE_FAILURE_MESSAGE);
		}
		return response;
	}

	/**
	 * This method creates suggestion record in database once we sends the request
	 * for the first time
	 * 
	 * @param actionConversation
	 * @param clientRequestId
	 * @param currentTime
	 */
	public void createSuggestionRequestRecord(Conversation actionConversation, String clientRequestId,
			Date currentTime) {
		try {
			NLPSuggestionRecord sugRecord = new NLPSuggestionRecord();
			sugRecord.setQmaRequestId(clientRequestId);
			sugRecord.setCrtDate(currentTime);
			sugRecord.setInquiryid(actionConversation.getInquiryId());
			sugRecord.setConversationId(actionConversation.getId());
			sugRecord.setNlpRequestSentDate(currentTime);
			mongoDatastore.save(sugRecord);
		} catch (Exception e) {
			logger.error("Issue happened in createSuggestionRequestRecord", e);
		}
	}

	/**
	 * This method provides latest suggestion data for provided inquiryId:convId
	 * 
	 * @param inquiryId
	 * @param convId
	 * @param nlpRequestType
	 * @return NLPSuggestionRecord
	 */
	public NLPSuggestionRecord getSuggestionRecordForInqAndConvId(Long inquiryId, Long convId,
			NLPRequestType nlpRequestType) {
		Query<NLPSuggestionRecord> query = null;
		NLPSuggestionRecord sugRecord = null;
		String nlpReqType = nlpRequestType.toString();
		// Auto-assignment happened in case of Settlement or Custody and assigned
		// groupId is non-subscribed group (type C or S)
		// in this case nlpRequestType is default that is A. So get correct request type
		// by checking whole eligible groupids again in subscription
		// This call only in case nlpRequestType A
		if ("A".equals(nlpReqType)) {
			nlpReqType = checkAutoAssignmentFromSettsOrCustody(inquiryId, convId);
		}
		try {
			final String dataString = "(inquiryId : " + inquiryId + ", convId : " + convId + ", nlpRequestType : "
					+ nlpReqType + ")";
			logger.info("Requested suggestion data for " + dataString);
			query = mongoDatastore.createQuery(NLPSuggestionRecord.class)
					.filter(NLPConstants.INQUIRY_ID_DB_KEY, inquiryId)
					.filter(NLPConstants.CONVERSATION_ID_DB_KEY, convId).filter("nlpRequestType", nlpReqType)
					.order("-nlpRequestSentDate");
			sugRecord = query.get();
			if (sugRecord == null) {
				logger.error(" No suggestion data found for" + dataString);
			}
		} catch (Exception e) {
			logger.error("Exception in NLPSuggestionDAO#getSuggestionRecordForInqAndConvId() :", e);
		}
		return sugRecord;
	}

	/**
	 * Auto-assignment happened in case of Settlement or Custody and assigned
	 * groupId is non-subscribed group (type C or S) in this case nlpRequestType is
	 * default that is A. So get correct request type by checking whole eligible
	 * groupids again in subscription
	 * 
	 * @param inquiryId
	 * @param convId
	 * @return
	 */
	private String checkAutoAssignmentFromSettsOrCustody(Long inquiryId, Long convId) {
		Query<NLPSuggestionRecord> query = null;
		NLPSuggestionRecord sugRecord = null;
		String nlpReqType = NLPRequestType.A.toString();
		try {
			final String dataString = "(inquiryId : " + inquiryId + ", convId : " + convId + ")";
			logger.info("Requested suggestion data for " + dataString);
			query = mongoDatastore.createQuery(NLPSuggestionRecord.class)
					.filter(NLPConstants.INQUIRY_ID_DB_KEY, inquiryId)
					.filter(NLPConstants.CONVERSATION_ID_DB_KEY, convId).order("-nlpRequestSentDate");
			sugRecord = query.get();
			if (sugRecord != null) {
				QMACache qmaCache = QMACacheFactory.getCache();
				Map<Long, String> groupIdToCodeMap = qmaCache.getGroupIdToCodeMap();
				// List<String> nlpCustodyGrps =
				// qmaCache.getNlpSubsciptionGroups("nlpSuggestionMandatoryGroups");
				List<String> nlpCustodyGrps = QMACacheFactory.getCache().getCustodySuggestionEnabledGroupList();
				// List<String> nlpSettsGrps =
				// qmaCache.getNlpSubsciptionGroups("nlpSettsMandatoryGroups");
				List<String> nlpSettsGrps = qmaCache.getAutoReplySuggestionEnabledGroupList();
				List<Long> eligibleGroupList = sugRecord.getEligibleGroupIdList();
				for (Long groupId : eligibleGroupList) {
					String groupCode = groupIdToCodeMap.get(groupId);
					if (nlpCustodyGrps.contains(groupCode)) {
						nlpReqType = NLPRequestType.C.toString();
						break;
					} else if (nlpSettsGrps.contains(groupCode.toUpperCase())) {
						nlpReqType = NLPRequestType.S.toString();
						break;
					}
				}
			} else {
				logger.error("No suggestion data found for" + dataString);
			}
		} catch (Exception e) {
			logger.error(
					"Exception while fetching nlpRequestType if auto-assignment happened with settelement or custody:",
					e);
		}
		return nlpReqType;
	}

	/**
	 * This method resends the Async request to refresh the suggestion for provided
	 * inquiryId and converstionID
	 * 
	 * @param soeId
	 * @param request
	 * @return BasicDBObject
	 */
	public BasicDBObject refreshSuggestion(String soeId, String request) {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBObject reqObj = BasicDBObject.parse(request);
			final String inquiryId = reqObj.getString(NLPConstants.INQUIRY_ID_KEY);
			final String convId = reqObj.getString(NLPConstants.CONV_ID_KEY);
			final String groupId = reqObj.getString(NLPConstants.GROUP_ID_KEY);
			final String action = reqObj.getString(NLPConstants.ACTION_KEY);
			final List<String> tradeRefList = (List<String>) reqObj.get("tradeRefList");
			logger.info("Refresh Suggestion request by " + soeId + " " + request);
			if (StringUtils.isNotEmpty(convId) && StringUtils.isNotEmpty(inquiryId)
					&& NLPConstants.ACTION_REFRESH.equalsIgnoreCase(action)) {
				Long conversationId = Long.valueOf(convId);
				Long inqId = Long.valueOf(inquiryId);
				ConversationTO convTO = inquiryCommonDAO.getInquiryConversationById(conversationId);
				if (convTO != null && convTO.getConversationList().get(0) != null) {
					sendRefreshRequest(response, groupId, conversationId, inqId, convTO, soeId, tradeRefList);
				}
			} else {
				response.put(QmaMailConstants.MESSAGE_KEY, NLPConstants.INCORRECT_REQUEST_MSG);
				response.put(QmaMailConstants.SUCCESS_KEY, false);
			}
		} catch (Throwable e) {
			logger.error("Error while refreshing suggestion : ", e);
			response.put(QmaMailConstants.MESSAGE_KEY, NLPConstants.SERVICE_FAILURE_MSG);
			response.put(QmaMailConstants.SUCCESS_KEY, false);
		}
		return response;
	}

	/**
	 * This method sends refresh request for provided parameters
	 * 
	 * @param response
	 * @param groupId
	 * @param conversationId
	 * @param inqId
	 * @param convTO
	 * @param actionBy
	 * @param tradeRefList 
	 * @throws CommunicatorException
	 */
	private void sendRefreshRequest(BasicDBObject response, final String groupId, Long conversationId, Long inqId,
			ConversationTO convTO, String actionBy, List<String> tradeRefList) throws CommunicatorException {
		Conversation conv = convTO.getConversationList().get(0);
		NLPRequestType nlpRequestTypeByGroupId = getNlpRequestTypebyGroupId(groupId);
		NLPSuggestionRecord nlpRecord = getSuggestionRecordForInqAndConvId(inqId, conversationId,
				nlpRequestTypeByGroupId);
		// String clientRequestId = nlpRecord.getQmaRequestId();
		String clientRequestId = UUID.randomUUID().toString();
		String nlpRequestType = nlpRecord.getNlpRequestType();
		Inquiry inquiry = convTO.getInquiry();
		if (StringUtils.isBlank(nlpRequestType)) {
			nlpRequestType = NLPRequestType.C.toString();
		}
		List<Map<String, Object>> attachments = MailCommonUtil.getAllInlineAttachments(conv);
		List<Long> groupIdList;
		if (nlpRecord.getEligibleGroupIdList() != null && !nlpRecord.getEligibleGroupIdList().isEmpty()) {
			groupIdList = nlpRecord.getEligibleGroupIdList();
		} else {
			groupIdList = new ArrayList<>();
			groupIdList.add(Long.valueOf(groupId));
		}
		NLPQueryEngineUtil.getNLPSuggestionWithAttachments(clientRequestId, conv, attachments, groupIdList, actionBy,
				nlpRequestType, inquiry, tradeRefList);
		response.put(QmaMailConstants.MESSAGE_KEY, NLPConstants.REFRESH_SUCCESS_MSG);
		response.put(QmaMailConstants.SUCCESS_KEY, true);
	}

	/**
	 * This method checks if group is configured for suggestion and sends the
	 * conversation for updating suggestion status
	 * 
	 * @param conversationTO
	 * @param inquiryId
	 * @param inqAssignedGroupId
	 * @return
	 */
	public ConversationTO checkForNLPSuggestion(ConversationTO conversationTO, Long inquiryId,
			List<Long> inqAssignedGroupIdsList) {
		try {
			if (conversationTO != null && inquiryId != null && null != inqAssignedGroupIdsList.get(0)
					&& conversationTO.getConversationList() != null) {
				String assignedGroupId = inqAssignedGroupIdsList.get(0) == null ? null
						: inqAssignedGroupIdsList.get(0).toString();
				String groupCode = inqAssignedGroupIdsList.get(0) == null ? null
						: QMACacheFactory.getCache().getGroupIdToNameMap().get(inqAssignedGroupIdsList.get(0));
				NLPRequestType nlpReqType = getNlpRequestTypebyGroupId(assignedGroupId);
				conversationTO.setAutoAssignmentAvailable(false);
				if (null != nlpReqType && !conversationTO.getConversationList().isEmpty()) {
					getSuggestionByNlpReqType(conversationTO, inquiryId, assignedGroupId, groupCode, nlpReqType);
				} else {
					logger.info("NLP not configured for Group :" + groupCode + "(" + assignedGroupId + ")");
					conversationTO.setSuggestionAvailable(false);
				}
				NLPRequestType intentNlpReqType = getINlpRequestTypebyGroupId(assignedGroupId);
				if(null != intentNlpReqType && NLPRequestType.I.equals(intentNlpReqType)) {
					Conversation conv = conversationTO.getConversationList().get(0);
					if(null != conv && ACTION_NEW.equalsIgnoreCase(conv.getAction())) {
						conversationTO.setIntentSuggestionAvailable(conv.isIntentSuggestionAvailable());
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception while checking NLP suggestions", e);
		}
		return conversationTO;
	}

	private void getSuggestionByNlpReqType(ConversationTO conversationTO, Long inquiryId, String inqAssignedGroupId,
			String groupCode, NLPRequestType nlpReqType) {
		BasicDBObject suggestionStatus = getSuggestionStatusForConversation(conversationTO.getConversationList(),
				inquiryId, nlpReqType);
		if (suggestionStatus != null && suggestionStatus.getBoolean(NLPConstants.STATUS_KEY)) {
			conversationTO.setSuggestionAvailable(true);
			conversationTO.setSuggestionStatus(suggestionStatus.getString(NLPConstants.SUGGESTION_STATUS));
			conversationTO.setAutoAssignmentAvailable(suggestionStatus.getBoolean(AUTO_ASSIGNMENT_AVAILABLE_FLAG));
			logger.info(
					"NLP suggestion configured and updated for Group :" + groupCode + "(" + inqAssignedGroupId + ")");
		}
	}

	/**
	 * This method checks extracts 0th conversation as it's latest one and send it
	 * for getting suggestion
	 * 
	 * @param convList
	 * @param inquiryId
	 * @return BasicDBObject
	 */
	public BasicDBObject getSuggestionStatusForConversation(List<Conversation> convList, Long inquiryId,
			NLPRequestType nlpRequestType) {
		BasicDBObject suggestionStatus = new BasicDBObject();
		if (convList != null && !convList.isEmpty()) {
			/*
			 * As getAllInquiryConversation rest call collects data for latest conversation
			 * and clears data for rest of the conversation. Also there us a separate call
			 * for extracting data of each selected conversation, hence .get(0) is used
			 * below
			 */
			suggestionStatus = updateConvSuggestionStatus(convList.get(0), inquiryId, nlpRequestType);
		}
		return suggestionStatus;
	}

	/**
	 * This function retrieves suggestion record and check the status of response
	 * 
	 * @param conv
	 * @param inquiryId
	 * @return BasicDBObject
	 */
	private BasicDBObject updateConvSuggestionStatus(Conversation conv, Long inquiryId, NLPRequestType nlpRequestType) {
		BasicDBObject suggestionStatus = new BasicDBObject();
		try {
			Long convId = conv.getId();
			NLPSuggestionRecord record = getSuggestionRecordForInqAndConvId(inquiryId, convId, nlpRequestType);
			if (record != null) {
				Integer statusCode = record.getSuggestionReqStatusCode();
				int responseLevelIndicator = record.getResponseLevelIndicator();
				suggestionStatus = getSuggestionStatus(statusCode, responseLevelIndicator);
				suggestionStatus.put(AUTO_ASSIGNMENT_AVAILABLE_FLAG, false);
				if (null != record.getAutoRouting() && null != record.getAutoRouting().getNlpTags()
						&& "Y".equals(record.getAutoRouting().getWorkflowQueueRouted())) {
					suggestionStatus.put(AUTO_ASSIGNMENT_AVAILABLE_FLAG, true);
				}
			}
		} catch (Exception e) {
			logger.error("Error while updating conversation suggestion status : ", e);
		}
		return suggestionStatus;
	}

	/**
	 * This method identifies actual status of suggestion along with color code
	 * 
	 * @param statusCode
	 * @param suggestedResponse
	 * @return
	 */

	// Change method as per responseLevelIndicator
	private BasicDBObject getSuggestionStatus(Integer statusCode, Integer responseLevelIndicator) {
		BasicDBObject response = new BasicDBObject();
		response.put(NLPConstants.STATUS_KEY, true);
		if (statusCode != null && statusCode != 0) {
			if (null != responseLevelIndicator && responseLevelIndicator == 1) {
				/*
				 * NLP is providing trade details responseLevelIndicator= 1 Blue indication
				 */
				response.put(NLPConstants.SUGGESTION_STATUS, NLPConstants.COLOR_BLUE);
			} else if (null != responseLevelIndicator && responseLevelIndicator == 2) {
				/*
				 * NLP is providing trade details and suggested text responseLevelIndicator= 2
				 * Green indication icon
				 */
				response.put(NLPConstants.SUGGESTION_STATUS, NLPConstants.COLOR_GREEN);
			} /*
				 * else if(responseLevelIndicator == 3) { RNLP is replying back with no trade
				 * details and no suggestions responseLevelIndicator= 3, along with the relevant
				 * error message No reflection response.put(NLPConstants.SUGGESTION_STATUS,
				 * NLPConstants.COLOR_RED); }
				 */
		} /*
			 * else { timeout or network error response.put(NLPConstants.SUGGESTION_STATUS,
			 * NLPConstants.COLOR_BLACK); }
			 */
		return response;
	}

	/**
	 * This method logs audit when user declines suggestion
	 * 
	 * @param soeId
	 * @param request
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBObject declineSuggestion(String soeId, String request) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBObject reqObj = BasicDBObject.parse(request);
			final Long inquiryId = reqObj.getLong(NLPConstants.INQUIRY_ID_KEY);
			final Long convId = reqObj.getLong(NLPConstants.CONV_ID_KEY);
			final Long groupId = reqObj.getLong(NLPConstants.GROUP_ID_KEY);
			final String action = reqObj.getString(NLPConstants.ACTION_KEY);

			// C170665-304 | Save Decline Comment to NLP Suggestion Record.
			final String declineComment = reqObj.containsField("userNote") ? reqObj.getString("userNote") : "";
			final String feedbackComment = reqObj.containsField("comment") ? reqObj.getString("comment") : "";
			Object actionDetails = reqObj.containsField("actionDetails") ? reqObj.getString("actionDetails") : null;
			Boolean userFeedback = reqObj.containsField("isAdequateResponse")? reqObj.getBoolean("isAdequateResponse") : null;
			logger.info(soeId + " declining suggestion for (inquiryId:" + inquiryId + ", convId: " + convId
					+ ", decline comment: " + declineComment + ")");
			if (null != inquiryId && null != convId && null != groupId && null != action) {
				Inquiry inquiry = inquiryCommonDAO.getInquiryById(inquiryId);
				Date lastModifiedDate = new Date();
				getRecordForUpdate(convId, inquiryId, groupId, soeId, lastModifiedDate, action, null, declineComment,
						feedbackComment, actionDetails, null,userFeedback);
				updateInquiryWorkFlowAudit(inquiry, groupId, soeId, action, QmaMailConstants.SUGGESTION_DECLINED_DESC,
						lastModifiedDate);
				response.put("success", true);
				response.put("message", NLPConstants.SUGGESTIONS_DECLINED_MSG);
				if ("feedback".equalsIgnoreCase(action.trim())) {
					response.put("message", "Feedback submitted successfully.");
				}
			} else {
				response.put("success", false);
				response.put("message", NLPConstants.SUGGESTIONS_DECLINED_ERROR_MSG);
			}
		} catch (Exception e) {
			logger.error("Error in NLPSuggestionDAO#declineSuggestions() : ", e);
		}
		return response;
	}

	/**
	 * This method is used to create a WorkFlow audit for declining suggestion
	 * 
	 * @param inquiry
	 * @param groupId
	 * @param soeId
	 * @param action
	 * @param actionDetails
	 * @param lastModifiedDate
	 */
	public void updateInquiryWorkFlowAudit(Inquiry inquiry, Long groupId, String soeId, String action,
			String actionDetails, Date lastModifiedDate) {
		String userName;
		QMACache qmaCache = QMACacheFactory.getCache();
		User user = qmaCache.getUserInfoMap().get(soeId.toUpperCase());
		String groupName;
		if (user != null) {
			userName = user.getName();
		} else {
			userName = soeId;
		}
		WorkflowAudit workflowAudit = new WorkflowAudit();
		workflowAudit.setAction(action);
		workflowAudit.setGroupId(groupId);
		workflowAudit.setActionDetails(actionDetails);
		workflowAudit.setModBy(userName);
		workflowAudit.setModDate(lastModifiedDate);
		workflowAudit.setUserId(userName);
		if (groupId != null) {
			groupName = qmaCache.getGroupIdToNameMap().get(groupId);
			if (!StringUtils.isEmpty(groupName)) {
				workflowAudit.setGroupName(groupName);
			} else {
				workflowAudit.setGroupName(groupId + "");
			}
		} else {
			workflowAudit.setGroupName(groupId + "");
		}

		List<WorkflowAudit> dbWorkflowAuditList = inquiry.getWorkflowAudit();
		if (dbWorkflowAuditList == null) {
			dbWorkflowAuditList = new ArrayList<>();
		}
		dbWorkflowAuditList.add(workflowAudit);
		updateInquiryWorkFlowAuditInDB(inquiry, dbWorkflowAuditList);
	}

	/**
	 * This method updates Workflow audit of an inquiry in database
	 * 
	 * @param inquiry
	 * @param dbWorkflowAuditList
	 */
	private void updateInquiryWorkFlowAuditInDB(Inquiry inquiry, List<WorkflowAudit> dbWorkflowAuditList) {
		try {
			Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("id", inquiry.getId());
			UpdateOperations<Inquiry> ops = mongoDatastore.createUpdateOperations(Inquiry.class).set("workflowAudit",
					dbWorkflowAuditList);
			mongoDatastore.update(query, ops);
		} catch (Exception e) {
			logger.error(
					"Error in while updating inquiry workflow audit for decline in NLPSuggestionDAO#updateInquiryWorkFlowAuditInDB() : ",
					e);
		}
	}

	/**
	 * This function validates all the data for suggestion action and send it
	 * forward for updating into database.
	 * 
	 * @param inquiry
	 * @param convId
	 * @param conversationContents
	 * @param groupId
	 * @param action
	 */
	public void acceptSuggestion(Inquiry inquiry, Long convId, String conversationContents, Long groupId,
			String action, String responseEdited) {
		try {
			if (null != inquiry && null != convId && null != groupId && null != action) {
				Long inquiryId = inquiry.getId();
				String lastActionBy = inquiry.getModBy();
				Date lastActionTime = inquiry.getModDate();
				getRecordForUpdate(convId, inquiryId, groupId, lastActionBy, lastActionTime, action,
						conversationContents, null, null, null,responseEdited);
			} else {
				logger.info("Error while performing action on suggestion");
			}
		} catch (Exception e) {
			logger.error("Error while updating suggestion action", e);
		}

	}
	
	private void updateFeedbackForIntentSuggestion(String soeId, BasicDBObject reqObj) {
		
		final Long inquiryId = reqObj.getLong(NLPConstants.INQUIRY_ID_KEY);
		final Long convId = reqObj.getLong(NLPConstants.CONV_ID_KEY);
		final Long groupId = reqObj.getLong(NLPConstants.GROUP_ID_KEY);
		final boolean intentUserFeedback = reqObj.getBoolean(NLPConstants.INTENT_USER_FEEDBACK_KEY);
		final String description = reqObj.containsField(NLPConstants.DESCRIPTION_KEY) ? reqObj.getString(NLPConstants.DESCRIPTION_KEY) : "";
		Object correctIntents = reqObj.containsField(NLPConstants.CORRECT_INTENTS_KEY) ? reqObj.getString(NLPConstants.CORRECT_INTENTS_KEY) : null;
		
		NLPSuggestionRecord suggestionRecord = getSuggestionRecordForInqAndConvId(inquiryId, convId, NLPRequestType.I);
		
		if (suggestionRecord != null) {
			Date actionTime = new Date();
			List<IntentFeedback> feedbackList = suggestionRecord.getIntentFeedback();
			if(null == feedbackList || feedbackList.isEmpty()) {
				logger.info("No intent feedback present for record. Creating new record");
				List<IntentFeedback> newFeedbackList = new ArrayList<>();
				
				NLPSuggestionRecord.IntentFeedback newFeedback = new NLPSuggestionRecord.IntentFeedback(groupId, intentUserFeedback,correctIntents, description, soeId, actionTime);
				newFeedbackList.add(newFeedback);
				suggestionRecord.setIntentFeedback(newFeedbackList);
				updateIntentSuggestionFeedback(suggestionRecord);
			}else {
				updateExistingSuggestionRecord(soeId,reqObj, actionTime, feedbackList,correctIntents);
				updateIntentSuggestionFeedback(suggestionRecord);
			}
		}
	}
	private void updateExistingSuggestionRecord(String soeId, BasicDBObject reqObj, Date actionTime, List<IntentFeedback> feedbackList,Object correctIntents) {
		
		final Long groupId = reqObj.getLong(NLPConstants.GROUP_ID_KEY);
		final boolean intentUserFeedback = reqObj.getBoolean(NLPConstants.INTENT_USER_FEEDBACK_KEY);
		final String description = reqObj.containsField(NLPConstants.DESCRIPTION_KEY) ? reqObj.getString(NLPConstants.DESCRIPTION_KEY) : "";
		boolean isGrouFeedbackFound = false;
		for(IntentFeedback feedback : feedbackList) {
			if(feedback.getGroupId().equals(groupId)){
				updateExistingFeedback(soeId, actionTime, correctIntents, intentUserFeedback, description, feedback);
				isGrouFeedbackFound = true;
				break;
			}
		}
		
		if(!isGrouFeedbackFound) {
			NLPSuggestionRecord.IntentFeedback newFeedback = new NLPSuggestionRecord.IntentFeedback(groupId, intentUserFeedback, description, soeId, actionTime);
			if(!intentUserFeedback) {
				newFeedback.setCorrectIntents(correctIntents);
			}
			feedbackList.add(newFeedback);
		}
	}
	private void updateExistingFeedback(String soeId, Date actionTime, Object correctIntents,
			final boolean intentUserFeedback, final String description, IntentFeedback feedback) {
		feedback.setIntentUserFeedback(intentUserFeedback);
		feedback.setDescription(description);
		feedback.setActionBy(soeId);
		feedback.setActionTime(actionTime);
		if(!intentUserFeedback)
			feedback.setCorrectIntents(correctIntents);
		else {
			feedback.setCorrectIntents(null);
		}
	}
	private void updateIntentSuggestionFeedback(NLPSuggestionRecord suggestionRecord) {
		try {
			Query<NLPSuggestionRecord> query = mongoDatastore.createQuery(NLPSuggestionRecord.class).filter("id",
					suggestionRecord.getId());
			UpdateOperations<NLPSuggestionRecord> ops = mongoDatastore.createUpdateOperations(NLPSuggestionRecord.class)
					.set("intentFeedback", suggestionRecord.getIntentFeedback());
			mongoDatastore.update(query, ops);

		} catch (Exception e) {
			logger.error("Error while updating suggestion record into database for inquiry(" + suggestionRecord.getInquiryid()
					+ ") : convId(" + suggestionRecord.getConversationId() + ")", e);
		}
	}
	
	private void getRecordForUpdate(Long convId, Long inquiryId, Long groupId, String lastActionBy, Date lastActionTime,
			String action, String conversationContents, String declineComment, String feedbackComment, Object actionDetails, String responseEdited) {
		getRecordForUpdate(convId, inquiryId, groupId, lastActionBy, lastActionTime, action, null, declineComment,
				feedbackComment, actionDetails, responseEdited,null);
	}

	/**
	 * This method extract suggestion record for updating suggestion action.
	 * 
	 * @param convId
	 * @param inquiryId
	 * @param groupId
	 * @param lastActionBy
	 * @param lastActionTime
	 * @param action
	 * @param conversationContents
	 * @param declineComment
	 * @param actionDetails
	 * @param comment
	 */
	private void getRecordForUpdate(Long convId, Long inquiryId, Long groupId, String lastActionBy, Date lastActionTime,
			String action, String conversationContents, String declineComment, String feedbackComment, Object actionDetails, String responseEdited, Boolean userFeedback) {
		NLPRequestType nlpRequestTypeByGroupId = getNlpRequestTypebyGroupId(groupId.toString());
		NLPSuggestionRecord record = getSuggestionRecordForInqAndConvId(inquiryId, convId, nlpRequestTypeByGroupId);
		BasicDBObject activityObj = new BasicDBObject();

		if (record != null) {
			String responseEditedStatus = "";
			if (NLPConstants.ACTION_ACCEPT.equalsIgnoreCase(action) && StringUtils.isNotBlank(responseEdited)) {
				responseEditedStatus = responseEdited;
			}
			List<GroupData> groupData = record.getGroupData();
			if (groupData == null || groupData.isEmpty()) {
				logger.info("No group data present for record. Creating new record");
				List<GroupData> newGroupDataList = new ArrayList<>();
				NLPSuggestionRecord.GroupData newGroupData = new NLPSuggestionRecord.GroupData(groupId, action,
						lastActionBy, lastActionTime);
				updateActionCountAndStatus(newGroupData, action, responseEditedStatus, declineComment, feedbackComment,
						actionDetails);
				updateUserFeedback(newGroupData,feedbackComment,userFeedback);
				newGroupDataList.add(newGroupData);
				record.setGroupData(newGroupDataList);
				activityObj.put("action", action);
				activityObj.put(NLPConstants.LAST_ACTION_BY, lastActionBy);
				activityObj.put("groupId", groupId);
			} else {
				logger.info("GroupData present for the record for id :" + record.getId());
				updateExistingGroupDataRecord(record, groupId, lastActionBy, lastActionTime, action, groupData,
						responseEditedStatus, declineComment, feedbackComment, actionDetails,userFeedback);
				activityObj.put("action", action);
				activityObj.put(NLPConstants.LAST_ACTION_BY, lastActionBy);
				activityObj.put("groupId", groupId);
			}
			
			updateGroupData(record, activityObj);
		} else {
			logger.info("Could not update action as no NLP suggestion record present for this request inquiryId("
					+ inquiryId + ") : conveId(" + convId + ")");
		}
	}

	private void updateUserFeedback(GroupData newGroupData,String feedbackComment, Boolean userFeedback) {
		if (StringUtils.isNotEmpty(feedbackComment)) {
			newGroupData.setFeedbackComment(feedbackComment);
		}
		if(null != userFeedback) {
			newGroupData.setUserFeedback(userFeedback);
		}
	}
	/**
	 * This method checks if suggestion response was edited before sending or not.
	 * 
	 * @param record
	 * @param conversationContents
	 * @return String
	 */
	private String checkIfResponseEdited(NLPSuggestionRecord record, String conversationContents) {
		String responseEdited = NLPConstants.RESPONSE_NOT_EDITED;
		try {
			if (record != null && !StringUtils.isEmpty(conversationContents)) {
				String responseContents = getResponseContents(conversationContents);
				/*
				 * Replaced <br /> with <br> because when the content goes into Kendo editor
				 * with <br> it gets replaced with <br />, hence to make it same, replaced with
				 * original <br>. Also Kendo editor adds random spaces in between even if you
				 * don't edit, hence replaces spaces as well
				 */
				responseContents = responseContents.replaceAll("<br />", "<br>").replaceAll("\\s", "");
				String originalContents = record.getSuggestedResponse();
				/* Replaced <HTML> starting and ending tag and spaces for comparison */
				originalContents = originalContents.replace(NLPConstants.HTML_START_TAG, "")
						.replace(NLPConstants.HTML_END_TAG, "").replaceAll("\\s", "");
				if (!responseContents.equals(originalContents)) {
					responseEdited = NLPConstants.RESPONSE_EDITED;
				}
			}
		} catch (Exception e) {
			logger.error("Error while checking if response edited while accepting for qmaRequestID("
					+ record.getQmaRequestId() + "): ", e);
			responseEdited = NLPConstants.RESPONSE_NOT_EDITED;
		}

		return responseEdited;
	}

	/**
	 * This method extracts the actual response sent by user.
	 * 
	 * @param conversationContents
	 * @return String
	 */
	private String getResponseContents(String conversationContents) {
		String suggestionContents = "";
		if (!StringUtils.isEmpty(conversationContents)
				&& conversationContents.contains(NLPConstants.CONTENT_START_PATTERN)
				&& conversationContents.contains(NLPConstants.CONTENT_END_PATTERN)) {
			Pattern pattern = Pattern.compile(NLPConstants.COMPLETE_PATTERN);
			Matcher matcher = pattern.matcher(conversationContents);
			while (matcher.find()) {
				String extract = matcher.group();
				if (extract.indexOf(NLPConstants.CONTENT_START_PATTERN) == 0) {
					suggestionContents = extract.substring(NLPConstants.CONTENT_START_PATTERN.length(),
							extract.indexOf(NLPConstants.CONTENT_END_PATTERN));
				}
				/*
				 * Break the loop after first match as there are chances same conversation
				 * contents may have multiple occurrences if same suggestion is accepted
				 * multiple times
				 */
				break;
			}
		}
		return suggestionContents;
	}

	/**
	 * This method updates existing group data for give groupID
	 * 
	 * @param record
	 * @param groupId
	 * @param lastActionBy
	 * @param lastActionTime
	 * @param action
	 * @param groupData
	 * @param responseEditedStatus
	 * @param declineComment
	 * @param actionDetails
	 * @param comment
	 */
	private void updateExistingGroupDataRecord(NLPSuggestionRecord record, Long groupId, String lastActionBy,
			Date lastActionTime, String action, List<GroupData> groupData, String responseEditedStatus,
			String declineComment, String feedbackComment, Object actionDetails, Boolean userFeedback) {
		boolean isGroupRecordFound = false;
		for (NLPSuggestionRecord.GroupData currentGrpData : groupData) {
			if (null != currentGrpData.getGroupId() && currentGrpData.getGroupId().equals(groupId)) {
				logger.info("Group data for groupID(" + groupId + ") present in record. Updating existing group data");
				currentGrpData.setLastActionBy(lastActionBy);
				currentGrpData.setLastActionTime(lastActionTime);
				currentGrpData.setLastAction(action);
				updateActionCountAndStatus(currentGrpData, action, responseEditedStatus, declineComment, feedbackComment,
						actionDetails);
				updateUserFeedback(currentGrpData,feedbackComment,userFeedback);
				isGroupRecordFound = true;
				break;
			}
		}
		if (!isGroupRecordFound) {
			logger.info("No group data present for record. Creating new record");
			NLPSuggestionRecord.GroupData newGroupData = new NLPSuggestionRecord.GroupData(groupId, action,
					lastActionBy, lastActionTime);
			updateActionCountAndStatus(newGroupData, action, responseEditedStatus, declineComment, feedbackComment,
					actionDetails);
			updateUserFeedback(newGroupData,feedbackComment,userFeedback);
			record.getGroupData().add(newGroupData);
			BasicDBObject activityObj = new BasicDBObject();
			activityObj.put("action", action);
			activityObj.put(NLPConstants.LAST_ACTION_BY, lastActionBy);
			activityObj.put("groupId", groupId);
			updateGroupData(record);
		}
	}

	/**
	 * This method updates action count for any particular action given group data
	 * and response edited flag for accept action
	 * 
	 * @param groupData
	 * @param action
	 * @param responseEditedStatus
	 * @param declineComment
	 * @param actionDetails
	 * @param comment
	 */
	private void updateActionCountAndStatus(GroupData groupData, String action, String responseEditedStatus,
			String declineComment, String feedbackComment, Object actionDetails) {
		if (QmaMailConstants.SUGGESTION_ACCEPT_ACTION.equalsIgnoreCase(action)) {
			groupData.setAcceptCount(groupData.getAcceptCount() + 1);
			groupData.setSuggestionStatus(QmaMailConstants.SUGGESTION_STATUS_SENT);
			groupData.setResponseEditedFlag(responseEditedStatus);
		} else if (QmaMailConstants.SUGGESTION_DECLINE_ACTION.equalsIgnoreCase(action)) {
			groupData.setDeclineCount(groupData.getDeclineCount() + 1);
			if (StringUtils.isNotBlank(declineComment)) {
				groupData.setDeclineComment(declineComment); // C170665-304 | Set Decline Comment to group data.
			}
		}
		
		groupData.setFeedbackComment(feedbackComment);
		
		if (null != actionDetails) {
			groupData.setActionDetails(actionDetails);
		}
	}

	/**
	 * This method updates the record into database.
	 * 
	 * @param record
	 */
	private void updateGroupData(NLPSuggestionRecord record) {
		try {
			Query<NLPSuggestionRecord> query = mongoDatastore.createQuery(NLPSuggestionRecord.class).filter("id",
					record.getId());
			UpdateOperations<NLPSuggestionRecord> ops = mongoDatastore.createUpdateOperations(NLPSuggestionRecord.class)
					.set("groupData", record.getGroupData());
			mongoDatastore.update(query, ops);
		} catch (Exception e) {
			logger.error("Error while updating suggestion record into database for inquiry(" + record.getInquiryid()
					+ ") : convId(" + record.getConversationId() + ")", e);
		}
	}

	/**
	 * This method updates status indicator for inquiry workflow
	 * 
	 * @param sugRecord
	 * @param inquiryId
	 * @param groupIds
	 */
	public void checkAndUpdateStatusIndicatorForInquiry(NLPSuggestionRecord sugRecord, Long inquiryId,
			List<Long> groupIds) {
		
		try {
			if (inquiryId != null && groupIds != null && !groupIds.isEmpty()) {
				Inquiry inquiry = inquiryCommonDAO.getInquiryById(inquiryId);
				if (inquiry != null && inquiry.getWorkflows() != null && !inquiry.getWorkflows().isEmpty()) {
					updateIndicatorForGroupInWorkflow(sugRecord, groupIds, inquiry);
					mongoDatastore.save(inquiry);
				}
			}
		} catch (Exception e) {
			logger.error("Exception while updating suggestion indicator when the suggestion is received by callback :",
					e);
		}

	}

	/**
	 * This method updates the status indicator in workflow
	 * 
	 * @param sugRecord
	 * @param groupIds
	 * @param inquiry
	 */
	private void updateIndicatorForGroupInWorkflow(NLPSuggestionRecord sugRecord, List<Long> groupIds,
			Inquiry inquiry) {
		String intentSuggestionName = "";
		String intentTimeToVD = null ;
		SuggestionStatusIndicator indicator = null;
		String nlpRequestType = sugRecord.getNlpRequestType();
		logger.info("nlpRequestType as : {}, sugRecord.getIntentSuggested(): {}",nlpRequestType,sugRecord.getIntentSuggested());
		if(NLPRequestType.I.name().equalsIgnoreCase(nlpRequestType) 
				&& null != sugRecord.getIntentSuggested() && sugRecord.getIntentSuggested().booleanValue()) {
			intentSuggestionName = getIntentSuggestionIndicatorForWorkflow(sugRecord);
			intentTimeToVD = getIntentTimeToVD(sugRecord.getIntentValueDates());
		} else {
			indicator = getIndicatorForWorkflow(sugRecord);
		}
		
		for (Workflow currentWorkflow : inquiry.getWorkflows()) {
			if (null != currentWorkflow.getAssignedGroupId()
					&& groupIds.contains(currentWorkflow.getAssignedGroupId())) {
				logger.info("intentSuggestionName as : {}, TimeToVd: {}, is inetent suggested: {},nlpRequestType:{}",intentSuggestionName,intentTimeToVD,sugRecord.getIntentSuggested(),nlpRequestType );
				if(NLPRequestType.I.name().equalsIgnoreCase(nlpRequestType) && StringUtils.isNotBlank(intentSuggestionName)
						&& null != sugRecord.getIntentSuggested() && sugRecord.getIntentSuggested().booleanValue()) {
					
					currentWorkflow.setIntentSuggestionName(intentSuggestionName);
					currentWorkflow.setIntentTimeToVD(intentTimeToVD);
				}else { 
				logger.info("Updating indicator as : {} for group workflow : {} for inquiry : {}",indicator,currentWorkflow.getAssignedGroupId(), inquiry.getId());
				if(null != indicator) {
					currentWorkflow.setSuggestionIndicator(indicator.toString());
				}
				
				}
			}
		}
		updateConversationAsAwaitingResponse(sugRecord, indicator,intentSuggestionName,intentTimeToVD);
	}

	public String getIntentTimeToVD(List<String> timeToVDList) {
		return (null != timeToVDList && !timeToVDList.isEmpty()) ? timeToVDList.get(0) : "";
		
	}
	private String getIntentSuggestionIndicatorForWorkflow(NLPSuggestionRecord sugRecord) {
		List<Intents> intentSuggestionList = sugRecord.getIntentList();
		String intentSuggestionIndicator = "";
		if(null != intentSuggestionList && !intentSuggestionList.isEmpty()) {
			Intents intent = intentSuggestionList.get(0);
			String intentName = intent.getIntent();
			Map<String, Object> config = QMACacheFactory.getCache().getConfigById("nlpConfiguration").getNlpConfiguration();
			Map<String, String> intentSuggestionIndicators = new TreeMap<String, String>();
			intentSuggestionIndicators = (Map<String, String>) config.get("intentSuggestionIndicator");
			
			Map<String, String> intentSuggestionIndicatorMapCaseInsensitive = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
			intentSuggestionIndicatorMapCaseInsensitive.putAll(intentSuggestionIndicators);
			 
			if(!intentSuggestionIndicatorMapCaseInsensitive.isEmpty() &&  null!= intentSuggestionIndicatorMapCaseInsensitive.get(intentName)) {
					for(Map.Entry<String,String> entry: intentSuggestionIndicatorMapCaseInsensitive.entrySet()) {
						logger.info("entry.getKey(): {},intentName: {}",entry.getKey(),intentName);
						if(entry.getKey().equalsIgnoreCase(intentName)) {
							intentSuggestionIndicator = entry.getKey();
							break;
						}
					}
			}
			
		}
		logger.info("intentSuggestionIndicator: {}",intentSuggestionIndicator);
		return intentSuggestionIndicator;
	}
	/**
	 * This method provides SuggestionStatusIndicator depending on current colorCode
	 * of record
	 * 
	 * @param sugRecord
	 * @return SuggestionStatusIndicator
	 */
	private SuggestionStatusIndicator getIndicatorForWorkflow(NLPSuggestionRecord sugRecord) {
		SuggestionStatusIndicator indicator = SuggestionStatusIndicator.N;
		BasicDBObject reponse = getSuggestionStatus(sugRecord.getSuggestionReqStatusCode(),
				sugRecord.getResponseLevelIndicator());
		// Check new field and set Red, Blue and green
		if (reponse != null && reponse.getBoolean(NLPConstants.STATUS_KEY)
				&& reponse.getString(NLPConstants.SUGGESTION_STATUS) != null
				&& !reponse.getString(NLPConstants.SUGGESTION_STATUS).isEmpty()) {
			String colorCode = reponse.getString(NLPConstants.SUGGESTION_STATUS);
			switch (colorCode) {
			case NLPConstants.COLOR_BLACK:
				indicator = SuggestionStatusIndicator.N;
				break;
			case NLPConstants.COLOR_RED:
				indicator = SuggestionStatusIndicator.R;
				break;
			case NLPConstants.COLOR_BLUE:
				indicator = SuggestionStatusIndicator.B;
				break;
			case NLPConstants.COLOR_GREEN:
				indicator = SuggestionStatusIndicator.G;
				break;
			default:
				logger.info("Suggestion status is not available");
				break;
			}
			logger.info("For suggestion record(" + sugRecord.getId() + ") Color Code is : " + colorCode
					+ " and Indicator is : " + indicator.toString());
		}
		return indicator;
	}

	/**
	 * This method updates status indicator for an inquiry
	 * 
	 * @param inquiryId
	 * @param groupId
	 * @param indicator
	 */
	private void updateSuggestionIndicatorForInquiry(Long inquiryId, Long groupId,
			SuggestionStatusIndicator indicator) {
		try {
			if (inquiryId != null && groupId != null) {
				Inquiry inquiry = inquiryCommonDAO.getInquiryById(inquiryId);
				logger.info("Updating workflow for inquiry :" + inquiryId);
				List<Workflow> workflows = inquiry.getWorkflows();
				if (workflows != null && !workflows.isEmpty()) {
					updateSuggestionIndicator(groupId, indicator, workflows);
					logger.info("Updating status indicator as : " + indicator.toString() + " for groupID : " + groupId
							+ " in workflow for inquiry(" + inquiryId + ").");
					mongoDatastore.save(inquiry);
				}
			}
		} catch (Exception e) {
			logger.error("Error while updating suggestion status in workflow : ", e);
		}
	}

	/**
	 * This method updates status indicator in group Workflow for an inquiry
	 * 
	 * @param groupId
	 * @param indicator
	 * @param workflows
	 */
	private void updateSuggestionIndicator(Long groupId, SuggestionStatusIndicator indicator,
			List<Workflow> workflows) {
		for (Workflow currentWorkflow : workflows) {
			if (null != currentWorkflow.getAssignedGroupId() && currentWorkflow.getAssignedGroupId().equals(groupId)) {
				currentWorkflow.setSuggestionIndicator(indicator.toString());
			}
		}
	}

	/**
	 * @param conversation
	 * @param nlpRequestType
	 * @throws CommunicatorException
	 */
	public void updateInquiry(Conversation conversation, String nlpRequestType) throws CommunicatorException {
		updateInquiryForNLPSuggestion(conversation, nlpRequestType);
	}

	/**
	 * @param conversation
	 * @throws CommunicatorException Update Inquiry for NLP Suggestion
	 */
	private void updateInquiryForNLPSuggestion(Conversation conversation, String nlpRequestType)
			throws CommunicatorException {
		logger.info("inside updateInquiryForNLPSuggestion to update the inquiry");
		try {
			Long inquiryId = conversation.getInquiryId();
			NLPSuggestionRecord suggestionRecord = getSuggestionRecordForInqAndConvId(inquiryId, conversation.getId(),
					NLPRequestType.valueOf(nlpRequestType));
			Inquiry inquiryObject;
			if (null != inquiryId) {
				inquiryObject = inquiryCommonDAO.getInquiryById(inquiryId);
				long nlpConversationId = conversation.getId();
				long nlpSuggestionId = suggestionRecord.getId();
				if (null == inquiryObject.getNlpRPTCocnversationId()) {
					inquiryObject.setNlpRPTCocnversationId(nlpConversationId);
					inquiryObject.setNlpRPTSuggestionId(nlpSuggestionId);
					inquiryObject.setNlpRPTType(nlpRequestType);
				} else if (null != inquiryObject.getNlpRPTCocnversationId()
						&& inquiryObject.getNlpRPTCocnversationId() == nlpConversationId
						&& !inquiryObject.isNlpRPTFreeze()) {
					inquiryObject.setNlpRPTSuggestionId(nlpSuggestionId);
				}

				mongoDatastore.save(inquiryObject);
			}
		} catch (Exception e) {
			logger.error("Error while updating inquiry : ", e);
		}

	}

	/**
	 * This method returns NLP request type from config
	 * 
	 * @param assignedGroupId
	 * @return
	 */
	private NLPRequestType getNlpRequestTypebyGroupId(String assignedGroupId) {
		QMACache qmaCache = QMACacheFactory.getCache();
		// List<String> nlpCustodyGrps =
		// qmaCache.getNlpSubsciptionGroups("nlpSuggestionMandatoryGroups");
		List<String> nlpCustodyGrps = QMACacheFactory.getCache().getCustodySuggestionEnabledGroupList();
		// List<String> nlpSettsGrps =
		// qmaCache.getNlpSubsciptionGroups("nlpSettsMandatoryGroups");
		List<String> nlpSettsGrps = qmaCache.getAutoReplySuggestionEnabledGroupList();
		// List<String> nlpAutoAssignmentGrps =
		// QMACacheFactory.getCache().getNlpSubsciptionGroups("enableAutoRoutingGroups");
		String groupCode = qmaCache.getGroupIdToCodeMap().get(Long.parseLong(assignedGroupId));

		List<String> intentSuggestionGrps = qmaCache.getIntentSuggestionEnabledGroupList();
		NLPRequestType reqType = NLPRequestType.A;
		if (nlpCustodyGrps.contains(groupCode)) {
			reqType = NLPRequestType.C;
		} else if (nlpSettsGrps.contains(groupCode.toUpperCase())) {
			reqType = NLPRequestType.S;
		} else if(null != intentSuggestionGrps && !intentSuggestionGrps.isEmpty() && intentSuggestionGrps.contains(groupCode.toUpperCase())) {
			reqType = NLPRequestType.I;
		}

		return reqType;
	}

	/**
	 * This method checks if group is configured for suggestion and sends the
	 * conversation for updating suggestion status
	 * 
	 * @param conversationTO
	 * @param inquiryId
	 * @param inqAssignedGroupId
	 */
	public void checkNLPSuggestionForAllConv(ConversationTO conversationTO, Long inquiryId,
			List<Long> inqAssignedGroupId) {
		try {
			if (conversationTO != null && inquiryId != null && inqAssignedGroupId.size() > 0
					&& null != inqAssignedGroupId.get(0) && conversationTO.getConversationList() != null) {
				String assignedGroupId = inqAssignedGroupId.get(0).toString();
				NLPRequestType nlpRequestType = getNlpRequestTypebyGroupId(assignedGroupId);
				String groupCode = QMACacheFactory.getCache().getGroupIdToNameMap()
						.get(Long.parseLong(assignedGroupId));
				if (null != nlpRequestType && !conversationTO.getConversationList().isEmpty()) {
					BasicDBObject suggestionStatus = getSuggestionStatusForConversation(
							conversationTO.getConversationList(), inquiryId, nlpRequestType);
					if (suggestionStatus != null && suggestionStatus.getBoolean(NLPConstants.STATUS_KEY)) {
						conversationTO.setSuggestionAvailable(true);
						conversationTO.setSuggestionStatus(suggestionStatus.getString(NLPConstants.SUGGESTION_STATUS));
						conversationTO.setAutoAssignmentAvailable(
								suggestionStatus.getBoolean(AUTO_ASSIGNMENT_AVAILABLE_FLAG));
						logger.info("NLP suggestion configured and updated for Group :" + groupCode + "("
								+ inqAssignedGroupId.get(0) + ")");
					}
					getSuggestionStatusForAllConversation(conversationTO, inquiryId, nlpRequestType);
				} else {
					logger.info("NLP not configured for Group :" + groupCode + "(" + inqAssignedGroupId.get(0) + ")");
					conversationTO.setSuggestionAvailable(false);
					conversationTO.setAutoAssignmentAvailable(false);
				}
			}
		} catch (Exception e) {
			logger.error("Exception while check nlp suggestion", e);
		}
	}

	/**
	 * @param conversationTO
	 * @param inquiryId
	 * @param nlpRequestType
	 */
	private void getSuggestionStatusForAllConversation(ConversationTO conversationTO, Long inquiryId,
			NLPRequestType nlpRequestType) {
		try {
			List<Conversation> conversationList = getSuggestionStatusConversationList(
					conversationTO.getConversationList(), inquiryId, nlpRequestType);
			if (null != conversationList && !conversationList.isEmpty()) {
				conversationTO.setConversationList(conversationList);
			}
		} catch (Exception e) {
			logger.error("Error while  getSuggestionStatusForAllConversation : ", e);
		}
	}

	/**
	 * This method checks extracts all conversation send it for getting suggestion
	 * 
	 * @param convList
	 * @param inquiryId
	 * @param nlpRequestType
	 * @return BasicDBObject
	 */
	public List<Conversation> getSuggestionStatusConversationList(List<Conversation> convList, Long inquiryId,
			NLPRequestType nlpRequestType) {
		List<Conversation> convListupdated = new ArrayList<>();
		try {
			if (null != convList && !convList.isEmpty()) {
				for (Conversation conv : convList) {
					BasicDBObject suggestionStatus = updateConvSuggestionStatus(conv, inquiryId, nlpRequestType);// Get
																													// from
																													// request
					if (suggestionStatus != null && suggestionStatus.getBoolean(NLPConstants.STATUS_KEY)) {
						conv.setSuggestionAvailable(suggestionStatus.getBoolean(NLPConstants.STATUS_KEY));
						conv.setSuggestionStatus(suggestionStatus.getString(NLPConstants.SUGGESTION_STATUS));
					}
					Boolean autoAssign = suggestionStatus.getBoolean(AUTO_ASSIGNMENT_AVAILABLE_FLAG);
					if (null != autoAssign && autoAssign) {
						conv.setAutoAssignmentAvailable(true);
					}
					convListupdated.add(conv);
				}
			}
		} catch (Exception e) {
			logger.error("Error while  getSuggestionStatusConversationList : ", e);
		}
		return convListupdated;
	}

	/**
	 * This method will validate response and if valid response it will apply auto
	 * routing.
	 * 
	 * @param sugRecord
	 * @param autoRouting
	 */
	private void applyAutoRoutingToWorkflows(NLPSuggestionRecord sugRecord, AutoRouting autoRouting) {
		if (null != sugRecord.getInquiryid()) {
			Inquiry inquiry = mongoDatastore.get(Inquiry.class, sugRecord.getInquiryid());
			try {
				AutoRoutingUtil.validateAutoRouting(sugRecord, inquiry);
				autoRouting.setValidationSuccess(NLPConstants.YES);
				List<Long> autoRoutingGroupIds = AutoRoutingUtil.getAutoRoutingGroups(sugRecord);
				boolean isAutoRouted = false;
				if (null != autoRoutingGroupIds && !autoRoutingGroupIds.isEmpty()) {
					isAutoRouted = applyAutoRoutingWorkflows(sugRecord, inquiry, autoRoutingGroupIds);
				}
				String workflowQueueRouted = isAutoRouted ? NLPConstants.YES : NLPConstants.NO;
				autoRouting.setWorkflowQueueRouted(workflowQueueRouted);
			} catch (NlpAutoAssignmentValidationException e) {
				autoRouting.setValidationSuccess(NLPConstants.NO);
				autoRouting.setFailReason(e.getMessage());
			}
			sugRecord.setAutoRouting(autoRouting);
			updateAutoRoutingMatrixData(sugRecord);
		}
	}

	/**
	 * This method used to update auto routing matrix data into NLPSuggestionsRecord
	 * 
	 * @param sugRecord
	 */
	private void updateAutoRoutingMatrixData(NLPSuggestionRecord sugRecord) {
		try {
			Query<NLPSuggestionRecord> query = mongoDatastore.createQuery(NLPSuggestionRecord.class).filter("id",
					sugRecord.getId());
			UpdateOperations<NLPSuggestionRecord> ops = mongoDatastore
					.createUpdateOperations(NLPSuggestionRecord.class);
			ops.set("autoRouting", sugRecord.getAutoRouting());
			mongoDatastore.update(query, ops);

		} catch (Exception e) {
			logger.error("Error while updating auto routing matrix data for suggestion Id(" + sugRecord.getId() + ")",
					e);
		}

	}

	/**
	 * @param sugRecord
	 * @param inquiry
	 * @param autoRoutingGroupIds
	 * @return
	 * @throws NlpAutoAssignmentValidationException
	 */
	private boolean applyAutoRoutingWorkflows(NLPSuggestionRecord sugRecord, Inquiry inquiry,
			List<Long> autoRoutingGroupIds) throws NlpAutoAssignmentValidationException {
		boolean isAutoRouted = false;
		try {
			List<Long> autoAssignmentSubscriberList = AutoRoutingUtil.addAutoAssignedGroupsForAutoRouting();
			checkIfSubscriptionIsValidForAutoRouting(sugRecord, autoAssignmentSubscriberList);
			if (null != inquiry && null != inquiry.getWorkflows()) {
				isAutoRouted = updateWorkflowsCreateAddAudit(inquiry, autoRoutingGroupIds,
						autoAssignmentSubscriberList);
			}
		} catch (NlpAutoAssignmentValidationException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Exception in bulk update workflow or workflowAudit:" + e);
		}
		return isAutoRouted;
	}

	/**
	 * This method will update workflow and create workflow audit for same
	 * 
	 * @param inquiry
	 * @param autoRoutingGroupIds
	 * @param autoAssignmentSubscriberList
	 */
	private Boolean updateWorkflowsCreateAddAudit(Inquiry inquiry, List<Long> autoRoutingGroupIds,
			List<Long> autoAssignmentSubscriberList) {
		UpdateOperations<Inquiry> ops = mongoDatastore.createUpdateOperations(Inquiry.class);
		Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("id", inquiry.id);
		Date currentTime = new Date();
		List<Workflow> workflowList = inquiry.getWorkflows();
		List<WorkflowAudit> workflowAuditList = inquiry.getWorkflowAudit();
		Boolean isAutoRouted = updateWorkflows(inquiry, autoRoutingGroupIds, workflowList, workflowAuditList,
				currentTime, autoAssignmentSubscriberList);
		if (isAutoRouted) {
			ops.set(WORKFLOWS, workflowList);
			ops.set(WORKFLOW_AUDIT, workflowAuditList);
			ops.set(AUTO_ASSIGNMENT_AVAILABLE_FLAG, true);
			mongoDatastore.update(query, ops);
		}
		return isAutoRouted;
	}

	/**
	 * This method update update workflow with rules flag true for auto-assignment
	 * 
	 * @param inquiry
	 * @param autoRoutingGroupIds
	 * @param workflowList
	 * @param workflowAuditList
	 * @param currentTime
	 * @param autoAssignmentSubscriberList
	 */
	private Boolean updateWorkflows(Inquiry inquiry, List<Long> autoRoutingGroupIds, List<Workflow> workflowList,
			List<WorkflowAudit> workflowAuditList, Date currentTime, List<Long> autoAssignmentSubscriberList) {
		Boolean isAutoRouted = false;
		for (Workflow workflow : workflowList) {
			if (null != workflow.getAssignedGroupId() && !autoRoutingGroupIds.contains(workflow.getAssignedGroupId())
					&& autoAssignmentSubscriberList.contains(workflow.getAssignedGroupId())
					&& null == workflow.getRulesFlag()) {
				workflow.setLastActionby(NLPConstants.SYSTEM_USER);
				workflow.setLastActionTime(currentTime);
				workflow.setAutoAssigned(NLPConstants.YES);
				workflow.setAutoAssignedAction(NLPConstants.SYSTEM_ASSIGN);
				RulesFlag rulesFlag = new RulesFlag();
				rulesFlag.setMarkAsNonInquiry(true);
				rulesFlag.setRuleType(NLPConstants.AUTO_ASSIGNMENT_RULE);
				workflow.setRulesFlag(rulesFlag);
				createAutoAssignedInquiryDetails(workflow, inquiry);
				workflowAuditList.add(createWorkFlowsAudit(workflow.getAssignedGroupId(), currentTime));
				updateConversationAutoAssignFlag(inquiry.getId(), NLPConstants.YES);
				isAutoRouted = true;
			} else {
				logger.info("GroupId:[" + workflow.getAssignedGroupId()
						+ "] recommended owner of this workflow, hence not updating workflow");
			}
		}
		return isAutoRouted;
	}

	/**
	 * @param inquiryId
	 * @param autoAssigned
	 */
	public void updateConversationAutoAssignFlag(Long inquiryId, String autoAssigned) {
		try {

			Query<Conversation> query = mongoDatastore.createQuery(Conversation.class)
					.filter(NLPConstants.INQUIRY_ID_KEY, inquiryId)
					.filter(NLPConstants.ACTION_KEY, NLPConstants.NEW_INQUIRY);
			UpdateOperations<Conversation> updateOps = mongoDatastore.createUpdateOperations(Conversation.class);
			updateOps.set(NLPConstants.AUTO_ASSIGNED, autoAssigned);
			if (NLPConstants.YES.equalsIgnoreCase(autoAssigned)) {
				updateOps.set(NLPConstants.CONV_AUTO_ASSIGN_AVAILABLE_KEY, true);
			} else {
				updateOps.set(NLPConstants.CONV_AUTO_ASSIGN_AVAILABLE_KEY, false);
			}
			mongoDatastore.update(query, updateOps);

		} catch (Exception e) {
			logger.error("Exception in update convsersation setting autoAssign flag : {}", inquiryId, e);
		}
	}

	/**
	 * @param workflow
	 * @param inquiry
	 */
	private void createAutoAssignedInquiryDetails(Workflow workflow, Inquiry inquiry) {
		try {
			AutoAssignedInquiry autoAssignedInquiries = new AutoAssignedInquiry();
			autoAssignedInquiries.setInquiryId(inquiry.id);
			autoAssignedInquiries.setActionBy(NLPConstants.SYSTEM_USER);
			autoAssignedInquiries.setAssignedGroupId(workflow.getAssignedGroupId());
			autoAssignedInquiries.setProcessedFlag(false);
			Date autoAssignedStartDate = new Date();
			autoAssignedInquiries.setAutoAssignStartTime(autoAssignedStartDate);
			autoAssignedInquiries.setAutoAssignEndTime(getAutoAssignedEndTime(autoAssignedStartDate));
			logger.info("Creating entry in AutoAssignedInquiry:" + autoAssignedInquiries.getInquiryId() + "End Time:"
					+ autoAssignedInquiries.getAutoAssignEndTime());
			mongoDatastore.save(autoAssignedInquiries);
		} catch (Exception e) {
			logger.error("Exception occurred while save auto assigned inquiry to AutoAssignedInquiry:", e);
		}

	}

	/**
	 * @param autoAssignedStartDate
	 * @return
	 */
	private Date getAutoAssignedEndTime(Date autoAssignedStartDate) {
		Date autoAssignedEndDate = DateUtils.addHours(autoAssignedStartDate, 2);
		try {
			Map<String, Object> nlpConfig = QMACacheFactory.getCache().getNlpConfiguration();
			if (null != nlpConfig && null != nlpConfig.get("autoAssignedEndHrs")) {
				int autoAssignedEndHrs = (int) nlpConfig.get("autoAssignedEndHrs");
				autoAssignedEndDate = DateUtils.addHours(autoAssignedStartDate, autoAssignedEndHrs);
			}
		} catch (Exception e) {
			logger.error("Exception occurred while setting auto assigned end time:", e);
		}
		return autoAssignedEndDate;
	}

	/**
	 * This method will create workflow audit for auto-assigned groups
	 * 
	 * @param groupId
	 * @param currentTime
	 * @return
	 */
	private static WorkflowAudit createWorkFlowsAudit(Long groupId, Date currentTime) {
		WorkflowAudit workflowAudit = new WorkflowAudit();
		workflowAudit.setAction("NLP - Auto Assignment");
		workflowAudit.setGroupId(groupId);
		String actionDesc = "Non Inquiry Assigned for Group";
		if (null != QMACacheFactory.getCache().getGroupIdToNameMap()) {
			String groupCode = QMACacheFactory.getCache().getGroupIdToNameMap().get(groupId);
			workflowAudit.setGroupName(groupCode);
			actionDesc = actionDesc.concat(" [" + groupCode + "]");
		}
		workflowAudit.setActionDetails(actionDesc);
		workflowAudit.setModBy(NLPConstants.SYSTEM_USER);
		workflowAudit.setModDate(currentTime);
		return workflowAudit;
	}

	/**
	 * This method is used to update workflow as per auto assignment list. Mark
	 * other groups workflow as non inquiry.
	 * 
	 * @param sugRecord
	 * @param sugRecord
	 * @param inquiryid
	 * @param autoFwdedGroupsIds
	 * @throws NlpAutoAssignmentValidationException
	 */
	/*
	 * private boolean applyAutoRoutingWorkflows(NLPSuggestionRecord sugRecord,
	 * Inquiry inquiry, List<Long> autoRoutingGroupIds) throws
	 * NlpAutoAssignmentValidationException { boolean isAutoRotingApplied = false;
	 * try { List<Long> autoAssignmentSubscriberList =
	 * AutoRoutingUtil.addAutoAssignedGroupsForAutoRouting();
	 * checkIfSubscriptionIsValidForAutoRouting(sugRecord,
	 * autoAssignmentSubscriberList); if(null != inquiry && null !=
	 * inquiry.getWorkflows()) { DBCollection inquiryCollection =
	 * mongoDatastore.getCollection(Inquiry.class); BulkWriteOperation
	 * bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation(); Date
	 * currentTime = new Date(); for(Workflow workflow:inquiry.getWorkflows()) { if
	 * (null!= workflow.getAssignedGroupId() &&
	 * !autoRoutingGroupIds.contains(workflow.getAssignedGroupId())){
	 * AutoRoutingUtil.prepareBulkUpdateOperations(bulkInquiryUpdOp, currentTime,
	 * inquiry, workflow); }else {
	 * logger.info("GroupId:["+workflow.getAssignedGroupId()
	 * +"] recommended owner of this workflow, hence not updating workflow"); } }
	 * bulkInquiryUpdOp.execute(); isAutoRotingApplied = true; } }
	 * catch(NlpAutoAssignmentValidationException e) { throw e; } catch (Exception
	 * e) { logger.error("Exception in bulk update workflow or workflowAudit:"+e); }
	 * return isAutoRotingApplied; }
	 */

	private void checkIfSubscriptionIsValidForAutoRouting(NLPSuggestionRecord sugRecord,
			List<Long> autoAssignmentSubscriberList) throws NlpAutoAssignmentValidationException {
		String validationMessage = "NO_SUBSCRIBERS_IN_EMAIL";

		if (autoAssignmentSubscriberList == null || autoAssignmentSubscriberList.isEmpty()) {
			logger.info("auto routing subscribers list is empty, AA NA for all request");
		} else {
			List<Long> validGroupsInRequest = sugRecord.getValidToCcGroupIds();
			if (validGroupsInRequest == null || validGroupsInRequest.isEmpty()) {
				validationMessage = "NO_VALID_GROUPS_IN_EMAIL";
			} else {
				Collection<Long> groupsFoundInSubscribersList = CollectionUtils
						.intersection(autoAssignmentSubscriberList, validGroupsInRequest);
				if (groupsFoundInSubscribersList.size() > 0) {
					validationMessage = NLPConstants.NLP_AUTO_ASSIGNMENT_VALIDATION_SUCCESS;
				} else {
					logger.info(
							"None of the groups in this request have subscribed for autoRouting, hence skipping autoRouting processing for ");
				}
			}
		}
		if (!NLPConstants.NLP_AUTO_ASSIGNMENT_VALIDATION_SUCCESS.equalsIgnoreCase(validationMessage)) {
			logger.info("auto routing subscription validation is failed");
			throw new NlpAutoAssignmentValidationException(validationMessage);
		} else {
			logger.info("auto routing subscription validation is successful");
		}
	}

	public void updateHttpRequestHeaders(String clientRequestId, Map<String, Object> httpHeadersParamMap) {
		try {
			if (null != httpHeadersParamMap && !httpHeadersParamMap.isEmpty()) {
				Query<NLPSuggestionRecord> query = mongoDatastore.createQuery(NLPSuggestionRecord.class)
						.filter(NLPConstants.QMA_REQUEST_ID_KEY, clientRequestId).limit(1);
				UpdateOperations<NLPSuggestionRecord> ops = mongoDatastore
						.createUpdateOperations(NLPSuggestionRecord.class);
				ops.set("httpRequestHeaders", httpHeadersParamMap);
				mongoDatastore.update(query, ops);
			}
		} catch (Exception e) {
			logger.error("Error while updating auto routing matrix data for clientRequestId(" + clientRequestId + ")",
					e);
		}

	}

	private boolean getAutoAssignmentSubscriptionEnable(String nlpRequestType) {
		boolean autoAssignmentSubEnabled = false;
		Map<String, Object> nlpConfig = QMACacheFactory.getCache().getNlpConfiguration();
		if (null != nlpConfig.get(NLPConstants.AUTO_ROUTING_CONFIG)) {
			BasicDBObject autoForwardConfig = (BasicDBObject) nlpConfig.get(NLPConstants.AUTO_ROUTING_CONFIG);
			logger.info("Auto routing configuration found:" + autoForwardConfig.toString());
			List<String> autoForwardSubscriptionList = (List<String>) autoForwardConfig
					.get(NLPConstants.SUBSCRIPTION_NLP_TYPE);
			if (autoForwardSubscriptionList.contains(nlpRequestType)) {
				autoAssignmentSubEnabled = true;
			}
		}
		return autoAssignmentSubEnabled;
	}

	/**
	 * This method used to revert auto routed workflows by inquiryId and assigned
	 * groupIds
	 * 
	 * @param inputJsonObj
	 * @param soeId
	 * @return
	 */
	public BasicDBObject revertAutoRoutedWorkflows(BasicDBObject inputJsonObj, String soeId) {
		BasicDBObject response = new BasicDBObject();
		Long inquiryId = null;
		try {
			inquiryId = inputJsonObj.getLong(NLPConstants.INQUIRY_ID);
			List<Long> autoRoutedGroupIds = GenericUtility.getIdListFromRequest(inputJsonObj,
					NLPConstants.AUTO_ROUTED_GROUP_IDS);
			if (null != autoRoutedGroupIds && !autoRoutedGroupIds.isEmpty()) {
				Inquiry inquiry = inquiryCommonDAO.getInquiryById(inquiryId);
				updateWorkflowsAndAudit(autoRoutedGroupIds, inquiry, soeId);
				response.put(NLPConstants.SUCCESS, true);
				response.put(NLPConstants.MESSAGE, "Revert request for auto routed workflows completed successfully.");
			} else {
				response.put(NLPConstants.SUCCESS, true);
				response.put(NLPConstants.MESSAGE, "No groups mentioned to revert auto-routing");
			}
		} catch (Exception ex) {
			logger.error("Error while revoking auto routing for inquiryId:[" + inquiryId + "]", ex);
			response.put(NLPConstants.SUCCESS, false);
			response.put(NLPConstants.MESSAGE, "RRevert request for auto routed workflows failed.");
		}
		return response;
	}

	/**
	 * This method is used to update and workflow audit.
	 * 
	 * @param autoRoutedGroupIds
	 * @param inquiry
	 * @param soeId
	 */
	private void updateWorkflowsAndAudit(List<Long> autoRoutedGroupIds, Inquiry inquiry, String soeId) {
		UpdateOperations<Inquiry> ops = mongoDatastore.createUpdateOperations(Inquiry.class);
		Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("id", inquiry.id);
		Date currentTime = new Date();
		List<Workflow> workflowList = inquiry.getWorkflows();
		List<WorkflowAudit> workflowAuditList = inquiry.getWorkflowAudit();
		boolean autoAssigned = removeRulesFlagFromWorkflow(inquiry, autoRoutedGroupIds, workflowList, workflowAuditList,
				currentTime, soeId);
		ops.set(WORKFLOWS, workflowList);
		ops.set(WORKFLOW_AUDIT, workflowAuditList);
		ops.set(NLPConstants.MOD_DATE, currentTime);
		if (!autoAssigned) {
			ops.set(AUTO_ASSIGNMENT_AVAILABLE_FLAG, false);
		}
		mongoDatastore.update(query, ops);
	}

	/**
	 * This method used to remove rulesflags from workflows
	 * 
	 * @param inquiry
	 * @param autoRoutedGroupIds
	 * @param workflowList
	 * @param workflowAuditList
	 * @param currentTime
	 * @param soeId
	 */
	private boolean removeRulesFlagFromWorkflow(Inquiry inquiry, List<Long> autoRoutedGroupIds,
			List<Workflow> workflowList, List<WorkflowAudit> workflowAuditList, Date currentTime, String soeId) {
		boolean autoAssigned = false;
		for (Workflow workflow : workflowList) {
			if (null != workflow.getAssignedGroupId() && autoRoutedGroupIds.contains(workflow.getAssignedGroupId())) {
				workflow.setLastActionby(soeId);
				workflow.setLastActionTime(currentTime);
				workflow.setModDate(currentTime);
				workflow.setModBy(soeId);
				workflow.setRulesFlag(null);
				workflow.setAutoAssigned(NLPConstants.REVOKED);
				workflow.setAutoAssignedAction(NLPConstants.REVOKE_MANUAL + " " + soeId);
				workflowAuditList.add(createWorkFlowsAudit(workflow.getAssignedGroupId(), currentTime, soeId));
			}
			if (NLPConstants.YES.equals(workflow.getAutoAssigned())) {
				autoAssigned = true;
			}
		}
		if (!autoAssigned) {
			updateConversationAutoAssignFlag(inquiry.getId(), NLPConstants.REVOKED);
		}
		return autoAssigned;
	}

	/**
	 * This method used to create workflow audit when auto routing revertd.
	 * 
	 * @param assignedGroupId
	 * @param currentTime
	 * @param soeId
	 * @return
	 */
	private WorkflowAudit createWorkFlowsAudit(Long assignedGroupId, Date currentTime, String soeId) {
		WorkflowAudit workflowAudit = new WorkflowAudit();
		workflowAudit.setAction("Revert NLP - Auto Assignment");
		workflowAudit.setGroupId(assignedGroupId);
		String actionDesc = "Workflow Marked as Inquiry";
		if (null != QMACacheFactory.getCache().getGroupIdToNameMap()) {
			String groupCode = QMACacheFactory.getCache().getGroupIdToNameMap().get(assignedGroupId);
			workflowAudit.setGroupName(groupCode);
			actionDesc = actionDesc.concat(" [" + groupCode + "]");
		}
		workflowAudit.setActionDetails(actionDesc);
		workflowAudit.setModBy(soeId);
		workflowAudit.setModDate(currentTime);
		return workflowAudit;
	}

	/**
	 * This method used to get auto routed workflows by inquiry id
	 * 
	 * @param inquiryId
	 * @return
	 */
	public BasicDBObject getAutoRoutedWorkflows(Long inquiryId) {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBList autoRoutedWorkflows = new BasicDBList();
			Inquiry inquiryObj = inquiryCommonDAO.getInquiryById(inquiryId);
			List<Workflow> workflows = inquiryObj.getWorkflows();
			for (Workflow workflow : workflows) {
				if (null != workflow.getAssignedGroupId() && null != workflow.getRulesFlag()
						&& null != workflow.getRulesFlag().getRuleType()
						&& NLPConstants.AUTO_ASSIGNMENT_RULE.equalsIgnoreCase(workflow.getRulesFlag().getRuleType())) {
					BasicDBObject routedObect = new BasicDBObject();
					routedObect.put(workflow.getAssignedGroupId().toString(), workflow.getAssignedGroupName());
					autoRoutedWorkflows.add(routedObect);
				}
			}
			response.put("autoRoutedWorkflows", autoRoutedWorkflows);
		} catch (Exception ex) {
			logger.error("Error while fetching auto routed workflows for inquiryId:[" + inquiryId + "]", ex);
		}
		return response;
	}

	/**
	 * This method adds suggestion status to the conversation.
	 * 
	 * @param sugRecord
	 */
	private void updateConversationForSuggestion(NLPSuggestionRecord sugRecord) {
		try {

			BasicDBObject suggestionStatus = getSuggestionStatus(sugRecord.getSuggestionReqStatusCode(),
					sugRecord.getResponseLevelIndicator());

			if (suggestionStatus != null && suggestionStatus.getBoolean(NLPConstants.STATUS_KEY)) {
				Query<Conversation> query = mongoDatastore.createQuery(Conversation.class).filter("_id",
						sugRecord.getConversationId());
				UpdateOperations<Conversation> updateOps = mongoDatastore.createUpdateOperations(Conversation.class);
				updateOps.set(NLPConstants.CONV_IS_SUGGESTION_AVAILABLE_KEY,
						suggestionStatus.getBoolean(NLPConstants.STATUS_KEY));
				// below is for default nlp subscribed groups. not in C and not in S.
				// updateOps.set(NLPConstants.CONV_SUGGESTION_STATUS_KEY,
				// suggestionStatus.getString(NLPConstants.SUGGESTION_STATUS));
				// below is for either type C or S. Type A need to added with one more if
				if (sugRecord.getNlpRequestType().equalsIgnoreCase(NLPRequestType.C.name())) {
					updateOps.set(NLPConstants.CONV_C_SUGGESTION_INDICATOR_KEY,
							suggestionStatus.getString(NLPConstants.SUGGESTION_STATUS));
					updateOps.set(NLPConstants.CONV_IS_NLP_DATA_STAMPED_AT_CONV_KEY, true);
				} else if (sugRecord.getNlpRequestType().equalsIgnoreCase(NLPRequestType.S.name())) {
					updateOps.set(NLPConstants.CONV_S_SUGGESTION_INDICATOR_KEY,
							suggestionStatus.getString(NLPConstants.SUGGESTION_STATUS));
					updateOps.set(NLPConstants.CONV_IS_NLP_DATA_STAMPED_AT_CONV_KEY, true);
				} else if(NLPRequestType.I.name().equalsIgnoreCase(sugRecord.getNlpRequestType())) {
					updateOps.set(NLPConstants.CONV_IS_NLP_DATA_STAMPED_AT_CONV_KEY, true);
				}else{
					logger.info("Not Supported NLPRequestType : {} to update converation.",
							sugRecord.getNlpRequestType());
				}
				mongoDatastore.update(query, updateOps);
				ConversationCache.getInstance().removeEntriesWithKeySetIteration(sugRecord.getInquiryid());
				logger.info(
						"Suggestion Status updated for conversation {} and inquiry {} as [ Suggestion Available : {}, SuggestionStatus: {} ]",
						sugRecord.getConversationId(), sugRecord.getInquiryid(),
						suggestionStatus.getBoolean(NLPConstants.STATUS_KEY),
						suggestionStatus.getString(NLPConstants.SUGGESTION_STATUS));
			}
		} catch (Exception e) {
			logger.error("Exception in NLPSuggestionDAO#updateConversationForSuggestion() for suggestion record : {}",
					sugRecord.getId(), e);
		}
	}

	/**
	 * This method used to stamp suggestion indicator orange as response is
	 * awaiting.
	 * 
	 * @param indicator
	 * @param conversation
	 * @param nlpRequestType
	 */
	public void updateConversationAsAwaitingResponse(NLPSuggestionRecord sugRecord,
			SuggestionStatusIndicator indicator, String intentSuggestionName, String intentTimeToVD) {
		try {
			if (null != sugRecord && (sugRecord.getNlpRequestType().equalsIgnoreCase(NLPRequestType.C.name())
					|| sugRecord.getNlpRequestType().equalsIgnoreCase(NLPRequestType.S.name())
					|| sugRecord.getNlpRequestType().equalsIgnoreCase(NLPRequestType.I.name()))) {
				Query<Conversation> query = mongoDatastore.createQuery(Conversation.class).filter("_id",
						sugRecord.getConversationId());
				UpdateOperations<Conversation> updateOps = mongoDatastore.createUpdateOperations(Conversation.class);
				if (sugRecord.getNlpRequestType().equalsIgnoreCase(NLPRequestType.C.name())) {
					updateOps.set(NLPConstants.CONV_C_SUGGESTION_INDICATOR_KEY, indicator.toString());
					updateOps.set(NLPConstants.CONV_IS_SUGGESTION_AVAILABLE_KEY, true);
				}
				if (sugRecord.getNlpRequestType().equalsIgnoreCase(NLPRequestType.S.name())) {
					updateOps.set(NLPConstants.CONV_S_SUGGESTION_INDICATOR_KEY, indicator.toString());
					updateOps.set(NLPConstants.CONV_IS_SUGGESTION_AVAILABLE_KEY, true);
				}
				if(sugRecord.getNlpRequestType().equalsIgnoreCase(NLPRequestType.I.name()) 
						&& null != sugRecord.getIntentSuggested() && sugRecord.getIntentSuggested().booleanValue()) {
					updateOps.set(NLPConstants.CONV_I_SUGGESTION_NAME_KEY, intentSuggestionName);
					updateOps.set(NLPConstants.CONV_I_ITME_TO_VD_KEY, intentTimeToVD);
					updateOps.set(NLPConstants.CONV_IS_INENT_SUGGESTION_AVAILABLE_KEY, true);
				}
				mongoDatastore.update(query, updateOps);
			}
		} catch (Exception e) {
			logger.error("Exception while updating conversation ID:" + sugRecord.getConversationId()
					+ "For NLP request Type:" + sugRecord.getNlpRequestType());
		}
	}
	
	
	public BasicDBObject saveIntentSuggestionFeedback(String soeId, BasicDBObject reqObj,BasicDBObject response, String actionDesc) throws CommunicatorException {
		try {
			final Long inquiryId = reqObj.getLong(NLPConstants.INQUIRY_ID_KEY);
			final Long convId = reqObj.getLong(NLPConstants.CONV_ID_KEY);
			
			final Long groupId = reqObj.getLong(NLPConstants.GROUP_ID_KEY);
			
			logger.info("{} giving feedback for intent suggestion for inquiryId: {},convId: {} ",soeId ,inquiryId , convId);
			
			if (null != inquiryId && null != convId && null != groupId) {
				Inquiry inquiry = inquiryCommonDAO.getInquiryById(inquiryId);
				Date lastModifiedDate = new Date();
				updateFeedbackForIntentSuggestion(soeId,reqObj);
				updateInquiryWorkFlowAudit(inquiry, groupId, soeId, NLPConstants.INTENT_FEEDBACK_KEY, actionDesc,
						lastModifiedDate);
				response.put("success", true);
				response.put("message", NLPConstants.FEEDBACK_MESSAGE_SUCCESS_KEY);
			} else {
				response.put("success", false);
				response.put("message", NLPConstants.FEEDBACK_MESSAGE_ERROR_KEY);
			}
		} catch (Exception e) {
			logger.error("Error in NLPSuggestionDAO#declineSuggestions() : ", e);
			response.put("success", false);
			response.put("message", NLPConstants.FEEDBACK_MESSAGE_ERROR_KEY);
		}
		return response;
	}
	
	private NLPRequestType getINlpRequestTypebyGroupId(String assignedGroupId) {
		QMACache qmaCache = QMACacheFactory.getCache();
		String groupCode = qmaCache.getGroupIdToCodeMap().get(Long.parseLong(assignedGroupId));
		List<String> intentSuggestionGrps = qmaCache.getIntentSuggestionEnabledGroupList();
		NLPRequestType reqType = NLPRequestType.A;
		if(null != intentSuggestionGrps && !intentSuggestionGrps.isEmpty() && intentSuggestionGrps.contains(groupCode.toUpperCase())) {
			reqType = NLPRequestType.I;
		}
		return reqType;
	}
	
	public void updateInquiryAndConversationObj(BasicDBObject reqObj,BasicDBObject response,Long inquiryId, Long convId,List<Long> groupIds, boolean intentUserFeedback) {
		try {
			
			String userIntentSuggestion = getUserIntentSuggestionName(reqObj);
			updateConversationObjWithUserSuggestedIntent(userIntentSuggestion,convId,intentUserFeedback);
			updateInquiryObjWithUserSuggestedIntent(userIntentSuggestion,inquiryId,response, groupIds,intentUserFeedback);
			logger.info("User intent suggestion feedback updated succesfully");
		} catch (Exception e) {
			logger.info("Exception while updating user intent sugeestion feedback: ",e);
		}
	}
	private String getUserIntentSuggestionName(BasicDBObject reqObj) {
		String userIntentSuggestion = "";
		try {
			BasicDBObject correctIntents = reqObj.containsField(NLPConstants.CORRECT_INTENTS_KEY) ? (BasicDBObject) reqObj.get(NLPConstants.CORRECT_INTENTS_KEY) : new BasicDBObject();
			BasicDBObject intents = (BasicDBObject) correctIntents.get("correctIntents");
			Collection<Object> col = intents.values();
			userIntentSuggestion = (String) col.iterator().next();
		}catch(Exception e) {
			logger.warn("Exception while getting user intnet suggestion from request: {}", reqObj);
		}
		logger.info("userIntentSuggestion: {}", userIntentSuggestion);
		return userIntentSuggestion;
	}
	
	private void updateInquiryObjWithUserSuggestedIntent(String userSuggestionIntent, Long inquiryId, BasicDBObject result,List<Long> groupIds, boolean intentUserFeedback){
		try {
            if(intentUserFeedback)  {
				logger.info("intnetUserFeedback:{} or userSuggestionIntent:{}, skipping Workflow updation.",intentUserFeedback,userSuggestionIntent);;
				return;
			}	
			Inquiry inquiry = inquiryCommonDAO.getInquiryById(inquiryId);
			if (inquiry != null && inquiry.getWorkflows() != null && !inquiry.getWorkflows().isEmpty()) {
				for (Workflow currentWorkflow : inquiry.getWorkflows()) {
					if(groupIds.contains(currentWorkflow.getAssignedGroupId())) {
						currentWorkflow.setUserIntentSuggestionName(userSuggestionIntent);
						result.put("predictedIntent", currentWorkflow.getIntentSuggestionName());
						result.put("userIntentSuggestion", userSuggestionIntent);
					}
				}
				mongoDatastore.save(inquiry);
			}
		} catch (Exception e) {
			logger.error("Exception while saving user intent suggestion feedback: ", e);
		}
	}
	
	public NLPSuggestionRecord getSuggestionReord(Long inquiryId, Long convId,String nlpRequestType) {
		Query<NLPSuggestionRecord> query = null;
		NLPSuggestionRecord sugRecord = null;
		try {
			query = mongoDatastore.createQuery(NLPSuggestionRecord.class)
					.filter(NLPConstants.INQUIRY_ID_DB_KEY, inquiryId)
					.filter(NLPConstants.CONVERSATION_ID_DB_KEY, convId)
					.filter(NLPConstants.NLP_REQUEST_TYPE_KEY, nlpRequestType).limit(0); 
			query.order("-crtDate");
			sugRecord = query.get();
			if (sugRecord == null) {
				logger.error("No NLP data found for inquiryId= {}, convId: {}, nlpRequestType= {}",inquiryId, convId, nlpRequestType);
			}
		} catch (Exception e) {
			logger.error("Exception in getSuggestionRecordfor inquiryId= {}, convId: {}, nlpRequestType= {}, ",inquiryId, convId, nlpRequestType,e);
		}
		return sugRecord;
	}
	
	private void updateConversationObjWithUserSuggestedIntent(String userSuggestionIntent, Long convId, boolean intentUserFeedback) {
		if(intentUserFeedback)  {
			logger.info("intnetUserFeedback:{} or userSuggestionIntent:{}, skipping conversation updation.",intentUserFeedback,userSuggestionIntent);;
			return;
		}
		Query<Conversation> query = mongoDatastore.createQuery(Conversation.class).filter("_id",
				convId).limit(0);
		query.order("crtDate");
		UpdateOperations<Conversation> updateOps = mongoDatastore.createUpdateOperations(Conversation.class);
		updateOps.set("userIntentSuggestionName", userSuggestionIntent);
		mongoDatastore.update(query, updateOps);
	}

	public BasicDBObject intentSuggestionFeedback(String soeId, String request) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBObject reqObj = BasicDBObject.parse(request);
			final Long inquiryId = reqObj.getLong(NLPConstants.INQUIRY_ID_KEY);
			final Long convId = reqObj.getLong(NLPConstants.CONV_ID_KEY);

			final Long groupId = reqObj.getLong(NLPConstants.GROUP_ID_KEY);

			logger.info("{} giving feedback for intent suggestion for inquiryId: {},convId: {} ",soeId ,inquiryId , convId);

			if (null != inquiryId && null != convId && null != groupId) {
				Inquiry inquiry = inquiryCommonDAO.getInquiryById(inquiryId);
				Date lastModifiedDate = new Date();
				updateFeedbackForIntentSuggestion(soeId,reqObj);
				updateInquiryWorkFlowAudit(inquiry, groupId, soeId, NLPConstants.INTENT_FEEDBACK_KEY, NLPConstants.FEEDBACK_MESSAGE_SUCCESS_KEY,
						lastModifiedDate);
				response.put("success", true);
				response.put("message", NLPConstants.FEEDBACK_MESSAGE_SUCCESS_KEY);
			} else {
				response.put("success", false);
				response.put("message", NLPConstants.FEEDBACK_MESSAGE_ERROR_KEY);
			}
		} catch (Exception e) {
			logger.error("Error in NLPSuggestionDAO#declineSuggestions() : ", e);
			response.put("success", false);
			response.put("message", NLPConstants.FEEDBACK_MESSAGE_ERROR_KEY);
		}
		return response;
	}
}
