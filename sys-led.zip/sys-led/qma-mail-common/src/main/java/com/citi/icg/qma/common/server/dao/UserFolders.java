package com.citi.icg.qma.common.server.dao;

public class UserFolders
{
	private String userId;
	private String folderName;

	public UserFolders()
	{

	}

	public UserFolders(String userId, String folderName)
	{

		this.userId = userId;
		this.folderName = folderName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFolderName() {
		return folderName;
	}

	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}
	
}
