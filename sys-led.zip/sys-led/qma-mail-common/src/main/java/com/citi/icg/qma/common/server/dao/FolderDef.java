package com.citi.icg.qma.common.server.dao;

import java.util.Date;

import org.bson.types.ObjectId;

import dev.morphia.annotations.Embedded;

@Embedded
public class FolderDef
{
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private ObjectId folderId;
	private String name;
	private Date crtDate;
	private Date modDate;

	public FolderDef(String name, Date crtDate, Date modDate)
	{
		this.name = name;
		this.crtDate = crtDate;
		this.modDate = modDate;

	}

	public ObjectId getFolderId() {
		return folderId;
	}

	public void setFolderId(ObjectId folderId) {
		this.folderId = folderId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getCrtDate() {
		return crtDate;
	}

	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}

	public Date getModDate() {
		return modDate;
	}

	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}
}
