package com.citi.icg.qma.common.server.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hslf.usermodel.HSLFSlideShow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.poifs.crypt.Decryptor;
import org.apache.poi.poifs.crypt.EncryptionInfo;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.MailCommonUtil;

import net.lingala.zip4j.ZipFile;

public class EncryptionUtility
{
	private static final Logger logger = LoggerFactory.getLogger(EncryptionUtility.class);
	public static final String[] fileTypesSupportedForPasswordProtection = {"XLSX",  "XLS",  "DOCX",  "DOC",  "PPTX",  "PPT" , "PDF" , "ZIP"};
	
	public static boolean isFileEncrypted(String fileExtension, File file)
	{
		InputStream targetStream;
		try
		{
			if(file!=null){
				targetStream = new FileInputStream(file);
				return isFileEncrypted(fileExtension, targetStream);
			}
		}
		catch (FileNotFoundException e)
		{
			logger.error("Error in converting to InputStream for file: "+ file.getAbsolutePath(), e);
		}
		return false;
	}
	
	public static boolean isFileEncrypted(String fileExtension, InputStream inputStream)
	{
		boolean isEncrypted = false;
		if(inputStream != null && !StringUtils.isBlank(fileExtension))
		{
			switch(fileExtension.toUpperCase()){
			case "PDF":
				isEncrypted = isPdfEncrypted(inputStream);
				break;

			case "ZIP":
				isEncrypted = isZipEncrypted(inputStream);
				break;

			case "DOCX":
				isEncrypted = isMicrosoftFileEncrypted(inputStream);
				break;

			case "XLSX":
				isEncrypted = isMicrosoftFileEncrypted(inputStream);
				break;

			case "PPTX":
				isEncrypted = isMicrosoftFileEncrypted(inputStream);
				break;

			case "DOC":
				isEncrypted = isOldWordDocEncrypted(inputStream);
				break;

			case "XLS":
				isEncrypted = isOldExcelEncrypted(inputStream);
				break;

			case "PPT":
				isEncrypted = isOldPptEncrypted(inputStream);
				break;

			default:	

			}
		}
		return isEncrypted;
	}
	
	// Checking encryption for PDF files
	private static boolean isPdfEncrypted(InputStream inputStream)
	{
		boolean encrypted = false;
		try{
			PDDocument doc = Loader.loadPDF(IOUtils.toByteArray(inputStream));
			if(doc.isEncrypted())
	            encrypted=true;			
			doc.close();
		}
		catch (InvalidPasswordException e){
			encrypted = true;
		}		
		catch (Exception e) {
			logger.error("Error in verifying pdf encryption", e);
		}
		return encrypted;
	}
	
	// Checking encryption for zip files
	private static boolean isZipEncrypted(InputStream inputStream)
	{
		boolean encrypted = false;
		OutputStream outStream = null;
		File tempFile = null;
		try{
			
			byte[] buffer = new byte[inputStream.available()];
			inputStream.read(buffer);
			Date date = new Date() ;
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
			String timeStamp = dateFormat.format(date);
		    tempFile = MailCommonUtil.createFile("TempZipFile_"+ timeStamp +".zip");
		    outStream = new FileOutputStream(tempFile);
		    outStream.write(buffer); 
			ZipFile zipFile = new ZipFile(tempFile);
			if (zipFile.isEncrypted()) {
	            encrypted=true;
			}
			
		}
		catch (Exception e) {
			logger.error("Error in verifying zip encryption", e);
		}
		finally{
			try
			{
				if(outStream != null) outStream.close();
				if(tempFile != null) tempFile.delete();
			}
			catch (Exception e)
			{
				logger.error("Error in temp zip file deletion in isZipEncrypted() method", e);
			}
		}
		return encrypted;
	}
	
	// Checking encryption for Microsoft Word, Excel and PowerPoint files
	private static boolean isMicrosoftFileEncrypted(InputStream inputStream)
	{
		boolean encrypted = false;
		try{
			POIFSFileSystem fs = new POIFSFileSystem(inputStream);
			EncryptionInfo info = new EncryptionInfo(fs);
			Decryptor d = Decryptor.getInstance(info);

			if (!d.verifyPassword("")) {
				encrypted = true;
			}
		}		
		catch (Exception e) {
			logger.debug("Microsoft file not encrypted", e);
		}
		return encrypted;
	}
	
	// Checking encryption for Microsoft Word 97-2003 document
	private static boolean isOldWordDocEncrypted(InputStream inputStream)
	{
		boolean encrypted = false;
		try{
			new HWPFDocument(inputStream);
		}
		catch(EncryptedDocumentException e){
			encrypted = true;
		}		
		catch (Exception e) {
			logger.error("Error in verifying OldWordDoc encryption", e);
		}
		return encrypted;
	}
	
	// Checking encryption for Microsoft Excel 97-2003 worksheet
	private static boolean isOldExcelEncrypted(InputStream inputStream)
	{
		boolean encrypted = false;
		try{
			new HSSFWorkbook(inputStream);
		}
		catch(EncryptedDocumentException e){
			encrypted = true;
		}		
		catch (Exception e) {
			logger.error("Error in verifying OldExcel encryption", e);
		}
		return encrypted;
	}
	
	// Checking encryption for Microsoft PowerPoint 97-2003 presentation
	private static boolean isOldPptEncrypted(InputStream inputStream)
	{
		boolean encrypted = false;
		try{
			new HSLFSlideShow(inputStream);
		}
		catch(EncryptedDocumentException e){
			encrypted = true;
		}		
		catch (Exception e) {
			logger.error("Error in verifying OldPpt encryption", e);
		}
		return encrypted;
	}
}
