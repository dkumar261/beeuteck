package com.citi.icg.qma.common.server.dao.persistence;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

//Use this class if query needs to be executed based on Mongo-Java Driver (instead of Morphia based).
public class MongoJavaDriverDAO
{
	private static final Logger subLogger = LoggerFactory.getLogger(MongoJavaDriverDAO.class);
	private static final DB database = MongoDB.instance().getDB();

	public void getInquiryDetails()
	{

		DBCollection col = database.getCollection("Inquiry");
		DBObject query = new BasicDBObject("_id", 7185351);
		BasicDBObject fields = new BasicDBObject("inquiryId", true).append("status", true).append("groupId", true);

		DBCursor c1 = col.find(query, fields);
		try
		{
			while (c1.hasNext())
			{
				String dbData = c1.next().toString();
			}
		}
		finally
		{
			c1.close();
		}

	}

}
