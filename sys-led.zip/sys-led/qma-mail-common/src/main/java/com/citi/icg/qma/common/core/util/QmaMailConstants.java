package com.citi.icg.qma.common.core.util;

import java.text.SimpleDateFormat;

public final class QmaMailConstants
{
	private QmaMailConstants(){};//Sonar fix - to hide the class having all methods and variables as static
	
	// Added to decrypt the encrypted passwords
	public static final String APPLICATION_ENCRYPTION_KEY = "heyQI0JfwINcT3M0WAwOXA==";
	public static final String STATUS_OPEN = "OPEN";
	public static final String STATUS_RESOLVE = "RESOLVED";
	public static final String MONGO_PK = "_id";
	public static final String SERVICE_FAILURE_MESSAGE = "Service failed !";
	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
	public static final String SUGGESTION_ACCEPT_ACTION = "accept";
	public static final String SUGGESTION_DECLINE_ACTION = "decline";
	public static final String SUGGESTION_DECLINED_DESC = "Suggestion Declined";
	public static final String SUGGESTION_STATUS_SENT = "Sent";
	public static final String SUGGESTION_STATUS_NOT_SENT = "Not Sent";
	public static final String SUCCESS_KEY = "success";
	public static final String MESSAGE_KEY = "message";
	public static final String ESCALATION_CRITERIA_CONFIG_ID = "EscalationCriteria";
	public static final String INQUIRY_DIRECTION_IN = "IN";
	public static final String INQUIRY_DIRECTION_OUT = "OUT";
	public static final String STRING_YES = "Y";
	public static final String STRING_NO = "N";
	public static final String ACTION_TIME = "actionTime";
	public static final String CC_CATEGORY = "CC";
	public static final String TO_CATEGARY = "TO";
	public static final String CC_CATEGARY = "CC";
	public static final String APP_CONTEXT = "QMA";
	//public static final String APPBASEURL = "/QMASTORM/rest";
	
	public static final String STRING_TO = "TO";
	public static final String STRING_CC = "CC";
	public static final String STRING_FROM = "FROM";
	public static final String STRING_BCC = "BCC";
	// This is the maximum record fetch limit at a time
	public static final int MAX_SERVER_REC_LIMIT = 5000000;
	public static final String ACTION_ASSIGN_TO_OWNER_AUTO = "Assign Owner (Auto)";
	public static final String ACTION_ASSIGN_TO_REQ_TYPE_AUTO = "Assign Request Type (Auto)";
	public static final String ACTION_ASSIGN_TO_TAG_AUTO = "Assign Tag (Auto)";
	public static final String ACTION_ASSIGN_TO_TAG_PROCESSING_REGION = "Assign Processing Region (Auto)";
	public static final String REQUEST_TYPE = "requestType";
	public static final String ASSIGN_TO_USER = "assignToUser";
	public static final String MARK_AS_NON_INQUIRY = "markAsNonInquiry";
	public static final String MARK_FOR_DELETION = "markForDeletion";
	public static final String ASSIGN_TAG = "assignToTag";
	public static final String ASSIGN_PROCESSING_REGION = "assignProcessingRegion";
	public static final String INQUIRY_RULE = "Inquiry Rule";
	public static final String GROUP_RULE = "groupRule";
	public static final String SMART_RULE = "smartRule";
	public static final String SMARTWORKFLOWSTATUS = "Smart Routing Rule";
	public static final String SMART_ROUTING_CONFIG_FLAG_ID = "smartRoutingRule";
	public static final String COULMN_DISPLAY_TYPE_ICON = "icon";
	public static final String ACTION_NON_INQUIRY_AUTO = "Non Inquiry (Auto)";
	
	public static final String ACTION_REPLY = "Reply";
	public static final String ORIGIN_TYPE_INTERNAL = "INTERNAL";
	public static final String ORIGIN_TYPE_EXTERNAL = "EXTERNAL";
	public static final String ACTION_NEW_INQUIRY = "New Inquiry";
	
	
	public static final String ACTION_RESOLVE = "Resolved";
	public static final String FROM_CATEGORY = "FROM";
	
	
	public static final String PENDING_APPROVAL = "PENDINGAPPROVAL";
	public static final String PENDING_APPROVAL_REAGE = "PND_REAGE";
	
	public static String QMA_MAIL_CONFIG_FILE = "qma.mail.config.file";
	public static String QMA_ICG_ENV = "icg.env";
	
	// Time Difference and Time Units
	public static final String TIME_DIFF = "timeDiff";
	public static final String TIME_UNIT_MINS = "minutes";
	public static final String TIME_UNIT_HRS = "hours";
	public static final String TIME_UNIT_DAYS = "days";

	public static final String INDIVIDUAL_VIEW_NAME = "Individual";
	public static final String INDIVIDUAL_NODE_TYPE = "IND";
	
	public static final class Kafka {
		// [C153176-3382] - increasing the maximum message size to 104857600 bytes(100 MB)
		public static final String MAX_REQUEST_SIZE_CONFIG = (Integer.valueOf(104857600)).toString();
		public static final String COMPRESSION_TYPE_CONFIG = "snappy";
	}
}
