package com.citi.icg.qma.common.server.dao.persistence;

//import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.UserActivities;
import com.citi.icg.qma.common.server.dao.UserUsageStats;

import dev.morphia.Datastore;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

public class UserActivitiesDAO extends MongoMorphiaDAO {
	private static final Logger subLogger = LoggerFactory.getLogger(UserActivitiesDAO.class);
	private static MongoDB mongoDB;
	private static Datastore store;

	//private static final AuditTrailDAO audit = new AuditTrailDAO();

	static {
		mongoDB = MongoDB.instance();
		store = mongoDB.getDataStore();
	}

	/*
	 * Use saveUserActivities method with response time public boolean
	 * saveUserActivities(String userId, String action, String description,
	 * UserActivities userActivity) throws CommunicatorException//Sonar Fix --
	 * Define and throw a dedicated exception instead of using a generic one {
	 * return saveUserActivities(userId, action, description,userActivity,null); }
	 */

	public boolean saveUserActivities(String userId, UserActivities userActivity, Long responseTimeInMills)
			throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a
										// generic one
	{
		try {
			if (!StringUtils.isEmpty(userId)) {
				if (null != responseTimeInMills) {
					userActivity.setResponseTimeInMills(responseTimeInMills);
				}
				store.save(userActivity);
				subLogger.info("User action saved successfully. User Id: " + userId + " User Action: " + userActivity.getDescription());
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			subLogger.error("Exception in UserActivitiesDAO.saveUserActivities", e);
			throw new CommunicatorException("Exception in UserActivitiesDAO.saveUserActivities", e);
		}
	}

	/**
	 * This method will log source origin QMA1/QMA2
	 * 
	 * @param request
	 * @param userActivity
	 */
	/*
	 * private void updateUserRequestInformation(UserActivities userActivity) { if
	 * (null != userActivity) { audit.logUserInformation(userActivity); } }
	 */

	/**
	 * This method saves user activity object into database
	 * 
	 * @param activity
	 * @return
	 */
	public boolean saveUserActivity(UserActivities activity) {
		boolean saveFlag = false;
		try {
			store.save(activity);
			saveFlag = true;
		} catch (Exception e) {
			subLogger.error("Exception while saving object into user activities : ", e);
		}
		return saveFlag;
	}

	public void saveUserUsageStats(UserUsageStats userUsageStats) {
		try {
			UserUsageStats userUsageStatsFromDB = getUserStatsByComponentId(userUsageStats);
			if(null != userUsageStatsFromDB && null != userUsageStats.getLoginTime() && null == userUsageStats.getLogoutTime()) {
				long timeSpent =  (userUsageStats.getLoginTime().getTime() - userUsageStatsFromDB.getLoginTime().getTime())/1000;
				UpdateOperations<UserUsageStats> ops = mongoDatastore.createUpdateOperations(UserUsageStats.class);
				Query<UserUsageStats> query = mongoDatastore.createQuery(UserUsageStats.class).filter("_id",userUsageStatsFromDB.getId());
				ops.set("timeSpentInSec", timeSpent);
				ops.set("logoutTime", userUsageStats.getLoginTime());
				store.update(query, ops);
			}
			store.save(userUsageStats);
		} catch (Exception e) {
			subLogger.error("Exception while saving object into userUsageStats : ", e);
		}
	}
	public UserUsageStats getUserStatsByComponentId(UserUsageStats userUsageStats) throws CommunicatorException
	{
		return mongoDatastore.createQuery(UserUsageStats.class).filter("userId", userUsageStats.getUserId()).order("-loginTime").limit(1).get();
	}
}
