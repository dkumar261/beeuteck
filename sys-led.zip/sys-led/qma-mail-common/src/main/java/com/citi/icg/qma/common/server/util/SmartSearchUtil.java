package com.citi.icg.qma.common.server.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

public class SmartSearchUtil {
	private static final String SEARCH = "Search";
	private static final String VIEW_NAME = "viewName";
	private static final String STATUS_LIST = "statusList";
	private static final String TRADES = "trades";
	private static final String CONTENT = "content";
	private static final String VALUE = "value";
	private static final String ID = "id";
	private static final String SMART_ENTITIES = "entities";
	private static final String ADVANCE_SEARCH_DATA_KEY = "advanceSearchData";
	private static final String END_DT_KEY = "endDt";
	private static final String START_DT_KEY = "startDt";
	private static final String SUBJECT_KEY = "subject";
	private static final String ORIGINATOR_KEY = "originator";
	private static final String SOLR_SEARCH_TEXT_KEY = "solrSearchText";
	private static final String SMART_SEARCH_CONFIG = "smartSearchConfig";
	private static final String SMART_SEARCH_ENABLED = "smartSearchEnabled";
	private static final String SMART_SEARCH_API = "smartSearchAPI";
	private static final String SMART_SEARCH_API_TIMEOUT_LIMIT = "apiTimeoutLimitInSec";
	public static final String SOLR_SEARCH_TEXT = "solrSearchText";
	public static final String ADVANCED_SEARCH_DATA = "advanceSearchData";
	private static final Logger logger = LoggerFactory.getLogger(SmartSearchUtil.class);
	private static QMACache qmaCache = QMACacheFactory.getCache();
	private static int timeoutLimitMillis = 0;

	public static void setSmartSearchUrlOnlyForUnitTesting(String smartSearchUrl) {
		SmartSearchUtil.smartSearchUrl = smartSearchUrl;
	}

	private static String smartSearchUrl = null;
	
	
	/**
	 * @param inputJsonObj
	 * @return
	 */
	public static BasicDBObject getSmartSearchCriteria(BasicDBObject inputJsonObj) {
		BasicDBObject modifiedSolrInput = null;
		long startTime = System.currentTimeMillis();
		try {
			if (null != smartSearchUrl) {
				BasicDBObject smartSearchResponse = getResponseFromSmartSearch(inputJsonObj);
				logger.info("Time taken to get response from smart serach API:{} in ms",(System.currentTimeMillis() - startTime));
				if(null != smartSearchResponse) {
					modifiedSolrInput = prepareSolrQueryInput(smartSearchResponse, inputJsonObj);
				}else {
					modifiedSolrInput = getInputForRegularSearch(inputJsonObj);
				}
			}
		} catch (Exception ex) {
			logger.error("Exception in getSmartSearchCriteria", ex);
			modifiedSolrInput = getInputForRegularSearch(inputJsonObj);
		}
		return modifiedSolrInput;
	}
	/**
	 * @param smartSearchResponse
	 * @param inputJsonObj
	 * @return
	 */
	private static BasicDBObject prepareSolrQueryInput(BasicDBObject smartSearchResponse, BasicDBObject inputJsonObj) {
		BasicDBObject modifiedSearchParam = new BasicDBObject();
		if(smartSearchResponse.containsField(SMART_ENTITIES)) {
			BasicDBList smartEntitiesList = (BasicDBList) smartSearchResponse.get(SMART_ENTITIES);
			if(null != smartEntitiesList && !smartEntitiesList.isEmpty()) {
				for (Object entity : smartEntitiesList) {
					BasicDBObject entityObject = BasicDBObject.parse(entity.toString());
					modifiedSearchParam = getFilteredParams(inputJsonObj, modifiedSearchParam, entityObject);
				}
			}else {
				modifiedSearchParam = getInputForRegularSearch(inputJsonObj);
				modifiedSearchParam = inputJsonObj;

			}
		}else {
			modifiedSearchParam = getInputForRegularSearch(inputJsonObj);
		}
		return modifiedSearchParam;
	}

	public static BasicDBObject getInputForRegularSearch(BasicDBObject inputJsonObj) {
		if (inputJsonObj.containsField(VIEW_NAME) && "All".equalsIgnoreCase(inputJsonObj.getString(VIEW_NAME))) {
			inputJsonObj.put(VIEW_NAME, SEARCH);
		} 
		return inputJsonObj;
	}
	
	/**
	 * @param inputJsonObj
	 * @param modifiedSearchParam
	 * @param entityObject
	 * @return
	 */
	private static BasicDBObject getFilteredParams(BasicDBObject inputJsonObj, BasicDBObject modifiedSearchParam,	BasicDBObject entityObject) {
		if (entityObject.containsField("filter_params")) {
			BasicDBList filterParamsList = (BasicDBList) entityObject.get("filter_params");
			if(null != filterParamsList && !filterParamsList.isEmpty()) {
				for (Object filterParam : filterParamsList) {
					BasicDBObject param = BasicDBObject.parse(filterParam.toString());
					if (param.containsField(ID) && param.containsField(VALUE)) {
						String paramId = param.getString(ID);
						BasicDBList valueList = (BasicDBList) param.get(VALUE);
						getSearchValue(paramId, valueList, inputJsonObj, modifiedSearchParam);
					}
				}
				if(inputJsonObj.containsField(SOLR_SEARCH_TEXT_KEY) && !inputJsonObj.containsField("isGlobalSearch")) {
					inputJsonObj.remove(SOLR_SEARCH_TEXT_KEY);
				}		
			}else {
				inputJsonObj = getInputForRegularSearch(inputJsonObj);
			}
		}
		modifiedSearchParam = inputJsonObj;
		return modifiedSearchParam;
	}
	/**
	 * @param paramId
	 * @param valueList
	 * @param inputJsonObj
	 * @param modifiedSearchParam 
	 * @return
	 */
	private static BasicDBObject getSearchValue(String paramId, BasicDBList valueList, BasicDBObject inputJsonObj, BasicDBObject newAdvancedSearchObject) {
		switch(paramId) {
		case "INQ_ID":
			setInquiryIdForSolrQuery(valueList, inputJsonObj);
			break;
		case "SUBJECT":
			setSubjectForSolrQuery(valueList, newAdvancedSearchObject, inputJsonObj);
			break;
		case "CONTENT":
			setContentForSolrQuery(valueList, newAdvancedSearchObject, inputJsonObj);
			break;
		case "FROM_EMAIL":
			setRecipientsFromForSolrQuery(valueList, inputJsonObj, newAdvancedSearchObject);
			break;
		case "TO_EMAIL":
			setRecipientsToForSolrQuery(valueList, inputJsonObj, newAdvancedSearchObject);
			break;
		case "AGE_DAY":
			setDateCriteriaForSolrQuery(valueList, inputJsonObj, newAdvancedSearchObject);
			break;
		case "TRD_DT":
			setTradeDateCriteriaForSolrQuery(valueList, newAdvancedSearchObject);
			break;
		case "STATUS":
			setStausForSolrQuery(valueList, newAdvancedSearchObject, inputJsonObj);
			break;
		default:
			logger.info("No match found");
		}
		inputJsonObj.put(ADVANCE_SEARCH_DATA_KEY, newAdvancedSearchObject);
		return inputJsonObj;
	}
	private static void setStausForSolrQuery(BasicDBList valueList, BasicDBObject newAdvancedSearchObject,
			BasicDBObject inputJsonObj) {
		if(!valueList.isEmpty()) {
			newAdvancedSearchObject.put(STATUS_LIST, valueList);		}
		
	}
	/**
	 * @param valueList
	 * @param newAdvancedSearchObject
	 */
	private static void setTradeDateCriteriaForSolrQuery(BasicDBList valueList, BasicDBObject newAdvancedSearchObject) {
		String trdStartDate = getMongoFormatedDt((String) valueList.get(0));
		String trdEndDate = null;
		if(null != valueList && valueList.size() == 1) {
			trdEndDate = trdStartDate;
			trdStartDate = datePreviousDay((String) valueList.get(0));
		}else {
			trdEndDate = getMongoFormatedDt((String) valueList.get(1));
		}
		if(null != trdStartDate && null != trdEndDate) {
			newAdvancedSearchObject.put(START_DT_KEY, trdStartDate+"T18:30:00.000Z");
			newAdvancedSearchObject.put(END_DT_KEY, trdEndDate+"T18:29:59.999Z");
			newAdvancedSearchObject.put(SUBJECT_KEY, TRADES);
			newAdvancedSearchObject.put(CONTENT, TRADES);
		}
	}
	/**
	 * @param valueList
	 * @param inputJsonObj
	 * @param newAdvancedSearchObject
	 */
	private static void setDateCriteriaForSolrQuery(BasicDBList valueList, BasicDBObject inputJsonObj,
			BasicDBObject newAdvancedSearchObject) {
		BasicDBList dateList = (BasicDBList)valueList.get(0);
		String startDate =(String) dateList.get(0);
		String endDate = (String) dateList.get(1);
		String startFormattedDate = getMongoFormatedDt((String) dateList.get(0));
		if(startDate.equals(endDate)) {
			startFormattedDate = datePreviousDay(startDate);
		}
		String endFormattedDate = getMongoFormatedDt(endDate);
		if(null != startFormattedDate && null != endFormattedDate) {
			String searchText = inputJsonObj.getString(SOLR_SEARCH_TEXT_KEY);
			if(searchText.contains("trade")) {
				newAdvancedSearchObject.put(CONTENT, TRADES);
			}
			newAdvancedSearchObject.put(START_DT_KEY, startFormattedDate+"T18:30:00.000Z");
			newAdvancedSearchObject.put(END_DT_KEY, endFormattedDate+"T18:29:59.999Z");
		}
	}
	/**
	 * @param valueList
	 * @param inputJsonObj
	 * @param newAdvancedSearchObject
	 */
	private static void setRecipientsToForSolrQuery(BasicDBList valueList, BasicDBObject inputJsonObj,
			BasicDBObject newAdvancedSearchObject) {
		String toOrginator = (String) valueList.get(0);
		if(!StringUtils.isEmpty(toOrginator)) {
			inputJsonObj.put("to", toOrginator);
			toOrginator = handleOrginator(toOrginator);
			newAdvancedSearchObject.put(ORIGINATOR_KEY, toOrginator);
		}
	}
	/**
	 * @param valueList
	 * @param inputJsonObj
	 * @param newAdvancedSearchObject
	 */
	private static void setRecipientsFromForSolrQuery(BasicDBList valueList, BasicDBObject inputJsonObj,
			BasicDBObject newAdvancedSearchObject) {
		String fromOrginator = (String) valueList.get(0);
		if(!StringUtils.isEmpty(fromOrginator) ) {
			inputJsonObj.put("from", fromOrginator);
			fromOrginator = handleOrginator(fromOrginator);
			newAdvancedSearchObject.put(ORIGINATOR_KEY, fromOrginator);
		}
	}
	/**
	 * @param fromOrginator
	 * @return
	 */
	private static String handleOrginator(String fromOrginator) {
		boolean fullEmailId = false;
		if(fromOrginator.contains("@")) {
			fromOrginator = fromOrginator.replace("@", "%40");
			fullEmailId = true;
		}
		if(!fromOrginator.contains(" ") && !fullEmailId) {
			fromOrginator = fromOrginator.concat("*");
		}else {
			fromOrginator = fromOrginator.replace(" ", "%2B");
		}
		return fromOrginator;
	}
	private static void setContentForSolrQuery(BasicDBList valueList, BasicDBObject newAdvancedSearchObject, BasicDBObject inputJsonObj) {
		String content = (String) valueList.get(0);
		if (!StringUtils.isEmpty(content)) {
			if (null != inputJsonObj.get(SOLR_SEARCH_TEXT_KEY) && inputJsonObj.getString(SOLR_SEARCH_TEXT_KEY).contains("\"")) {
				inputJsonObj.put(SOLR_SEARCH_TEXT_KEY, "content:\"" + content + "\"");
			} else {
				newAdvancedSearchObject.put(CONTENT, content);
			}	
		}
	}

	private static void setSubjectForSolrQuery(BasicDBList valueList, BasicDBObject newAdvancedSearchObject, BasicDBObject inputJsonObj) {
		String subject = (String) valueList.get(0);
		if (!StringUtils.isEmpty(subject)) {
			if (null != inputJsonObj.get(SOLR_SEARCH_TEXT_KEY) && inputJsonObj.getString(SOLR_SEARCH_TEXT_KEY).contains("\"")) {
				newAdvancedSearchObject.put(SUBJECT_KEY, "\"" + subject + "\"");
			} else {
				newAdvancedSearchObject.put(SUBJECT_KEY, subject);
			}	
		}
	}

	private static void setInquiryIdForSolrQuery(BasicDBList valueList, BasicDBObject inputJsonObj) {
		String inquiryId = (String) valueList.get(0);
		if(!StringUtils.isEmpty(inquiryId)) {
			inputJsonObj.put(SOLR_SEARCH_TEXT_KEY, inquiryId);
			inputJsonObj.put("isGlobalSearch", true);
		}
	}
	
	private static String datePreviousDay(String trdStartDate) {
		String previousDayDate = null;
		try {
			SimpleDateFormat outputDate = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat inputFormat = new SimpleDateFormat("MM-dd-yyyy");
			Date date = inputFormat.parse(trdStartDate);
			if (null != date) {
				Calendar c = Calendar.getInstance(); 
				c.setTime(date); 
				c.add(Calendar.DATE, -1);
				date = c.getTime();
				previousDayDate = outputDate.format(date);
			}
		} catch (Exception e) {
			logger.warn("Exception while parsing date", e);
		}
		return previousDayDate;
	}
	/**
	 * @param dateText
	 * @return
	 */
	private static String getMongoFormatedDt(String dateText) {
		String formattedvalue = null;
		try {
			SimpleDateFormat outputDate = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat inputFormat = new SimpleDateFormat("MM-dd-yyyy");
			Date date = inputFormat.parse(dateText);
			if (null != date) {
				formattedvalue = outputDate.format(date);
			}
		} catch (Exception e) {
			logger.warn("Exception while parsing date", e);
		}
		return formattedvalue;
	}
	/**
	 * @return
	 */
	public static boolean isSmartSearchEnabled () {
		boolean isSmartSearchEnabled = false;
		if(null != qmaCache.getConfigById(SMART_SEARCH_CONFIG)) {
			Map<String, Object> smartSearchConfigMap = qmaCache.getConfigById(SMART_SEARCH_CONFIG).getSmartSearchConfig();
				if(!MapUtils.isEmpty(smartSearchConfigMap)) {
					if(null != smartSearchConfigMap.get(SMART_SEARCH_API) && null != smartSearchConfigMap.get(SMART_SEARCH_ENABLED)) {
						isSmartSearchEnabled = (boolean) smartSearchConfigMap.get(SMART_SEARCH_ENABLED);
						smartSearchUrl = (String) smartSearchConfigMap.get(SMART_SEARCH_API);
					}
				}
		}
		return isSmartSearchEnabled;
	}
	/**
	 * @param inputJsonObj
	 * @return
	 */
	public static boolean requestFromSearch(BasicDBObject inputJsonObj) {
		boolean isRequestFromSearch = false;
		if(inputJsonObj.getString(SOLR_SEARCH_TEXT) != null) {
			isRequestFromSearch = true;
		}
		return isRequestFromSearch;
	}
	/**
	 * @param inputJsonObj
	 * @return
	 */
	private static BasicDBObject getResponseFromSmartSearch(BasicDBObject inputJsonObj) {
		HttpPost postRequest = null;
		BasicDBObject responseResult = null;
		try {
			if (null != qmaCache.getConfigById(SMART_SEARCH_CONFIG)) {
				Map<String, Object> smartSearchConfigMap = qmaCache.getConfigById(SMART_SEARCH_CONFIG).getSmartSearchConfig();
				if (!MapUtils.isEmpty(smartSearchConfigMap) && smartSearchConfigMap.get(SMART_SEARCH_API_TIMEOUT_LIMIT) != null) {
					logger.info("SmartSearchUtil :: smartSearchConfigMap size :: {}", smartSearchConfigMap.size());
					int timeoutLimitFromConfig = (int) smartSearchConfigMap.get(SMART_SEARCH_API_TIMEOUT_LIMIT);
					logger.info("SmartSearchUtil :: timeoutLimitFromConfig :: {}", timeoutLimitFromConfig);
					if (timeoutLimitFromConfig >= 0) {
						timeoutLimitMillis =  timeoutLimitFromConfig * 1000; // Converting seconds into milliseconds as setConnectTimeout accepts value in milliseconds
					}
				}
			}
			RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeoutLimitMillis).build();
			HttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(requestConfig).build();
			if (httpClient != null) {
				postRequest = new HttpPost(smartSearchUrl);
				BasicDBObject smartInput = new BasicDBObject();
				smartInput.put("text", inputJsonObj.get(SOLR_SEARCH_TEXT_KEY));
              	StringEntity input = new StringEntity(smartInput.toString(),"UTF-8"); //C170665-4908 - added UTF-8 encoding
				postRequest.setEntity(input);
				HttpResponse response = httpClient.execute(postRequest);
				logger.info("SmartSearchUtil :: HttpResponse status :: {}", response.getStatusLine().getStatusCode());
				if (response.getStatusLine().getStatusCode() == 200) {
					String responseEntity = EntityUtils.toString(response.getEntity());
					responseResult = BasicDBObject.parse(responseEntity);
				} 
			}
		} catch (ConnectTimeoutException e) {
			logger.error("ConnectTimeoutException occur for SmartSearch Continue with Simple search :: {}", e.getLocalizedMessage());
		} catch (Exception ex) {
			logger.error("Error in invokeURL(" + smartSearchUrl + ")", ex);
		} finally {
			if (postRequest != null) {
				try {
					postRequest.completed();
				} catch (Exception e) {
					logger.error("Error in getResponseFromSmartSearch while completing post request ", e);
				}
			}
		}
		return responseResult;
	}
	public static void main(String[] args) {
		String url = "http://sd-xxl9-fsio:5040/model/parse";
		//smartSearchUrl = url;
		BasicDBObject inputJsonObj = new BasicDBObject();
		inputJsonObj.put(SOLR_SEARCH_TEXT_KEY, TRADES);
		getSmartSearchCriteria(inputJsonObj);
	}
}
