/**
 * 
 */
package com.citi.icg.qma.common.server.dao;
import java.io.Serializable;

import dev.morphia.annotations.Embedded;

/**
 * 
 *
 */
@Embedded
public class TimeZone implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -154485063245056846L;
	private String timeZoneCode;
	private String timeZoneName;
	private String utcOffset;
	private String timeZone;
	/**
	 * @return the timeZoneCode
	 */
	public String getTimeZoneCode() {
		return timeZoneCode;
	}
	/**
	 * @param timeZoneCode the timeZoneCode to set
	 */
	public void setTimeZoneCode(String timeZoneCode) {
		this.timeZoneCode = timeZoneCode;
	}
	/**
	 * @return the timeZoneName
	 */
	public String getTimeZoneName() {
		return timeZoneName;
	}
	/**
	 * @param timeZoneName the timeZoneName to set
	 */
	public void setTimeZoneName(String timeZoneName) {
		this.timeZoneName = timeZoneName;
	}
	/**
	 * @return the utcOffset
	 */
	public String getUtcOffset() {
		return utcOffset;
	}
	/**
	 * @param utcOffset the utcOffset to set
	 */
	public void setUtcOffset(String utcOffset) {
		this.utcOffset = utcOffset;
	}
	/**
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return timeZone;
	}
	/**
	 * @param timeZone the timeZone to set
	 */
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	
	
}
