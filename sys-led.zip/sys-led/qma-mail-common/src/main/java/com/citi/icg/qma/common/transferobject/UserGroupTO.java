package com.citi.icg.qma.common.transferobject;

import java.io.Serializable;

public class UserGroupTO implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8161123669398493577L;
	private String text;
	private String value;
	private String email;
	private boolean isActive;
	private String id; 
	private String country;
	private String timeZone;
	
	// C170665-4331
	private String groupType;
	
	public UserGroupTO()
	{
	}
	
	public UserGroupTO(String text, String value)
	{
		super();
		this.text = text;
		this.value = value;
	}


	public UserGroupTO(String text, String value, boolean isActive)
	{
		super();
		this.text = text;
		this.value = value;
		this.isActive = isActive;
	}

	public UserGroupTO(String text, String value, String id)
	{
		super();
		this.text = text;
		this.value = value;
		this.id=id;
	}

	public String getText()
	{
		return text;
	}

	public void setText(String text)
	{
		this.text = text;
	}

	public String getValue()
	{
		return value;
	}

	public void setValue(String value)
	{
		this.value = value;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}
	
	public boolean isActive()
	{
		return isActive;
	}

	public void setActive(boolean isActive)
	{
		this.isActive = isActive;
	}

	//JIRA [C153176-172] - Ability to enter SOEID only to bring up email address
	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return timeZone;
	}

	/**
	 * @param timeZone the timeZone to set
	 */
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getGroupType() {
		return groupType;
	}

	public void setGroupType(String groupType) {
		this.groupType = groupType;
	}
}
