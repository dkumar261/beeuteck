package com.citi.icg.qma.dao;

public enum Action {
	NEW, REPLY
}
