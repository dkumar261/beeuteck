package com.citi.icg.qma.performance.utils.verification;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dev.morphia.Datastore;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.InquiryMessageRef;
import com.citi.icg.qma.dao.MessageSnapshot;

public class CompareMessages {

    private static final Logger logger = LoggerFactory.getLogger(CompareMessages.class);
	
	public static void main(String[] args) {
		
//		System.setProperty("", "C:/git_qma/storm_repos/qma-mail-processor/src/main/resources/mongodb.cacerts");
		try {
			int limit = 3000;
			long iterationNumber=0;
			SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
			format.setTimeZone(TimeZone.getTimeZone("UTC"));
			Date startDate = format.parse("2019/07/02");
			Date endDate = format.parse("2019/07/03");
			
			//syncSnapshotsIntoComparison(DBHelper.getMongoUAT(), startDate,endDate);
			//System.exit(0);		
			//while(true){
				long startTime=System.currentTimeMillis();				
				List<String> pendingMessageIdsForProdSync = messageIdsToBeSyncedFromProd(limit);
				List<String> pendingMessageIdsForUatSync = messageIdsToBeSyncedInUat(limit);
				if(pendingMessageIdsForProdSync.isEmpty() && pendingMessageIdsForUatSync.isEmpty()){
//					System.out.println("sleeping for "+sleepPeriodInMinutes+" minute ");
//					Thread.sleep(1000*60*sleepPeriodInMinutes);
					
					System.exit(0);					
				}else{
					syncComparisonDataWithProd(pendingMessageIdsForProdSync);
					syncComparisonDataWithUAT(pendingMessageIdsForUatSync);
				}
				iterationNumber++;
				
				
			//}
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
		    logger.warn("ParseException ", e);
		}
		
	}

	private static List<String> messageIdsToBeSyncedFromProd(int limit) {
		//get message ids for which prod sync is false
				Query<MessageComparison> q2 = DBHelper.getMongoUAT().find(MessageComparison.class)
						.field("oldSynced").equal(false)
						.field("detailedStatus").equal(MessageComparison.NOT_ATTEMPTED)
						.retrievedFields(true, "_id")
						.limit(limit);
				List<MessageComparison> messComparList=q2.asList();
				
				List<String> msgIdList=messComparList.stream().map(MessageComparison::getMessageId).collect(Collectors.toList());
			
				return msgIdList;
	}

	private static List<String> messageIdsToBeSyncedInUat(int limit) {
		Query<MessageComparison> q2 = DBHelper.getMongoUAT().find(MessageComparison.class)
				.field("newSynced").equal(false)
				.retrievedFields(true, "_id")
				.limit(limit);				
		List<MessageComparison> messComparList = q2.asList();
		
		List<String> pendingMessageIds = messComparList.stream().map(MessageComparison::getMessageId).collect(Collectors.toList());
				return pendingMessageIds;
	}

	private static void syncComparisonDataWithUAT(List<String> pendingMessageIdsForUatSync) {
		if (pendingMessageIdsForUatSync!=null && !pendingMessageIdsForUatSync.isEmpty()) {
			Datastore datastoreUAT = DBHelper.getMongoUAT();
			
//			List<InquiryMessageRef> inqMessageRefsUAT = getMessageRefsFromUat(datastoreUAT, pendingMessageIdsForUatSync);
//			Map<Long, String> inquiryIdToMsgIdMap = getInquiryIds(inqMessageRefsUAT);
			Map<Long, String> inquiryIdToMsgIdMap = getInquiryIdToMessageMap(pendingMessageIdsForUatSync);
			Set<Long> inquiryToBeFetched = inquiryIdToMsgIdMap.keySet();
			if (inquiryToBeFetched!=null && !inquiryToBeFetched.isEmpty()) {
				Map<Long, Inquiry> inquiryIdToDocumentMap = getInquiryForInquiryIDs(datastoreUAT, inquiryToBeFetched);
				Map<Long, List<Conversation>> inquiryIdToConversationsMap = getConversationForInquiryIDs(datastoreUAT, inquiryToBeFetched);
				
				for (Long currentInquiryId : inquiryToBeFetched) {
					if (currentInquiryId != null) {
						String currentMsgId = inquiryIdToMsgIdMap.get(currentInquiryId);
						Inquiry newInquiry = inquiryIdToDocumentMap.get(currentInquiryId);
						List<Conversation> newConversations = inquiryIdToConversationsMap.get(currentInquiryId);
						
						Query<MessageComparison> updateQuery = datastoreUAT.createQuery(MessageComparison.class).field("_id").equal(currentMsgId);
						UpdateOperations<MessageComparison> updateOperations = datastoreUAT.createUpdateOperations(MessageComparison.class)
								.set("newInquiry", newInquiry)
								.set("newConversations", newConversations)
								.set("newSynced",true);					
						datastoreUAT.update(updateQuery,updateOperations,false);
					}			
				}
			}			
			
		}		
	}

	/*private static List<InquiryMessageRef> getMessageRefsFromUat(Datastore datastoreUAT, List<String> messageIds) {
		List<InquiryMessageRef> allFoundRefs = new ArrayList<>();
		
		for (String msgId : messageIds) {
			Query<InquiryMessageRef> query = datastoreUAT.createQuery(InquiryMessageRef.class).field("referencesAudit").contains(msgId);
			List<InquiryMessageRef> refs = query.asList();
			if (refs != null && !refs.isEmpty()) {
				if (refs.size()> 1) {
					System.out.println("WARNING : more than one InquiryMsgRef["+refs.size()+"] found for " + msgId);
				} else {
					allFoundRefs.add(refs.get(0));
				}
			}
		}
		System.out.println("count of messageIDs = "+ messageIds.size());
		System.out.println("Count of InquiryMessageRef = " + allFoundRefs.size());
		return allFoundRefs;		
	}*/

	private static Map<Long, String> getInquiryIdToMessageMap(List<String> pendingMessageIdsForUatSync) {

		Query<MessageSnapshot> query  = DBHelper.getMongoUAT().createQuery(MessageSnapshot.class)
				 .field("_id").in(pendingMessageIdsForUatSync)
				 .retrievedFields(true, "_id", "inquiryId");
		List<MessageSnapshot> snapshots = query.asList();
		Map<Long, String> inqIdToMessageIdMap = new HashMap<>();
		if (inqIdToMessageIdMap != null) {
			for (MessageSnapshot messageSnapshot : snapshots) {
				Long inquiryId = messageSnapshot.getInquiryId();
				if (inquiryId!=null) {
					inqIdToMessageIdMap.put(inquiryId, messageSnapshot.getMessageId());
				}
			}
		}
		return inqIdToMessageIdMap;
	}

	private static void syncComparisonDataWithProd(List<String> pendingMessageIds) {
		if (pendingMessageIds!=null && !pendingMessageIds.isEmpty()) {
			Datastore datastorePROD = DBHelper.getMongoPROD();
			List<InquiryMessageRef> inqMessageRefsProd = getMessageRefs(datastorePROD, pendingMessageIds);
			Map<Long, String> inquiryIdToMsgIdMap = getInquiryIds(inqMessageRefsProd);
			
			Set<Long> inquiryToBeFetched = inquiryIdToMsgIdMap.keySet();
			Map<Long, Inquiry> inquiryIdToDocumentMap = getInquiryForInquiryIDs(datastorePROD, inquiryToBeFetched);
			Map<Long, List<Conversation>> inquiryIdToConversationsMap = getConversationForInquiryIDs(datastorePROD, inquiryToBeFetched);
			
			for (Long currentInquiryId : inquiryToBeFetched) {
				String currentMsgId = inquiryIdToMsgIdMap.get(currentInquiryId);
				Inquiry oldInquiry = inquiryIdToDocumentMap.get(currentInquiryId);
				List<Conversation> oldConversations = inquiryIdToConversationsMap.get(currentInquiryId);
				
				syncFromProdInUAT(DBHelper.getMongoUAT(),currentMsgId, oldInquiry, oldConversations);
			}
			
			//updating attempted failed status for remaining docs
			pendingMessageIds.removeAll(inquiryIdToMsgIdMap.values());
			
			Datastore datastoreUAT = DBHelper.getMongoUAT();
			Query<MessageComparison> updateQuery=datastoreUAT.createQuery(MessageComparison.class).field("_id").in(pendingMessageIds);
			UpdateOperations<MessageComparison> updateOperations=datastoreUAT.createUpdateOperations(MessageComparison.class)
					.set("detailedStatus", MessageComparison.ATTEMPTED_FAILED);
			datastoreUAT.update(updateQuery,updateOperations,false);
		}
	}

	private static void syncFromProdInUAT(Datastore mongoUAT,String currentMsgId, Inquiry oldInquiry, List<Conversation> oldConversations) {
		
		Query<MessageComparison> updateQuery=mongoUAT.createQuery(MessageComparison.class).field("_id").equal(currentMsgId);
		UpdateOperations<MessageComparison> updateOperations=mongoUAT.createUpdateOperations(MessageComparison.class)
				.set("oldInquiry", oldInquiry)
				.set("oldConversations", oldConversations)
				.set("oldSynced",true)
				.set("detailedStatus",MessageComparison.ATTEMPTED_SUCCESS);
		mongoUAT.update(updateQuery,updateOperations,false);
	}

	

	private static Map<Long, List<Conversation>> getConversationForInquiryIDs(Datastore datastore, Set<Long> inquiryToBeFetched) {
		Query<Conversation> query = datastore.createQuery(Conversation.class).field("inquiryId").in(inquiryToBeFetched);
		List<Conversation> conversations = query.asList();
		Map<Long, List<Conversation>> mapInquiryIdToConversationList = new HashMap<>();
		for (Conversation conversation : conversations) {
			Long inquiryId = conversation.getInquiryId();
			List<Conversation> convList = mapInquiryIdToConversationList.get(inquiryId);
			if (convList == null) {
				convList = new ArrayList<>();
			} 
			convList.add(conversation);
			mapInquiryIdToConversationList.put(inquiryId, convList);
		}
		return mapInquiryIdToConversationList;		
	}

	private static Map<Long, Inquiry> getInquiryForInquiryIDs(Datastore datastore, Set<Long> inquiryToBeFetched) {
		Query<Inquiry> query = datastore.createQuery(Inquiry.class).field("_id").in(inquiryToBeFetched);
		List<Inquiry> inquiryList = query.asList();
		Map<Long, Inquiry> inquiryIDToDocumentMap = new HashMap<>();
		for (Inquiry inquiry : inquiryList) {			
			inquiryIDToDocumentMap.put(inquiry.getId(), inquiry);
		}
		return inquiryIDToDocumentMap;		
	}

	private static Map<Long, String> getInquiryIds(List<InquiryMessageRef> refs) {
		Map<Long, String> inquiryIDToMsgIDMap = new HashMap<>();
		for (InquiryMessageRef ref : refs) {
			inquiryIDToMsgIDMap.put(ref.getInquiryId(), ref.getLatestMessageId());
		}
		return inquiryIDToMsgIDMap;
	}

	private static List<InquiryMessageRef> getMessageRefs(Datastore datastore, List<String> messageIds) {
		Query<InquiryMessageRef> query = datastore.createQuery(InquiryMessageRef.class).field("latestMessageId").in(messageIds);
		List<InquiryMessageRef> refs = query.asList();
		
//		refs.forEach(ref -> {
//			System.out.println("INQ: " + ref.getInquiryId() + " | MsgRefID: " + ref.getId() + " | MessageID: " + ref.getMessageId());
//		});
		
		return refs;
	}

	private static void syncSnapshotsIntoComparison(Datastore datastore, Date startDate, Date endDate) throws ParseException {
		
		
		/*int day = dateTime.getDayOfMonth();
		int month = dateTime.getMonthValue();
		int year = dateTime.getYear();		
		Instant startInstant = ZonedDateTime.of(year, month, day-1, 0, 0, 0, 0, ZoneOffset.UTC).toInstant();
		Date startDate = Date.from(startInstant);
		
		Date endDate = Date.from(ZonedDateTime.of(year, month, day, 0, 0, 0, 0, ZoneOffset.UTC).toInstant());*/
		
//		long countOfSnaps = datastore.createQuery(MessageSnapshot.class)
//				 			.disableValidation()				 
//				 			.field("events.0.time").greaterThanOrEq(startDate)
//				 			.field("events.0.time").lessThan(endDate)
//				 			.countAll();		
//		System.out.println("count of Snapshots for  = " + countOfSnaps);
		Query<MessageSnapshot> query  = datastore.createQuery(MessageSnapshot.class)
//												 .disableValidation()												 
												 .field("createDate").greaterThanOrEq(startDate)
												 .retrievedFields(true, "_id")								 		
												 .field("createDate").lessThan(endDate);
												 //.limit(limit)
												//.order("sentDate");
		
		
		List<MessageSnapshot> snapshotsList = query.asList();
		List<String> snapshotMessageIds = snapshotsList.stream().map(MessageSnapshot::getMessageId).collect(Collectors.toList());;
			
		createEntriesInComparison(DBHelper.getMongoUAT(), snapshotMessageIds);
		
	}
	
	private static void createEntriesInComparison(Datastore datastoreUAT, List<String> messageIdsInSnapshot) {
		if (messageIdsInSnapshot!=null && !messageIdsInSnapshot.isEmpty()) {
			//get messageids in not present in comparison		
			List<MessageComparison> existingDocs = datastoreUAT.find(MessageComparison.class).field("_id").in(messageIdsInSnapshot).asList();
			List<String> toBeRemovedExistingDocs=existingDocs.stream().map(MessageComparison::getMessageId).collect(Collectors.toList());
//			System.out.println("toBeRemovedExistingDocs size: "+toBeRemovedExistingDocs.size());
			messageIdsInSnapshot.removeAll(toBeRemovedExistingDocs);
//			System.out.println("messageIdsInSnapshot size after removal: "+messageIdsInSnapshot.size());
			
			if (messageIdsInSnapshot.isEmpty()) {
				
			} else {
				//create mess comparison for ones not present
				List<MessageComparison> toBeSavedList=new ArrayList<>();
				int batchSize = 200;
				int counter = 0;
				int total = messageIdsInSnapshot.size(); 
				
				for (String messageId : messageIdsInSnapshot) {
					
					MessageComparison mes = new MessageComparison();
					mes.setMessageId(messageId);
					mes.setNewSynced(false);
					mes.setOldSynced(false);
					mes.setDetailedStatus(MessageComparison.NOT_ATTEMPTED);
					toBeSavedList.add(mes);
					counter++;
					if (counter%batchSize==0) {
						//save entire toBeSavedList in DB
						datastoreUAT.save(toBeSavedList);
						
						toBeSavedList.clear();
					}
				}
				
				if (!toBeSavedList.isEmpty()) {
					datastoreUAT.save(toBeSavedList);
					
					toBeSavedList.clear();
				}
				
			}
		}		
	}
	/*private static void getParallelRecordStats(Datastore datastore){
        
        Date startDate=getDate("2019-06-11","yyyy-MM-dd");
        Date endDate=getDate("2019-06-12","yyyy-MM-dd");
        Query<MessageSnapshot> query   = datastore.createQuery(MessageSnapshot.class)
                    .disableValidation()                           
            .field("events.0.time").greaterThanOrEq(startDate)
           .field("events.0.time").lessThan(endDate);
        System.out.println("Query = " + query);
        System.out.println("count = "  +query.countAll());
  }
  private static Date getDate(String date, String format){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat (format);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("US/Eastern"));
      //  String dateStr ="01-10-2016"; 
        

        Date startDate = null;
		try {
			startDate = simpleDateFormat.parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
        return startDate;
  }*/

	
	
}
