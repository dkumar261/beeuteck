package com.citi.icg.qma.common.server.dao.persistence;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.core.util.MailCommonUtil;
import com.citi.icg.qma.common.server.dao.BaseEntity;
import com.citi.icg.qma.common.server.dao.CyberArkConnectionActivityLog;
import com.citi.icg.qma.common.server.dao.CyberArkConnectionActivityLog.ConnectionType;
import com.citi.icg.qma.config.MongoDBConfig;
import com.citi.icg.qma.config.QmaMailConfigLoader;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.MongoClientURI;
import com.mongodb.ReadPreference;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

import dev.morphia.Datastore;
import dev.morphia.Key;
import dev.morphia.Morphia;


/**
 * MongoDB providing the database connection.
 */
public class MongoDB
{
	private static Logger logger = LoggerFactory.getLogger(MongoDB.class);

	private static String DB_NAME = null;
	private static String BACKUP_DB_NAME = null;
	private static MongoDB INSTANCE = null;
	private static Datastore datastore;
	private static Datastore secondaryDatastore;
	private static MongoClient mongoClient;
	private static MongoClient secondaryMongoClient;
	private static final String CERT_FILE = System.getProperty("javax.net.ssl.trustStore");

	private MongoDB() {

		MongoDBConfig mongoDBConfig = QmaMailConfigLoader.getConfig().getMongoDBConfig();
		MongoDB.setDB_NAME(mongoDBConfig.getDbName());
		BACKUP_DB_NAME=mongoDBConfig.getBackupdbName();
		String clusterServers = mongoDBConfig.getMongoCluster();
		
		Builder builder = MailCommonUtil.configureMongoConnection(mongoDBConfig);
		
		/* Below map contains both credentials CyberArk Fetched as well as current static fetched from YAML file */
		Map<String, String> userNamePasswordMap=null;
		try {
			userNamePasswordMap = SecretServiceDAO.getInstance().getUserNamePasswordMap(mongoDBConfig,SecretServiceDAO.LIVE_DB_KEY, false);
		} catch (Exception e) {
			logger.error(SecretServiceDAO.CA_ERROR_LOG_PREFIX_KEY + "for component : " + mongoDBConfig.getServiceName(), e);
			SecretServiceDAO.getInstance().sendEmailToSupport(e.getMessage(),mongoDBConfig);
			System.exit(101);
		} 
		
		if(null != userNamePasswordMap && !userNamePasswordMap.isEmpty()) {
			
			String userName = userNamePasswordMap.get(SecretServiceDAO.CA_USER_NAME_KEY);
			String password = userNamePasswordMap.get(SecretServiceDAO.CA_PASSWORD_KEY);
			
			boolean isValidCyberArkConnectivity = false;
			/* 1. Check if CyberArk credentials are empty or not */
			if(StringUtils.isNotEmpty(userName) && StringUtils.isNotEmpty(password) && mongoDBConfig.isCyberArkEnabled()) {
				/* 2. if CyberArk credentials are not empty, connect using CyberArk credentials */
				connectToMongoDB(builder, clusterServers, userName, password,mongoDBConfig.getConnectionScheme());
				/* 3. Check if the connection is successful using CyberArk credentials */
				if( ! isValidCyberArkDBAuthetication(mongoDBConfig, ConnectionType.CYBERARK)) {
					/* 4. If connection is unsuccessful using CyberArk credentials  */
					logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"FAILED TO CONNECT TO DATABASE USING CYBERARK CREDENTIALS");
				} else {
					/* 4. Connection is successful using CyberArk credentials */
					logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"CONNECTED TO DATABASE USING CYBERARK CREDENTIALS");
					isValidCyberArkConnectivity = true;
				}
			} else {
				/* 2. CyberArk credentials are either empty or null or CyberArk connection usage is disabled */
				logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"CYBERARK DISABLE FOR CURRENT ENVIRONMENT OR CYBERARK CREDENTIALS ARE INVALID");
			}
			
			if(!isValidCyberArkConnectivity) {
				connectUsingNonCyberArkCredentials(builder, clusterServers, userNamePasswordMap,mongoDBConfig);
			}
			
		} else {
			String error = "UserName and password extracted is either 'empty' or 'null'. Please check urgently.";
			logger.warn(error);
			SecretServiceDAO.getInstance().sendEmailToSupport(error,mongoDBConfig);
			System.exit(101);
		}
	}


	/**
	 * This method connects to database using static credentials
	 * @param builder
	 * @param clusterServers
	 * @param userNamePasswordMap
	 * @throws Exception
	 */
	private void connectUsingNonCyberArkCredentials(Builder builder, String clusterServers,
			Map<String, String> userNamePasswordMap,MongoDBConfig mongoDBConfig) {
		/* 1. Set the current static credentials read from YAML files to connect and try connecting again */
		String userName = userNamePasswordMap.get(SecretServiceDAO.USER_NAME_KEY);
		String password = userNamePasswordMap.get(SecretServiceDAO.PASSWORD_KEY);
		if(StringUtils.isNotEmpty(userName) && StringUtils.isNotEmpty(password)) {
			/* 2. Connect to DB using static credentials */
			connectToMongoDB(builder, clusterServers, userName, password, mongoDBConfig.getConnectionScheme());
			/* 3. Check if connection is successful using static credentials read from YAML file */
			if(validateNonCyberArkDBAuthetication(mongoDBConfig,ConnectionType.NON_CYBERARK)) {
				/* 4. Connection is successful using credentials read from YAML file */
				logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"CONNECTED TO DATABASE USING NON CYBERARK CREDENTIALS");
			} else {
				/* 4. Failed to connect even with static credentials. Need to send an email to Support with failure details */
				String errorMessage = SecretServiceDAO.CA_LOG_PREFIX_KEY+"FAILED TO CONNECT TO DATABASE USING NON CYBERARK CREDENTIALS, PLEASE VALIDATE CONNECTION PARAMETERS";
				logger.info(errorMessage);
				SecretServiceDAO.getInstance().sendEmailToSupport(errorMessage,mongoDBConfig);
			}
		} else {
			/* 2. Static credentials are not found, send an email to support with module name and details. */
			String errorMessage = SecretServiceDAO.CA_LOG_PREFIX_KEY+"NON CYBERARK CREDENTIALS ARE EITHER 'null' or 'empty'";
			logger.info(errorMessage);
			SecretServiceDAO.getInstance().sendEmailToSupport(errorMessage,mongoDBConfig);
		}
	}


	/**
	 * This method validates if the connection to DB is successful or not.
	 * NOTE : As connection to MongoDB is handled internally by demon thread, hence we can not get the real time exception of connection failure while establishing the connection.
	 * 		  We can only get to know about failure in connection when we try to fetch something or perform any CRUD operation on database. Hence below code for adding one document
	 *        in DBConnectionAudit for logging. 
	 * 
	 * @return boolean
	 */
	private boolean isValidCyberArkDBAuthetication(MongoDBConfig config, ConnectionType type) {
		boolean isValidDBAuthentication = false;
		Datastore store = getDataStore();
		if( null != store ) {
			CyberArkConnectionActivityLog audit = new CyberArkConnectionActivityLog(config.getServiceName(), type, getCurrentHost(), new Date());
			Key<CyberArkConnectionActivityLog> returnObj = store.save(audit);
			if(null!= returnObj && null != returnObj.getId()) {
				logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"DATABASE AUTHENTICATION SUCCESSFUL USING : {} ", type);
				logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"NEW DB AUDIT CREATED WITH ID : '{}' IN COLLECTION : '{}'", returnObj.getId(), returnObj.getCollection());
				isValidDBAuthentication = true;
			}
		}
		return isValidDBAuthentication;
	}
	
	
	/**
	 * This method validate if database connection using non cyberark credentials is used
	 * @param config
	 * @param type
	 * @return boolean
	 */
	private boolean validateNonCyberArkDBAuthetication(MongoDBConfig config, ConnectionType type) {
		boolean isValidDBAuthentication = false;
		Datastore store = getDataStore();
		if( null != store ) {
			CyberArkConnectionActivityLog audit = new CyberArkConnectionActivityLog(config.getServiceName(), type, getCurrentHost(), new Date());
			Key<CyberArkConnectionActivityLog> returnObj = store.save(audit);
			if(null!= returnObj && null != returnObj.getId()) {
				logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"DATABASE AUTHENTICATION SUCCESSFUL USING : {}", type);
				logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"NEW DB AUDIT CREATED WITH ID : '{}' IN COLLECTION : '{}'", returnObj.getId(), returnObj.getCollection());
				isValidDBAuthentication = true;
			}
		}
		return isValidDBAuthentication;
	}

	
	/**
	 * This method provides current host details
	 * @return
	 */
	private String getCurrentHost() {
		String host = "";
		try {
			InetAddress hostNameAdd = InetAddress.getLocalHost();
			host = null != hostNameAdd ? hostNameAdd.toString() : "";
		} catch (UnknownHostException e) {
			logger.error("Exception while retrieveing current host :", e);
		}
		return host;
	}


	/**
	 * This method takes care of establishing a connection to Mongo Database
	 * @param builder
	 * @param clusterServers
	 * @param userName
	 * @param password
	 * @throws Exception
	 */
	private void connectToMongoDB(Builder builder, String clusterServers, String userName, String password, String connectionScheme){
		
		logger.info("Connecting to {}  db, at {}  with connection scheme {}", DB_NAME, clusterServers, connectionScheme);
		MongoClientURI mcURI = new MongoClientURI(connectionScheme + "://" + userName + ":" + password + "@" + clusterServers, builder);
		logger.info("Cacerts Path before connecting to mongo: {}", CERT_FILE);
		mongoClient = new MongoClient(mcURI);
		//mongoClient.setWriteConcern(WriteConcern.SAFE);
//			mongoClient.setWriteConcern(WriteConcern.NORMAL);
		Morphia morphia = new Morphia().mapPackage(BaseEntity.class.getPackage().getName());
		datastore = morphia.createDatastore(mongoClient, DB_NAME);
		BaseEntity.setMongoDatastore(datastore);

		secondaryMongoClient = new MongoClient(mcURI);
		//secondaryMongoClient.setWriteConcern(WriteConcern.SAFE);
//			mongoClient.setWriteConcern(WriteConcern.NORMAL);
		Morphia secondaryMorphia = new Morphia().mapPackage(BaseEntity.class.getPackage().getName());
		secondaryDatastore = secondaryMorphia.createDatastore(secondaryMongoClient, DB_NAME);
		//BaseEntity.setSecondaryMongoDatastore(secondaryDatastore);// TODO? CHECK IF REQUIRED, IN CASE OF MORPHIA

		logger.info("Connection to database '" + DB_NAME + "' initialized");

	}
	

	private void setConnectionPoolConfig(Builder builder)
	{
		try{
			String dbpoolSize=System.getProperty("dbPoolSize");
			logger.debug("In MongoDB.....Connection pool size configured = "+dbpoolSize);
			if(StringUtils.isNotBlank(dbpoolSize))
			{
				//	builder.connectionsPerHost(5000);

				//builder.threadsAllowedToBlockForConnectionMultiplier(Integer.parseInt(dbpoolSize));
			}
		}catch(Exception e){
			logger.error("In MongoDB.....Error in setConnectionPool", e);
		}
		
	}

	// Creating the mongo connection is expensive - we used a singleton for performance reasons
	// Both the underlying Java driver and Datastore are thread safe
	public static synchronized MongoDB instance()//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
	{
		if (INSTANCE == null) {
			INSTANCE = new MongoDB();

		}
		return INSTANCE;
	}

	// Use datastore for Morphia operations
	public Datastore getDataStore()
	{
		return datastore;
	}

	// get the DB for Mongo-JavaDriver operations.
	public DB getDB()
	{
		return mongoClient.getDB(DB_NAME);
	}
	public MongoDatabase getDatabase() {
		return mongoClient.getDatabase(DB_NAME);
	}
	public DB getSecondaryDB()
	{
		DB db = secondaryMongoClient.getDB(DB_NAME);
		
		db.setReadPreference(ReadPreference.secondaryPreferred());
		
		return db;
	}
	
	public DB getbackupDB()
	{
		DB db = mongoClient.getDB(BACKUP_DB_NAME);
		return db;
	}
	
	public void closeDB()
	{
		try
		{
			if (mongoClient != null)
			{
				logger.info("Start Closing MongoClient Connections");
				
				mongoClient.close();
				INSTANCE = null;
				datastore = null;
				
				logger.info("End Closing MongoClient Connections");

			}
		}
		catch (Exception e)
		{
			logger.error("Issue in closing MongoClient Connection "+e);

		}
	}

	public static String getDB_NAME() {
		return DB_NAME;
	}

	public static void setDB_NAME(String dB_NAME) {
		DB_NAME = dB_NAME;
	}
	
	public static void main(String[] args) {
		Datastore store = MongoDB.instance().getDataStore();
		
	}
	public static <T> MongoCursor<T> executeAggregatePipelineWithCursorReadPref(String collectionName,List<BasicDBObject> pipelines,ReadPreference readPref,boolean allowDiskUse,Class<T> clazz) {
		MongoDatabase db = MongoDB.instance().getDatabase();
		MongoCollection<Document> collection = db.getCollection(collectionName).withReadPreference(readPref);
		return collection.aggregate(pipelines,clazz).allowDiskUse(allowDiskUse).cursor();
	}
	
	
	public static <T> List<T> executeAggregatePipelineAndGetData(String collectionName,List<BasicDBObject> pipelines,ReadPreference readPref,boolean allowDiskUse,Class<T> clazz) {
		MongoDatabase db = MongoDB.instance().getDatabase();
		MongoCollection<Document> collection = db.getCollection(collectionName).withReadPreference(readPref);
		return collection.aggregate(pipelines,clazz).allowDiskUse(allowDiskUse).into(new ArrayList<>());
	}
	public static <T> MongoCursor<T> executeAggregatePipelineWithCursorReadPref(String collectionName,String strQuery,ReadPreference readPref,boolean allowDiskUse,Class<T> clazz) {
		List<BasicDBObject> pipelines = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(strQuery));
		MongoDatabase db = MongoDB.instance().getDatabase();
		MongoCollection<Document> collection = db.getCollection(collectionName).withReadPreference(readPref);
		return collection.aggregate(pipelines,clazz).allowDiskUse(allowDiskUse).cursor();
	}
	public static <T> MongoCursor<T> executeAggregatePipelineWithCursor(String collectionName,String strQuery,boolean allowDiskUse,Class<T> clazz) {
		List<BasicDBObject> pipelines = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(strQuery));
		MongoDatabase db = MongoDB.instance().getDatabase();
		MongoCollection<Document> collection = db.getCollection(collectionName);
		return collection.aggregate(pipelines,clazz).allowDiskUse(allowDiskUse).cursor();
	}
}
