package com.citi.icg.qma.common.server.utilCMCPayload;

public class Roles
{
    private String name;

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    @Override
    public String toString()
    {
        return "InputForCMC [name = "+name+"]";
    }
}
			
