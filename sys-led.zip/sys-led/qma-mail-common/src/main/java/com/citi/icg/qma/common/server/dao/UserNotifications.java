package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Entity;

@Entity(value = "UserNotifications", noClassnameStored = true)
public class UserNotifications extends BaseEntity{
	private String userId;
	private String type;
	private String action;
	private boolean isRead;
	private Long inquiryId;
	public UserNotifications()
	{
		super();
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public boolean isRead() {
		return isRead;
	}
	public void setRead(boolean isRead) {
		this.isRead = isRead;
	}
	public Long getInquiryId() {
		return inquiryId;
	}
	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}
}
