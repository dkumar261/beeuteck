/**
 * 
 */
package com.citi.icg.qma.common.server.util;

/**
 * 
 *
 */
public enum SuggestionStatusIndicator {

	O("O"), /* Amber */
	G("G"), /* Green */
	R("R"), /* Red */
	B("B"), /* Black */
	N("N"); /* No Indicator */

	private String indicatorValue;

	private SuggestionStatusIndicator(String indicatorValue) {
		this.indicatorValue = indicatorValue;
	}

	public String getName() {
		return indicatorValue;
	}

	public static SuggestionStatusIndicator getIndicatorFromString(String indicatorValue) {
		for (SuggestionStatusIndicator indicatorVal : SuggestionStatusIndicator.values()) {
			if (indicatorVal.indicatorValue.equalsIgnoreCase(indicatorValue)) {
				return indicatorVal;
			}
		}
		return null;
	}

	@Override
	public String toString() {
		return indicatorValue;
	}
}
