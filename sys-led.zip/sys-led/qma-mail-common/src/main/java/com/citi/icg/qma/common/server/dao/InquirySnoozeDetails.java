package com.citi.icg.qma.common.server.dao;

import java.util.Date;

import dev.morphia.annotations.Entity;

@Entity(value = "InquirySnoozeDetails", noClassnameStored = true)
public class InquirySnoozeDetails extends BaseEntity{

	private Long inquiryId;
	private String snoozeDuration;
	private Date snoozeStartTime;
	private Date snoozeEndTime;
	private String snoozedBy;
	private Long assignedGroupId;
	private String direction;
	private boolean processedFlag;
	
	public Long getInquiryId() {
		return inquiryId;
	}
	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}
	public String getSnoozeDuration() {
		return snoozeDuration;
	}
	public void setSnoozeDuration(String snoozeDuration) {
		this.snoozeDuration = snoozeDuration;
	}
	public Date getSnoozeStartTime() {
		return snoozeStartTime;
	}
	public void setSnoozeStartTime(Date snoozeStartTime) {
		this.snoozeStartTime = snoozeStartTime;
	}
	public Date getSnoozeEndTime() {
		return snoozeEndTime;
	}
	public void setSnoozeEndTime(Date snoozeEndTime) {
		this.snoozeEndTime = snoozeEndTime;
	}
	public String getSnoozedBy() {
		return snoozedBy;
	}
	public void setSnoozedBy(String snoozedBy) {
		this.snoozedBy = snoozedBy;
	}
	public Long getAssignedGroupId() {
		return assignedGroupId;
	}
	public void setAssignedGroupId(Long assignedGroupId) {
		this.assignedGroupId = assignedGroupId;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public boolean isProcessedFlag() {
		return processedFlag;
	}
	public void setProcessedFlag(boolean processedFlag) {
		this.processedFlag = processedFlag;
	}
}
