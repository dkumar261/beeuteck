package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Entity;

/**
 * This class is entity class for UIConsoleLog
 * 
 * 
 */
@Entity(value = "UIConsoleLog", noClassnameStored = true)
public class UIConsoleLog extends BaseEntity {
	
	private String userId;
	private String userLog;
	private String browser;
	private String os;
	private String requestReceivedHost;
	private String requesterHost;
	private String origin;

	public UIConsoleLog() {
		super();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserLog() {
		return userLog;
	}

	public void setUserLog(String userLog) {
		this.userLog = userLog;
	}

	/**
	 * @return the browser
	 */
	public String getBrowser() {
		return browser;
	}

	/**
	 * @param browser the browser to set
	 */
	public void setBrowser(String browser) {
		this.browser = browser;
	}

	/**
	 * @return the os
	 */
	public String getOs() {
		return os;
	}

	/**
	 * @param os the os to set
	 */
	public void setOs(String os) {
		this.os = os;
	}

	/**
	 * @return the requestReceivedHost
	 */
	public String getRequestReceivedHost() {
		return requestReceivedHost;
	}

	/**
	 * @param requestReceivedHost the requestReceivedHost to set
	 */
	public void setRequestReceivedHost(String requestReceivedHost) {
		this.requestReceivedHost = requestReceivedHost;
	}

	/**
	 * @return the requesterHost
	 */
	public String getRequesterHost() {
		return requesterHost;
	}

	/**
	 * @param requesterHost the requesterHost to set
	 */
	public void setRequesterHost(String requesterHost) {
		this.requesterHost = requesterHost;
	}

	/**
	 * @return the origin
	 */
	public String getOrigin() {
		return origin;
	}

	/**
	 * @param origin the origin to set
	 */
	public void setOrigin(String origin) {
		this.origin = origin;
	}
}
