package com.citi.icg.qma.common.contact.tcl.entity;

public class TCLContact {

	private String dateTime;
	private String taxid;
	private String sourceSystem;
	private String customerName;
	private String correntistaInd;
	private TCLCustomerContactDetails[] customerContactDetails;
	public TCLContact() {
		super();
		// Auto-generated constructor stub
	}
	public String getDateTime() {
		return dateTime;
	}
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	public String getTaxid() {
		return taxid;
	}
	public void setTaxid(String taxid) {
		this.taxid = taxid;
	}
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCorrentistaInd() {
		return correntistaInd;
	}
	public void setCorrentistaInd(String correntistaInd) {
		this.correntistaInd = correntistaInd;
	}
	public TCLCustomerContactDetails[] getCustomerContactDetails() {
		return customerContactDetails;
	}
	public void setCustomerContactDetails(TCLCustomerContactDetails[] customerContactDetails) {
		this.customerContactDetails = customerContactDetails;
	}
	
	
	
}
