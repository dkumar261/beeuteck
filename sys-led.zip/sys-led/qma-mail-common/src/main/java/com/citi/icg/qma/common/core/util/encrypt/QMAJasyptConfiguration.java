package com.citi.icg.qma.common.core.util.encrypt;

import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

public class QMAJasyptConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(QMAJasyptConfiguration.class);

    public static SimpleStringPBEConfig getSimpleStringPBEConfig() {
        final SimpleStringPBEConfig pbeConfig = new SimpleStringPBEConfig();
        try {
            pbeConfig.setPassword(getEncryptorKey()); //encryptor private key
            //Below algorithm is used as per "Approved Security Protocols and Cryptographic Algorithm Standards (ASPCAS)"
            pbeConfig.setAlgorithm("PBEWithMD5AndTripleDES");
            pbeConfig.setProviderName("SunJCE");
            pbeConfig.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
            pbeConfig.setKeyObtentionIterations("1000");
            pbeConfig.setPoolSize("2");
            pbeConfig.setStringOutputType("base64");
        } catch (Exception e) {
            logger.error("Unable to provide string encryptor config : ", e);
        }
        return pbeConfig;
    }

    private static String getEncryptorKey() {
        try {
            InputStream inputStream = QMAJasyptConfiguration.class.getClassLoader().getResourceAsStream("key.dat");
            String key = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))
                    .lines()
                    .collect(Collectors.joining("\n"));
            return key;
        } catch (Exception e) {
        }
		return null;
    }

    
    public StringEncryptor encryptor() {
        final PooledPBEStringEncryptor pbeStringEncryptor = new PooledPBEStringEncryptor();
        pbeStringEncryptor.setConfig(getSimpleStringPBEConfig());
        return pbeStringEncryptor;
    }
}

