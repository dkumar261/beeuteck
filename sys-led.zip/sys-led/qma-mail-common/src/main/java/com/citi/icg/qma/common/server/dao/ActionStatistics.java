package com.citi.icg.qma.common.server.dao;

import java.util.Date;
import java.util.List;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "ActionStatistics", noClassnameStored = true)
public class ActionStatistics
{
	@Id
	private String id;
	private Long inquiryId;
	private String userId;
	private String userName;
	private String emailId;
	private String domain;
	private Long groupId;
	private String groupName;
	private String isBulkAction;
	private String hasAttachment;
	private String isMakerChecker;
	private String isRoutingApplied;
	private String isMarkAsNonInquiry;
	private String isMarkForDeletion;
	private String hasBCC;
	private String hasReOpen;
	private String action;
	private Date actionTime;
	private Date createdTime;
	private Date lastModifiedTime;
	private Long responseTime;
	private Long resolveTimeSinceCreation;
	private Long resolveTimeSinceLastResponse;
	
	//C153176-154-ActionStatistics Improvements
	private String requestType;
	private	String assignedUserId;
	private String assignedUserName;
	private String subject;
	private List<ConversationRecipient> recipients;
	private Integer prevResponseCntr;//Previous Response counter before resolve
	private Integer noOfExternalRecipients;// Number of External recipients
	private Integer noOfInternalRecipients;//Number of Internal recipients
	
	private String inquirySource;
	private String inquirySubStatus;
	private String rootCause;
	private String processingRegion;
	private String tag;
	private String gpNum;
	private String gpName;
	private String gfcid; 	
	private String gfcName;
	
	//to capture client chaser response
	private String isResponseToClientChaser;
	private Long resolutionTimeInMinutes; // Total Resolve time consider working hours.
	private Long responseTimeInMinutes; // Total Response time consider working hours.
	
	private String resolveAllocation;
	
	public ActionStatistics()
	{
		super();
	}

	//Sonar Fix Constructor has 23 parameters, which is greater than 7 authorized..so removed this constructor as it is not called anywhere, also if required in future pls call getter/setter for the same
	
	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public Long getInquiryId() {
		return inquiryId;
	}


	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public String getDomain() {
		return domain;
	}


	public void setDomain(String domain) {
		this.domain = domain;
	}


	public Long getGroupId() {
		return groupId;
	}


	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}


	public String getGroupName() {
		return groupName;
	}


	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}


	public String getAction() {
		return action;
	}


	public void setAction(String action) {
		this.action = action;
	}


	public Date getActionTime() {
		return actionTime;
	}


	public void setActionTime(Date actionTime) {
		this.actionTime = actionTime;
	}


	public Date getCreatedTime() {
		return createdTime;
	}


	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}


	public Date getLastModifiedTime() {
		return lastModifiedTime;
	}


	public void setLastModifiedTime(Date lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}


	public Long getResponseTime() {
		return responseTime;
	}


	public void setResponseTime(Long responseTime) {
		this.responseTime = responseTime;
	}


	public Long getResolveTimeSinceCreation() {
		return resolveTimeSinceCreation;
	}


	public void setResolveTimeSinceCreation(Long resolveTimeSinceCreation) {
		this.resolveTimeSinceCreation = resolveTimeSinceCreation;
	}


	public Long getResolveTimeSinceLastResponse() {
		return resolveTimeSinceLastResponse;
	}


	public void setResolveTimeSinceLastResponse(Long resolveTimeSinceLastResponse) {
		this.resolveTimeSinceLastResponse = resolveTimeSinceLastResponse;
	}


	public String getIsBulkAction() {
		return isBulkAction;
	}


	public void setIsBulkAction(String isBulkAction) {
		this.isBulkAction = isBulkAction;
	}


	public String getHasAttachment() {
		return hasAttachment;
	}


	public void setHasAttachment(String hasAttachment) {
		this.hasAttachment = hasAttachment;
	}


	public String getIsMakerChecker() {
		return isMakerChecker;
	}


	public void setIsMakerChecker(String isMakerChecker) {
		this.isMakerChecker = isMakerChecker;
	}


	public String getIsRoutingApplied() {
		return isRoutingApplied;
	}


	public void setIsRoutingApplied(String isRoutingApplied) {
		this.isRoutingApplied = isRoutingApplied;
	}


	public String getIsMarkAsNonInquiry() {
		return isMarkAsNonInquiry;
	}


	public void setIsMarkAsNonInquiry(String isMarkAsNonInquiry) {
		this.isMarkAsNonInquiry = isMarkAsNonInquiry;
	}


	public String getIsMarkForDeletion() {
		return isMarkForDeletion;
	}


	public void setIsMarkForDeletion(String isMarkForDeletion) {
		this.isMarkForDeletion = isMarkForDeletion;
	}


	public String getHasBCC() {
		return hasBCC;
	}


	public void setHasBCC(String hasBCC) {
		this.hasBCC = hasBCC;
	}


	public String getHasReOpen() {
		return hasReOpen;
	}


	public void setHasReOpen(String hasReOpen) {
		this.hasReOpen = hasReOpen;
	}

	public String getRequestType()
	{
		return requestType;
	}

	public void setRequestType(String requestType)
	{
		this.requestType = requestType;
	}

	public String getAssignedUserId()
	{
		return assignedUserId;
	}

	public void setAssignedUserId(String assignedUserId)
	{
		this.assignedUserId = assignedUserId;
	}

	public String getAssignedUserName()
	{
		return assignedUserName;
	}

	public void setAssignedUserName(String assignedUserName)
	{
		this.assignedUserName = assignedUserName;
	}

	public String getSubject()
	{
		return subject;
	}

	public void setSubject(String subject)
	{
		this.subject = subject;
	}

	public List<ConversationRecipient> getRecipients()
	{
		return recipients;
	}

	public void setRecipients(List<ConversationRecipient> recipients)
	{
		this.recipients = recipients;
	}

	public Integer getPrevResponseCntr()
	{
		return prevResponseCntr;
	}

	public void setPrevResponseCntr(Integer prevResponseCntr)
	{
		this.prevResponseCntr = prevResponseCntr;
	}

	public Integer getNoOfExternalRecipients()
	{
		return noOfExternalRecipients;
	}

	public void setNoOfExternalRecipients(Integer noOfExternalRecipients)
	{
		this.noOfExternalRecipients = noOfExternalRecipients;
	}

	public Integer getNoOfInternalRecipients()
	{
		return noOfInternalRecipients;
	}

	public void setNoOfInternalRecipients(Integer noOfInternalRecipients)
	{
		this.noOfInternalRecipients = noOfInternalRecipients;
	}

	public String getInquirySource() {
		return inquirySource;
	}

	public void setInquirySource(String inquirySource) {
		this.inquirySource = inquirySource;
	}

	public String getProcessingRegion() {
		return processingRegion;
	}

	public void setProcessingRegion(String processingRegion) {
		this.processingRegion = processingRegion;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getGpNum() {
		return gpNum;
	}

	public void setGpNum(String gpNum) {
		this.gpNum = gpNum;
	}

	public String getGpName() {
		return gpName;
	}

	public void setGpName(String gpName) {
		this.gpName = gpName;
	}

	public String getGfcid() {
		return gfcid;
	}

	public void setGfcid(String gfcid) {
		this.gfcid = gfcid;
	}

	public String getGfcName() {
		return gfcName;
	}

	public void setGfcName(String gfcName) {
		this.gfcName = gfcName;
	}

	public String getIsResponseToClientChaser() {
		return isResponseToClientChaser;
	}

	public void setIsResponseToClientChaser(String isResponseToClientChaser) {
		this.isResponseToClientChaser = isResponseToClientChaser;
	}
	
	public Long getResolutionTimeInMinutes() {
		return resolutionTimeInMinutes;
	}

	public void setResolutionTimeInMinutes(Long resolutionTimeInMinutes) {
		this.resolutionTimeInMinutes = resolutionTimeInMinutes;
	}

	public Long getResponseTimeInMinutes() {
		return responseTimeInMinutes;
	}

	public void setResponseTimeInMinutes(Long responseTimeInMinutes) {
		this.responseTimeInMinutes = responseTimeInMinutes;
	}

	public String getResolveAllocation() {
		return resolveAllocation;
	}

	public void setResolveAllocation(String resolveAllocation) {
		this.resolveAllocation = resolveAllocation;
	}

	public String getInquirySubStatus() {
		return inquirySubStatus;
	}

	public void setInquirySubStatus(String inquirySubStatus) {
		this.inquirySubStatus = inquirySubStatus;
	}

	public String getRootCause() {
		return rootCause;
	}

	public void setRootCause(String rootCause) {
		this.rootCause = rootCause;
	}

}
