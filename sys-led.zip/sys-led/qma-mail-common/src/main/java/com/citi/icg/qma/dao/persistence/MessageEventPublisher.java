package com.citi.icg.qma.dao.persistence;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.Objects;

import com.citi.icg.qma.dao.ComponentEvent;
import com.citi.icg.qma.dao.ProcessingStatus;
import com.citi.icg.qma.exception.NonRecoverableDBException;

public class MessageEventPublisher {

	private String guid = null;
	private ComponentEvent event = null;
	private Throwable exception = null;
	private ProcessingStatus processingStatus;
	
	private MessageEventPublisher(String guid) {
		this.guid = guid;
		this.event = new ComponentEvent();
	}
	
	public static MessageEventPublisher info_(String guid) {
		return new MessageEventPublisher(guid).setLevel(ComponentEvent.LEVEL_INFO);				
	}
	
	public static MessageEventPublisher warn_(String guid, Throwable e) {
		return new MessageEventPublisher(guid).setLevel(ComponentEvent.LEVEL_WARN).setException(e);
	}

	public static MessageEventPublisher error_(String guid, Throwable e) {
		return new MessageEventPublisher(guid).setLevel(ComponentEvent.LEVEL_ERROR).setException(e);
	}
	
//	public String getMessageId() {
//		return guid;
//	}

	public MessageEventPublisher setComponentName(String componentName) {
		event.setComponent(componentName);
		return this;
	}
	
	public MessageEventPublisher setBlock(String blockName) {
		event.setBlock(blockName);
		return this;
	}
	
	public MessageEventPublisher setEventName(String eventName) {
		event.setEvent(eventName);
		return this;
	}

	public MessageEventPublisher setDetails(String details) {
		event.setDetails(details);
		return this;
	}
	
	private MessageEventPublisher setLevel(String level) {
		event.setLevel(level);
		return this;
	}
	
	private MessageEventPublisher setException(Throwable e) {
		this.exception = e;		
		return this;
	}
	
	public MessageEventPublisher setProcessingStatus(ProcessingStatus processingStatus) {
		this.processingStatus = processingStatus;		
		return this;
	}
	
	public ComponentEvent publish() throws NonRecoverableDBException {
		event.setTime(new Date());
		event.setHostname(System.getProperty("qma.current.machine.hostname", "value_not_initialized"));
		event.setDetails(generateDetails());
		event.setStatus(ComponentEvent.STATUS_ACTIVE);
		MessageSnapshotDAO.getInstance().updateSnapshot(this.event, this.processingStatus, this.guid);
		return event;	
	}
	
	public ComponentEvent publishDuplicateCheckEvents() throws NonRecoverableDBException {
		event.setTime(new Date());
		event.setHostname(System.getProperty("qma.current.machine.hostname", "value_not_initialized"));
		event.setDetails(generateDetails());
		event.setStatus(ComponentEvent.STATUS_ACTIVE);
		MessageSnapshotDAO.getInstance().updateSnapshotForDuplicateCheckEvents(this.event, this.processingStatus, this.guid);
		return event;	
	}

	private String generateDetails() {
		StringBuilder detailContent = new StringBuilder();
		if (!Objects.isNull(event.getDetails()) && !event.getDetails().isEmpty()) {
			detailContent.append(event.getDetails());
		}
		if (!Objects.isNull(this.exception)) {
			StringWriter sw = new StringWriter();
			this.exception.printStackTrace(new PrintWriter(sw));
			if (detailContent.length()>0) {
				detailContent.append(System.lineSeparator());
			}
			detailContent.append("------------------------ Exception Trace ---------------------------------")
						 .append(sw.toString())
						 .append("--------------------------------------------------------------------------");			
		}
		return detailContent.toString();
	}
}
