package com.citi.icg.qma.hazelcast.cache.client;


public class QMACacheFactory {
	
	private QMACacheFactory(){
		
	}
	
	public static QMACache getCache(){
		return HazelcastCache.getInstance();
	}

}