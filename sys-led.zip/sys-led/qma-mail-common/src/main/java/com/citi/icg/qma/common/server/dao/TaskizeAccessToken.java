package com.citi.icg.qma.common.server.dao;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import dev.morphia.annotations.Entity;

@Entity(value = "TaskizeAccessTokens", noClassnameStored = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TaskizeAccessToken extends BaseEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7479263938899730242L;

	private String username;
	
	@JsonProperty("access_token")
	private String accessTkn;
	
	@JsonProperty("refresh_token")
	private String refreshTkn;
	
	@JsonProperty("token_type")
	private String tokenType;
	
	@JsonProperty("expires_in")
	private int expiresIn;
	
	@JsonProperty("tokenExpiryDate")
	private Date tokenExpiryDate;

	public String getAccessToken() {
		return accessTkn;
	}

	public void setAccessToken(String accessToken) {
		this.accessTkn = accessToken;
	}
	
	public String getRefreshToken() {
		return refreshTkn;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshTkn = refreshToken;
	}

	public String getTokenType() {
		return tokenType;
	}

	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}

	public int getExpiresIn() {
		return expiresIn;
	}

	public void setExpiresIn(int expiresIn) {
		this.expiresIn = expiresIn;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Date getTokenExpiryDate() {
		return tokenExpiryDate;
	}

	public void setTokenExpiryDate(Date tokenExpiryDate) {
		this.tokenExpiryDate = tokenExpiryDate;
	}
}
