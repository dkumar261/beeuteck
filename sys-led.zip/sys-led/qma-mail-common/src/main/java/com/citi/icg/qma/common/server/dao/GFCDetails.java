package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "GFCDetails", noClassnameStored = true)
public class GFCDetails {

	@Id
	private String gfcId;
	private String gfpId;

	public GFCDetails() {
		super();
	}

	public GFCDetails(String gfcId, String gfpId) {
		super();
		this.gfcId = gfcId;
		this.gfpId = gfpId;
	}

	/**
	 * @return the gfcId
	 */
	public String getGfcId() {
		return gfcId;
	}

	/**
	 * @param gfcId the gfcId to set
	 */
	public void setGfcId(String gfcId) {
		this.gfcId = gfcId;
	}

	/**
	 * @return the gfpId
	 */
	public String getGfpId() {
		return gfpId;
	}

	/**
	 * @param gfpId the gfpId to set
	 */
	public void setGfpId(String gfpId) {
		this.gfpId = gfpId;
	}

}
