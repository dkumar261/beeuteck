package com.citi.icg.qma.common.server.utilCMCPayload;

import java.util.List;

public class InputForCMC
{
	private List<Clients> clients;

	private List<Soeids> soeids;

	private String managementId;

	private List<Roles> roles;

	private List<Affiliations> affiliations;

	private String sort;

	private List<Branches> branches;

	private String phone;

	private String includeDl;

	private String name;

	private String ids;

	private List<Links> links;

	private String srcSys;

	private List<Accounts> accounts;

	private String email;

	private String mnemonic;

	public List<Clients> getClients()
	{
		return clients;
	}

	public void setClients(List<Clients> clients)
	{
		this.clients = clients;
	}

	public List<Soeids> getSoeids()
	{
		return soeids;
	}

	public void setSoeids(List<Soeids> soeids)
	{
		this.soeids = soeids;
	}

	public String getManagementId()
	{
		return managementId;
	}

	public void setManagementId(String managementId)
	{
		this.managementId = managementId;
	}

	public List<Roles> getRoles()
	{
		return roles;
	}

	public void setRoles(List<Roles> roles)
	{
		this.roles = roles;
	}

	public List<Affiliations> getAffiliations()
	{
		return affiliations;
	}

	public void setAffiliations(List<Affiliations> affiliations)
	{
		this.affiliations = affiliations;
	}

	public String getSort()
	{
		return sort;
	}

	public void setSort(String sort)
	{
		this.sort = sort;
	}

	public List<Branches> getBranches()
	{
		return branches;
	}

	public void setBranches(List<Branches> branches)
	{
		this.branches = branches;
	}

	public String getPhone()
	{
		return phone;
	}

	public void setPhone(String phone)
	{
		this.phone = phone;
	}

	public String getIncludeDl()
	{
		return includeDl;
	}

	public void setIncludeDl(String includeDl)
	{
		this.includeDl = includeDl;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getIds()
	{
		return ids;
	}

	public void setIds(String ids)
	{
		this.ids = ids;
	}

	public List<Links> getLinks()
	{
		return links;
	}

	public void setLinks(List<Links> links)
	{
		this.links = links;
	}

	public String getSrcSys()
	{
		return srcSys;
	}

	public void setSrcSys(String srcSys)
	{
		this.srcSys = srcSys;
	}

	public List<Accounts> getAccounts()
	{
		return accounts;
	}

	public void setAccounts(List<Accounts> accounts)
	{
		this.accounts = accounts;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getMnemonic()
	{
		return mnemonic;
	}

	public void setMnemonic(String mnemonic)
	{
		this.mnemonic = mnemonic;
	}

	@Override
	public String toString()
	{
		return "InputForCMC [clients = " + clients + ", soeids = " + soeids + ", managementId = " + managementId + ", roles = " + roles + ", affiliations = " + affiliations + ", sort = " + sort
				+ ", branches = " + branches + ", phone = " + phone + ", includeDl = " + includeDl + ", name = " + name + ", ids = " + ids + ", links = " + links + ", srcSys = " + srcSys
				+ ", accounts = " + accounts + ", email = " + email + "]";
	}

}
