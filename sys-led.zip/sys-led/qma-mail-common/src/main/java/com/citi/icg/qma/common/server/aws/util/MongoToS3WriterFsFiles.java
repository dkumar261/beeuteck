package com.citi.icg.qma.common.server.aws.util;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.persistence.GenericDAO;
import com.citi.icg.qma.common.server.dao.persistence.MongoDB;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.ReadPreference;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;


public class MongoToS3WriterFsFiles {

	private static final Logger logger = LoggerFactory.getLogger(MongoToS3WriterFsFiles.class);
	private static DateFormat inputdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	private static final DB mongodb = MongoDB.instance().getDB();
	//private static DateFormat inputdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	static Long totalDocumentCount = (long) 0;
	static Long totalInquiresFetched = (long) 0;
	static List<String> totalMongoIds = new ArrayList<String>();
	static List<GridFSDBFile> queryFileList =null;

	static int S3ThreadCount = 10;
	static int S3InquiryBatchlimit = 1000;
	static int s3HandlingWeekOldData = 26;
	static Integer s3ArchiveNoOfDays = null;
	static Integer s3ArchiveNoOfDaysRange = null;
	private static List<Future<?>> futures;
	static List<GridFSDBFile> msgSnapFileList =null;
	static private long startTimeInMilli = 0;
	MongoToS3WriterFsFiles(){
		futures = new ArrayList<>();
	}
	
	public static void main(String[] args) {
	
		logger.info("testing......");
		run(args[0], args[1]);
	}

	
	public static void run(String startDateStr, String endDateStr)
	{
		
		try
		{
			String environment = System.getProperty("icg.env");			
			logger.info("START TIME :" + new Date());
			logger.info("Environment is :" + environment);
			startTimeInMilli = System.currentTimeMillis();
			loadThreadCountAndInquiryLimitFromDB();

			MongoToS3WriterFsFiles s3writer = new MongoToS3WriterFsFiles();

			// "12/03/2017 20:00:00" "12/04/2017 20:00:00"
			if (StringUtils.isNotBlank(startDateStr) && StringUtils.isNotBlank(endDateStr))
			{
				logger.info("input dates :" + startDateStr + "--" + endDateStr);
				s3writer.startJob(startDateStr, endDateStr,"");
			}
			else
			{
				s3writer.startJob("", "",environment);
			}

			logger.info("END TIME :" + new Date());

			logger.info("Msgsnap START TIME for Message Snap archieval:" + new Date());
			logger.info("Msgsnap Environment is :" + environment);
			startArchivalForMsgSnapshotRecords();
			logger.info("Msgsnap End TIME for Message Snap archieval:" + new Date());
			
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
			
		}

	}
	
	
	public void startJob(String startDateStr, String endDateStr, String environment)
	{
		try
		{
			Date startDate = null;
			Date endDate = null;

			// input date format is MM/dd/yyyy
			if (StringUtils.isNotBlank(startDateStr) && StringUtils.isNotBlank(endDateStr))
			{
				startDate = inputdf.parse(startDateStr);
				endDate = inputdf.parse(endDateStr);
			}
			else
			{
				if(!"prod".equals(environment))
				{
					Calendar cal = Calendar.getInstance();
					cal.add(Calendar.MONTH, -1);
					startDate = cal.getTime();
	
					cal = Calendar.getInstance();
					endDate = cal.getTime();
					
				}else
				{
					//anything older than given months (here six months (24 weeks) till now), move to S3.
					
					// one month older data will be moved to s3 from given month.
					// currentDay is May-13th and monthOldDatatoBeMoved = 6 then May-13 to Jun-13 data will be moved to s3.
					
					int daysOldDatatoBeMovedEndDate  = s3HandlingWeekOldData * 7 ; // multiply by 7 (7days a week)
					if(null != s3ArchiveNoOfDays && s3ArchiveNoOfDays > 0) {
						logger.info("Config found s3ArchiveNoOfDays:{}",s3ArchiveNoOfDays);
						daysOldDatatoBeMovedEndDate = s3ArchiveNoOfDays;
					}
					int daysOldDatatoBeMovedStartDate = daysOldDatatoBeMovedEndDate + 30; // 30 days
					if(null != s3ArchiveNoOfDaysRange && s3ArchiveNoOfDaysRange > 0 ){
						logger.info("Config found s3ArchiveNoOfDaysRange:{}",s3ArchiveNoOfDaysRange);
						daysOldDatatoBeMovedStartDate = daysOldDatatoBeMovedEndDate +s3ArchiveNoOfDaysRange; 
					}
					
					Calendar cal = Calendar.getInstance();
					cal.add(Calendar.DATE, - daysOldDatatoBeMovedStartDate); 
					startDate = cal.getTime();
	
					cal = Calendar.getInstance();
					cal.add(Calendar.DATE, - daysOldDatatoBeMovedEndDate); 
					endDate = cal.getTime();
				}

			}

			logger.info("in MongoToS3LoadFsFiles startJob - startDate:" + startDate + ", endDate:" + endDate);
			fetchDocIdsforNonS3MigratedData(startDate, endDate);

			logger.info("MongoToS3LoadFsFiles is completed successfully");
			createExecutorServiceTofetchDocId();

		}
		catch (Exception e)
		{
			logger.error("Error in MongoToS3Writer, will shutdown now : ", e);
		}
	}

	
	/**
	 * @param startDate
	 * @param endDate
	 * 
	 * Load fs files based on uploadDate
	 */
	private void fetchDocIdsforNonS3MigratedData(Date startDate,Date endDate) 
	{

		GridFS fs = new GridFS(mongodb);
		BasicDBObject findQuery = new BasicDBObject("uploadDate", new BasicDBObject("$gte", startDate).append("$lt", endDate));		
		
		logger.info("fetchDocIdsforNonS3MigratedData - find Query based on UploadDate :" + findQuery);
		
		
		//List<GridFSDBFile> 
		queryFileList = fs.find(findQuery);
		
		/*if(null!= queryFileList && queryFileList.listIterator() != null)
		{
			ListIterator<GridFSDBFile> gridFsIter = queryFileList.listIterator();
		
			while(gridFsIter.hasNext())
			{
				GridFSDBFile fsFile = gridFsIter.next();
				logger.info(fsFile.getFilename()+"---------"+fsFile.getId() +"------" + fsFile.getUploadDate() );
				totalDocs ++;
				totalMongoIds.add(""+ fsFile.getId());
			}
			
		}*/
		
		logger.info("****Total Docs pulled for migration are**** and should match count stats in last: " + queryFileList.size());
		
	}
	
	private static void createExecutorServiceTofetchDocId()
	{

		logger.info("inside createExecutorServiceTofetchDocId.......... inquirylimit :" + S3InquiryBatchlimit + ", threadCount:" + S3ThreadCount);
		ExecutorService service = Executors.newFixedThreadPool(S3ThreadCount);
		//List<List<String>> chunkList = getChunkList(totalMongoIds, S3InquiryBatchlimit);
		List<List<GridFSDBFile>> chunkList = getChunkList(queryFileList, S3InquiryBatchlimit);

		logger.info("inside createExecutorServiceTofetchDocId numberOf Chunks :" + chunkList.size());

		for (List<GridFSDBFile> mongoIdsChunkList : chunkList)
		{
			try
			{
				MongoToS3WriterHelperFsFiles runnable = new MongoToS3WriterHelperFsFiles(mongoIdsChunkList);
				Future<?> future = service.submit(runnable);
				futures.add(future);
			}
			catch (IOException e)
			{
				logger.error("inside createExecutorServiceTofetchDocId:" + e);
				
			}
		}

		shutDownExecutorService(service, "MongoToS3LoadFsFiles");

		logger.info(" End of createExecutorServiceTofetchDocId..........");
	}

	private static void shutDownExecutorService(ExecutorService threadService, String jobName) {
		try {
			threadService.shutdown();
			/* Below code will wait till all threads completes execution */
			if (!threadService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS)) {
				threadService.shutdown();
			}
		} catch (InterruptedException e) {
			logger.error(jobName+": Exception while awaiting termination of threads :", e);
			threadService.shutdownNow();
			Thread.currentThread().interrupt();
		} finally {
			if (!futures.isEmpty()) {
				for (Future<?> future : futures) {
					try {
						/* Below line of code waits till execution of thread finishes */
						future.get();
					} catch (InterruptedException | ExecutionException e) {
						logger.error("Exception while reading response from future :", e);
					}
				}
				futures.clear();
				long diff = System.currentTimeMillis() - startTimeInMilli;
				logger.info("Total time taken for multi-threaded for execution of "+jobName+" is : " + (diff) / (1000 * 60) + " mins ["
						+ diff / 1000 + " secs]");
				logger.info("Released all resources.");
				
			}
		}
	}
	/**
	 * Returns List of the List argument passed to this function with size = chunkSize
	 * 
	 * @param largeList
	 *            input list to be portioned
	 * @param chunkSize
	 *            maximum size of each partition
	 * @param <T>
	 *            Generic type of the List
	 * @return A list of Lists which is portioned from the original list
	 */
	private static <T> List<List<T>> getChunkList1(List<T> largeList, int chunkSize, Date dt)
	{
		
		List<List<T>> chunkList = new ArrayList<>();
		for (int i = 0; i < largeList.size(); i += chunkSize)
		{
			chunkList.add(largeList.subList(i, i + chunkSize >= largeList.size() ? largeList.size() : i + chunkSize));
		}
		return chunkList;
	}
	
	private static <T> List<List<T>> getChunkList(List<T> largeList, int chunkSize)
	{
		List<List<T>> chunkList = new ArrayList<>();
		for (int i = 0; i < largeList.size(); i += chunkSize)
		{
			chunkList.add(largeList.subList(i, i + chunkSize >= largeList.size() ? largeList.size() : i + chunkSize));
		}
		return chunkList;
	}
	private static void loadThreadCountAndInquiryLimitFromDB()
	{

		GenericDAO genricDAO = new GenericDAO();

		Config configData = genricDAO.getConfigDetailsForId("S3Migration");
		if (configData != null)
		{
			S3ThreadCount = configData.getS3ThreadCount();
			S3InquiryBatchlimit = configData.getS3InquiryBatchlimit();
			s3HandlingWeekOldData = configData.getS3HandlingWeekOldData();
			s3ArchiveNoOfDays = configData.getS3ArchiveNoOfDays();
			s3ArchiveNoOfDaysRange = configData.getS3ArchiveNoOfDaysRange();
		}

		logger.info(" loadThreadCountAndInquiryLimitFromDB from config threadCount :" + S3ThreadCount + " , inquirylimit :" + S3InquiryBatchlimit + ", s3HandlingWeekOldData :" + s3HandlingWeekOldData);

	}

	/**
	 * @param startDate
	 * @param endDate
	 * 
	 * Load fs files based on uploadDate
	 */
	private static void startArchivalForMsgSnapshotRecords() 
	{
		try{
			
			logger.info("Msgsnap startArchivalForMsgSnapshotRecords");
			//Start for MSgSnapshot
			GenericDAO genricDAO = new GenericDAO();
			Config msgSnapConfig = genricDAO.getConfigDetailsForId("msgSnapshotConfig");
			Integer msgSnapshotPurgeLimitInDays=3;
			if (Objects.nonNull(msgSnapConfig) && StringUtils.isNotEmpty(msgSnapConfig.getMsgSnapshotPurgeLimitInDays())) {
				msgSnapshotPurgeLimitInDays = Integer.parseInt(msgSnapConfig.getMsgSnapshotPurgeLimitInDays());
			}
			
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, - msgSnapshotPurgeLimitInDays); 
			Date objStoreMoveEndDate = cal.getTime();
			
			
			//get documents ids
			String projectionQuery = "{ _id : 1, processingStatus : 1, sentDate :1}";
			DBObject projection = BasicDBObject.parse(projectionQuery);
			BasicDBObject query = new BasicDBObject("createDate", new BasicDBObject("$lt", objStoreMoveEndDate));
			query.append("gridFSId", new BasicDBObject("$exists",true));
			query.append("storageType", new BasicDBObject("$exists", false));
			query.append("processingStatus", "PROCESSED");
			
			DBCursor cursorDoc = mongodb.getCollection("MessageSnapshot").find(query, projection).setReadPreference(ReadPreference.secondary());
			
			Set<String> totalMIds = new HashSet<String>();
			while (cursorDoc.hasNext())
			{
				DBObject msgObject = cursorDoc.next();

				if (msgObject != null)
				{
					String mid = (String) msgObject.get("_id");
					totalMIds.add(mid);
				}

			}

			logger.info("Msgsnap TOTAL Number of Msgs  :" + totalMIds.size());
			if(!totalMIds.isEmpty() && Objects.nonNull(msgSnapConfig)){
				createExecutorServiceForSnapshot(convertSetToList(totalMIds),msgSnapConfig);
			}
			
		}catch(Exception e){
			logger.error("Msgsnap Error in MongoToS3Writer Snapshot, will shutdown now : ", e);
		}
		
	}
	// Generic function to convert set to list 
    public static <T> List<T> convertSetToList(Set<T> set) 
    { 
        // create a list from Set 
        return set 
  
            // Create stream from the Set 
            .stream() 
  
            // Convert the set to list and collect it 
            .collect(Collectors.toList()); 
    } 
	
    private static void createExecutorServiceForSnapshot(List<String> mIds, Config msgSnapConfig)
	{

		logger.info("Msgsnap..........batchlimit :" + msgSnapConfig.getMsgBatchlimit() + ", threadCount:" + msgSnapConfig.getMsgThreadCount());
		ExecutorService service = Executors.newFixedThreadPool(msgSnapConfig.getMsgThreadCount());
		List<List<String>> chunkList = getChunkList(mIds,  msgSnapConfig.getMsgBatchlimit());

		logger.info("Msgsnap createExecutorServiceTofetchDocId numberOf Chunks :" + chunkList.size());

		for (List<String> midChunkList : chunkList)
		{
			try
			{
				MongoToS3SnapshotWriter runnable = new MongoToS3SnapshotWriter(midChunkList);
				Future<?> future = service.submit(runnable);
				futures.add(future);
			}
			catch (IOException e)
			{
				logger.error("Msgsnap createExecutorServiceTofetchDocId:" + e);
							}
		}

		shutDownExecutorService(service, "Msgsnap");

		logger.info("Msgsnap End of createExecutorServiceTofetchDocId..........");
	}
    
    private static void createExecutorServiceForSnapshotPurge(List<String> mIds)
	{

		logger.info("MongoFilePurger.......... inquirylimit :" + S3InquiryBatchlimit + ", threadCount:" + S3ThreadCount);
		ExecutorService service = Executors.newFixedThreadPool(S3ThreadCount);
		List<List<String>> chunkList = getChunkList(mIds, S3InquiryBatchlimit);

		logger.info("MongoFilePurger createExecutorServiceForSnapshotPurge numberOf Chunks :" + chunkList.size());

		for (List<String> midChunkList : chunkList)
		{
			try
			{
				MongoFilePurger runnable = new MongoFilePurger(midChunkList);
				Future<?> future = service.submit(runnable);
				futures.add(future);
			}
			catch (IOException e)
			{
				logger.error("MongoFilePurger createExecutorServiceForSnapshotPurge:" + e);
				
			}
		}

		shutDownExecutorService(service, "MongoFilePurger");

		logger.info("MongoFilePurger End of createExecutorServiceForSnapshotPurge..........");
	}
	
    private static void purgeSnapshotRecords() 
	{
    	
    	//1. Purge All Archived records from Snapshot file store
    	try{
    		//get documents ids
			String projectionQuery = "{ _id : 1, processingStatus : 1, sentDate :1}";
			DBObject projection = BasicDBObject.parse(projectionQuery);
			BasicDBObject query = new BasicDBObject("gridFSId", new BasicDBObject("$exists",true));
					
				//	("createDate", new BasicDBObject("$gte", objStoreMoveStartDate).append("$lt", objStoreMoveEndDate));
			query.append("gridFSId", new BasicDBObject("$exists",true));
			query.append("storageType","A");
			
			DBCursor cursorDoc = mongodb.getCollection("MessageSnapshot").find(query, projection).setReadPreference(ReadPreference.secondary());
			
			Set<String> totalMIds = new HashSet<String>();
			while (cursorDoc.hasNext())
			{
				DBObject msgObject = cursorDoc.next();

				if (msgObject != null)
				{
					String mid = (String) msgObject.get("_id");
					totalMIds.add(mid);
				}

			}

			logger.info("Msgsnap purgeSnapshotRecords TOTAL Number of Msgs  :" + totalMIds.size());
			if(!totalMIds.isEmpty()){
				createExecutorServiceForSnapshotPurge(convertSetToList(totalMIds));
			}
			
		}catch(Exception e){
			logger.error("Msgsnap Error in purgeSnapshotRecords, will shutdown now : ", e);
		}
		
	}

}
