/**
 * 
 */
package com.citi.icg.qma.common.server.util;

import static java.time.temporal.TemporalAdjusters.lastDayOfYear;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonArray;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.Country;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;

/**
 * 
 *
 */
public class ISGCloudHolidaysUtil {

	private static final Logger logger = LoggerFactory.getLogger(ISGCloudHolidaysUtil.class);
	public static final String ISG_CLOUD_HOLIDAYS_CONFIG = "isgCloudHolidaysConfig";
	private static final Object SEARCH_PARAM = "searchParam";
	private static final String UTF_8_CHARACTERSET = "UTF-8";
	private static final String ERRORCODE = "ERRORCODE";
	private static final String BEARER = "Bearer ";
	private static final String AUTHORIZATION = "Authorization";
	private static final String GET = "GET";
	private static final Object API_URL = "apiUrl";
	private static final String PROJECTION = "projection";
	public static final String CALENDAR_TYPE_CODE = "CalendarTypeCode";
	public static final String CALENDAR_DAY_NAME = "CalendarDayName";
	private static final String ROW_LIMIT = "rowLimit";
	public static final String CALENDAR_DATE = "CalendarDate";
	public static final String COUNTRY_CODE = "CountryCode";
	public static final String HOLIDAY_DATE = "holidayDate";
	public static final String HOLIDAY_DESC = "holidayDesc";
	public static final String TYPE = "type";
	public static final String ID = "_id";
	private static final Object BACK_DATE = "backDate";	
	public static Integer PAGE_SIZE = 200;
	private static String responseToken = null;
	private static final String WS_TOKEN_URL = "accessTokenUrl";
	private static final String COUNTRY_CODE_IN_URL = "specifyCountryCodeInUrl";
	private ISGCloudHolidaysUtil() {
	}

	/**
	 * Method used to get Holidays from ISG cloud
	 * @param nextPageUrl
	 * @param logger 
	 * @return
	 * @throws CommunicatorException
	 * @throws IOException
	 */
	public static String getISGCloudHolidays(String nextPageUrl)	throws CommunicatorException, IOException {
		String apiUrl = nextPageUrl;
		String apiResponse = null;
		final String tokenUrl;
		boolean countryCodeRequiredInUrl = false;
		List<String> countryList = null;
		if (null == apiUrl) {

			Config configData = QMACacheFactory.getCache().getConfigById(ISG_CLOUD_HOLIDAYS_CONFIG);
			Map<String, Object> isgCloudHolidayConfigMap = configData.getIsgCloudHolidaysConfig();

			countryCodeRequiredInUrl = (boolean) isgCloudHolidayConfigMap.get(COUNTRY_CODE_IN_URL);
			tokenUrl = (String) isgCloudHolidayConfigMap.get(WS_TOKEN_URL);
			String holidayApiUrl = (String) isgCloudHolidayConfigMap.get(API_URL);
			if (StringUtils.isNotBlank(tokenUrl))
				responseToken = ISGCloudRestServiceClient.getAuthorizationToken(isgCloudHolidayConfigMap);
			//apiUrl = buildUrl(configData);
			if (countryCodeRequiredInUrl) {
				countryList = getCountryList();
			}
			if (CollectionUtils.isNotEmpty(countryList)) {
				JsonArray jsonArray = new JsonArray();
				countryList.forEach(country -> {
					jsonArray.addAll(
							HolidaySync.convertJsonToAnotherJsonArray(buildApiResponse(holidayApiUrl, tokenUrl, country)));
				});
				if (!jsonArray.isEmpty()) {
					apiResponse = String.valueOf(HolidaySync.convertJsonArrayToObject(jsonArray));
				}
			} else {
				apiResponse = buildApiResponse(apiUrl, tokenUrl, null);
				apiResponse = String.valueOf(HolidaySync.convertJsonToAnotherJsonObject(apiResponse));
				logger.info("Response : " +apiResponse);
			}
		} else {
			//This is Citi code
			Map<String, String> authorizationHeader = new HashMap<>();
			if (null != responseToken && !responseToken.contains(ERRORCODE)) {
				authorizationHeader.put(AUTHORIZATION, BEARER + responseToken);
				apiResponse = ISGCloudRestServiceClient.doRequest(apiUrl, GET, null, authorizationHeader);
			}
		}
		logger.info("Response : " +apiResponse);
		return apiResponse;
	}

	private static String buildApiResponse(String apiUrl, String tokenUrl, String countryCode) {
		String apiResponse = null;
		Map<String, String> authorizationHeader = new HashMap<>();
		apiUrl = buildHolidayUrl(apiUrl, countryCode);
		logger.info("Api url for the countryCode {} is {}",countryCode, apiUrl );
		try {
			if (null != responseToken && !responseToken.contains(ERRORCODE)) {
				authorizationHeader.put(AUTHORIZATION, BEARER + responseToken);
				apiResponse = ISGCloudRestServiceClient.doRequest(apiUrl, GET, null, authorizationHeader);
			} else if (responseToken == null && StringUtils.isEmpty(tokenUrl)) {
				apiResponse = ISGCloudRestServiceClient.doRequest(apiUrl, GET, null, null);
			}
		} catch (Exception e) {
			logger.error("Unable to connect to Holiday calendar API. Exception :" + e.getMessage());
		}
		//Conversion to a list of response
		logger.info("Api response: " + apiResponse);
		return apiResponse;
	}

	private static String buildHolidayUrl(String apiUrl, String countryCode) {
		if (StringUtils.isNotEmpty(apiUrl) && apiUrl.contains("?countryCode") && StringUtils.isNotEmpty(countryCode)) {
			apiUrl = apiUrl.replace("?countryCode", countryCode);
		}
		return apiUrl;
	}


	/**
	 * Method used to build URL for the given configuration
	 * @param configData 
	 * @param isgCloudHolidayConfigMap
	 * @param logger 
	 * @return
	 */
	private static String buildUrl(Config configData) {
		Map<String, Object> isgCloudHolidayConfigMap = configData.getIsgCloudHolidaysConfig();
		String apiUrl = (String) isgCloudHolidayConfigMap.get(API_URL);
		@SuppressWarnings("unchecked")
		Map<String, String> searcParamMap = (Map<String, String>) isgCloudHolidayConfigMap.get(SEARCH_PARAM);
		@SuppressWarnings("unchecked")
		List<BasicDBList> projection = (List<BasicDBList>) isgCloudHolidayConfigMap.get(PROJECTION);
		String calendarTypeCode = searcParamMap.get(CALENDAR_TYPE_CODE);
		String isFirstTimeUpload= configData.getIsgIsFirstTimeUpload();
		Date startDate;
		
		if(("Y").equalsIgnoreCase(isFirstTimeUpload)) {
			startDate =  (Date) isgCloudHolidayConfigMap.get(BACK_DATE);
		} else {
			startDate = new Date(); 
		}
		LocalDate now = LocalDate.now();
		LocalDate date = now.with(lastDayOfYear());
		Date endDate = Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant());
		logger.info("Fetching holidays data between date range :" +"["+startDate+"] - "+"["+endDate+"]");
		String calendarDayName = searcParamMap.get(CALENDAR_DAY_NAME);
		String rowLimit = (String) isgCloudHolidayConfigMap.get(ROW_LIMIT);
		PAGE_SIZE = Integer.parseInt(rowLimit);
		List<String> countryList = getCountryList(); 
		StringBuilder searchJson = new StringBuilder();
		searchJson.append("{\"$and\":[{\""+COUNTRY_CODE+"\":{\"$in\":"+countryList+"}},{\""+CALENDAR_TYPE_CODE+"\":\"" + calendarTypeCode + "\"},"
				+ "{\""+CALENDAR_DATE+"\":{\"$gte\":{\"$date\":\"" + getDate(startDate) + "\"}}},"
				+ "{\""+CALENDAR_DATE+"\":{\"$lte\":{\"$date\":\"" + getDate(endDate) + "\"}}},"
				+ "{\"$or\":[{\"HolidayCode\":{\"$ne\":\"712\"}}," + "{\""+CALENDAR_DAY_NAME+"\":{\"$ne\":\""
				+ calendarDayName + "\"}}]}]}");
		StringBuilder finalProjection  = new StringBuilder();
		finalProjection.append("&projection={");
		for (int i = 0; i < projection.size(); i++) {
			String lastProjection;
			if (i == projection.size() - 1) {
				lastProjection = "\":1";
			} else {
				lastProjection = "\":1,";
			}
			finalProjection.append("\"" + projection.get(i) + lastProjection);
		}
		logger.info("ISG CLOUD URL:"+apiUrl+searchJson+finalProjection+ "}&sort={\""+CALENDAR_DATE+"\":1}&limit="+rowLimit);
		String encodedQuery = apiUrl + getUrlEncodedString(searchJson.append(finalProjection)+ "}&sort={\""+CALENDAR_DATE+"\":1}&limit="+rowLimit);
		apiUrl = encodedQuery.replace("%24", "$").replace("%3A", ":").replace("%2C", ",").replace("%26", "&").replace("%3D", "=").replace("+", "");
		return apiUrl;
	}

	/**
	 * @param startDate
	 * @return
	 */
	private static String getDate(Date startDate) {
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		String dateRet =  df1.format(startDate);
		return dateRet+"Z";
	}

	/**
	 * @return
	 */
	private static List<String> getCountryList() {
		//CacheDAO cacheDAO = CacheDAO.getInstance();
		List<Country> countryList = QMACacheFactory.getCache().getConfigById("countryList").getCountryList();
		List<String> countryCodeList = new ArrayList<>();
		for (Country country : countryList) {
			countryCodeList.add(country.getCountryCode());
		}
		return countryCodeList;
	}

	/**
	 * @param inputString
	 * @param logger 
	 * @return
	 */
	public static String getUrlEncodedString(String inputString) {
		String outputString = "";
		try {
			outputString = URLEncoder.encode(inputString, UTF_8_CHARACTERSET);
		} catch (UnsupportedEncodingException e) {
			logger.error("Unable to encode provided String :" + e);
			outputString = inputString;
		}
		return outputString;
	}
	
}
