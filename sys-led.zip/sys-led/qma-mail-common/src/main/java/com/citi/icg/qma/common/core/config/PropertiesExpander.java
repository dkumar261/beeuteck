package com.citi.icg.qma.common.core.config;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PropertiesExpander
{
	private static final Pattern VARIABLE_EXPANSION_PATTERN = Pattern.compile("\\$\\{([^\\{\\}]+)\\}");
	
	private final Properties properties = new Properties();
	private final Stack expansionStack = new Stack();
	
	public PropertiesExpander(Properties properties)
	{
		this.properties.putAll(properties);
	}
	
	public Properties expandProperties()
	{
		expansionStack.clear();
		
		Iterator<Object> iter = new ArrayList<Object>(properties.keySet()).iterator();

		while (iter.hasNext())
		{
			expandProperty((String)iter.next());
		}
		
		return properties;
	}

	private void expandProperty(String key)
	{
		if(expansionStack.contains(key))
		{
			String references = key;
			
			while(!expansionStack.isEmpty())// Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
			{
				references = expansionStack.pop() + " -> " + references;
			}
			
			throw new ConfigurationException("circular reference detected: " + references);
		}

		String value = properties.getProperty(key, System.getProperty(key));
		
		if(value==null)
		{
			throw new ConfigurationException("property [" + expansionStack.pop() + "] references undefined property [" + key + "]");
		}
		
		while(true)
		{
			Matcher matcher = VARIABLE_EXPANSION_PATTERN.matcher(value);

			if(!matcher.find(0))
			{
				break;
			}

			expansionStack.push(key);
			expandProperty(matcher.group(1));
			expansionStack.pop();
			
			value = matcher.replaceFirst(properties.getProperty(matcher.group(1)));
		}
		
		if(value.matches(".*\\$\\{.*"))
		{
			throw new ConfigurationException("property [" + key + "] has a missing closing bracket");
		}
		
		properties.setProperty(key, value);
	}
}
