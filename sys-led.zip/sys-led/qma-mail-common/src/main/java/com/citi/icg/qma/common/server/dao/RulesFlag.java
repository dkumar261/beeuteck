package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Embedded;

@Embedded
public class RulesFlag
{
	private Boolean markForDeletion;
	private Boolean markAsNonInquiry;
	private String ruleType ;
	
	public RulesFlag()
	{
		
	}
	
	public RulesFlag(Boolean markForDeletion, Boolean markAsNonInquiry)
	{
		this.markAsNonInquiry = markAsNonInquiry;
		this.markForDeletion = markForDeletion;
	}
	
	public Boolean getMarkForDeletion()
	{
		return markForDeletion;
	}
	public void setMarkForDeletion(Boolean markForDeletion)
	{
		this.markForDeletion = markForDeletion;
	}
	public Boolean getMarkAsNonInquiry()
	{
		return markAsNonInquiry;
	}
	public void setMarkAsNonInquiry(Boolean markAsNonInquiry)
	{
		this.markAsNonInquiry = markAsNonInquiry;
	}

	public String getRuleType() {
		return ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}
	
	
}
