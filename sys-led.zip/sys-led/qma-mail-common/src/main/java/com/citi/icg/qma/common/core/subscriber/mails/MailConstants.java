package com.citi.icg.qma.common.core.subscriber.mails;

public interface MailConstants//changes from class to interface as all psf variables....
{
	// POP3
	public static final String POP3_PROTOCOL = "pop3";
	public static final String POP3_SSL_FACTORY = "mail.pop3.socketFactory.class";
	public static final String POP3_FALL_BACK = "mail.pop3.socketFactory.fallback";
	public static final String POP3_PORT = "mail.pop3.socketFactory.port";
	
	public static final Integer MONGO_RETRY_MAX_COUNT = 10;
	public static final Integer MONGO_RETRY_WAIT_INTERVAL_IN_MS = 10;
}