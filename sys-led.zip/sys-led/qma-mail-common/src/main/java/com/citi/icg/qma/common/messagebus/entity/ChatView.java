package com.citi.icg.qma.common.messagebus.entity;

import java.util.ArrayList;
import java.util.List;

public class ChatView {
	private Inquiry inquiry;
	private List<Conversation> conversationList=new ArrayList<Conversation>();
	public ChatView() {
		super();
	}
	public Inquiry getInquiry() {
		return inquiry;
	}
	public void setInquiry(Inquiry inquiry) {
		this.inquiry = inquiry;
	}
	public List<Conversation> getConversationList() {
		return conversationList;
	}
	public void setConversationList(List<Conversation> conversationList) {
		this.conversationList = conversationList;
	}
	

}
