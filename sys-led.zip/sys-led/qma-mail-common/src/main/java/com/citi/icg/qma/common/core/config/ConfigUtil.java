package com.citi.icg.qma.common.core.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.Environment;

/**
 * Configuration file lookup and load utility functions.
 */
public final class ConfigUtil
{
	private static final String EXT_XML = ".xml";
	public static final String CONFIG_FILE_PROPRTY_PREFIX = "icg.configuration.";
	public static final String NAME_PREFIX = "configuration";
	public static final String DELIMETER = "-";
	private static final String DEFAULT_BLANK_CONFIGFILE = "XXXXX";
	/** Log. */
	//private static Logger logger = GenericUtil.getLogger();//Sonar Fix -- Standard outputs should not be used directly to log anything
	private static final Logger logger = LoggerFactory.getLogger(ConfigUtil.class);
	/**
	 * Retrieves an instance of an IcgConfiguration. It attempts to load the
	 * configuration data from the file as specified, first as a resource from a
	 * WAR/JAR, and if that fails, directly from the file system.
	 */

	private ConfigUtil(){
		//As this class is Util, so added making private constructor.
		//Sonar Fix -- Utility classes should not have public constructors 
	}
	
	public static <T extends Configuration> T getInstance(Class<T> configurationClass) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{

		try
		{
			Assert.notNull(configurationClass, "Configuration Class");

			// 1. instantiate
			T instance = ClassUtil.getInstance(configurationClass);

			// 2. load config
			// Get the configuration name.
			String name = instance.getConfigurationName();
			return getInstance(instance, name);
		}
		catch (Exception e)
		{
			throw new CommunicatorException(e.getMessage(), e); // Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
		}

	}

	public static <T extends Configuration> T getInstance(T instance, String name) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			String configFileName = getConfigFileName(name.trim());
			InputStream configStream = getConfigFileStream(configFileName);//Sonar fix - remove the useless assignements
			// If Env specific file is not present. Look for the file with
			// the
			// same name.
			if (configStream == null)
			{
				configStream = getConfigFileStream(name.trim() + EXT_XML);
			}
			if (configStream == null)
			{
				configStream = getConfigFileStream(DEFAULT_BLANK_CONFIGFILE);
			}

			
			instance.load(configStream);

			// 3. Validate
			validateEntries(instance);

			// 3. register with configuration manager
			ConfigurationManager.register(name, instance);

			return instance;
		}
		catch (Exception e)// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
		{
			throw new CommunicatorException(e.getMessage(), e);
		}
	}

	public static InputStream getConfigFileStream(String configFileName) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one ..also remove useless return..
	{
		Assert.notNullOrBlank(configFileName, "Configuration Name");

		logger.info("Loading config file : {} from file {} ",configFileName, configFileName);

		// If did not load as resource, then load directly from file
		// system.
		InputStream configStream = null;
		try
		{
			// Check as a direct filename.
			File file = new File(configFileName);
			if (file.exists())
			{
				configStream = new FileInputStream(file);
			}
			// check if the file exists in the application config dir if
			// defined.
			if (configStream == null)
			{
				String applicationConfigDir = AppConfiguration.getApplicationConfigDir();
				if (StringUtils.isNotBlank(applicationConfigDir))
				{
					file = new File(applicationConfigDir, configFileName);
					if (file.exists())
					{
						configStream = new FileInputStream(file);
					}
				}
			}
			// look up in the class path.
			if (configStream == null)
			{
				configStream = ConfigUtil.class.getClassLoader().getResourceAsStream(configFileName);
			}
		}
		catch (FileNotFoundException e)
		{
			logger.warn(ConfigUtil.class + ", " + e.getMessage(), e);
		}
		return configStream;
	}

	private static <T extends Configuration> void validateEntries(T instance) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		// Check that the required entries exist in the configuration.
		List<String> missingEntries = instance.getMissingEntries();
		if (missingEntries != null && !missingEntries.isEmpty())
		{
			StringBuffer buffer = new StringBuffer();
			buffer.append("Configuration '" + instance.getConfigurationName() + "' is missing the following required entries: ");
			for (int ctr = 0; ctr < missingEntries.size(); ctr++)
			{
				if (ctr > 0)
				{
					buffer.append(", ");
				}

				buffer.append("\"");
				buffer.append(missingEntries.get(ctr));
				buffer.append("\"");
			}

			throw new CommunicatorException(buffer.toString());// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
		}
	}

	private static String getConfigFileName(String configName) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Assert.notNullOrBlank(configName, "Configuration Name");
		String filename ;
		// C153176-376 Exception Analysis and Improved StackTracing
		//  use default config file name - format=configuration-name-env.xml - configuration-xm-uat.xml
		filename = NAME_PREFIX + DELIMETER + configName + DELIMETER + Environment.getEnvironment() + EXT_XML;
		logger.info("USE default filename: {}", filename);
		return filename;
	}

	public static String getConfigName(Class<?> configClass)
	{
		String name = configClass.getSimpleName().toLowerCase();
		if (name.startsWith("icg"))
		{
			name = name.substring("icg".length());
		}
		if (name.endsWith("config"))
		{
			name = name.substring(0, name.length() - "config".length());
		}
		if (name.endsWith(NAME_PREFIX))
		{
			name = name.substring(0, name.length() - NAME_PREFIX.length());
		}
		return name;
	}

}
