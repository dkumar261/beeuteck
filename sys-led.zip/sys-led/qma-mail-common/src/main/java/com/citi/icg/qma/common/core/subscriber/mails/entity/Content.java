package com.citi.icg.qma.common.core.subscriber.mails.entity;

import java.io.IOException;
import java.io.InputStream;

import com.citi.icg.qma.common.core.subscriber.mails.ContentType;
import com.citi.icg.qma.common.core.util.MailUtil;

public class Content
{


	private ContentType type;
	private String value;

	public Content(ContentType type, InputStream inputStream) throws IOException
	{
		this.type = type;

		StringBuilder strContents = new StringBuilder();// Sonar Fix -- Use StringBuilder instead of StringBuffer
		byte[] contents = new byte[1024];

		int bytesRead = 0;
		while ((bytesRead = inputStream.read(contents)) != -1)
		{
			strContents.append(new String(contents, 0, bytesRead));
		}

		value = MailUtil.getUTFEncodedString(strContents.toString());
	}

	public Content(ContentType type, String value)
	{
		this.type = type;
		this.value = MailUtil.getUTFEncodedString(value);
	}
	
	//default constructor , getters and setters added for kryo deserialisation
	public Content(){
		
	}
	
	public ContentType getType()
	{
		return type;
	}

	public String getValue()
	{
		return value;
	}
	public void setType(ContentType type) {
		this.type = type;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
