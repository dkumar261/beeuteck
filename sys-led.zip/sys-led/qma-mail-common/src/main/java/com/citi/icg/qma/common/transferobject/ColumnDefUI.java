package com.citi.icg.qma.common.transferobject;

import java.io.Serializable;
import java.util.Map;

public class ColumnDefUI implements Serializable
{
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -974067483207889028L;
	private String id;
	private int place;
	private String label;
	private String type;
	private String plugin;
	private Map plugin_config;
	private String input;
	private Map values;
	//private String optgroup;///[C153176-160] changes for saved search with work flow Criteria query
	private String operators[];
	private String disableFilter;
	private String displayType;

	public ColumnDefUI()
	{
		super();
	}

	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getPlace() {
		return place;
	}

	public void setPlace(int place) {
		this.place = place;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPlugin() {
		return plugin;
	}

	public void setPlugin(String plugin) {
		this.plugin = plugin;
	}

	public Map getPlugin_config() {
		return plugin_config;
	}

	public void setPlugin_config(Map plugin_config) {
		this.plugin_config = plugin_config;
	}

	public String getInput() {
		return input;
	}

	public void setInput(String input) {
		this.input = input;
	}

	public Map getValues() {
		return values;
	}

	public void setValues(Map values) {
		this.values = values;
	}

	public String[] getOperators() {
		return operators;
	}

	public void setOperators(String[] operators) {
		this.operators = operators;
	}

	public String getDisableFilter()
	{
		return disableFilter;
	}

	public void setDisableFilter(String disableFilter)
	{
		this.disableFilter = disableFilter;
	}

	public String getDisplayType()
	{
		return displayType;
	}

	public void setDisplayType(String displayType)
	{
		this.displayType = displayType;
	}

	/*public String getOptgroup()
	{
		return optgroup;
	}

	public void setOptgroup(String optgroup)
	{
		this.optgroup = optgroup;
	}*/

}
