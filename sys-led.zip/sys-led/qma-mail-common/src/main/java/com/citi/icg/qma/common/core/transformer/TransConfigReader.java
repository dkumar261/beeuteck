package com.citi.icg.qma.common.core.transformer;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.config.ConfigReader;
import com.citi.icg.qma.common.core.config.ConfigurationException;

public class TransConfigReader implements ConfigReader<TransformationConfig>
{
	private static final String NAME = "name";
    private static final String SOURCE = "source";
    private static final String DESTINATION = "destination";
    private static final String TRANSFORMER = "transformer";
    private static final String PARAM = "param0";
    private static final String DELIMITER = ".";
    

    //Sonar fix -- use override annotation on overridden method
  	@Override
  	public TransformationConfig readConfiguration(Object input) throws ConfigurationException
	{
		TransformationConfig transConfig = new TransformationConfig();
		Logger log = LoggerFactory.getLogger(getClass());
        
        String transformerName = null;
        String sourceClassName = null;
        String destinationClassName = null;
        String transformerClassName = null;
        String paramClass = null;
        String paramName = null;
        
        Properties config = System.getProperties();
        for (int index=0; index < Integer.MAX_VALUE; index++)
        {
            if (config.getProperty(SOURCE + index) == null && config.getProperty(NAME + index) == null)
            {
                break;
            }
            transformerName = config.getProperty(NAME + index);
            sourceClassName = config.getProperty(SOURCE + index);
            destinationClassName = config.getProperty(DESTINATION + index);
            transformerClassName = config.getProperty(TRANSFORMER + index);
            paramName = TRANSFORMER + index + DELIMITER + PARAM;
                      
        	paramClass = config.getProperty(paramName);
        	if (transformerName != null)
        	{
        		log.debug("{} : {} : {}",transformerName , transformerClassName ,paramClass);
        	}
        	else
        	{
        		log.debug("{} : {} : {} : {}",sourceClassName, destinationClassName ,transformerClassName ,paramClass);
        	}
            
            transConfig.addTransformationConfigEntry(new TransformationConfigEntry(transformerName,
            																	sourceClassName, 
            																	destinationClassName, 
            																	transformerClassName, 
            																	paramClass));
        }
		return transConfig;
	}

}
