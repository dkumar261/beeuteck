package com.citi.icg.qma.dao;

public class ExchangeItemEventTO {

	private ExchangeEventType exchEventType;
	private String exchItemId;
	private String exchOldItemId;
	private String exchFolder;
	private String exchFolderId;
	private String exchOldFolder;
	private String exchOldFolderId;
	private Boolean isRead;
	private Boolean isImportant;
	
	public ExchangeItemEventTO(ExchangeEventType eventType, String itemId, String exchFolderId) {
		this.exchEventType = eventType;
		this.exchItemId = itemId;
		this.exchFolderId = exchFolderId;
	}
	
	public ExchangeEventType getExchEventType() {
		return exchEventType;
	}
	public void setExchEventType(ExchangeEventType exchEventType) {
		this.exchEventType = exchEventType;
	}
	public String getExchItemId() {
		return exchItemId;
	}
	public void setExchItemId(String exchItemId) {
		this.exchItemId = exchItemId;
	}
	public String getExchOldItemId() {
		return exchOldItemId;
	}
	public void setExchOldItemId(String exchOldItemId) {
		this.exchOldItemId = exchOldItemId;
	}
	public String getExchFolder() {
		return exchFolder;
	}
	public void setExchFolder(String exchFolder) {
		this.exchFolder = exchFolder;
	}
	public String getExchFolderId() {
		return exchFolderId;
	}
	public void setExchFolderId(String exchFolderId) {
		this.exchFolderId = exchFolderId;
	}
	public String getExchOldFolder() {
		return exchOldFolder;
	}
	public void setExchOldFolder(String exchOldFolder) {
		this.exchOldFolder = exchOldFolder;
	}
	public String getExchOldFolderId() {
		return exchOldFolderId;
	}
	public void setExchOldFolderId(String exchOldFolderId) {
		this.exchOldFolderId = exchOldFolderId;
	}
	
	public Boolean getIsRead() {
		return isRead;
	}

	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}

	public Boolean getIsImportant() {
		return isImportant;
	}

	public void setIsImportant(Boolean isImportant) {
		this.isImportant = isImportant;
	}

	public void updateMessageSnapshotWithEventDetails(MessageSnapshot snapshot) {
		snapshot.setExchEventType(exchEventType);
		snapshot.setExchItemId(exchItemId);
		snapshot.setExchOldItemId(exchOldItemId);
		snapshot.setExchFolderId(exchFolderId);
		snapshot.setExchFolder(exchFolder);
		snapshot.setExchOldFolderId(exchOldFolderId);
		snapshot.setExchOldFolder(exchOldFolder);
		snapshot.setIsRead(isRead);
		snapshot.setIsImportant(isImportant);
	}
	
}
