package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import dev.morphia.annotations.Entity;

@Entity(value = "OrganizationAuditTrail", noClassnameStored = true)
public class OrganizationAuditTrail extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 3597182568844166L;
	private String orgName;
	private List<OrgAuditTrailRequestType> requestTypes;
	private List<OrgAuditTrailHighLevelRequestTypeMapping> highLevelRequestTypeMapping;
	private List<OrgAuditTrailRootCause> rootCause;
	private List<OrgAuditTrailRequestTypeRootCauseMapping> requestTypeRootCauseMapping;
	private String maker;
	private List<String> checker;
	private OrgPreferences preferences;
	private String workflowStatus;
	private String comment;
	private String enableOrgLevelMetaData;
	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public List<OrgAuditTrailRequestType> getRequestTypes() {
		return requestTypes;
	}

	public void setRequestTypes(List<OrgAuditTrailRequestType> requestTypes) {
		this.requestTypes = requestTypes;
	}

	public List<OrgAuditTrailHighLevelRequestTypeMapping> getHighLevelRequestTypeMapping() {
		return highLevelRequestTypeMapping;
	}

	public void setHighLevelRequestTypeMapping(
			List<OrgAuditTrailHighLevelRequestTypeMapping> highLevelRequestTypeMapping) {
		this.highLevelRequestTypeMapping = highLevelRequestTypeMapping;
	}

	public List<OrgAuditTrailRootCause> getRootCause() {
		return rootCause;
	}

	public void setRootCause(List<OrgAuditTrailRootCause> rootCause) {
		this.rootCause = rootCause;
	}

	public List<OrgAuditTrailRequestTypeRootCauseMapping> getRequestTypeRootCauseMapping() {
		return requestTypeRootCauseMapping;
	}

	public void setRequestTypeRootCauseMapping(List<OrgAuditTrailRequestTypeRootCauseMapping> requestTypeRootCauseMapping) {
		this.requestTypeRootCauseMapping = requestTypeRootCauseMapping;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public List<String> getChecker() {
		return checker;
	}

	public void setChecker(List<String> checker) {
		this.checker = checker;
	}

	public OrgPreferences getPreferences() {
		return preferences;
	}

	public void setPreferences(OrgPreferences preferences) {
		this.preferences = preferences;
	}

	public String getWorkflowStatus() {
		return workflowStatus;
	}

	public void setWorkflowStatus(String workflowStatus) {
		this.workflowStatus = workflowStatus;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getEnableOrgLevelMetaData() {
		return enableOrgLevelMetaData;
	}

	public void setEnableOrgLevelMetaData(String enableOrgLevelMetaData) {
		this.enableOrgLevelMetaData = enableOrgLevelMetaData;
	}
	
}
