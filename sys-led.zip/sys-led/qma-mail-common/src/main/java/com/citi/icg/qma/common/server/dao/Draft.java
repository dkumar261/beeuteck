package com.citi.icg.qma.common.server.dao;
import java.util.Date;
import java.util.List;

import dev.morphia.annotations.Entity;

@Entity(value = "Draft", noClassnameStored = true)
public class Draft extends Conversation
{
	private String userId;//Login User Id
	private String requestType;
	private Long refConvCount;//Ref Conversation Number. It will be used to show user warning message when user tries to convert old draft to Inquiry conversation.
	private String attchFlag;//Set to Y when there is an attachment.
	private String processingRegion;
	private String rootCause;
	private Long queryCount;
	private String inquirySource;
	private String inquirySubStatus;
	private String gfpid;
	private String gfcid;
	private String gfpName;
	private String gfcName;
	
	// C170665-5 | Sk Account Number and Branch which getting populated from AMCAR
	private String skAccountNo;
	private String branch;
		
	private List<Note> userNotes;
	private Date scheduleForLater;
	private boolean makerCheckerRqd;
	private Long fromGroupId;
	private Long linkedInquiryId;
	private String draftInquiryAction;
	
	public Draft()
	{
		super();
	}
	
	public String getUserId()
	{
		return userId;
	}
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	public String getRequestType()
	{
		return requestType;
	}
	public void setRequestType(String requestType)
	{
		this.requestType = requestType;
	}
	public Long getRefConvCount()
	{
		return refConvCount;
	}
	public void setRefConvCount(Long refConvCount)
	{
		this.refConvCount = refConvCount;
	}
	public String getAttchFlag()
	{
		return attchFlag;
	}
	public void setAttchFlag(String attchFlag)
	{
		this.attchFlag = attchFlag;
	}

	public String getProcessingRegion() {
		return processingRegion;
	}

	public void setProcessingRegion(String processingRegion) {
		this.processingRegion = processingRegion;
	}
	
	public String getRootCause() {
		return rootCause;
	}

	public void setRootCause(String rootCause) {
		this.rootCause = rootCause;
	}

	public Long getQueryCount() {
		return queryCount;
	}

	public void setQueryCount(Long queryCount) {
		this.queryCount = queryCount;
	}

	public String getInquirySource()
	{
		return inquirySource;
	}

	public void setInquirySource(String inquirySource)
	{
		this.inquirySource = inquirySource;
	}

	public String getGfpid()
	{
		return gfpid;
	}

	public void setGfpid(String gfpid)
	{
		this.gfpid = gfpid;
	}

	public String getGfcid()
	{
		return gfcid;
	}

	public void setGfcid(String gfcid)
	{
		this.gfcid = gfcid;
	}

	public String getGfpName()
	{
		return gfpName;
	}

	public void setGfpName(String gfpName)
	{
		this.gfpName = gfpName;
	}

	public String getGfcName()
	{
		return gfcName;
	}

	public void setGfcName(String gfcName)
	{
		this.gfcName = gfcName;
	}

	public List<Note> getUserNotes() {
		return userNotes;
	}

	public void setUserNotes(List<Note> userNotes) {
		this.userNotes = userNotes;
	}
	
	public Date getScheduleForLater() {
		return scheduleForLater;
	}

	public void setScheduleForLater(Date scheduleForLater) {
		this.scheduleForLater = scheduleForLater;
	}

	public boolean isMakerCheckerRqd() {
		return makerCheckerRqd;
	}

	public void setMakerCheckerRqd(boolean makerCheckerRqd) {
		this.makerCheckerRqd = makerCheckerRqd;
	}

	public Long getFromGroupId() {
		return fromGroupId;
	}

	public void setFromGroupId(Long fromGroupId) {
		this.fromGroupId = fromGroupId;
	}

	/**
	 * @return the skAccountNo
	 */
	public String getSkAccountNo() {
		return skAccountNo;
	}

	/**
	 * @param skAccountNo the skAccountNo to set
	 */
	public void setSkAccountNo(String skAccountNo) {
		this.skAccountNo = skAccountNo;
	}

	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}

	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getInquirySubStatus() {
		return inquirySubStatus;
	}

	public void setInquirySubStatus(String inquirySubStatus) {
		this.inquirySubStatus = inquirySubStatus;
	}

	public Long getLinkedInquiryId() {
		return linkedInquiryId;
	}

	public void setLinkedInquiryId(Long linkedInquiryId) {
		this.linkedInquiryId = linkedInquiryId;
	}

	public String getDraftInquiryAction() {
		return draftInquiryAction;
	}

	public void setDraftInquiryAction(String draftInquiryAction) {
		this.draftInquiryAction = draftInquiryAction;
	}

	
}
