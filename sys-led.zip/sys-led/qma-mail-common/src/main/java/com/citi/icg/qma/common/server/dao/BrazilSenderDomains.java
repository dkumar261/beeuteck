package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.List;

public class BrazilSenderDomains implements Serializable {
	
	private Long groupId;
	private List<String> domains;
	
	
	public BrazilSenderDomains() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public List<String> getDomains() {
		return domains;
	}
	public void setDomains(List<String> domains) {
		this.domains = domains;
	}
	
	

}
