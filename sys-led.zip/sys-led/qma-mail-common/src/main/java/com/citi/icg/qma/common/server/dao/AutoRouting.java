package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.List;

public class AutoRouting implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6930153804027072076L;
	private List<NLPTags> nlpTags;
	private String validationSuccess;
	private String failReason;
	private String workflowQueueRouted;
	public List<NLPTags> getNlpTags() {
		return nlpTags;
	}
	public void setNlpTags(List<NLPTags> nlpTags) {
		this.nlpTags = nlpTags;
	}
	public String getValidationSuccess() {
		return validationSuccess;
	}
	public void setValidationSuccess(String validationSuccess) {
		this.validationSuccess = validationSuccess;
	}
	public String getFailReason() {
		return failReason;
	}
	public void setFailReason(String failReason) {
		this.failReason = failReason;
	}
	public String getWorkflowQueueRouted() {
		return workflowQueueRouted;
	}
	public void setWorkflowQueueRouted(String workflowQueueRouted) {
		this.workflowQueueRouted = workflowQueueRouted;
	}
	
}
