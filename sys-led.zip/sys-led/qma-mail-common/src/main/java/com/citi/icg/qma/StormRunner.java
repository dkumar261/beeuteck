package com.citi.icg.qma;

public interface StormRunner {
	
}
