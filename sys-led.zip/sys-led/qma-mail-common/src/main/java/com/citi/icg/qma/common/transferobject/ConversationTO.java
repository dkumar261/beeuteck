package com.citi.icg.qma.common.transferobject;

import java.util.List;

import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.Inquiry;

public class ConversationTO
{
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private List<Conversation> conversationList;

	private Inquiry inquiry;
	
	private String suggestionStatus;
	
	private boolean isSuggestionAvailable;

	private boolean isClcSuggestionAvailable;
	
	private List<String> clcSuggestionRecords;
	
	private boolean autoAssignmentAvailable;
	
	private String cacheEvictId;
	
	private boolean intentSuggestionAvailable;
	
	public ConversationTO()
	{

	}

	public ConversationTO(List<Conversation> conversationList, Inquiry inquiry)
	{
		super();
		this.conversationList = conversationList;
		this.inquiry = inquiry;
	}
	
	public List<Conversation> getConversationList() {
		return conversationList;
	}

	public void setConversationList(List<Conversation> conversationList) {
		this.conversationList = conversationList;
	}

	public Inquiry getInquiry() {
		return inquiry;
	}

	public void setInquiry(Inquiry inquiry) {
		this.inquiry = inquiry;
	}

	/**
	 * @return the suggestionStatus
	 */
	public String getSuggestionStatus() {
		return suggestionStatus;
	}

	/**
	 * @param suggestionStatus the suggestionStatus to set
	 */
	public void setSuggestionStatus(String suggestionStatus) {
		this.suggestionStatus = suggestionStatus;
	}

	/**
	 * @return the isSuggestionAvailable
	 */
	public boolean isSuggestionAvailable() {
		return isSuggestionAvailable;
	}

	/**
	 * @param isSuggestionAvailable the isSuggestionAvailable to set
	 */
	public void setSuggestionAvailable(boolean isSuggestionAvailable) {
		this.isSuggestionAvailable = isSuggestionAvailable;
	}

	public boolean isClcSuggestionAvailable() {
		return isClcSuggestionAvailable;
	}

	public void setClcSuggestionAvailable(boolean isClcSuggestionAvailable) {
		this.isClcSuggestionAvailable = isClcSuggestionAvailable;
	}

	public List<String> getClcSuggestionRecords() {
		return clcSuggestionRecords;
	}

	public void setClcSuggestionRecords(List<String> clcSuggestionRecords) {
		this.clcSuggestionRecords = clcSuggestionRecords;
	}

	public boolean isAutoAssignmentAvailable() {
		return autoAssignmentAvailable;
	}

	public void setAutoAssignmentAvailable(boolean autoAssignmentAvailable) {
		this.autoAssignmentAvailable = autoAssignmentAvailable;
	}

	public String getCacheEvictId() {
		return cacheEvictId;
	}

	public void setCacheEvictId(String cacheEvictId) {
		this.cacheEvictId = cacheEvictId;
	}

	public boolean isIntentSuggestionAvailable() {
		return intentSuggestionAvailable;
	}

	public void setIntentSuggestionAvailable(boolean intentSuggestionAvailable) {
		this.intentSuggestionAvailable = intentSuggestionAvailable;
	} 
	
	

}
