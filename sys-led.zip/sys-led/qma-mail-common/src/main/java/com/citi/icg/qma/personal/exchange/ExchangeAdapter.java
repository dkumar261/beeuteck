package com.citi.icg.qma.personal.exchange;

import com.citi.icg.qma.common.server.dao.MailBoxDLMapping;
import com.citi.icg.qma.common.server.util.DedicatedReaderUtility;
import com.citi.icg.qma.personal.exception.ExchangeAuthenticationFailure;
import com.citi.icg.qma.personal.exception.MandatoryConfigurationMissingException;
import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.PropertySet;
import microsoft.exchange.webservices.data.core.enumeration.misc.ExchangeVersion;
import microsoft.exchange.webservices.data.core.enumeration.notification.EventType;
import microsoft.exchange.webservices.data.core.exception.service.remote.ServiceRequestException;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.core.service.schema.EmailMessageSchema;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.credential.WebCredentials;
import microsoft.exchange.webservices.data.notification.PullSubscription;
import microsoft.exchange.webservices.data.property.complex.ItemId;
import microsoft.exchange.webservices.data.property.complex.MimeContent;
import microsoft.exchange.webservices.data.property.complex.RuleCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.mail.Session;
import jakarta.mail.internet.MimeMessage;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.util.Properties;

public final class ExchangeAdapter {

	private static Logger logger = LoggerFactory.getLogger(ExchangeAdapter.class);
	private static DedicatedReaderUtility readerUtil = DedicatedReaderUtility.getInstance();

	public static ExchangeService getExchangeService(String mailbox, String serviceFid, String serviceFidPassword,
			String webServiceURL, String region) throws ExchangeOperationException {
		try (ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2010_SP2)){
				ExchangeCredentials credentials = new WebCredentials(serviceFid, serviceFidPassword, region);
				service.setCredentials(credentials);
				service.setUrl(new URI(webServiceURL));
				
				try {
					RuleCollection inboxRule = service.getInboxRules();
					logger.info("inbox rules count = {}", inboxRule.getCount());
					logger.info("getInboxRules Call executed successfully");
					
				} catch (Throwable e) {
					String errMsg = "Authentication failed with Exchange for account["+mailbox+"], userId["+serviceFid+"]";		
					throw new ExchangeAuthenticationFailure(errMsg, e);
				}
				return service;
			
		} catch (Exception e) {
			String errMsg = "Failure occurred while initializing exchange service";
			logger.error(errMsg, e);
			throw new ExchangeOperationException(errMsg, e);
		}
	}

	/**
	 * This method validates user's exchange account credentials with MailBoxDLMapping
	 * @param mapping
	 * @return boolean
	 * @throws ExchangeAuthenticationFailure
	 */
	public static boolean isUserExchangeAccountExpired(MailBoxDLMapping mapping) {
		String loginSecret = readerUtil.getSecret(mapping);
		return isUserExchangeAccountExpired(mapping.getId(),loginSecret,mapping.getConnectionURL(), mapping.getRegion());
	}

	/**
	 * This method validates user's exchange account credentials
	 * @param userAccountId
	 * @param userAccountSecret
	 * @param userAccountConnectionUrl
	 * @param userAccountRegion
	 * @return boolean
	 */
	public static boolean isUserExchangeAccountExpired(String userAccountId, String userAccountSecret, String userAccountConnectionUrl, String userAccountRegion) {
		boolean isAccountCredentialsExpired = false;
		try (ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2010_SP2)){
				ExchangeCredentials credentials = new WebCredentials(userAccountId, userAccountSecret, userAccountRegion);
				service.setCredentials(credentials);
				service.setUrl(new URI(userAccountConnectionUrl));
				RuleCollection inboxRule = service.getInboxRules();
				logger.info("Inbox rule count = {}", inboxRule.getCount());	
				logger.info("Exchange service is active and credentials are valid for user {} !",userAccountId);
		} catch (Exception e) {
			/**
			 * INFO : Currently for verifying exchange service authentication, there is no dedicated method which validates the credentials and returns
			 * true/false or any specific exception. We will need to get the service instance and perform some operation like above service.getInboxRules(),
			 * here if credentials are expired then while doing this operation it throws ServiceRequestException. This exception is also thrown in many other
			 * scenarios like if your account is reset while fetching service instance due to multi cluster deployment on exchange nodes even though your account
			 * credentials are valid. Hence we can not rely only on this condition (e instanceof ServiceRequestException) to identify credentials are expired.
			 * The only difference when account is expired is, this exception carries error code (401)Unauthorized in the message. Hence we are adding more
			 * more condition (e.getMessage().contains("401")).
			 * TODO : Going forward if exchange API comes with dedicated exception or error code in identifying credential validity,
			 * we will need to change this code as per new code
			 */
			if(e instanceof ServiceRequestException && e.getMessage().contains("401")) {
				String message = "Account credentials expired for user mailbox : " + userAccountId;
				logger.error(message);
				isAccountCredentialsExpired = true;
			} else {
				logger.warn("Exception while getting exchange service instance for mailbox : {}, please try again.", userAccountId, e);
			}
		}
		return isAccountCredentialsExpired;
	}


	public static ExchangeService getExchangeService(String soeId) throws ExchangeOperationException {
		try (ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2010_SP2)){
				MailBoxDLMapping mapping = readerUtil.getMappingById(soeId);
				if(null == mapping) {
					throw new MandatoryConfigurationMissingException("exchange connectivity config not available for soeid ["+soeId+"], please check mailboxDLMapping");
				}
					
				String loginSecret = readerUtil.getSecret(mapping);
				ExchangeCredentials credentials = new WebCredentials(mapping.getId(), loginSecret, mapping.getRegion());
				service.setCredentials(credentials);
				service.setUrl(new URI(mapping.getConnectionURL()));
				/*ImpersonatedUserId  impersonatedUserId1= new ImpersonatedUserId(ConnectingIdType.SmtpAddress, mailbox+"@nalab.exlaborg.com");
				service.setImpersonatedUserId(impersonatedUserId1);*/
				try {
					RuleCollection inboxRule = service.getInboxRules();
					logger.info("inbox rules count = {}", inboxRule.getCount());
					logger.info("getInboxRules Call executed successfully");
					
				} catch (Throwable e) {
					String errMsg = "Authentication failed with Exchange for account["+soeId+"] ";		
					throw new ExchangeAuthenticationFailure(errMsg, e);
				}
				return service;
						
			
		} catch (Exception e) {
			String errMsg = "Failure occurred while initializing exchange service";
			logger.error(errMsg, e);
			throw new ExchangeOperationException(errMsg, e);
		}
	}
	
	public static MimeMessage getMimeMessage(ExchangeService service, ItemId itemId) throws ExchangeOperationException {
		PropertySet propertySetForEmailContent = new PropertySet(EmailMessageSchema.MimeContent,
				EmailMessageSchema.Subject, EmailMessageSchema.InternetMessageId);
		
		MimeMessage mimeMessage = null;
		try {
			EmailMessage message = EmailMessage.bind(service, itemId, propertySetForEmailContent);
			MimeContent mimeContent = message.getMimeContent();
			byte[] bytes = mimeContent.getContent();

			Properties props = new Properties();
			props.setProperty("mail.mime.address.strict", "false");
			props.setProperty("mail.mime.decodetext.strict", "false");
			Session session = Session.getDefaultInstance(props);
			mimeMessage = new MimeMessage(session, new ByteArrayInputStream(bytes));
			logger.debug("Fetched Email from exchange: ID[{}], subject: {};", mimeMessage.getMessageID(), mimeMessage.getSubject());
			return mimeMessage;
		} catch (Exception e) {
			String errMsg = "Could not fetch the Email Message content assiciated with the itemId : ["+itemId+"]";
			logger.error(errMsg, itemId, e);
			throw new ExchangeOperationException(errMsg, e);
		}
	}
	
	public static PullSubscription getPullSubscriptionOnAllFolders(ExchangeService service, String emailSyncState) throws ExchangeOperationException {
		PullSubscription subscription = null;
		try {
			try {
				subscription = service.subscribeToPullNotificationsOnAllFolders(
						1440/* timeOut: the subscription will end if the server is not polled within 5 minutes. can configure no-timeout */, 
						emailSyncState /* watermark: null to start a new subscription. If we need to pull only specific watermark email, then specify*/, 
						EventType.NewMail, 
						EventType.Created, 
						EventType.Deleted,// Debate on this
						EventType.Modified,// Debate on this
						EventType.Moved,// Debate on this
						EventType.FreeBusyChanged,//Skype online/bust status
						EventType.Copied);//Debate on this
			} catch (Exception e) {
				logger.info(e.getMessage());
				String errMsg = "The watermark used for creating this subscription was not found";
				if (e.getMessage().contains(errMsg)) {
					emailSyncState = null;
					subscription = service.subscribeToPullNotificationsOnAllFolders(
							1440/* timeOut: the subscription will end if the server is not polled within 5 minutes. can configure no-timeout */, 
							emailSyncState /* watermark: null to start a new subscription. If we need to pull only specific watermark email, then specify*/, 
							EventType.NewMail, 
							EventType.Created, 
							EventType.Deleted,// Debate on this
							EventType.Modified,// Debate on this
							EventType.Moved,// Debate on this
							EventType.FreeBusyChanged,//Skype online/bust status
							EventType.Copied);//Debate on this
				}				
			}
			return subscription;
		} catch (Exception e) {
			String errMsg = "Failure occurred while initializing a pullSubscription";
			logger.debug(errMsg);
			throw new ExchangeOperationException(errMsg, e);
		}
		
	}
}
