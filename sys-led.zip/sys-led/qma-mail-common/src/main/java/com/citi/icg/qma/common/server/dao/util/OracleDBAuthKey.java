package com.citi.icg.qma.common.server.dao.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.GenericUtil;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

public class OracleDBAuthKey
{
	
	private static final String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";
	private static Connection oracleDBConnection = null; 
	private static OracleDBAuthKey instance = null;
	private static final Logger logger = LoggerFactory.getLogger(OracleDBAuthKey.class);
	private OracleDBAuthKey() throws CommunicatorException
	{
		try
		{
			if (null != QMACacheFactory.getCache() && null != QMACacheFactory.getCache().getConfigById("smartOracleConnectionConfig"))
			{
				Config smartOracleConnectionConfig = QMACacheFactory.getCache().getConfigById("smartOracleConnectionConfig");
				if (null != smartOracleConnectionConfig && null != smartOracleConnectionConfig.getSmartOracleConnectionConfig()){
					String url = (String) smartOracleConnectionConfig.getSmartOracleConnectionConfig().get("url");
					String userName = (String) smartOracleConnectionConfig.getSmartOracleConnectionConfig().get("userName");
					String password = (String) smartOracleConnectionConfig.getSmartOracleConnectionConfig().get("password");
					String passwordIV = (String) smartOracleConnectionConfig.getSmartOracleConnectionConfig().get("passwordIV");
					
					Properties prop = new Properties();
					prop.setProperty("password", password);
					prop.setProperty("passwordIV", passwordIV);
					String pwd = GenericUtil.getDecryptedPassword(prop);
					Class.forName(ORACLE_DRIVER);
					oracleDBConnection = DriverManager.getConnection(url,userName,pwd);
				} else {
					logger.info("SMART DB Connection is not configured in Collection");
				}
			} else {
				logger.info("Cache not loaded properly for getting SMART DB connection configuration");
			}
			
			
			
			if(oracleDBConnection!=null)
			{
				logger.info("SMART DB connection successful");
			}
			
		}
		catch(Exception e)
		{
			logger.error("Exception caught in oracle ",e);
			throw new CommunicatorException("Exception in OracleDBAuthKey", e);
		}

	}
	
	public static OracleDBAuthKey getInstance()
	{
		
		try {
			if(instance == null || (null!=oracleDBConnection && oracleDBConnection.isClosed()))
			{
				synchronized (OracleDBAuthKey.class)
				{
					if(instance == null || (null!=oracleDBConnection && oracleDBConnection.isClosed()))
					{
						try {
							instance = new OracleDBAuthKey();
						} catch (CommunicatorException e) {
							logger.error("Exception while initializing OracleDBAuthKey.getInstance ",e);
							instance = null;
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception caught in OracleDBAuthKey.getInstance ",e);
		}
		
		return instance;
		
	}
	
	public Connection getConnection()
	{
		return oracleDBConnection;
	}
	
	
	
	public void closeConnection()
	{
		try
		{
			if(oracleDBConnection!=null)
			{
				oracleDBConnection.close();
			}
		}
		catch(SQLException e)
		{
			logger.info("Exception caught while closing the Netezza connection"+e);
		}
		
	}

}
