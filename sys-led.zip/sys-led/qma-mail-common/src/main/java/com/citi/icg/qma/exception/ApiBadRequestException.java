package com.citi.icg.qma.exception;

public class ApiBadRequestException extends Exception{

	private static final long serialVersionUID = 5130810050223136600L;
	
	public ApiBadRequestException(String message) {
		super(message);
	}

}
