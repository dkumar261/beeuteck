package com.citi.icg.qma.common.server.dao;
import java.io.Serializable;
public class OrgAuditTrailRequestType implements Serializable {
	private static final long serialVersionUID = 3114670723952492917L;
	private String requestType;
	private String statusIndicator;

	public OrgAuditTrailRequestType() {
		super();
	}

	public OrgAuditTrailRequestType(String requestType, String statusIndicator) {
		super();
		this.requestType = requestType;
		this.statusIndicator = statusIndicator;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getStatusIndicator() {
		return statusIndicator;
	}

	public void setStatusIndicator(String statusIndicator) {
		this.statusIndicator = statusIndicator;
	}

}
