package com.citi.icg.qma.common.server.cache;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.hazelcast.cache.client.HazelcastCache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import com.mongodb.BasicDBObject;

public class ConversationCache {

	HazelcastInstance hz;
	private IMap<String, String> convResponseMap;
	private static volatile ConversationCache instance;
	private static Logger logger = LoggerFactory.getLogger(ConversationCache.class);
	private AtomicLong cachePutTotal = new AtomicLong(0);
	private AtomicLong cachePutSuccess = new AtomicLong(0);
	private AtomicLong cacheHitTotal = new AtomicLong(0);
	private AtomicLong cacheHitSuccess = new AtomicLong(0);


	private ConversationCache() {
		HazelcastCache qmaHzCache = (HazelcastCache) QMACacheFactory.getCache();
		hz = qmaHzCache.getHZInstance();
		convResponseMap = hz.getMap("conversationResponseMap");
	}

	public static ConversationCache getInstance() {
		if (instance == null) {
			synchronized (HazelcastCache.class) {
				if (instance == null) {
					instance = new ConversationCache();
					logger.info("initialized cache for Conversation");
				}
			}
		}
		return instance;
	}

	private Boolean checkIfConversationCacheEnabled() {
		Boolean isConvCacheEnabled = false;
//		try {
//			Map<String, Object> qmaHzCacheConfig = getConversationCacheConfig();
//			if (Objects.nonNull(qmaHzCacheConfig)) {
//				isConvCacheEnabled = (Boolean) qmaHzCacheConfig.get("conversationCacheEnabled");
//			}
//			logger.debug(" is conversation cache enabled : " + isConvCacheEnabled);
//		} catch (Exception e) {
//			logger.warn("failed to fetch details of qmaHazelcastCacheConfig from Hazelcast cache", e);
//		}

		return isConvCacheEnabled;
	}

	private Boolean hasAnyGroupSubscribedForConversationCache(List<Long> groupIdList) {
		Boolean hasAnyGroupSubscribed = false;
//		try {
//			Map<String, Object> qmaHzCacheConfig = getConversationCacheConfig();
//			if (Objects.nonNull(qmaHzCacheConfig)) {
//				List<String> subscriberGroups = (List<String>) qmaHzCacheConfig.get("subscriberGroups");
//				hasAnyGroupSubscribed = checkGroupBasedSubscription(subscriberGroups, groupIdList);
//			}
//		} catch (Exception e) {
//			logger.warn("failed to fetch details of qmaHazelcastCacheConfig from Hazelcast cache", e);
//		}
		return hasAnyGroupSubscribed;
	}

	private Boolean checkGroupBasedSubscription(List<String> subscriberGroups, List<Long> groupIdList) {
		if (CollectionUtils.isNotEmpty(groupIdList)) {
			if (CollectionUtils.isNotEmpty(subscriberGroups)) {
				logger.debug("subscriber groups : " + subscriberGroups);
				for (Long grpId : groupIdList) {
					String groupCode = grpId == null ? null
							: QMACacheFactory.getCache().getGroupIdToNameMap().get(grpId);
					if (StringUtils.isNotBlank(groupCode) && subscriberGroups.contains(groupCode)) {
						logger.info("The group[{}] has subscribed for caching conversation data", groupCode);
						return true;
					}
				}
			} else {
				logger.info("There subscriberGroups config is either empty or not defined, cache conversation subscription is by default applied for all");
				return true;
			}
		} else {
			logger.info("no group IDs present in this check for subscription of conversation data");
		}
		return false;
	}

	private Map<String, Object> getConversationCacheConfig() {
		Map<String, Object> qmaHzCacheConfig = null;
		try {
			com.citi.icg.qma.common.server.dao.Config qmaConfig = QMACacheFactory.getCache()
					.getConfigById("qmaHazelcastCacheConfig");
			if (Objects.nonNull(qmaConfig)) {
				qmaHzCacheConfig = (Map<String, Object>) qmaConfig.getQmaHazelcastCacheConfig();
			}
		} catch (Exception e) {
			logger.warn("failed to fetch details of qmaHazelcastCacheConfig from Hazelcast cache", e);
		}
		return qmaHzCacheConfig;
	}

	private Boolean isEligibleForCaching(boolean isAllConvContent, BasicDBObject inputJsonObject) {
		Boolean isEligibleForCaching = true;
//		if (!isAllConvContent) {
//			isEligibleForCaching = false;
//			logger.debug("conversation cache request not eligible as content is not requested");
//		}
		Integer pageNum = GenericUtility.convertLongToIntFromBSON(inputJsonObject.get("pageNum"));
		Integer pageSize = GenericUtility.convertLongToIntFromBSON(inputJsonObject.get("pageSize"));
		if (Objects.nonNull(pageNum) || Objects.nonNull(pageSize)) {
			isEligibleForCaching = false;
			logger.debug("conversation cache request not eligible as pagintion is being used");
		}
		return isEligibleForCaching;

	}

	public String getCachedResponse(Long inquiryId, List<Long> selectInqAssignedGroupId, boolean isAllConvContent,
			BasicDBObject inputJsonObj) {
		String cachedResponse = null;		
		try {
			Boolean isConvCacheEnabled = checkIfConversationCacheEnabled();
			Boolean hasAnyGroupSubscribed = hasAnyGroupSubscribedForConversationCache(selectInqAssignedGroupId);
			if (isConvCacheEnabled && hasAnyGroupSubscribed) {
				Long total = cacheHitTotal.incrementAndGet();
				Long success = cacheHitSuccess.get();
				Boolean isEligibleForCaching = isEligibleForCaching(isAllConvContent, inputJsonObj);
				if (isEligibleForCaching) {
					StringBuffer keyBuffer = new StringBuffer();
					String key = null;
					if (Objects.nonNull(inquiryId)) {
						keyBuffer.append(inquiryId.toString());
						if (Objects.nonNull(selectInqAssignedGroupId) && selectInqAssignedGroupId.size() > 0
								&& Objects.nonNull(selectInqAssignedGroupId.get(0))) {
							keyBuffer.append("-").append(selectInqAssignedGroupId.get(0).toString());
							key = keyBuffer.toString();
							cachedResponse = this.convResponseMap.get(key);
						}
					}
					if (Objects.nonNull(cachedResponse)) {
						success = cacheHitSuccess.incrementAndGet();
						logger.debug("conversation-cache-hit  for key : [{}], get-counters : [{}/{}]", key, success, total);
					} else {
						logger.debug("conversation-cache-miss for key : [{}], get-counters : [{}/{}]", key, success, total);
					}
				}
			}			
		} catch (Exception e) {
			logger.warn("exception occurred while trying to get entry from conversation cache", e);
		}
		return cachedResponse;
	}

	public void putResponseInCache(Long inquiryId, List<Long> selectInqAssignedGroupId, boolean isAllConvContent,
			BasicDBObject inputJsonObject, String convResponse) {
		try {
			Boolean isConvCacheEnabled = checkIfConversationCacheEnabled();
			Boolean hasAnyGroupSubscribed = hasAnyGroupSubscribedForConversationCache(selectInqAssignedGroupId);
			if (isConvCacheEnabled && hasAnyGroupSubscribed) {
				Long total = cachePutTotal.incrementAndGet();
				Long success = cachePutSuccess.get();
				Boolean isEligibleForCaching = isEligibleForCaching(isAllConvContent, inputJsonObject);
				if (isEligibleForCaching) {
					StringBuffer keyBuffer = new StringBuffer();
					String key = null;
					if (Objects.nonNull(inquiryId)) {
						keyBuffer.append(inquiryId.toString());
						if (Objects.nonNull(selectInqAssignedGroupId) && selectInqAssignedGroupId.size() > 0
								&& Objects.nonNull(selectInqAssignedGroupId.get(0))) {
							keyBuffer.append("-").append(selectInqAssignedGroupId.get(0).toString());
							key = keyBuffer.toString();
							this.convResponseMap.put(key, convResponse);
							success = cachePutSuccess.incrementAndGet();
							logger.debug("conversationTO added to key : [{}], put-counters : [{}/{}]", key, success,
									total);
						}
					}
				}
			}
		} catch (Exception e) {
			logger.warn("exception occurred while trying to put entry in conversation cache", e);
		}

	}

	public Integer removeEntry(Long inquiryId, Collection<Long> groupIdList) {
		int entryCount = 0;
		try {
			Boolean isConvCacheEnabled = checkIfConversationCacheEnabled();
			if (isConvCacheEnabled) {
				if (inquiryId != null && convResponseMap.size() > 0) {
					for (Long groupId : groupIdList) {
						if (Objects.nonNull(groupId)) {
							String key = inquiryId.toString() + groupId.toString();
							String previousData = convResponseMap.remove(key);
							if (Objects.nonNull(previousData)) {
								entryCount++;
							}
						}
					}
				}
				if (entryCount > 0) {
					logger.debug(
							"removed {} entries from conversation cache for all entries for inquiryId : {} and groupIds: {}",
							entryCount, inquiryId, groupIdList);
				} else {
					logger.debug("no entry found in conversation cache for inquiryId : {} and groupIds: {}", inquiryId,
							groupIdList);
				}
			}			
		} catch (Exception e) {
			logger.warn("exception occurred while trying to remove entries from conversation cache", e);
		}
		return entryCount;
	}

	public void removeEntriesWithKeySetIteration(List<Long> inquiryIdList) {
		try {
			Boolean isConvCacheEnabled = checkIfConversationCacheEnabled();
			if (isConvCacheEnabled) {
				for (Long inquiryId : inquiryIdList) {
					removeEntriesWithKeySetIteration(inquiryId);
				}
			}
		} catch (Exception e) {
			logger.warn("exception occurred while trying to remove entries from conversation cache", e);
		}		
	}
	public Integer removeEntriesWithKeySetIteration(Long inquiryId) {
		int entryCount = 0;
		try {
			Boolean isConvCacheEnabled = checkIfConversationCacheEnabled();
			if (isConvCacheEnabled) {
				Set<String> matchedKeys = new HashSet<String>();
				if (inquiryId != null && convResponseMap.size() > 0) {
					String inquiryIdStr = inquiryId.toString();
					Set<String> keys = convResponseMap.keySet();
					for (String key : keys) {
						String previousData = null;
						if (StringUtils.isNotBlank(key) && key.contains(inquiryIdStr)) {
							matchedKeys.add(key);
							previousData = convResponseMap.remove(key);
							if (Objects.nonNull(previousData)) {
								entryCount++;
							}
						}
					}
				}
				if (entryCount > 0) {
					logger.debug("removed {} entries from conversation cache for inquiryId : {}, removedKeys: [{}]",
							entryCount, inquiryId, matchedKeys);
				} else {
					logger.debug("no entry found in conversation cache for inquiryId : {}", inquiryId);
				}
			}
		} catch (Exception e) {
			logger.warn("exception occurred while trying to remove entries from conversation cache");
		}
		return entryCount;
	}

	public void removeAllCacheEntries() {
		try {
			Boolean isConvCacheEnabled = checkIfConversationCacheEnabled();
			if (isConvCacheEnabled) {
				convResponseMap.evictAll();
			}			
		} catch (Exception e) {
			logger.warn("exception occurred while trying to remove all (evictAll) entries from conversation cache");
		}
	}

//	public Integer removeEntriesWithValuePredicate(Long inquiryId) {
//		int entryCount = 0;
//		if (inquiryId != null && convResponseMap.size() > 0) {
//			convResponseMap.keySet();
//			String previousData = convResponseMap.remove(Predicates.equal("cacheEvictId", inquiryId));
//			if (Objects.nonNull(previousData)) {
//				entryCount++;
//			}
//		}
//		if (entryCount > 0) {
//			logger.debug("removed {} entries from conversation cache for inquiryId : {} and groupIds: {}", entryCount,
//					inquiryId);
//		} else {
//			logger.debug("no entry found in conversation cache for inquiryId : {} and groupIds: {}", inquiryId);
//		}
//		return entryCount;
//	}

}
