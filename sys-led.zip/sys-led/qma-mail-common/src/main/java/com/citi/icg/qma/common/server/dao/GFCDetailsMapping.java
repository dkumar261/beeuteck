package com.citi.icg.qma.common.server.dao;

import java.util.Date;
import java.util.List;
import java.util.Set;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "GFCDetailsMapping", noClassnameStored = true)
public class GFCDetailsMapping {

	@Id
	private String recordId;
	private String gfpId;
	private String gfpName;

	private String gfcId;
	private String gfcName;

	private String accountBranch;
	private String accountCountry;
	private String skAccountNo;

	private String grandParentNumber;
	private String grandParentName;

	private Date createDate;
	private Date modDate;
	private Set<String> skAccountGrams;
	private Set<String> gfcIdGrams;
	private Set<String> accountBranchGrams;
	
	public GFCDetailsMapping() {
		super();
	}

	/**
	 * @return the gfpId
	 */
	public String getGfpId() {
		return gfpId;
	}

	/**
	 * @param gfpId the gfpId to set
	 */
	public void setGfpId(String gfpId) {
		this.gfpId = gfpId;
	}

	/**
	 * @return the gfpName
	 */
	public String getGfpName() {
		return gfpName;
	}

	/**
	 * @param gfpName the gfpName to set
	 */
	public void setGfpName(String gfpName) {
		this.gfpName = gfpName;
	}

	/**
	 * @return the gfcId
	 */
	public String getGfcId() {
		return gfcId;
	}

	/**
	 * @param gfcId the gfcId to set
	 */
	public void setGfcId(String gfcId) {
		this.gfcId = gfcId;
	}

	/**
	 * @return the gfcName
	 */
	public String getGfcName() {
		return gfcName;
	}

	/**
	 * @param gfcName the gfcName to set
	 */
	public void setGfcName(String gfcName) {
		this.gfcName = gfcName;
	}

	/**
	 * @return the accountBranch
	 */
	public String getAccountBranch() {
		return accountBranch;
	}

	/**
	 * @param accountBranch the accountBranch to set
	 */
	public void setAccountBranch(String accountBranch) {
		this.accountBranch = accountBranch;
	}

	/**
	 * @return the accountCountry
	 */
	public String getAccountCountry() {
		return accountCountry;
	}

	/**
	 * @param accountCountry the accountCountry to set
	 */
	public void setAccountCountry(String accountCountry) {
		this.accountCountry = accountCountry;
	}

	/**
	 * @return the skAccountNo
	 */
	public String getSkAccountNo() {
		return skAccountNo;
	}

	/**
	 * @param skAccountNo the skAccountNo to set
	 */
	public void setSkAccountNo(String skAccountNo) {
		this.skAccountNo = skAccountNo;
	}

	/**
	 * @return the grandParentNumber
	 */
	public String getGrandParentNumber() {
		return grandParentNumber;
	}

	/**
	 * @param grandParentNumber the grandParentNumber to set
	 */
	public void setGrandParentNumber(String grandParentNumber) {
		this.grandParentNumber = grandParentNumber;
	}

	/**
	 * @return the grandParentName
	 */
	public String getGrandParentName() {
		return grandParentName;
	}

	/**
	 * @param grandParentName the grandParentName to set
	 */
	public void setGrandParentName(String grandParentName) {
		this.grandParentName = grandParentName;
	}

	public String getRecordId() {
		return recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getModDate() {
		return modDate;
	}

	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}

	public Set<String> getSkAccountGrams() {
		return skAccountGrams;
	}

	public void setSkAccountGrams(Set<String> skAccountGrams) {
		this.skAccountGrams = skAccountGrams;
	}

	public Set<String> getGfcIdGrams() {
		return gfcIdGrams;
	}

	public void setGfcIdGrams(Set<String> gfcIdGrams) {
		this.gfcIdGrams = gfcIdGrams;
	}

	public Set<String> getAccountBranchGrams() {
		return accountBranchGrams;
	}

	public void setAccountBranchGrams(Set<String> accountBranchGrams) {
		this.accountBranchGrams = accountBranchGrams;
	}
	
}
