package com.citi.icg.qma.common.server.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.AccessPermission;
import org.apache.pdfbox.pdmodel.encryption.StandardProtectionPolicy;
import org.apache.poi.hslf.usermodel.HSLFSlideShow;
import org.apache.poi.hssf.record.crypto.Biff8EncryptionKey;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.poifs.crypt.EncryptionInfo;
import org.apache.poi.poifs.crypt.EncryptionMode;
import org.apache.poi.poifs.crypt.Encryptor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.CompressionLevel;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;


/**
 * 
 *
 */

public class PasswordProtectionUtil {
	
	private static final Logger subLogger = LoggerFactory.getLogger(PasswordProtectionUtil.class);
	
	public static boolean applyPasswordForFiles(String fileName, File newFile, InputStream inputStream, String soeId, String password) throws CommunicatorException 
	{

		String fileExtension = FilenameUtils.getExtension(fileName);

		try
		{
			switch (fileExtension.toUpperCase())
			{

				case "XLSX": case "DOCX": case "PPTX": 
					return applyPasswordForMicrosoftDocuments(fileName, newFile, inputStream, password);
				
				case "DOC": 
					return applyPasswordForOLDWordDocuments(fileName, newFile, inputStream, password);
	
				case "XLS": 
					return applyPasswordForOLDExcelFiles(fileName, newFile, inputStream, password);
					
				case "PPT": 
					return applyPasswordForOLDPPTDocuments(fileName, newFile, inputStream, password);
					
				case "PDF":
					return applyPasswordForPdfDocuments(fileName, newFile, IOUtils.toByteArray( inputStream ) , password);
	
				case "ZIP":
					return applyPasswordForZipFiles(fileName, newFile, inputStream, soeId, password);
	
				default:

			}

		}
		catch (IOException e)
		{
			subLogger.error("Inside PasswordProtectionUtil.applyPasswordForFiles, error while appying password to attached File : " + fileName, e);
		}

		return false;
	}
	
	/*public static void main(String[] args)  
	{
		Logger logger = (Logger) LoggerFactory.getLogger("XStreamCommunicator");
		String fileDest = "C:\\Users\\XXXXXX\\Desktop\\Xstream\\QMA\\Password Protection\\title1.ppt";
		String fileName = FilenameUtils.getName(fileDest);
		
		
		InquiryRestServiceImpl impl = new InquiryRestServiceImpl();
		String soeid = "testSoeId";
		File file = new File(fileDest);
		
		try (InputStream inputStream = new FileInputStream(file))
		{

			File newFileForPwdProtection = impl.createFileForPwdProtection(soeid, fileName);

			boolean isPasswordProtectionSuccess = PasswordProtectionUtil.applyPasswordForFiles(fileName, newFileForPwdProtection, inputStream, "testSoeId", "test", logger);

			System.out.println(isPasswordProtectionSuccess);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
*/
	/**
	 * @param fileName
	 * @param newFileForPwdProtection
	 * @param inputStream
	 * @param password
	 * @param subLogger
	 * @return
	 * @throws IOException
	 */
	public static boolean applyPasswordForPdfDocuments(String fileName, File newFile, byte[] inputStream, String password) throws IOException
	{

		subLogger.info("Inside PasswordProtectionUtil.applyPasswordForPdfDocuments - applying password for attached File :" + fileName);

		try (PDDocument document = Loader.loadPDF(inputStream))
		{

			// Define the length of the encryption key.
			// Possible values are 40 or 128 (256 will be available in PDFBox 2.0).
			int keyLength = 128;
			AccessPermission ap = new AccessPermission();
			// Disable printing, everything else is allowed
			ap.setCanPrint(false);

			// Owner password (to open the file with all permissions) is "12345"
			// User password (to open the file but with restricted permissions, is empty here)
			StandardProtectionPolicy spp = new StandardProtectionPolicy(password, password, ap);
			spp.setEncryptionKeyLength(keyLength);
			spp.setPermissions(ap);
			document.protect(spp);

			document.save(newFile);
			document.close();

			subLogger.info("Inside PasswordProtectionUtil.applyPasswordForPdfDocuments - is completed and file is secured, and newFile :" + newFile);
			return true;

		}
		catch (Exception e)
		{
			subLogger.error("Inside PasswordProtectionUtil.applyPasswordForPdfDocuments, error while appying password to attached File : " + fileName, e);
		}

		return false;

	}
	/**
	 * @param fileName
	 * @param newFileForPwdProtection
	 * @param inputStream
	 * @param password 
	 * @param subLogger
	 * @return
	 */
	public static boolean applyPasswordForMicrosoftDocuments(String fileName, File newFile, InputStream inputStream, String password)
	{
		subLogger.info("Inside PasswordProtectionUtil.applyPasswordForMicrosoftDocuments - applying password for attached File :" + fileName);
		
		try (POIFSFileSystem fs = new POIFSFileSystem()) {
		    EncryptionInfo info = new EncryptionInfo(EncryptionMode.agile);
		    Encryptor enc = info.getEncryptor();
		    enc.confirmPassword(password);
		    try (OPCPackage opc = OPCPackage.open(inputStream);
		        OutputStream os = enc.getDataStream(fs)) {
		        opc.save(os);
		    } catch (Exception opcE) {
		    	subLogger.warn("Inside PasswordProtectionUtil.applyPasswordForMicrosoftDocuments.OPCPackage - error while applying password to fileName: " + fileName, opcE);
			} 
		    try (FileOutputStream fos = new FileOutputStream(newFile)) {
		        fs.writeFilesystem(fos);
		        subLogger.info("Inside PasswordProtectionUtil.applyPasswordForMicrosoftDocuments - is completed and file is secured , newFile :" + newFile);
		        return true;
		    } catch (Exception fosE) {
		    	subLogger.warn("Inside PasswordProtectionUtil.applyPasswordForMicrosoftDocuments.FileOutputStream - error while applying password to fileName: " + fileName, fosE);
			}
		} catch (Exception e) {
			subLogger.warn("Inside PasswordProtectionUtil.applyPasswordForMicrosoftDocuments - error while applying password to fileName: " + fileName, e);
		}

		return false;
	}
	/**
	 * @param fileName
	 * @param newFileForPwdProtection
	 * @param inputStream
	 * @param password 
	 * @param subLogger
	 * @return
	 */
	public static boolean applyPasswordForMicrosoftDocuments_old(String fileName, File newFile, InputStream inputStream, String password)
	{
		subLogger.info("Inside PasswordProtectionUtil.applyPasswordForMicrosoftDocuments - applying password for attached File :" + fileName);
		
		try (OPCPackage opc = OPCPackage.open(inputStream))
		{
			// apply password 
			EncryptionInfo info = new EncryptionInfo(EncryptionMode.agile);
			Encryptor enc = info.getEncryptor();
			enc.confirmPassword(password);

			POIFSFileSystem poiFS = new POIFSFileSystem();
			OutputStream outStream;
			outStream = enc.getDataStream(poiFS);

			opc.save(outStream);
			opc.close();

			FileOutputStream fos = new FileOutputStream(newFile);
			poiFS.writeFilesystem(fos);
			fos.close();

			subLogger.info("Inside PasswordProtectionUtil.applyPasswordForMicrosoftDocuments - is completed and file is secured , newFile :" + newFile);
			return true;

		}
		catch (Exception e)
		{
			subLogger.error("Inside PasswordProtectionUtil.applyPasswordForMicrosoftDocuments - error while applying password to fileName: " + fileName, e);
		}

		return false;

	}

	/**
	 * @param fileName
	 * @param newFile
	 * @param inputStream
	 * @param password
	 * @param subLogger
	 * @return
	 */
	public static boolean applyPasswordForOLDWordDocuments(String fileName, File newFile, InputStream inputStream, String password)
	{
		subLogger.info("Inside PasswordProtectionUtil.applyPasswordForOLDWordDocuments - applying password for attached File :" + fileName);

		try
		{
	
			BufferedInputStream bufferInput = new BufferedInputStream(inputStream);
			POIFSFileSystem poiFileSystem = new POIFSFileSystem(bufferInput);
			
			// Setting password
			// Sets the BIFF8 encryption/decryption password for the current thread.
			Biff8EncryptionKey.setCurrentUserPassword(password);		
			
			HWPFDocument wordDoc = new HWPFDocument(poiFileSystem);
			FileOutputStream fileOut = new FileOutputStream(newFile);
			wordDoc.write(fileOut);
			bufferInput.close();
			fileOut.close();
			wordDoc.close();
			
			Biff8EncryptionKey.setCurrentUserPassword(null);

			subLogger.info("Inside PasswordProtectionUtil.applyPasswordForOLDWordDocuments - is completed and file is secured , newFile :" + newFile);
			return true;

		}
		catch (Exception e)
		{
			subLogger.error("Inside PasswordProtectionUtil.applyPasswordForOLDWordDocuments - error while applying password to fileName: " + fileName, e);
		}

		return false;

	}
	
	/**
	 * @param fileName
	 * @param newFile
	 * @param inputStream
	 * @param password
	 * @param subLogger
	 * @return
	 */
	public static boolean applyPasswordForOLDExcelFiles(String fileName, File newFile, InputStream inputStream, String password)
	{
		subLogger.info("Inside PasswordProtectionUtil.applyPasswordForOLDExcelFiles - applying password for attached File :" + fileName);
		
		try 
		{
			BufferedInputStream bufferInput = new BufferedInputStream(inputStream);
			POIFSFileSystem poiFS = new POIFSFileSystem(bufferInput);
			// Setting password
			// Sets the BIFF8 encryption/decryption password for the current thread.
			Biff8EncryptionKey.setCurrentUserPassword(password);
			HSSFWorkbook hwb = new HSSFWorkbook(poiFS);
			hwb.write(newFile);
			poiFS.close();
			hwb.close();

			Biff8EncryptionKey.setCurrentUserPassword(null);

			subLogger.info("Inside PasswordProtectionUtil.applyPasswordForOLDExcelFiles - is completed and file is secured , newFile :" + newFile);
			return true;

		}
		catch (Exception e)
		{
			subLogger.error("Inside PasswordProtectionUtil.applyPasswordForOLDExcelFiles - error while applying password to fileName: " + fileName, e);
		}

		return false;

	}
	
	/**
	 * @param fileName
	 * @param newFile
	 * @param inputStream
	 * @param password
	 * @param subLogger
	 * @return
	 */
	public static boolean applyPasswordForOLDPPTDocuments(String fileName, File newFile, InputStream inputStream, String password)
	{
		subLogger.info("Inside PasswordProtectionUtil.applyPasswordForOLDPPTDocuments - applying password for attached File :" + fileName);
		
		try (FileOutputStream fos = new FileOutputStream(newFile))
		{
			BufferedInputStream bufferInput = new BufferedInputStream(inputStream);
			POIFSFileSystem poiFS = new POIFSFileSystem(bufferInput);
			// Setting password
			// Sets the BIFF8 encryption/decryption password for the current thread.
			Biff8EncryptionKey.setCurrentUserPassword(password);
			HSLFSlideShow hwb = new HSLFSlideShow(poiFS);
			hwb.write(fos);
			fos.close();
			poiFS.close();
			hwb.close();

			Biff8EncryptionKey.setCurrentUserPassword(null);

			subLogger.info("Inside PasswordProtectionUtil.applyPasswordForOLDPPTDocuments - is completed and file is secured, newFile :" + newFile);
			return true;

		}
		catch (Exception e)
		{
			subLogger.error("Inside PasswordProtectionUtil.applyPasswordForOLDPPTDocuments - error while applying password to fileName: " + fileName, e);
		}

		return false;

	}
	
	
	/**
	 * @param fileName
	 * @param newZipFile
	 * @param inputStream
	 * @param soeId
	 * @param password
	 * @param subLogger
	 * @return
	 * @throws IOException
	 */
	public static boolean applyPasswordForZipFiles(String fileName, File newZipFile, InputStream inputStream, String soeId, String password) throws IOException
	{
		String extractZipFileLocation = null;
		try
		{
			subLogger.info("Inside PasswordProtectionUtil.applyPasswordForZipFiles - applying password for attached File :" + fileName);
			fileName = GenericUtility.sanitizeFileName(fileName);
			String defaultFileCreationFolder = GenericUtility.getDefaultFileCreationDirectory();
			extractZipFileLocation = getPathForZipExtraction(fileName , defaultFileCreationFolder ,  soeId);
			
			if(!GenericUtility.isValidFileName(fileName) || !GenericUtility.isValidPath(extractZipFileLocation)) {
				subLogger.error("Invalid filename {} or zip file location {} while while applying password for zip files " ,fileName , extractZipFileLocation);
				return false;
			}
			extractFilesFromZipInputStream(fileName,inputStream,  extractZipFileLocation);
			
			ZipFile newEncryptedZipFile = new ZipFile(newZipFile);
			// Initiate Zip Parameters which define various properties
			ZipParameters parameters = new ZipParameters();
			parameters.setCompressionMethod(CompressionMethod.DEFLATE);
			//parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE); // set compression method to deflate compression
			// DEFLATE_LEVEL_FASTEST - Lowest compression level but higher speed of compression
			// DEFLATE_LEVEL_FAST - Low compression level but higher speed of compression
			// DEFLATE_LEVEL_NORMAL - Optimal balance between compression level/speed
			// DEFLATE_LEVEL_MAXIMUM - High compression level with a compromise of speed
			// DEFLATE_LEVEL_ULTRA - Highest compression level but low speed
			//parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
			parameters.setCompressionLevel(CompressionLevel.NORMAL);
			// Set the encryption flag to true
			parameters.setEncryptFiles(true);
			// Set the encryption method to AES Zip Encryption
			//parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
			parameters.setEncryptionMethod(EncryptionMethod.AES);
			// AES_STRENGTH_128 - For both encryption and decryption
			// AES_STRENGTH_192 - For decryption only
			// AES_STRENGTH_256 - For both encryption and decryption
			// Key strength 192 cannot be used for encryption. But if a zip file
			// already has a
			// file encrypted with key strength of 192, then Zip4j can decrypt
			// this file
			//parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
			parameters.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256);
			// Set password
			newEncryptedZipFile.setPassword(password.toCharArray());
			//parameters.setPassword(password);
			parameters.setIncludeRootFolder(false);
			// Now add files to the zip file
			newEncryptedZipFile.addFolder(new File(extractZipFileLocation), parameters);
			
			// delete extractZipFileLocation from server
			GenericUtility.deleteDirectory(extractZipFileLocation);
			subLogger.info("Inside PasswordProtectionUtil.applyPasswordForZipFiles - is completed and file is secured , newFile :" + newZipFile);
			return true;

		}
		catch (ZipException | CommunicatorException e)
		{
			subLogger.error("Inside PasswordProtectionUtil.applyPasswordForZipFiles - error while applying password to fileName: " + fileName, e);
			// delete extractZipFileLocation from server
			GenericUtility.deleteDirectory(extractZipFileLocation);
		}

		return false;
	}



	/**
	 * @param defaultFileCreationFolder
	 * @param fileNameWithoutExtension
	 * @param soeId
	 * @return
	 */
	private static String getPathForZipExtraction(String fileName, String defaultFileCreationFolder,  String soeId)
	{
		String zipExtractionLocation;
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss"); //2018-10-16-13-28-15
		String currentTimeStamp = dateFormat.format(date);

		// replace abc.zip to abc_zip
		String fileNameWithoutExtension = fileName.replace(".", "_").replace(" ", "_");
		
		if(null!=defaultFileCreationFolder)
		{
			
			zipExtractionLocation = defaultFileCreationFolder + soeId + "_" + currentTimeStamp + "_" + fileNameWithoutExtension; 
		}else
		{
			zipExtractionLocation = soeId + "_" + currentTimeStamp + "_" + fileNameWithoutExtension; 
		}
		
		return zipExtractionLocation;		
	}



	/**
	 * @param fileName 
	 * @param inputStream
	 * @param subLogger
	 * @param pathToExtractZipFiles
	 * @throws CommunicatorException 
	 * @throws  
	 * @throws IOException
	 */
	private static void extractFilesFromZipInputStream(String fileName, InputStream inputStream,  String zipFileExtractionDirectory) throws IOException, CommunicatorException 
	{
		subLogger.info("Inside PasswordProtectionUtil.ExtractFilesFromZipInputStream - Extracting zipFile : " + fileName + " , into temp directory : " + zipFileExtractionDirectory);
		
		File directory = new File(zipFileExtractionDirectory);
	    if (! directory.exists()){
	        directory.mkdir();
	    }

	    try
	    {
		    ZipInputStream zipIns = new ZipInputStream(inputStream);
			ZipEntry zipEntry;
			byte[] buffer = new byte[2048];
	
			// iterate ZipEntry and extract files to pathToExtractFiles
			while ((zipEntry = zipIns.getNextEntry()) != null)
			{
	
				String fileInfo = "Entry: [%s] len %d added %TD".formatted(
						zipEntry.getName(), zipEntry.getSize(),
						new Date(zipEntry.getTime()));
				subLogger.info("PasswordProtectionUtil.ExtractFilesFromZipInputStream file info :" + fileInfo);
	
				Path outDir = Path.of(zipFileExtractionDirectory);
				Path filePath = outDir.resolve(zipEntry.getName());
	
				writeFiles( zipIns, buffer, filePath);
	
			}
	    }catch (IOException e)
		{
			subLogger.error("Inside PasswordProtectionUtil.extractFilesFromZipInputStream - error while extracting zip files into directory: " + zipFileExtractionDirectory, e);
			throw new CommunicatorException("Inside PasswordProtectionUtil.extractFilesFromZipInputStream - error while extracting zip files into directory: " + zipFileExtractionDirectory, e);
		}
	    
	    subLogger.info("Inside PasswordProtectionUtil.ExtractFilesFromZipInputStream is completed..");

	}



	/**
	 * @param subLogger
	 * @param zipIns
	 * @param buffer
	 * @param filePath
	 * @throws CommunicatorException 
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	private static void writeFiles( ZipInputStream zipIns, byte[] buffer, Path filePath) throws CommunicatorException 
	{
		
		filePath = Path.of(GenericUtility.sanitizeFileNameForPathTraversal(filePath.toString()));
		// Read the file data from the stream until it returns 0 or less.
		try (FileOutputStream output = new FileOutputStream((filePath).toFile()))
		{
			subLogger.info("PasswordProtectionUtil.writeFiles into : " + filePath);
			int len;
			while ((len = zipIns.read(buffer)) > 0)
			{
				output.write(buffer, 0, len);
			}
		}
		catch (IOException e)
		{
			subLogger.error("Inside PasswordProtectionUtil.writeFiles - error while writing files into directory: " + filePath, e);
			throw new CommunicatorException("Inside PasswordProtectionUtil.writeFiles - error while writing files into directory: " + filePath, e);
		}
	}
	
}
