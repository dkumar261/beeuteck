package com.citi.icg.qma.common.contact.tcl.entity;

public class TCLContactData {

	private String cobDate;
	private String custId;
	private String custName;
	private String taxId;
	private String productFamily;
	private String email;
	private String crtdBy;
	private String crtdTs;
	
	public TCLContactData() {
		super();
		// Auto-generated constructor stub
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getTaxId() {
		return taxId;
	}
	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getProductFamily() {
		return productFamily;
	}
	public void setProductFamily(String productFamily) {
		this.productFamily = productFamily;
	}
	public String getCobDate() {
		return cobDate;
	}
	public void setCobDate(String cobDate) {
		this.cobDate = cobDate;
	}
	public String getCrtdBy() {
		return crtdBy;
	}
	public void setCrtdBy(String crtdBy) {
		this.crtdBy = crtdBy;
	}
	public String getCrtdTs() {
		return crtdTs;
	}
	public void setCrtdTs(String crtdTs) {
		this.crtdTs = crtdTs;
	}
}
