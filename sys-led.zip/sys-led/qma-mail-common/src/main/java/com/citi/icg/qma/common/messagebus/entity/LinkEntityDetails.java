package com.citi.icg.qma.common.messagebus.entity;

import java.util.List;

public class LinkEntityDetails {
	
	private List<InquiryDetails> inquiryDetails;
	private String eventType;

	public LinkEntityDetails() {
		super();
	}

	public List<InquiryDetails> getInquiryDetails() {
		return inquiryDetails;
	}

	public void setInquiryDetails(List<InquiryDetails> inquiryDetails) {
		this.inquiryDetails = inquiryDetails;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	

}
