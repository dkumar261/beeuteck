package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Entity;

// test class, not for our db model
@Entity(value = "AppUsers", noClassnameStored = false)
public class AppUsers extends BaseEntity
{

	private String firstName;
	private String lastName;
	private int age;
	private boolean read;

	public AppUsers(String firstname, String lastName, int age)
	{

		this.firstName = firstname;
		this.lastName = lastName;
		this.age = age;

	}

	public AppUsers()
	{
	}

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	@Override
	public String toString()
	{
		// TODO Auto-generated method stub
		return firstName + lastName + age;
	}

	public int getAge()
	{
		return age;
	}

	public void setAge(int age)
	{
		this.age = age;
	}

	public boolean isRead()
	{
		return read;
	}

	public void setRead(boolean read)
	{
		this.read = read;
	}
}
