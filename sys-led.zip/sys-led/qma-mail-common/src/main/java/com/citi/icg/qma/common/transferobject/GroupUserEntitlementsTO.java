/**
 * 
 */
package com.citi.icg.qma.common.transferobject;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.citi.icg.qma.common.server.dao.ManagementHeirarchy;

/**
 * 
 *
 */
public class GroupUserEntitlementsTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String groupName;
	private String groupEmail;
	private boolean isActive;
	private ManagementHeirarchy heirarchyData;
	private List<String> requestTypes;
	private List<UserGroupRoles> userEntitlements;
	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}
	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	/**
	 * @return the groupEmail
	 */
	public String getGroupEmail() {
		return groupEmail;
	}
	/**
	 * @param groupEmail the groupEmail to set
	 */
	public void setGroupEmail(String groupEmail) {
		this.groupEmail = groupEmail;
	}
	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}
	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public List<UserGroupRoles> getUserEntitlements() {
		return userEntitlements;
	}
	public void setUserEntitlements(List<UserGroupRoles> userEntitlements) {
		this.userEntitlements = userEntitlements;
	}
	
	/**
	 * @return the heirarchyData
	 */
	public ManagementHeirarchy getHeirarchyData() {
		return heirarchyData;
	}
	/**
	 * @param heirarchyData the heirarchyData to set
	 */
	public void setHeirarchyData(ManagementHeirarchy heirarchyData) {
		this.heirarchyData = heirarchyData;
	}

	/**
	 * @return the requestType
	 */
	public List<String> getRequestTypes() {
		return requestTypes;
	}
	/**
	 * @param requestType the requestType to set
	 */
	public void setRequestTypes(List<String> requestTypes) {
		this.requestTypes = requestTypes;
	}

	public static class UserGroupRoles implements Serializable{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		
		private String id;
		private String name;
		private Set<String> groupRoles;
		
		public UserGroupRoles()
		{
			//default
		}
		public UserGroupRoles(String id, String name, Set<String> groupRoles) {
			this.id = id;
			this.name = name;
			this.groupRoles = groupRoles;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		/**
		 * @return the groupRoles
		 */
		public Set<String> getGroupRoles() {
			return groupRoles;
		}
		/**
		 * @param groupRoles the groupRoles to set
		 */
		public void setGroupRoles(Set<String> groupRoles) {
			this.groupRoles = groupRoles;
		}
		
	}

	
}
