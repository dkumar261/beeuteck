package com.citi.icg.qma.performance.utils;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import jakarta.mail.Session;
import jakarta.mail.internet.MimeMessage;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.ClientMapping;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.IncomingToCcDLAliasMapping;
import com.citi.icg.qma.common.server.dao.RoutingCriteriaBean;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.WorkflowAudit;
import com.citi.icg.qma.config.storm.StormTopolgyConfig;
import com.citi.icg.qma.config.storm.StormTopolgyConfig.TopologyName;
import com.citi.icg.qma.dao.ComponentEvent;
import com.citi.icg.qma.dao.MessageSnapshot;
import com.citi.icg.qma.dao.persistence.MessageSnapshotDAO;
import com.citi.icg.qma.exception.NonRecoverableDBException;
import com.citi.icg.qma.hazelcast.cache.client.HazelcastCache;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.hazelcast.core.DistributedObject;
import com.hazelcast.map.IMap;


@SuppressWarnings("unused")
public class TempStuff {
	private static final Logger logger = LoggerFactory.getLogger(TempStuff.class);
	
	public static void main(String[] args) throws Exception {
		
		testInactiveUpdate();
		
		
		System.exit(0);
	}
	
	private static void testInactiveUpdate() throws NonRecoverableDBException{

	}
	
	private static void laodMimeMessageFromFile(){
		try {
			
			String fileName="C:\\Users\\XXXXXX\\Desktop\\5d4948a3d84551115c0c156a.eml";
			FileInputStream is = new FileInputStream(fileName);
				Properties props = new Properties();
				props.setProperty("mail.mime.address.strict", "false");
				props.setProperty("mail.mime.decodetext.strict", "false");
				Session session = Session.getDefaultInstance(props);
				MimeMessage m = new MimeMessage(session, is);
						
			
			
			
		} catch (Exception e) {
		    logger.warn("Exception in laodMimeMessageFromFile.", e);
		}
		
	}
																																																												
	private static void createAutoSysJobs() {
		
		String jobNameSuff = "_QMA_PROCESSOR_TOPOLOGY_START_Job";
		String boxName = "170665_QMA_PROCESSOR_TOPOLOGY_START_BOX";
		String jobDesc = "Starts processor topology";
		String command = "$QMA_SCRIPTS/storm-topology.sh -a start -t processor";
		
		
		String vmNamePrfix ="V170665_VM_QMA";
		Integer[] vms={4,5,6,7,8};
		
		
		for (Integer vm : vms) {
			String vmName=vmNamePrfix+"%02d".formatted(vm);
			String jobName="170665_QMA"+"%02d".formatted(vm)+jobNameSuff;
			
			/*
			 * System.out.println("insert_job: "+jobName+"    job_type: cmd");
			 * System.out.println("description: "+jobDesc);
			 * System.out.println("box_name: "+boxName);
			 * System.out.println("machine: "+vmName); System.out.println("owner: qma");
			 * System.out.println("max_run_alarm: 0");
			 * System.out.println("alarm_if_fail: y"); System.out.
			 * println("profile: /opt/qma/qma-mail-common-utils/170665_AutosysProfile.sh");
			 * System.out.
			 * println("std_out_file: $AUTOSYS_LOGS_DIR/${AUTO_JOB_NAME}.${DATESTAMP}.${RUN}.stdout"
			 * ); System.out.
			 * println("std_err_file: $AUTOSYS_LOGS_DIR/${AUTO_JOB_NAME}.${DATESTAMP}.${RUN}.stderr"
			 * ); System.out.println("command: "+command); System.out.println("");
			 */
		}
	}
	
	private static void checkqmStormConfigFromCache(){
		StormTopolgyConfig stormTopolgyConfig=StormTopolgyConfig.load(TopologyName.CONTROLLER);
		//System.out.println("StormTopolgyConfig config"+ReflectionToStringBuilder.toString(stormTopolgyConfig, ToStringStyle.MULTI_LINE_STYLE));
		
	}
	/**
	 * Arguments to be passed to jvm to run this function utility are:<br>
	 * 1) -Dqma.mail.config.file="<yaml config with db details>" <br>
	 * 2) -Djavax.net.ssl.trustStore="<cacert file location>"
	 */
	private static void downloadMessageFromGridFs(String guid){
		try {
			MessageSnapshot ms = MessageSnapshotDAO.getInstance().getMessageSnapshotByGuid(guid);
			String gridFsId=ms.getGridFSId();
			//get mime message from grif fs using the gridfs id
			MimeMessage msg=MessageSnapshotDAO.getInstance().getMimeMessageFromGridFS(gridFsId);
			
			if(msg !=null) {
			//to write to EML file, gridFsId.eml
			String fileName=gridFsId+".eml";
			FileOutputStream os = new FileOutputStream(fileName);
			msg.writeTo(os);
			os.close();
			/*
			 * System.out.println("created file  "+fileName+ " for messageId:"+
			 * msg.getMessageID());
			 */
			}
			
		} catch ( Exception e) {
		    logger.warn("Exception in downloadMessageFromGridFs.", e);
		}
	}
	private static void timeCimsAndManualEmails() {
		Set<ConversationRecipient> recipientDOList=new HashSet<ConversationRecipient>();
		List<String> l=new ArrayList<String>();
		l.add("XXXX");
		l.add("XXXX");
		l.add("XXXX");
		l.add("XXXX");
		for (String string : l) {
			findGroupIdUsingCIMSandManualEmails(string, "TO",recipientDOList , new HashSet<Long>());
		}
	}

	private static void countCacheUsersAndClientMapping(){
		for (int i = 0; i < 2; i++) {
		    /* System.out.println("\n------------- i="+i+"------------"); */
			long s=System.currentTimeMillis();
			Map<String, ClientMapping> cmMap = QMACacheFactory.getCache().getClientMappingMap();
			/* System.out.println("time to get cmMap "+(System.currentTimeMillis()-s)); */
			s=System.currentTimeMillis();
			Map<String, User> userMap = QMACacheFactory.getCache().getUserInfoMap();
			/*
			 * System.out.println("time to get userMap "+(System.currentTimeMillis()-s));
			 * 
			 * System.out.println("clientMappingMap size="+cmMap.size()+" | userMap size="
			 * +userMap.size());
			 */
			ClientMapping c=cmMap.get("FRONTIERCAP.COM");
			User usr=userMap.get("XXXXXX".toUpperCase());
			/*
			 * System.out.println(ReflectionToStringBuilder.toString(c,
			 * ToStringStyle.MULTI_LINE_STYLE));;
			 * System.out.println("User : id="+usr.getId()+" name="+usr.getName());
			 * System.out.println("Client Mapping time");
			 */
		}
	}
	
	private static void countActiveGroups() {
		Long start = System.currentTimeMillis();

		List<Group> groupList= QMACacheFactory.getCache().getGroupList();
		int activeGroups = 0;
		int inActiveGroups = 0;
		long its=System.currentTimeMillis();
		for (Group group : groupList) {
			if (group.getActive()) {
				activeGroups++;
			} else {
				inActiveGroups++;
			}

		}      
		/*
		 * System.out.println("Time taken for iter = " + (System.currentTimeMillis() -
		 * its)); System.out.println("activeGroups {" +activeGroups +
		 * "},  inActiveGroups " + inActiveGroups); System.out.println("Time taken = " +
		 * (System.currentTimeMillis() - start));
		 */
	}

	private static void printStatsForCacheEntry() {
		//System.out.println(" --- all objects ---");
		 Collection<DistributedObject> o = HazelcastCache.getInstance().getHZInstance().getDistributedObjects();
		 for (DistributedObject distributedObject : o) {
			//System.out.println(distributedObject.getName()+" - "+distributedObject.getClass());
		}
		//System.out.println("\n\n --- group ---");
		List<String> keys = Arrays.asList("parentToChildDLsListMap", "emailWithDomaintoGroupMap", "groupList", "groupIdToNameMap", "groupIdToCIMSEmailList", "groupIdToManualEmailList", "dbRoutingCriteriaList", "groupCodeToEmailMap", "groupCodeToIdMap", "groupIdToCodeMap", "groupIdToEmailMap", "groupIdToActiveMap", "groupEmailToIdMap", "groupIdToDisclaimerMap", "groupIdToGrpCrtDateMap", "groupIdToRequestTypeMap", "groupIdToHierarchyMap", "groupIdToParentDLEmailAliasListMap", "groupIdToTagMap", "incomingToCcDLAliasMappingEmailsMap", "allGroupsMap", "groupIdToProcessingRegionMap");
		IMap<Object, Object> groupDataMap = HazelcastCache.getInstance().getHZInstance().getMap("groupDataMap");
		for (String key : keys) {
			System.out.println("Current entry :" + key);
			Object value = groupDataMap.get(key);
			if (value instanceof Map) {
				//System.out.println("size : " +((Map)value).size());
			} else if (value instanceof List) {
				//System.out.println("size : " +((List)value).size());
			} else {
				//System.out.println("Object : " + value);
			}
		}
		
		
		 //System.out.println("\n\n--- config ---");
		 
		IMap<String,Config> Configmap=  HazelcastCache.getInstance().getHZInstance().getMap("configMap");
		List<String> Configkeys = Arrays.asList("EscalationCriteria","smartRoutingRule","citiDomain","msExchangeServerConfiguration","msExchangeServerConfigParallel","autoFwdDLsMapping");
		for (String string : Configkeys) {
			//System.out.println("Current entry :" + string);
			Object value = Configmap.get(string);
			if (value instanceof Map) {
				//System.out.println("size : " +((Map)value).size());
			} else if (value instanceof List) {
				//System.out.println("size : " +((List)value).size());
			} else {
				//System.out.println("Object : " + value);
			}
		}
	}

	

	private static Long findGroupIdUsingCIMSandManualEmails(String emailAddressReceived, String recipientCategory, Set<ConversationRecipient> recipientDOList, Set<Long> groupIdSet)
	{
		//System.out.println("inside findGroupIdUsingCIMSandManualEmails ");
		Long groupId = null;
		try
		{
			////List<Group> dbGroupListFromcache = mongoGroupMappingCache.getGroupList();
			//List<Group> dbGroupListFromcache = QMACacheFactory.getCache().getGroupList();//TODO this call will be time expensive
			////Map<Long, List<String>> groupIdToCIMSEmailList = mongoGroupMappingCache.getGroupIdToCIMSEmailList();
			Map<Long, List<String>> groupIdToCIMSEmailList = QMACacheFactory.getCache().getGroupIdToCIMSEmailList();
			Map<Long, Group> map = QMACacheFactory.getCache().getAllGroupsMap();
			////Map<Long, List<String>> groupIdToManualGroupEmailList = mongoGroupMappingCache.getGroupIdToManualEmailList();
			Map<Long, List<String>> groupIdToManualGroupEmailList = QMACacheFactory.getCache().getGroupIdToManualEmailList();

			if (!StringUtils.isBlank(emailAddressReceived) && map != null && !map.isEmpty())
			{
				//System.out.println("start of for loop in findGroupIdUsingCIMSandManualEmails"+System.currentTimeMillis());

				long foreachTimeTotal = 0;
				long subEmailListTimeTotal = 0;
				long ifBlockTimeTotal = 0;
				long foreachTime = System.currentTimeMillis();
				//int s=dbGroupListFromcache.size();
				int i=0;

				//				
				//				for (Group grp : dbGroupListFromcache)
				//				{   
				//				
				for (Long grpId : map.keySet())
				{   
					Group grp =map.get(grpId);
					//				 for (Entry<Long, Group> entry : map.entrySet())  {
					//					 Group grp=entry.getValue();
					//if(i++ > 10)break;
					foreachTimeTotal += (System.currentTimeMillis() -  foreachTime);

					Long subEmailListTime = System.currentTimeMillis();
					List<String> cimsEmailList = grp.id==null?null:groupIdToCIMSEmailList.get(grp.id); // This list is also in uppercase with @ data
					List<String> manualEmailList = grp.id==null?null: groupIdToManualGroupEmailList.get(grp.id); //// This list is also in uppercase with @ data
					subEmailListTimeTotal += (System.currentTimeMillis() - subEmailListTime);


					long ifBlockTime=System.currentTimeMillis();
					// Don't consider inactive groups
					// 1. Match incoming email with AllGroupEmails, If Matched, create receipient and abort.
					if (grp.getActive() && cimsEmailList != null && cimsEmailList.contains(emailAddressReceived))
					{
						groupId = grp.getId();
						logger.info("Group Matched in AllGroupEmailsFromCIMS for Email " + emailAddressReceived + " , recipientCategory: " + recipientCategory + " , Group Id: " + groupId
								+ " , Group Name:" + grp.getGroupName());
						groupIdSet.add(groupId);
						// Create and Add Recipient
						ConversationRecipient memberRecipient = new ConversationRecipient();
						//createInqRecipient(memberRecipient, groupId, grp.getGroupEmail(), recipientCategory, grp.getGroupName());
						recipientDOList.add(memberRecipient);

						break;

					}
					// 2. Else Match incoming email with ManualGroupEmails, If Matched, create receipient and abort.
					else if (grp.getActive() && manualEmailList != null && manualEmailList.contains(emailAddressReceived))
					{
						groupId = grp.getId();
						logger.info("Group Matched in ManualGroupEmails for Email " + emailAddressReceived + " ,recipientCategory: " + recipientCategory + " ,Group Id: " + groupId + " ,Group Name:"
								+ grp.getGroupName());
						groupIdSet.add(groupId);
						// Create and Add Recipient
						ConversationRecipient memberRecipient = new ConversationRecipient();
						//createInqRecipient(memberRecipient, groupId, grp.getGroupEmail(), recipientCategory, grp.getGroupName());
						recipientDOList.add(memberRecipient);
						break;
					}
					ifBlockTimeTotal += (System.currentTimeMillis()-ifBlockTime);
					foreachTime = System.currentTimeMillis();

				}
				String LogTimeMessage="findGroupIdUsingCIMSandManualEmails foreachTimeTotal="+foreachTimeTotal+" | subEmailListTimeTotal="+subEmailListTimeTotal+" | ifBlockTimeTotal="+ifBlockTimeTotal;
				/*
				 * System.out.println(LogTimeMessage+System.currentTimeMillis());
				 * System.out.println("end of for loop in findGroupIdUsingCIMSandManualEmails"
				 * +System.currentTimeMillis());
				 */
			}
		}
		catch (Exception e)
		{
			
			logger.warn("Exception in findGroupIdUsingCIMSandManualEmails:", e);
		}

		return groupId;
	}


	private static void tesmp() {
		//System.out.println("Started");
		if(true)
			while(true){
				List<Group> dbGroupListFromcache = QMACacheFactory.getCache().getGroupList();//TODO this call will be time expensive
				long totalTime =0;
				for (int i = 0; i <2; i++) {
					long h=System.currentTimeMillis();
					for (Group group : dbGroupListFromcache) {

						@SuppressWarnings("unused")
						Boolean a = group.getActive();
						//System.out.println(group.id);
						totalTime += (System.currentTimeMillis()-h);
						//System.out.println(" o  time: "+(System.currentTimeMillis()-h));
						h=System.currentTimeMillis();

					}	
					//System.out.println(i+"-  "+totalTime);
					totalTime=0;
				}



				//System.out.println(totalTime);
				System.exit(0);
				//System.out.println("full list"+dbGroupListFromcache.size());
				Map<Long, List<String>> groupIdToCIMSEmailList = QMACacheFactory.getCache().getGroupIdToCIMSEmailList();
				//System.out.println(groupIdToCIMSEmailList.size());

				int i=0;
				for (Long group : groupIdToCIMSEmailList.keySet()) {
					long t=System.currentTimeMillis();
					List l=groupIdToCIMSEmailList.get(group);
					//System.out.println(" o "+group+" - "+l.size()+" time: "+(System.currentTimeMillis()-t));
					if(i++==10)break;
				}

				//			Map<Long, List<String>> groupIdToManualGroupEmailList = QMACacheFactory.getCache().getGroupIdToManualEmailList();
				//			for (Long group : groupIdToManualGroupEmailList.keySet()) {
				//				System.out.println(" opp "+group+" - "+groupIdToManualGroupEmailList.get(group).size());
				//			}

				//System.out.println("aslidhao-----------------------------------s");

			}
		System.exit(0);
		Config cas=QMACacheFactory.getCache().getConfigById("qmaStormConfig");
		Map<String, Object> map=QMACacheFactory.getCache().getConfigById("qmaStormConfig").getQmaStormConfig();
		//map=dao.mongoDatastore.find(Config.class).field("_id").equal("qmaStormConfig").get().getQmaStormConfig();
		map.forEach((k,v)->{
			//System.out.println(k+" - "+v+" "+v.getClass());
		});


		System.exit(0);
		Config conf=new Config();

		conf.setId("qmaStormConfig");
		//	conf.setQmaStormConfig(qmaStormConfig);
		logger.info("{}");


		Map<String, List<String>> mm = QMACacheFactory.getCache().getParentToChildDLsListMap();
		Map<String, Group> mmm = QMACacheFactory.getCache().getEmailWithDomaintoGroupMap();
		/*
		 * System.out.println(mm.size()); System.out.println(mmm.size());
		 */
		//mmm.forEach((k,v)->{System.out.println(k+" - "+v.id);});
		/* System.out.println("over oooo"); */
		//mm.forEach((k,v)->{System.out.println(k+" - ");});
		List<String> lo = mm.get("XXXX@XXX.COM");
		
		logger.info("{}",lo);
		;
		System.exit(0);
		Field[] allFields = WorkflowAudit.class.getDeclaredFields();
		for (Field f : allFields) {
			//System.out.println(f.getType()+" compare(\""+f.getName()+"\",newAudit.get"+StringUtils.capitalize(f.getName())+"(),oldAudit.get"+StringUtils.capitalize(f.getName())+"());");
		}


		
		List<MessageSnapshot> list = null;

		//list= dao.mongoDatastore.createQuery(MessageSnapshot.class).limit(12000).asList();

		//System.out.println( " SIZE OF LIST: "+list.size());
		int totalRep=0;

		List<Long> procTime=new ArrayList<Long>();



		for(MessageSnapshot m:list){
			List<ComponentEvent> clist=m.getEvents();
			boolean flag = false;
			if(clist.size()>18) {flag=true; totalRep++;}
			Date procFini=null;
			Date readStart=null;
			int p=0;
			Date procMin=null;
			Date procMax=null;
			for(ComponentEvent e:clist){

				if(e.getComponent()!=null&&e.getComponent().equalsIgnoreCase("PROCESSOR")){
					if(e.getEvent().equalsIgnoreCase("STARTED")){
						if(procMin==null)procMin=e.getTime();
						else{
							if(e.getTime().before(procMin))
								procMin=e.getTime();
						}

					}else if(e.getEvent().equalsIgnoreCase("FINISHED")){
						if(procMax==null)procMax=e.getTime();
						else{
							if(e.getTime().after(procMax))
								procMax=e.getTime();
						}
					}
				}
				if(e.getComponent()!=null&&e.getComponent().equalsIgnoreCase("READER")&&e.getEvent().equalsIgnoreCase("STARTED")){
					readStart=e.getTime();
				}
				if(e.getComponent()!=null&&e.getComponent().equalsIgnoreCase("PROCESSOR")&&e.getEvent().equalsIgnoreCase("FINISHED")){

					p++;
					if(p==5){
						procFini=e.getTime();
						//break;
					}
				}


			}
			long diffInMillies=0;
			if(procMax!=null&&procMin!=null){ diffInMillies= procMax.getTime() - procMin.getTime();}
			procTime.add(diffInMillies);

			//System.out.println(m.getMessageId()+ " "+procFini +"        " +readStart + " multiple pr: " +flag +"total processors finished: "+p +" Processor Time taken ms: "+diffInMillies);	
		}
		/*
		 * System.out.println("Total REPET: "+totalRep);
		 * 
		 * System.out.println("done");
		 */
		//procFini.getTime() -readStart.getTime() 

		//procTime.sort();
		procTime.forEach(o->{
			//System.out.print(o+" ");
		});
		//System.out.println("Processor Times "+procTime.get(0)+" last: "+procTime.get(procTime.size()-1));

		System.exit(0);
		QMACache cache = HazelcastCache.getInstance();



		Map<Long, String> groupIdToCodeMap = cache.getGroupIdToNameMap();
		Map<Long, String> groupIdToNameMap = cache.getGroupIdToNameMap();
		Map<Long, List<RoutingCriteriaBean>> dbRoutingCriteriaList =cache.getDbRoutingCriteriaList();

		/*
		 * System.out.println("Size: "+groupIdToCodeMap.size()+" "+groupIdToCodeMap.get(
		 * 10L)); System.out.println("Size: "+groupIdToNameMap.size());
		 * System.out.println("Size: "+dbRoutingCriteriaList.size() +" - "
		 * +dbRoutingCriteriaList.get(60L).get(0).getGroupName());
		 */
		List<IncomingToCcDLAliasMapping> incomingToCcDLAliasMapping =cache.getIncomingToCcDLAliasMapping();
		/*
		 * System.out.println(ReflectionToStringBuilder.toString(
		 * incomingToCcDLAliasMapping, ToStringStyle.MULTI_LINE_STYLE));
		 * System.out.println("Size: "+incomingToCcDLAliasMapping.size()+
		 * incomingToCcDLAliasMapping.get(0).getEmail());
		 */
		//		ClientMapping c=cache.getClientMappingByDomain("FRONTIERCAP.COM");
		//	System.out.println(ReflectionToStringBuilder.toString(c, ToStringStyle.MULTI_LINE_STYLE));;

		List<String> citiDomainsList=cache.getCitiDomainsList();
		//System.out.println(" Citi Domains LIST"+ReflectionToStringBuilder.toString(citiDomainsList, ToStringStyle.MULTI_LINE_STYLE));

		Map<String, String> msMap=cache.getMsExchangeServerMap();
		//System.out.println(".get(SUPPORT_EMAIL)"+msMap.get("SUPPORT_EMAIL"));
		msMap.forEach((k, v) -> {
		//	System.out.println(k + " - " + v);
		});
	//	System.out.println(" MS EXCHANGE config"+ReflectionToStringBuilder.toString(msMap, ToStringStyle.MULTI_LINE_STYLE));



		long t,tt;
		for(int i=0;i<5;i++){
			t=System.nanoTime();
			String name=groupIdToNameMap.get(4770L);
			tt=System.nanoTime();
			//System.out.println("val: "+name+"Time: "+(tt-t));

		}

		/*groupIdToNameMap.forEach((k, v) -> {
			System.out.println(k + " - " + v);
		});*/

		//HazelcastCache.getHZInstance().shutdown();
	}

}
