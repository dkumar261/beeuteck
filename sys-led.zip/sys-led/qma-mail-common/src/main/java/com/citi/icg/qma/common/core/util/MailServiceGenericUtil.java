package com.citi.icg.qma.common.core.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.mail.Message;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.subscriber.mails.entity.InquiryMail;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

public class MailServiceGenericUtil {
	private static final String ENDS_WITH = "endsWith";
	private static final String EQ = "eq";
	public static final String REFERENCE_CLOSE_PATTERN = ">";
	public static final String REFERENCE_DELIM_LINE_BREAK = "\r\n";
	public static final String REFERENCE_DELIM_COMMA = ",";
	private static Logger logger = LoggerFactory.getLogger(MailServiceGenericUtil.class);

	// Sonar Fix-Add a private constructor to hide implicit variables
	private MailServiceGenericUtil() {

	}

	public static boolean isEmailRoutedFromInternal(List<String> toCCGroupCodes) {
		boolean routingGrpFlag = QmaMailConstants.STRING_YES.equalsIgnoreCase(QMACacheFactory.getCache().getEnableInternalGroupEmailRouting());
		// Inclusion Filter is null or empty- no need to match-default match as
		// true- set routing for all
		// Else atleast one TO/CC Grp should match filter grps configured in
		// static data
		List<String> grpRoutingInclusionList = QMACacheFactory.getCache().getInternalGrpRoutingInclusionList();
		boolean routingGrpFilterMatch = matchRoutingGrpFilter(toCCGroupCodes, grpRoutingInclusionList);

		// Routing is enabled based on Routing flag && groupFilter Match
		boolean routingEnabled = routingGrpFlag && routingGrpFilterMatch;

		logger.debug("Routing Grp Flag = {} ,grpRoutingInclusionList = {}  , toCCGroupCodes received = {} , Routing Enabled for this conversation email = {} "
				,routingGrpFlag, grpRoutingInclusionList,toCCGroupCodes,routingEnabled);

		return routingEnabled;
	}

	public static boolean isEnableOnHalfOfBasedOnFromGroup(String fromGroupCode) {
		boolean disableOnBehalfFlag = QmaMailConstants.STRING_YES.equalsIgnoreCase(QMACacheFactory.getCache().getDisableOnBehalfOf());
		// Inclusion Filter is null or empty- no need to match-default match as
		// true- set disable onbehalf for all emails
		// Else disable onbehalf for the emails sending from 'From' Group only.
		List<String> disableInclusionList = QMACacheFactory.getCache().getDisableOnBehalfOfGrpList();
		
		boolean disableGrpFilterMatch = matchDisableGrpFilter(fromGroupCode, disableInclusionList);

		// Routing is enabled based on Routing flag && groupFilter Match
		boolean onBehalfOfEnabled = !(disableOnBehalfFlag && disableGrpFilterMatch);

		logger.debug("disableOnBehalfFlag = {}  ,disableInclusionList = {}, from group code received = {} , OnbehalfOf Enabled for this conversation email = {} ", disableOnBehalfFlag,disableInclusionList,fromGroupCode,onBehalfOfEnabled);
		return onBehalfOfEnabled;
	}

	public static boolean matchRoutingGrpFilter(List<String> toCCGroupCodes, List<String> grpRoutingInclusionList) {
		boolean routingGrpFilterMatched = true;

		// Inclusion Filter is null or empty- no need to match-default match as
		// true- set routing for all
		// Else atleast one TO/CC Grp should match filter grps configured in
		// static data
		if (null != grpRoutingInclusionList && !grpRoutingInclusionList.isEmpty()
				&& !containsOne(grpRoutingInclusionList, toCCGroupCodes)) {
			routingGrpFilterMatched = false;
		}
		return routingGrpFilterMatched;
	}

	private static boolean matchDisableGrpFilter(String fromGroupCode, List<String> disableGrpInclusionList) {
		boolean disableGrpFilterMatched = true;

		// Inclusion Filter is null or empty- no need to match-default match as
		// true- set disable onbehalf for all emails
		// Else disable onbehalf for the emails sending from 'From' Group only.

		if (null != disableGrpInclusionList && !disableGrpInclusionList.isEmpty()
				&& !disableGrpInclusionList.contains(fromGroupCode)) {
			disableGrpFilterMatched = false;
		}
		return disableGrpFilterMatched;
	}

	public static boolean containsOne(Collection<?> collectionSrc, Collection<?> collectionDest) {
		if (null != collectionSrc && null != collectionDest) {
			Iterator localIterator = collectionDest.iterator();
			while (localIterator.hasNext()) {
				Object localObject = localIterator.next();
				if (collectionSrc.contains(localObject)) {
					return true;
				}
			}
		}
		return false;
	}

	// Method to replace all special chars with spaces.
	public static String replaceSpecialCharsForParsingReport(String inputData) {
		String outputData = null;
		if (null != inputData) {
			outputData = inputData.replaceAll(",", " ").replaceAll("\n", " ").replaceAll("\r", " ").replaceAll("\t",
					" ");
		}

		return outputData;

	}

	// Method to get Email Subject Appended with Environment Details
	public static String getEmailSubjectWithEnvironment(String subject) {
		String environment = System.getProperty("icg.env");

		if (!StringUtils.isBlank(subject) && !StringUtils.isBlank(environment)
				&& !("prod").equalsIgnoreCase(environment)) {
			subject = subject + " [" + environment.toUpperCase() + "]";
		}
		logger.debug("getEmailSubjectWithEnvironment - Environment {} , subject: {};" ,environment,subject);
		return subject;

	}

	public static String[] extractMailReferencesToRefArray(String incomingEmailReferences) {
		String[] referencesArray = null;
		String[] stringArray = {};

		List<String> referencesArrayList = new ArrayList<>();

		if (null != incomingEmailReferences) {
			// 1. Remove all blank spaces and Split by referenceCloseStrPattern
			// = >
			referencesArray = incomingEmailReferences.replaceAll(" ", "").split(REFERENCE_CLOSE_PATTERN);
			for (int i = 0; i < referencesArray.length; i++) {
				// 2.Replace all expected referenceDelimeterPatterns (/r/n and
				// comma) and add referenceCloseStrPattern again which is lost
				// in above split.
				String reference = referencesArray[i].replaceAll(REFERENCE_DELIM_LINE_BREAK, "")
						.replaceAll(REFERENCE_DELIM_COMMA, "") + REFERENCE_CLOSE_PATTERN;
				if (!( reference.equals(">") || reference.equals("<") || reference.equals("null")
						|| reference.equals("null>") || reference.equals("<null") || reference.equals("<null>"))) {
					referencesArrayList.add(reference);
				}

			}
			Object[] refObjArray = referencesArrayList.toArray();
			stringArray = Arrays.copyOf(refObjArray, refObjArray.length, String[].class);

			logger.debug("references incoming {} ,after split {} " , incomingEmailReferences,stringArray);
		}
		return stringArray;
	}

	
	public static String getLatestReference(String references) {
		String latestReference = "";
		if (references != null) {
			String[] referencesArray = references.replaceAll(" ", "").split("\r\n");
			if (referencesArray != null && referencesArray.length > 0) {
				latestReference = referencesArray[referencesArray.length - 1];
				if (latestReference != null) {
					String[] referencesArrayTemp = latestReference.replaceAll(" ", "").split(">");

					if (referencesArrayTemp != null && referencesArrayTemp.length > 1) {

						for (int i = 0; i < referencesArrayTemp.length; i++) {
							logger.debug("References array item  at  {} ::: {} " ,i, referencesArrayTemp[i]);
							referencesArrayTemp[i] = referencesArrayTemp[i] + ">";
						}

						latestReference = referencesArrayTemp[referencesArrayTemp.length - 1];
					}

				}

			}
		}
		return latestReference;
	}

	/*
	 * 
	 * Check whether email sent from QMA Mail servers based on email reference
	 * and servers configured in each environment
	 * 
	 */
	public static boolean isEmailFromQMAServer(InquiryMail inquiryMail) {
		logger.debug("MessageID = {}", inquiryMail.getEnvelope().getMessageId());
		return isEmailFromQMAServer(inquiryMail.getEnvelope().getMessageId());
	}
	
	public static boolean isEmailFromQMAServer(String messageId) {
		Boolean emailFromQMA = Boolean.TRUE;
		List<String> qmaMailServers =QMACacheFactory.getCache().getQmaMailServers();
		logger.debug("isEmailFromQMAServer with config = {}, for messageID = {}",qmaMailServers, messageId);
		if (!(qmaMailServers == null || qmaMailServers.isEmpty() || StringUtils.isBlank(messageId))) {
			emailFromQMA = Boolean.FALSE;
			for (String mailServerHost : qmaMailServers) {
				if (messageId.endsWith("@" + mailServerHost + ">")) {
					emailFromQMA = Boolean.TRUE;
					break;
				}
			}
			logger.debug("isEmailFromQMAServer with config = {}, latestReference = {}, emailFromQMA = {} ",qmaMailServers, messageId, emailFromQMA);
		}
		return emailFromQMA;
	} 
	
	public static boolean shouldProcessForLocalDebug(Message message) {
		boolean bProcess = true;
		try {
			// -Dtest.env=local -Dtest.user=XXXXXX
			String testEnv = System.getProperty("test.env");
			if (testEnv != null && StringUtils.isNotBlank(testEnv) && "local".equals(testEnv)) {
				bProcess = false;
				String testUsr = System.getProperty("test.user");
				if (testUsr != null) {
					 String fromAddress = message.getFrom()[0].toString();
					String[] usersArray = testUsr.split(",");
					for (String usrString : usersArray) {
						if (null != fromAddress && fromAddress.contains(usrString)) {
							bProcess = true;
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error in shouldProcessForLocalDebug " , e);
		}
		return bProcess;
	}
	
	/**
     * This function identifies valid list of group Id's from list of recipients for TO and CC
     * @param recipients
     * @return List<Long>
     */
	public static List<Long> getValidToCCGroupIdListFromRecipients(List<ConversationRecipient> recipients) {
		List<Long> validToCcGroupIdList = new ArrayList<>();
		if(recipients!=null && !recipients.isEmpty()){
			for(ConversationRecipient currentRecipient : recipients){
				if(null != currentRecipient.getGroupId() && (QmaMailConstants.STRING_TO.equalsIgnoreCase(currentRecipient.getToFrom()) 
						|| QmaMailConstants.STRING_CC.equalsIgnoreCase(currentRecipient.getToFrom()))) {
					validToCcGroupIdList.add(currentRecipient.getGroupId());
				}
			}
		}
		return validToCcGroupIdList;
	}
	
	public static String getLastReference(String references, Logger subLogger)
	{
		String latestReference = "";
		try {
			if (references != null)
			{
				String[] referencesArray = references.replaceAll(" ", "").split("\r\n");
				if (referencesArray != null && referencesArray.length > 1)
				{
					latestReference = referencesArray[referencesArray.length - 2];
					if (latestReference != null)
					{
						String[] referencesArrayTemp = latestReference.replaceAll(" ", "").split(">");

						if (referencesArrayTemp != null && referencesArrayTemp.length > 2)
						{

							for (int i = 0; i < referencesArrayTemp.length; i++)
							{
								referencesArrayTemp[i] = referencesArrayTemp[i] + ">";
							}

							latestReference = referencesArrayTemp[referencesArrayTemp.length - 2];
						}

					}

				}
			}
		} catch (Exception e) {
			subLogger.error("Exception while getting last reference of message in getLastReference ", e);
		}
		return latestReference;
	}

	public static String sanitizeEmailHeader(String strHeader, Map<String,String> subPreFixPatternMap) {
		logger.debug("Inside MailServiceGenericUtil.sanitizeEmailHeader method with subject: {};, regEx size:{}", strHeader, subPreFixPatternMap.size());
		try {
			boolean matchOrExistCriteriaMet=true;
			int matchIteration = 0;
			int maxMatchIteration = 5;
			do {
				if (null != strHeader && null != subPreFixPatternMap) {
					strHeader = strHeader.trim();
					String transportHdrRegex = subPreFixPatternMap.get("TRANSPORT_HDR_REGEX");
					Map<String, String> result = trimPatternMultiLineCaseInsensitive(strHeader, transportHdrRegex);
					boolean transportHdrMatch = "Y".equalsIgnoreCase(result.get("isMatched")) ? true : false;
					strHeader = result.get("strSubject");
					String commonPatternRegex = subPreFixPatternMap.get("COMMON_PREFIX_REGEX");
					result = trimPatternMultiLineCaseInsensitive(strHeader, commonPatternRegex);
					boolean commonPatternMatch = "Y".equalsIgnoreCase(result.get("isMatched")) ? true : false;
					strHeader = result.get("strSubject");
					String subjectPrefixRegex = subPreFixPatternMap.get("SUB_PREFIX_REGEX");
					result = trimPatternMultiLineCaseInsensitive(strHeader, subjectPrefixRegex);
					boolean subPrefixMatch = "Y".equalsIgnoreCase(result.get("isMatched")) ? true : false;
					strHeader = result.get("strSubject");
					matchIteration++;
					// If match or max retry completed, then return else repeat
					boolean noMatch = !transportHdrMatch && !commonPatternMatch && !subPrefixMatch;
					matchOrExistCriteriaMet = noMatch ? true : (matchIteration >= maxMatchIteration);
				}
			} while (!matchOrExistCriteriaMet);
			logger.info("After replaceAll subject: {};, matchIteration: {}", strHeader,matchIteration);
		} catch (Exception e) {
			logger.warn("Error while sanitizeEmailHeader:{}", strHeader, e);
		}
		return strHeader;
	}

	private static Map<String, String> trimPatternMultiLineCaseInsensitive(String strSubject,String regEx) {
		Pattern sqPattern = Pattern.compile(regEx, Pattern.MULTILINE | Pattern.CASE_INSENSITIVE);
		   Matcher matcher = sqPattern.matcher(strSubject.trim());
		   boolean matched=matcher.find();
		   strSubject = matcher.replaceAll("");
		   Map<String, String> result=new HashMap<>();
		   result.put("isMatched",(matched)?"Y":"N");
		   result.put("strSubject",strSubject);
		   return result;
	}
	public static boolean sanitizeAndMatchSubject(String existingSubject,String newMailSubject,Map<String,String> subPreFixMap, String matchOp) {
		existingSubject = sanitizeEmailHeader(existingSubject, subPreFixMap);
		newMailSubject = sanitizeEmailHeader(newMailSubject, subPreFixMap);
		logger.debug("Inside MailServiceGenericUtil.sanitizeAndMatchSubject method after sanitization existing subject: {};, matchOp:{}",existingSubject, matchOp);
		logger.debug("And newMail subject: {};", newMailSubject);
		boolean isSubMatched = false;
		if (existingSubject == null && newMailSubject == null) {
			isSubMatched = true;
		} else if (existingSubject != null && newMailSubject != null){
			if(EQ.equalsIgnoreCase(matchOp)) {
				logger.debug("Inside MailServiceGenericUtil.sanitizeAndMatchSubject#eq method after sanitization existing subject: {};, matchOp:{}",existingSubject, matchOp);
				logger.debug("And newMail subject: {};", newMailSubject);
				isSubMatched = newMailSubject.trim().equalsIgnoreCase(existingSubject.trim());
			}
			else if(ENDS_WITH.equalsIgnoreCase(matchOp))	{
				isSubMatched = newMailSubject.toLowerCase().trim().endsWith(existingSubject.toLowerCase().trim());
			}
		}
		return isSubMatched;
	}
}