package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

import dev.morphia.annotations.Embedded;
import dev.morphia.annotations.Transient;

@Embedded
public class ConversationRecipient implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2266365155998462474L;
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private String emailAddr;
	private Long groupId;
	private String userId;
	private String displayName;
	private String toFrom;
	@Transient
	private String displayUserName;
	
	public ConversationRecipient()
	{

	}

	public ConversationRecipient(String emailAddr, Long groupId, String userId, String displayName, String toFrom)
	{
		super();
		this.emailAddr = emailAddr;
		this.groupId = groupId;
		this.userId = userId;
		this.displayName = displayName;
		this.toFrom = toFrom;
	}

	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getToFrom() {
		return toFrom;
	}

	public void setToFrom(String toFrom) {
		this.toFrom = toFrom;
	}
	public String getDisplayUserName() {
		return displayUserName;
	}

	public void setDisplayUserName(String displayUserName) {
		this.displayUserName = displayUserName;
	}

	/*
	 * This toString method is required. This is used while loading data to solr, to avoid a iteration over the list of recipients.
	 */
	@Override
	public String toString() {
		return "ConversationRecipient [emailAddr=" + emailAddr + ", groupId=" + groupId + ", userId=" + userId
				+ ", displayName=" + displayName + ", toFrom=" + toFrom + ", displayUserName=" + displayUserName + "]";
	}
	
	
}
