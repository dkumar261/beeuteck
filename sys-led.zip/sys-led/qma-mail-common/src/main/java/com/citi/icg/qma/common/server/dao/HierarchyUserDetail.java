package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

import dev.morphia.annotations.Embedded;

@Embedded
public class HierarchyUserDetail implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = -3002713831011840102L;
    private String userId;
    private String userName;
    private String emailId;
    private String geId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getGeId() {
        return geId;
    }

    public void setGeId(String geId) {
        this.geId = geId;
    }

}