package com.citi.icg.qma.common.server.util;

public class AmcResponse {

	private Integer responseCode;
	private String responseData;
	
	public AmcResponse(Integer responseCode) {
		this.responseCode = responseCode;
	}

	public Integer getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(Integer responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseData() {
		return responseData;
	}

	public void setResponseData(String responseData) {
		this.responseData = responseData;
	}
	
	
}
