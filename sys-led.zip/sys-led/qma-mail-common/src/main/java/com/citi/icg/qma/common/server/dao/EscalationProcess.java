package com.citi.icg.qma.common.server.dao;

import java.util.Date;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "EscalationProcess", noClassnameStored = true)
public class EscalationProcess
{

	@Id
	private String id;
	private Date threadStartTime ;
	private Date threadEndTime;
	private Long threadTotalProcessingTimeInMilliSeconds ;
	private Integer noOfGroupsHaveResponseTimeThreshold ;
	private Integer noOfInquiresFetched ;
	private Integer noOfWorkflowsEscalated;
	
	public Date getThreadStartTime()
	{
		return threadStartTime;
	}
	public void setThreadStartTime(Date threadStartTime)
	{
		this.threadStartTime = threadStartTime;
	}
	public Date getThreadEndTime()
	{
		return threadEndTime;
	}
	public void setThreadEndTime(Date threadEndTime)
	{
		this.threadEndTime = threadEndTime;
	}
	public Long getThreadTotalProcessingTimeInMilliSeconds()
	{
		return threadTotalProcessingTimeInMilliSeconds;
	}
	public void setThreadTotalProcessingTimeInMilliSeconds(Long threadTotalProcessingTimeInMilliSeconds)
	{
		this.threadTotalProcessingTimeInMilliSeconds = threadTotalProcessingTimeInMilliSeconds;
	}
	public Integer getNoOfInquiresFetched()
	{
		return noOfInquiresFetched;
	}
	public void setNoOfInquiresFetched(Integer noOfInquiresFetched)
	{
		this.noOfInquiresFetched = noOfInquiresFetched;
	}
	public Integer getNoOfWorkflowsEscalated()
	{
		return noOfWorkflowsEscalated;
	}
	public void setNoOfWorkflowsEscalated(Integer noOfWorkflowsEscalated)
	{
		this.noOfWorkflowsEscalated = noOfWorkflowsEscalated;
	}
	public Integer getNoOfGroupsHaveResponseTimeThreshold()
	{
		return noOfGroupsHaveResponseTimeThreshold;
	}
	public void setNoOfGroupsHaveResponseTimeThreshold(Integer noOfGroupsHaveResponseTimeThreshold)
	{
		this.noOfGroupsHaveResponseTimeThreshold = noOfGroupsHaveResponseTimeThreshold;
	}
	
	
}
