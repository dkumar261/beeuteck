package com.citi.icg.qma.common.server.dao.persistence;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.Workflow;
import com.mongodb.BasicDBObject;

public interface IInquiryActionStat
{
	public static final String UI_ACTION_ASSIGN_REQ_TYPE = "uiActionAssignReqType";
	public static final String UI_ACTION_ASSIGN_OWNER = "uiActionAssignOwner";
	public static final String EXT_SENDER_DOMAIN = "extSenderDomain";
	public static final String ACTION_AUTO_ASSIGN_REQ_TYPE = "actionAutoAssignReqType";
	public static final String ACTION_AUTO_ASSIGN_OWNER = "actionAutoAssignOwner";
	void updateInquiryActionStats(List<ConversationRecipient> recipientsList,  Inquiry inquiry, List<Workflow> workFlowList, Date currentTime, Map<Long, HashMap<String, String>> routingCriteriaMap) throws CommunicatorException;
	void bulkUpdateInquiryActionStats(Inquiry inquiry,String action, Date currentTime, Set<Long> groupIdList) throws CommunicatorException;
	boolean createInquiryActionStats(List<ConversationRecipient> recipientList, Inquiry dbInquiryInfo, List<Workflow> workFlowList, Date currentTime, String extSenderDomain, Map<Long, HashMap<String, String>> routingCriteriaMap) throws CommunicatorException;
}
