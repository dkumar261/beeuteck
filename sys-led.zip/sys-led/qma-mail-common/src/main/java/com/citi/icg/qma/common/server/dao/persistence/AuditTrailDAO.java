package com.citi.icg.qma.common.server.dao.persistence;

/**
 * 
 */
import java.net.InetAddress;

//import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.server.dao.UserActivities;

import com.citi.icg.qma.common.server.util.GenericUtility;

public class AuditTrailDAO {

	private static final Logger auditTrailLogger = LoggerFactory.getLogger(AuditTrailDAO.class);

	public static final String HEADER_PORTAL_LOGIN = "XXXXX";
	public static final String HEADER_ALT_PORTAL_LOGIN = "XXXXX";
	private static final String ORIGIN_KEY = "origin";
	public static final String REQUEST_ORIGIN_KEY = "request_origin";
	public static final String REQUEST_ORIGIN_QMA1 = "QMA1";
	public static final String REQUEST_ORIGIN_QMA2 = "QMA2";
	private static final String SEPARATOR = ":";

	/**
	 * This method extract and logs user information
	 * 
	 * @param request
	 * @param userActivity
	 */
	/*
	 * public void logUserInformation(UserActivities userActivity) { try {
	 * 
	 * logUserActivity(userActivity);
	 * 
	 * } catch (Exception e) {
	 * GenericUtility.logMethodGenericException(auditTrailLogger,
	 * "AuditTrailDAO#logUserInformation()", e); } }
	 */

	/**
	 * This method identifies if the request is QMA2 originated or not
	 * 
	 * @param request
	 * @param origin
	 * @return boolean
	 */
	/*
	 * public boolean checkIfQMA2Origin(HttpServletRequest request, String origin) {
	 * boolean isQMA2 = false; try { if ((null !=
	 * request.getHeader(REQUEST_ORIGIN_KEY) &&
	 * REQUEST_ORIGIN_QMA2.equalsIgnoreCase(request.getHeader(REQUEST_ORIGIN_KEY)))
	 * || (StringUtils.isNotEmpty(origin) && origin.contains(REQUEST_ORIGIN_QMA2)))
	 * { isQMA2 = true; } else {
	 * auditTrailLogger.info("Request not originated from QMA2."); } } catch
	 * (Exception e) { GenericUtility.logMethodGenericException(auditTrailLogger,
	 * "AuditTrailDAO#checkIfQMA2Origin()", e); } return isQMA2; }
	 */

	/**
	 * This method logs user activity when QMA is accessed by user.
	 * 
	 * @param request
	 * @param userActivity
	 *//*
		 * private void logUserActivity(UserActivities userActivity) { try { if(
		 * StringUtils.isNotEmpty(userActivity.getUserId()) ) { String userAgentString =
		 * getUserAgent(request); String requestOrigin = request.getHeader(ORIGIN_KEY);
		 * String requestUrl = request.getRequestURL().toString();
		 * if(StringUtils.isNotEmpty(userAgentString)) { String browser =
		 * getUserBrowser(userAgentString); String userOs = getUserOs(userAgentString);
		 * String requesterHost = getRequestHost(requestUrl,requestOrigin); String
		 * requestReceivedHost = getRequestReceivedHost(); String origin =
		 * checkIfQMA2Origin(request,requestOrigin) ? REQUEST_ORIGIN_QMA2 :
		 * REQUEST_ORIGIN_QMA1;
		 * logUserDetails(browser,userOs,requestReceivedHost,requesterHost,origin
		 * ,userActivity);
		 * 
		 * // C153176-5849 | Email as chat feature adoption audit information.
		 * logChatViewDetails(request, userActivity); } else {
		 * auditTrailLogger.info("user-agent not found for user :" +
		 * userActivity.getUserId()); } } else { auditTrailLogger.
		 * info("Not able to identify user information from request !!!"); } } catch
		 * (Exception e) { GenericUtility.logMethodGenericException(auditTrailLogger,
		 * "AuditTrailDAO#logUserActivity()", e); } }
		 */
	/**
	 * This method identifies request received host
	 * 
	 * @return String
	 */
	private String getRequestReceivedHost() {
		String requestReceivedHost = "";
		try {
			InetAddress hostNameAdd = InetAddress.getLocalHost();
			requestReceivedHost = null != hostNameAdd ? hostNameAdd.toString() : "";
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(auditTrailLogger, "AuditTrailDAO#getRequestReceivedHost()", e);
		}
		return requestReceivedHost;
	}

	/**
	 * This method gets user agent for request
	 * 
	 * @param request
	 * @return String
	 *//*
		 * private String getUserAgent(HttpServletRequest request) { String userAgent =
		 * null; try { userAgent = request.getHeader("User-Agent"); } catch (Exception
		 * e) { GenericUtility.logMethodGenericException(auditTrailLogger,
		 * "AuditTrailDAO#getUserAgent()", e); } return userAgent; }
		 */

	/**
	 * This method identifies user browser information
	 * 
	 * @param userAgent
	 * @return String
	 */
	private String getUserBrowser(String userAgent) {
		String browser = "";
		try {
			String user = userAgent.toLowerCase();
			if (user.contains("msie")) {
				String substring = userAgent.substring(userAgent.indexOf("MSIE")).split(";")[0];
				browser = substring.split(" ")[0].replace("MSIE", "IE") + " - v" + substring.split(" ")[1];
			} else if (user.contains("safari") && user.contains("version")) {
				browser = (userAgent.substring(userAgent.indexOf("Safari")).split(" ")[0]).split("/")[0] + " - v"
						+ (userAgent.substring(userAgent.indexOf("Version")).split(" ")[0]).split("/")[1];
			} else if (user.contains("opr") || user.contains("opera")) {
				if (user.contains("opera")) {
					browser = (userAgent.substring(userAgent.indexOf("Opera")).split(" ")[0]).split("/")[0] + " - v"
							+ (userAgent.substring(userAgent.indexOf("Version")).split(" ")[0]).split("/")[1];
				} else if (user.contains("opr")) {
					browser = ((userAgent.substring(userAgent.indexOf("OPR")).split(" ")[0]).replace("/", " - v"))
							.replace("OPR", "Opera");
				}
			} else if (user.contains("chrome")) {
				browser = (userAgent.substring(userAgent.indexOf("Chrome")).split(" ")[0]).replace("/", "-");
			} else if ((user.indexOf("mozilla/7.0") > -1) || (user.indexOf("netscape6") != -1)
					|| (user.indexOf("mozilla/4.7") != -1) || (user.indexOf("mozilla/4.78") != -1)
					|| (user.indexOf("mozilla/4.08") != -1) || (user.indexOf("mozilla/3") != -1)) {
				browser = "Netscape-?";
			} else if (user.contains("firefox")) {
				browser = (userAgent.substring(userAgent.indexOf("Firefox")).split(" ")[0]).replace("/", "-");
			} else if (user.contains("rv")) {
				browser = "IE-" + user.substring(user.indexOf("rv") + 3, user.indexOf(')'));
			} else {
				browser = "UnKnown, More-Info: " + userAgent;
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(auditTrailLogger, "AuditTrailDAO#getUserBrowser()", e);
		}
		return browser;
	}

	/**
	 * This method identifies user OS
	 * 
	 * @param userAgent
	 * @return String
	 */
	private String getUserOs(String userAgent) {
		String os = "";
		try {
			if (StringUtils.isNotEmpty(userAgent)) {
				if (userAgent.toLowerCase().indexOf("android") >= 0) {
					os = "Android";
				} else if (userAgent.toLowerCase().indexOf("iphone") >= 0) {
					os = "IPhone";
				} else if (userAgent.toLowerCase().indexOf("ipad") >= 0) {
					os = "iPad";
				} else if (userAgent.toLowerCase().indexOf("windows") >= 0) {
					os = "Windows";
				} else if (userAgent.toLowerCase().indexOf("mac") >= 0) {
					os = "Mac";
				} else if (userAgent.toLowerCase().indexOf("x11") >= 0) {
					os = "Unix";
				} else if (userAgent.toLowerCase().indexOf("linux") >= 0) {
					os = "Linux";
				} else {
					os = "UnKnown, More-Info: " + userAgent;
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(auditTrailLogger, "AuditTrailDAO#getUserOs()", e);
		}
		return os;
	}

	/**
	 * This method identifies requester host information
	 * 
	 * @param requestUrl
	 * @param requestOrigin
	 * @return String
	 */
	private String getRequestHost(String requestUrl, String requestOrigin) {
		String requestHost = requestOrigin;
		try {
			if (StringUtils.isEmpty(requestOrigin)) {
				String port = "";
				String[] parts = requestUrl.split(SEPARATOR);
				if (parts.length == 3) {
					port = parts[2].substring(0, parts[2].indexOf('/'));
				}
				requestHost = parts[0] + SEPARATOR + parts[1] + SEPARATOR + port;
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(auditTrailLogger, "AuditTrailDAO#getRequestHost()", e);
		}
		return requestHost;
	}

	/**
	 * This method logs user details in activity object
	 * 
	 * @param browser
	 * @param userOs
	 * @param requestReceivedHost
	 * @param requesterHost
	 * @param origin
	 * @param activity
	 */
	private void logUserDetails(String browser, String userOs, String requestReceivedHost, String requesterHost,
			String origin, UserActivities activity) {
		try {
			activity.setBrowser(browser);
			activity.setOs(userOs);
			activity.setRequestReceivedHost(requestReceivedHost);
			activity.setRequesterHost(requesterHost);
			activity.setOrigin(origin);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(auditTrailLogger, "AuditTrailDAO#logUserDetails()", e);
		}
	}

	/**
	 * This method gets the property value based on property name
	 * 
	 * @param request
	 * @param prop
	 * @return
	 */
	/*
	 * public String getRequestChannelProperty(HttpServletRequest request, String
	 * propName) { String propValue = null; try { if
	 * ("OS".equalsIgnoreCase(propName)) { String userAgentString =
	 * getUserAgent(request); if (StringUtils.isNotEmpty(userAgentString)) {
	 * propValue = getUserOs(userAgentString); } } } catch (Exception e) {
	 * GenericUtility.logMethodGenericException(auditTrailLogger,
	 * "AuditTrailDAO#getRequestProperty()", e); } return propValue; }
	 */

	/**
	 * Method to update the chat view related details to use activity.
	 * 
	 * @param request
	 * @param userActivity
	 */
	/*
	 * private void logChatViewDetails(HttpServletRequest request, UserActivities
	 * userActivity) { // C153176-5849 | Email as chat feature adoption audit
	 * information try { if (null !=
	 * request.getAttribute(AppserverConstants.VIEW_NAME) && null !=
	 * request.getAttribute(AppserverConstants.VIEW_TYPE)) { String viewName =
	 * (String) request.getAttribute(AppserverConstants.VIEW_NAME); String viewType
	 * = (String) request.getAttribute(AppserverConstants.VIEW_TYPE);
	 * 
	 * userActivity.setViewName(viewName); userActivity.setViewType(viewType); } }
	 * catch (Exception e) {
	 * GenericUtility.logMethodGenericException(auditTrailLogger,
	 * "AuditTrailDAO#logChatViewDetails()", e); } }
	 */
}
