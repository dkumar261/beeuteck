package com.citi.icg.qma.common.core.subscriber.mails.entity;

import java.io.IOException;
import java.util.List;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

public class Mail
{
	private List<NVPair> headers;
	private String content;

	public Mail(List<NVPair> headers, List<Content> contents) throws IOException
	{
		this.headers = headers;

		content = convertContentsToXML(contents);
	}

	public String getContent()
	{
		return content;
	}

	public List<NVPair> getHeaders()
	{
		return headers;
	}

	public String serialize()
	{
		XStream xstream = new XStream(new DomDriver());
		xstream.autodetectAnnotations(true);
		xstream.alias("mail", Mail.class);
		xstream.alias("nvpair", NVPair.class);

		return xstream.toXML(this);
	}

	private String convertContentsToXML(List<Content> contents) throws IOException
	{
		String xmlContent = "";
		for (Content contnt : contents)//Sonar Fix -- Rename "content" which hides the field declared
		{
			xmlContent = xmlContent + "ContentType : " + contnt.getType();
			xmlContent = xmlContent + contnt.getValue();
		}
		return xmlContent;
	}
}
