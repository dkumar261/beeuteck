package com.citi.icg.qma.config;

public class ConfluentKafkaConfig {

	private String brokerCluster;

	// the topic which qma-mail-reader produces to,
	// qma-mail-controller consumes from
	private String controllerTopic;

	// Topic which wma-mail-controller produces to,
	// qma-mail-processor consumes from
	private String processorTopic;

	// Topic which qma-mail-reader produces to for snapshot
	private String snapshotTopic;
	
	private String controllerSpoutConsumerGroup;
	private String processorSpoutConsumerGroup;
	
	private String sslKeyStoreLocation;
	private String sslKeyStorePassword;
	private String sslTrustStoreLocation;
	private String sslTrustStorePassword;
	private String sslEndpointIdentificationAlgorithm;
	private String kafkaProtocol;
	private boolean sslEnabled;

	public String getBrokerCluster() {
		return brokerCluster;
	}

	public void setBrokerCluster(String brokerCluster) {
		this.brokerCluster = brokerCluster;
	}

	public String getControllerTopic() {
		return controllerTopic;
	}

	public void setControllerTopic(String controllerTopic) {
		this.controllerTopic = controllerTopic;
	}

	public String getProcessorTopic() {
		return processorTopic;
	}

	public void setProcessorTopic(String processorTopic) {
		this.processorTopic = processorTopic;
	}

	public String getSnapshotTopic() {
		return snapshotTopic;
	}

	public void setSnapshotTopic(String snapshotTopic) {
		this.snapshotTopic = snapshotTopic;
	}

	public String getProcessorSpoutConsumerGroup() {
		return processorSpoutConsumerGroup;
	}

	public void setProcessorSpoutConsumerGroup(String processorSpoutConsumerGroup) {
		this.processorSpoutConsumerGroup = processorSpoutConsumerGroup;
	}

	public String getControllerSpoutConsumerGroup() {
		return controllerSpoutConsumerGroup;
	}

	public void setControllerSpoutConsumerGroup(String controllerSpoutConsumerGroup) {
		this.controllerSpoutConsumerGroup = controllerSpoutConsumerGroup;
	}

	public String getSslKeyStoreLocation() {
		return sslKeyStoreLocation;
	}

	public void setSslKeyStoreLocation(String sslKeyStoreLocation) {
		this.sslKeyStoreLocation = sslKeyStoreLocation;
	}

	public String getSslKeyStorePassword() {
		return sslKeyStorePassword;
	}

	public void setSslKeyStorePassword(String sslKeyStorePassword) {
		this.sslKeyStorePassword = sslKeyStorePassword;
	}

	public String getSslTrustStoreLocation() {
		return sslTrustStoreLocation;
	}

	public void setSslTrustStoreLocation(String sslTrustStoreLocation) {
		this.sslTrustStoreLocation = sslTrustStoreLocation;
	}

	public String getSslTrustStorePassword() {
		return sslTrustStorePassword;
	}

	public void setSslTrustStorePassword(String sslTrustStorePassword) {
		this.sslTrustStorePassword = sslTrustStorePassword;
	}

	public String getSslEndpointIdentificationAlgorithm() {
		return sslEndpointIdentificationAlgorithm;
	}

	public void setSslEndpointIdentificationAlgorithm(String sslEndpointIdentificationAlgorithm) {
		this.sslEndpointIdentificationAlgorithm = sslEndpointIdentificationAlgorithm;
	}

	public String getKafkaProtocol() {
		return kafkaProtocol;
	}

	public void setKafkaProtocol(String kafkaProtocol) {
		this.kafkaProtocol = kafkaProtocol;
	}

	public boolean isSslEnabled() {
		return sslEnabled;
	}

	public void setSslEnabled(boolean sslEnabled) {
		this.sslEnabled = sslEnabled;
	}

}
