package com.citi.icg.qma.common.transferobject;

import java.util.List;

import com.citi.icg.qma.common.server.dao.UserNotifications;

public class UserNotificationsTO {
	
	private List<UserNotifications> userNotificationsList;

	
	public List<UserNotifications> getUserNotificationsList() {
		return userNotificationsList;
	}

	public void setUserNotificationsList(List<UserNotifications> userNotificationsList) {
		this.userNotificationsList = userNotificationsList;
	}
}
