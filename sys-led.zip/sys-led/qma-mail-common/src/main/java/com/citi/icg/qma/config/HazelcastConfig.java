package com.citi.icg.qma.config;

public class HazelcastConfig {

	private String hazelcastServerAddress[];
	private String managementCenterUrl;
	private String groupName;
	private String instanceName;
	
	private String hazelcastSecondClusterServerAddress[];
	private String secondClusterGroupName;
	
	public String getManagementCenterUrl() {
		return managementCenterUrl;
	}
	public void setManagementCenterUrl(String managementCenterUrl) {
		this.managementCenterUrl = managementCenterUrl;
	}
	public String[] getHazelcastServerAddress() {
		return hazelcastServerAddress;
	}
	public void setHazelcastServerAddress(String hazelcastServerAddress[]) {
		this.hazelcastServerAddress = hazelcastServerAddress;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getInstanceName() {
		return instanceName;
	}
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}
	public String[] getHazelcastSecondClusterServerAddress() {
		return hazelcastSecondClusterServerAddress;
	}
	public void setHazelcastSecondClusterServerAddress(String[] hazelcastSecondClusterServerAddress) {
		this.hazelcastSecondClusterServerAddress = hazelcastSecondClusterServerAddress;
	}
	public String getSecondClusterGroupName() {
		return secondClusterGroupName;
	}
	public void setSecondClusterGroupName(String secondClusterGroupName) {
		this.secondClusterGroupName = secondClusterGroupName;
	}
	
}
