package com.citi.icg.qma.performance.utils.verification;

import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dev.morphia.Datastore;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

import com.citi.icg.qma.dao.MessageSnapshot;


public class QueryAndCompareDocs {
	private static final Logger logger = LoggerFactory.getLogger(QueryAndCompareDocs.class);
	private static Datastore mongoUAT=DBHelper.getMongoUAT();
	public static void main(String[] args) throws IOException {
		
		int limit =500;
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date startDate = null,endDate = null;
		try {
			startDate = format.parse("2019/07/02");
			endDate = format.parse("2019/07/03");
			
		} catch (ParseException e1) {
		
		    logger.warn("ParseException ", e1);
		}
		logger.info("startDate: {}",startDate);
		logger.info("endDate: {}", endDate);
		
		List<MessageComparison> messComparList = null;
		try {
			
			messComparList = getMessageComparisonDocsForLastDay(startDate,endDate, limit);
		} catch (ParseException e) {
			logger.warn("exception: ", e);
		}
		for (MessageComparison messageComparison : messComparList) {
			
			//do matching for those not done
			messageComparison.setMatchingDetails(null);
			
			if(!(messageComparison.getDetailedStatus().equals(MessageComparison.MATCHING_DONE)))
			{
				messageComparison=CompareIndividualDoc.compare(messageComparison);
			}
		}
		
		//update list back to DB
		
		logger.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		int successCount=0;
		int failedCount=0;
		int partialSucessCount=0;
		int unknownCount=0;
		int totalCount=messComparList.size();
		int convSucCount=0;
		int wf=0;
		int wfa=0;
		int iq=0;
		String fileName="messCompare_"+Instant.now().toEpochMilli()+".txt";
		FileWriter fw=new FileWriter(fileName);
		try {
			for (MessageComparison messageComparison : messComparList) {
				String matchingStatus = messageComparison.getMatchingStatus();
				fw.write("id:"+messageComparison.getMessageId()+"\n");
				logger.info("id: {}" ,messageComparison.getMessageId());
				logger.info("matching status: {}",matchingStatus);
				fw.write("matching status:"+matchingStatus+" \n");
				if(matchingStatus.equals(MessageComparison.COMPLETE_MATCH)){
					successCount++;
				}else if(matchingStatus.equals(MessageComparison.FAILED_MATCH)){
					failedCount++;
				}else if(matchingStatus.equals(MessageComparison.PARTIAL_MATCH_PROD_MOVED_FORWARD)){
					partialSucessCount++;
				}else{
					unknownCount++;
				}
				messageComparison.getMatchingDetails().forEach(s->{
					try {
						fw.write(s);
						fw.write("\n");
					} catch (Exception e) {
						logger.warn("Exception: ",e);
					}
				});
				if(messageComparison.getMatchingDetails().contains("Conversation matching isSuccesful:true")){
					convSucCount++;
				}
				if(messageComparison.getMatchingDetails().contains("Workflow matched isSuccessful: true")){
					wf++;
				}
				if(messageComparison.getMatchingDetails().contains("WorkFlow audit matching isSuccesful:true")){
					wfa++;
				}
				if(messageComparison.getMatchingDetails().contains("Inquiry matching isSuccesful:true")){
					iq++;
				}
				fw.write("\n========================\n");
				
			}
		}catch (Exception e) {
			logger.info("Error occured",e);
		}finally {
			fw.close();
		}
			
				
		
		logger.info("\n\n\n");
		logger.info("Total Count: {}",totalCount);
		logger.info("Sucess COMPLETE_MATCH Count: {}",successCount);
		logger.info("Fail FAILED_MATCH Count: {}",failedCount);
		logger.info("Partial Sucess PARTIAL_MATCH_PROD_MOVED_FORWARD Count: {}",partialSucessCount);
		logger.info("Partial Sucess UNKNOWN Count: {}",unknownCount);
		logger.info("convSucCount: {}",convSucCount);
		logger.info("workflow success count: {}",wf);
		logger.info("workflowaudit success count: {}",wfa);
		logger.info("Inquiry success count: {}",iq);
		
		
		
	}
	
	private static void updateBackToDB(List<MessageComparison> messComparList) {
		for (MessageComparison mc : messComparList) {
			Query<MessageComparison> q = mongoUAT.createQuery(MessageComparison.class).field("_id").equal(mc.getMessageId());
			UpdateOperations<MessageComparison> uo = mongoUAT.createUpdateOperations(MessageComparison.class)
					.set("detailedStatus", mc.getDetailedStatus())
					.set("matchingStatus", mc.getMatchingStatus())
					.set("matchingDetails", mc.getMatchingDetails());
			
			mongoUAT.update(q,uo,false);
		}
		
	}

	private static List<MessageComparison> getMessageComparisonDocsForLastDay(Date startDate,Date endDate, int limit) throws ParseException {
		
		logger.info("startDate: {}", startDate);
		
		logger.info("endDate: {}",endDate);
//		long countOfSnaps = datastore.createQuery(MessageSnapshot.class)
//				 			.disableValidation()				 
//				 			.field("events.0.time").greaterThanOrEq(startDate)
//				 			.field("events.0.time").lessThan(endDate)
//				 			.countAll();		
//		logger.info("count of Snapshots for  = " + countOfSnaps);
		Query<MessageSnapshot> query  = mongoUAT.createQuery(MessageSnapshot.class)
												// .disableValidation()												 
												.field("createDate").greaterThanOrEq(startDate)
				 								.retrievedFields(true, "_id")								 		
				 								.field("createDate").lessThan(endDate)
												 .limit(limit);
												//.order("sentDate");
		
		logger.info("Query : [{}]",query);
		List<MessageSnapshot> snapshotsList = query.asList();
		List<String> snapshotMessageIds = snapshotsList.stream().map(MessageSnapshot::getMessageId).collect(Collectors.toList());;
		logger.info("Total messages found for above query = {}", snapshotMessageIds.size());		
		
		
		//get list of MesssageComparison
			Query<MessageComparison> q2=mongoUAT.find(MessageComparison.class)
					//.field("_id").equal("XXX");
					.field("newSynced").equal(true)
					.field("oldSynced").equal(true)
					.field("_id").in(snapshotMessageIds);
					//.limit(limit);

			List<MessageComparison> messComparList=q2.asList();
			return messComparList;
	}
	
}
