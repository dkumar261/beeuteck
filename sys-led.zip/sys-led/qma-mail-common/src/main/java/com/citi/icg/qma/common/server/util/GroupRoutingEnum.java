package com.citi.icg.qma.common.server.util;

public enum GroupRoutingEnum
{
	CONTAINS("Contains"),
	BEGINSWITH("Begins With"),
	EQUALS("Equal"),
	NOTEQUALS("Not Equal"),
	NOTCONTAINS("Not Contains"); //Jira  /*[C153176-1458] - Adding 'Not Contains' criteria for InquiryRules*/

	
	private String routingOperator;

    private GroupRoutingEnum(String routingOperator) {
        this.routingOperator = routingOperator;
    }

    public String getName() {
        return routingOperator;
    }
    
    public static GroupRoutingEnum fromString(String routingOperator) {
        for (GroupRoutingEnum b : GroupRoutingEnum.values()) {
          if (b.routingOperator.equalsIgnoreCase(routingOperator)) {
            return b;
          }
        }
        return null;
      }
    @Override
    public String toString() {
        return routingOperator;
    }

}
