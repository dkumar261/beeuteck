package com.citi.icg.qma.common.server.dao.persistence;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.server.dao.Attachment;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.NotificationTypeEnum;
import com.citi.icg.qma.common.server.dao.UserNotificationEmails;

import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.common.transferobject.ConversationTO;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.WriteConcern;

import dev.morphia.Morphia;
import dev.morphia.mapping.Mapper;
import dev.morphia.query.Query;

/*
 * rsisodiya
 * 
 */
public class InquiryUserNotificationDao extends MongoMorphiaDAO
{
	private static final Logger subLogger = LoggerFactory.getLogger(InquiryUserNotificationDao.class);
	private InquiryCommonDAO inquiryCommonDAO = new InquiryCommonDAO();
	public boolean addNotification(String soeId, BasicDBObject inputJsonObj, String action, String editorContent) throws CommunicatorException
	{
		boolean isNotificationAdded = false;
		if (NotificationTypeEnum.USERFEEDBACK.toString().equals(action))
		{
			isNotificationAdded = addUserFeedbackNotification(soeId, inputJsonObj, NotificationTypeEnum.USERFEEDBACK, editorContent);
		}
		if (NotificationTypeEnum.USERNOTIFICATION.toString().equals(action))
		{
			isNotificationAdded = addUserNotification(soeId, inputJsonObj, NotificationTypeEnum.USERNOTIFICATION);
		}
		return isNotificationAdded;
	}

	/*
	 * Method for handling the user notifications
	 */
	public boolean addUserNotification(String soeId, BasicDBObject inputJsonObj, NotificationTypeEnum notificationType) throws CommunicatorException
	{
		Long inquiryId = GenericUtility.getIdFromRequest(inputJsonObj, "inquiryId");
		Long conversationId = GenericUtility.getIdFromRequest(inputJsonObj, "conversationId");
		String notificationFrom = inputJsonObj.getString("notificationFrom");
		String errorReason;
		subLogger.info("addUserNotification - Started for inquiryId: " + inquiryId + "; conversationId: " + conversationId + "; notificationFrom: " + notificationFrom);

		if (inquiryId == null || conversationId == null || StringUtils.isBlank(notificationFrom))
		{
			errorReason = "ERROR in addUserNotification - Invalid notification params- inquiryId: " + inquiryId + "; conversationId: " + conversationId + "; notificationFrom: " + notificationFrom;
			subLogger.error(errorReason);
			throw new CommunicatorException(errorReason);
		}

		boolean isValidNotification = validateConversationDetailsForNotification(inquiryId, conversationId);

		if (isValidNotification)
		{
			String notificationSubject = inputJsonObj.getString("notificationSubject");
			String notificationTo = inputJsonObj.getString("notificationTo");
			if (null != notificationFrom && null != notificationTo)
			{
				String[] recipients = notificationTo.split(";");
				List<DBObject> userNotificationList = createBulkUserNotifications(inquiryId, conversationId, notificationFrom, notificationSubject, recipients, notificationType);
				subLogger.info("addUserNotification - user notification list created : " + userNotificationList.size());
			}
		}
		else
		{
			subLogger.info("Invalid input conversation details. Ignoring notification.");
		}

		return isValidNotification;
	}

	/*
	 * Method to add user feedback notifications.
	 */
	public boolean addUserFeedbackNotification(String soeId, BasicDBObject inputJsonObj, NotificationTypeEnum notificationType, String editorContent) throws CommunicatorException
	{
		String notificationFrom = inputJsonObj.getString("notificationFrom");
		subLogger.info("addUserFeedbackNotification - Started " + "; notificationFrom: " + notificationFrom);
		String notificationSubject = inputJsonObj.getString("notificationSubject");
		String notificationTo = getFeedbackGrp();
		
		if (null != notificationFrom && null != notificationTo)
		{
			UserNotificationEmails notificationEntity = createNotificationEntity(null, null, notificationFrom, notificationSubject, notificationTo, notificationType);
			List<Attachment> attachmentList = getAttachmentsInfo(inputJsonObj);
			if (null != attachmentList && !attachmentList.isEmpty())
			{
				notificationEntity.setAttachments(attachmentList);
			}
			// Inline Images within draft
			String cntn = GenericUtility.updateContentWithImages(editorContent, soeId);
			notificationEntity.setFeedbackContent(cntn);
			Long notificationId = persist(notificationEntity);
			subLogger.info("addUserFeedbackNotification - user notification feedback record creaed : " + notificationId);
		}

		return true;
	}

	/*
	 * Get feedback group form config.
	 */
			
	private String  getFeedbackGrp()
	{
		String feedbackGrpId = null;
		Query<Config> dbQuery = mongoDatastore.createQuery(Config.class);
		dbQuery.filter("id", "qmaFeedbackDl");
		dbQuery.limit(1);
		List<Config> configList = dbQuery.asList();
		Config feedbackDb = configList == null || configList.isEmpty() ? null : configList.get(0);
		// Ignore new web socket configuration if it's not present in Config collection in DB.
		if (null != feedbackDb)
		{
			feedbackGrpId = feedbackDb.getFeedbackDlId();
		}
		
		return feedbackGrpId;
	}

	/*
	 * Create notification entity for user feedback/notification
	 */
	private UserNotificationEmails createNotificationEntity(Long inquiryId, Long conversationId, String notificationFrom, String notificationSubject, String recipient,
			NotificationTypeEnum notificationType)
	{
		Date d = new Date();
		UserNotificationEmails notificationEntity = new UserNotificationEmails();
		notificationEntity.setReferences(null);
		notificationEntity.setMessageId(null);
		notificationEntity.setInquiryId(inquiryId);
		notificationEntity.setConversationId(conversationId);
		notificationEntity.setNotificationFrom(notificationFrom);
		notificationEntity.setNotificationSubject(notificationSubject);
		notificationEntity.setNotificationRecipient(recipient.trim());
		notificationEntity.setNotificationType(notificationType.toString());
		notificationEntity.setProcessed(AppserverConstants.N);
		notificationEntity.setDirection("EXTERNAL");
		notificationEntity.setModDate(d);
		notificationEntity.setCrtDate(d);
		return notificationEntity;
	}

	/*
	 * Method to validate conversations
	 */
	private boolean validateConversationDetailsForNotification(Long inquiryId, Long conversationId) throws CommunicatorException
	{
		boolean isValidNotification = true;
		ConversationTO dbConversation = inquiryCommonDAO.getInquiryConversationById(conversationId);

		if (dbConversation == null || (CollectionUtils.isEmpty(dbConversation.getConversationList())))
		{
			subLogger.info("Conversation not found for conversationId: " + conversationId);
			isValidNotification = false;
		}
		else if (!inquiryId.equals(dbConversation.getConversationList().get(0).getInquiryId()))
		{
			subLogger.info(
					"Input_inquiryId: " + inquiryId + " doesnt match with db_inquiryId: " + dbConversation.getConversationList().get(0).getInquiryId() + " for conversationId: " + conversationId);
			isValidNotification = false;
		}
		return isValidNotification;
	}

	private List<Attachment> getAttachmentsInfo(BasicDBObject inputJsonObj)
	{
		List<Attachment> attachmentList = null;
		if (null != inputJsonObj.getString("attachment"))
		{
			JSONArray jsArray = new JSONArray(inputJsonObj.getString("attachment"));
			attachmentList = new ArrayList<>();
			subLogger.info("Attachment Size: " + jsArray.length() + jsArray);
			for (int i = 0; i < jsArray.length(); i++)
			{
				JSONObject jsonObj = jsArray.getJSONObject(i);
				if (!jsonObj.isNull("name") && !jsonObj.isNull("id"))
				{
					if (jsonObj.isNull("secure"))
					{
						Attachment attch = new Attachment(jsonObj.getString("name"), jsonObj.getString("id"));
						attachmentList.add(attch);
					}
					else
					{
						Attachment attch = new Attachment(jsonObj.getString("name"), jsonObj.getString("id"), jsonObj.getString("secure"));
						attachmentList.add(attch);
					}
				}

			}
		}

		return attachmentList;
	}

	private List<DBObject> createBulkUserNotifications(Long inquiryId, Long conversationId, String notificationFrom, String notificationSubject, String[] recipients,
			NotificationTypeEnum notificationType) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a
	{
		Morphia morphia = new Morphia();
		Mapper mapper = morphia.getMapper();
		List<DBObject> userNotificationList = new ArrayList<>();
		DBCollection userNotification = mongoDatastore.getCollection(UserNotificationEmails.class);

		for (String recipient : recipients)
		{
			if (null != recipient)
			{
				UserNotificationEmails notification = createNotificationEntity(inquiryId, conversationId, notificationFrom, notificationSubject, recipient, notificationType);
				userNotificationList.add(mapper.toDBObject(notification));
			}
		}
		userNotification.insert(userNotificationList, WriteConcern.ACKNOWLEDGED);
		return userNotificationList;
	}
}
