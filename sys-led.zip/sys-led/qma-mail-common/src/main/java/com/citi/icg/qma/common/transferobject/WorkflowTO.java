package com.citi.icg.qma.common.transferobject;

import java.util.List;

import com.citi.icg.qma.common.server.dao.Workflow;

public class WorkflowTO
{
	private List<Workflow> workflowList;


	public WorkflowTO()
	{

	}

	public WorkflowTO(List<Workflow> workflowList)
	{
		super();
		this.workflowList = workflowList;
	}

	public List<Workflow> getWorkflowList() {
		return workflowList;
	}

	public void setWorkflowList(List<Workflow> workflowList) {
		this.workflowList = workflowList;
	}

	
}
