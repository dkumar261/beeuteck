package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Embedded;

@Embedded
public class ExternalEmail
{
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	//Sonar fix -- rename the field so not to hide the name of class
	private String extEmail;

	public String getExternalEmail() {
		return extEmail;
	}

	public void setExternalEmail(String externalEmail) {
		this.extEmail = externalEmail;
	}
}
