package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

public class OrgMetaDataAdminRole implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8859978086123725613L;
	private Long orgId;
	private String orgName;
	private Date crtDate;
	private String crtBy;

	public OrgMetaDataAdminRole() {

	}

	public OrgMetaDataAdminRole(Long orgId, String orgName, Date crtDate, String crtBy) {
		super();
		this.orgId = orgId;
		this.orgName = orgName;
		this.crtDate = crtDate;
		this.crtBy = crtBy;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public Date getCrtDate() {
		return crtDate;
	}

	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

}
