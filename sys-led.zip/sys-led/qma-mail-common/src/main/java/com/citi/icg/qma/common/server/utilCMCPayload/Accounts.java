package com.citi.icg.qma.common.server.utilCMCPayload;

public class Accounts
{
    private String accountNumber;

    public String getAccountNumber ()
    {
        return accountNumber;
    }

    public void setAccountNumber (String accountNumber)
    {
        this.accountNumber = accountNumber;
    }

    @Override
    public String toString()
    {
        return "InputForCMC [accountNumber = "+accountNumber+"]";
    }
}
			
	