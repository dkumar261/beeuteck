package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.List;

import dev.morphia.annotations.Embedded;

@Embedded
public class ViewConfig implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 528670268822798588L;

	private String viewName;

	@Embedded
	private List<ColumnDef> columnsToShow;
	@Embedded
	private List<ColumnDef> groupByColumns;
	@Embedded
	private List<ColumnDef> orderByColumns;

	public ViewConfig()
	{
		super();
	}

	// TODO: SUNIL 10 August, this data in db has to be migrate again for right data types, earlier String now BasicDBObject.
	// commented to run Query..
	// Rollied back to BasicDBObject to String, bcoz of MongoDB issue with version2.8 12 Aug : Sunil
	private String criteria;
	private String groupCriteria; // we can remove this.. Not required .. Later SUNIL 12 AUGUST
    private String defaultCriteria; ///[C153176-160] changes for saved search with work flow Criteria query
	public ViewConfig(String viewName, List<ColumnDef> columnsToShow, List<ColumnDef> groupByColumns, List<ColumnDef> orderByColumns,
			String groupCriteria)
	{
		super();
		this.setViewName(viewName);
		this.setColumnsToShow(columnsToShow);
		this.groupByColumns = groupByColumns;
		this.setOrderByColumns(orderByColumns);
		this.groupCriteria = groupCriteria;
	}

	public List<ColumnDef> getColumnsToShow() {
		return columnsToShow;
	}

	public void setColumnsToShow(List<ColumnDef> columnsToShow) {
		this.columnsToShow = columnsToShow;
	}

	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public List<ColumnDef> getOrderByColumns() {
		return orderByColumns;
	}

	public void setOrderByColumns(List<ColumnDef> orderByColumns) {
		this.orderByColumns = orderByColumns;
	}

	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}

	public String getGroupCriteria() {
		return groupCriteria;
	}

	public void setGroupCriteria(String groupCriteria) {
		this.groupCriteria = groupCriteria;
	}

	public String getDefaultCriteria()
	{
		return defaultCriteria;
	}

	public void setDefaultCriteria(String defaultCriteria)
	{
		this.defaultCriteria = defaultCriteria;
	}
	
	

}
