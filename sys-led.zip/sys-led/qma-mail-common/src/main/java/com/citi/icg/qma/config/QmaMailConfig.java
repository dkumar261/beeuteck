package com.citi.icg.qma.config;

public class QmaMailConfig {
	
	private MongoDBConfig mongoDBConfig;
	private ConfluentKafkaConfig confluentKafkaConfig;
	private String topologyHomeDir;
	private String mongoCertsLocation;
	private HazelcastConfig hazelcastConfig;
	private int readerbatchSize;
	private boolean readerDeleteMessages;
	private MessageBusConfig messageBusConfig;
	private boolean referencePlusSubThreading;
	private String MBOX;
	private String AZURE_CLIENT_ID;
	private String AZURE_CLIENT_SECRET;
	private String EX_SERVER_AUTHORITY_URL;
	private String AZURE_SCOPE;

	public String getMBOX() {
		return MBOX;
	}

	public void setMBOX(String MBOX) {
		this.MBOX = MBOX;
	}

	public String getAZURE_CLIENT_ID() {
		return AZURE_CLIENT_ID;
	}

	public void setAZURE_CLIENT_ID(String AZURE_CLIENT_ID) {
		this.AZURE_CLIENT_ID = AZURE_CLIENT_ID;
	}

	public String getAZURE_CLIENT_SECRET() {
		return AZURE_CLIENT_SECRET;
	}

	public void setAZURE_CLIENT_SECRET(String AZURE_CLIENT_SECRET) {
		this.AZURE_CLIENT_SECRET = AZURE_CLIENT_SECRET;
	}

	public String getEX_SERVER_AUTHORITY_URL() {
		return EX_SERVER_AUTHORITY_URL;
	}

	public void setEX_SERVER_AUTHORITY_URL(String EX_SERVER_AUTHORITY_URL) {
		this.EX_SERVER_AUTHORITY_URL = EX_SERVER_AUTHORITY_URL;
	}

	public String getAZURE_SCOPE() {
		return AZURE_SCOPE;
	}

	public void setAZURE_SCOPE(String AZURE_SCOPE) {
		this.AZURE_SCOPE = AZURE_SCOPE;
	}

	public MongoDBConfig getMongoDBConfig() {
		return mongoDBConfig;
	}
	public void setMongoDBConfig(MongoDBConfig mongoDBConfig) {
		this.mongoDBConfig = mongoDBConfig;
	}
	public ConfluentKafkaConfig getConfluentKafkaConfig() {
		return confluentKafkaConfig;
	}
	public void setConfluentKafkaConfig(ConfluentKafkaConfig confluentKafkaConfig) {
		this.confluentKafkaConfig = confluentKafkaConfig;
	}
	
	public String getTopologyHomeDir() {
		return topologyHomeDir;
	}
	public void setTopologyHomeDir(String topologyHomeDir) {
		this.topologyHomeDir = topologyHomeDir;
	}
	public String getMongoCertsLocation() {
		return mongoCertsLocation;
	}
	public void setMongoCertsLocation(String mongoCertsLocation) {
		this.mongoCertsLocation = mongoCertsLocation;
	}
	public HazelcastConfig getHazelcastConfig() {
		return hazelcastConfig;
	}
	public void setHazelcastConfig(HazelcastConfig hazelcastConfig) {
		this.hazelcastConfig = hazelcastConfig;
	}
	public int getReaderbatchSize() {
		return readerbatchSize;
	}
	public void setReaderbatchSize(int readerbatchSize) {
		this.readerbatchSize = readerbatchSize;
	}
	public boolean getReaderDeleteMessages() {
		return readerDeleteMessages;
	}
	public void setReaderDeleteMessages(boolean readerDeleteMessages) {
		this.readerDeleteMessages = readerDeleteMessages;
	}
	public MessageBusConfig getMessageBusConfig() {
		return messageBusConfig;
	}
	public void setMessageBusConfig(MessageBusConfig messageBusConfig) {
		this.messageBusConfig = messageBusConfig;
	}
	public boolean isReferencePlusSubThreading() {
		return referencePlusSubThreading;
	}
	public void setReferencePlusSubThreading(boolean referencePlusSubThreading) {
		this.referencePlusSubThreading = referencePlusSubThreading;
	}

	
}
