/**
 * 
 */
package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

import dev.morphia.annotations.Embedded;

/**
 * 
 *
 */
@Embedded
public class Country implements Serializable {
	private String countryCode;
	private String countryName;
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	/**
	 * @return the countryName
	 */
	public String getCountryName() {
		return countryName;
	}
	/**
	 * @param countryName the countryName to set
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
}
