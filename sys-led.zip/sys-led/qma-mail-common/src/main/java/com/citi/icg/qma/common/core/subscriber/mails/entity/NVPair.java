package com.citi.icg.qma.common.core.subscriber.mails.entity;

public class NVPair
{

	private String name;
	private String value;

	public NVPair(String name, String value)
	{
		this.name = name;
		this.value = value;
	}

	public String getName()
	{
		return name;
	}

	public String getValue()
	{
		return value;
	}

	//Sonar fix -- use override annotation on overridden method
	@Override
	public String toString()
	{
		return name + " : " + value;
	}

	
	
	// added for kryo
	public void setName(String name) {
		this.name = name;
	}

	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * 
	 */
	public NVPair() {
		super();
	}
	
}
