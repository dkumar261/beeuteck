package com.citi.icg.qma.common.core.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LogUtil
{
	private static final Logger logger = LoggerFactory.getLogger(LogUtil.class);
	private LogUtil(){
		//As this class is Util, so added making private constructor.
		//Sonar Fix -- Utility classes should not have public constructors 
	}
	
	public static void loadLog4j()
	{
		//TODO: load if required
		//PropertyConfigurator.configure("config/log4j.properties");
	}
  
	public static void printTimeTaken(Object caller, String methodName, long startTime)
	{
	   logger.info(caller + "Time taken to [" + methodName + "] : " + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
	}
  
//	public static void printTimeTaken(Object caller, String methodName, long startTime, Logger logger
//			)
//	{
//	  GenericUtil.getLogger().info(caller + "  Time taken to [" + methodName + "] : " + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
//	}
}
