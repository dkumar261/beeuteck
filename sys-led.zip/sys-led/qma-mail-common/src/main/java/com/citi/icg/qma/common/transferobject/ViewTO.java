package com.citi.icg.qma.common.transferobject;

import java.util.List;

import com.citi.icg.qma.common.server.dao.ColumnDef;

public class ViewTO
{
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private String name;
	//Need columns field to show up in UserInfo data.
	private List<ColumnDef> columnsToShow;

	public ViewTO()
	{

	}

	public ViewTO(String name, List<ColumnDef> columnsToShow)
	{
		super();
		this.name = name;
		this.columnsToShow = columnsToShow;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<ColumnDef> getColumnsToShow()
	{
		return columnsToShow;
	}

	public void setColumnsToShow(List<ColumnDef> columnsToShow)
	{
		this.columnsToShow = columnsToShow;
	}
}
