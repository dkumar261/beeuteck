package com.citi.icg.qma.common.server.dao.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.utilCMCPayload.Clients;
import com.citi.icg.qma.common.server.utilCMCPayload.InputForCMC;
import com.citi.icg.qma.common.transferobject.CMCSearchCriteriaTO;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;

public class CMCDAO
{

	private static final Logger subLogger = LoggerFactory.getLogger(CMCDAO.class);
	private static final String CONFIG_CMC_CONFIGURATION_KEY = "cmcConfiguration";
	private static Map<String, Object> cmcConfig;
	private static final String CONTACTS = "contacts";
	private static final String CLIENTS = "clients";
	private List<QMAContact> qmaContactList = new ArrayList<QMAContact>();
	private List<QMAContact> qmaContactListForClientID = new ArrayList<QMAContact>();
	private List<String> clientIDList = new ArrayList<String>();
	private String clientSecretKey;
	private String clientIdKey;
	private String url;
	private String contactGlobalUrl;
	private String enableGlobalContactSearch;//Y/N
	private String srcSys;
	private String clientUrl;
	private String searchContactLimit;
	private String offset;
	private static final UserActivitiesDAO user_Activities_Dao = new UserActivitiesDAO();
	private static final String CISATTRIBUTES_KEY = "cisAttributes";
	private static final String PRIORITY_KEY = "priority";
	private static final String SRC_SYS ="srcSys";
	private static final String LAST_NAME ="lastName";
	private static final String JOB_TITLES="jobTitles";
	private static final String FIRST_NAME="firstName";
	private static final String EMAIL="email";
	private static final String CLIENT_NAME="clientName";
	private static final String CLIENT_TYPE="clientIdType";
	private static final String CLIENT_ID="clientId";
	private static final String APPLICATION_JSON="application/json";

	static
	{
		try
		{
			if(null != QMACacheFactory.getCache().getConfigById(CONFIG_CMC_CONFIGURATION_KEY)) {
				Config configData = QMACacheFactory.getCache().getConfigById(CONFIG_CMC_CONFIGURATION_KEY);
				if (null != configData)
				{
					cmcConfig = configData.getCmcConfiguration();
				}
			}
		}
		catch (Exception e)
		{
			subLogger.error("Error while retrieving value for CMC config :", e);
		}
	}

	// Set search criteria inputs to transfer object
	public CMCSearchCriteriaTO getSearchCriteriaInput(BasicDBObject inputJsonObj)
	{
		return new CMCSearchCriteriaTO(inputJsonObj.getString(FIRST_NAME), inputJsonObj.getString(LAST_NAME), inputJsonObj.getString("contactEmail"), inputJsonObj.getString("jobTitle"),
				inputJsonObj.getString("clientIdentifierOption"), inputJsonObj.getString("clientIdentifierValue"), inputJsonObj.getString("toCcBcc"));
	}

	// Search using Client Name
	public List<String> getClientIDsUsingClientName(String soeId, String clientName) throws CommunicatorException
	{
		cmcSetConfig();
		JSONObject jsonResponseFromCMC = getResponseFromCMCForGetRequest(soeId, modifyURL(soeId, clientUrl + "?limit=" + searchContactLimit + "&name=" + clientName));
		return extractClientIDsFromCMCResponse(soeId, jsonResponseFromCMC);
	}
	/**
	 * Method will get all matching clients from CMC
	 * @param soeId
	 * @param clientName
	 * @return client priority Platinum/Gold/Silver/Bronze/No
	 * @throws CommunicatorException
	 */
	public String getClientPriorityUsingClientName(String soeId, String clientName) throws CommunicatorException
	{
		cmcSetConfig();
		JSONObject jsonResponseFromCMC = getResponseFromCMCForGetRequest(soeId, modifyURL(soeId, clientUrl + "/?limit=" + searchContactLimit + "&name=" + clientName));
		return extractClientPriorityFromCMCResponse(soeId, jsonResponseFromCMC, clientName);
	}

	/**
	 * Method will extract response from CMC
	 * @param soeId
	 * @param jsonResponseFromCMC
	 * @param clientName
	 * @return priority
	 * @throws CommunicatorException
	 */
	private String extractClientPriorityFromCMCResponse(String soeId, JSONObject jsonResponseFromCMC, String clientName)
			throws CommunicatorException {
		String clientPriority = "";
		try {
			JSONArray clientList;
			if (jsonResponseFromCMC.has(CLIENTS) && !jsonResponseFromCMC.isNull(CLIENTS)) {
				clientList = jsonResponseFromCMC.getJSONArray(CLIENTS);
				clientPriority = parseCMCResponseForClientPriority(clientList, clientName);
			} else {
				subLogger.debug("NO clients for the ClientName");
			}

		} catch (JSONException e) {
			subLogger.debug("Exception in extractClientPriorityFromCMCResponse for soeId = {}", soeId, e);
			throw new CommunicatorException("Exception in extractClientPriorityFromCMCResponse " + e);
		}
		return clientPriority;
	}

	/**
	 * Method will return priority for matching client name.
	 * @param clientList
	 * @param clientName
	 * @return
	 */
	private String parseCMCResponseForClientPriority(JSONArray clientList, String clientName) {
		String clientPriority = "";
		for (int clientCount = 0; clientCount < clientList.length(); clientCount++) {
			JSONObject client = clientList.getJSONObject(clientCount);
			String clientNameFromList = (String) client.get(CLIENT_NAME);
			if (clientNameFromList.equals(clientName) && client.has(CISATTRIBUTES_KEY) && !client.isNull(CISATTRIBUTES_KEY)) {// sonar fix Collapsible "if" statements should be merged
					JSONObject cisAttributes = client.getJSONObject(CISATTRIBUTES_KEY);
					if(null != cisAttributes && null !=  cisAttributes.get(PRIORITY_KEY)) {
					clientPriority = (String) cisAttributes.get(PRIORITY_KEY);
					}//sonar fix A conditionally executed single line should be denoted by indentation
				
			}
		}
		return clientPriority;
	}

	// getting contacts corresponding to all the searched clients of QMA
	public List<QMAContact> getContactListUsingClientIDList(String soeId, List<String> clientIDList, CMCSearchCriteriaTO cmcSearchCriteriaTO)
			throws CommunicatorException
	{
		qmaContactList.clear();
		for (int clientCount = 0; clientCount < clientIDList.size(); clientCount++)
		{
			cmcSearchCriteriaTO.setClientIdentifierOption("GP ID");
			cmcSearchCriteriaTO.setClientIdentifierValue(clientIDList.get(clientCount));
			List<QMAContact> tempContact = getContactListUsingSearchCriteria(soeId, cmcSearchCriteriaTO);
			if (!tempContact.isEmpty())
				qmaContactList.addAll(tempContact);
		}
		return qmaContactList;
	}

	// Search on the basis of first name, last name, gpid, email, management id
	public List<QMAContact> getContactListUsingSearchCriteria(String soeId, CMCSearchCriteriaTO cmcSearchCriteriaTO) throws CommunicatorException
	{
		cmcSetConfig();
		qmaContactListForClientID.clear();
		JSONObject payload = generatePayloadToSearchBySearchCriteria(soeId, cmcSearchCriteriaTO);
		JSONObject jsonResponseFromCMC = getResponseFromCMCForPostRequest(soeId, payload,true);
		return extractContactDetailsFromCMCResponse(soeId, jsonResponseFromCMC,true);
	}
	// Search on the basis of first name, last name, gpid, email, management id
	public QMAContact getContactFromGlobalSrcInCMC(String soeId, String contactEmail) throws CommunicatorException
		{
			QMAContact contact=null;
			cmcSetConfig();
			qmaContactListForClientID.clear();
			JSONObject payload=new JSONObject();
			payload.put(EMAIL, contactEmail);
			JSONObject jsonResponseFromCMC = getResponseFromCMCForPostRequest(soeId, payload,false);
			List<QMAContact> contactList=extractContactDetailsFromCMCResponse(soeId, jsonResponseFromCMC,false);
			if(contactList != null && !contactList.isEmpty()){
				contact=contactList.get(0);
			}
			return contact;
		}

	private void cmcSetConfig()
	{
		url = (String) cmcConfig.get("contact-url");
		contactGlobalUrl = (String) cmcConfig.get("contact-global-url");
		enableGlobalContactSearch = (String) cmcConfig.get("enableGlobalContactSearch");
		clientUrl = (String) cmcConfig.get("client-url");
		srcSys = (String) cmcConfig.get(SRC_SYS);
		clientIdKey = (String) cmcConfig.get("client-id");
		clientSecretKey = (String) cmcConfig.get("client-secret");
		searchContactLimit = (String) cmcConfig.get("searchContactLimit");
		offset = (String) cmcConfig.get("offset");
	}

	// Payload generation for search criteria
	private JSONObject generatePayloadToSearchBySearchCriteria(String soeId, CMCSearchCriteriaTO cmcSearchCriteriaTO) throws CommunicatorException
	{
		InputForCMC input = new InputForCMC();
		if (!StringUtils.isBlank(cmcSearchCriteriaTO.getFirstName() + " " + cmcSearchCriteriaTO.getLastName()))
			input.setName(cmcSearchCriteriaTO.getFirstName() + " " + cmcSearchCriteriaTO.getLastName());
		if (!StringUtils.isBlank(cmcSearchCriteriaTO.getContactEmail()))
			input.setEmail(cmcSearchCriteriaTO.getContactEmail());
		if ("GP ID".equals(cmcSearchCriteriaTO.getClientIdentifierOption()) && !StringUtils.isBlank(cmcSearchCriteriaTO.getClientIdentifierValue()))
		{
			Clients client = new Clients();
			client.setClientId(cmcSearchCriteriaTO.getClientIdentifierValue());
			client.setClientIdType("gp");
			List<Clients> clients = new ArrayList<Clients>();
			clients.add(client);
			input.setClients(clients);
		}
		input.setSrcSys(srcSys);
		if ("Mgmt ID".equals(cmcSearchCriteriaTO.getClientIdentifierOption()) && !StringUtils.isBlank(cmcSearchCriteriaTO.getClientIdentifierValue()))
			input.setManagementId(cmcSearchCriteriaTO.getClientIdentifierValue());
		input.setIncludeDl("true");
		if ("Client Mnemonic".equals(cmcSearchCriteriaTO.getClientIdentifierOption()) && !StringUtils.isBlank(cmcSearchCriteriaTO.getClientIdentifierValue()))
			input.setMnemonic(cmcSearchCriteriaTO.getClientIdentifierValue());
		String jsonInString = null;
		try
		{
			jsonInString=DataConversionUtil.convertJavaObjectToJson(input);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in generatePayloadToSearchBySearchCriteria for soeId = {}", soeId, e);
			throw new CommunicatorException("Exception in generatePayloadToSearchBySearchCriteria " + e);
		}
		return new JSONObject(jsonInString);
	}

	// GET Request to get response of clients from CMC
	private JSONObject getResponseFromCMCForGetRequest(String soeId, String modifiedURL) throws CommunicatorException
	{
		HttpResponse response;
		String result = null;
		HttpClient httpClient = HttpClientBuilder.create().build();
		try
		{

			HttpGet request = new HttpGet(modifiedURL);
			request.setHeader("X-SrcSys", srcSys);
			request.setHeader("X-MW-SOEID", soeId);
			request.setHeader("accept", APPLICATION_JSON);
			request.setHeader("content-type", APPLICATION_JSON);
			request.setHeader("x-ibm-client-id", clientIdKey);
			request.setHeader("x-ibm-client-secret", clientSecretKey);

			response = httpClient.execute(request);
			subLogger.debug("Retreiving CMC data...");
			HttpEntity entity = response.getEntity();

			if (entity != null)
			{
				InputStream instream = entity.getContent();
				result = convertStreamToString(instream);
			}
		}
		catch (Exception e)
		{
			subLogger.debug("Exception in getResponseFromCMCForGetRequest for soeId = {}", soeId, e);
			throw new CommunicatorException("Exception in getResponseFromCMCForGetRequest " + e);
		}
		finally
		{
			httpClient.getConnectionManager().shutdown();
		}
		return new JSONObject(result);
	}

	// POST request to search on the basis of request payload
	private JSONObject getResponseFromCMCForPostRequest(String soeId, JSONObject requestPayload, boolean isQMADataSearch) throws CommunicatorException
	{
		HttpResponse response;
		String result = null;
		HttpClient httpClient = HttpClientBuilder.create().build();
		try
		{
			String contactSearchUrl=isQMADataSearch?url:(null==contactGlobalUrl?url:contactGlobalUrl);
			HttpPost request = new HttpPost(modifyURL(soeId, contactSearchUrl + "?limit=" + searchContactLimit + "&offset=" + offset));
			StringEntity params = new StringEntity(requestPayload.toString());
			request.setEntity(params);
			request.setHeader("X-SrcSys", srcSys);
			request.setHeader("X-MW-SOEID", soeId);
			request.setHeader("accept", APPLICATION_JSON);
			request.setHeader("content-type", APPLICATION_JSON);
			request.setHeader("x-ibm-client-id", clientIdKey);
			request.setHeader("x-ibm-client-secret", clientSecretKey);

			response = httpClient.execute(request);

			subLogger.info("Retreiving CMC data... from {}",contactSearchUrl);
			HttpEntity entity = response.getEntity();

			if (entity != null)
			{
				InputStream instream = entity.getContent();
				result = convertStreamToString(instream);
			}
		}
		catch (Exception e)
		{
			subLogger.debug("Exception in getResponseFromCMCForPostRequest for soeId = {}", soeId, e);
			throw new CommunicatorException("Exception in getResponseFromCMCForPostRequest " + e);
		}
		finally
		{
			httpClient.getConnectionManager().shutdown();
		}
		return new JSONObject(result);
	}

	// Extract clients list from CMC Response
	private List<String> extractClientIDsFromCMCResponse(String soeId, JSONObject jsonResponseFromCMC) throws CommunicatorException
	{
		clientIDList.clear();
		try
		{
			JSONArray clientList = null;
			if (jsonResponseFromCMC.has(CLIENTS) && !jsonResponseFromCMC.isNull(CLIENTS))
			{
				clientList = jsonResponseFromCMC.getJSONArray(CLIENTS);
				parseCMCResponseForClientIDs(clientList);
			}
			else
			{
				subLogger.debug("NO clients for the ClientName");
			}

		}
		catch (JSONException e)
		{
			subLogger.debug("Exception in getResponseFromCMCForGetRequest for soeId = {}", soeId, e);
			throw new CommunicatorException("Exception in getResponseFromCMCForGetRequest " + e);
		}
		return clientIDList;
	}

	// Extract contact list from CMC response
	private List<QMAContact> extractContactDetailsFromCMCResponse(String soeId, JSONObject jsonResponseFromCMC, boolean isQMADataSearch) throws CommunicatorException
	{
		try
		{
			JSONArray contactsList = new JSONArray();
			if (jsonResponseFromCMC.has(CONTACTS) && !jsonResponseFromCMC.isNull(CONTACTS))
			{
				contactsList = jsonResponseFromCMC.getJSONArray(CONTACTS);
				parseCMCResponse(contactsList,isQMADataSearch);
			}
			else
			{
				subLogger.debug("NO contacts for the combination of clientID and source system");
			}

		}
		catch (JSONException e)
		{
			subLogger.debug("Exception in extractDetailsFromCMCResponse for soeId = {} ", soeId, e);
			throw new CommunicatorException("Exception in extractDetailsFromCMCResponse " + e);
		}
		return qmaContactListForClientID;
	}

	// Parse the client list of QMA from the client list obtained from CMC
	private void parseCMCResponseForClientIDs(JSONArray clientList)
	{
		for (int clientCount = 0; clientCount < clientList.length(); clientCount++)
		{
			JSONObject client = clientList.getJSONObject(clientCount);
			if (client.getString(CLIENT_TYPE).equals("gp"))
				clientIDList.add(client.getString(CLIENT_ID));
		}
	}

	// Parse the contact list obtanied from CMC
	private void parseCMCResponse(JSONArray contactsList, boolean isQMADataSearch)
	{
		for (int contactCount = 0; contactCount < contactsList.length(); contactCount++)
		{
			JSONObject contact = contactsList.getJSONObject(contactCount);
			QMAContact qmaContact = setInitialEmptyQMAContact();
			if (!contact.isNull("srcSysAttributes"))
			{
				JSONObject srcSysAttributes = contact.getJSONObject("srcSysAttributes");
				if (!srcSysAttributes.isNull("managementInfo"))
				{
					JSONArray managementInfo = (JSONArray) srcSysAttributes.getJSONArray("managementInfo");
					String managementIdList = "";
					for (int i = 0; i < managementInfo.length(); i++)
					{
						JSONObject managementId = managementInfo.getJSONObject(i);
						if (managementIdList != null)
							managementIdList = managementIdList + managementId.get("id").toString() + ",";
					}
					qmaContact.setManagementId(managementIdList);
				}
				if (!srcSysAttributes.isNull("mnemonic"))
				{
					JSONArray mnemonic = (JSONArray) srcSysAttributes.getJSONArray("mnemonic");
					String mnemonicList = "";
					for (int i = 0; i < mnemonic.length(); i++)
					{
						if (mnemonicList != null)
							mnemonicList = mnemonicList + mnemonic.get(i) + ",";
					}
					qmaContact.setMnemonic(mnemonicList);
				}
			}

			if (!contact.isNull("alternateNames"))
			{
				JSONArray alternateNameList = (JSONArray) contact.getJSONArray("alternateNames");
				boolean gotQMAAlternateName = false;
				for (int i = 0; i < alternateNameList.length() && gotQMAAlternateName == false; i++)
				{
					JSONObject alternateName = alternateNameList.getJSONObject(i);
					if (isQMADataSearch && "qma".equals(alternateName.get(SRC_SYS)))
					{
						gotQMAAlternateName = true;
						qmaContact.setFirstName(alternateName.get(FIRST_NAME).toString());
						qmaContact.setLastName(alternateName.get(LAST_NAME).toString());
						if (alternateName.get("type").toString().equalsIgnoreCase(FIRST_NAME))
							qmaContact.setType("CLIENT");
						else
							qmaContact.setType("DL");
					}else if(!isQMADataSearch && alternateName.get(SRC_SYS) !=null){
						gotQMAAlternateName = true;
						qmaContact.setFirstName(alternateName.get(FIRST_NAME).toString());
						qmaContact.setLastName(alternateName.get(LAST_NAME).toString());
						if (alternateName.get("type").toString().equalsIgnoreCase(FIRST_NAME))
							qmaContact.setType("CLIENT");
						else
							qmaContact.setType("DL");
					}
				}
			}

			if (!contact.isNull(CLIENTS))
			{
				JSONArray clientList = (JSONArray) contact.getJSONArray(CLIENTS);
				boolean gotQMAClient = false;
				for (int i = 0; i < clientList.length() && gotQMAClient == false; i++)
				{
					JSONObject client = clientList.getJSONObject(i);
					if (isQMADataSearch && "qma".equals(client.get(SRC_SYS)))
					{
					
						if (!client.get("srcSysId").toString().contentEquals("null"))
							qmaContact.setSrcSysId(client.get("srcSysId").toString());
						if (!client.get(CLIENT_ID).toString().contentEquals("null"))
							qmaContact.setClientID(client.get(CLIENT_ID).toString());
						if (!client.get(CLIENT_NAME).toString().contentEquals("null"))
							qmaContact.setClientName(client.get(CLIENT_NAME).toString());
						if (!client.get(CLIENT_TYPE).toString().contentEquals("null"))
							qmaContact.setClientIdType(client.get(CLIENT_TYPE).toString());
						if (!client.isNull(JOB_TITLES))
						{
							JSONArray jobTitlesArray = (JSONArray) client.get(JOB_TITLES);
							String jobTitles = "";
							for (int j = 0; j < jobTitlesArray.length(); j++)
							{
								if (jobTitles != null)
									jobTitles = jobTitles + jobTitlesArray.get(j) + ",";
							}
							qmaContact.setJobTitle(jobTitles);
						}
					}else if (!isQMADataSearch && client.get(SRC_SYS) !=null ){
						gotQMAClient = true;
						if (!client.get(SRC_SYS).toString().contentEquals("null"))
							qmaContact.setSrcSysId(client.get(SRC_SYS).toString());
						if (!client.get(CLIENT_ID).toString().contentEquals("null"))
							qmaContact.setClientID(client.get(CLIENT_ID).toString());
						if (!client.get(CLIENT_NAME).toString().contentEquals("null"))
							qmaContact.setClientName(client.get(CLIENT_NAME).toString());
						if (!client.get(CLIENT_TYPE).toString().contentEquals("null"))
							qmaContact.setClientIdType(client.get(CLIENT_TYPE).toString());
						if (!client.isNull(JOB_TITLES))
						{
							JSONArray jobTitlesArray = (JSONArray) client.get(JOB_TITLES);
							String jobTitles = "";
							for (int j = 0; j < jobTitlesArray.length(); j++)
							{
								if (jobTitles != null)
									jobTitles = jobTitles + jobTitlesArray.get(j) + ",";
							}
							qmaContact.setJobTitle(jobTitles);
						}
					}
				}
			}

			if (!contact.isNull("emails"))
			{
				JSONArray emailList = (JSONArray) contact.getJSONArray("emails");
				for (int emailNumber = 0; emailNumber < emailList.length(); emailNumber++)
				{
					JSONObject email = emailList.getJSONObject(emailNumber);
					if (email.get("type").toString().equals("Office"))
					{
						if (!email.getString(EMAIL).contentEquals("null"))
							qmaContact.setEmail(email.getString(EMAIL));
					}
				}
			}

			if (!contact.isNull("phones"))
			{
				JSONArray phoneNumbersList = (JSONArray) contact.getJSONArray("phones");
				for (int phonesNumber = 0; phonesNumber < phoneNumbersList.length(); phonesNumber++)
				{
					JSONObject phoneNumberEntry = phoneNumbersList.getJSONObject(phonesNumber);
					if (phoneNumberEntry.get("type").equals("Work 1"))
					{
						if (!phoneNumberEntry.getString("phone").contentEquals("null"))
							qmaContact.setPhone(phoneNumberEntry.getString("phone"));
					}
				}
			}

			qmaContactListForClientID.add(qmaContact);
		}
	}

	// initialize the contact received from CMC to empty contact at the beginning
	private QMAContact setInitialEmptyQMAContact()
	{
		QMAContact qmaContact = new QMAContact();
		qmaContact.setClientID("");
		qmaContact.setClientName("");
		qmaContact.setEmail("");
		qmaContact.setFirstName("");
		qmaContact.setJobTitle("");
		qmaContact.setLastName("");
		qmaContact.setManagementId("");
		qmaContact.setPhone("");
		qmaContact.setSrcSysId("");
		qmaContact.setType("");
		qmaContact.setMnemonic("");
		return qmaContact;
	}

	// encoding URL
	private String modifyURL(String soeId, String url) throws CommunicatorException
	{
		URL newUrl;
		URI uri;
		try
		{
			newUrl = URI.create(url).toURL();
			uri = new URI(newUrl.getProtocol(), newUrl.getUserInfo(), newUrl.getHost(), newUrl.getPort(), newUrl.getPath(), newUrl.getQuery(), newUrl.getRef());
		}
		catch (MalformedURLException | URISyntaxException e)
		{
			subLogger.debug("Exception in modifyURL for soeId = {}", soeId, e);
			throw new CommunicatorException("Exception in modifyURL " + e);
		}
		return uri.toASCIIString();
	}

	// Http Response to string conversion
	private static String convertStreamToString(InputStream is)
	{
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try
		{
			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
		}
		catch (IOException e)
		{
			subLogger.debug(e.toString());
		}
		finally
		{
			try
			{
				is.close();
			}
			catch (IOException e)
			{
				subLogger.debug(e.toString());
			}
		}
		return sb.toString();
	}

	
}
