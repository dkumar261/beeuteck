/**
 * 
 */
package com.citi.icg.qma.common.server.dao.persistence;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.server.dao.MailBoxDLMapping;
import com.citi.icg.qma.common.server.dao.MailBoxDLMapping.CurrentMailBoxRunStatus;
import com.citi.icg.qma.common.server.dao.MailBoxDLMapping.MailBoxMappingType;
import com.citi.icg.qma.common.server.dao.MailBoxDLMapping.ModifiedBy;
import com.citi.icg.qma.common.server.util.DedicatedReaderUtility;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.hazelcast.cache.client.HazelCastCacheIncrementalLoad;
import com.mongodb.BasicDBObject;

import dev.morphia.Datastore;

public class ReaderUIOperationsDAO {

	private static final String REQUEST_PARAM_CRT_DATE = "crtDate";
	private static final String REQUEST_PARAM_CRT_BY = "crtBy";
	private static final String REQUEST_PARAM_MOD_DATE = "modDate";
	private static final String REQUEST_PARAM_MOD_BY = "modBy";
	private static final String REQUEST_PARAM_STARTED_ON = "startedOn";
	private static final String REQUEST_PARAM_STOPPED_AT = "stoppedAt";
	private static final String REQUEST_PARAM_STARTED_AT = "startedAt";
	private static final String REQUEST_PARAM_CURRENT_RUN_STATUS = "currentRunStatus";
	private static final String REQUEST_PARAM_READER_BATCH_SIZE = "readerBatchSize";
	private static final String REQUEST_PARAM_ALLOWED_DOMAINS = "allowedDomains";
	private static final String REQUEST_PARAM_MAPPED_DL = "mappedDL";
	private static final String REQUEST_PARAM_LOGIN_SECRET = "loginSecret";
	private static final String REQUEST_PARAM_MAX_MEMORY = "maxMemoryRequirementInMB";
	private static final String REQUEST_PARAM_MIN_MEMORY = "minMemoryRequirementInMB";
	private static final String REQUEST_PARAM_REGION = "region";
	private static final String REQUEST_PARAM_CONNECTION_URL = "connectionURL";
	private static final String REQUEST_PARAM_VERSION = "version";
	private static final String REQUEST_PARAM_MAX_ERROR_EMAIL_COUNT = "maxErrorEmailCount";
	private static final String REQUEST_PARAM_WAIT_TIME_BETWEEN_POLL = "waitTimeBetweenPoll";
	private static final String REQUEST_PARAM_DOMAIN = "domain";
	private static final String REQUEST_PARAM_SUPPORT_EMAIL = "supportEmail";
	private static final String REQUEST_PARAM_ATTACHMENT_PATH = "attachmentPath";
	private static final String REQUEST_PARAM_HOST_NAME = "hostName";
	private static final String REQUEST_PARAM_MAPPING_TYPE = "mappingType";
	private static final String REQUEST_PARAM_MAIL_BOX_ID = "_id";
	public static final String REQUEST_PARAM_SECRET = "secret";
	public static final String REQUEST_PARAM_SECRET_IV = "secretIV";
	private static final String REQUEST_PARAM_EXCHANGE_WEB_SERVICE_URL = "exchangeWebServiceUrl";
	private static final String REQUEST_PARAM_IS_TO_BE_FORCE_STOPPED = "isToBeForceStopped";
	private static final String REQUEST_PARAM_IS_TO_BE_FORCE_STARTED = "isToBeForceStarted";
	private static final String DB_ALLOWED_DOMAINS = "allowedDomains";
	private static final String DB_READER_BATCH_SIZE = "readerBatchSize";
	private static final String DB_DEFAULT_MAXIMUM_MEMORY_REQUIRED_FOR_ANY_READER_TO_START_IN_MB = "defaultMaximumMemoryRequiredForAnyReaderToStartInMB";
	private static final String DB_DEFAULT_MINIMUM_MEMORY_REQUIRED_FOR_ANY_READER_TO_START_IN_MB = "defaultMinimumMemoryRequiredForAnyReaderToStartInMB";
	private static final String MAPPING_TYPE_SHARED = "shared";
	private static final String MAPPING_TYPE_PERSONAL = "personal";
	private static final String MAPPING_TYPE_DEDICATED = "dedicated";
	private static final String INPUT_REQUEST_PARSING_ERROR = "Issue while parsing input request. Please validate input parameters.";
	private static final Logger logger = LoggerFactory.getLogger(ReaderUIOperationsDAO.class);
	private static final DedicatedReaderUtility readerUtil = DedicatedReaderUtility.getInstance();
	private static ReaderUIOperationsDAO instance = null;
	private final Datastore dataStore;
	
	public ReaderUIOperationsDAO(){
		dataStore = MongoDB.instance().getDataStore();
	}
	
	/**
	 * This will returns a singleton object of this class
	 * @return
	 */
	public static synchronized ReaderUIOperationsDAO getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		if (instance == null) {
			instance = new ReaderUIOperationsDAO();
		}

		return instance;
	}
	
	/**
	 * This method adds a new reader to the database.
	 * @param requester
	 * @param request
	 * @return BasicDB
	 */
	public BasicDBObject addReader(String requester, String request) {
		BasicDBObject result;
		BasicDBObject inputObj = GenericUtility.parseRequestToObject(request);
		if( null == inputObj ) {
			result = addResponseParameters(false,INPUT_REQUEST_PARSING_ERROR);
		} else {
			result = addReader(requester, inputObj);
		}
		return result;
	}
	
	/**
	 * This method updates reader attributes in database.
	 * @param requester
	 * @param request
	 * @return BasicDBObject
	 */
	public BasicDBObject updateReader(String requester, String request) {
		BasicDBObject result;
		BasicDBObject inputObj = GenericUtility.parseRequestToObject(request);
		if( null == inputObj ) {
			result = addResponseParameters(false,INPUT_REQUEST_PARSING_ERROR);
		} else {
			result = updateReader(requester, inputObj);
		}
		return result;
	}

	/**
	 * This method removes reader entry from database.
	 * @param requester
	 * @param request
	 * @return BasicDBObject
	 */
	public BasicDBObject removeReader(String requester, String request) {
		BasicDBObject result;
		BasicDBObject inputObj = GenericUtility.parseRequestToObject(request);
		if( null == inputObj ) {
			result = addResponseParameters(false,INPUT_REQUEST_PARSING_ERROR);
		} else {
			result = removeReader(requester, inputObj);
		}
		return result;
	}
	
	/**
	 * This method will set reader to start
	 * @param requester
	 * @param request
	 * @return BasicDBObject
	 */
	public BasicDBObject startReader(String requester, String request) {
		BasicDBObject result;
		BasicDBObject inputObj = GenericUtility.parseRequestToObject(request);
		if( null == inputObj ) {
			result = addResponseParameters(false,INPUT_REQUEST_PARSING_ERROR);
		} else {
			result = startReader(requester, inputObj);
		}
		return result;
	}

	/**
	 * This method will set reader to stop
	 * @param requester
	 * @param request
	 * @return BasicDBObject
	 */
	public BasicDBObject stopReader(String requester, String request) {
		BasicDBObject result;
		BasicDBObject inputObj = GenericUtility.parseRequestToObject(request);
		if( null == inputObj ) {
			result = addResponseParameters(false,INPUT_REQUEST_PARSING_ERROR);
		} else {
			result = stopReader(requester, inputObj);
		}
		return result;
	}

	/**
	 * This method gets reader status
	 * @param requester
	 * @param request
	 * @return BasicDBObject
	 */
	public BasicDBObject getStatus(String requester, String request) {
		BasicDBObject result;
		BasicDBObject inputObj = GenericUtility.parseRequestToObject(request);
		if( null == inputObj ) {
			result = addResponseParameters(false,INPUT_REQUEST_PARSING_ERROR);
		} else {
			result = getReaderStatus(requester, inputObj);
		}
		return result;
	}
	
	/**
	 * This method adds response parameters to the resposne.
	 * @param success
	 * @param message
	 * @return BasicDBObject
	 */
	private BasicDBObject addResponseParameters(boolean success, String message) {
		BasicDBObject result = new BasicDBObject();
		result.put(AppserverConstants.SUCCESS_KEY, success);
		result.put(AppserverConstants.MESSAGE_KEY, message);
		return result;
	}

	/**
	 * This method adds reader to the database.
	 * @param requester
	 * @param inputObj
	 * @return BasicDBObject
	 */
	public BasicDBObject addReader(String requester, BasicDBObject inputObj) {
		BasicDBObject result = new BasicDBObject();
		try {
			MailBoxDLMapping mapping = getMailBoxMappingObjectFromRequest(requester, inputObj);
			if( null != mapping && null != mapping.getId()) {
				boolean success = addAnEntryIntoMailBoxDLMapping(mapping);
				if(success) {
					result = addResponseParameters(true, "MailBoxDLMapping entry added for the mailBox : " + mapping.getId());
				} else {
					result = addResponseParameters(false, "MailBoxDLMapping entry not updated in database for mailBox: " + mapping.getId());
				}
			} else {
				result = addResponseParameters(false, "Either provided MailBox already exists in database or validate and provide correct input parameters to onboard mailbox.");
			}
		} catch (Exception e) {
			logger.error("Exception while adding a new reader :",e);
			result = addResponseParameters(false, "Error while adding new reader.");
		}
		return result;
	}
	
	/**
	 * This method prepares a MailBoxDLMapping object from the request
	 * @param requester
	 * @param inputObj
	 * @return MailBoxDLMapping
	 * @throws CommunicatorException
	 */
	private MailBoxDLMapping getMailBoxMappingObjectFromRequest(String requester, BasicDBObject inputObj) throws CommunicatorException {
		MailBoxDLMapping mapping = null;
		try {
			String mailBoxName = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_MAIL_BOX_ID)) ? 
					inputObj.getString(REQUEST_PARAM_MAIL_BOX_ID) : "" ;
			String mappingTypeStr = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_MAPPING_TYPE)) ? 
					inputObj.getString(REQUEST_PARAM_MAPPING_TYPE) : "" ;
			MailBoxMappingType mappingType = getMailBoxMappingType(mappingTypeStr);
			mapping = readerUtil.getMappingById(mailBoxName);
			if( mapping == null ) {
				logger.info("Creating new MailBoxMapping entry for {}", mailBoxName);
				mapping = new MailBoxDLMapping();
				updateMailBoxMapping(requester, inputObj, mapping, mailBoxName, mappingType);
			} else {
				logger.warn("Provided mailbox already exists in the database.");
			}
		} catch (Exception e) {
			logger.error("Exception while getting mailbox mapping object from request :" ,e);
		}
		return mapping;
	}
	
	/**
	 * This function gets the mapping type based on provide string value.
	 * @param mappingTypeStr
	 * @return MailBoxMappingType
	 */
	private MailBoxMappingType getMailBoxMappingType(String mappingTypeStr) {
		MailBoxMappingType mappingType = null;
		if(StringUtils.isNotEmpty(mappingTypeStr)){
			if(MAPPING_TYPE_DEDICATED.equalsIgnoreCase(mappingTypeStr) || mappingTypeStr.contains(MAPPING_TYPE_DEDICATED)){
				mappingType = MailBoxMappingType.DEDICATED;
			} else if(MAPPING_TYPE_PERSONAL.equalsIgnoreCase(mappingTypeStr) || mappingTypeStr.contains(MAPPING_TYPE_PERSONAL)){
				mappingType = MailBoxMappingType.PERSONAL;
			}  else if(MAPPING_TYPE_SHARED.equalsIgnoreCase(mappingTypeStr) || mappingTypeStr.contains(MAPPING_TYPE_SHARED)){
				mappingType = MailBoxMappingType.SHARED;
			} else {
				logger.warn("Please provide correct mapping type.");
			}
		} else {
			logger.warn("Please provide correct mapping type.");
		}
		return mappingType;
	}
	
	/**
	 * This method updates mailbox mapping domain object fields.
	 * @param requester
	 * @param inputObj
	 * @param mapping
	 * @param mailBoxName
	 * @param mappingType
	 * @throws CommunicatorException
	 */
	private void updateMailBoxMapping(String requester, BasicDBObject inputObj, MailBoxDLMapping mapping,
			String mailBoxName, MailBoxMappingType mappingType) throws CommunicatorException {
		try {
			if( StringUtils.isNotBlank(mailBoxName) && null != mappingType ) {
				addInitialOnBoardingParams(mapping,mailBoxName, mappingType, requester, inputObj);
				if(mappingType.equals(MailBoxMappingType.DEDICATED) || mappingType.equals(MailBoxMappingType.SHARED)) {
					updateDedicateMappingFields(mapping,inputObj);
				} else if(mappingType.equals(MailBoxMappingType.PERSONAL)) {
					updatePersonalMappingFields(mapping,inputObj);
				}
			} else {
				logger.warn("Provide correct mailBox mapping type and name.");
			}
		} catch (Exception e) {
			logger.error("Exception while updating mailbox mapping : ", e);
		}
	}
	
	/**
	 * This method updates mandatory onboarding fields
	 * @param mapping
	 * @param mailBoxName
	 * @param mappingType
	 * @param requester
	 * @param inputObj
	 * @throws CommunicatorException
	 */
	private void addInitialOnBoardingParams(MailBoxDLMapping mapping, String mailBoxName, MailBoxMappingType mappingType, 
			String requester, BasicDBObject inputObj) throws CommunicatorException {
		try {
			Long minMemory = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_MIN_MEMORY)) ? inputObj.getLong(REQUEST_PARAM_MIN_MEMORY) 
					: (Long)readerUtil.getDefaultValueForMailBox(DB_DEFAULT_MINIMUM_MEMORY_REQUIRED_FOR_ANY_READER_TO_START_IN_MB);
			Long maxMemory = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_MAX_MEMORY)) ? inputObj.getLong(REQUEST_PARAM_MAX_MEMORY) 
					: (Long)readerUtil.getDefaultValueForMailBox(DB_DEFAULT_MAXIMUM_MEMORY_REQUIRED_FOR_ANY_READER_TO_START_IN_MB);

			mapping.setId(mailBoxName);
			mapping.setMappingType(mappingType);
			mapping.setMinMemoryRequirementInMB(minMemory);
			mapping.setMaxMemoryRequirementInMB(maxMemory);
			mapping.setToBeForceStarted(true);
			mapping.setCrtBy(requester);
			mapping.setModBy(ModifiedBy.SYSTEM_ADMIN);
			Date date = new Date();
			mapping.setCrtDate(date);
			mapping.setModDate(date);
			
			String encodedSecret = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_LOGIN_SECRET)) ? inputObj.getString(REQUEST_PARAM_LOGIN_SECRET) : "" ;
			String[] loginSecret = readerUtil.getEncryptedLoginSecret(encodedSecret);
			if (null != loginSecret && loginSecret.length == 2) {
				mapping.setLoginSecretEnc(loginSecret[0]);
				mapping.setLoginSecretEncIV(loginSecret[1]);
			} else {
				logger.info("Can not set login secret in the mapping object.");
			}

			if(StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_SECRET)) && StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_SECRET_IV))){
				mapping.setLoginSecretEnc(inputObj.getString("secret"));
				mapping.setLoginSecretEncIV(inputObj.getString("secretIV"));
			}

		} catch (Exception e) {
			throw new CommunicatorException("Error while adding mandatory onboarding details for mailbox mapping :",e);
		}
	}
	
	/**
	 * This method updates the fields related to dedicated mailbox
	 * @param mapping
	 * @param inputObj
	 */
	private void updateDedicateMappingFields(MailBoxDLMapping mapping, BasicDBObject inputObj) {
		try {
			String mappedDL = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_MAPPED_DL)) ? inputObj.getString(REQUEST_PARAM_MAPPED_DL) : "" ;
			String allowedDomains = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_ALLOWED_DOMAINS)) ? inputObj.getString(REQUEST_PARAM_ALLOWED_DOMAINS) 
					: (String) readerUtil.getDefaultValueForMailBox(DB_ALLOWED_DOMAINS);
			Long readerBatchSize = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_READER_BATCH_SIZE)) ? inputObj.getLong(REQUEST_PARAM_READER_BATCH_SIZE)
					: (Long) readerUtil.getDefaultValueForMailBox(DB_READER_BATCH_SIZE);
			mapping.setMappedDL(mappedDL);
			mapping.setAllowedDomains(allowedDomains);
			mapping.setReaderBatchSize(readerBatchSize);
			
			updateExchangeConfiguration(mapping, inputObj);
		} catch (Exception e) { 
			logger.error("Exception while updating dedicated mailbox mapping fields : ",e);
		}
	}
	
	/**
	 * This method updates the exchange configuration for the mailbox
	 * @param mapping
	 * @param inputObj
	 */
	private void updateExchangeConfiguration(MailBoxDLMapping mapping, BasicDBObject inputObj) {
		try {
			String hostName = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_HOST_NAME)) ? inputObj.getString(REQUEST_PARAM_HOST_NAME) 
					: (String) readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_HOST_NAME);
			String attachmentPath = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_ATTACHMENT_PATH)) ? inputObj.getString(REQUEST_PARAM_ATTACHMENT_PATH) 
					: (String) readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_ATTACHMENT_PATH);
			String supportEmail = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_SUPPORT_EMAIL)) ? inputObj.getString(REQUEST_PARAM_SUPPORT_EMAIL) 
					: (String) readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_SUPPORT_EMAIL);
			String domain = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_DOMAIN)) ? inputObj.getString(REQUEST_PARAM_DOMAIN) 
					: (String) readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_DOMAIN);
			Long waitTimeBetweenPoll = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_WAIT_TIME_BETWEEN_POLL)) ? inputObj.getLong(REQUEST_PARAM_WAIT_TIME_BETWEEN_POLL)
					: (Long) readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_WAIT_TIME_BETWEEN_POLL);
			Long maxErrorEmailCount = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_MAX_ERROR_EMAIL_COUNT)) ?  inputObj.getLong(REQUEST_PARAM_MAX_ERROR_EMAIL_COUNT) 
					: (Long) readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_MAX_ERROR_EMAIL_COUNT);
			Long version = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_VERSION)) ?  inputObj.getLong(REQUEST_PARAM_VERSION)
					: (Long) readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_VERSION);
			String exchangeWebServiceUrl = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_EXCHANGE_WEB_SERVICE_URL)) ? inputObj.getString(REQUEST_PARAM_EXCHANGE_WEB_SERVICE_URL) 
					: (String) readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_EXCHANGE_WEB_SERVICE_URL);
			
			if(null == mapping.getExchangeConfig()){
				mapping.setExchangeConfig(new MailBoxDLMapping.ExchangeConfig());
			}

			mapping.getExchangeConfig().setHostName(hostName);
			mapping.getExchangeConfig().setAttachmentPath(attachmentPath);
			mapping.getExchangeConfig().setSupportEmail(supportEmail);
			mapping.getExchangeConfig().setDomain(domain);
			mapping.getExchangeConfig().setWaitTimeBetweenPoll(waitTimeBetweenPoll);
			mapping.getExchangeConfig().setMaxErrorEmailCount(maxErrorEmailCount);
			mapping.getExchangeConfig().setVersion(version);
			mapping.getExchangeConfig().setExchangeWebServiceUrl(exchangeWebServiceUrl);
			
		} catch (Exception e) {
			logger.error("Exception while updating exchange configuration for the mailbox [{}] : ", mapping.getId(), e);
		}
	}
	
	/**
	 * This method updates the personal mailbox fields
	 * @param mapping
	 * @param inputObj
	 */
	private void updatePersonalMappingFields(MailBoxDLMapping mapping, BasicDBObject inputObj) {
		try {
			String connectionURL = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_CONNECTION_URL)) ? inputObj.getString(REQUEST_PARAM_CONNECTION_URL) : "" ;
			String region = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_REGION)) ? inputObj.getString(REQUEST_PARAM_REGION) : "" ;
			mapping.setConnectionURL(connectionURL);
			mapping.setRegion(region);
		} catch (Exception e) {
			logger.error("Exception while updating personal mailbox mapping fields : ",e);
		}
	}
	
	/**
	 * This method updates the reader parameters
	 * @param requester
	 * @param inputObj
	 * @return BasicDBObject
	 */
	private BasicDBObject updateReader(String requester, BasicDBObject inputObj) {
		BasicDBObject result = null;
		try {
			String mailBoxName = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_MAIL_BOX_ID)) ? 
					inputObj.getString(REQUEST_PARAM_MAIL_BOX_ID) : "" ;
			MailBoxDLMapping mapping = readerUtil.getMappingById(mailBoxName);
			if( mapping == null ) {
				result = addResponseParameters(false, "MailBoxDLMapping entry not found in database for mailBox to be updated.");
			} else {
				result = validateInputParamsAndUpdate(mapping,inputObj);
			}
		} catch (Exception e) {
			logger.error("Exception while removing reader :",e);
		}
		return result;
	}
	
	/**
	 * This method validates the input parameters before updating an entry
	 * @param mapping
	 * @param inputObj
	 * @return BasicDBObject
	 */
	private BasicDBObject validateInputParamsAndUpdate(MailBoxDLMapping mapping, BasicDBObject inputObj) {
		BasicDBObject result;
		boolean shouldUpdateEntry = updateMailBoxMappingObjectFromRequest(mapping,inputObj);
		if(shouldUpdateEntry){
			boolean success = updateAnEntryIntoMailBoxDLMapping(mapping);
			if(success) {
				result = addResponseParameters(true, "Entry updated for mailbox "+ mapping.getId() +". Please restart the reader to take changes into effect.");
			} else {
				result = addResponseParameters(false, "There was an issue updating mailbox entry into database.");
			}
		} else {
			result = addResponseParameters(false, "Issue extracting parameters from request. Please try again later.");
		}
		return result;
	}
	/**
	 * This method will update the mapping object based on input parameters.
	 * @param mapping
	 * @param inputObj
	 * @return boolean
	 */
	private boolean updateMailBoxMappingObjectFromRequest(MailBoxDLMapping mapping, BasicDBObject inputObj) {
		boolean isUpdated = false;
		try {
			updateReaderMemoryParams(mapping, inputObj);
			if(null != mapping.getMappingType()) {
				if(mapping.getMappingType().equals(MailBoxMappingType.DEDICATED)) {
					updateDedicatedMailBoxConfig(mapping, inputObj);
				} else if(mapping.getMappingType().equals(MailBoxMappingType.PERSONAL)) {
					updatePersonalMappingFields(mapping,inputObj);
				}
				isUpdated = true;
			}
		} catch (Exception e) {
			logger.error("Exception while updating mapping object from request data :" ,e);
		}
		return isUpdated;
	}
	
	/**
	 * This method reads and updates memory parameters into mapping object.
	 * @param mapping
	 * @param inputObj
	 */
	private void updateReaderMemoryParams(MailBoxDLMapping mapping, BasicDBObject inputObj) {
		Long minMemory = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_MIN_MEMORY)) ? inputObj.getLong(REQUEST_PARAM_MIN_MEMORY) 
				: (Long)readerUtil.getDefaultValueForMailBox(DB_DEFAULT_MINIMUM_MEMORY_REQUIRED_FOR_ANY_READER_TO_START_IN_MB);
		Long maxMemory = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_MAX_MEMORY)) ? inputObj.getLong(REQUEST_PARAM_MAX_MEMORY) 
				: (Long)readerUtil.getDefaultValueForMailBox(DB_DEFAULT_MAXIMUM_MEMORY_REQUIRED_FOR_ANY_READER_TO_START_IN_MB);
		mapping.setMinMemoryRequirementInMB(minMemory);
		mapping.setMaxMemoryRequirementInMB(maxMemory);
	}
	
	/**
	 * This method reads dedicated reader specific attributes from request and update the existing mapping
	 * @param mapping
	 * @param inputObj
	 */
	private void updateDedicatedMailBoxConfig(MailBoxDLMapping mapping, BasicDBObject inputObj) {
		String allowedDomains = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_ALLOWED_DOMAINS)) ? inputObj.getString(REQUEST_PARAM_ALLOWED_DOMAINS) 
				: (String) readerUtil.getDefaultValueForMailBox(DB_ALLOWED_DOMAINS);
		Long readerBatchSize = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_READER_BATCH_SIZE)) ? inputObj.getLong(REQUEST_PARAM_READER_BATCH_SIZE) 
				: (Long) readerUtil.getDefaultValueForMailBox(DB_READER_BATCH_SIZE);
		mapping.setAllowedDomains(allowedDomains);
		mapping.setReaderBatchSize(readerBatchSize);
		updateExchangeConfiguration(mapping,inputObj);
	}


	/**
	 * This method removes mailbox entry for the provided mailbox
	 * @param soeId
	 * @param inputObj
	 * @return BasicDBObject
	 */
	private BasicDBObject removeReader(String requester, BasicDBObject inputObj) {
		BasicDBObject result = null;
		try {
			String mailBoxName = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_MAIL_BOX_ID)) ? 
					inputObj.getString(REQUEST_PARAM_MAIL_BOX_ID) : "" ;
			MailBoxDLMapping mapping = readerUtil.getMappingById(mailBoxName);
			if( mapping == null ) {
				result = addResponseParameters(false, "MailBoxDLMapping entry not found in database for mailBox to be removed.");
			} else {
				result = validateReaderStateAndRemove(mapping);
			}
		} catch (Exception e) {
			logger.error("Exception while removing reader :",e);
		}
		return result;
	}

	/**
	 * This method validates reader params before removing mailbox entry from db.
	 * @param mapping
	 * @return BasicDBObject
	 */
	private BasicDBObject validateReaderStateAndRemove(MailBoxDLMapping mapping) {
		BasicDBObject result;
		if( mapping.getCurrentRunStatus().equals(CurrentMailBoxRunStatus.STOPPED) && !mapping.isToBeForceStarted()) {
			boolean success = removeAnEntryFromMailBoxDLMapping(mapping);
			if(success) {
				result = addResponseParameters(true, "Entry removed from MailBoxDLMapping Collections as reader is already in STOPPED state.");
			} else {
				result = addResponseParameters(false, "There was an issue removing mailbox entry from database.");
			}
		} else {
			result = addResponseParameters(false, "Please ensure mailbox ["+mapping.getId()+"] reader is in STOPPED state in order to remove it from the system.");
		}
		return result;
	}
	
	/**
	 * This method sets the reader to start
	 * @param soeId
	 * @param inputObj
	 * @return BasicDBObject
	 */
	private BasicDBObject startReader(String requester, BasicDBObject inputObj) {
		BasicDBObject result;
		String mailBoxName = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_MAIL_BOX_ID)) ? 
				inputObj.getString(REQUEST_PARAM_MAIL_BOX_ID) : "" ;
		MailBoxDLMapping mapping = readerUtil.getMappingById(mailBoxName);
		if( mapping == null ) {
			result = addResponseParameters(false, "MailBoxDLMapping entry not found in database for mailBox to be started.");
		} else {
			result = validateReaderStateAndSetToStart(mapping);
		}
		return result;
	}

	/**
	 * This method validates the reader current state before setting reader to START
	 * @param mapping
	 * @return BasicDBObject
	 */
	private BasicDBObject validateReaderStateAndSetToStart(MailBoxDLMapping mapping) {
		BasicDBObject result;
		if( mapping.getCurrentRunStatus().equals(CurrentMailBoxRunStatus.STOPPED) && !mapping.isToBeForceStopped()) {
			
			mapping.setToBeForceStarted(true);
			mapping.setModDate(new Date());
			mapping.setModBy(ModifiedBy.SYSTEM_ADMIN);
			
			boolean success = updateAnEntryIntoMailBoxDLMapping(mapping);
			if(success) {
				result = addResponseParameters(true, "MailBox["+mapping.getId()+"] Reader is set to START. Please wait for next Ochestrator cycle to start it and check status again.");
			} else {
				result = addResponseParameters(false, "There was an issue setting mailbox["+mapping.getId()+"] to start");
			}
		} else {
			result = addResponseParameters(false, "Please ensure mailbox["+mapping.getId()+"] current run status and try again later.");
		}
		return result;
	}
	
	/**
	 * This method sets the reader to stop
	 * @param soeId
	 * @param inputObj
	 * @return BasicDBObject
	 */
	private BasicDBObject stopReader(String requester, BasicDBObject inputObj) {
		BasicDBObject result;
		String mailBoxName = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_MAIL_BOX_ID)) ? 
				inputObj.getString(REQUEST_PARAM_MAIL_BOX_ID) : "" ;
		MailBoxDLMapping mapping = readerUtil.getMappingById(mailBoxName);
		if( mapping == null ) {
			result = addResponseParameters(false, "MailBoxDLMapping entry not found in database for mailBox to be stopped.");
		} else {
			result = validateReaderStateAndSetToStop(mapping);
		}
		return result;
	}

	/**
	 * This method validates the reader current state before setting reader to STOP
	 * @param mapping
	 * @return BasicDBObject
	 */
	private BasicDBObject validateReaderStateAndSetToStop(MailBoxDLMapping mapping) {
		BasicDBObject result;
		if( mapping.getCurrentRunStatus().equals(CurrentMailBoxRunStatus.STARTED) && !mapping.isToBeForceStarted()) {
			
			mapping.setToBeForceStopped(true);
			mapping.setModDate(new Date());
			mapping.setModBy(ModifiedBy.SYSTEM_ADMIN);
			
			boolean success = updateAnEntryIntoMailBoxDLMapping(mapping);
			if(success) {
				result = addResponseParameters(true, "MailBox["+mapping.getId()+"] Reader is set to STOP. Please wait for next Ochestrator cycle to stop it and check status again.");
			} else {
				result = addResponseParameters(false, "There was an issue setting mailbox["+mapping.getId()+"] to stop");
			}
		} else {
			result = addResponseParameters(false, "Please ensure mailbox["+mapping.getId()+"] current run status and try again later.");
		}
		return result;
	}
	
	/**
	 * This method validates input parameters and gets reader status
	 * @param requester
	 * @param inputObj
	 * @return BasicDBObject
	 */
	private BasicDBObject getReaderStatus(String requester, BasicDBObject inputObj) {
		BasicDBObject result;
		String mailBoxName = StringUtils.isNotEmpty(inputObj.getString(REQUEST_PARAM_MAIL_BOX_ID)) ? 
				inputObj.getString(REQUEST_PARAM_MAIL_BOX_ID) : "" ;
		MailBoxDLMapping mapping = readerUtil.getMappingById(mailBoxName);
		if( mapping == null ) {
			result = addResponseParameters(false, "MailBoxDLMapping entry not found in database for mailBox to be stopped.");
		} else {
			result = getReaderStatus(mapping);
		}
		return result;
	}

	/**
	 * This method will provide all attributes of provided mailBox
	 * @param mapping
	 * @return BasicDBObject
	 */
	private BasicDBObject getReaderStatus(MailBoxDLMapping mapping) {
		BasicDBObject result  = addResponseParameters(true, "MailBoxDLMapping entry found in database.");
		result.put(REQUEST_PARAM_MAIL_BOX_ID, mapping.getId());
		result.put(REQUEST_PARAM_MAPPING_TYPE, null != mapping.getMappingType() ? mapping.getMappingType().toString() : "N/A");
		result.put(REQUEST_PARAM_MIN_MEMORY, mapping.getMinMemoryRequirementInMB());
		result.put(REQUEST_PARAM_MAX_MEMORY, mapping.getMaxMemoryRequirementInMB());
		result.put(REQUEST_PARAM_CURRENT_RUN_STATUS, null != mapping.getCurrentRunStatus() ? mapping.getCurrentRunStatus().toString():"N/A");
		result.put(REQUEST_PARAM_STARTED_AT, mapping.getStartedAt());
		result.put(REQUEST_PARAM_STOPPED_AT, mapping.getStoppedAt());
		result.put(REQUEST_PARAM_STARTED_ON, mapping.getStartedOn());
		result.put(REQUEST_PARAM_MOD_BY, null !=  mapping.getModBy() ? mapping.getModBy().toString() : "N/A");
		result.put(REQUEST_PARAM_MOD_DATE, mapping.getModDate());
		result.put(REQUEST_PARAM_ALLOWED_DOMAINS, mapping.getAllowedDomains());
		result.put(REQUEST_PARAM_READER_BATCH_SIZE, mapping.getReaderBatchSize());
		result.put(REQUEST_PARAM_CRT_BY, mapping.getCrtBy());
		result.put(REQUEST_PARAM_CRT_DATE, mapping.getCrtDate());
		result.put(REQUEST_PARAM_IS_TO_BE_FORCE_STARTED, mapping.isToBeForceStarted());
		result.put(REQUEST_PARAM_IS_TO_BE_FORCE_STOPPED, mapping.isToBeForceStopped());
		
		if(mapping.getMappingType().equals(MailBoxMappingType.DEDICATED)) {
			result.put(REQUEST_PARAM_MAPPED_DL, mapping.getMappedDL());
			addExchangeAttributesToResult(result,mapping);
		} else if(mapping.getMappingType().equals(MailBoxMappingType.PERSONAL)) {
			result.put(REQUEST_PARAM_REGION, mapping.getRegion());
			result.put(REQUEST_PARAM_CONNECTION_URL, mapping.getConnectionURL());
		}
		return result;
	}
	
	/**
	 * This method will add exchange attriutes to the response.
	 * @param result
	 * @param mapping
	 */
	private void addExchangeAttributesToResult(BasicDBObject result, MailBoxDLMapping mapping) {
		if(null != mapping.getExchangeConfig()) {
			result.put(REQUEST_PARAM_HOST_NAME, mapping.getExchangeConfig().getHostName());
			result.put(REQUEST_PARAM_ATTACHMENT_PATH, mapping.getExchangeConfig().getAttachmentPath());
			result.put(REQUEST_PARAM_WAIT_TIME_BETWEEN_POLL, mapping.getExchangeConfig().getWaitTimeBetweenPoll());
			result.put(REQUEST_PARAM_SUPPORT_EMAIL, mapping.getExchangeConfig().getSupportEmail());
			result.put(REQUEST_PARAM_MAX_ERROR_EMAIL_COUNT, mapping.getExchangeConfig().getMaxErrorEmailCount());
			result.put(REQUEST_PARAM_DOMAIN, mapping.getExchangeConfig().getDomain());
			result.put(REQUEST_PARAM_VERSION, mapping.getExchangeConfig().getVersion());
			result.put(REQUEST_PARAM_EXCHANGE_WEB_SERVICE_URL, mapping.getExchangeConfig().getExchangeWebServiceUrl());
		} else {
			addDefaultExchangeConfig(result);
		}
	}
	
	/**
	 * This method gets the default exchange configuration for any mailbox
	 * @return BasicDBObject
	 */
	public BasicDBObject getDefaultExchangeData() {
		BasicDBObject result = new BasicDBObject();
		try {
			addDefaultExchangeConfig(result);
		} catch (Exception e) {
			logger.error("Exception while retriving default exchange fields from DB : ",e);
			result = addResponseParameters(false, "Could not retrive default exchange fields from DB" );
		}
		return result;
	}

	
	/**
	 * This method adds default exchange configuration.
	 * @param result
	 */
	private void addDefaultExchangeConfig(BasicDBObject result) {
		result.put(REQUEST_PARAM_HOST_NAME, readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_HOST_NAME));
		result.put(REQUEST_PARAM_ATTACHMENT_PATH,readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_ATTACHMENT_PATH) );
		result.put(REQUEST_PARAM_WAIT_TIME_BETWEEN_POLL, readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_WAIT_TIME_BETWEEN_POLL));
		result.put(REQUEST_PARAM_SUPPORT_EMAIL, readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_SUPPORT_EMAIL));
		result.put(REQUEST_PARAM_MAX_ERROR_EMAIL_COUNT, readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_MAX_ERROR_EMAIL_COUNT));
		result.put(REQUEST_PARAM_DOMAIN, readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_DOMAIN));
		result.put(REQUEST_PARAM_VERSION, readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_VERSION));
		result.put(REQUEST_PARAM_EXCHANGE_WEB_SERVICE_URL, readerUtil.getDefaultExchangeConfigValueForMailBox(REQUEST_PARAM_EXCHANGE_WEB_SERVICE_URL));
		result.put(DB_ALLOWED_DOMAINS, readerUtil.getDefaultExchangeConfigValueForMailBox(DB_ALLOWED_DOMAINS));
		result.put(DB_READER_BATCH_SIZE, readerUtil.getDefaultExchangeConfigValueForMailBox(DB_READER_BATCH_SIZE));
	}
	
	/**
	 * This method adds a database entry for MailBoxDLMapping Collection.
	 * @param mapping
	 * @return boolean
	 */
	private boolean addAnEntryIntoMailBoxDLMapping(MailBoxDLMapping mapping) {
		return addOrUpdateMappingEntryIntoDB(mapping);
	}
	
	/**
	 * This method updates a database entry for MailBoxDLMapping Collection.
	 * @param mapping
	 * @return boolean
	 */
	private boolean updateAnEntryIntoMailBoxDLMapping(MailBoxDLMapping mapping) {
		return addOrUpdateMappingEntryIntoDB(mapping);
	}

	/**
	 * This method adds a new entry or updates the existing entry into database.
	 * @param mapping
	 * @return
	 */
	private boolean addOrUpdateMappingEntryIntoDB(MailBoxDLMapping mapping) {
		boolean success = false;
		try {
			dataStore.save(mapping);
			success = true;
			HazelCastCacheIncrementalLoad.refreshMailBoxDLMappings(mapping.getId());
		} catch (Exception e) {
			logger.error("Exception while adding reader entry in database for mailbox  {} :",mapping.getId(), e);
		}
		return success;
	}
	
	/**
	 * This method adds a database entry for MailBoxDLMapping Collection.
	 * @param mapping
	 * @return boolean
	 */
	private boolean removeAnEntryFromMailBoxDLMapping(MailBoxDLMapping mapping) {
		boolean success = false;
		try {
			dataStore.delete(mapping);
			success = true;
			HazelCastCacheIncrementalLoad.removeMailBoxDLMappings(mapping.getId());
		} catch (Exception e) {
			logger.error("Exception while removing reader entry from database for mailbox {}:",mapping.getId(), e);
		}
		return success;
	}
}