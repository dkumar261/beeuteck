package com.citi.icg.qma.performance.utils.verification;

import org.apache.commons.lang.StringUtils;
import dev.morphia.Datastore;
import dev.morphia.Morphia;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.DecryptionUtil;
import com.citi.icg.qma.common.core.util.QmaMailConstants;
import com.citi.icg.qma.common.server.dao.BaseEntity;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.MongoClientURI;
import com.mongodb.WriteConcern;

public class DBHelper {

	private static Logger logger = LoggerFactory.getLogger(DBHelper.class);
	private static Datastore uatDatastore = null;
	private static Datastore prodDatastore = null;
	
	//deprecated
	public static Datastore getMongoUAT() {
		//Use arg construtor to create datastore -- sonar fix 'Password' detected in this expression, review this potentially hard-coded credential.
		return uatDatastore;
	}
	
	//deprecated
	public static Datastore getMongoPROD() {
		//Use arg construtor to create datastore -- sonar fix 'Password' detected in this expression, review this potentially hard-coded credential.
		return prodDatastore;
	}

	public static Datastore getMongoUAT(String dbPassword,String dbPasswordIV) {
		
		if (uatDatastore == null) {
			String dbName = "xmc";		
			String dbUserName = "xstream";
			String cluster = "maas-gt-p269-l2005:37017,maas-mw-p269-l2003:37017,maas-sw-p269-l2001:37017";
			uatDatastore = getMongoDatastore(dbName, dbUserName, dbPassword, dbPasswordIV, cluster);
		} 		
		BaseEntity.setMongoDatastore(uatDatastore);
		return uatDatastore;
	}

	public static Datastore getMongoPROD(String dbPassword,String dbPasswordIV) {
		if (prodDatastore == null ) {
			String dbName = "xmc";		
			String dbUserName = "xstream";
			String cluster = "MAAS-MW-P252-XX2001:37017,MAAS-SW-P251-XX2001:37017,MAAS-GT-P254-XX2001:37017/?ssl=true&authSource=admin";
			prodDatastore = getMongoDatastore(dbName, dbUserName, dbPassword, dbPasswordIV, cluster);
		}		
		BaseEntity.setMongoDatastore(prodDatastore);
		return prodDatastore;
	}

	private static Datastore getMongoDatastore(String dbName, String dbUserName, String dbPassword, String dbPasswordIV, String cluster) {

		Builder builder = MongoClientOptions.builder();
		builder.socketTimeout(1600000);
		builder.connectTimeout(1200000);
		//setConnectionPoolConfig(builder);

		// [C153176-980] Mongo driver upgrade to 3.x change
		builder.sslInvalidHostNameAllowed(true);
		//setMongoDBLogLevel();

		
		// String propFile = "db-" + xmcEnvironment + ".properties";
		// logger.info(" Loading properties for " + xmcEnvironment + "file name
		// is" + propFile);

		//MongoDBConfig mongoDBConfig = QmaMailConfigLoader.getConfig().getMongoDBConfig();
		//MongoDB.setDB_NAME(mongoDBConfig.getDbName());
		//BACKUP_DB_NAME = mongoDBConfig.getBackupdbName();
//		String userName = mongoDBConfig.getUserName();
//		String password = DecryptionUtil.decrypt(mongoDBConfig.getPassword(), mongoDBConfig.getPasswordIV(),QmaMailConstants.APPLICATION_ENCRYPTION_KEY);
		
		//String clusterServers = mongoDBConfig.getMongoCluster();
//		logger.info("Connecting to " + DB_NAME + " db, at " + clusterServers);

		String userName = dbUserName;
		String password = DecryptionUtil.decrypt(dbPassword, dbPasswordIV, QmaMailConstants.APPLICATION_ENCRYPTION_KEY);
		MongoClientURI mcURI = new MongoClientURI("mongodb://" + userName + ":" + password + "@" + cluster,
				builder);
		logger.info("Cacerts Path before connecting to mongo: " + System.getProperty("javax.net.ssl.trustStore"));
		MongoClient mongoClient = new MongoClient(mcURI);
		//mongoClient.setWriteConcern(WriteConcern.SAFE);
		//mongoClient.setWriteConcern(WriteConcern.NORMAL);
		Morphia morphia = new Morphia().mapPackage(BaseEntity.class.getPackage().getName());
		Datastore datastore = morphia.createDatastore(mongoClient, dbName);
//		BaseEntity.setMongoDatastore(datastore);

//		MongoClient secondaryMongoClient = new MongoClient(mcURI);
//		// secondaryMongoClient.setWriteConcern(WriteConcern.SAFE);
//		mongoClient.setWriteConcern(WriteConcern.NORMAL);
//		Morphia secondaryMorphia = new Morphia().mapPackage(BaseEntity.class.getPackage().getName());
//		Object secondaryDatastore = secondaryMorphia.createDatastore(secondaryMongoClient, DB_NAME);
		// BaseEntity.setSecondaryMongoDatastore(secondaryDatastore);// TODO?
		// CHECK IF REQUIRED, IN CASE OF MORPHIA

//		logger.info("Connection to database '" + DB_NAME + "' initialized");
		return datastore;

	}

	private static void setConnectionPoolConfig(Builder builder) {
		try {
			String dbpoolSize = System.getProperty("dbPoolSize");
			logger.debug("In MongoDB.....Connection pool size configured = " + dbpoolSize);
			if (StringUtils.isNotBlank(dbpoolSize)) {
				// builder.connectionsPerHost(5000);

				//builder.threadsAllowedToBlockForConnectionMultiplier(Integer.parseInt(dbpoolSize));
			}
		} catch (Exception e) {
			logger.error("In MongoDB.....Error in setConnectionPool", e);
		}

	}
}
