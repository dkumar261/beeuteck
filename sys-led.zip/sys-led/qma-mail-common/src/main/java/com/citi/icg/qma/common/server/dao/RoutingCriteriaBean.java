package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

public class RoutingCriteriaBean implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2065954753035509133L;
	private Long groupId;
	private String groupName;
	private String groupEmail;
	private String from;
	private String fromOperator;
		// Enhance inquiry rules to include the TO field.
	private String to;
	private String toOperator;
	private String subject;
	private String subjectOperator;
	private RuleAction actions;
	private Date createdTime;
	
	private Integer ruleOrder;
	private Boolean attachment;
	
	public RoutingCriteriaBean()
	{
		
	}
	public Long getGroupId()
	{
		return groupId;
	}
	public void setGroupId(Long groupId)
	{
		this.groupId = groupId;
	}
	public String getGroupName()
	{
		return groupName;
	}
	public void setGroupName(String groupName)
	{
		this.groupName = groupName;
	}
	public String getGroupEmail()
	{
		return groupEmail;
	}
	public void setGroupEmail(String groupEmail)
	{
		this.groupEmail = groupEmail;
	}
	public String getFrom()
	{
		return from;
	}
	public void setFrom(String from)
	{
		this.from = from;
	}
	public String getFromOperator()
	{
		return fromOperator;
	}
	public void setFromOperator(String fromOperator)
	{
		this.fromOperator = fromOperator;
	}
	public String getSubject()
	{
		return subject;
	}
	public void setSubject(String subject)
	{
		this.subject = subject;
	}
	public String getSubjectOperator()
	{
		return subjectOperator;
	}
	public void setSubjectOperator(String subjectOperator)
	{
		this.subjectOperator = subjectOperator;
	}
	public RuleAction getActions()
	{
		return actions;
	}
	public void setActions(RuleAction actions)
	{
		this.actions = actions;
	}
	public Date getCreatedTime()
	{
		return createdTime;
	}
	public void setCreatedTime(Date createdTime)
	{
		this.createdTime = createdTime;
	}
	
	public Integer getRuleOrder()
	{
		return ruleOrder;
	}
	public void setRuleOrder(Integer ruleOrder)
	{
		this.ruleOrder = ruleOrder;
	}
		// Enhance inquiry rules to include the TO field.
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getToOperator() {
		return toOperator;
	}
	public void setToOperator(String toOperator) {
		this.toOperator = toOperator;
	}
	public Boolean getAttachment() {
		return attachment;
	}
	public void setAttachment(Boolean attachment) {
		this.attachment = attachment;
	}
	@Override
	public String toString()
	{
		// TODO Auto-generated method stub
		return this.ruleOrder +"";
	}
	
}
