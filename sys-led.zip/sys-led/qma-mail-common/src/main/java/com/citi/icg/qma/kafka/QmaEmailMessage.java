package com.citi.icg.qma.kafka;

import jakarta.mail.Message;

public class QmaEmailMessage {

	private String guid;
	private Message message;

	public QmaEmailMessage() {
		super();
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

}
