package com.citi.icg.qma.common.server.dao;

import java.util.Date;

import dev.morphia.annotations.Entity;

@Entity(value = "MISReportExclusion", noClassnameStored = true)
public class MISReportExclusionRecord extends BaseEntity
{
	private String groupName;
	private Integer groupId;
	private String misExclusionReportName;
	private Integer misExclusionTimelineInMonths;
	private Date misExclusionStartDate;
	private Date misExclusionEndDate;
	private String misExclusionReason;
	private boolean active;
	private String comments;

	public MISReportExclusionRecord()
	{
		super();
	}

	public String getGroupName()
	{
		return groupName;
	}

	public Integer getGroupId()
	{
		return groupId;
	}

	public void setGroupId(Integer groupId)
	{
		this.groupId = groupId;
	}

	public void setGroupName(String groupName)
	{
		this.groupName = groupName;
	}

	public String getMisExclusionReportName()
	{
		return misExclusionReportName;
	}

	public void setMisExclusionReportName(String misExclusionReportName)
	{
		this.misExclusionReportName = misExclusionReportName;
	}

	public Integer getMisExclusionTimelineInMonths()
	{
		return misExclusionTimelineInMonths;
	}

	public void setMisExclusionTimelineInMonths(Integer misExclusionTimelineInMonths)
	{
		this.misExclusionTimelineInMonths = misExclusionTimelineInMonths;
	}

	public Date getMisExclusionStartDate()
	{
		return misExclusionStartDate;
	}

	public void setMisExclusionStartDate(Date misExclusionStartDate)
	{
		this.misExclusionStartDate = misExclusionStartDate;
	}

	public Date getMisExclusionEndDate()
	{
		return misExclusionEndDate;
	}

	public void setMisExclusionEndDate(Date misExclusionEndDate)
	{
		this.misExclusionEndDate = misExclusionEndDate;
	}

	public String getMisExclusionReason()
	{
		return misExclusionReason;
	}

	public void setMisExclusionReason(String misExclusionReason)
	{
		this.misExclusionReason = misExclusionReason;
	}

	public boolean isActive()
	{
		return active;
	}

	public void setActive(boolean active)
	{
		this.active = active;
	}

	public String getComments()
	{
		return comments;
	}

	public void setComments(String comments)
	{
		this.comments = comments;
	}
}
