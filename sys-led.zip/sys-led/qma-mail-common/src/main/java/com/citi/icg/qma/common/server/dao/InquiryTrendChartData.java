package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import dev.morphia.annotations.Entity;

@Entity(value = "InquiryTrendChartData", noClassnameStored = true)
public class InquiryTrendChartData extends BaseEntity implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 744070916217448354L;
	private Long groupId;
	private String groupName;
	private Date date;
	private long count;
	private Map<String,Object> timeFrame;
	
	//non inquiry count
	private long nonInquiryCount;
	private Map<String,Object> nonInquiryTimeFrame;

	public InquiryTrendChartData() {
		super();
	}

	public InquiryTrendChartData(Long groupId, String groupName, Date date, long count) {
		super();
		this.groupId = groupId;
		this.groupName = groupName;
		this.date = date;
		this.count = count;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Map<String, Object> getTimeFrame() {
		return timeFrame;
	}

	public void setTimeFrame(Map<String, Object> timeFrame) {
		this.timeFrame = timeFrame;
	}

	public long getNonInquiryCount() {
		return nonInquiryCount;
	}

	public void setNonInquiryCount(long nonInquiryCount) {
		this.nonInquiryCount = nonInquiryCount;
	}

	public Map<String, Object> getNonInquiryTimeFrame() {
		return nonInquiryTimeFrame;
	}

	public void setNonInquiryTimeFrame(Map<String, Object> nonInquiryTimeFrame) {
		this.nonInquiryTimeFrame = nonInquiryTimeFrame;
	}



	
}
