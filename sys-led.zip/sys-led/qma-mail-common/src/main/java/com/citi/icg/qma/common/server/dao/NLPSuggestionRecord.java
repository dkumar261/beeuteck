package com.citi.icg.qma.common.server.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.citi.icg.qma.common.core.util.QmaMailConstants;

import dev.morphia.annotations.Entity;

@Entity(value = "NLPSuggestionRecord", noClassnameStored = true)
public class NLPSuggestionRecord extends BaseEntity
{

	private Long inquiryid;
	private Long conversationId;
	private	String qmaRequestId;//UUID
	private String nlpRequestId;
	private Date nlpRequestSentDate;
	private Date nlpResponseReceivedDate;
	private String suggestionReqBody;
	private String suggestedResponse;
	private Integer suggestionReqStatusCode;
	private String processingStatus;
	private String suggestionReqStatusDesc;
	private String nlpRespTimeInSecs;
	private String actionBy;
	private List<Long> eligibleGroupIdList;
	private List<GroupData> groupData;
	private String nlpRequestType;
	private AutoRouting autoRouting;
	private List<Long> validToCcGroupIds;
	private Map<String, Object> httpRequestHeaders;
	
	//New fields
	private String replyComment;
	//JSON parsable string
	private String intermediateData;
	private List<Object> suggestedResponseTradeDetails;
	// Error/integration message from NLP API
	private String message;
	//This field indicates NLP response status Red, blue and Green
	//responseLevelIndicator= 3, along with the relevant error message
	//responseLevelIndicator= 1
	//responseLevelIndicator= 2
	private Integer responseLevelIndicator;
	
	private Map<String, Object> statistics;
	private String tradesInfo;
	private List<Intents> intentList;
	private Map<String, Object> intentStatistics;
	private Boolean intentSuggested;
	private List<String> intentValueDates;
	private String intentMessage;
	private List<IntentFeedback> intentFeedback;
	private String intentReturnCode;
	
	
	
	public NLPSuggestionRecord()
	{
		super();
	}



	public Long getInquiryid()
	{
		return inquiryid;
	}



	public void setInquiryid(Long inquiryid)
	{
		this.inquiryid = inquiryid;
	}



	public Long getConversationId()
	{
		return conversationId;
	}



	public void setConversationId(Long conversationId)
	{
		this.conversationId = conversationId;
	}



	public String getQmaRequestId()
	{
		return qmaRequestId;
	}



	public void setQmaRequestId(String qmaRequestId)
	{
		this.qmaRequestId = qmaRequestId;
	}



	/**
	 * @return the nlpRequestId
	 */
	public String getNlpRequestId() {
		return nlpRequestId;
	}



	/**
	 * @param nlpRequestId the nlpRequestId to set
	 */
	public void setNlpRequestId(String nlpRequestId) {
		this.nlpRequestId = nlpRequestId;
	}



	public Date getNlpRequestSentDate()
	{
		return nlpRequestSentDate;
	}



	public void setNlpRequestSentDate(Date nlpRequestSentDate)
	{
		this.nlpRequestSentDate = nlpRequestSentDate;
	}



	public Date getNlpResponseReceivedDate()
	{
		return nlpResponseReceivedDate;
	}



	public void setNlpResponseReceivedDate(Date nlpResponseReceivedDate)
	{
		this.nlpResponseReceivedDate = nlpResponseReceivedDate;
	}



	public String getSuggestedResponse()
	{
		return suggestedResponse;
	}



	public void setSuggestedResponse(String suggestionResponse)
	{
		this.suggestedResponse = suggestionResponse;
	}



	public String getSuggestionReqBody()
	{
		return suggestionReqBody;
	}



	public void setSuggestionReqBody(String suggestionReqBody)
	{
		this.suggestionReqBody = suggestionReqBody;
	}



	public Integer getSuggestionReqStatusCode()
	{
		return suggestionReqStatusCode;
	}



	public void setSuggestionReqStatusCode(Integer suggestionReqStatusCode)
	{
		this.suggestionReqStatusCode = suggestionReqStatusCode;
	}



	/**
	 * @return the processingStatus
	 */
	public String getProcessingStatus() {
		return processingStatus;
	}



	/**
	 * @param processingStatus the processingStatus to set
	 */
	public void setProcessingStatus(String processingStatus) {
		this.processingStatus = processingStatus;
	}



	public String getSuggestionReqStatusDesc()
	{
		return suggestionReqStatusDesc;
	}



	public void setSuggestionReqStatusDesc(String suggestionReqStatusDesc)
	{
		this.suggestionReqStatusDesc = suggestionReqStatusDesc;
	}



	public String getNlpRespTimeInSecs()
	{
		return nlpRespTimeInSecs;
	}



	public void setNlpRespTimeInSecs(String nlpRespTimeInSecs)
	{
		this.nlpRespTimeInSecs = nlpRespTimeInSecs;
	}


	/**
	 * @return the actionBy
	 */
	public String getActionBy() {
		return actionBy;
	}



	/**
	 * @param actionBy the actionBy to set
	 */
	public void setActionBy(String actionBy) {
		this.actionBy = actionBy;
	}



	/**
	 * @return the eligibleGroupIdList
	 */
	public List<Long> getEligibleGroupIdList() {
		return eligibleGroupIdList;
	}



	/**
	 * @param eligibleGroupIdList the eligibleGroupIdList to set
	 */
	public void setEligibleGroupIdList(List<Long> eligibleGroupIdList) {
		this.eligibleGroupIdList = eligibleGroupIdList;
	}
	
	/**
	 * This function adds provided groupID to eligibleGroupIdList
	 * @param groupID
	 */
	public void addToEligibleGroupIdList(Long groupId) {
		if(this.getEligibleGroupIdList()==null){
			this.setEligibleGroupIdList(new ArrayList<>());
		}
		this.getEligibleGroupIdList().add(groupId);
	}



	/**
	 * @return the groupData
	 */
	public List<GroupData> getGroupData() {
		return groupData;
	}



	/**
	 * @param groupData the groupData to set
	 */
	public void setGroupData(List<GroupData> groupData) {
		this.groupData = groupData;
	}

	public String getNlpRequestType() {
		return nlpRequestType;
	}

	public void setNlpRequestType(String nlpRequestType) {
		this.nlpRequestType = nlpRequestType;
	}
	

	public AutoRouting getAutoRouting() {
		return autoRouting;
	}



	public void setAutoRouting(AutoRouting autoRouting) {
		this.autoRouting = autoRouting;
	}



	public List<Long> getValidToCcGroupIds() {
		return validToCcGroupIds;
	}

	public void setValidToCcGroupIds(List<Long> validToCcGroupIds) {
		this.validToCcGroupIds = validToCcGroupIds;
	}
	
	public Map<String, Object> getHttpRequestHeaders() {
		return httpRequestHeaders;
	}



	public void setHttpRequestHeaders(Map<String, Object> httpRequestHeaders) {
		this.httpRequestHeaders = httpRequestHeaders;
	}

	public String getReplyComment() {
		return replyComment;
	}

	public void setReplyComment(String replyComment) {
		this.replyComment = replyComment;
	}


	public String getIntermediateData() {
		return intermediateData;
	}



	public void setIntermediateData(String intermediateData) {
		this.intermediateData = intermediateData;
	}

	public List<Object> getSuggestedResponseTradeDetails() {
		return suggestedResponseTradeDetails;
	}
	public void setSuggestedResponseTradeDetails(List<Object> suggestedResponseTradeDetails) {
		this.suggestedResponseTradeDetails = suggestedResponseTradeDetails;
	}

	public String getMessage() {
		return message;
	}



	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getResponseLevelIndicator() {
		return responseLevelIndicator;
	}



	public void setResponseLevelIndicator(Integer responseLevelIndicator) {
		this.responseLevelIndicator = responseLevelIndicator;
	}

	public Map<String, Object> getStatistics() {
		return statistics;
	}

	public void setStatistics(Map<String, Object> statistics) {
		this.statistics = statistics;
	}

	public String getTradesInfo() {
		return tradesInfo;
	}

	public void setTradesInfo(String tradesInfo) {
		this.tradesInfo = tradesInfo;
	}

	public List<Intents> getIntentList() {
		return intentList;
	}

	public void setIntentList(List<Intents> intentList) {
		this.intentList = intentList;
	}

	public Map<String, Object> getIntentStatistics() {
		return intentStatistics;
	}

	public void setIntentStatistics(Map<String, Object> intentStatistics) {
		this.intentStatistics = intentStatistics;
	}
	


	public List<String> getIntentValueDates() {
		return intentValueDates;
	}



	public void setIntentValueDates(List<String> intentValueDates) {
		this.intentValueDates = intentValueDates;
	}



	public String getIntentReturnCode() {
		return intentReturnCode;
	}



	public void setIntentReturnCode(String intentReturnCode) {
		this.intentReturnCode = intentReturnCode;
	}


	public Boolean getIntentSuggested() {
		return intentSuggested;
	}



	public void setIntentSuggested(Boolean intentSuggested) {
		this.intentSuggested = intentSuggested;
	}

	public String getIntentMessage() {
		return intentMessage;
	}



	public void setIntentMessage(String intentMessage) {
		this.intentMessage = intentMessage;
	}

	

	public List<IntentFeedback> getIntentFeedback() {
		return intentFeedback;
	}



	public void setIntentFeedback(List<IntentFeedback> intentFeedback) {
		this.intentFeedback = intentFeedback;
	}



	public static class GroupData {
		private Long groupId;
		private int acceptCount;
		private int declineCount;
		private String responseEditedFlag;
		private String lastAction;
		private String lastActionBy;
		private String suggestionStatus;
		private Date lastActionTime;
		private String declineComment;
		private String feedbackComment;
		private Object actionDetails;
		private Boolean userFeedback;
		public GroupData(){/*Default Constructor*/}
		public GroupData(Long groupId){
			this.groupId = groupId;
			this.suggestionStatus= QmaMailConstants.SUGGESTION_STATUS_NOT_SENT;
		}
		public GroupData(Long groupId, String lastAction, String lastActionBy, Date lastActionTime){
			this.groupId = groupId;
			this.lastAction = lastAction;
			this.lastActionBy = lastActionBy;
			this.lastActionTime = lastActionTime;
			this.suggestionStatus= QmaMailConstants.SUGGESTION_STATUS_NOT_SENT;
		}
		/**
		 * @return the groupId
		 */
		public Long getGroupId() {
			return groupId;
		}
		/**
		 * @param groupId the groupId to set
		 */
		public void setGroupId(Long groupId) {
			this.groupId = groupId;
		}
		/**
		 * @return the suggestion acceptCount
		 */
		public int getAcceptCount() {
			return acceptCount;
		}
		/**
		 * @param suggestion acceptCount the suggestion acceptCount to set
		 */
		public void setAcceptCount(int acceptCount) {
			this.acceptCount = acceptCount;
		}
		/**
		 * @return the suggestion declineCount
		 */
		public int getDeclineCount() {
			return declineCount;
		}
		/**
		 * @param suggestion declineCount the suggestion declineCount to set
		 */
		public void setDeclineCount(int declineCount) {
			this.declineCount = declineCount;
		}
		/**
		 * @return the responseEditedFlag
		 */
		public String getResponseEditedFlag() {
			return responseEditedFlag;
		}
		/**
		 * @param responseEditedFlag the responseEditedFlag to set
		 */
		public void setResponseEditedFlag(String responseEditedFlag) {
			this.responseEditedFlag = responseEditedFlag;
		}
		/**
		 * @return the lastAction
		 */
		public String getLastAction() {
			return lastAction;
		}
		/**
		 * @param lastAction the lastAction to set
		 */
		public void setLastAction(String lastAction) {
			this.lastAction = lastAction;
		}
		/**
		 * @return the lastActionBy
		 */
		public String getLastActionBy() {
			return lastActionBy;
		}
		/**
		 * @param lastActionBy the lastActionby to set
		 */
		public void setLastActionBy(String lastActionBy) {
			this.lastActionBy = lastActionBy;
		}
		/**
		 * @return the suggestionStatus
		 */
		public String getSuggestionStatus() {
			return suggestionStatus;
		}
		/**
		 * @param suggestionStatus the suggestionStatus to set
		 */
		public void setSuggestionStatus(String suggestionStatus) {
			this.suggestionStatus = suggestionStatus;
		}
		/**
		 * @return the lastActionTime
		 */
		public Date getLastActionTime() {
			return lastActionTime;
		}
		/**
		 * @param lastActionTime the lastActionTime to set
		 */
		public void setLastActionTime(Date lastActionTime) {
			this.lastActionTime = lastActionTime;
		}
		/**
		 * @return the declineComment
		 */
		public String getDeclineComment() {
			return declineComment;
		}
		/**
		 * @param declineComment the declineComment to set
		 */
		public void setDeclineComment(String declineComment) {
			this.declineComment = declineComment;
		}
		public String getFeedbackComment() {
			return feedbackComment;
		}
		public void setFeedbackComment(String feedbackComment) {
			this.feedbackComment = feedbackComment;
		}
		public Object getActionDetails() {
			return actionDetails;
		}
		public void setActionDetails(Object actionDetails) {
			this.actionDetails = actionDetails;
		}
		public Boolean getUserFeedback() {
			return userFeedback;
		}
		public void setUserFeedback(Boolean userFeedback) {
			this.userFeedback = userFeedback;
		}
	
		
	}
	
	public static class IntentFeedback{
		
		private Long groupId;
		private boolean intentUserFeedback;
		private Object correctIntents;
		private String description;
		private String actionBy;
		private Date actionTime;
		public IntentFeedback() {
			super();
		}
		
		public IntentFeedback(Long groupId, boolean intentUserFeedback, Object correctIntents,
				String description, String actionBy, Date actionTime) {
			super();
			this.groupId = groupId;
			this.intentUserFeedback = intentUserFeedback;
			this.correctIntents = correctIntents;
			this.description = description;
			this.actionBy = actionBy;
			this.actionTime = actionTime;
		}

		public IntentFeedback(Long groupId, boolean intentUserFeedback, String description, String actionBy,
				Date actionTime) {
			super();
			this.groupId = groupId;
			this.intentUserFeedback = intentUserFeedback;
			this.description = description;
			this.actionBy = actionBy;
			this.actionTime = actionTime;
		}

		public boolean isIntentUserFeedback() {
			return intentUserFeedback;
		}

		public void setIntentUserFeedback(boolean intentUserFeedback) {
			this.intentUserFeedback = intentUserFeedback;
		}

		public Long getGroupId() {
			return groupId;
		}
		public void setGroupId(Long groupId) {
			this.groupId = groupId;
		}
		

		public Object getCorrectIntents() {
			return correctIntents;
		}

		public void setCorrectIntents(Object correctIntents) {
			this.correctIntents = correctIntents;
		}

		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getActionBy() {
			return actionBy;
		}
		public void setActionBy(String actionBy) {
			this.actionBy = actionBy;
		}
		public Date getActionTime() {
			return actionTime;
		}
		public void setActionTime(Date actionTime) {
			this.actionTime = actionTime;
		}
		
	}
	
}