/**
 * 
 */
package com.citi.icg.qma.common.contact.exception;

/**
 * 
 *
 */
public class UnauthorizedException extends Exception {
	private static final long serialVersionUID = 8235467588044371308L;

	public UnauthorizedException(String message) {
		super(message);
	}

}
