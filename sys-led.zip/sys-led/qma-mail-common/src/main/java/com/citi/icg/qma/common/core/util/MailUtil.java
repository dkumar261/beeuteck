package com.citi.icg.qma.common.core.util;

import java.io.File;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Enumeration;
import java.util.logging.Level;

import com.citi.icg.qma.config.QmaMailConfigLoader;
import jakarta.activation.DataHandler;
import jakarta.activation.FileDataSource;
import jakarta.mail.Header;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.Multipart;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.*;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.config.AppConfiguration;
import com.citi.icg.qma.common.core.subscriber.mails.MailHeaders;

/**
 * Utility class to send email notifications.
 */
public class MailUtil
{
	/*Added character set */
	private static final String MIME_TEXT_PLAIN = "text/plain;";
	private static final String MIME_TEXT_HTML = "text/html;";
	private static final String MIME_TEXT_MULTIPART = "multipart/*";
	private static final String MIME_BINARY_MULTIPART = "application/octet-stream";
	private static final Logger logger = LoggerFactory.getLogger(MailUtil.class);
	/** Port. */
	private static final Integer PORT = Integer.valueOf(25);

	/** SMTP host. */
	private static final String SMTP_HOST = "mail.smtp.host";

	/** SMTP host. */
	private static final String SMTP_PORT = "mail.smtp.port";
	private static final String QMA_ICG_ENV="icg.env";

	private MailUtil(){
		//As this class is Util, so added making private constructor.
		//Sonar Fix -- Utility classes should not have public constructors 
	}

	/*@Deprecated
	*//** @deprecated as of 1.6. Use version with java.util.loggin.Level *//*
	public static void notifySupport(String subject, String message)
	{
		notifySupport(Level.INFO, subject, message, null);
	}
*/
	@Deprecated
	//** @deprecated as of 1.6. Use version with java.util.loggin.Level *//*
	public static void notifySupport(String subject, String message, Throwable ex)
	{
		notifySupport(Level.INFO, subject, message, ex);
	}

	public static void notifySupport(Level level, String subject, String message)
	{
		notifySupport(level, subject, message, null);
	}

	public static void notifySupport(Level level, String subject, String message, Throwable ex)
	{

		String[] recipents = new String[] { AppConfiguration.getInstance().getSupportEmail() };

		String envSubStr = addEnvInSubject(level, subject);

		StringBuilder envMessage = new StringBuilder();
		envMessage.append(message);
		if (ex != null)
		{
			envMessage.append("\nCause: " + ex.getCause());
			envMessage.append("\nMessage: " + ex.getLocalizedMessage());
			//envMessage.append("\nStack Trace: " + GwtServiceUtil.getStackTrace(ex));
		}
		if (!AppConfiguration.getInstance().getSupportEmailDisabled())
		{
			sendMail(recipents, AppConfiguration.getInstance().getSupportEmail(), envSubStr, envMessage.toString(), false);
		}
		else
		{
			logger.error(MailUtil.class + " Support Notification: " + envSubStr + envMessage.toString());
		}
	}

	/**
	 *@deprecated as of 1.6. Use version with java.util.loggin.Level *
	 */
	@Deprecated
	public static String addEnvInSubject(String subject)
	{
		return addEnvInSubject(Level.INFO, subject);
	}

	public static String addEnvInSubject(Level level, String subject)
	{
		StringBuilder envSubject = new StringBuilder();
		envSubject.append(AppConfiguration.getInstance().getApplicationName() + ':');
		try
		{
			envSubject.append('[' + StringUtils.upperCase(Environment.getEnvironment()) + ':' + level + ':'
					+ InetAddress.getLocalHost().getHostName() + ']');
		}
		catch (Exception e)
		{
			logger.error(MailUtil.class + " Support Notification: ", e);
		}
	//	envSubject.append('[' + RequestContext.getUserId() + ']');
		envSubject.append(subject);
		return envSubject.toString();
	}

	public static void sendMailFromSupport(String[] recipents, String subject, String message, boolean htmlFormat)
	{
		sendMail(recipents, AppConfiguration.getInstance().getSupportEmail(), subject, message, htmlFormat);
	}

	public static void sendMail(String[] recipents, String from, String subject, String message)
	{
		sendMail(recipents, from, subject, message, false);
	}

	public static void sendMailFromSupport(String[] recipients, String subject, String message, File attachment)
	{
		sendMail(AppConfiguration.getInstance().getSupportEmail(), subject, message, false, attachment, recipients);
	}

	public static void sendMail(String[] recipients, String from, String subject, String message, boolean htmlFormat)
	{
		sendMail(AppConfiguration.getInstance().getSupportEmail(), subject, message, htmlFormat, null, recipients);
		logger.info("From is not used here " + from);//Sonar Fix - remove the useless parameter..so use it

	}

	public static void sendMail(String from, String subject, String message, boolean htmlFormat, File attachment, String... recipients) {
		try {
			String fromMailBox = QmaMailConfigLoader.getConfig().getMBOX();
			InternetAddress[] address = new InternetAddress[recipients.length];
			InternetAddress sender = new InternetAddress(fromMailBox);
			Session session = MailCommonUtil.getSession(fromMailBox);
			for (int i = 0; i < address.length; i++) {
				address[i] = new InternetAddress(recipients[i]);
			}
			Message msg = new MimeMessage(session);
			msg.setFrom(sender);
			msg.setRecipients(Message.RecipientType.TO, address);
			msg.setSubject(subject);
			msg.setSentDate(new Date());

			String messageMime = htmlFormat ? MIME_TEXT_HTML : MIME_TEXT_PLAIN;
			if (attachment != null) {
				Multipart multipart = new MimeMultipart();
				if (message != null) {
					MimeBodyPart messageBodyPart = new MimeBodyPart();
					msg.setContent(message, messageMime);
					messageBodyPart.setText(message);
					multipart.addBodyPart(messageBodyPart);
				}
				FileDataSource source = new FileDataSource(attachment) {
					@Override
					public String getContentType()
					{
						return MIME_BINARY_MULTIPART;
					}
				};
				MimeBodyPart attachmentBodyPart = new MimeBodyPart();
				attachmentBodyPart.setFileName(attachment.getName());
				attachmentBodyPart.setDataHandler(new DataHandler(source));
				multipart.addBodyPart(attachmentBodyPart);
				msg.setContent(multipart);
			}
			else {
				msg.setContent(message, messageMime);
			}

			Transport.send(msg);
		}
		catch (MessagingException mex) {
			logger.error(mex.getMessage(), mex);
		}
	}

	public static String soeIdToEmail(String soeID)
	{
		return soeID.trim() + "XXXX.com";
	}
	
	/**
	 * @param stringData
	 * @return
	 */
	public static String getUTFEncodedString(String stringData) {
		String returnStr="";
		if(StringUtils.isNotEmpty(stringData)){
			returnStr = new String(stringData.getBytes(StandardCharsets.UTF_8));
		}
		return returnStr;
	}
	public static String getMessageId(Message message){
		String messageId = null;
		try{
			Enumeration<Header> parts = message.getAllHeaders();
			while (parts.hasMoreElements()) {
				Header header = (Header) parts.nextElement();
	
				if (MailHeaders.MESSAGEID.getName().equalsIgnoreCase(header.getName())) {
					messageId = header.getValue();
					break;
				}
			} 
		}catch (Exception e) {
			logger.error("Error while getting messageId:" + e);
		}
		return messageId;
	}
}
