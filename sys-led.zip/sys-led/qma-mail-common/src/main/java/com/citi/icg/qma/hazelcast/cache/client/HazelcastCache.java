package com.citi.icg.qma.hazelcast.cache.client;

import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.ClientMapping;
import com.citi.icg.qma.common.server.dao.ColumnDef;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.CustomClientCriteriaRuleBean;
import com.citi.icg.qma.common.server.dao.EmailAlias;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.HolidayMaster;
import com.citi.icg.qma.common.server.dao.IncomingToCcDLAliasMapping;
import com.citi.icg.qma.common.server.dao.KeyValue;
import com.citi.icg.qma.common.server.dao.MailBoxDLMapping;
import com.citi.icg.qma.common.server.dao.ManagementHeirarchy;
import com.citi.icg.qma.common.server.dao.OrgPreferences;
import com.citi.icg.qma.common.server.dao.OrganizationAuditTrail;
import com.citi.icg.qma.common.server.dao.RoutingCriteriaBean;
import com.citi.icg.qma.common.server.dao.StaticData;
import com.citi.icg.qma.common.server.dao.TimeZone;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.ViewConfig;
import com.citi.icg.qma.common.server.dao.persistence.MongoDB;
import com.citi.icg.qma.common.server.util.AgeAndTimeUtils.GroupShiftConfig;
import com.citi.icg.qma.common.transferobject.SymphonyUserMapTO;
import com.citi.icg.qma.config.QmaMailConfigLoader;
import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.client.config.ClientConnectionStrategyConfig;
import com.hazelcast.client.config.SocketOptions;
import com.hazelcast.client.util.ClientStateListener;
import com.hazelcast.config.InMemoryFormat;
import com.hazelcast.config.NearCacheConfig;
import com.hazelcast.config.SocketInterceptorConfig;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;

import dev.morphia.Datastore;
import dev.morphia.query.Query;


@SuppressWarnings("unchecked")
public final class HazelcastCache implements QMACache {

	private static Logger logger = LoggerFactory.getLogger(HazelcastCache.class);
	
	private static final String HAZELCAST_CLIENTS_STATISTICS_ENABLED = "hazelcast.client.statistics.enabled";
	private static final String HAZELCAST_LOGGING_TYPE = "hazelcast.logging.type";
	
	private static volatile HazelcastCache instance;
	private HazelcastInstance hz = null;

	private Boolean isPreLoadingDone = false;
	private static ClientStateListener clientStateListener;
	public  static Datastore mongoDatastore =  MongoDB.instance().getDataStore();
	

//	private static ThreadLocal<Integer> totalCacheHits = new ThreadLocal<Integer>() {
//															protected Integer initialValue() {
////																logger.info("HazelcastCache--totalCacheHits--initialValue called");
//																return 0;
//															};
//														};
//														
//	private static ThreadLocal<Integer> newCacheHits = new ThreadLocal<Integer>() {
//															protected Integer initialValue() {
////																logger.info("HazelcastCache--totalCacheHits--initialValue called");
//																return 0;
//															};
//														};
//														
	private HazelcastCache() {

		ClientConfig clientConfig=getHzClientConfig();
		clientStateListener = new ClientStateListener(clientConfig);
		logger.info("Initializing hazelcast client instance, if the success log doesn't come, please check Hazelcast server immediately!!");
		this.hz = HazelcastClient.newHazelcastClient(clientConfig);
		Runtime.getRuntime().addShutdownHook(new Thread(){
			;
		});
		try {
			clientStateListener.awaitConnected(100, TimeUnit.SECONDS);			
		} catch (InterruptedException e) {
			logger.error("Could not connect to Hazelcast",e);
		}		
		logger.info("Hazelcast client initialized successfully for the first time");
//		preload();
		
	}
	
	private static ClientConfig getHzClientConfigOld(){
		ClientConfig clientConfig = new ClientConfig();		
		clientConfig.getConnectionStrategyConfig()
			.setAsyncStart(false)
			.setReconnectMode(ClientConnectionStrategyConfig.ReconnectMode.ASYNC);
			
		clientConfig.getConnectionStrategyConfig().getConnectionRetryConfig()
				.setInitialBackoffMillis(1000)
		        .setMaxBackoffMillis(30000)
		        .setMultiplier(2)
		       // .setFailOnMaxBackoff(false)
		        .setJitter(0.2);
		      //  .setEnabled(true);

		clientConfig.getNetworkConfig()
				//.setConnectionAttemptLimit(0)
				.addAddress(QmaMailConfigLoader.getConfig().getHazelcastConfig().getHazelcastServerAddress());
		
		clientConfig.setProperty(HAZELCAST_CLIENTS_STATISTICS_ENABLED, "true");
		clientConfig.setClusterName(QmaMailConfigLoader.getConfig().getHazelcastConfig().getGroupName());
		//clientConfig.getGroupConfig().setName(QmaMailConfigLoader.getConfig().getHazelcastConfig().getGroupName());//qmadev
		if(null != QmaMailConfigLoader.getConfig().getHazelcastConfig().getInstanceName())
		{
			clientConfig.setInstanceName(QmaMailConfigLoader.getConfig().getHazelcastConfig().getInstanceName());
		}
		clientConfig.getMetricsConfig().getJmxConfig().setEnabled(false);
		NearCacheConfig nearCacheConfig = new NearCacheConfig()
			.setInMemoryFormat(InMemoryFormat.OBJECT);

		clientConfig.addNearCacheConfig(nearCacheConfig);
		clientConfig.setProperty(HAZELCAST_LOGGING_TYPE, "slf4j");
		
		return clientConfig;
	}
	
	private static ClientConfig getHzClientConfig() {
		ClientConfig clientConfig = new ClientConfig();
		String[] hazelcastServerAddress = null;
		clientConfig.getConnectionStrategyConfig().setAsyncStart(false).setReconnectMode(ClientConnectionStrategyConfig.ReconnectMode.ASYNC);
		clientConfig.getConnectionStrategyConfig().getConnectionRetryConfig().setMultiplier(2);
		clientConfig.getConnectionStrategyConfig().getConnectionRetryConfig().setJitter(0.2);
		clientConfig.getNetworkConfig().setSmartRouting(true);
        clientConfig.getNetworkConfig().isSmartRouting();
        clientConfig.getNetworkConfig().getSocketInterceptorConfig();
        clientConfig.getNetworkConfig().setSocketInterceptorConfig(new SocketInterceptorConfig());
        clientConfig.getNetworkConfig().getConnectionTimeout();
        clientConfig.getNetworkConfig().setConnectionTimeout(1000);
        
        if(null != QmaMailConfigLoader.getConfig().getHazelcastConfig().getInstanceName() 
        		&& QmaMailConfigLoader.getConfig().getHazelcastConfig().getInstanceName().equals("communicator-ui"))
        {
        	logger.info("Instance is communicator-ui so checking hazelcastSecondClusterConnectionConfig config value");
        	
        	Query<Config> query = mongoDatastore.createQuery(Config.class)
					.filter("_id", "hazelcastSecondClusterConnectionConfig");
			boolean hzClusterConnectionFlag = query.get().isHazelcastSecondClusterConnectionConfig();
			
			logger.info("Value of hazelcastSecondClusterConnectionConfig is " + hzClusterConnectionFlag);
			
			hazelcastServerAddress = hzClusterConnectionFlag == false? 
					QmaMailConfigLoader.getConfig().getHazelcastConfig().getHazelcastServerAddress()
					:QmaMailConfigLoader.getConfig().getHazelcastConfig().getHazelcastSecondClusterServerAddress();
        	
			String hzGroupName = hzClusterConnectionFlag == false? 
					QmaMailConfigLoader.getConfig().getHazelcastConfig().getGroupName()
					:QmaMailConfigLoader.getConfig().getHazelcastConfig().getSecondClusterGroupName();
			
    		clientConfig.setClusterName(hzGroupName);
        }else {
			hazelcastServerAddress = QmaMailConfigLoader.getConfig().getHazelcastConfig().getHazelcastServerAddress();
    		
    		clientConfig.setClusterName(QmaMailConfigLoader.getConfig().getHazelcastConfig().getGroupName());
        }
        
        clientConfig.getNetworkConfig().addAddress(hazelcastServerAddress);
		clientConfig.getNetworkConfig().getAddresses();
		clientConfig.getNetworkConfig().isRedoOperation();
	    clientConfig.getNetworkConfig().setRedoOperation(true);
	    clientConfig.getNetworkConfig().getSocketOptions();
	    clientConfig.getNetworkConfig().setSocketOptions(new SocketOptions());
	    
		clientConfig.setProperty(HAZELCAST_CLIENTS_STATISTICS_ENABLED, "true");
        if (null != QmaMailConfigLoader.getConfig().getHazelcastConfig().getInstanceName()) {
			clientConfig.setInstanceName(QmaMailConfigLoader.getConfig().getHazelcastConfig().getInstanceName());
		}
		clientConfig.getMetricsConfig().getJmxConfig().setEnabled(false);

        		
		NearCacheConfig nearCacheConfig = new NearCacheConfig().setInMemoryFormat(InMemoryFormat.OBJECT);
		clientConfig.addNearCacheConfig(nearCacheConfig);
		clientConfig.setProperty(HAZELCAST_LOGGING_TYPE, "slf4j");

		return clientConfig;
	}
	
	public static HazelcastCache getInstance() {
		if (instance == null) {
			synchronized (HazelcastCache.class) {
				if (instance == null) {
					instance = new HazelcastCache();
					
				}
			}
		}
//		incrTotalCacheHits();
		return instance;
	}
	
	
	@Override
	public void preload() {
//		Set<String> groupDataMapKeys = new HashSet<>(Arrays.asList("a", "b", "c"));
//		getGroupDataMap().getAll(groupDataMapKeys);
		Instant startTime = Instant.now();
		
		Instant temp = Instant.now();
		getClientMappingMap();
		logger.info("Cache Preloading Time  : clientMapping      : {} milliseconds", Duration.between(temp, Instant.now()).toMillis() );
		
		temp = Instant.now();
		getConfigById("configMap");
		logger.info("Cache Preloading Time  : configMap           : {} milliseconds", Duration.between(temp, Instant.now()).toMillis() );
		
		temp = Instant.now();
		IMap<String, Object> groupDataMap = getGroupDataMap();
		groupDataMap.get("parentToChildDLsListMap");
		groupDataMap.get("emailWithDomaintoGroupMap");
		groupDataMap.get("holidayMaster");
		groupDataMap.get("groupAgeConfigMap");
		groupDataMap.get("configIdMap");
		groupDataMap.get("groupList");
		groupDataMap.get("groupIdToNameMap");
		groupDataMap.get("groupIdToCIMSEmailList");
		groupDataMap.get("groupIdToManualEmailList");
		groupDataMap.get("dbRoutingCriteriaList");
		groupDataMap.get("groupCodeToEmailMap");
		groupDataMap.get("groupCodeToIdMap");
		groupDataMap.get("groupIdToCodeMap");
		groupDataMap.get("groupIdToEmailMap");
		groupDataMap.get("groupIdToActiveMap");
		groupDataMap.get("groupEmailToIdMap");
		groupDataMap.get("groupIdToDisclaimerMap");
		groupDataMap.get("groupIdToGrpCrtDateMap");
		groupDataMap.get("groupIdToRequestTypeMap");
		groupDataMap.get("groupIdToHierarchyMap");
		groupDataMap.get("groupIdToParentDLEmailAliasListMap");
		groupDataMap.get("groupIdToTagMap");
		groupDataMap.get("incomingToCcDLAliasMappingEmailsMap");
		groupDataMap.get("allGroupsMap");
		groupDataMap.get("groupIdToProcessingRegionMap");
		groupDataMap.get("groupCodeToIdMapBothActiveInactive");
		groupDataMap.get("groupIdToCodeMapBothActiveInactive");
		groupDataMap.get("groupIdToEmailMapBothActiveInactive");
		groupDataMap.get("personalGroupIdList");
		groupDataMap.get("personalMailboxIdToGroupIdMap");
		groupDataMap.get("dbCustomClientCriteriaList");
		groupDataMap.get("orgGroupMap"); //populate org group for hard code data point C170665-185
		groupDataMap.get("groupIdToDBCodeMap");
		logger.info("Cache Preloading Time  : groupDataMap        : {} milliseconds", Duration.between(temp, Instant.now()).toMillis() );
		
		temp = Instant.now();
		getMailBoxDLMappingMap();
		logger.info("Cache Preloading Time  : MailboxDLMappingMap : {} milliseconds", Duration.between(temp, Instant.now()).toMillis() );
		
		temp = Instant.now();
		getNlpConfiguration();
		logger.info("Cache Preloading Time  : nlpConfig           : {} milliseconds", Duration.between(temp, Instant.now()).toMillis() );
		
		temp = Instant.now();
		getStaticData();
		logger.info("Cache Preloading Time  : staticData          : {} milliseconds", Duration.between(temp, Instant.now()).toMillis() );
		
		temp = Instant.now();
		Map<String, User> userMap = getUserInfoMap();
//		userMap.get("XXXXXX");
		logger.info("Cache Preloading Time  : UserInfoMap         : {} milliseconds", Duration.between(temp, Instant.now()).toMillis() );
				
		temp = Instant.now();
		getUserSymphonyIdToUserMap();
		logger.info("Cache Preloading Time  : SymphonyIdToUserMap : {} milliseconds", Duration.between(temp, Instant.now()).toMillis() );
		
		// for load all request for hard code data point C170665-185
		temp = Instant.now();
		getOrgRequestsList();
		this.isPreLoadingDone = true;
		logger.info("Cache Preloading Time  : getOrgRequestsList : {} milliseconds", Duration.between(temp, Instant.now()).toMillis() );
		logger.info("Cache Preloading Time   :  TOTAL             : {} milliseconds", Duration.between(startTime, Instant.now()).toMillis() );
		logger.info("preloading of hazelcast cache data finished");
	}

	public HazelcastInstance getHZInstance() {
		try {
			if (hz.getLifecycleService().isRunning()) {
				// C170665-1068 : introduced below check to conditionally wait for 100 ms if hz client 
				// is disconnected and preloading is not done.
				boolean waitIfHzClientNotConnected = (this.isPreLoadingDone==false && clientStateListener.isConnected()==false);
				if (waitIfHzClientNotConnected) {
					boolean isConnected = clientStateListener.awaitConnected(100, TimeUnit.MILLISECONDS);
					if (isConnected == false ) {
						logger.error("Hazelcast client is disconnected from server, please check health of Hazelcast cluster immediately !!");
					}
				}
				return hz;
			} else {
				logger.error("hazelcast client is not running");				
			}
		} catch (InterruptedException e) {
			logger.error("Unable to Connect to Hazelcast Server");
		}
		return hz;

	}

//	public static Integer getTotalCacheHits() {
//		return totalCacheHits.get();
//	}
//
//	private static void resetTotalCacheHits() {
//		HazelcastCache.totalCacheHits.set(0);
//	}
//	
//	public static void incrTotalCacheHits() {
//		HazelcastCache.totalCacheHits.set(totalCacheHits.get()+1);
//	}
//
//	public static Integer getNewCacheHits() {
//		return newCacheHits.get();
//	}
//
//	private static void resetNewCacheHits() {
//		HazelcastCache.newCacheHits.set(0);
//	}
//
//	public static void incrNewCacheHits() {
//		HazelcastCache.newCacheHits.set(newCacheHits.get()+1);
//	}
//	
//	public static void resetCacheHitsStats() {
//		resetTotalCacheHits();
//		resetNewCacheHits();
//	}
//	
//	public static void printCacheHitStats(String restAPIorContext, long executionTime) {
//		logger.debug("CacheInfoContext [{}] : totalCacheHits[{}], executionTime[{}]", restAPIorContext, getTotalCacheHits(), executionTime);
//	}
	
	private IMap<String,Object> getGroupDataMap(){
		return this.getHZInstance().getMap("groupDataMap");
	}

	@Override
	public Map<Long, String> getGroupIdToCodeMap() {
//		return this.getHZInstance().getMap("groupIdToCodeMap");
		return (Map<Long, String>) this.getGroupDataMap().get("groupIdToCodeMap");
	}
	
	@Override
	public Map<Long, String> getGroupIdToNameMap() {//TODO single-map
		return (Map<Long, String>) this.getGroupDataMap().get("groupIdToNameMap");
		//this.getHZInstance().getMap("groupIdToNameMap");
	}
	
	@Override
	public Map<Long, List<RoutingCriteriaBean>> getDbRoutingCriteriaList() { //TODO single-map
		return (Map<Long, List<RoutingCriteriaBean>>) this.getGroupDataMap().get("dbRoutingCriteriaList");
		//return this.getHZInstance().getMap("dbRoutingCriteriaList");
	}

	@Override
	public Map<String, ClientMapping> getClientMappingMap() {
		return (Map<String, ClientMapping>)this.getHZInstance().getMap("clientMappingDataMap").get("clientMappingMap");
	}
	
	@Override
	public Map<String, MailBoxDLMapping> getMailBoxDLMappingMap() {
		return (Map<String, MailBoxDLMapping>)this.getHZInstance().getMap("mailBoxDLMappingMap").get("mailBoxDLMappings");
	}

	@Override
	public Map<String, String> getMsExchangeServerMap() {
		 Config config=getConfigById("msExchangeServerConfiguration");
		 List<KeyValue> configList=config.getMsExchangeServerConfigList();
		 return configList.stream().collect(Collectors.toMap(KeyValue::getKey,KeyValue::getValue));
	}
	
	@Override
	public Map<String, String> getMsExchangeServerMapParallel() {
		 Config config=getConfigById("msExchangeServerConfigParallel");
		 List<KeyValue> configList=config.getMsExchangeServerConfigParallel();
		 return configList.stream().collect(Collectors.toMap(KeyValue::getKey,KeyValue::getValue));
	}
	@Override
	public Map<String, List<String>> getAutoFwdConfigMap() {
		 Config config=getConfigById("autoFwdDLsMapping");
		 Map<String, List<String>> configList = config==null?null:config.getAutoFwdDLsMappings();
		return configList;
	}
	
	@Override
	public Config getConfigById(String configId){
		IMap<String,Config> map=  this.getHZInstance().getMap("configMap");
		return map.get(configId);
	}

	@Override
	public Map<String, Config> getConfigIdEscalationCriteriaMap() {
		Config config=getConfigById("EscalationCriteria");
		Map<String, Config> map=new HashMap<String, Config>();
		map.put("EscalationCriteria",config);
		return map;
	}

	@Override
	public boolean getSmartRoutingFlagFromConfig() {
		return getConfigById("smartRoutingRule").isSmartRoutingRuleEnabled();
	}

	@Override
	public List<String> getCitiDomainsList() {
		List<String> list=getConfigById("citiDomain").getCitiDomains();
		return  list;
	}

	@Override
	public Map<String, List<String>> getParentToChildDLsListMap() { //TODO single-map
		return (Map<String, List<String>>) this.getGroupDataMap().get("parentToChildDLsListMap");
	//	return this.getHZInstance().getMap("parentToChildDLsListMap");
	}

	@Override
	public Map<String, String> getGroupCodeToEmailMap() {  //TODO single-map
		return (Map<String, String>) this.getGroupDataMap().get("groupCodeToEmailMap");
		//return this.getHZInstance().getMap("groupCodeToEmailMap");
	}

	@Override
	public Map<String, Group> getEmailWithDomaintoGroupMap() { //TODO single-map
		return (Map<String, Group>) this.getGroupDataMap().get("emailWithDomaintoGroupMap");
		//return this.getHZInstance().getMap("emailWithDomaintoGroupMap");
	}

	@Override
	public Map<Long, Boolean> getGroupIdToActiveMap() {
//		return this.getHZInstance().getMap("groupIdToActiveMap");
		return (Map<Long, Boolean>) this.getGroupDataMap().get("groupIdToActiveMap");
	}

	@Override
	public List<Group> getGroupList() {  //TODO single-map
		return (List<Group>) this.getGroupDataMap().get("groupList");
		//return this.getHZInstance().getList("groupList");
	}

	@Override
	public Map<Long, List<String>> getGroupIdToCIMSEmailList() { //TODO single-map
		return (Map<Long, List<String>>) this.getGroupDataMap().get("groupIdToCIMSEmailList");
		//return this.getHZInstance().getMap("groupIdToCIMSEmailList");
	}

	@Override
	public Map<Long, List<String>> getGroupIdToManualEmailList() { //TODO single-map
		return (Map<Long, List<String>>) this.getGroupDataMap().get("groupIdToManualEmailList");
		//return this.getHZInstance().getMap("groupIdToManualEmailList");
	}

	@Override
	public Map<String, String> getIncomingToCcDLAliasMappingEmailsMap() {
//		return this.getHZInstance().getMap("incomingToCcDLAliasMappingEmailsMap");
		return (Map<String, String>) this.getGroupDataMap().get("incomingToCcDLAliasMappingEmailsMap");
	}

	@Override
	public Map<Long, Group> getAllGroupsMap() {
//		return this.getHZInstance().getMap("allGroupsMap");
		return (Map<Long, Group>) this.getGroupDataMap().get("allGroupsMap");
	}

	@Override
	public Map<Long, List<String>> getGroupIdToTagMap() {
//		return this.getHZInstance().getMap("groupIdToTagMap");
		return (Map<Long, List<String>>) this.getGroupDataMap().get("groupIdToTagMap");
	}

	@Override
	public Map<Long, List<String>> getGroupIdToRequestTypeMap() {
//		return this.getHZInstance().getMap("groupIdToRequestTypeMap");
		return (Map<Long, List<String>>) this.getGroupDataMap().get("groupIdToRequestTypeMap");
	}

	@Override
	public Map<Long, List<String>> getGroupIdToProcessingRegionMap() {
		//return this.getHZInstance().getMap("groupIdToProcessingRegionMap");
		return (Map<Long, List<String>>) this.getGroupDataMap().get("groupIdToProcessingRegionMap");
	}

	@Override
	public Map<String, Long> getGroupCodeToIdMap() { //TODO single-map
		return (Map<String, Long>) this.getGroupDataMap().get("groupCodeToIdMap");
		//return this.getHZInstance().getMap("groupCodeToIdMap");
	}

	@Override
	public Map<String, Long> getGroupEmailToIdMap() {
//		return this.getHZInstance().getMap("groupEmailToIdMap");
		return (Map<String, Long>) this.getGroupDataMap().get("groupEmailToIdMap");
	}

	@Override
	public Map<Long, String> getGroupIdToEmailMap() {
		return (Map<Long, String>) this.getGroupDataMap().get("groupIdToEmailMap");
//		return this.getHZInstance().getMap("groupIdToEmailMap");
	}

	@Override
	public Map<Long, String> getGroupIdToDisclaimerMap() {
//		return this.getHZInstance().getMap("groupIdToDisclaimerMap");
		return (Map<Long, String>) this.getGroupDataMap().get("groupIdToDisclaimerMap");
	}

	@Override
	public Map<Long, String> getGroupIdToGrpCrtDateMap() {
		return (Map<Long, String>) this.getGroupDataMap().get("groupIdToGrpCrtDateMap");
	}
	
	@Override
	public Map<Long, ManagementHeirarchy> getGroupIdToHierarchyMap() {
		return (Map<Long, ManagementHeirarchy>) this.getGroupDataMap().get("groupIdToHierarchyMap");
	}
	
	@Override
	public Map<Long, List<EmailAlias>> getGroupIdToParentDLEmailAliasListMap() {
		return (Map<Long, List<EmailAlias>>) this.getGroupDataMap().get("groupIdToParentDLEmailAliasListMap");
	}
	
	
	private StaticData getStaticData(){
		IMap<String, StaticData> map = this.getHZInstance().getMap("staticDataMap");
		StaticData staticData = map.get("staticData");
		return staticData;
	}
	
	@Override
	public List<IncomingToCcDLAliasMapping> getIncomingToCcDLAliasMapping() {
		return getStaticData().getIncomingToCcDLAliasMapping();
	}

	@Override
	public List<String> getIgnoreEmailListForProcessing() {
		return getStaticData().getIgnoreEmailListForProcessing();
	}

	@Override
	public Long getBccRoutingGroup() {
		return getStaticData().getBccRoutingGroup();
	}

	@Override
	public String getEnableConvReferenceCheckAlways() {
		return getStaticData().getEnableConvReferenceCheckAlways();
	}

	@Override
	public String getEnableInternalGroupEmailRouting() {
		return getStaticData().getEnableInternalGroupEmailRouting();
	}

	@Override
	public List<String> getInternalGrpRoutingInclusionList() {
		return getStaticData().getInternalGrpRoutingInclusionList();
	}

	@Override
	public String getDisableOnBehalfOf() {
		return getStaticData().getDisableOnBehalfOf();
	}

	@Override
	public List<String> getDisableOnBehalfOfGrpList() {
		return getStaticData().getDisableOnBehalfOfGrpList();
	}

	@Override
	public List<String> getQmaMailServers() {
		return getStaticData().getQmaMailServers();
	}

	@Override
	public List<Long> getBccGroupIdList() {
		return getStaticData().getBccGroupIdList();
	}

	@Override
	public String getEnableCharacterEncoding() {
		return getStaticData().getEnableCharacterEncoding();
	}

	@Override
	public String getCslRestServerUrl() {
		return getStaticData().getCslRestServerUrl();
	}

	@Override
	public int getRefreshTimeMinutes() {
		return getStaticData().getRefreshTimeMinutes();
	}

	@Override
	public List<String> getNlpSubsciptionGroups(String catetory) {
		IMap<String,Config> map = this.getHZInstance().getMap("nlpSubscriptionGroupsMap");
		List<String> groupsList = null;
		if (map!=null) {
			groupsList = (List<String>) map.get(catetory);
		}		
		return groupsList;
	}
	
	@Override
	public Map<String, Object> getNlpConfiguration() {
		//return getStaticData().getNlpConfiguration();
		Config config = getConfigById("nlpConfiguration");
		Map<String,Object> configMap = config==null ? null : config.getNlpConfiguration();
		return configMap;
	}

	@Override
	public Map<String, Object> getClcConfiguration() {
		Config config = getConfigById("clcConfiguration");
		Map<String,Object> configMap = config==null ? null : config.getClcConfiguration();
		return configMap;
	}
	
	@Override
	public Map<String, Object> getOasysPaymentProcessingConfig() {
		Config config = getConfigById("oasysPaymentProcessingConfig");
		Map<String,Object> configMap = config==null ? null : config.getOasysPaymentProcessingConfig();
		return configMap;
	}
	
	@Override
	public Map<String, User> getUserInfoMap() {
		IMap<String, User> userDataMap=this.getHZInstance().getMap("userDataMap");
		return (Map<String, User>) userDataMap.get("userInfoMap"); 
	}

	@Override
	public Map<String, List<HolidayMaster>> getHolidayMasterMap() {
		 return (Map<String, List<HolidayMaster>>) this.getGroupDataMap().get("holidayMaster");
	}

	@Override
	public Map<Long, GroupShiftConfig> getGroupAgeConfigMap() {
		return (Map<Long, GroupShiftConfig>) this.getGroupDataMap().get("groupAgeConfigMap");
	}

	@Override
	public List<TimeZone> getTimeZonesConfig() {
		Config config = getConfigById("timeZones");
		return config==null ? null : config.getTimeZones();
	}

	@Override
	public Map<Long, List<CustomClientCriteriaRuleBean>> getDbCustomClientCriteriaList() {
		return (Map<Long, List<CustomClientCriteriaRuleBean>>) this.getGroupDataMap().get("dbCustomClientCriteriaList");
	}

	@Override
	public List<Long> getPersonalGroupIdList() {
		return (List<Long>) this.getGroupDataMap().get("personalGroupIdList");
	}

	@Override
	public Map<String, Long> getPersonalMailboxIdToGroupIdMap() {
		return (Map<String, Long>) this.getGroupDataMap().get("personalMailboxIdToGroupIdMap");
	}

	@Override
	public boolean isMailboxStatsExecutorFlag() {
		return getStaticData().isMailboxStatsExecutorFlag();
	}
	
	public Map<String, Object> getQmaPersonalConfig() {
		Config config = getConfigById("qmaPersonalConfig");
		Map<String,Object> configMap = config==null ? null : config.getQmaPersonalConfig();
		return configMap;
	}
	
	@Override
	public Map<String, Long> getGroupCodeToIdMapBothActiveInactive() {
		return (Map<String,Long>) this.getGroupDataMap().get("groupCodeToIdMapBothActiveInactive");
	}
	
	@Override
	public Map<String, String> getGroupIdToCodeMapBothActiveInactive() {
		return (Map<String,String>) this.getGroupDataMap().get("groupIdToCodeMapBothActiveInactive");
	}

	@Override
	public Map<String, String> getGroupIdToEmailMapBothActiveInactive() {
		return (Map<String,String>) this.getGroupDataMap().get("groupIdToEmailMapBothActiveInactive");
	}

	@Override
	public Map<String, SymphonyUserMapTO> getUserSymphonyIdToUserMap() {
		return (Map<String, SymphonyUserMapTO>) this.getHZInstance().getMap("userSymphonyIdToUserMap").get("userSymphonyIdToUserMap");
	}

	@Override
	public Map<Long, List<String>> getGroupIdToUserListMap() {
		return (Map<Long, List<String>>) this.getGroupDataMap().get("groupIdToUserListMap");
	}
	
	@Override
	public Map<Long, String> getAutoAssignmentEnabledGroupMap() {
		return (Map<Long,String>) this.getGroupDataMap().get("autoAssignmentEnabledGroupMap");
	}

	@Override
	public List<OrganizationAuditTrail> getOrgRequestsList() {
		return this.getHZInstance().getList("orgRequests");
	}

	@Override
	public Map<String, List<Group>> getOrgGroupMap() {
		return (Map<String, List<Group>>) this.getGroupDataMap().get("orgGroupMap");
	}

	@Override
	public Map<String, String> getGroupIdToDBCodeMap() {
		return (Map<String,String>) this.getGroupDataMap().get("groupIdToDBCodeMap");
	}

	@Override
	public Map<String, String> getGroupEmailToCodeMap() {
		return (Map<String,String>) this.getGroupDataMap().get("groupEmailToCodeMap");
	}

	@Override
	public Long getPubSubMonitorTimeMillis() {
		return getStaticData().getPubSubMonitorTimeMillis();
	}

	@Override
	public String getPubSubMonitorEmail() {
		return getStaticData().getPubSubMonitorEmail();
	}

	@Override
	public String getEnableOptimizePubSub() {
		return getStaticData().getEnableOptimizePubSub();
	}

	@Override
	public String getEnablePubSubMonitor() {
		return getStaticData().getEnablePubSubMonitor();
	}

	@Override
	public String getEnableGraphs() {
		return getStaticData().getEnableGraphs();
	}

	@Override
	public Long getMaxJobRetryCount() {
		return getStaticData().getMaxJobRetryCount();
	}

	@Override
	public String getSolrURL() {
		return getStaticData().getSolrURL();
	}

	public Map<String, Map<String, Integer>> getUserHighestDateConfiguredViewMap() {
		IMap<String, User> userDataMap=this.getHZInstance().getMap("userDataMap");
		return (Map<String, Map<String, Integer>>) userDataMap.get("userHighestDateConfiguredViewMap"); 
	}

	@Override
	public String getEnableMakerCheckerForUnapprovedDomains() {
		return getStaticData().getEnableMakerCheckerForUnapprovedDomains();
	}

	@Override
	public int getConvLimitCount() {
		return getStaticData().getConvLimitCount();
	}

	@Override
	public List<ColumnDef> getMasterColumnDef() {
		return getStaticData().getMasterColumnDef();
	}

	@Override
	public String getDefaultDateFormate() {
		return getStaticData().getDefaultDateFormate();
	}

	@Override
	public String getDefaultInboxName() {
		return (String) this.getGroupDataMap().get("defaultInboxName");
	}

	@Override
	public Map<String, ViewConfig> getDefaultViewMap() {
		return (Map<String, ViewConfig>) this.getGroupDataMap().get("defaultViewMap");
	}

	@Override
	public StaticData getDefaultStaticData() {
		return getStaticData();
	}

	@Override
	public List<String> getDefaultViewNameList() {
		return  (List<String>) this.getGroupDataMap().get("defaultViewNameList");
	}

	@Override
	public Config getXmcExportDlConfig() {
		return getConfigById("xmcExportDlConfig");
	}

	@Override
	public Map<String, OrgPreferences> getOrgNameToOrgPref() {
		return (Map<String, OrgPreferences>) this.getGroupDataMap().get("orgNameToOrgPref");
	}

	@Override
	public HashMap<Long, String> getGroupIdToOrgName() {
		return (HashMap<Long, String>) this.getGroupDataMap().get("groupIdToOrgName");
	}
	@Override
	public Map<Long, Boolean> getPersonalIdToActiveMap() {
		return (Map<Long, Boolean>) this.getGroupDataMap().get("personalIdToActiveMap");
	}

	@Override
	public Map<Long, String> getPersonalIdToEmailMap() {
		return (Map<Long, String>) this.getGroupDataMap().get("personalIdToEmailMap");
	}

	@Override
	public Map<Long, String> getPersonalIdToCodeMap() {
		return (Map<Long, String>) this.getGroupDataMap().get("personalIdToCodeMap");
	}

	@Override
	public Map<Long, String> getPersonalIdToNameMap() {
		return (Map<Long, String>) this.getGroupDataMap().get("personalIdToNameMap");
	}

	@Override
	public Map<String, Long> getPersonalCodeToIdMap() {
		return (Map<String, Long>) this.getGroupDataMap().get("personalCodeToIdMap");
	}

	@Override
	public Map<String, Long> getPersonalEmailToIdMap() {
		return (Map<String, Long>) this.getGroupDataMap().get("personalEmailToIdMap");
	}

	@Override
	public Map<String, String> getPersonalEmailToCodeMap() {
		return (Map<String, String>) this.getGroupDataMap().get("personalEmailToCodeMap");
	}

	@Override
	public Map<String, String> getPersonalCodeToEmailMap() {
		return (Map<String, String>) this.getGroupDataMap().get("personalCodeToEmailMap");
	}

	@Override
	public Map<Long, List<String>> getPersonalIdToCIMSEmailList() {
		return (Map<Long, List<String>>) this.getGroupDataMap().get("personalIdToCIMSEmailList");
	}

	@Override
	public Map<Long, List<String>> getPersonalIdToManualEmailList() {
		return (Map<Long, List<String>>) this.getGroupDataMap().get("personalIdToManualEmailList");
	}

	@Override
	public List<String> getAutoReplySuggestionEnabledGroupList() {
		return (List<String>) this.getGroupDataMap().get("autoReplySuggestionEnabledGroupList");
	}
	
	@Override
	public List<String> getCustodySuggestionEnabledGroupList() {
		return (List<String>) this.getGroupDataMap().get("custodySuggestionEnabledGroupList");
	}
	
	//[C170665-3742] Added this in cache to fix delay issue for taskize in prod
	@Override
	public Map<String, String> getUserSoeIdToEmailIdMap() {
		IMap<String, User> userDataMap=this.getHZInstance().getMap("userDataMap");
		return (Map<String, String>) userDataMap.get("userEmailIdToSoeIdMap"); 
	}
	
	@Override
	public Boolean isLogMaskingEnabled() {
		return getStaticData().isLogMaskingEnabled();
	}
	
	@Override
	public Boolean isUIDataMaskingEnabled() {
		return getStaticData().isUIDataMaskingEnabled();
	}

	@Override
	public int getReRefreshTimeMinutes() {
		return getStaticData().getRefreshTimeMinutes();
	}

	@Override
	public List<String> getIntentSuggestionEnabledGroupList() {
		return (List<String>) this.getGroupDataMap().get("intentSuggestionEnabledGroupList");
	}
}