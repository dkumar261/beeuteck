package com.citi.icg.qma.exception;

public class QmaInitializationException extends RuntimeException {

	private static final long serialVersionUID = 8420565327172635463L;

	public QmaInitializationException(String message, Throwable e) {
		super(message, e);
	}

	public QmaInitializationException(Throwable e) {
		super(e);
	}

	public QmaInitializationException(String message) {
		super(message);
	}	
}