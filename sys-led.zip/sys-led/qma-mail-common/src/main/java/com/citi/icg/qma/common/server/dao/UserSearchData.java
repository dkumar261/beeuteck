package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "UserSearchData", noClassnameStored = true)
public class UserSearchData implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1545475986075132571L;
	
	@Id
	private String id;
	private String userId;
	private String searchKeyword;
	private Map<String, Object> userFeedback;
	private Date crtDate;
	private Date modDate;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getSearchKeyword() {
		return searchKeyword;
	}
	public void setSearchKeyword(String searchKeyword) {
		this.searchKeyword = searchKeyword;
	}
	public Date getCrtDate() {
		return crtDate;
	}
	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}
	public Map<String, Object> getUserFeedback() {
		return userFeedback;
	}
	public void setUserFeedback(Map<String, Object> userFeedback) {
		this.userFeedback = userFeedback;
	}
	public Date getModDate() {
		return modDate;
	}
	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}
	

}
