package com.citi.icg.qma.common.server.dao.util;

import java.util.List;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.persistence.DashboardDAO;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

public class MailBoxCountExecutor implements Callable<BasicDBList>{
	
	private static final Logger subLogger = LoggerFactory.getLogger(MailBoxCountExecutor.class);
	boolean executionflag;
	List<Long> groupIds;
	String viewName;
	String soeId;
	boolean isOnlyViewCountRequest;
	String savedSearchName;
	BasicDBObject inputJsonObj;
	
	DashboardDAO dashboardDao = DashboardDAO.getInstance();
	
	public MailBoxCountExecutor(boolean executionflag, List<Long> groupIds, String viewName, String soeId, boolean isOnlyViewCountRequest, String savedSearchName, BasicDBObject inputJsonObj ) {
		super();
		this.executionflag = executionflag;
		this.groupIds = groupIds;
		this.viewName = viewName;
		this.soeId = soeId;
		this.isOnlyViewCountRequest = isOnlyViewCountRequest;
		this.savedSearchName = savedSearchName;
		this.inputJsonObj = inputJsonObj;
	}

	@Override
	public BasicDBList call() {
		BasicDBList mailBoxStats = new BasicDBList();
		try {
			if(executionflag){
				subLogger.info("getViewStats thread starts for view : "+this.viewName+" and thread is : "+Thread.currentThread().getName());
				mailBoxStats =  getViewStats(this.groupIds, this.viewName, this.soeId, this.inputJsonObj);
				subLogger.info("getViewStats thread ends for view : "+this.viewName+" and thread is : "+Thread.currentThread().getName());
			} else {
				subLogger.info("getMyViewsDetails thread starts for view : "+this.savedSearchName+" and thread is : "+Thread.currentThread().getName());
				mailBoxStats = getMyViewsDetails(this.groupIds, this.soeId,	this.isOnlyViewCountRequest, this.savedSearchName, this.inputJsonObj);
				subLogger.info("getMyViewsDetails thread ends for view : "+this.savedSearchName+" and thread is : "+Thread.currentThread().getName());
			}
		} catch (CommunicatorException e) {
			subLogger.error("Exception in MailboxCountExecutor", e);
		}
		return mailBoxStats;
	}
	
	private BasicDBList getViewStats(List<Long> groupIds, String viewName, String soeId, BasicDBObject inputJsonObj){
		
		BasicDBList mailBoxStats = new BasicDBList();
		dashboardDao.getViewStats(groupIds, mailBoxStats, viewName,soeId, inputJsonObj);
		return mailBoxStats;
	}
	
	private BasicDBList getMyViewsDetails(List<Long> groupIds, String soeId,
			boolean isOnlyViewCountRequest, String savedSearchName, BasicDBObject inputJsonObj) throws CommunicatorException{
		BasicDBList mailBoxStats = new BasicDBList();
		dashboardDao.getMyViewDetailsStats(groupIds, mailBoxStats, soeId,
				isOnlyViewCountRequest, savedSearchName, inputJsonObj);
		return mailBoxStats;
	}

}
