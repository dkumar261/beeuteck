package com.citi.icg.qma.common.server.dao;

import com.citi.icg.qma.common.server.dao.BaseEntity;

import dev.morphia.annotations.CappedAt;
import dev.morphia.annotations.Entity;

@Entity(value = "MessageIdDetails", noClassnameStored = true, cap = @CappedAt(count = 5000, value = 500000))
public class MessageIdDetails extends BaseEntity{

	private String messageId;
	
	public MessageIdDetails(String messageId) {
		super();
		this.messageId = messageId;
		}
	
	
	public MessageIdDetails() {
		// TODO Auto-generated constructor stub
	}

	public String getMessageId() {
		return messageId;
	}
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	
}

