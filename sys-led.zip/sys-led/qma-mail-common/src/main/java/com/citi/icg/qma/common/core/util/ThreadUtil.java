package com.citi.icg.qma.common.core.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ThreadUtil
{
	private static final Logger logger = LoggerFactory.getLogger(ThreadUtil.class);
	
	private ThreadUtil(){
		//As this class is Util, so added making private constructor.
		//Sonar Fix -- Utility classes should not have public constructors 
	}
	
	
	public static void stopThreadPool(Thread[] threads)
	{
		for (Thread thread : threads)
		{
			thread.interrupt();

		}
	}

	public static void sleep(long timeInMillis)
	{
		// sleep for soem time.
		long timeInMils = timeInMillis;//sonar fix -- Introduce a new variable instead of reusing the parameter
		try
		{
			timeInMils = 1000L;
			Thread.sleep(timeInMils);
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			logger.error(ThreadUtil.class+ "Exception Occured  " + e.getMessage(),e);
		}
	}

}
