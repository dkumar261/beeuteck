package com.citi.icg.qma.common.server.dao.persistence;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.JobStatus;

public class JobStatusDAO extends MongoMorphiaDAO
{
	private static final Logger subLogger = LoggerFactory.getLogger(JobStatusDAO.class);
	private static JobStatusDAO instance = null;
	

	public static synchronized JobStatusDAO getInstance()//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
	{
		if (instance == null) {
			instance = new JobStatusDAO();
		}
		return instance;
	}
	public void insertJobStatus(JobStatus obj) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("JobStatusDAO.class #insertJobStatus" + " - Job Name: " + obj.getJobName()
		+ " Job Start Time: " + obj.getJobStartTime() + " Job End Time: " + obj.getJobEndTime() + " Job Status : "+ obj.getStatus()
		+ " data count: "+ obj.getDataCount() + " Exception : "+ obj.getException());
		try
		{
			if (!StringUtils.isEmpty(obj.getJobName()))
			{
				persist(obj);
				subLogger.info("Job Started for Job name: "+obj.getJobName());
			}
			else
			{
				subLogger.info("Job name is not available");
			}

		}
		catch (Exception e)
		{
			subLogger.error("Exception in JobStatusDAO.insertJobStatus", e);
			throw new CommunicatorException("Exception in JobStatusDAO.insertJobStatus", e);
		}
	}
	
	public void updateJobStatus(JobStatus obj) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("JobStatusDAO.class #updateJobStatus" + " - Job Name: " + obj.getJobName()
				+ " Job Start Time: " + obj.getJobStartTime() + " Job End Time: " + obj.getJobEndTime() + " Job Status : "+ obj.getStatus()
				+ " data count: "+ obj.getDataCount() + " Exception : "+ obj.getException());
		try
		{
			persist(obj);
			subLogger.info("Job status updated for Job name: "+obj.getJobName());

		}
		catch (Exception e)
		{
			subLogger.error("Exception in JobStatusDAO.updateJobStatus", e);
			throw new CommunicatorException("Exception in JobStatusDAO.saveJobStatus", e);
		}
	}
}
