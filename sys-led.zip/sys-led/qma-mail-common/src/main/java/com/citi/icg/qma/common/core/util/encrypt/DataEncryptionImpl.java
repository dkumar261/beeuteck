package com.citi.icg.qma.common.core.util.encrypt;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.ApplicationConstants;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.persistence.SecretServiceDAO;
import com.citi.icg.qma.config.MongoDBConfig;
import com.citi.icg.qma.config.QmaMailConfigLoader;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

/**
 * 
 */
public class DataEncryptionImpl implements IDataEncryption {
    private static final String SECRET_TYPE = "mongodb";
	private static final Logger logger = LoggerFactory.getLogger(DataEncryptionImpl.class);
    private AESUtil aesUtil = new AESUtil();
    private static String qmaRootKey;

    /**
     * This method encrypts data
     *
     * @param dataToBeEncrypted
     * @return String
     * @throws DataEncrpyptDecryptException
     */
    public String encryptData(String dataToBeEncrypted) throws Exception {
        //1. Get Data key
        String qesDataKey = getDataKey();

        String encodedCipherData = aesUtil.enc_aes256CbcHmacSha512(qesDataKey,
                ApplicationConstants.DETERMINISTIC_ENCRYPTION_MODE, dataToBeEncrypted);

        return encodedCipherData;
    }


    /**
     * This method decrypts data
     *
     * @param dataToBeDecrypted
     * @return String
     * @throws DataEncrpyptDecryptException
     */
    public String decryptData(String dataToBeDecrypted) throws Exception {
        // 1. Get Data key
        String qesDataKey = getDataKey();

        String decrytedData = aesUtil.dec_aes256CbcHmacSha512(qesDataKey, dataToBeDecrypted);
        return decrytedData;
    }

    /**
     * This method gets the data key for encryption
     *
     * @return
     * @throws DataEncrpyptDecryptException
     */
    @Override
	public String getDataKey() throws Exception {
        String encDataKey = getRawDataKey();
        String rootKey = getBase64EncryptedRootKeyFromCyberark();
        if(StringUtils.isEmpty(rootKey)) {
        	rootKey = getBase64EncryptedRootKey();
        }
        String dataKey = aesUtil.dec_aes256CbcHmacSha512(rootKey, encDataKey);
        return dataKey;
    }

	/**
	 * This method gets the root key for encryption
	 * @return
	 * @throws DataEncrpyptDecryptException
	 */
    @Override
	public String getBase64EncryptedRootKey() throws DataEncrpyptDecryptException {
        String rootKey = null;
        Map<String, Object> encryptionConfig = getEncryptionConfig();
        if (null != encryptionConfig && encryptionConfig.containsKey("rootKeyConfig")) {
            Map<String, Object> rootKeyConfig = (Map<String, Object>) encryptionConfig.get("rootKeyConfig");
            if (null != rootKeyConfig && rootKeyConfig.containsKey("rootKey")) {
                rootKey = (String) rootKeyConfig.get("rootKey");
            } else {
                logger.warn("Could not find root key in the configuration");
            }
        } else {
            logger.warn("Could not find root key in the configuration");
        }
        return rootKey;
    }
    /**
	 * This method gets the root key for encryption
	 * @return
	 * @throws DataEncrpyptDecryptException
	 */
	private String getBase64EncryptedRootKeyFromCyberark() {		
		String rootKey = null;
		
		try {
			if (StringUtils.isEmpty(qmaRootKey)) {
				MongoDBConfig mongoDBConfig = QmaMailConfigLoader.getConfig().getMongoDBConfig();
			
				if (null != mongoDBConfig && null != mongoDBConfig.getSecretRetrivalEndpointEcs()
						&& null != mongoDBConfig.getEncryptionKeyNickName()) {
					String secretEndPoint = mongoDBConfig.getSecretRetrivalEndpointEcs();
					qmaRootKey = SecretServiceDAO.getInstance().getSecretFromService(secretEndPoint, SECRET_TYPE,
							mongoDBConfig.getEncryptionKeyNickName());
					if (StringUtils.isEmpty(qmaRootKey)) {
						throw new DataEncrpyptDecryptException("Unable to fetch and load encryption key.");
					}
				} else {
					logger.info("MongoDb config for encryption key retrieval is missing in yaml file.");
				}
			}
		} catch (Exception e) {
			logger.warn("Exception while getting secret key:{}", e);
		}
        return rootKey;
    }
	
    private String getRawDataKey() {
        String dataKey = null;
        Map<String, Object> encryptionConfig = getEncryptionConfig();
        if (null != encryptionConfig && encryptionConfig.containsKey("dataEncryptionKey")) {
            dataKey = (String) encryptionConfig.get("dataEncryptionKey");
        } else {
            logger.warn("Could not find data key in the configuration");
        }
        return dataKey;
    }

    private Map<String, Object> getDataKey(String key) {
        Map<String, Object> encryptionConfig = (Map<String, Object>) QMACacheFactory.getCache().getConfigById("encryptionConfig");
        return encryptionConfig;
    }

    private Map<String, Object> getEncryptionConfig() {
        Map<String, Object> encryptionConfigMap = null;
        Config encryptionConfig = QMACacheFactory.getCache().getConfigById("encryptionConfig");
        if(null != encryptionConfig && null != encryptionConfig.getEncryptionConfig()) {
            encryptionConfigMap = encryptionConfig.getEncryptionConfig();
        }
        return encryptionConfigMap;
    }

}
