package com.citi.icg.qma.common.server.dao.userview;

public enum GroupOperator
{

	and, or, nor
}
