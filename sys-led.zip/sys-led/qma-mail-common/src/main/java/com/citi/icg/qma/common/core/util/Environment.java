package com.citi.icg.qma.common.core.util;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.citi.icg.qma.common.core.exception.CommunicatorException;

/**
 * Root class to get the Application runtime environment. based on
 */
public class Environment
{
	// --- Static variables ---
	/** Runtime environment. */
	public static final String ICG_ENV = "icg.env";

	/** Runtime: Local Development. */
	public static final String RUNTIME_LOCAL = "local";

	/** Runtime: Development. */
	public static final String RUNTIME_DEV = "dev";

	/** Runtime: INTEGRATION (QA). */
	public static final String RUNTIME_INT = "int";
	
	/** Runtime: NAM-DEV (NAM-DEV). */
	public static final String RUNTIME_NAM_DEV = "nam-dev";
	
	/** Runtime: NAM-UAT (NAM-UAT). */
	public static final String RUNTIME_NAM_UAT = "nam-uat";
	
	/** Runtime: NAM-COB (NAM-COB). */
	public static final String RUNTIME_NAM_COB = "nam-cob";
	
	/** Runtime: NAM-PROD (NAM-PROD). */
	public static final String RUNTIME_NAM_PROD = "nam-prod";

  	/** Runtime: APAC-DEV (APAC DEV). */
	public static final String RUNTIME_APAC_DEV = "apac-dev";
	
  	/** Runtime: APAC-UAT (STAGE). */
	public static final String RUNTIME_APAC_UAT = "apac-uat";
  
	/** Runtime: APAC-PROD (PROD). */
	public static final String RUNTIME_APAC_PROD = "apac-prod";
	
	/** Runtime: APAC-COB (COB). */
	public static final String RUNTIME_APAC_COB = "apac-cob";
	
	/** Runtime: UAT (STAGE). */
	public static final String RUNTIME_UAT = "uat";

	/** Runtime: Production. */
	public static final String RUNTIME_PROD = "prod";
	
	/** Runtime: COB. */
	public static final String RUNTIME_COB = "cob";

	/** Runtime: auto test . */
	public static final String RUNTIME_AUTO_TEST = "autotest";

	/** List of environments. */
	private static final String[] ENVIRONMENTS = new String[] { RUNTIME_AUTO_TEST, RUNTIME_LOCAL, RUNTIME_DEV, RUNTIME_INT, RUNTIME_APAC_UAT , 
			RUNTIME_NAM_DEV, RUNTIME_NAM_UAT, RUNTIME_NAM_COB, RUNTIME_NAM_PROD, RUNTIME_UAT, RUNTIME_APAC_DEV, RUNTIME_APAC_COB, RUNTIME_APAC_PROD, RUNTIME_PROD, RUNTIME_COB };

	private static final String ICG_ENV_VALUE = initIcgEnv();

	// --- Constructor(s) ---

	/**
	 * Constructs an IcgEnvironment object.
	 */
	private Environment()
	{

	}

	/**
	 *@deprecated as of 1.6. Use version with java.util.loggin.Level *
	 */
	@Deprecated
	public Environment getInstance()
	{
		return new Environment();
	}

	private static String initIcgEnv()
	{
		String env = System.getProperty(ICG_ENV);
		if (env == null)
		{
			throw new RuntimeException("No value for system property " + ICG_ENV);
		}

		if (!ArrayUtils.contains(ENVIRONMENTS, env))
		{
			throw new RuntimeException("Invalid value for system property " + ICG_ENV + ": " + env + ".  Valid values are: "
					+ StringUtils.join(ENVIRONMENTS, ','));
		}
		return env;
	}

	// --- Environment Methods ---

	/**
	 * Get the environment for this runtime.
	 */
	public static String getEnvironment()
	{
		return ICG_ENV_VALUE;
	}

	/**
	 * Indicates if the runtime environment is auto test .
	 */
	public static boolean isInAutoTest() throws CommunicatorException // Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		return RUNTIME_AUTO_TEST.equals(getEnvironment());
	}

	/**
	 * Indicates if the runtime environment is development.
	 */
	public static boolean isInDevelopment() throws CommunicatorException // Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		return RUNTIME_DEV.equals(getEnvironment());
	}

	/**
	 * Indicates if the runtime environment is SIT.
	 */
	public static boolean isInINT() throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		return RUNTIME_INT.equals(getEnvironment());
	}

	/**
	 * Indicates if the runtime environment is UAT.
	 */
	public static boolean isInUAT() throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		return RUNTIME_UAT.equals(getEnvironment());
	}

	/**
	 * Indicates if the runtime environment is production.
	 */
	public static boolean isInProduction() throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		return RUNTIME_PROD.equals(getEnvironment());
	}

	/**
	 * Indicates if the runtime environment is Local.
	 */
	public static boolean isInLocal() throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		return RUNTIME_LOCAL.equals(getEnvironment());
	}

}
