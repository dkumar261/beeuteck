package com.citi.icg.qma.common.server.dao;

import java.util.Date;
import java.util.List;

import dev.morphia.annotations.Entity;

@Entity(value = "UserReportRequest", noClassnameStored = true)
public class UserReportRequest extends BaseEntity
{

	private String userId;
	private String reportType;
	private Date startDate;
	private Date endDate;
	private Boolean processFlag;
	private List<String> groupList;	
	private String fileName;
	
	public UserReportRequest()
	{
		super();
	}

	public UserReportRequest(String userId, String reportType, Date startDate, Date endDate, List<String> groupList, boolean processFlag)
	{
		super();
		this.userId = userId;
		this.reportType = reportType;
		this.startDate = startDate;
		this.endDate = endDate;
		this.groupList = groupList;
		this.processFlag = processFlag;
	}
	
	public String getUserId()
	{
		return userId;
	}
	
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	
	public String getReportType()
	{
		return reportType;
	}

	public void setReportType(String reportType)
	{
		this.reportType = reportType;
	}

	public Date getStartDate()
	{
		return startDate;
	}
	
	public void setStartDate(Date startDate)
	{
		this.startDate = startDate;
	}
	
	public Date getEndDate()
	{
		return endDate;
	}
	
	public void setEndDate(Date endDate)
	{
		this.endDate = endDate;
	}

	public Boolean getProcessFlag()
	{
		return processFlag;
	}

	public void setProcessFlag(Boolean processFlag)
	{
		this.processFlag = processFlag;
	}

	public List<String> getGroupList()
	{
		return groupList;
	}

	public void setGroupList(List<String> groupList)
	{
		this.groupList = groupList;
	}

	public String getFileName()
	{
		return fileName;
	}

	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

}
