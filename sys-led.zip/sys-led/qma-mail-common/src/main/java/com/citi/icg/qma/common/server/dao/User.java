package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.citi.icg.qma.common.transferobject.Template;

@Entity(value = "User", noClassnameStored = true)
public class User implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8187677668535123706L;
	@Id
	private String id;
	private String name;
	private String email;
	private List<Signature> signatures;
	// Uncommenting since we are introducing multiple signatures now.
	private String defaultSignature;
	private List<GroupRole> groupRoles;
	private List<String> adminRoles;
	private List<String> folders;
	// public List<FolderDef> folders;// Data Migration not needed as user will
	// setup its own data going forward(new functionality)// 31st July: SUNIL
	private List<ViewConfig> views; // Data Migration not needed as user will setup its own views from scratch//
									// 31st July: SUNIL
	private List<FavoriteContact> favorites; // Initially will be blank as it is new feature : SUNIL 31ST jULY

	private String crtBy;
	private Date crtDate;
	private String modBy;
	private Date modDate;
	private Boolean active;
	private List<Preference> preferences;
	// Added to create Templates for user. Made private & provided get/set methods
	// as per best practices.
	private List<Template> templates;
	// User level Customized View Column Definitions for Default Views-April 15
	// release
	private List<ViewConfig> customDefaultViews;

	// [C153176-553]-Ability to set OOO status and notifications
	private Boolean outOfOffice;

	private Map<String, Object> outOfOfficeSettings;

	// [C153176-1013] Ability to systemically add 'Secure' in email subject
	private Boolean sendSecureEmail;

	private String mgrName;
	private String mgrPhone;
	private String mgrEmail;

	private String phone;
	private String firstName;
	private String lastName;
	private String department;
	private String country;
	private String gocCode;
	private String msL5;
	private String msL6;
	private String msL7;
	private String longDesc;

	// [C153176-1278]-Add scroll bar to QMA screen
	private Boolean fitToMyResolution;

	// [C153176-1281] Show latest release notes on QMA UI.
	private String viewedReleaseDocumentName;

	private byte[] profilePic;

	private Boolean disableAutoComplete;

	// This is for attachment pwd protection popup screen.
	// On this Scree , User can select the files and provide other details.
	private Boolean attachmentPwdProtectionFlag;

	private Map<String, Object> dashboardSettings;

	private List<String> myCoverage;

	private Map<String, Boolean> notificationSettings;

	private List<ViewFilters> viewFilters;

	private List<CustomColumnsView> customColumnsForDefaultViews;

	private String previousDayBoxCount;

	private String userAuthKey;

	private String geId;

	private String symphonyId;

	private String symphonyEmailId;

	private String isSymphonyEnabledForUser;
	
	private String isTaskizeEnabledForUser;

	private int noOfChatroom;

	private String exchUrl;

	private String exchDomain;

	private Boolean isCalendarSubscribed;

	private Boolean isPersonalEmailSubscribed;

	private String loginSecret;
	
	private List<Map<String, Object>> viewDateRangeConfig;

	private boolean isAuthenticationExpired;

	private boolean isPersonalAccountActive;
	
	// C170665-185	Hard Code data Points
	private List<OrgMetaDataAdminRole>orgAdminRole;
	
	private boolean gdActive;

	private String psL5;
	private String psL6;
	private String psL7;
	
	public User() {
		super();
	}

	public User(String email, List<Signature> signatures, List<ViewConfig> views, String crtBy, Date crtDate,
			String modBy, Date modDate) {

		this.setEmail(email);
		this.setSignatures(signatures);
		this.views = views;
		this.setCrtBy(crtBy);
		this.setCrtDate(crtDate);
		this.modBy = modBy;
		this.modDate = modDate;
	}

	public List<ViewConfig> getViews() {
		return views;
	}

	public void setViews(List<ViewConfig> views) {
		this.views = views;
	}

	public List<Template> getTemplates() {
		return templates;
	}

	public void setTemplates(List<Template> templates) {
		this.templates = templates;
	}

	public List<ViewConfig> getCustomDefaultViews() {
		return customDefaultViews;
	}

	public void setCustomDefaultViews(List<ViewConfig> customDefaultViews) {
		this.customDefaultViews = customDefaultViews;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getAdminRoles() {
		return adminRoles;
	}

	public void setAdminRoles(List<String> adminRoles) {
		this.adminRoles = adminRoles;
	}

	public List<GroupRole> getGroupRoles() {
		return groupRoles;
	}

	public void setGroupRoles(List<GroupRole> groupRoles) {
		this.groupRoles = groupRoles;
	}

	public List<Preference> getPreferences() {
		return preferences;
	}

	public void setPreferences(List<Preference> preferences) {
		this.preferences = preferences;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<String> getFolders() {
		return folders;
	}

	public void setFolders(List<String> folders) {
		this.folders = folders;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<Signature> getSignatures() {
		return signatures;
	}

	public void setSignatures(List<Signature> signatures) {
		this.signatures = signatures;
	}

	public List<FavoriteContact> getFavorites() {
		return favorites;
	}

	public void setFavorites(List<FavoriteContact> favorites) {
		this.favorites = favorites;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Date getCrtDate() {
		return crtDate;
	}

	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}

	public String getModBy() {
		return modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public Date getModDate() {
		return modDate;
	}

	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}

	public String getDefaultSignature() {
		return defaultSignature;
	}

	public void setDefaultSignature(String defaultSignature) {
		this.defaultSignature = defaultSignature;
	}

	public Boolean getOutOfOffice() {
		return outOfOffice == null ? false : outOfOffice;
	}

	public void setOutOfOffice(Boolean outOfOffice) {
		this.outOfOffice = outOfOffice;
	}

	public Boolean getSendSecureEmail() {
		return sendSecureEmail;
	}

	public void setSendSecureEmail(Boolean sendSecureEmail) {
		this.sendSecureEmail = sendSecureEmail;
	}

	public String getMgrName() {
		return mgrName;
	}

	public void setMgrName(String mgrName) {
		this.mgrName = mgrName;
	}

	public String getMgrPhone() {
		return mgrPhone;
	}

	public void setMgrPhone(String mgrPhone) {
		this.mgrPhone = mgrPhone;
	}

	public String getMgrEmail() {
		return mgrEmail;
	}

	public void setMgrEmail(String mgrEmail) {
		this.mgrEmail = mgrEmail;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	public String getViewedReleaseDocumentName() {
		return viewedReleaseDocumentName;
	}

	public void setViewedReleaseDocumentName(String viewedReleaseDocumentName) {
		this.viewedReleaseDocumentName = viewedReleaseDocumentName;
	}

	public Boolean getFitToMyResolution() {
		return fitToMyResolution;
	}

	public void setFitToMyResolution(Boolean fitToMyResolution) {
		this.fitToMyResolution = fitToMyResolution;
	}

	/**
	 * @return the profilePic
	 */
	public byte[] getProfilePic() {
		return profilePic;
	}

	/**
	 * @param profilePic the profilePic to set
	 */
	public void setProfilePic(byte[] profilePic) {
		this.profilePic = profilePic;
	}

	public Boolean getDisableAutoComplete() {
		return disableAutoComplete;
	}

	public void setDisableAutoComplete(Boolean disableAutoComplete) {
		this.disableAutoComplete = disableAutoComplete;
	}

	public Boolean getAttachmentPwdProtectionFlag() {
		return attachmentPwdProtectionFlag;
	}

	public void setAttachmentPwdProtectionFlag(Boolean attachmentPwdProtectionFlag) {
		this.attachmentPwdProtectionFlag = attachmentPwdProtectionFlag;
	}

	public String getGocCode() {
		return gocCode;
	}

	public void setGocCode(String gocCode) {
		this.gocCode = gocCode;
	}

	public String getMsL5() {
		return msL5;
	}

	public void setMsL5(String msL5) {
		this.msL5 = msL5;
	}

	public String getMsL6() {
		return msL6;
	}

	public void setMsL6(String msL6) {
		this.msL6 = msL6;
	}

	public String getMsL7() {
		return msL7;
	}

	public void setMsL7(String msL7) {
		this.msL7 = msL7;
	}

	public String getLongDesc() {
		return longDesc;
	}

	public void setLongDesc(String longDesc) {
		this.longDesc = longDesc;
	}

	public Map<String, Object> getOutOfOfficeSettings() {
		return outOfOfficeSettings;
	}

	public void setOutOfOfficeSettings(Map<String, Object> outOfOfficeSettings) {
		this.outOfOfficeSettings = outOfOfficeSettings;
	}

	public Map<String, Object> getDashboardSettings() {
		return dashboardSettings;
	}

	public void setDashboardSettings(Map<String, Object> dashboardSettings) {
		this.dashboardSettings = dashboardSettings;
	}

	public List<String> getMyCoverage() {
		return myCoverage;
	}

	public void setMyCoverage(List<String> myCoverage) {
		this.myCoverage = myCoverage;
	}

	public Map<String, Boolean> getNotificationSettings() {
		return notificationSettings;
	}

	public void setNotificationSettings(Map<String, Boolean> notificationSettings) {
		this.notificationSettings = notificationSettings;
	}

	public List<ViewFilters> getViewFilters() {
		return viewFilters;
	}

	public void setViewFilters(List<ViewFilters> viewFilters) {
		this.viewFilters = viewFilters;
	}

	public List<CustomColumnsView> getCustomColumnsForDefaultViews() {
		return customColumnsForDefaultViews;
	}

	public void setCustomColumnsForDefaultViews(List<CustomColumnsView> customColumnsForDefaultViews) {
		this.customColumnsForDefaultViews = customColumnsForDefaultViews;
	}

	public String getPreviousDayBoxCount() {
		return previousDayBoxCount;
	}

	public void setPreviousDayBoxCount(String previousDayBoxCount) {
		this.previousDayBoxCount = previousDayBoxCount;
	}

	public String getUserAuthKey() {
		return userAuthKey;
	}

	public void setUserAuthKey(String userAuthKey) {
		this.userAuthKey = userAuthKey;
	}

	public String getGeId() {
		return geId;
	}

	public void setGeId(String geId) {
		this.geId = geId;
	}

	public String getSymphonyId() {
		return symphonyId;
	}

	public void setSymphonyId(String symphonyId) {
		this.symphonyId = symphonyId;
	}

	public String getSymphonyEmailId() {
		return symphonyEmailId;
	}

	public void setSymphonyEmailId(String symphonyEmailId) {
		this.symphonyEmailId = symphonyEmailId;
	}

	public void setIsSymphonyEnabledForUser(String isSymphonyEnabledForUser) {
		this.isSymphonyEnabledForUser = isSymphonyEnabledForUser;
	}

	public String getIsSymphonyEnabledForUser() {
		return isSymphonyEnabledForUser;
	}

	public int getNoOfChatroom() {
		return noOfChatroom;
	}

	public void setNoOfChatroom(int noOfChatroom) {
		this.noOfChatroom = noOfChatroom;
	}

	public Boolean isCalendarSubscribed() {
		return isCalendarSubscribed;
	}

	public void setCalendarSubscribed(Boolean isCalendarSubscribed) {
		this.isCalendarSubscribed = isCalendarSubscribed;
	}

	public String getLoginSecret() {
		return loginSecret;
	}

	public void setLoginSecret(String loginSecret) {
		this.loginSecret = loginSecret;
	}

	public String getExchUrl() {
		return exchUrl;
	}

	public void setExchUrl(String exchUrl) {
		this.exchUrl = exchUrl;
	}

	public String getExchDomain() {
		return exchDomain;
	}

	public void setExchDomain(String exchDomain) {
		this.exchDomain = exchDomain;
	}

	public Boolean isPersonalEmailSubscribed() {
		return isPersonalEmailSubscribed;
	}

	public void setIsPersonalEmailSubscribed(Boolean isPersonalEmailSubscribed) {
		this.isPersonalEmailSubscribed = isPersonalEmailSubscribed;
	}

	public List<OrgMetaDataAdminRole> getOrgAdminRole() {
		return orgAdminRole;
	}

	public void setOrgAdminRole(List<OrgMetaDataAdminRole> orgAdminRole) {
		this.orgAdminRole = orgAdminRole;
	}
	
	public List<Map<String, Object>> getViewDateRangeConfig() {
		return viewDateRangeConfig;
	}

	public void setViewDateRangeConfig(List<Map<String, Object>> viewDateRangeConfig) {
		this.viewDateRangeConfig = viewDateRangeConfig;
	}

	public boolean isAuthenticationExpired() {
		return isAuthenticationExpired;
	}

	public void setAuthenticationExpired(boolean authenticationExpired) {
		isAuthenticationExpired = authenticationExpired;
	}

	public boolean isPersonalAccountActive() {
		return isPersonalAccountActive;
	}

	public void setPersonalAccountActive(boolean personalAccountActive) {
		isPersonalAccountActive = personalAccountActive;
	}

	public boolean isGdActive() {
		return gdActive;
	}

	public void setGdActive(boolean gdActive) {
		this.gdActive = gdActive;
	}

	public String getPsL5() {
		return psL5;
	}

	public void setPsL5(String psL5) {
		this.psL5 = psL5;
	}

	public String getPsL6() {
		return psL6;
	}

	public void setPsL6(String psL6) {
		this.psL6 = psL6;
	}

	public String getPsL7() {
		return psL7;
	}

	public void setPsL7(String psL7) {
		this.psL7 = psL7;
	}

	public String getIsTaskizeEnabledForUser() {
		return isTaskizeEnabledForUser;
	}

	public void setIsTaskizeEnabledForUser(String isTaskizeEnabledForUser) {
		this.isTaskizeEnabledForUser = isTaskizeEnabledForUser;
	}
}