package com.citi.icg.qma.common.server.dao;

import java.util.Date;
import java.util.List;

import dev.morphia.annotations.Embedded;
import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "GFPIDMapping", noClassnameStored = true)
public class GFPIDMapping
{
	@Id
	private String id;//GFPID
	private String gfpName;
	private String crtBy;
	private Date crtDate;
	private String modBy;
	private Date modDate;
	
	@Embedded
	private List<GFCId> gfcIds;//List of GFCIds for each GFPID.
	
	public GFPIDMapping(){
		
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}


	public String getGfpName()
	{
		return gfpName;
	}

	public void setGfpName(String gfpName)
	{
		this.gfpName = gfpName;
	}

	public List<GFCId> getGfcIds()
	{
		return gfcIds;
	}

	public void setGfcIds(List<GFCId> gfcIds)
	{
		this.gfcIds = gfcIds;
	}

	public String getCrtBy()
	{
		return crtBy;
	}

	public void setCrtBy(String crtBy)
	{
		this.crtBy = crtBy;
	}

	public Date getCrtDate()
	{
		return crtDate;
	}

	public void setCrtDate(Date crtDate)
	{
		this.crtDate = crtDate;
	}

	public String getModBy()
	{
		return modBy;
	}

	public void setModBy(String modBy)
	{
		this.modBy = modBy;
	}

	public Date getModDate()
	{
		return modDate;
	}

	public void setModDate(Date modDate)
	{
		this.modDate = modDate;
	}
	
	
	
}
