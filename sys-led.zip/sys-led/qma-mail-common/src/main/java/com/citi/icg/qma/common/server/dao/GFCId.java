package com.citi.icg.qma.common.server.dao;

import java.util.Date;

public class GFCId
{
	private String gfcId;
	private String gfcName;
	private String crtBy;
	private Date crtDate;
	private String modBy;
	private Date modDate;
	
	public GFCId(){
		
	}

	public String getGfcId()
	{
		return gfcId;
	}

	public void setGfcId(String gfcId)
	{
		this.gfcId = gfcId;
	}

	public String getGfcName()
	{
		return gfcName;
	}

	public void setGfcName(String gfcName)
	{
		this.gfcName = gfcName;
	}

	public String getCrtBy()
	{
		return crtBy;
	}

	public void setCrtBy(String crtBy)
	{
		this.crtBy = crtBy;
	}

	public Date getCrtDate()
	{
		return crtDate;
	}

	public void setCrtDate(Date crtDate)
	{
		this.crtDate = crtDate;
	}

	public String getModBy()
	{
		return modBy;
	}

	public void setModBy(String modBy)
	{
		this.modBy = modBy;
	}

	public Date getModDate()
	{
		return modDate;
	}

	public void setModDate(Date modDate)
	{
		this.modDate = modDate;
	}
	
	
}
