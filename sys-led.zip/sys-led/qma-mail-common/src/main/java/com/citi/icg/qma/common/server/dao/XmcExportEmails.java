/**
 * 
 */
package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

import org.bson.types.ObjectId;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;
import dev.morphia.annotations.Transient;

/**
 * 
 *
 */
@Entity(value = "XmcExportEmails", noClassnameStored = true)
public class XmcExportEmails implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1691031488270569844L;
	@Id
	private ObjectId id;
	private Long inquiryId;
	private Long groupId;
	private Long conversationId;
	private String processedFlag;
	private String failedReason;
	private Integer emailSizeInBytes;
	private Date processStartTime;
	private Date processEndTime;
	private String groupName;
	private String batchRunId;
	
	public ObjectId getId() {
		return id;
	}
	public void setId(ObjectId id) {
		this.id = id;
	}
	public Long getInquiryId() {
		return inquiryId;
	}
	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public Long getConversationId() {
		return conversationId;
	}
	public void setConversationId(Long conversationId) {
		this.conversationId = conversationId;
	}
	
	public String getProcessedFlag() {
		return processedFlag;
	}
	public void setProcessedFlag(String processedFlag) {
		this.processedFlag = processedFlag;
	}
		
	public String getFailedReason() {
		return failedReason;
	}
	public void setFailedReason(String failedReason) {
		this.failedReason = failedReason;
	}
	public Integer getEmailSizeInBytes() {
		return emailSizeInBytes;
	}
	public void setEmailSizeInBytes(Integer emailSizeInBytes) {
		this.emailSizeInBytes = emailSizeInBytes;
	}
	public Date getProcessStartTime() {
		return processStartTime;
	}
	public void setProcessStartTime(Date processStartTime) {
		this.processStartTime = processStartTime;
	}
	public Date getProcessEndTime() {
		return processEndTime;
	}
	public void setProcessEndTime(Date processEndTime) {
		this.processEndTime = processEndTime;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getBatchRunId() {
		return batchRunId;
	}
	public void setBatchRunId(String batchRunId) {
		this.batchRunId = batchRunId;
	}
	@Override
	public String toString() {
		return "XmcExportEmails [id=" + id + ", inquiryId=" + inquiryId + ", groupId=" + groupId + ", conversationId="
				+ conversationId + ", processedFlag=" + processedFlag + ", failedReason=" + failedReason
				+ ", emailSizeInBytes=" + emailSizeInBytes + ", groupName=" + groupName + ", batchRunId=" + batchRunId
				+ "]";
	}

}
