package com.citi.icg.qma.dao.persistence;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import jakarta.mail.MessagingException;
import jakarta.mail.Session;
import jakarta.mail.internet.MimeMessage;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.MsgSourceType;
import com.citi.icg.qma.common.server.dao.persistence.MongoMorphiaDAO;
import com.citi.icg.qma.dao.Action;
import com.citi.icg.qma.dao.ComponentEvent;
import com.citi.icg.qma.dao.MessageSnapshot;
import com.citi.icg.qma.dao.ProcessingStatus;
import com.citi.icg.qma.exception.NonRecoverableDBException;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.citi.icg.qma.kafka.KryoMailMessageCodec;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;

import dev.morphia.Key;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;


public class MessageSnapshotDAO extends MongoMorphiaDAO {

	private static volatile MessageSnapshotDAO instance=null;

	private static Logger logger = LoggerFactory.getLogger(MessageSnapshotDAO.class);
	private static final String MessageSnapshot_BUCKET_GRIDFS = "messageSnapshot";	

	private KryoMailMessageCodec kryoMailMessageCodec;
	private GridFS gridFS;

	private MessageSnapshotDAO() {
		kryoMailMessageCodec = new KryoMailMessageCodec();
		gridFS = new GridFS(mongoDatastore.getDB(), MessageSnapshot_BUCKET_GRIDFS);
	}

	public static MessageSnapshotDAO getInstance() {
		if (instance == null) {
			synchronized (MessageSnapshotDAO.class) {
				if (instance == null) {
					instance = new MessageSnapshotDAO();
				}
			}
		}
		return instance;
	}

	public Key<MessageSnapshot> saveMessageSnapshotInDB(MessageSnapshot messageSnapshot) throws NonRecoverableDBException  {
		// return mongoDatastore.save(messageSnapshot);
		return MongoMorphiaDAO.saveWithRetry(mongoDatastore, messageSnapshot);
	}

	public Map<String, String> saveMimeMessageInGridFS(MimeMessage message) throws MessagingException  {
//		TODO:GUID: I think bcc emails will have different recipients and hence, guid should 
//		be used to save and retrieve binary backup 		
		String fileName = message.getMessageID();
		GridFSInputFile gridFile = gridFS.createFile(kryoMailMessageCodec.serialize("", message));
		gridFile.setFilename(fileName);
		gridFile.setContentType("ser");
		gridFile.save();

		Map<String, String> map = new HashMap<>();
		map.put("gridFsFileName", gridFile.getFilename());
		//map.put("md5", gridFile.getMD5());
		map.put("gridFsId", gridFile.getId().toString());
		logger.debug("MimeMessage saved in GrifFS ");
		return map;
	}

	public MimeMessage getMimeMessageFromGridFS(String gridFsId) throws MessagingException, IOException ,Exception{
		MimeMessage message = null;
		ObjectId objectId = new ObjectId(gridFsId);
		GridFSDBFile gridFSDBFile = gridFS.find(objectId);
		if (gridFSDBFile != null) {
			Properties props = new Properties();
			props.setProperty("mail.mime.address.strict", "false");
			props.setProperty("mail.mime.decodetext.strict", "false");
			Session session = Session.getDefaultInstance(props);
			message = new MimeMessage(session, gridFSDBFile.getInputStream());
		}

		return message;
	}

	public MessageSnapshot getMessageSnapshotByMessageId(String messageId) {
		MessageSnapshot messageSnapshot = null;
		messageSnapshot=mongoDatastore.find(MessageSnapshot.class)
				.field("messageId").equal(messageId)
				.get();
		return messageSnapshot;
	}
	
	public MessageSnapshot getMessageSnapshotByMessageIdAndMailbox(String messageId, String mailbox) {
		MessageSnapshot messageSnapshot = null;
		messageSnapshot=mongoDatastore.find(MessageSnapshot.class)
				.field("messageId").equal(messageId)
				.field("mailboxName").equalIgnoreCase(mailbox)
				.get();
		return messageSnapshot;
	}
	
	public List<MessageSnapshot> getMessageSnapshotListByMessageIdAndMailbox(String messageId) {
		List<MessageSnapshot> messageSnapshots = null;
		messageSnapshots=mongoDatastore.find(MessageSnapshot.class)
				.field("messageId").equal(messageId)
				.field("msgSourceType").notEqual(MsgSourceType.personal)
				.asList();
		return messageSnapshots;
	}
	
	public MessageSnapshot getMessageSnapshotByGuid(String guid) {
		MessageSnapshot messageSnapshot = null;
		messageSnapshot=mongoDatastore.find(MessageSnapshot.class).field("_id").equal(guid).get();
		return messageSnapshot;
	}
	
	public MessageSnapshot getMessageSnapshotByMessageIdAndInquiryId(String messageId,Long inquiryId) {
		MessageSnapshot messageSnapshot = null;
		messageSnapshot=mongoDatastore.find(MessageSnapshot.class)
				.field("messageId").equal(messageId)
				.field("inquiryId").equal(inquiryId)
				.get();
		return messageSnapshot;
	}
	
	public void setMessageSnapshotToBeProcessed(String messageId,Boolean toBeProcessedAtController, Boolean toBeProcessedAtProcessor, String guid) throws NonRecoverableDBException {
		Query<MessageSnapshot> findQuery=mongoDatastore.createQuery(MessageSnapshot.class).field("_id").equal(guid);
		UpdateOperations<MessageSnapshot> ops=mongoDatastore.createUpdateOperations(MessageSnapshot.class)
				.set("modDate", new Date());
		
		if(toBeProcessedAtController!=null){
			ops.set("toBeProcessedAtController", toBeProcessedAtController.booleanValue());
		}
		if(toBeProcessedAtProcessor!=null){
			ops.set("toBeProcessed", toBeProcessedAtProcessor.booleanValue());
		}
				
		//mongoDatastore.update(updateQuery,ops,true);
		MongoMorphiaDAO.updateWithRetry(mongoDatastore, findQuery,ops,true);
		logger.debug("Updated toBeProcessed for guid:[{}], messageId:[{}] toBeProcessedAtController: {} toBeProcessedAtProcessor: {}",guid, messageId,toBeProcessedAtController,toBeProcessedAtProcessor);
	}
	
//	public void updateEventsToInactive(String messageId) throws NonRecoverableDBException{
//		if(messageId ==null){
//			logger.warn("MessageID is null in updateEventsToInactive skipping");
//			return;
//		}
//		Query<MessageSnapshot> findQuery=mongoDatastore.createQuery(MessageSnapshot.class).field("_id").equal(messageId)
//				.field("events.component").equal(ComponentEvent.COMPONENT_CONTROLLER);
//		System.out.println(findQuery);
//		UpdateOperations<MessageSnapshot> ops=mongoDatastore.createUpdateOperations(MessageSnapshot.class)
//				.disableValidation()
//				.set("events.$.status","from java11111");
//		
//		System.out.println(ops);
//		mongoDatastore.update(findQuery, ops);
//		
//	}
	
	public void updateProcessedCount(String guid, String messageId, int newProcessedCount) throws NonRecoverableDBException{
		if(guid ==null){
			logger.warn("guid is null in updateProcessedCount skipping");
			return;
		}
		Query<MessageSnapshot> findQuery=mongoDatastore.createQuery(MessageSnapshot.class).field("_id").equal(guid);
		UpdateOperations<MessageSnapshot> ops=mongoDatastore.createUpdateOperations(MessageSnapshot.class)
				.set("modDate", new Date())
				.set("processedCount",newProcessedCount);
				
		MongoMorphiaDAO.updateWithRetry(mongoDatastore, findQuery,ops,false);	
		
		logger.debug("updated the processed count of guid:[{}] messageid: {} to {}",guid, messageId,newProcessedCount);
	}
	
	public List<MessageSnapshot> getMessageSnapshotFromDBWithSubjectName(String subject) {
		List<MessageSnapshot> list=null;
	//	list=mongoDatastore.find(MessageSnapshot.class).field("subject").contains(subject).limit(20).asList();
		list=mongoDatastore.find(MessageSnapshot.class).field("subject").contains(subject).asList();
		return list;
	}

	public List<MessageSnapshot> getMessageSnapshotListContainsId(String partialMessageId){
		List<MessageSnapshot> list=null;
		list=mongoDatastore.find(MessageSnapshot.class).field("_id").contains(partialMessageId).limit(10).asList();
		return list;
	}

	public void updateGridFSDetails(String gridFSFilename, String gridFSId, String guid) throws NonRecoverableDBException  {
		Query<MessageSnapshot> updateQuery=mongoDatastore.createQuery(MessageSnapshot.class).field("_id").equal(guid);
		UpdateOperations<MessageSnapshot> ops=mongoDatastore.createUpdateOperations(MessageSnapshot.class)
				.set("gridFSFilename", gridFSFilename)
				.set("gridFSId", gridFSId)
				.set("modDate", new Date());
//		mongoDatastore.update(updateQuery,ops,true);
		MongoMorphiaDAO.updateWithRetry(mongoDatastore, updateQuery,ops,true);
		logger.debug("Updated GRIDFS details for guid: "+guid+" gridFSFilename: " +gridFSFilename+" gridFSId: "+gridFSId);
	}


	public void updateSnapshot(ComponentEvent event ,ProcessingStatus processingStatus, String guid) throws NonRecoverableDBException  {		
		
		if(guid ==null){
			logger.warn("guid is null in updateSnapshot skipping");
			return;
		}
		Query<MessageSnapshot> updateQuery=mongoDatastore.createQuery(MessageSnapshot.class).field("_id").equal(guid);
		UpdateOperations<MessageSnapshot> ops=mongoDatastore.createUpdateOperations(MessageSnapshot.class)
				.set("modDate", new Date())
				.add("events", event); 
		
		if(processingStatus!=null){
			ops.set("processingStatus",processingStatus);
		}
		
//		mongoDatastore.update(updateQuery,ops,true);
		MongoMorphiaDAO.updateWithRetry(mongoDatastore, updateQuery,ops,true);
		logger.debug("Added Event for guid: "+guid+ "  " + event);
		
	}
	
	public void updateSnapshotForDuplicateCheckEvents(ComponentEvent event ,ProcessingStatus processingStatus, String guid) throws NonRecoverableDBException  {		
		
		if(guid ==null){
			logger.warn("guid is null in updateSnapshotForDuplicateCheckEvents skipping");
			return;
		}
		Query<MessageSnapshot> updateQuery=mongoDatastore.createQuery(MessageSnapshot.class).field("_id").equal(guid);
		UpdateOperations<MessageSnapshot> ops=mongoDatastore.createUpdateOperations(MessageSnapshot.class)
				.set("modDate", new Date())
				.add("duplicateCheckEvents", event); 
		
		if(processingStatus!=null){
			ops.set("processingStatus",processingStatus);
		}
		
//		mongoDatastore.update(updateQuery,ops,true);
		MongoMorphiaDAO.updateWithRetry(mongoDatastore, updateQuery,ops,true);
		logger.debug("Added duplicateCheckEvent for guid:[{}] event[{}] ", guid, event);
		
	}
	
	public void updateInquiryIdAndConversationId(Long inquiryId,Long conversationId, Set<Long> validGroupIds, String guid) throws NonRecoverableDBException {
		if(guid==null){
			logger.warn("guid is null in updateInquiryId skipping");
			return;
		}
		Query<MessageSnapshot> findQuery=mongoDatastore.createQuery(MessageSnapshot.class).field("_id").equal(guid);
		
		UpdateOperations<MessageSnapshot> ops=mongoDatastore.createUpdateOperations(MessageSnapshot.class)
				.set("inquiryId", inquiryId)
				.set("conversationId", conversationId)
				.set("modDate", new Date());
				//.set("",inquiry.getgr);
				if (validGroupIds!=null && !validGroupIds.isEmpty()) {
					//converting to list so that the entries in groupIds and groupNames can be related by index in MessageSnapshot 
					List<Long> validGroupIdsList = new ArrayList<>();
					for (Long id : validGroupIds) {
						validGroupIdsList.add(id);
					}					
					ops.set("groupIds", validGroupIdsList);
					Map<Long, String> groupIdToNameMap = QMACacheFactory.getCache().getGroupIdToNameMap();
					List<String> groupNames = new ArrayList<String>();
					if (groupIdToNameMap!=null && !groupIdToNameMap.isEmpty()) {
						for (Long groupId : validGroupIdsList) {
							groupNames.add(groupIdToNameMap.get(groupId));
						}
						ops.set("groupNames", groupNames);
					}					
				}

		//mongoDatastore.update(updateQuery,ops,true);
		MongoMorphiaDAO.updateWithRetry(mongoDatastore,findQuery,ops,true);
		logger.debug("Updated inquiryId and conversationId details for guid: [{}]  inquiryId: {} conversationId: {} in MessageSnapshot ",guid,inquiryId,conversationId);
	}


	public void updateSnapshot(Long inquiryMessageRefId, Long inquiryId, Action action, String guid) throws NonRecoverableDBException {
		if(guid==null){
			logger.warn("guid is null in updateInquiryId skipping");
			return;
		}
		Query<MessageSnapshot> updateQuery=mongoDatastore.createQuery(MessageSnapshot.class).field("_id").equal(guid);
		UpdateOperations<MessageSnapshot> ops=mongoDatastore.createUpdateOperations(MessageSnapshot.class)
				.set("modDate", new Date())
				.set("inquiryMessageRefId", inquiryMessageRefId)
				.set("action", action);
		
		if(inquiryId!=null){
			ops.set("inquiryId", inquiryId);
		}
		
//		mongoDatastore.update(updateQuery,ops,true);
		MongoMorphiaDAO.updateWithRetry(mongoDatastore,updateQuery,ops,true);
		logger.debug("Updated InquiryID details for guid: [{}] inquiryMessageRefId: {} action: {} , inquiryId: {}",guid,inquiryMessageRefId,action,inquiryId);
	}
	
}
