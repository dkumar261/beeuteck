package com.citi.icg.qma.common.core.config;

import java.lang.reflect.Array;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

import org.apache.commons.beanutils.ConvertUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.citi.icg.qma.common.core.exception.CommunicatorException;

public class XmlConfigW3dom
{
	private static final String GETTER_PREFIX = "get";
	private static final Pattern LIST_DELIMETER = Pattern.compile("\\s*,\\s*");
	private final XmlDocumentSource configSource;
	private final String selector;
	private static final Logger LOGGER = LoggerFactory.getLogger(XmlConfigW3dom.class);//Sonar Fix -- Standard outputs should not be used directly to log anything

	public XmlConfigW3dom(XmlDocumentSource config, String selector)
	{
		this.configSource = config;
		this.selector = selector;
	}

	private String getTagName(String methodName)
	{
		if (methodName.startsWith(GETTER_PREFIX))
		{
			return NamesUtil.toXmlName(methodName.substring(GETTER_PREFIX.length()));
		}
		return methodName;
	}

	public synchronized Object getValue(Class<?> returnType, String elementName, Component icgComonent) throws CommunicatorException // Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		String tagName = getTagName(elementName);
		Node parent = getConfigRootElement();
		Element element = XmlW3DomUtils.getChildByTagName(parent, tagName);
		if (element == null)
		{
			return null;
		}
		if (returnType.isArray())
		{
			return getArrayValue(returnType, element);
		}
		if (returnType == Properties.class)
		{
			Map<String, String> properties = XmlW3DomUtils.getPropertiesValue(element);
			Properties props = new Properties();
			props.putAll(properties);
			return props;
		}
		if (returnType == Map.class || returnType == LinkedHashMap.class)
		{
			return getReturnTypeAsMap(icgComonent, element);//sonar fix - reduce complexity less then 10 of method 
		}
		return getSimpleValue(returnType, element);
	}

	private Object getReturnTypeAsMap(Component icgComonent, Element element)
	{
		if (icgComonent != null)
		{
			return getMapValue(icgComonent, element);
		}
		
		return XmlW3DomUtils.getPropertiesValue(element);
	}

	@SuppressWarnings("unchecked")
	private LinkedHashMap<Object,Object> getMapValue(Component icgComonent, Element element)
	{
		LinkedHashMap<Object,Object> valueMap = new LinkedHashMap<>();
		List<Element> childs = XmlW3DomUtils.getChildElements(element);
		for (Element child : childs)
		{
			XmlConfigW3dom itemConfig = new XmlConfigW3dom(configSource, XmlW3DomUtils.getUniqXPath(child));
			Object keyValue = null;
			try
			{
				keyValue = itemConfig.getValue(String.class, icgComonent.key(), null);
			}
			catch (CommunicatorException e)
			{
				LOGGER.error("Error in XmlConfigW3dom getMapValue() " , e);
			}
			Object component = ConfigInstanceFactory.createProxy(icgComonent.type(), itemConfig);
			valueMap.put(keyValue, component);
		}
		return valueMap;
	}

	private Object[] getArrayValue(Class<?> returnType, Element element)
	{
		Class<?> elemType = returnType.getComponentType();
		List<Element> childs = XmlW3DomUtils.getChildElements(element);
		if (childs.size() == 1 && hasConverter(elemType))
		{
			String nodeValue = XmlW3DomUtils.getNodeText(childs.get(0));
			String[] tokens = LIST_DELIMETER.split(nodeValue);
			Object[] array = (Object[]) Array.newInstance(elemType, tokens.length);
			for (int i = 0; i < array.length; i++)
			{
				array[i] = convertType(tokens[i], elemType);
			}
			return array;
		}
		Object[] array = (Object[]) Array.newInstance(elemType, childs.size());
		for (int i = 0; i < array.length; i++)
		{
			array[i] = getSimpleValue(elemType, childs.get(i));
		}
		return array;
	}

	private Object getSimpleValue(Class<?> returnType, Element selectNode)
	{
		Object nodeValue ;//Sonar fix - remove the useless assignments
		if (hasConverter(returnType))
		{
			nodeValue = convertType(XmlW3DomUtils.getNodeText(selectNode), returnType);
		}
		else if (Date.class.isAssignableFrom(returnType))
		{
			nodeValue = convertToDate(XmlW3DomUtils.getNodeText(selectNode));
		}
		else
		{
			nodeValue = getConfiguration(returnType, XmlW3DomUtils.getUniqXPath(selectNode));
		}
		return nodeValue;
	}

	private boolean hasConverter(Class<?> type)
	{
		return ConvertUtils.lookup(type) != null;
	}

	public static Object convertType(String nodeValue, Class<?> type)
	{
		if (nodeValue == null || type == null || type == String.class)
		{
			return nodeValue == null ? null : nodeValue.trim();
		}
		return ConvertUtils.convert(nodeValue, type);
	}

	private Date convertToDate(String value)
	{
		//TODO-Implement date conversation logic
		LOGGER.info("value=null {}", value);
		return null;
	}

	public Element getConfigRootElement() throws CommunicatorException
	{
		try
		{
			if (selector == null)
			{
				return configSource.getDocument().getDocumentElement();
			}
			return (Element) XmlW3DomUtils.selectSingleNode(configSource.getDocument(), selector);
		}
		catch (Exception e)
		{
			throw new CommunicatorException(e.getMessage(), e);
		}
	}

	public <T> T getConfiguration(final Class<T> configInterface, String selector)
	{
		XmlConfigW3dom icgConfig = new XmlConfigW3dom(configSource, selector);
		return ConfigInstanceFactory.createProxy(configInterface, icgConfig);
	}
}
