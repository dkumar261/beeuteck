package com.citi.icg.qma.common.core.config;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;

public class ConfigInstanceFactory
{
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigInstanceFactory.class);//Sonar Fix -- Standard outputs should not be used directly to log anything
	
	private ConfigInstanceFactory(){
		//As this class is Util, so added making private constructor.
		//Sonar Fix -- Utility classes should not have public constructors 
	}
	
	public static XmlConfigW3dom getInstance(String configName)
	{
		return new XmlConfigW3dom(getIcgXmlDocumentSource(configName), null);
	}

	public static <T> T getRootConfiguration(Class<T> configuratinoRootInterface)
	{
		return getConfiguration(ConfigUtil.getConfigName(configuratinoRootInterface), configuratinoRootInterface);
	}

	public static <T> T getConfiguration(String configName, final Class<T> configInterface)
	{
		return ConfigInstanceFactory.createProxy(configInterface, getInstance(configName));
	}

	private static XmlDocumentSource getIcgXmlDocumentSource(String configName)
	{
		Configuration configuration = ConfigurationManager.getConfiguration(configName);
		if (configuration == null)
		{
			try
			{
				configuration = ConfigUtil.getInstance(new Configuration(), configName);
			}
			catch (CommunicatorException e)
			{
				LOGGER.error("Error in ConfigInstanceFactory getIcgXmlDocumentSource() ", e);
			}
		}
		return configuration;
	}

	public static <T> T createProxy(final Class<T> configInterface, XmlConfigW3dom icgConfig)
	{
		XmInvocationHandler proxyHandler = new XmInvocationHandler(icgConfig);
		Class[] interfaces = new Class[] { configInterface };
		Object proxyInstance = Proxy.newProxyInstance(configInterface.getClassLoader(), interfaces, proxyHandler);
		return (T) proxyInstance;
	}

	/**
	 * Java proxy implementation.
	 */
	static class XmInvocationHandler implements InvocationHandler
	{
		XmlConfigW3dom icgConfig;

		public XmInvocationHandler(XmlConfigW3dom handler)
		{
			this.icgConfig = handler;
		}
		//Sonar fix -- use override annotation on overridden method
		@Override
		public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
		{
			return icgConfig.getValue(method.getReturnType(), method.getName(), method.getAnnotation(Component.class));
		}
	}
}
