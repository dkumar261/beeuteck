package com.citi.icg.qma.common.server.dao.persistence;

import java.util.List;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.EmailUtil;
import com.citi.icg.qma.common.core.util.GenericUtil;
import com.citi.icg.qma.common.server.dao.AppUsers;
import com.citi.icg.qma.common.server.dao.BaseEntity;
import com.mongodb.MongoException;
import com.mongodb.MongoSocketException;

import dev.morphia.Datastore;

/**
 * 
 * 
 *
 */
public class MongoMorphiaArchivalInstance implements IGenericBeanDAO {

	private static final Logger logger = LoggerFactory.getLogger(MongoMorphiaArchivalInstance.class);
	public final Datastore mongoArchivalDataStore;
	private static String supportEmail = "XXXX";

	public MongoMorphiaArchivalInstance() {
		mongoArchivalDataStore = MongoDBArchivalInstance.getInstance().getDataStore();
	}
	
	@Override
	public <E extends BaseEntity> E get(Class<E> clazz, final ObjectId id)
	{
		if ((clazz == null) || (id == null))
		{
			return null;
		}

		return mongoArchivalDataStore.find(clazz).field("id").equal(id).get();
	}

	@Override
	public <E extends BaseEntity> Long persist(E entity)
	{
		mongoArchivalDataStore.save(entity);
		return entity.getId();
	}

	@Override
	public <E extends BaseEntity> Long count(Class<E> clazz)
	{
		if (clazz == null)
		{
			return 0L;
		}

		return mongoArchivalDataStore.find(clazz).countAll();
	}

	@Override
	public <E extends BaseEntity> E clear(Class<E> clazz)
	{
		mongoArchivalDataStore.delete(mongoArchivalDataStore.createQuery(clazz));

		return null;
	}

	@Override
	public List<AppUsers> getAllAppUsers(Class clazz)
	{
		return mongoArchivalDataStore.find(clazz).asList();
	}

	@Override
	public void close()
	{

		mongoArchivalDataStore.getMongo().close();
	}

	public Datastore getMongoDatastore()
	{
		return mongoArchivalDataStore;
	}

	public void handleCriticalException(String processName, Throwable e, boolean alwaysNotifySupport, Long retryCount)
	{
		boolean isExInstanceOf = e instanceof MongoException || e instanceof ExceptionInInitializerError || e instanceof MongoSocketException;
		if (alwaysNotifySupport || isExInstanceOf || (e.getCause() != null && e.getCause().toString().contains("com.mongodb.MongoException$Network")))
		{

			logger.error(processName + " : Unexpected exception. DB has issues [" + (isExInstanceOf || (e.getCause() != null && e.getCause().toString().contains("com.mongodb.MongoException$Network")))
					+ "], Please checkwith MongoDB Team for DB issues, once up and ready please restart the process. QMA Services are being closed", e);
			if (retryCount == 0)
			{
				EmailUtil.sendEmailToSupport(null, processName + " :", " Unexpected exception, Please do log analysis and check with application, DBA team.",
						supportEmail, e);
			}
			else
			{
				EmailUtil.sendEmailToSupport(null, processName + " :",
						" Unexpected exception, Please do log analysis and check with application, DBA team. Tried running process for " + retryCount + " times",
						supportEmail, e);
			}
			GenericUtil.stopProcess(processName, -1);
		}
	}

}
