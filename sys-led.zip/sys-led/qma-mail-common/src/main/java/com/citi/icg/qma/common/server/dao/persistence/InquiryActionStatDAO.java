package com.citi.icg.qma.common.server.dao.persistence;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.QmaMailConstants;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.InquiryActionStatistics;
import com.citi.icg.qma.common.server.dao.Workflow;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class InquiryActionStatDAO extends MongoMorphiaDAO implements IInquiryActionStat
{
	private static final Logger logger = LoggerFactory.getLogger(InquiryActionStatDAO.class);
	//private CacheDAO cacheDAO = CacheDAO.getInstance();

	public boolean createInquiryActionStats(List<ConversationRecipient> recipientList, Inquiry dbInquiryInfo, List<Workflow> workFlowList, Date currentTime, String extSenderDomain, Map<Long, HashMap<String, String>> routingCriteriaMap)
			throws CommunicatorException
	{
		boolean recordInserted = false;
		try
		{
			DBCollection inquiryStatsCollection = mongoDatastore.getCollection(InquiryActionStatistics.class);
			Map<Long, DBObject> inquiryStatsMap = new HashMap<>();
			String firstGrpInTo = QmaMailConstants.STRING_YES;
			for (ConversationRecipient recipient : recipientList)
			{
				if (null != recipient.getGroupId())
				{
					DBObject inqStat;
					Long groupId = recipient.getGroupId();
					if (QmaMailConstants.TO_CATEGARY.equals(recipient.getToFrom()))
					{
						inqStat = createStatObject(dbInquiryInfo, workFlowList, QmaMailConstants.STRING_YES, QmaMailConstants.STRING_NO, currentTime, firstGrpInTo, recipient.getGroupId());
						firstGrpInTo = QmaMailConstants.STRING_NO;
						inqStat.put(EXT_SENDER_DOMAIN, extSenderDomain);
						setAutoReqTypeAssignOwner(routingCriteriaMap, groupId, inqStat);
						inquiryStatsMap.put(recipient.getGroupId(), inqStat);
					}
					else if (QmaMailConstants.CC_CATEGORY.equals(recipient.getToFrom()))
					{
						inqStat = createStatObject(dbInquiryInfo, workFlowList, QmaMailConstants.STRING_NO, QmaMailConstants.STRING_YES, currentTime, QmaMailConstants.STRING_NO,
								recipient.getGroupId());
						inqStat.put(EXT_SENDER_DOMAIN, extSenderDomain);
						setAutoReqTypeAssignOwner(routingCriteriaMap, groupId, inqStat);
						inquiryStatsMap.put(recipient.getGroupId(), inqStat);
					}
				}

			}

			if (!inquiryStatsMap.isEmpty())
			{
				// Bulk insert records to inquiry stats collection.
				inquiryStatsCollection.insert(new ArrayList<DBObject>(inquiryStatsMap.values()));
				recordInserted = true;
			}

		}
		catch (Exception ex)
		{
			logger.error("Exception in createInquiryActionStats while inserting stats data for inquiryId= "+ dbInquiryInfo.id, ex);
			throw new CommunicatorException("Exception in createInquiryActionStats while inserting stats data for inquiryId= " + dbInquiryInfo.id, ex);
		}
		return recordInserted;
	}

	private void setAutoReqTypeAssignOwner(Map<Long, HashMap<String, String>> routingCriteriaMap, Long groupId, DBObject inqStat)
	{
		if(null != routingCriteriaMap && null != routingCriteriaMap.get(groupId))				
		{
			if(null != routingCriteriaMap.get(groupId).get("assignToUser"))
			{
				inqStat.put("actionAutoAssignOwner", QmaMailConstants.STRING_YES);
			}
			if(null != routingCriteriaMap.get(groupId).get("requestType"))
			{
				inqStat.put("actionAutoAssignReqType", QmaMailConstants.STRING_YES);
			}
		}
	}

	@Override
	public void updateInquiryActionStats(List<ConversationRecipient> recipientsList, Inquiry inquiry, List<Workflow> workFlowList, Date currentTime, Map<Long, HashMap<String, String>> routingCriteriaMap) throws CommunicatorException
	{
		if (null != recipientsList && !recipientsList.isEmpty())
		{
			String action = inquiry.getAction();
			bulkInsertUpdateInquiryActionStats(inquiry, workFlowList, action, recipientsList, currentTime, routingCriteriaMap);
		}

	}

	public void bulkUpdateInquiryActionStats(Inquiry inquiry, String action, Date currentTime, Set<Long> groupIdList) throws CommunicatorException
	{
		if (!groupIdList.isEmpty())
		{
			Long inquiryId = inquiry.id;
			DBCollection inquiryStatsCollection = mongoDatastore.getCollection(InquiryActionStatistics.class);
			BulkWriteOperation bulkInquiryStatUpdOp = inquiryStatsCollection.initializeOrderedBulkOperation();
			for (Long groupId : groupIdList)
			{
				addStatObjForBulkUpdate(action, currentTime, inquiryId, bulkInquiryStatUpdOp, groupId, null);
			}
			// Bulk update inquiry action stats
			bulkInquiryStatUpdOp.execute();
		}
	}

	private void bulkInsertUpdateInquiryActionStats(Inquiry inquiry, List<Workflow> workFlowList, String action, List<ConversationRecipient> recipientsList, Date currentTime, Map<Long, HashMap<String, String>> routingCriteriaMap)
			throws CommunicatorException
	{
		try
		{
			Long inquiryId = inquiry.id;
			DBCollection inquiryStatsCollection = mongoDatastore.getCollection(InquiryActionStatistics.class);
			BulkWriteOperation bulkInquiryStatUpdOp = inquiryStatsCollection.initializeOrderedBulkOperation();
			String firstGrpInTo = QmaMailConstants.STRING_YES;
			BasicDBObject projFields = new BasicDBObject();
			projFields.put("groupId", 1);
			DBCursor cur = inquiryStatsCollection.find(new BasicDBObject(InquiryDAO.INQUIRY_ID, inquiryId), projFields);
			List<Long> dbGroupIdList = new ArrayList<>();
			List<DBObject> newRecordInsertList = new ArrayList<>();
			boolean updateRecrods = false;
			while (cur.hasNext())
			{
				dbGroupIdList.add((Long) cur.next().get("groupId"));
			}
			for (ConversationRecipient recipient : recipientsList)
			{
				Long groupId = recipient.getGroupId();
				if (null != groupId)
				{
					// From Group Record
					if (InquiryDAO.FROM_CATEGORY.equals(recipient.getToFrom()))
					{
						updateRecrods = true;
						addStatObjForBulkUpdate(action, currentTime, inquiryId, bulkInquiryStatUpdOp, groupId, routingCriteriaMap);
					}
					// New TO/CC group record insert
					else if (!dbGroupIdList.contains(groupId))
					{
						firstGrpInTo = addRecordForInsert(inquiry, workFlowList, currentTime, firstGrpInTo, newRecordInsertList, recipient, routingCriteriaMap);
					}
					//Existing To/CC record, but category changed in current conversation
					else if(InquiryDAO.TO_CATEGORY.equals(recipient.getToFrom())){
						updateRecrods = true;
						addStatObjForBulkUpdateToCc(currentTime, inquiry, bulkInquiryStatUpdOp, groupId,QmaMailConstants.STRING_YES,QmaMailConstants.STRING_NO, firstGrpInTo);
						firstGrpInTo = QmaMailConstants.STRING_NO;
					}
					//Existing TO/CC record, but category changed in current conversation
					else if(InquiryDAO.CC_CATEGORY.equals(recipient.getToFrom())){
						updateRecrods = true;
						addStatObjForBulkUpdateToCc(currentTime, inquiry, bulkInquiryStatUpdOp, groupId,QmaMailConstants.STRING_NO,QmaMailConstants.STRING_YES,QmaMailConstants.STRING_NO);
					}
				}
			}
			if (updateRecrods)
			{
				// Bulk update inquiry action stats
				bulkInquiryStatUpdOp.execute();
			}

			if (!newRecordInsertList.isEmpty())
			{
				inquiryStatsCollection.insert(newRecordInsertList);
			}
		}
		catch (Exception ex)
		{
			logger.error("Exception in bulkInsertUpdateInquiryActionStats while updating inquiry stat for inquiryId= " + inquiry.id, ex);
			throw new CommunicatorException("Exception in bulkInsertUpdateInquiryActionStats while updating inquiry stat for inquiryId= " + inquiry.id, ex);
		}
	}

	private String addRecordForInsert(Inquiry inquiry, List<Workflow> workFlowList, Date currentTime, String firstGrpInTo, List<DBObject> newRecordInsertList, ConversationRecipient recipient,
			Map<Long, HashMap<String, String>> routingCriteriaMap) throws CommunicatorException
	{
		DBObject newInqStatObj = new BasicDBObject();
		if (QmaMailConstants.TO_CATEGARY.equals(recipient.getToFrom()))
		{
			newInqStatObj = createStatObject(inquiry, workFlowList, QmaMailConstants.STRING_YES, QmaMailConstants.STRING_NO, currentTime, firstGrpInTo, recipient.getGroupId());
			firstGrpInTo = QmaMailConstants.STRING_NO;
			setAutoReqTypeAssignOwner(routingCriteriaMap, recipient.getGroupId(), newInqStatObj);
		}
		else if (QmaMailConstants.CC_CATEGORY.equals(recipient.getToFrom()))
		{
			newInqStatObj = createStatObject(inquiry, workFlowList, QmaMailConstants.STRING_NO, QmaMailConstants.STRING_YES, currentTime, QmaMailConstants.STRING_NO, recipient.getGroupId());
			setAutoReqTypeAssignOwner(routingCriteriaMap, recipient.getGroupId(), newInqStatObj);
		}
		newRecordInsertList.add(newInqStatObj);
		return firstGrpInTo;
	}

	private void addStatObjForBulkUpdate(String action, Date currentTime, Long inquiryId, BulkWriteOperation bulkInquiryStatUpdOp, Long groupId,  Map<Long, HashMap<String, String>> routingCriteriaMap) throws CommunicatorException
	{
		DBObject updateFindQuery = new BasicDBObject();
		updateFindQuery.put(InquiryDAO.INQUIRY_ID, inquiryId);
		updateFindQuery.put(InquiryDAO.GROUP_ID, groupId);
		DBObject updateDBFields = new BasicDBObject();
		DBObject inqUpdStatObj = new BasicDBObject();
		// Update inquiry fields
		updateInquiryStatObject(inqUpdStatObj, action);
		inqUpdStatObj.put(QmaMailConstants.ACTION_TIME, currentTime);
		setAutoReqTypeAssignOwner(routingCriteriaMap, groupId, inqUpdStatObj);
		updateDBFields.put("$set", inqUpdStatObj);
		bulkInquiryStatUpdOp.find(updateFindQuery).update(updateDBFields);
	}
	
	private void addStatObjForBulkUpdateToCc(Date currentTime, Inquiry inquiry, BulkWriteOperation bulkInquiryStatUpdOp, Long groupId,String inTo,String inCc,String firstGroupInTo) throws CommunicatorException
	{
		DBObject updateFindQuery = new BasicDBObject();
		updateFindQuery.put(InquiryDAO.INQUIRY_ID, inquiry.id);
		updateFindQuery.put(InquiryDAO.GROUP_ID, groupId);
		DBObject updateDBFields = new BasicDBObject();
		DBObject inqUpdStatObj = new BasicDBObject();
		updateExistingStatObject(inqUpdStatObj, inTo, inCc, firstGroupInTo);
		inqUpdStatObj.put(QmaMailConstants.ACTION_TIME, currentTime);
		updateDBFields.put("$set", inqUpdStatObj);
		bulkInquiryStatUpdOp.find(updateFindQuery).update(updateDBFields);
	}

	private void updateInquiryStatObject(DBObject inqStat, String action) throws CommunicatorException
	{
		// Covering all the action performed from QMA.
		inqStat.put(InquiryDAO.ACTION, action);
		if (InquiryDAO.ACTION_REPLY.equalsIgnoreCase(action) || InquiryDAO.ACTION_REPLY_ALL.equalsIgnoreCase(action))
		{
			inqStat.put("uiActionReply", QmaMailConstants.STRING_YES);
		}
		else if (InquiryDAO.ACTION_REPLY_RESOLVE.equalsIgnoreCase(action) || InquiryDAO.ACTION_REPLYALL_RESOLVE.equalsIgnoreCase(action))
		{
			inqStat.put("uiActionResolveWithReply", QmaMailConstants.STRING_YES);
		}
		else if (InquiryDAO.ACTION_RESOLVE.equalsIgnoreCase(action))
		{
			inqStat.put("uiActionResolveWithoutReply", QmaMailConstants.STRING_YES);
		}
		else if (InquiryDAO.ACTION_FORWARD.equalsIgnoreCase(action))
		{
			inqStat.put("uiActionForward", QmaMailConstants.STRING_YES);
		}
		else if (InquiryDAO.ACTION_ASSIGN_TO_OWNER.equalsIgnoreCase(action))
		{
			inqStat.put(UI_ACTION_ASSIGN_OWNER, QmaMailConstants.STRING_YES);
		}
		else if (InquiryDAO.ACTION_ASSIGN_REQ_TYPE.equalsIgnoreCase(action))
		{
			inqStat.put(UI_ACTION_ASSIGN_REQ_TYPE, QmaMailConstants.STRING_YES);
		}
	}

	private DBObject createStatObject(Inquiry inquiry, List<Workflow> workFlowList, String inTo, String inCC, Date currentTime, String firstGrpInTo, Long groupId) throws CommunicatorException
	{
		DBObject inqStat = createStatObjectForNewInquiry(inquiry, inTo, inCC, firstGrpInTo);
		inqStat.put(QmaMailConstants.ACTION_TIME, currentTime);
		inqStat.put(InquiryDAO.GROUP_ID, groupId);
		//inqStat.put(InquiryDAO.GROUP_NAME, cacheDAO.getGroupIdToCodeMap().get(groupId + ""));
		inqStat.put(InquiryDAO.GROUP_NAME,( groupId==null?null:QMACacheFactory.getCache().getGroupIdToNameMap().get(groupId)));//nullchk
		Workflow workflow = getWorkflow(workFlowList, groupId, InquiryDAO.INQUIRY_DIRECTION_IN);
		if (null != workflow)
		{
			inqStat.put(UI_ACTION_ASSIGN_REQ_TYPE, workflow.getRequestType() == null || workflow.getRequestType() == "" ? QmaMailConstants.STRING_NO : QmaMailConstants.STRING_YES);
			inqStat.put(UI_ACTION_ASSIGN_OWNER, workflow.getRequestType() == null || workflow.getAssignedUserName() == "" ? QmaMailConstants.STRING_NO : QmaMailConstants.STRING_YES);
		}
		return inqStat;
	}

	private DBObject createStatObjectForNewInquiry(Inquiry inquiry, String inTo, String inCC, String firstGrpInTo) throws CommunicatorException
	{
		DBObject inqStat = new BasicDBObject();
		inqStat.put(InquiryDAO.INQUIRY_ID, inquiry.id);
		inqStat.put("isInTo", inTo);
		inqStat.put("isInCc", inCC);
		setDefaultValuesToInquiryActionStatObj(inqStat);
		if (QmaMailConstants.STRING_YES.equals(inTo))
		{
			inqStat.put("firstGroupInTo", firstGrpInTo);
		}
		// Covering all the action performed from QMA.
		String action = inquiry.getAction();
		inqStat.put(InquiryDAO.ACTION, action);
		if (QmaMailConstants.ACTION_NEW_INQUIRY.equalsIgnoreCase(action))
			inqStat.put(InquiryDAO.ACTION, QmaMailConstants.ACTION_NEW_INQUIRY);
		return inqStat;
	}
	
	private DBObject updateExistingStatObject(DBObject inqStat, String inTo, String inCC, String firstGrpInTo) throws CommunicatorException
	{
		if(QmaMailConstants.STRING_YES.equals(inTo)){
			inqStat.put("isInTo", inTo);
		}
		if(QmaMailConstants.STRING_YES.equals(inCC)){
			inqStat.put("isInCc", inCC);
		}
		if (QmaMailConstants.STRING_YES.equals(inTo) && QmaMailConstants.STRING_YES.equals(firstGrpInTo))
		{
			inqStat.put("firstGroupInTo", firstGrpInTo);
		}
		return inqStat;
	}

	private Workflow getWorkflow(List<Workflow> inquiryWorkflowList, Long groupId, String direction) throws CommunicatorException
	{
		Workflow workflow = null;
		if (inquiryWorkflowList == null || inquiryWorkflowList.isEmpty())
		{
			return workflow;
		}
		for (Workflow inqWorkflow : inquiryWorkflowList)
		{
			if (inqWorkflow.getDirection() != null && direction.equals(inqWorkflow.getDirection()) && inqWorkflow.getAssignedGroupId() != null && inqWorkflow.getAssignedGroupId().equals(groupId))
			{
				workflow = inqWorkflow;
				break;
			}
		}
		return workflow;
	}

	private void setDefaultValuesToInquiryActionStatObj(DBObject inqStat) throws CommunicatorException
	{
		inqStat.put("uiActionReply", QmaMailConstants.STRING_NO);
		inqStat.put("uiActionResolveWithoutReply", QmaMailConstants.STRING_NO);
		inqStat.put("uiActionResolveWithReply", QmaMailConstants.STRING_NO);
		inqStat.put("uiActionForward", QmaMailConstants.STRING_NO);
		inqStat.put(UI_ACTION_ASSIGN_OWNER, QmaMailConstants.STRING_NO);
		inqStat.put(UI_ACTION_ASSIGN_REQ_TYPE, QmaMailConstants.STRING_NO);
		inqStat.put("firstGroupInTo", QmaMailConstants.STRING_NO);
		inqStat.put("actionAutoAssignReqType", QmaMailConstants.STRING_NO);
		inqStat.put("actionAutoAssignOwner", QmaMailConstants.STRING_NO);
		inqStat.put(EXT_SENDER_DOMAIN, "");
	}
}
