package com.citi.icg.qma.common.transferobject;

import java.util.List;

import com.citi.icg.qma.common.server.dao.MyUsers;

public class GridResponseTO
{
	List<MyUsers> data;
	int total;
	GridColumnsTO[] columnDefs;

	public List<MyUsers> getData()
	{
		return data;
	}

	public void setData(List<MyUsers> data)
	{
		this.data = data;
	}

	public int getTotal()
	{
		return total;
	}

	public void setTotal(int total)
	{
		this.total = total;
	}

	public GridColumnsTO[] getColumnDefs()
	{
		return columnDefs;
	}

	public void setColumnDefs(GridColumnsTO[] columnDefs)
	{
		this.columnDefs = columnDefs;
	}

}
