package com.citi.icg.qma.performance.utils.verification;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.citi.icg.qma.common.server.dao.Attachment;
import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.FollowUp;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.Note;
import com.citi.icg.qma.common.server.dao.RulesFlag;
import com.citi.icg.qma.common.server.dao.Workflow;
import com.citi.icg.qma.common.server.dao.WorkflowAudit;

public class CompareIndividualDoc {

	public static void setMatchingDetails(List<String> matchingDetails) {
		CompareIndividualDoc.matchingDetails = matchingDetails;
	}

	private static List<String> matchingDetails;
	private static boolean isPartialMatch=false;

	public static MessageComparison compare(MessageComparison messageComparison) {

		matchingDetails=new ArrayList<>();

		Inquiry newInquiry=messageComparison.getNewInquiry();
		List<Conversation> newConv = messageComparison.getNewConversation();
		Inquiry oldInquiry=messageComparison.getOldInquiry();
		List<Conversation> oldConv = messageComparison.getOldConversation();

		boolean isMismatchCase=((newConv.size()!=oldConv.size())||
				(newInquiry.getWorkflowAudit().size()!=oldInquiry.getWorkflowAudit().size())||
				(newInquiry.getWorkflows().size()!=oldInquiry.getWorkflows().size()));

		if(isMismatchCase){
			isPartialMatch=true;
		}
		boolean concurrentCase=newInquiry.getAllToCCGrps().contains("*ICG US CGMI INTL Setts")||newInquiry.getAllToCCGrps().contains("*ICG NAM Tampa Incoming Group")||newInquiry.getAllToCCGrps().contains("*CMB UK EQCLIENTSUPPORT MZ");
		
		if(concurrentCase){
			matchingDetails.add("Concurrent processing case");
		}else{
			boolean isInqSame=compareInquiry(newInquiry,oldInquiry,isMismatchCase);
			
			boolean isConvSame=compareCompareConversationLists(newConv,oldConv);
			

			boolean isCompleteMatch=isInqSame&&isConvSame;
			if(isCompleteMatch){
				if(isPartialMatch){
					messageComparison.setMatchingStatus(MessageComparison.PARTIAL_MATCH_PROD_MOVED_FORWARD);	
				}else{
					messageComparison.setMatchingStatus(MessageComparison.COMPLETE_MATCH);	
				}
			}else{
				if(isPartialMatch){
					messageComparison.setMatchingStatus(MessageComparison.FAILED_MATCH);	
				}else{
					messageComparison.setMatchingStatus(MessageComparison.FAILED_MATCH);	
				}
			}
			
		}
	


		
		messageComparison.setDetailedStatus(MessageComparison.MATCHING_DONE);
		messageComparison.setMatchingDetails(matchingDetails);

		

		return messageComparison;


	}

	private static boolean compareInquiry(Inquiry newInquiry, Inquiry oldInquiry,boolean isMismatchCase) {
		
		boolean boolval=true;
		if(!"New Inquiry".equalsIgnoreCase(oldInquiry.getAction())){
			matchingDetails.add("Inquiry skipped as prod moved forward");
			matchingDetails.add("Inquiry matching isSuccesful:"+boolval);
			return true;
			
		}

		compareWorkFlowAudits(newInquiry.getWorkflowAudit(),oldInquiry.getWorkflowAudit());
		
		compareWorkflow(newInquiry.getWorkflows(),oldInquiry.getWorkflows());
		
		boolval=compare("inquiry:allToCCGrps",newInquiry.getAllToCCGrps(),oldInquiry.getAllToCCGrps())&&boolval;
		boolval=compare("inquiry:attchFlag",newInquiry.getAttchFlag(),oldInquiry.getAttchFlag())&&boolval;
		boolval=compare("inquiry:audFlag",newInquiry.getAudFlag(),oldInquiry.getAudFlag())&&boolval;
		boolval=compare("inquiry:latestEmail",newInquiry.getLatestEmail(),oldInquiry.getLatestEmail())&&boolval;
		boolval=compare("inquiry:latestGroup",newInquiry.getLatestGroup(),oldInquiry.getLatestGroup())&&boolval;
		boolval=compare("inquiry:latestUserId",newInquiry.getLatestUserId(),oldInquiry.getLatestUserId())&&boolval;
		boolval=compare("inquiry:latestUserName",newInquiry.getLatestUserName(),oldInquiry.getLatestUserName())&&boolval;
		boolval=compare("inquiry:action",newInquiry.getAction(),oldInquiry.getAction())&&boolval;
		boolval=compare("inquiry:status",newInquiry.getStatus(),oldInquiry.getStatus())&&boolval;
		boolval=compare("inquiry:latestToCCGroups",newInquiry.getLatestToCCGroups(),oldInquiry.getLatestToCCGroups())&&boolval;
		//boolval=compare("inquiry:latestToCCUser",newInquiry.getLatestToCCUser(),oldInquiry.getLatestToCCUser())&&boolval;
		boolval=compare("inquiry:notesFlag",newInquiry.getNotesFlag(),oldInquiry.getNotesFlag())&&boolval;
		boolval=compare("inquiry:openGroups",newInquiry.getOpenGroups(),oldInquiry.getOpenGroups())&&boolval;
		//boolval=compare("inquiry:openUsers",newInquiry.getOpenUsers(),oldInquiry.getOpenUsers())&&boolval;
		boolval=compare("inquiry:origGroupName",newInquiry.getOrigGroupName(),oldInquiry.getOrigGroupName())&&boolval;
		boolval=compare("inquiry:origSubject",newInquiry.getOrigSubject(),oldInquiry.getOrigSubject())&&boolval;
		boolval=compare("inquiry:origType",newInquiry.getOrigType(),oldInquiry.getOrigType())&&boolval;
		boolval=compare("inquiry:origEmail",newInquiry.getOrigEmail(),oldInquiry.getOrigEmail())&&boolval;
		boolval=compare("inquiry:origUserId",newInquiry.getOrigUserId(),oldInquiry.getOrigUserId())&&boolval;
		boolval=compare("inquiry:origUserName",newInquiry.getOrigUserName(),oldInquiry.getOrigUserName())&&boolval;
		boolval=compare("inquiry:recallInd",newInquiry.getRecallInd(),oldInquiry.getRecallInd())&&boolval;
		boolval=compare("inquiry:subject",newInquiry.getSubject(),oldInquiry.getSubject())&&boolval;
		boolval=compare("inquiry:urgentFlag",newInquiry.getUrgentFlag(),oldInquiry.getUrgentFlag())&&boolval;
		boolval=compare("inquiry:recentConversationSnap",newInquiry.getRecentConversationSnap(),oldInquiry.getRecentConversationSnap())&&boolval;
		boolval=compare("inquiry:requestTypeStr",newInquiry.getRequestTypeStr(),oldInquiry.getRequestTypeStr())&&boolval;
		boolval=compare("inquiry:clientName",newInquiry.getClientName(),oldInquiry.getClientName())&&boolval;
		//boolval=compare("inquiry:gpNum",newInquiry.getGpNum(),oldInquiry.getGpNum())&&boolval;
		//boolval=compare("inquiry:gpName",newInquiry.getGpName(),oldInquiry.getGpName())&&boolval;
		boolval=compare("inquiry:gfcid",newInquiry.getGfcid(),oldInquiry.getGfcid())&&boolval;
		boolval=compare("inquiry:gfcName",newInquiry.getGfcName(),oldInquiry.getGfcName())&&boolval;
		                      
		boolval=compare("inquiry:latestGroupId",newInquiry.getLatestGroupId(),oldInquiry.getLatestGroupId())&&boolval;
		boolval=compare("inquiry:conversCount",newInquiry.getConversCount(),oldInquiry.getConversCount())&&boolval;
		boolval=compare("inquiry:nlpRPTCocnversationId",newInquiry.getNlpRPTCocnversationId(),oldInquiry.getNlpRPTCocnversationId())&&boolval;
		boolval=compare("inquiry:nlpRPTSuggestionId",newInquiry.getNlpRPTSuggestionId(),oldInquiry.getNlpRPTSuggestionId())&&boolval;
		boolval=compare("inquiry:origGroupId",newInquiry.getOrigGroupId(),oldInquiry.getOrigGroupId())&&boolval;
		boolval=compare("inquiry:exceptionId",newInquiry.getExceptionId(),oldInquiry.getExceptionId())&&boolval;
		                          
		boolval=compare("inquiry:nlpRPTFreeze",newInquiry.isNlpRPTFreeze(),oldInquiry.isNlpRPTFreeze())&&boolval;
		
		//compareUserNoteLists(newInquiry.getUserNotes(),oldInquiry.getUserNotes());
		
		//compareReadBy(newInquiry.getReadBy(),oldInquiry.getReadBy());
		boolval=compareApprovedExternalDomains(newInquiry.getApprovedExternalDomains(),oldInquiry.getApprovedExternalDomains())&&boolval;
		
		
		matchingDetails.add("Inquiry matching isSuccesful:"+boolval);
		
		return boolval;

	}






	private static boolean compareApprovedExternalDomains(Set<String> approvedExternalDomains,Set<String> approvedExternalDomains2) {
		if(approvedExternalDomains==null&&approvedExternalDomains2==null){
			return true;
		}
		if(approvedExternalDomains==null||approvedExternalDomains2==null){
			
			matchingDetails.add("One inquiry:approvedExternalDomains is null and other is not");
			return false;
		}
		boolean value= approvedExternalDomains.equals(approvedExternalDomains2);
		if(!value){
			
			matchingDetails.add("inquiry:approvedExternalDomains did not match");
		}
		return value;
	}




	private static boolean compareWorkflow(List<Workflow> newWorkflows, List<Workflow> oldWorkflows) {
		//System.out.println("****************WokFlow comparison start****************");
		
		Iterator<Workflow> itnew = newWorkflows.iterator();
		Iterator<Workflow> itold = oldWorkflows.iterator();
		boolean boolval=true;
		while(itnew.hasNext()){
			if(!itold.hasNext()){
				matchingDetails.add("new workflow has more elements than old");
				boolval=false;
				break;
			}
			Workflow newWf = itnew.next();
			Workflow oldWf = itold.next();

			if((!"Open".equalsIgnoreCase(newWf.getStatus()))||(!"Open".equalsIgnoreCase(oldWf.getStatus()))){
				matchingDetails.add("Workflow is not open skipping");
				continue;
			}
			

			boolval=compare("workflow:status",newWf.getStatus(),oldWf.getStatus())&&boolval;
			boolval=compare("workflow:assignedGroupId",newWf.getAssignedGroupId(),oldWf.getAssignedGroupId())&&boolval;
			boolval=compare("workflow:crtBy",newWf.getCrtBy(),oldWf.getCrtBy())&&boolval;
			boolval=compare("workflow:direction",newWf.getDirection(),oldWf.getDirection())&&boolval;
			boolval=compare("workflow:requestType",newWf.getRequestType(),oldWf.getRequestType())&&boolval;
			boolval=compare("workflow:stage",newWf.getStage(),oldWf.getStage())&&boolval;
			
			boolval=compare("workflow:assignedGroupName",newWf.getAssignedGroupName(),oldWf.getAssignedGroupName())&&boolval;
			
			boolval=compare("workflow:maker",newWf.getMaker(),oldWf.getMaker())&&boolval;
			boolval=compare("workflow:tag",newWf.getTag(),oldWf.getTag())&&boolval;
			boolval=compare("workflow:rootCause",newWf.getRootCause(),oldWf.getRootCause())&&boolval;
			boolval=compare("workflow:processingRegion",newWf.getProcessingRegion(),oldWf.getProcessingRegion())&&boolval;
			boolval=compare("workflow:queryCount",newWf.getQueryCount(),oldWf.getQueryCount())&&boolval;
			boolval=compare("workflow:prevResponseCntr",newWf.getPrevResponseCntr(),oldWf.getPrevResponseCntr())&&boolval;
			boolval=compare("workflow:convCount",newWf.getConvCount(),oldWf.getConvCount())&&boolval;
			boolval=compare("workflow:inquirySource",newWf.getInquirySource(),oldWf.getInquirySource())&&boolval;
			
			boolval=compare("workflow:clientChaseCounter",newWf.getClientChaseCounter(),oldWf.getClientChaseCounter())&&boolval;
			//TODO boolval=compare("workflow:isLastConvToExtEmail",newWf.getIsLastConvToExtEmail(),oldWf.getIsLastConvToExtEmail())&&boolval;
			boolval=compare("workflow:isConvCountEscalation",newWf.getIsConvCountEscalation(),oldWf.getIsConvCountEscalation())&&boolval;
			boolval=compare("workflow:isClientChaseEscalation",newWf.getIsClientChaseEscalation(),oldWf.getIsClientChaseEscalation())&&boolval;
			boolval=compare("workflow:isSubjectEscalation",newWf.getIsSubjectEscalation(),oldWf.getIsSubjectEscalation())&&boolval;
			boolval=compare("workflow:generalEscalationReason",newWf.getGeneralEscalationReason(),oldWf.getGeneralEscalationReason())&&boolval;
			boolval=compare("workflow:responseTimeEscalationReason",newWf.getResponseTimeEscalationReason(),oldWf.getResponseTimeEscalationReason())&&boolval;
			boolval=compare("workflow:latestClientChaseCounter",newWf.getLatestClientChaseCounter(),oldWf.getLatestClientChaseCounter())&&boolval;
			
			boolval=compare("workflow:isManualEscalation",newWf.getIsManualEscalation(),oldWf.getIsManualEscalation())&&boolval;
			boolval=compare("workflow:manualEscalationReason",newWf.getManualEscalationReason(),oldWf.getManualEscalationReason())&&boolval;
			
			boolval=compare("workflow:workflowStatus",newWf.getWorkflowStatus(),oldWf.getWorkflowStatus())&&boolval;
			
			boolval=compare("workflow:suggestionIndicator",newWf.getSuggestionIndicator(),oldWf.getSuggestionIndicator())&&boolval;
			boolval=compare("workflow:isAckEscalation",newWf.getIsAckEscalation(),oldWf.getIsAckEscalation())&&boolval;
			
			boolval=compare("workflow:isEscalation",newWf.isEscalation(),oldWf.isEscalation())&&boolval;
			boolval=compare("workflow:rulesFlag",newWf.getRulesFlag(),oldWf.getRulesFlag())&&boolval;
			boolval=compare("workflow:followUp",newWf.getFollowUp(),oldWf.getFollowUp())&&boolval;
			boolval=compare("workflow:pendingExternalDomains",newWf.getPendingExternalDomains(),oldWf.getPendingExternalDomains())&&boolval;
			
		}

		
		//System.out.println("****************WokFlow comparison done isMatch="+boolval+"****************");
		matchingDetails.add("Workflow matched isSuccessful: "+boolval);
		return boolval;

	}


	/*private static boolean compareUserNoteLists(List<Note> newUserNotes, List<Note> oldUserNotes) {
		if(newUserNotes==null&&oldUserNotes==null){
			return true;
		}
		if(newUserNotes==null||oldUserNotes==null){
			System.out.println("One oldUserNotes is null and other is not");
			matchingDetails.add("One oldUserNotes is null and other is not");
			return false;
		}
		Iterator<Note> itnew = newUserNotes.iterator();
		Iterator<Note> itold = oldUserNotes.iterator();
		boolean boolval=true;
		while(itnew.hasNext()){
			if(!itold.hasNext()){
				System.out.println("new usernote has more elements than old");
				break;
			}
			Note newNote = itnew.next();
			Note oldNote = itold.next();

			boolval=compare("inquiry:usernote",newNote.getUserId(),oldNote.getUserId());
			boolval=compare("inquiry:usernote",newNote.getUserName(),oldNote.getUserName());
			boolval=compare("inquiry:commentDate",newNote.getComments(),oldNote.getComments());
			
		}
		return boolval;	
	}
*/


	private static boolean compare(String fieldName, RulesFlag newRulesFlag, RulesFlag oldRulesFlag) {
		boolean boolval=true;
		if(newRulesFlag==null&&oldRulesFlag==null){
			return true;
		}
		if(newRulesFlag==null||oldRulesFlag==null){
			
			matchingDetails.add("One rule flag is null and other is not");
			return false;
		}
		boolval=compare("markForDeletion",newRulesFlag.getMarkForDeletion(),oldRulesFlag.getMarkForDeletion())&&boolval;
		boolval=compare("markAsNonInquiry",newRulesFlag.getMarkAsNonInquiry(),oldRulesFlag.getMarkAsNonInquiry())&&boolval;
		boolval=compare("ruleType",newRulesFlag.getRuleType(),oldRulesFlag.getRuleType())&&boolval;
		return boolval;
	}



	private static boolean compare(String fieldName, FollowUp followUp, FollowUp followUp2) {
		if(followUp==null&&followUp2==null){
			return true;
		}
		if(followUp==null||followUp2==null){
			
			matchingDetails.add("One followUp is null and other is not");
			return false;
		}
		return compare(fieldName,followUp.getFlag(),followUp2.getFlag());
	}



	private static boolean compare(String fieldName, Set<String> pendingExternalDomains,Set<String> pendingExternalDomains2) {
		if(pendingExternalDomains==null&&pendingExternalDomains2==null){
			return true;
		}
		if(pendingExternalDomains==null||pendingExternalDomains2==null){
			
			matchingDetails.add("One pendingExternalDomains is null and other is not");
			return false;
		}
		return pendingExternalDomains.equals(pendingExternalDomains2);
	}



	private static boolean compareWorkFlowAudits(List<WorkflowAudit> newWorkflowAudit, List<WorkflowAudit> oldWorkflowAudit) {
		
		 boolean boolval=true;
		 newWorkflowAudit.removeIf(wfA->"SYSTEM".equalsIgnoreCase(wfA.getAction()));
		 oldWorkflowAudit.removeIf(wfA->"SYSTEM".equalsIgnoreCase(wfA.getAction()));
		 oldWorkflowAudit.removeIf(wfA->"Assign Owner (Auto)".equalsIgnoreCase(wfA.getAction()));
		 newWorkflowAudit.removeIf(wfA->"Assign Owner (Auto)".equalsIgnoreCase(wfA.getAction()));
		 oldWorkflowAudit.removeIf(wfA->"Assign Owner".equalsIgnoreCase(wfA.getAction()));
		 newWorkflowAudit.removeIf(wfA->"Assign Owner".equalsIgnoreCase(wfA.getAction()));
		 Comparator<WorkflowAudit> wfAComparatorAction=new Comparator<WorkflowAudit>() {

			@Override
			public int compare(WorkflowAudit o1, WorkflowAudit o2) {
				int val = o1.getAction().compareTo(o2.getAction());
				if(val==0)val=o1.getActionDetails().compareTo(o2.getActionDetails());
				return val;
			}
		};
		 
		oldWorkflowAudit.sort(wfAComparatorAction);
		newWorkflowAudit.sort(wfAComparatorAction);
		 Iterator<WorkflowAudit> itnew = newWorkflowAudit.iterator();
		 Iterator<WorkflowAudit> itold = oldWorkflowAudit.iterator();
		 while(itnew.hasNext()){
				
			 if(!itold.hasNext()){
				
				matchingDetails.add("new workflow audit has more elements than old");
				boolval=false;
				break;
			 }
		
			 WorkflowAudit oldAudit = itold.next();
			 WorkflowAudit newAudit = itnew.next();
			
			 //boolval=compare("workflowAudit:userId",newAudit.getUserId(),oldAudit.getUserId())&&boolval;
			 boolval=compare("workflowAudit:groupId",newAudit.getGroupId(),oldAudit.getGroupId())&&boolval;
			 boolval=compare("workflowAudit:action",newAudit.getAction(),oldAudit.getAction())&&boolval;
			 boolval=compare("workflowAudit:actionDetails",newAudit.getActionDetails(),oldAudit.getActionDetails())&&boolval;
			 //boolval=compare("workflowAudit:modBy",newAudit.getModBy(),oldAudit.getModBy())&&boolval;
			
			 boolval=compare("workflowAudit:groupName",newAudit.getGroupName(),oldAudit.getGroupName())&&boolval;
			
			 boolval=compare("workflowAudit:responseTimeEscalationReason",newAudit.getResponseTimeEscalationReason(),oldAudit.getResponseTimeEscalationReason())&&boolval;
			 boolval=compare("workflowAudit:responseTimeEscalationFlag",newAudit.getResponseTimeEscalationFlag(),oldAudit.getResponseTimeEscalationFlag())&&boolval;
			 boolval=compare("workflowAudit:ispendingApprovalEscalation",newAudit.getIspendingApprovalEscalation(),oldAudit.getIspendingApprovalEscalation())&&boolval;
			 boolval=compare("workflowAudit:isConvCountEscalation",newAudit.getIsConvCountEscalation(),oldAudit.getIsConvCountEscalation())&&boolval;
			 boolval=compare("workflowAudit:isClientChaseEscalation",newAudit.getIsClientChaseEscalation(),oldAudit.getIsClientChaseEscalation())&&boolval;
			 boolval=compare("workflowAudit:isSubjectEscalation",newAudit.getIsSubjectEscalation(),oldAudit.getIsSubjectEscalation())&&boolval;
			 boolval=compare("workflowAudit:generalEscalationReason",newAudit.getGeneralEscalationReason(),oldAudit.getGeneralEscalationReason())&&boolval;
			
			
		 }
			
	
		matchingDetails.add("WorkFlow audit matching isSuccesful:"+boolval);
		return boolval;
	}

	private static boolean compareCompareConversationLists(List<Conversation> convNewList, List<Conversation> convOldList){
		Iterator<Conversation> itnew = convNewList.iterator();
		Iterator<Conversation> itold = convOldList.iterator();
		boolean boolval=true;
		while(itnew.hasNext()){
			if(!itold.hasNext()){
				
				break;
			}
			Conversation newAt = itnew.next();
			Conversation oldAt = itold.next();
			
			boolval=compareCompareConversation(newAt, oldAt);
			
		}
		 matchingDetails.add("Conversation matching isSuccesful:"+boolval);
		return boolval;
	}

	private static boolean compareCompareConversation(Conversation conv1, Conversation conv2) {

		boolean boolval=true;
		if(!"New Inquiry".equalsIgnoreCase(conv2.getAction())){
			matchingDetails.add("Conversation not new inquiry , skipping as prod moved forward");
			return true;
		}
//		if(conv1.getContent()!=null&&(!conv1.getContent().contains("imageBrowser")||!conv1.getContent().contains("urldefense"))){//
//			boolval=compare("conversation:content",conv1.getContent(),conv2.getContent())&&boolval;	
//		}
		boolval=compare("conversation:action",conv1.getAction(),conv2.getAction())&&boolval;
		
		boolval=compare("conversation:subject",conv1.getSubject(),conv2.getSubject())&&boolval;
		//boolval=compare("conversation:audFlag",conv1.getAudFlag(),conv2.getAudFlag())&&boolval;
		
		boolval=compare("conversation:urgentFlag",conv1.getUrgentFlag(),conv2.getUrgentFlag())&&boolval;
		boolval=compare("conversation:approvalBypassed",conv1.getApprovalBypassed(),conv2.getApprovalBypassed())&&boolval;
		boolval=compare("conversation:inActive",conv1.getInActive(),conv2.getInActive())&&boolval;
		

		//boolval=compareRecipients(conv1.getRecipients(),conv2.getRecipients())&&boolval;
		boolval=compareAttachments(conv1.getAttachments(),conv2.getAttachments())&&boolval;
		return boolval;
	}

	private static boolean compareAttachments(List<Attachment> attachmentsNew, List<Attachment> attachmentsOld) {
		if(attachmentsNew==null&&attachmentsOld==null){
			return true;
		}
		if(attachmentsNew==null||attachmentsOld==null){
			matchingDetails.add("One attachments is null and other is not");
			return false;
		}
		Iterator<Attachment> itnew = attachmentsNew.iterator();
		Iterator<Attachment> itold = attachmentsOld.iterator();
		boolean boolval=true;
		while(itnew.hasNext()){
			if(!itold.hasNext()){
				matchingDetails.add("new Attachment has more elements than old");
				break;
			}
			Attachment newAt = itnew.next();
			Attachment oldAt = itold.next();
			boolval=compare("conversation:Attachment:name",newAt.getName(),oldAt.getName())&&boolval;
			boolval=compare("conversation:Attachment:secure",newAt.getSecure(),oldAt.getSecure())&&boolval;
			boolval=compare("conversation:Attachment:fileInfo",newAt.getFileInfo(),oldAt.getFileInfo())&&boolval;
			boolval=compare("conversation:Attachment:isSecuredByQMA",newAt.getIsSecuredByQMA(),oldAt.getIsSecuredByQMA())&&boolval;
			
		}
		return boolval;
	}
	
	private static boolean compareRecipients(List<ConversationRecipient> recipientsNew,List<ConversationRecipient> recipientsOld) {
		if(recipientsNew==null&&recipientsOld==null){
			return true;
		}
		if(recipientsNew==null||recipientsOld==null){
						matchingDetails.add("One recipients is null and other is not");
			return false;
		}
		Iterator<ConversationRecipient> itnew = recipientsNew.iterator();
		Iterator<ConversationRecipient> itold = recipientsOld.iterator();
		boolean boolval=true;
		while(itnew.hasNext()){
			if(!itold.hasNext()){
				
				break;
			}
			ConversationRecipient newCr = itnew.next();
			ConversationRecipient oldCr = itold.next();
			boolval=compare("ConversationRecipient:emailAddr",newCr.getEmailAddr(),oldCr.getEmailAddr())&&boolval;
			boolval=compare("ConversationRecipient:displayName",newCr.getDisplayName(),oldCr.getDisplayName())&&boolval;
			boolval=compare("ConversationRecipient:toFrom",newCr.getToFrom(),oldCr.getToFrom())&&boolval;
			
		}
		return boolval;
	}



	public static boolean compare(String fieldName, Integer newVal, Integer oldVal) {
		if(oldVal==null&&newVal==null){
			return true;
		}
		if(oldVal==null||newVal==null){
			
			matchingDetails.add("one value was null and other wasnt fieldName: "+fieldName);
			return false;
		}
		if(!oldVal.equals(newVal)){
			
			matchingDetails.add("Not Matched: "+fieldName+"NewValue: "+newVal+"OldValue: "+oldVal);
			return false;
		}
		return true;
	}



	public static boolean compare(String fieldName, Boolean newVal, Boolean oldVal) {
		if(oldVal==null&&newVal==null){
			return true;
		}
		if(oldVal==null||newVal==null){
			
			matchingDetails.add("one value was null and other wasnt fieldName: "+fieldName);
			return false;
		}
		if(!oldVal.equals(newVal)){
			
			matchingDetails.add("Not Matched: "+fieldName+"NewValue: "+newVal+"OldValue: "+oldVal);
			return false;
		}
		return true;
		
	}



	public static boolean compare(String fieldName,String newVal, String oldVal){
		if(oldVal==null&&newVal==null){
			return true;
		}
		if(oldVal==null||newVal==null){
			
			matchingDetails.add("one value was null and other wasnt fieldName: "+fieldName);
			return false;
		}
		if(!oldVal.equalsIgnoreCase(newVal)){
			
			matchingDetails.add("Not Matched: "+fieldName+" NewValue: "+newVal.substring(0, Math.min(20, newVal.length()))+" OldValue: "+oldVal.substring(0, Math.min(20, oldVal.length())));
			return false;
		}
		return true;
		
	}
	
	public static boolean compare(String fieldName,Long newVal, Long oldVal){
		if(oldVal==null&&newVal==null){
			return true;
		}
		if(oldVal==null||newVal==null){
			
			matchingDetails.add("one value was null and other wasnt fieldName: "+fieldName);
			return false;
		}
		if(!oldVal.equals(newVal)){
			
			matchingDetails.add("Not Matched: "+fieldName+"NewValue: "+newVal+"OldValue: "+oldVal);
			return false;
		}
		return true;
	}
	
}
