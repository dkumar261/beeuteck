package com.citi.icg.qma.common.server.dao.persistence;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.ResponseBuilder;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.bson.types.ObjectId;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.core.util.DateUtil;
import com.citi.icg.qma.common.core.util.EncryptionDecryptionUtil;
import com.citi.icg.qma.common.core.util.MailUtil;
import com.citi.icg.qma.common.core.util.NLPConstants;
import com.citi.icg.qma.common.core.util.QmaMailConstants;
import com.citi.icg.qma.common.server.dao.ClientCategory;
import com.citi.icg.qma.common.server.dao.ColumnDef;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.CustomColumnsView;
import com.citi.icg.qma.common.server.dao.ExchangeFolder;
import com.citi.icg.qma.common.server.dao.FavoriteContact;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.GroupRole;
import com.citi.icg.qma.common.server.dao.HierarchyOrgDetails;
import com.citi.icg.qma.common.server.dao.HierarchyUserDetail;
import com.citi.icg.qma.common.server.dao.HighlevelRequestType;
import com.citi.icg.qma.common.server.dao.HolidayMaster;
import com.citi.icg.qma.common.server.dao.KeyValue;
import com.citi.icg.qma.common.server.dao.MailBoxDLMapping;
import com.citi.icg.qma.common.server.dao.ManagementHeirarchy;
import com.citi.icg.qma.common.server.dao.OrgMetaDataAdminRole;
import com.citi.icg.qma.common.server.dao.OrgPreferences;
import com.citi.icg.qma.common.server.dao.Organization;
import com.citi.icg.qma.common.server.dao.Preference;
import com.citi.icg.qma.common.server.dao.Signature;
import com.citi.icg.qma.common.server.dao.StaticData;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.UserAdminAudit;
import com.citi.icg.qma.common.server.dao.UserSearchData;
import com.citi.icg.qma.common.server.dao.ViewConfig;
import com.citi.icg.qma.common.server.dao.ViewFilters;
import com.citi.icg.qma.common.server.dao.util.OracleDBAuthKey;
import com.citi.icg.qma.common.server.util.DedicatedReaderUtility;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.common.server.util.GlobalDirectoryService;
import com.citi.icg.qma.common.transferobject.CorporateAddressBookTO;
import com.citi.icg.qma.common.transferobject.GroupRoleTO;
import com.citi.icg.qma.common.transferobject.Template;
import com.citi.icg.qma.common.transferobject.UserContextTO;
import com.citi.icg.qma.common.transferobject.UserGroupTO;
import com.citi.icg.qma.common.transferobject.UserTO;
import com.citi.icg.qma.common.transferobject.ViewTO;
import com.citi.icg.qma.hazelcast.cache.client.HazelCastCacheIncrementalLoad;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;

import dev.morphia.Key;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;
import com.citi.icg.qma.common.server.dao.TaskizeAccessToken;
import com.citi.icg.qma.common.server.dao.TaskizeParticipantsContactMapping;


public class UserDAO extends MongoMorphiaDAO
{
	private static final String DEFAULT_VIEW_PERFORMANCE_CONFIG = "defaultViewPerformanceConfig";
	private static final String MOD_DATE = "modDate";
	private static final String ID = "id";
	private static final String CRT_DATE = "crtDate";
	private static final String SEARCH_KEY_ID = "searchKeyId";
	private static final String USER_FEEDBACK = "userFeedback";
	private static final String DATA = "data";
	private static final String SEARCH_KEYWORD = "solrSearchText";
	private static final String HIGH_LEVEL_REQ_TYPE_GENERAL_QUERY = "General Query";
	private static final String PERSONAL_EMAIL_REQUEST_TYPE = "Personal Email";
	private static final String COL_ID = "colId";
	private static final String HEADER_NAME = "headerName";
	private static final String DISABLE_USER_ORG_DISPLAY = "disableUserOrgDisplay";
	private static final String MIS_REPORTS = "MISReports";
	private static final String QMA_UI2_CONFIG_KEY = "qmaUI2Config";
	private static final Logger subLogger = LoggerFactory.getLogger(UserDAO.class);
	private static GroupDAO groupDAO = new GroupDAO();
	//private CacheDAO cacheDAO = CacheDAO.getInstance();
	private static AddressBookDAO addressBookDAO = new AddressBookDAO();
	//As per Discussion with Sunil, Below Map will maintain User Details and refreshed with getUserInfo() call(Browser refresh
	//This can be used for any User Details needed at the server side.
	private static Map<String,UserTO> userProfileMap = new HashMap<String,UserTO>();
	private GenericDAO genricDAO = new GenericDAO();

	/*Sonar Fix : define a constant instead of duplicating the literal*/
	public static final String VIEWS = "views";
	public static final String USERID = "userId";
	public static final String OUT_OF_OFFICE = "outOfOffice";
	public static final String FAVORITES = "favorites";
	public static final String EMAIL = "email";
	public static final String CREATED_BY = "createdBy";
	public static final String CONTACT_PH_NO = "contactPhNumber";
	public static final String ACTIVE = "active";
	public static final String SEND_SECURE_EMAIL = "sendSecureEmail";
	public static final String FIT_TO_MY_RESOLUTION = "fitToMyResolution";
	public static final String REGEX_KEY_PATTERN = "$regex";
	public static final String DISABLE_AUTO_COMPLETE = "disableAutoComplete";
	public static final String ATTACHMENT_PWD_PROTECTION_FLAG = "attachmentPwdProtectionFlag";
	public static final String ADMIN_ROLE = "adminRole";
	private static final String REMOVE_LOGIN_KEY = "RemoveLogin";
	private static final String GROUP_ROLES = "groupRoles";
	private static final String ADMIN_ROLES = "adminRoles";
	
	public static final String ISA_EDITUSER = "ISA EditUser";
	public static final String ISA_USER_DISABLED = "ISA User Disabled";
	public static final String ISA_USER_ENABLED = "ISA User Enabled";
	public static final String CREATE_ACTION = "ISA NewUser";
	
	public static final String ACCESS  = "Access";
	public static final String ENTITLEMENT_CHANGED  = "Entitlement Changed";
	//public static final String ACTIVATED = "Updated active flag";
	public static final String USER_ENABLED = "User Enabled";
	public static final String USER_DISABLED = "User Disabled";
	public static final String NEW_USER_ADDED = "New User Added";
	public static final String USER_ADDED = "User Added";
	
	private static final String USER_VALIDATION_REASON_KEY = "reason";
	private static final String USER_VALIDATION_STATUS_KEY = "status";
	private static final String USER_VALIDATION_NAME_KEY = "name";
	private static final String VALIDATION_KEY = "validation";
	private static final String USER_ID_LIST_KEY = "userIdList";
	
	public  static final GenericDAO genericDAO = new GenericDAO();
	private static final String MY_COVERAGE = "myCoverage";
	private static final String VIEW_FILTERS = "viewFilters";
	private static final String VIEW_NAME = "viewName";
	private static final String FILTER_NAME = "filterName";
	private static final String FILETR_PARAMS = "filterParams";
	private static final String COLUMN_CONFIG = "columnConfig";
	private static final String CUSTOM_COLUMNS_FOR_DEFAULT_VIEWS = "customColumnsForDefaultViews";
	private static final String FROM_DATE_KEY = "fromDate";
	private static final String TO_DATE_KEY = "toDate";
	private static final String MY_VIEWS = "myViews";
	private static final String MAILBOX_STATS_KEY = "mailBoxStats";
	private static final String TASKIZE_ENABLED = "taskizeEnabled";
	
	private static final String NOTIFICATIONS = "notifications";
	private static final String NOTIFICATION_SETTINGS = "notificationSettings";
	private static final String PREFERENCES = "preferences";
	
	private static final String CV_STREAMING_TOKEN_URL_KEY = "cvStreamingTokenURL";
	private static final String QMA_WEB_SOCKET_END_POINT_KEY = "qmaWebSocketEndPoint";
	private static final String CV_WEBSOCKET_UPDATE_ENABLED_KEY = "isCVWebSocketUpdateEnabled";
	private static final String CV_WEBSOCKET_UPDATE_ENABLED_FOR_QMA1_KEY = "isCVWebSocketUpdateEnabledForQMA1";
	private static final String CV_WEBSOCKET_CONFIG_KEY = "cvWebsocketConfig";
	
	private static final InquiryDAO inquiryDAO = new InquiryDAO();
	private static final AuditTrailDAO audit = new AuditTrailDAO();
	private static final String DATA_COPY_ORACLE = "oracle";
	private static final String DATA_COPY_NETEZZA = "netezza";
	private static final DedicatedReaderUtility readerUtil = DedicatedReaderUtility.getInstance();
	private EncryptionDecryptionUtil encryptDecryptUtil = new EncryptionDecryptionUtil();
	private static final String MONGO_UTC_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"; 
	private static final String QMA_AUTHORIZATION = "QMAAuthorization";
	private static final String TRUE = "true";
	private static final String QMA = "qma";
	private static final String X_CITIPORTAL_LOGINID = "XXXXX";
	private static final String TOKEN_END_POINT = "tokenEndPoint";
	private static final String SMART_CATEGORY_META_DATA_SYNC_END_POINT = "smartCategoryMetaDataSyncEndPoint";
	
	// C170665-4814
	private static final String USER_GROUP_ROLE_STANDARD_USER = "Standard User";
	private static final String USER_GROUP_ROLE_ANALYST = "Analyst";


	public static final String GROUP_NAME_FIELD = "groupName";
	public User getUserById(String soeId) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		return getUserById(soeId,false);
	}

	public User getActiveUserById(String soeId) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		return getUserById(soeId,true);
	}

	private User getUserById(String soeId,boolean activeUserOnly) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Query<User> query = null;
		User user = null;
		try
		{
			query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
			if(activeUserOnly){
				query.filter(ACTIVE, true);
			}
			user = query.get();
			if (user == null)
			{
				subLogger.error("No Active User data found for userId=" + soeId);
				throw new CommunicatorException("Invalid UserId input="+soeId+". Pl"
						+ "ease contact support.");
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getUserById for  user=" + soeId , e);
			throw new CommunicatorException("Exception in getUserById for  user=" + soeId);
		}
		
		return user;
	}
	
	/**
	 * This method is used to retrieve the user by passing email id to it.
	 * @param emailID
	 * @param activeUserOnly
	 * @return
	 * @throws CommunicatorException
	 */
	private User getUserByEmailId(String emailID,boolean activeUserOnly) throws CommunicatorException
	{
		Query<User> query = null;
		User user = null;
		try
		{
			query = mongoDatastore.createQuery(User.class).filter("email", emailID);
			if(activeUserOnly){
				query.filter(ACTIVE, true);
			}
			user = query.get();
			if (user == null)
			{
				subLogger.error("No Active User data found for mailid =" + emailID);
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getUserByEmailId for  user=" + emailID , e);
			throw new CommunicatorException("Exception in getUserByEmailId for  user=" + emailID);
		}
		
		return user;
	}
	
	/**
	 * This method finds user with multiple citi domain email address
	 * @param emailIDList
	 * @param activeUserOnly
	 * @return
	 * @throws CommunicatorException
	 */
	private User findUserByMultipleCitiDomains(List<String> emailIDList,boolean activeUserOnly) throws CommunicatorException
	{
		Query<User> query = null;
		User user = null;
		try
		{
			query = mongoDatastore.createQuery(User.class).field("email").in(emailIDList);
			if(activeUserOnly){
				query.filter(ACTIVE, true);
			}
			user = query.get();
			if (user == null)
			{
				subLogger.error("No Active User data found for multiple email address provided =" + emailIDList);
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in findUserByMultipleCitiDomains for  multiple emaild ids for user =" + emailIDList , e);
			throw new CommunicatorException("Exception in findUserByMultipleCitiDomains for  multiple emaild ids for user =" + emailIDList);
		}
		
		return user;
	}
	

	public ViewConfig getUserView(String userId, String viewName)
	{
		subLogger.debug("Inside UserDAO.getUserView-userId=" + userId + " , viewName=" + viewName);
		ViewConfig viewConfig = null;
		Query<User> query = null;
		User user = null;
		try
		{
			query = mongoDatastore.createQuery(User.class).filter("_id", userId);
					//.filter("views.viewName", viewName);
			user = query.get();
			if (user!=null && user.getViews() != null)
			{
				// get the existing criteria
				for (ViewConfig object : user.getViews())
				{
					if (viewName.equals(object.getViewName()))
					{
						viewConfig = object;
						break;
					}
				}
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getUserView for  user=" + userId + " , viewName=" + viewName, e);
			throw e;
		}
		return viewConfig;
	}
	///[C153176-160] changes for saved search with work flow Criteria query
	public boolean saveUserView(String userId, String viewName, String criteria, List<ColumnDef> columnsToShow, List<ColumnDef> orderByColumns,String defaultCriteria) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.debug("Inside UserDAO.saveView for user=" + userId + " with viewName=" + viewName + "[criteria : " + criteria + " ]");
		/*[C153176-1234]-Provide special character support in QMA saved search criteria*/
		String newCriteria = validateSpecialChars(criteria);
		String updatedCriteria = getUpdatedCriteria(BasicDBObject.parse(newCriteria));
		ViewConfig viewConfig = null;
		UpdateOperations<User> ops = null;
		Query<User> query = null;
		User userObj = null;
		String viewNamePassed = viewName;// Sonar Fix -- Method parameters, caught exceptions and foreach variables should not be reassigned
		//Avoid Extra Spaces in the View Name
		viewNamePassed=viewNamePassed!=null?viewNamePassed.trim():viewNamePassed;
		if (StringUtils.isBlank(userId) || StringUtils.isBlank(viewNamePassed))
		{
			subLogger.debug("Invalid input for saveUserView for user=" + userId + " with viewName=" + viewNamePassed);
			throw new CommunicatorException("Invalid input for saveUserView.");
		}
		try
		{
			query = mongoDatastore.createQuery(User.class).filter("_id", userId);
			userObj = query.get();
			if (userObj != null && userObj.getViews() != null)
			{
				// get the existing criteria
				for (ViewConfig object : userObj.getViews())
				{
					if (viewNamePassed.equals(object.getViewName()))
					{
						viewConfig = object;
						break;
					}
				}
			}

			if (viewConfig != null)
			{
				// updated the criteria
				viewConfig.setCriteria(updatedCriteria);
				viewConfig.setDefaultCriteria(defaultCriteria);

				// update columnsToShow
				viewConfig.setColumnsToShow(columnsToShow);

				// update orderByColumns
				viewConfig.setOrderByColumns(orderByColumns);

				// set back the views list
				ops = mongoDatastore.createUpdateOperations(User.class).set(VIEWS, userObj.getViews());
				mongoDatastore.update(query, ops);
			}
			else
			{
				// create new View
				viewConfig = new ViewConfig();
				viewConfig.setViewName(viewNamePassed);
				viewConfig.setCriteria(updatedCriteria);
				viewConfig.setDefaultCriteria(defaultCriteria);
				viewConfig.setColumnsToShow(columnsToShow);
				viewConfig.setOrderByColumns(orderByColumns);

				// add the criteria
				
				//added below code to handle if views is null in db after deleting all views 
				List<ViewConfig> views = null;
				if(null != userObj){
					views = userObj.getViews();
				}
				if(null == views){
					views = new ArrayList<>();
				}
						
				views.add(viewConfig);
				ops = mongoDatastore.createUpdateOperations(User.class).set(VIEWS, views);
				mongoDatastore.update(query, ops);
			}

			subLogger.info("View Saved sucessfully-" + viewNamePassed + " for " + userId);
		}
		catch (Exception e)
		{
			subLogger.error("Generic Exception in saveUserView for  user=" + userId + " , viewName=" + viewNamePassed, e);
			throw e;
		}
		return Boolean.TRUE;
	}
	/**
	 * This method return full date for given date criteria
	 * @param newCriteria
	 * @return
	 */
	private String getUpdatedCriteria(DBObject newCriteria) {
		DBObject jsonObj = newCriteria;
		try {
			for (Object key : jsonObj.keySet()) {
				String keyStr = (String) key;
				Object keyvalue = jsonObj.get(keyStr);
				if (!StringUtils.isBlank(keyStr) && (keyStr.contains(CRT_DATE) || keyStr.contains(MOD_DATE)
						|| keyStr.contains("resolveTime") || keyStr.contains("lastActionTime")
						|| keyStr.contains("reAgeDate") || keyStr.contains("reOpenDate"))) {
					DBObject dateObject = (DBObject) keyvalue;
					for (String dateKey : dateObject.keySet()) {
						if ("$lte".equals(dateKey) || "$gte".equals(dateKey) || "$lt".equals(dateKey) || "$gt".equals(dateKey)) {						
							Date dt = null;
							SimpleDateFormat simpleDateFormat = new SimpleDateFormat(MONGO_UTC_FORMAT);
							simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
							dt = simpleDateFormat.parse((String) dateObject.get(dateKey));	
							Calendar c = Calendar.getInstance();
							simpleDateFormat.setTimeZone(c.getTimeZone());
							if(c.getTimeZone().inDaylightTime(dt)) {
								Long updatedTime = dt.getTime() + c.getTimeZone().getDSTSavings();
								c.setTimeInMillis(updatedTime);
							}else {
								c.setTime(dt);
							}
							dt = c.getTime();
							String dtString = simpleDateFormat.format(dt); 
							dateObject.put(dateKey, dtString);
							
						} else if ("$nin".equals(dateKey)) {
							dateObject.put(dateKey, dateObject.get(dateKey));
						}
					}
					jsonObj.put(keyStr, dateObject);
				}
				if (keyvalue instanceof DBObject object)
					getUpdatedCriteria(object);
			}
		} catch (Exception e) {
			subLogger.error("Exception while getting updated full day date:",e);
		}
		return jsonObj.toString();
	}

	
	/**
	 * This method accepts criteria string for processing and validate 
	 * whether processing required or not.
	 * @param criteria
	 * @return String
	 */
	private String validateSpecialChars(String criteria) {
		String processedCriteria = criteria;
		try {
			if(processedCriteria.contains(REGEX_KEY_PATTERN)){
				JSONObject escCriteria = new JSONObject(processedCriteria);
				escapeSpecialChars(escCriteria);
				processedCriteria = escCriteria.toString();
			}
		} catch (Exception e) {
			subLogger.error("Exception while validating special characters from criteria in UserDAO#validateSpecialChars() : " + e.getMessage());
			subLogger.error("Error:"+e);
			processedCriteria = criteria;
		}
		return processedCriteria;
	}
	
	/**
	 * This method accepts input criteria JSON and escapes special characters
	 * in the value fields 
	 * @param inputCriteria
	 */
	private void escapeSpecialChars(JSONObject inputCriteria) {
		JSONObject criteriaJobj;
		try {
			criteriaJobj = inputCriteria;
			Iterator<?> keys = criteriaJobj.keys();
			while(keys.hasNext()){
				String currentKey = (String) keys.next();
				if( currentKey != null && criteriaJobj.get(currentKey)!=null){
					processCriteriaJson(currentKey,criteriaJobj);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception while escaping special characters from criteria in UserDAO#escapeSpecialChars() : " + e.getMessage());
			throw e;
		}
	}
	
	/**
	 * This method processes input criteria JSON 
	 * @param currentKey
	 * @param criteriaJobj
	 */
	private void processCriteriaJson(String currentKey, JSONObject criteriaJobj) {
		try {
			if(criteriaJobj.get(currentKey) instanceof JSONObject ){
				JSONObject currentJsonObj = (JSONObject)criteriaJobj.get(currentKey);
				escapeSpecialChars(currentJsonObj);
			} else if(criteriaJobj.get(currentKey) instanceof JSONArray ){
				escapeSpecialCharsInJsonArr((JSONArray)criteriaJobj.get(currentKey));
			} else if(criteriaJobj.get(currentKey) instanceof String && REGEX_KEY_PATTERN.equalsIgnoreCase(currentKey) ){
				String fieldValue = criteriaJobj.getString(currentKey);
				fieldValue = escapeCharacters(fieldValue);
				criteriaJobj.put(currentKey, fieldValue);
			}
		} catch (Exception e) {
			subLogger.error("Exception while processing input json in UserDAO#processCriteriaJson() : " + e.getMessage());
			throw e;
		}
	}

	/**
	 * This method accepts input criteria JSON array and escapes special characters
	 * in the value fields 
	 * @param jsonArr
	 */
	private void escapeSpecialCharsInJsonArr(JSONArray jsonArr) {
		JSONArray inputJsonArr;
		try {
			inputJsonArr = jsonArr;
			for(int i = 0 ; i < inputJsonArr.length(); i++){
				if(inputJsonArr.get(i) != null && inputJsonArr.get(i) instanceof JSONObject ){
					JSONObject currentObj = (JSONObject) inputJsonArr.get(i);
					escapeSpecialChars(currentObj);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception while escaping special characters from criteria in UserDAO#escapeSpecialCharsInJsonArr() : " + e.getMessage());
			throw e;
		}
	}
	
	/**
	 * This method accepts string and escapes all the special 
	 * characters 
	 * @param inputString
	 * @return
	 */
	private String escapeCharacters(String inputString){
		String escapedString = inputString;
		try {
			escapedString = escapedString.replaceAll("\\*", "\\\\*");
			escapedString = escapedString.replaceAll("\\(", "\\\\(");
			escapedString = escapedString.replaceAll("\\)", "\\\\)");
		} catch (Exception e) {
			subLogger.error("Exception while escaping special characters from criteria in UserDAO#escapeCharacters() : " + e.getMessage());
			throw e;
		}
		return escapedString;
	}

	public boolean deleteUserView(String userId, String viewName) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("Inside UserDao.deleteUserView for userId=" + userId + " ,viewName=" + viewName);
		ViewConfig viewConfig = null;
		UpdateOperations<User> ops = null;
		Query<User> query = null;
		User userObj = null;
		boolean deleteStatus = false;
		if (StringUtils.isBlank(userId) || StringUtils.isBlank(viewName))
		{
			subLogger.error("Invalid input for deleteUserView for user=" + userId + " with viewName=" + viewName);
			throw new CommunicatorException("Invalid input for deleteUserView.");
		}
		try
		{
			query = mongoDatastore.createQuery(User.class).filter("_id", userId);
			userObj = query.get();

			if (userObj != null && userObj.getViews() != null)
			{
				// get the existing criteria
				for (ViewConfig object : userObj.getViews())
				{
					if (viewName.equals(object.getViewName()))
					{
						viewConfig = object;
						break;
					}
				}
			}

			if (viewConfig != null)
			{
				userObj.getViews().remove(viewConfig);
				ops = mongoDatastore.createUpdateOperations(User.class);
				if(userObj.getViews().size()==0){
					ops = ops.unset(VIEWS);
				} else {
					ops = ops.set(VIEWS, userObj.getViews());
				}
				
				if(null != userObj.getDashboardSettings()){
					deleteViewFromDashBoardSetting(userObj,viewConfig);
					ops = ops.set("dashboardSettings", userObj.getDashboardSettings());
				} 
				
				mongoDatastore.update(query, ops);
				deleteStatus = true;
			}

			subLogger.info("Delete User view Success [" + deleteStatus + "] for userId=" + userId + " ,viewName=" + viewName);

			return deleteStatus;
		}
		catch (Exception e)
		{
			subLogger.error("Generic Exception in deleteUserView for  user=" + userId + " , viewName=" + viewName, e);
			throw e;
		}
	}

	private void deleteViewFromDashBoardSetting(User userObj, ViewConfig viewConfig) {
		try{
			if(null != userObj && null != userObj.getDashboardSettings())
			{
				BasicDBObject mailStats = (BasicDBObject) userObj.getDashboardSettings().get(MAILBOX_STATS_KEY);
				if(null != mailStats && null !=  mailStats.get(MY_VIEWS)){
					BasicDBList myViewsListRemove = new BasicDBList();
					myViewsListRemove.add(viewConfig.getViewName());
					BasicDBList myViewsList = (BasicDBList) mailStats.get(MY_VIEWS);
					myViewsList.removeAll(myViewsListRemove);
					mailStats.put(MY_VIEWS,myViewsList);
					Map<String, Object> updatedDashBoard = userObj.getDashboardSettings();
					updatedDashBoard.put(MAILBOX_STATS_KEY, mailStats);
					userObj.setDashboardSettings(updatedDashBoard);
				}
			}
		}catch(Exception e)
		{
			subLogger.error("Exception while delete myView from dashboard settings:",e);
		}
	}

	public boolean saveUserFavorites(String soeId, BasicDBObject inputJsonObjs) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("Inside UserDao.saveUserFavorites for userId=" + soeId);
		List<FavoriteContact> favCnts = new ArrayList<FavoriteContact>();
		//List<FavoriteContact> sharedFavConts = new ArrayList<FavoriteContact>();
		Map<Long, BasicDBList> groupIdContactListMapListMap =  new HashMap<>();
		//Get Configurations from DB always instead of cache
		//Static Data Collection fetches only 1 record from Secondary DB
		//StaticData staticData=genricDAO.getStaticData(subLogger);

		UpdateOperations<User> ops = null;
		Query<User> query = null;
		try
		{
			Date currentDate = new Date();
			String name = null;
			String email = null;
			String mapToGroupsName="";
			String sharedToGroupsName="";
			String createdBy=null;
			///[C153176-410] top contacts change to pop up window with additional information
			String contactAddress=null;
			String contactNote=null;
			String contactPhNumber="";
			//List<Long> userGrpIds= null;
			BasicDBList userFavoriteList=null;
			List<Long> groupIds=null;
			//if( "Y".equals(staticData.getEnableGrpBasedTopContact()))
		//	{
			userFavoriteList= (BasicDBList) inputJsonObjs.get("updateContactList");
			groupIds=GenericUtility.getIdListFromRequest(inputJsonObjs, "userGroupIdList");
			//}
			/*else
			{
				userFavoriteList= (BasicDBList) inputJsonObjs.get("updateContactList");
			}*/
			for (Object obj : userFavoriteList)
			{
				DBObject favObj = (DBObject) obj;
				name = (String) favObj.get(USER_VALIDATION_NAME_KEY);
				email = (String) favObj.get(EMAIL);
				mapToGroupsName=(String) favObj.get("mapToGroupsName");
				sharedToGroupsName=(String) favObj.get("sharedToGroupsName");
				createdBy=(String) favObj.get(CREATED_BY);
				if (!processGroupEmailSharing(mapToGroupsName, email)) {
					if(userFavoriteList.size() == 1)
						return Boolean.FALSE;
					else
						continue;
				}

				if((mapToGroupsName!=null) && (!mapToGroupsName.equals(""))){
				Query<Group> queryGroup = this.mongoDatastore.createQuery(Group.class).filter("groupName", mapToGroupsName);
				Group  group = queryGroup.get();
				subLogger.info("group name [" + mapToGroupsName + "] is email sharing is blocked=" + group.getIsEmailSharingBlocked());
				// Check if email sharing is blocked
				if (group.getIsEmailSharingBlocked()) {
					// Check  if the email belongs to the internal
					if (!GenericUtility.isCitiDomainEmail(email) && userFavoriteList.size() == 1) {
						return Boolean.FALSE;
					} else if (!GenericUtility.isCitiDomainEmail(email) && userFavoriteList.size() > 1){
						continue;
					}
					}
				}
				///[C153176-410] top contacts change to pop up window with additional information
				contactAddress=(String) favObj.get("contactAddress");
				contactNote=(String) favObj.get("contactNote");
			   if(favObj.get(CONTACT_PH_NO)!=null)
			   {
				//Removed Unnecessary cast to String in the below line. ToString already being done. 
				contactPhNumber= favObj.get(CONTACT_PH_NO).toString();
			   }
				// full constructor use
				FavoriteContact favContact=null;
				String favCreatedBy=soeId;
				if( !StringUtils.isBlank(createdBy) //&& "Y".equals(staticData.getEnableGrpBasedTopContact())
						)
				{
					//Retain Originator
					favCreatedBy=createdBy;
					
				}
				favContact = new FavoriteContact(currentDate, email, currentDate, name,mapToGroupsName,sharedToGroupsName,favCreatedBy,contactAddress,contactNote,contactPhNumber);
				if(!StringUtils.isBlank(favContact.getSharedToGroupsName()))
			    { 
					createMapWithGrpIdOfFavList(groupIdContactListMapListMap, favContact);
			    }
				else if(!StringUtils.isBlank(favCreatedBy) && favCreatedBy.equals(soeId))
				{
					favCnts.add(favContact);
				}
			}
			//favCnts.isEmpty() check is not required as we have a usecase of clearing all top contact for a given user from the UI.
			// User can save empty list of favCnts also
			//if (!favCnts.isEmpty())//Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
			//{
				// Find User Query
				query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
				User userObj = query.first();
				if (userObj != null)
				{
					// update the favorites
					ops = mongoDatastore.createUpdateOperations(User.class).set(FAVORITES, favCnts);
					mongoDatastore.update(query, ops);
				}
			//	if("Y".equals(staticData.getEnableGrpBasedTopContact()))
				//{//make flag based top contact changes 
				  setSharedTopContactToGroupUser(groupIdContactListMapListMap,soeId,groupIds);
				//}
			//}
			subLogger.info("saveUserFavorites saved successfully favSize=" + favCnts.size());
		}
		catch (Exception e)
		{
			subLogger.error("Exception in saveUserFavorites for  user=" + soeId, e);
			throw e;
		}
		return Boolean.TRUE;
	}

	public List<UserGroupTO> getAllActiveUsersIdName() throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		List<User> userList = null;
		try
		{
			QMACache qmaCache = QMACacheFactory.getCache();
			Config disableUserOrgDisplayConfig = qmaCache.getConfigById(DISABLE_USER_ORG_DISPLAY);
			userList = mongoDatastore.find(User.class).filter(ACTIVE, true).retrievedFields(true, USER_VALIDATION_NAME_KEY,EMAIL,"longDesc","_id").asList();
			List<UserGroupTO> ugList = new ArrayList<UserGroupTO>();
			for (int i = 0; i < userList.size(); i++)
			{
				String displayName = userList.get(i).getName();
				boolean disableUserOrgDisplay=false;
				if(null != disableUserOrgDisplayConfig && !disableUserOrgDisplayConfig.isDisableUserOrgDisplay()){
					disableUserOrgDisplay = !disableUserOrgDisplayConfig.isDisableUserOrgDisplay();
				}
				if(null != userList.get(i).getLongDesc() 
						&& userList.get(i).getLongDesc().contains("[") && disableUserOrgDisplay){
					displayName = userList.get(i).getLongDesc();
				}
				UserGroupTO ugto = new UserGroupTO(displayName, userList.get(i).getEmail(), userList.get(i).getId());
				ugList.add(ugto);
			}
			getSortedAllUsersIdName(ugList);
			return ugList;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getAllUsersIdName", e);
			throw e;
		}
	}
	
	private List<UserGroupTO> getSortedAllUsersIdName(List<UserGroupTO> favorites)//Sonar fix - Reduce this anonymous class number of lines max 20
	{
		if(favorites==null)
		{
			return favorites;
		}
		Collections.sort(favorites, new Comparator<Object>()
		{
			//Sonar fix -- use override annotation on overridden method
			@Override
			public int compare(final Object o1, final Object o2)
			{
				final String obj1 = ((UserGroupTO) o1).getText().toUpperCase();
				final String obj2 = ((UserGroupTO) o2).getText().toUpperCase();
				if (obj1 == obj2)
					return 0;
				if (obj1 == null)
					return -1;
				if (obj2 == null)
					return 1;
				return obj1.compareTo(obj2);
			}
		});
		return favorites;
		
	}

	public Set<Long> getUserGroupsList(String userId) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			subLogger.info("getUserGroupsList for userId" + userId);
			User user = getUserById(userId);
			return getUserGroupsList(user);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getUserGroupsList", e);
			throw e;
		}
	}
	
	public Set<Long> getUserGroupsList(User user) throws CommunicatorException
	{
	  return getUserGroupsList(user, null );
	}
	
	public Set<Long> getUserGroupsList(User user, Boolean active) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			Set<Long> grpList = new HashSet<Long>();
			//Check added to handle User not having any group roles-UI will display message to contact Group Admin
			boolean checkActiveInactive = active == null ? false :true;
			if (user != null && user.getGroupRoles()!=null)
			{
				QMACache qmaCache = QMACacheFactory.getCache();
				Map<Long, Group> allGroupsMap = qmaCache.getAllGroupsMap();
				List<GroupRole> groupRoleList = user.getGroupRoles();
				for (GroupRole groupRole : groupRoleList)
				{
				    Group group = allGroupsMap.get(groupRole.getGroupId());
					if(checkActiveInactive && null != group && Boolean.TRUE.equals(active.booleanValue() == group.getActive()))
					{ 
						grpList.add(groupRole.getGroupId());	
					}
					else if(!checkActiveInactive && null != group)  {
		                            grpList.add(groupRole.getGroupId());
					}
				}
			}
			return grpList;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getUserGroupsList", e);
			throw e;
		}
	}
	
	// va issue fix
	
	public Set<String> getUserGroupsNames(User user, Boolean active) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			Set<String> grpList = new HashSet<String>();
			//Check added to handle User not having any group roles-UI will display message to contact Group Admin
			boolean checkActiveInactive = active == null ? false :true;
			if (user != null && user.getGroupRoles()!=null)
			{
				QMACache qmaCache = QMACacheFactory.getCache();
				Map<Long, Group> allGroupsMap = qmaCache.getAllGroupsMap();
				List<GroupRole> groupRoleList = user.getGroupRoles();
				for (GroupRole groupRole : groupRoleList)
				{
				    Group group = allGroupsMap.get(groupRole.getGroupId());
					if(checkActiveInactive && null != group && Boolean.TRUE.equals(active.booleanValue() == group.getActive()))
					{ 
						grpList.add(group.getGroupName());	
					}
					else if(!checkActiveInactive && null != group)  {
		                            grpList.add(group.getGroupName());
					}
				}
			}
			subLogger.info("Users group for userId" + user.getId() + " ,group role list= " + grpList);
			return grpList;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getUserGroupsList", e);
			throw e;
		}
	}
	
	public String getUserGroupsListForSolr(String userId) throws CommunicatorException
	{
		String userGroupForSolr = null;
		Set<Long> userGroupSet = getUserGroupsList(userId);

		int i = 0;

		for (Long s : userGroupSet)
		{
			if (i == 0)
			{
				userGroupForSolr = "recipients:" + s;

			}
			else
			{
				userGroupForSolr = userGroupForSolr + " recipients:" + s;
			}
			i++;
		}
		return userGroupForSolr;
	}
	public UserTO getUserInfo(String userId,String fullPath) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		long startTime = System.currentTimeMillis();
		subLogger.info("Inside UserDao.getUserInfo for userId=" + userId);
		UserTO userTo = null;
		List<FavoriteContact> userFavorites=new ArrayList<FavoriteContact>();
		
		try
		{
			QMACache qmaCache = QMACacheFactory.getCache();
			//Only Active User's must be able to Login to communicator 
			User user = getUserById(userId, true);
			//subLogger.debug("====== Time Spent till 0 ===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
			if (user == null)
			{
				subLogger.error("No User data found for userId=" + userId);
				throw new CommunicatorException("Invalid UserId. Please contact support.");
			}
			
			subLogger.info("User information for soeId = "+userId +" ***** "+ user.toString());
			userTo = new UserTO(userId, user.getName(), getUserViewTOList(user.getViews()));
			boolean outOfOffice = user.getOutOfOffice() == null ? false : user.getOutOfOffice();
			userTo.setOutOfOffice(outOfOffice);
			Map<String, Object> outOfOfficeSettings = user.getOutOfOfficeSettings();
			if(outOfOfficeSettings != null){
				userTo.setOutOfOfficeSettings(outOfOfficeSettings);
			}
			boolean sendSecureEmail = user.getSendSecureEmail() == null ? false : user.getSendSecureEmail();
			userTo.setSendSecureEmail(sendSecureEmail);
			boolean fitToMyResolution = user.getFitToMyResolution() == null ? false : user.getFitToMyResolution();
			userTo.setFitToMyResolution(fitToMyResolution);
			if(user.getFavorites()!=null)
			{
			  userFavorites=user.getFavorites();
			}

			if (user.getSignatures() != null && !(user.getSignatures().isEmpty()))
			{
				userTo.setUserSignatures(user.getSignatures());
			}
			List<Group> userGroups = groupDAO.getMyDBGroups(user);
			//subLogger.debug("====== Time Spent till 1 ===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
			//Check added to handle User not having any group roles-UI will display message to contact Group Admin
			//Get Configurations from DB always instead of cache
			//Static Data Collection fetches only 1 record from Secondary DB
			
			//StaticData staticData=genricDAO.getStaticData(subLogger);
			StaticData staticData = qmaCache.getDefaultStaticData();
			if(userGroups!=null && !userGroups.isEmpty())
			{
				setSortedItemsForGroupList(userGroups);
				getSortedUserGroups(userGroups);
				mergeUserAndGrpFav(userGroups, userFavorites);
				getTaskizeUserGroups(userGroups, userId);

			}
			//subLogger.debug("======Time Spent till 2===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
			userTo.setClipboardPaste(staticData.getClipboardPaste());// setting the clipboard paste flag
			userTo.setMyGroups(userGroups);
			// subLogger.debug("======Time Spent till 3===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
			userTo.setMyFavoriteContacts(getSortedFavoritesByName(userFavorites));
			// subLogger.debug("======Time Spent till 4===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
			//[C153176-1275]-For the BCC group user names are also displayed under 'Assigned to Group', in the Inquiry Rules screen
			setAllTOCCGroupList(userTo);
			// subLogger.debug("======Time Spent till 5===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
			userTo.setViewWorkFlowColumn(staticData.getViewWorkFlowColumn());
			// subLogger.debug("======Time Spent till 6===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
			List<String> sortedUserFolders = user.getFolders();
			// subLogger.debug("======Time Spent till 7===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");

			GenericUtility.getCaseInsensitiveSortedList(sortedUserFolders);
			// subLogger.debug("======Time Spent till 8===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
			userTo.setUserFolders(sortedUserFolders);
			// userTo.setWsHost(getWebsocketHost());
			userTo.setDefaultViews(QMACacheFactory.getCache().getDefaultViewNameList());
			if (!StringUtils.isEmpty(user.getEmail()))
			{
				userTo.setEmail(user.getEmail());
			}
			if (user.getPreferences() != null && !(user.getPreferences().isEmpty()))
			{
				//userTo.preferences = user.preferences;
				//Changes to convert all Inquiry level View Preference to Group Level
				userTo.setPreferences(setGroupLevelViewPref(user.getPreferences()));
			}
			userTo.setGroupRoles(getUserGroupRole(user.getGroupRoles()));
			
			if(user.getAdminRoles() != null && !(user.getAdminRoles().isEmpty()))
			{
				userTo.setAdminRoles(user.getAdminRoles());
			}
			
			//Templates added as a part of UserInfo
			if(user.getTemplates()!=null)
			{
				userTo.setUserTemplateList(getActiveTemplates(user.getTemplates()));
			}
			if(user.getCustomDefaultViews()!=null)
			{
				userTo.setViewColumnDefs(user.getCustomDefaultViews());
			}
			if(user.getProfilePic()!=null)
			{
				userTo.setProfilePic(user.getProfilePic());
			}
			//Need to get the master columndefs as a part of userinfo and will be used in Column Chooser for default boxes.
			List<ColumnDef> masterColumnDef = staticData.getMasterColumnDef();
			
			if(masterColumnDef!=null)
			{
				userTo.setDefaultColumnDefs(masterColumnDef);
			}
			
			//Enable new top contact version 
			userTo.setEnableCustomStyleInConversation(staticData.getEnableCustomStyleInConversation());
			//[	C153176-289] Flag to enable disable advanced solr search pop up screen.
			userTo.setEnableAdvancedSolrSearch(staticData.getEnableAdvancedSolrSearch());
			//Enable customStyleOverrideList 
			userTo.setCustomStyleOverrideList(staticData.getCustomStyleOverrideList());
			//pass the flag to control the web socket restart.
			if(staticData.getErrorCodeForWebsocketRestartList() != null && !(staticData.getErrorCodeForWebsocketRestartList().isEmpty()))
			{
				userTo.setErrorCodeForWebSocketRestartList(staticData.getErrorCodeForWebsocketRestartList());
			}			
			// Enable dashboard count refresh interval
			userTo.setDashboardCountRefreshIntervalInMs(staticData.getDashboardCountRefreshIntervalInMs());
			
			//Refresh userProfileMap with latest Details
			//set editor font style data 
			if(staticData.getEditorFontStyle()!=null )
			{
				userTo.setEditorFontStyle(staticData.getEditorFontStyle());
			}
			//set default app font style 
			if(!StringUtils.isEmpty(staticData.getDefaultAppFontStyle()))
			{
				userTo.setDefaultAppFontStyle(staticData.getDefaultAppFontStyle());
			}
			//set editor font size data
			if(staticData.getEditorFontStyle()!=null )
			{
				userTo.setEditorFontSize(staticData.getEditorFontSize());
			}
			//set default app font size 
			if(!StringUtils.isEmpty(staticData.getDefaultAppFontSize()))
			{
				userTo.setDefaultAppFontSize(staticData.getDefaultAppFontSize());
			}
			//set default app font size 
			//[C153176-168] Changes for user preference date format
			if(!StringUtils.isBlank(staticData.getDefaultDateFormate()))
			{
				userTo.setDefaultDateFormate(staticData.getDefaultDateFormate());
			}
			if(staticData.getDateFormatterSelectItemList()!=null)
			{
				userTo.setDateFormatterSelectItemList(staticData.getDateFormatterSelectItemList());
			}
			if (null != qmaCache.getConfigById("countryList")) {
				Config countryListConfig = qmaCache.getConfigById("countryList");
				if (countryListConfig.getCountryList() != null) {
					userTo.setCountryList(countryListConfig.getCountryList());
				}
			}
			
			//Get TCL Product family
			if(null != qmaCache.getConfigById("TCLConfiguration")) {
				Config tclConfig = qmaCache.getConfigById("TCLConfiguration");
				if(null != tclConfig.getTCLConfiguration()) {
					List<String> productFamily = (List<String>) tclConfig.getTCLConfiguration().get("productFamily");
					userTo.setProductFamily(productFamily);
				}
			}
			
			//Get productFamilyToGroupIdMap
			if(null != qmaCache.getConfigById("brazilFxConfig")) {
				Config brazilFxConfig = qmaCache.getConfigById("brazilFxConfig");
				if(null != brazilFxConfig.getProductFamilyGroupIdMap()) {
					Map<String,Long> productFamilyGroupIdMap = brazilFxConfig.getProductFamilyGroupIdMap();
					userTo.setProductFamilyGroupIdMap(productFamilyGroupIdMap);
				}
			}
			
			//Get productFamilyToGroupIdMap
			if(null != qmaCache.getConfigById("brazilFxConfig")) {
				Config brazilFxConfig = qmaCache.getConfigById("brazilFxConfig");
				if(null != brazilFxConfig.getEnableBrazilFxIntegration()) {
					String enableBrazilFxIntegration = (String) brazilFxConfig.getEnableBrazilFxIntegration();
					userTo.setEnableBrazilFxIntegration(enableBrazilFxIntegration);
				}
			}
			
			//Get searchInDays
			if(null != qmaCache.getConfigById("brazilFxConfig")) {
				Config brazilFxConfig = qmaCache.getConfigById("brazilFxConfig");
				if(null != brazilFxConfig.getSearchInDays()) {
					Integer searchInDays = brazilFxConfig.getSearchInDays();
					userTo.setSearchInDays(searchInDays);
					//populate businessStartDate
					Date requiredDate = DateUtil.getBusinessDayBefore(userTo.getSearchInDays());
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat(MONGO_UTC_FORMAT);
					simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
					String dtString = simpleDateFormat.format(requiredDate); 
					userTo.setBussinessStartDate(dtString);
				}
			}
		
			//Get link/delink config
			if(null != qmaCache.getConfigById("brazilFxConfig")) {
				Config brazilFxConfig = qmaCache.getConfigById("brazilFxConfig");
				if(null != brazilFxConfig.getEnableManualDeLinkEntity()) {
					String enableBrazilFxIntegration = brazilFxConfig.getEnableManualDeLinkEntity();
					userTo.setEnableManualDeLinkEntity(enableBrazilFxIntegration);
				}
				
				if(null != brazilFxConfig.getEnableManualLinkEntity()) {
					String enableBrazilFxIntegration = brazilFxConfig.getEnableManualLinkEntity();
					userTo.setEnableManualLinkEntity(enableBrazilFxIntegration);
				}
			}
			
			//sbt:[C170665-1723] High CheckMark Findings
			if (null != qmaCache.getConfigById("FileNameAndPathValidation")) {
				Config validationConfig = qmaCache.getConfigById("FileNameAndPathValidation");
				if (validationConfig.getFileNameRegex() != null) {
					userTo.setFileNameRegex(validationConfig.getFileNameRegex());
				}
				if(validationConfig.getInvalidChars() != null) {
					userTo.setInvalidChars(validationConfig.getInvalidChars());
				}
			}
			
			//Get intentList
			if(null != qmaCache.getConfigById("nlpConfiguration")) {
				Config nlpConfiguration = qmaCache.getConfigById("nlpConfiguration");
				if(null != nlpConfiguration.getNlpConfiguration()) {
					Map<String,Object> productFamilyGroupIdMap = (Map<String, Object>) nlpConfiguration.getNlpConfiguration();
					Map<String,String> intentSuggestionIndicators = (Map<String, String>) productFamilyGroupIdMap.get("intentSuggestionIndicator");
					TreeMap<String, String> sortedIntentSuggestionIndicators = new TreeMap<String, String>(intentSuggestionIndicators);
					String noIntentOtherString = "";
					List<String> intentList = new ArrayList<String>();
					
					if(null != sortedIntentSuggestionIndicators && !sortedIntentSuggestionIndicators.isEmpty()) {
						Iterator<String> intentSet = sortedIntentSuggestionIndicators.keySet().iterator();
						while(intentSet.hasNext()) {
							String intent = intentSet.next();
							String intentAfterRegex = intent.replaceAll(NLPConstants.ALPHABATE_REGEX, " ");
							if(NLPConstants.NO_INTENT_OTHER_INTENT_KEY.equalsIgnoreCase(intentAfterRegex)) {
								noIntentOtherString = intent;
								intentSet.remove();
							}else {
								intentList.add(intent);
							}
						}
						intentList.add(noIntentOtherString);
						userTo.setIntentList(intentList);
					}
				}
			}
			
			if (null != qmaCache.getConfigById("timeZones")) {
				Config timeZonesConfig = qmaCache.getConfigById("timeZones");
				if (timeZonesConfig.getTimeZones() != null) {
					userTo.setTimeZones(timeZonesConfig.getTimeZones());
				}
			}
			if( null != qmaCache.getConfigById("enableAgeBasedCalculation") ) {
				Config ageConfig = qmaCache.getConfigById("enableAgeBasedCalculation");
				if( ageConfig.isEnableAgeBasedCalculation() ) {
					userTo.setAgeBasedCalculation(true);
				}
			}
			
			if(staticData.getWebSocketUpdateRows()!=null)
			{
				userTo.setWebSocketUpdateRows(staticData.getWebSocketUpdateRows());
			}
			
			setCvWebSocketConfig(userTo);
			
			if (null != qmaCache.getConfigById("misExclusionReports"))
			{
				Config misExclusionReportListConfig = qmaCache.getConfigById("misExclusionReports");
				if (misExclusionReportListConfig.getMisExclusionReports() != null)
				{
					userTo.setMisExclusionReportNameList(misExclusionReportListConfig.getMisExclusionReports());
				}
			}
			if (null != qmaCache.getConfigById("misExclusionReasons"))
			{
				Config misExclusionReasonsListConfig = qmaCache.getConfigById("misExclusionReasons");
				if (misExclusionReasonsListConfig.getMisExclusionReasons() != null)
				{
					userTo.setMisExclusionReasonList(misExclusionReasonsListConfig.getMisExclusionReasons());
				}
			}
			Map<String,List<HolidayMaster>> holidays = QMACacheFactory.getCache().getHolidayMasterMap();
			if(holidays!=null) {
				userTo.setHolidays(holidays);
			}
			if(staticData.getBccGroupIdList()!=null)
			{
				userTo.setBccGroupIdList(staticData.getBccGroupIdList());
			}
			if(staticData.getBccRoutingGroup()!=null)
			{
				userTo.setBccGroupRoutingId(staticData.getBccRoutingGroup());
			}
			//[C153176-283] - Link collaborate urls
			if(staticData.getCollaborateUrls()!=null && !staticData.getCollaborateUrls().isEmpty())
			{
				userTo.setCollaborateUrls(staticData.getCollaborateUrls());
			}
			
			//[C153176-1032]-Make maker-checker mandatory
			if(staticData.getMakerCheckerMandatoryOrgs() != null && !staticData.getMakerCheckerMandatoryOrgs().isEmpty())
			{
				userTo.setMakerCheckerMandatoryOrgs(staticData.getMakerCheckerMandatoryOrgs());
			}
			//[C153176-1032]-Make maker-checker mandatory
			if(staticData.getMakerCheckerExclusionGroups()!=null && !staticData.getMakerCheckerExclusionGroups().isEmpty())
			{
				userTo.setMakerCheckerExclusionGroups(staticData.getMakerCheckerExclusionGroups());
			}
			if(staticData.getAttachmentVerificationMandatoryOrgs() != null && !staticData.getAttachmentVerificationMandatoryOrgs().isEmpty())
			{
				userTo.setAttachmentVerificationMandatoryOrgs(staticData.getAttachmentVerificationMandatoryOrgs());
			}
			//[C153176-999] - Convert Kendo-Charts into Highcharts
			if(StringUtils.isNotBlank(staticData.getEnableHighcharts()))
			{
				userTo.setEnableHighcharts(staticData.getEnableHighcharts());
			}
			if(staticData.getHighchartsReqTypeMaxLength() != null)
			{
				userTo.setHighchartsReqTypeMaxLength(staticData.getHighchartsReqTypeMaxLength());
			}
			if(staticData.getHighchartsAssignedOwnerMaxLength() != null)
			{
				userTo.setHighchartsAssignedOwnerMaxLength(staticData.getHighchartsAssignedOwnerMaxLength());
			}
			if(staticData.getEnableMakerCheckerForUnapprovedDomains() != null)
			{
				userTo.setEnableMakerCheckerForUnapprovedDomains(staticData.getEnableMakerCheckerForUnapprovedDomains());
			}
			//subLogger.debug("======Time Spent till 9===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
			userTo.setReportList(getMISReportData(staticData));
			
			//[C153176-725] - Admin Menu Enhancements for config role and other role reviews
			populateConfigAdminRoles(userTo);
			//subLogger.debug("======Time Spent till 10===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
			//[C153176-544] - AutoResponse details
			populateAutoResponseTemplate(userTo);
			//subLogger.debug("======Time Spent till 11===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
			//[C153176-854] - Add new drop-down: Inquiry Source
			populateInquirySourceList(userTo);
			//C170665-1719 DCC Requirement: Add Case status field
			userTo.setEnableInquirySubStatusFlag(getEnableInquirySubStatusFlag());
			populateInquirySubStatusList(userTo);
			//subLogger.debug("======Time Spent till 12===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
			List<UserContextTO> userContext = getContextInfo(user);
			userTo.setContext(userContext);
			//subLogger.debug("======Time Spent till 14===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
			//[C153176-168] Changes for user preference date format End
			// [C153176-1281] Show latest release notes on QMA UI.
			populateReleaseNotesDocument(user, userTo,fullPath);
			//[C153176-1046] Create 'Black List' domains
			populateBlackListDomains(userTo);
			// [C153176-1626] Other citi domains 
			populateCitiDomains(userTo);
			//[C153176-1563] - Request Types normalization
			populateHighlevelRequestTypes(userTo);
			boolean disableAutoComplete = user.getDisableAutoComplete() == null ? false : user.getDisableAutoComplete();
			userTo.setDisableAutoComplete(disableAutoComplete);
			boolean attachmentPwdProtectionFlag = user.getAttachmentPwdProtectionFlag() == null ? false : user.getAttachmentPwdProtectionFlag();
			userTo.setAttachmentPwdProtectionFlag(attachmentPwdProtectionFlag);
			if(null != user.getMyCoverage())
			{
				userTo.setMyCoverage(user.getMyCoverage());
			}else{
				userTo.setMyCoverage(new ArrayList<>());
			}
			if (user.getNotificationSettings() != null)
			{
				userTo.setNotificationSettings(user.getNotificationSettings());
			}
			if(null != user.getViewFilters())
			{
				userTo.setViewFilters(user.getViewFilters());
			}else{
				userTo.setViewFilters(new ArrayList<>());
			}
			if(null != staticData.getDefaultClientCategories())
			{
				userTo.setDefaultClientCategories(staticData.getDefaultClientCategories());
			}else{
				userTo.setDefaultClientCategories(new ArrayList<>());
			}
			if (user.getPreviousDayBoxCount() != null)
			{
				userTo.setPreviousDayBoxCount(user.getPreviousDayBoxCount());
			}
			if (null != qmaCache.getConfigById("defaultViewsInQMA"))
			{
				Config defaultViewsInQMAConfig = qmaCache.getConfigById("defaultViewsInQMA");
				if (defaultViewsInQMAConfig.getDefaultViewNames() != null)
				{
					userTo.setDefaultViewsInQMA(defaultViewsInQMAConfig.getDefaultViewNames());
				}
			}
			if (null != qmaCache.getConfigById("tinyMCEUrl"))
			{
				Config tinyMCEUrl = qmaCache.getConfigById("tinyMCEUrl");
				if (null != tinyMCEUrl && StringUtils.isNotBlank(tinyMCEUrl.getTinyMCEUrl())){
					userTo.setTinyMCEUrl(tinyMCEUrl.getTinyMCEUrl());
				}
			}
			
			if (null != QMACacheFactory.getCache().getDefaultStaticData().getClientCategories())
			{
				List<ClientCategory> clientCategories = QMACacheFactory.getCache().getDefaultStaticData().getClientCategories();
				userTo.setClientCategories(clientCategories);
			}
			
			if (null != qmaCache.getConfigById("globalDirectoryConfig"))
			{
				Config globalDirectoryConfig = qmaCache.getConfigById("globalDirectoryConfig");
				if (null != globalDirectoryConfig && null != globalDirectoryConfig.getGlobalDirectoryConfig()){
					userTo.setGlobalDirectoryConfig(globalDirectoryConfig.getGlobalDirectoryConfig());
				}
			}
			
			if (null != qmaCache.getConfigById("symphonyConfig"))
			{
				Config symphonyConfig = qmaCache.getConfigById("symphonyConfig");
				if (null != symphonyConfig && null != symphonyConfig.getSymphonyConfig()){
					userTo.setSymphonyConfig(symphonyConfig.getSymphonyConfig());
				}
			}
			
			if(null != user.getUserAuthKey()){
				userTo.setUserAuthKey(user.getUserAuthKey());
			}
			if(null != user.getSymphonyId()){
				userTo.setSymphonyId(user.getSymphonyId());
			}
			if(null != user.getSymphonyEmailId()){
				userTo.setSymphonyEmailId(user.getSymphonyEmailId());
			}
			if (null != qmaCache.getConfigById(QMA_UI2_CONFIG_KEY) && null != QMACacheFactory.getCache().getConfigById(QMA_UI2_CONFIG_KEY).getQmaUI2Config())
			{
				Map<String, Object> qmaUI2Config = qmaCache.getConfigById(QMA_UI2_CONFIG_KEY).getQmaUI2Config();
				if (!MapUtils.isEmpty(qmaUI2Config)){
					userTo.setQmaUI2Config(qmaUI2Config);
				}
			}
			if (null !=  qmaCache.getUserSymphonyIdToUserMap())
			{
				userTo.setUserSymphonyIdToUserMap(qmaCache.getUserSymphonyIdToUserMap());
			}
			if (null != user.getIsSymphonyEnabledForUser())
			{
				userTo.setIsSymphonyEnabledForUser(user.getIsSymphonyEnabledForUser());
			}
			
			if(user.getIsTaskizeEnabledForUser() != null) {
				userTo.setIsTaskizeEnabledForUser(user.getIsTaskizeEnabledForUser());
			}
			
			if (null != user.isCalendarSubscribed() && user.isCalendarSubscribed()) {
				userTo.setCalendarSubscribed(user.isCalendarSubscribed());
			}
			
			// Get the Personal MailBox GroupId from the map for the user.
			if(null !=  qmaCache.getPersonalMailboxIdToGroupIdMap()) {
				subLogger.debug("From Hazelcast getPersonalMailboxIdToGroupIdMap userId:["+user.getId()+"] Value:"+QMACacheFactory.getCache().getPersonalMailboxIdToGroupIdMap().get(user.getId()));
				userTo.setPersonalMailboxGrpId(qmaCache.getPersonalMailboxIdToGroupIdMap().get(user.getId()));
			}
			
			// Personal Section - Settings
			if (null != user.isPersonalEmailSubscribed()) {
				userTo.setPersonalEmailSubscribed(user.isPersonalEmailSubscribed());
			}
			
			if (null != user.getExchUrl()) {
				userTo.setExchUrl(user.getExchUrl());
			}
			
			if (null != user.getExchDomain()) {
				userTo.setExchDomain(user.getExchDomain());
			}

			userTo.setAuthenticationExpired(user.isAuthenticationExpired());
			userTo.setPersonalAccountActive(user.isPersonalAccountActive());

			if (null != qmaCache.getConfigById("qmaPersonalConfig")) {
				Config qmaPersonalConfig = qmaCache.getConfigById("qmaPersonalConfig");
				if (null != qmaPersonalConfig && null != qmaPersonalConfig.getQmaPersonalConfig()) {
					List<String> subjectFlagwords = (List<String>) qmaPersonalConfig.getQmaPersonalConfig().get("subjectFlagwords");
					userTo.setSubjectFlagwords(subjectFlagwords);

					List<String> exchangeAccountHosts = (List<String>) qmaPersonalConfig.getQmaPersonalConfig().get("exchangeAccountHosts");
					userTo.setExchangeAccountHosts(exchangeAccountHosts);
				}
			}
			if(null != staticData && null != staticData.getRestrictedFileExtensions()) {
				userTo.setRestrictedFileExtensions(staticData.getRestrictedFileExtensions());
			}
            if(null != staticData && null != staticData.getAllowedFileExtensions()) {
				userTo.setAllowedFileExtensions(staticData.getAllowedFileExtensions());
			}
            if(null != staticData && null != staticData.getBlockedFileNameCharacters()) {
				userTo.setBlockedFileNameCharacters(staticData.getBlockedFileNameCharacters());
			}
			if (null != QMACacheFactory.getCache().getConfigById("sessionConfig"))
			{
				Config sessionConfig = QMACacheFactory.getCache().getConfigById("sessionConfig");
				if (null != sessionConfig && null != sessionConfig.getSessionConfig()){
					userTo.setSessionConfig(sessionConfig.getSessionConfig());
				}
			}
			if (null != qmaCache.getConfigById("qma2RedirectPopupConfig"))
			{
				Config qma2RedirectPopupConfig = qmaCache.getConfigById("qma2RedirectPopupConfig");
				if (null != qma2RedirectPopupConfig && null != qma2RedirectPopupConfig.getQma2RedirectPopupConfig()){
					userTo.setQma2RedirectPopupConfig(qma2RedirectPopupConfig.getQma2RedirectPopupConfig());
				}
			}
			if (null != qmaCache.getConfigById("uiConsoleLogConfig"))
			{
				Config uiConsoleLogConfig = qmaCache.getConfigById("uiConsoleLogConfig");
				if (null != uiConsoleLogConfig && null != uiConsoleLogConfig.getUiConsoleLogConfig()){
					userTo.setUiConsoleLogConfig(uiConsoleLogConfig.getUiConsoleLogConfig());
				}
			}
			
			// C170665-5 | Get the custody account to user
			if (null != staticData && null != staticData.getCustodyAccounts()) {
				userTo.setCustodyAccounts(staticData.getCustodyAccounts());
			}
			
			// Flag to enable or disable the Amcar Integration
			if(null != qmaCache.getConfigById("isgCloudAmcarConfig")) {
				Config isgCloudAmcarConfig = qmaCache.getConfigById("isgCloudAmcarConfig");
				if (null != isgCloudAmcarConfig && null != isgCloudAmcarConfig.getIsgCloudAmcarConfig()){
					Boolean enableAmcarIntegration = (Boolean) isgCloudAmcarConfig.getIsgCloudAmcarConfig().get("enableAmcarIntegration");
					userTo.setEnableAmcarIntegration(enableAmcarIntegration);
				}
			}
			if (null != qmaCache.getConfigById("pivotProConfig"))	{
				Config pivotProConfig = (Config) qmaCache.getConfigById("pivotProConfig");
				userTo.setPivotProConfigEnabled(pivotProConfig.isPivotProConfigEnabled());
			}
			// C170665-185 get org admin role from user in hard code data point
			if (null != user.getOrgAdminRole() && user.getOrgAdminRole().size() > 0) {
				userTo.setOrgAdminRole(user.getOrgAdminRole());
				//[C170665-1719] DCC Requirement: Add Case status field flg for Inq sub status enabled at DL / org level
				getIsInquirySubStatusEnabledAtOrg(userTo,user);
				
			}
			if(null != user.getViewDateRangeConfig() && user.getViewDateRangeConfig().size() > 0) {
				userTo.setViewDateRangeConfig(user.getViewDateRangeConfig());
			}
			if (null != qmaCache.getConfigById("ideationConfig"))	{
				Config ideationConfig = qmaCache.getConfigById("ideationConfig");
				userTo.setideationConfig(ideationConfig.getideationConfig());
			}
			userTo.setAutoAssignmentRollOutOrgsList(getAutoAssignmentRollOutOrgsList());
						
			if (qmaCache.getConfigById("taskizeConfig") != null) {
	            Map<String, Object> taskizeConfigCache = qmaCache.getConfigById("taskizeConfig").getTaskizeConfig();
	            if (taskizeConfigCache != null) {
	            	Map<String, Object> taskizeMapNew = getTaskizeConfig(taskizeConfigCache, user.getEmail());
	            	if(taskizeMapNew != null) {
	            		subLogger.info("taskizeMap Found in Cache");
	            	} else {
	            		subLogger.info("taskizeMap Not Found in Cache");
	            	}
	            	
	            	// This map will be return to the UI
	                userTo.setTaskizeConfig(taskizeMapNew);
	            }
	        }
			//QMA-1486 : adding msExchangeServerConfig in login user response
			Map<String, String> msExchangeServerConfigMap = qmaCache.getMsExchangeServerMap();
			if(!Objects.isNull(msExchangeServerConfigMap)){
			userTo.setMsExchangeServerConfigMap(msExchangeServerConfigMap);
			}
			
			if(null != qmaCache.getConfigById(DEFAULT_VIEW_PERFORMANCE_CONFIG)) {
				Config defaultViewPerformanceConfig = qmaCache.getConfigById(DEFAULT_VIEW_PERFORMANCE_CONFIG);
				if(null != defaultViewPerformanceConfig.getDefaultViewPerformanceConfig()) {
					userTo.setDefaultViewPerformanceConfig(defaultViewPerformanceConfig.getDefaultViewPerformanceConfig());
				}
			}
			
			userProfileMap.put(userId, userTo);
			subLogger.debug("======Total Time for getting userinfo===============" + (System.currentTimeMillis() - startTime) + " in Milli Seconds");
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getUserInfo", e);
			throw new CommunicatorException("Exception in getUserInfo",e);
		}
		return userTo;
	}
	
	private Map<String, Object> getTaskizeConfig(Map<String, Object> taskizeConfigCache, String loggedInUserId)
	{
		String clientId = null;
		String redirectUrl = null;
		String responseType = null;
		String authUrl = null;
		Boolean taskizeEnabledValue = false;
        
        clientId = (String) taskizeConfigCache.get("client_id");
        redirectUrl = (String) taskizeConfigCache.get("redirect_url");
        //encoded userId from url
        redirectUrl = redirectUrl + "?userId="+Base64.getEncoder().encodeToString(loggedInUserId.getBytes());
        responseType = (String) taskizeConfigCache.get("response_type"); 
        authUrl = (String) taskizeConfigCache.get("auth_url");
        if(null != taskizeConfigCache.get(TASKIZE_ENABLED)){
            taskizeEnabledValue = (Boolean) taskizeConfigCache.get(TASKIZE_ENABLED);
        }
        
        Map<String, Object> taskizeMap = new HashMap<>(); 
        taskizeMap.put("client_id", clientId);
        taskizeMap.put("redirect_url", redirectUrl);
        taskizeMap.put("response_type", responseType);
        taskizeMap.put("auth_url", authUrl);
        taskizeMap.put("taskizeTokenExpiryDate", getTaskizeTokenExpiryDate(loggedInUserId));
     // [C170665-3643] Taskize enabled
        taskizeMap.put(TASKIZE_ENABLED, taskizeEnabledValue);
        
        return taskizeMap;
	}
	
	private String getTaskizeTokenExpiryDate(String emailId) {
		String taskizeTokenExpiryDateStr = "";
		if(StringUtils.isNotEmpty(emailId)) {
			TaskizeAccessToken accessToken = genericDAO.get(TaskizeAccessToken.class,"username", emailId.toLowerCase());
			if(accessToken != null) {
				Date taskizeTokenExpiryDate = accessToken.getTokenExpiryDate();
				subLogger.info("taskizeTokenExpiryDate :: {}",taskizeTokenExpiryDate);
				SimpleDateFormat sdf = new SimpleDateFormat(MONGO_UTC_FORMAT);
				sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
				taskizeTokenExpiryDateStr = sdf.format(taskizeTokenExpiryDate);
				
				subLogger.info("taskizeTokenExpiryDateStr :: {}",taskizeTokenExpiryDateStr);
			}
		}
		return taskizeTokenExpiryDateStr;
	}

	private void getIsInquirySubStatusEnabledAtOrg(UserTO userTo,User user) {
		try {
			if(null != QMACacheFactory.getCache().getOrgNameToOrgPref()) {
				OrgPreferences orgPref = QMACacheFactory.getCache().getOrgNameToOrgPref().get(user.getOrgAdminRole().get(0).getOrgName());
				if(null != orgPref && orgPref.getEnableInquirySubStatus() != null && orgPref.getEnableInquirySubStatus().equals("true")) {
					userTo.setIsInquirySubStatusEnabledAtOrg(true);
				}else {
					userTo.setIsInquirySubStatusEnabledAtOrg(false);
				}
			}
		}catch(Exception e) {
			subLogger.warn("Exception while getting Org level inquiry level sub status enabled",e);
		}
	}

	/**
	 * This method is used to set list of auto assignment roll out orgs
	 * 
	 */
	private List<String> getAutoAssignmentRollOutOrgsList() {
		List<String> autoAssignmentRollOutOrgs =  new ArrayList<String>();
		try {
			if(null !=  QMACacheFactory.getCache().getNlpConfiguration()) {
				Map<String, Object> nlpConfig = QMACacheFactory.getCache().getNlpConfiguration();
				if (null != nlpConfig.get(NLPConstants.AUTO_ASSIGNMENT_ROLLOUT_ORGS)) {
					BasicDBList rollOutOrgsList = (BasicDBList) nlpConfig.get(NLPConstants.AUTO_ASSIGNMENT_ROLLOUT_ORGS);
					subLogger.info("Rollout orgs configured list :" + rollOutOrgsList.keySet());
					for(Object rollOutTerm :rollOutOrgsList) {
						if (null != rollOutTerm) {
							autoAssignmentRollOutOrgs.add(rollOutTerm.toString().toLowerCase());
						}
					}
				
				}
			}
		} catch (Exception e) {
			subLogger.error("Error while getting list of rollout ors:",e);
		}
		return autoAssignmentRollOutOrgs;
	}

	//[C153176-854] - Add new drop-down: Inquiry Source
	//Function to populate inquiry-source list from config
	private void populateInquirySourceList(UserTO userTo)
	{
		//Map<String, Config> configData  =  CacheDAO.getInstance().getConfigIdMap();
		//List<String> inquirySourceList = genricDAO.getConfigDetailsForId("InquirySource").getInquirySourceList();
		List<String> inquirySourceList = QMACacheFactory.getCache().getConfigById("InquirySource").getInquirySourceList();
		if (inquirySourceList!=null && !inquirySourceList.isEmpty())
		{
			userTo.setInquirySourceList(inquirySourceList);
		}		
	}
	
	public boolean getEnableInquirySubStatusFlag() {
		subLogger.info("inside getEnableInquirySubStatusFlag");
		boolean flag= false; 
		try {
			if(QMACacheFactory.getCache().getConfigById("enableInquirySubStatusFlag") != null) {
				Config enableInquirySubStatusFlag = QMACacheFactory.getCache().getConfigById("enableInquirySubStatusFlag");
				subLogger.info("enableInquirySubStatusFlag {}",enableInquirySubStatusFlag.isEnableInquirySubStatusFlag());
				flag= enableInquirySubStatusFlag.isEnableInquirySubStatusFlag();
			}
		}catch(Exception e) {
			subLogger.warn("Exception while getEnableInquirySubStatusFlag",e);
		}	
		return flag;
	}
	
	//C170665-1719 DCC Requirement: Add Case status field
	private void populateInquirySubStatusList(UserTO userTo)
	{
		subLogger.info("inside populateInquirySubStatuslist");
		try {
			if(userTo.getEnableInquirySubStatusFlag() && QMACacheFactory.getCache().getConfigById("InquirySubStatus") != null) {
				List<String> inquirySubStatusList = QMACacheFactory.getCache().getConfigById("InquirySubStatus").getInquirySubStatusList();
				subLogger.info("InquirySubStatus list: {}",inquirySubStatusList);
				if (inquirySubStatusList!=null && !inquirySubStatusList.isEmpty())
				{
					userTo.setInquirySubStatusList(inquirySubStatusList);
					subLogger.info("InquirySubStatus list added to userTO");
				}	
			}
		}catch(Exception e) {
			subLogger.warn("Exception while populating Inquiry Sub-Status List",e);
		}	
	}	
	
	// Function to populate application level black list domains from Config collection
	private void populateBlackListDomains(UserTO userTo){
		//Map<String, Config> configData  =  CacheDAO.getInstance().getConfigIdMap();
		List<String> blackListDomains = QMACacheFactory.getCache().getConfigById("BlackListDomains").getDomains();
		if (blackListDomains!=null && !blackListDomains.isEmpty())
		{
			userTo.setBlackListDomains(blackListDomains);
		}
	}
	
	/**
	 * @param userTo
	 * populate CitiDomains list with user login info.  
	 */
	private void populateCitiDomains(UserTO userTo){
		List <String> citidomainsList = null;
		if (null != genericDAO){
			citidomainsList  = genericDAO.getListOfCitiDomain();
			if (citidomainsList!=null && !citidomainsList.isEmpty())
			{
				userTo.setCitiDomainList(citidomainsList);
			}
		}
		
	}
	
	/**
	 * @param userTo
	 * populate highlevelRequestType List with user login info.  
	 * [C153176-1563] - Request Types normalization
	 */
	private void populateHighlevelRequestTypes(UserTO userTo){
		List <String> highlevelRequestTypeList = null;
		boolean highlevelRequestTypeFlag = false;
		userTo.setHighlevelRequestTypeFlag(highlevelRequestTypeFlag);
		if (null != genericDAO){
			highlevelRequestTypeFlag  = genericDAO.getHighlevelRequestTypeFlag();
			highlevelRequestTypeList  = genericDAO.getListOfHighlevelRequestTypes();
			if (highlevelRequestTypeList!=null && !highlevelRequestTypeList.isEmpty())
			{
				userTo.setHighlevelRequestTypeList(highlevelRequestTypeList);
			}
			if (highlevelRequestTypeFlag)
			{
				userTo.setHighlevelRequestTypeFlag(highlevelRequestTypeFlag);
			}
		}
		
	}
		
	//[C153176-544] - AutoResponse details
	//Function to populate auto response template details from config
	//  
	private void populateAutoResponseTemplate(UserTO userTo)
	{
		//Map<String, Config> configData  =  CacheDAO.getInstance().getConfigIdMap();
		String autoResponseTemplate = QMACacheFactory.getCache().getConfigById("AutoResponse").getTemplate();		
		//String autoResponseTemplate = genricDAO.getConfigDetailsForId("AutoResponse").getTemplate();
		if (!StringUtils.isBlank(autoResponseTemplate))
		{
			userTo.setAutoResponseTemplate(autoResponseTemplate);
		}		
	}

	// Common method to sort all items inside group
	//C170665-185 changes for hard code data point to display meta data in transaction screen
	public void setSortedItemsForGroupList(List<Group> userGroups) {
		boolean disableGroupEdit = false;
		for (Group grp : userGroups) {
			String orgName = getOrgName(grp);
			try {
				if (orgName != null && orgName.length() > 0) {
					OrganizationDAO orgDao = new OrganizationDAO();
					Organization organization = orgDao.getOrgData(orgName);
					if (organization != null) {
						boolean enableOrgMetaData=organization.isEnableOrgLevelMetaData();
						if(enableOrgMetaData) {
							OrgPreferences orgPreference = organization.getOrgPreferences();
							if (orgPreference != null)
							{
								disableGroupEdit = Boolean.parseBoolean(orgPreference.getEnableGroupLevelOverride());
								if (disableGroupEdit) {
									grp.setRequestTypes(organization.getRequestTypes());
									grp.setRequestTypeMappings(organization.getHighLevelRequestTypeMapping());
									grp.setRootCauseList(organization.getRootCause());
									grp.setRequestTypeRootCauseMapping(organization.getRequestTypeRootCauseMapping());
									sortMetaData(grp);
								} else {
									getUnionOfOrgAndGroupMetaData(organization, grp);
									sortMetaData(grp);
								}
							}else {
							 sortMetaData(grp);
							}	
						}else {
							sortMetaData(grp);
						}
					} else {
						sortMetaData(grp);
					}
				} else {
					sortMetaData(grp);
				}
			} catch (Exception e) {
				subLogger.error("Exception in setSortedItemsForGroupList", e);
			}
		}
	}
	
	//C170665-3791 marking a groups as for taskize user only using genric flag
	public void getTaskizeUserGroups(List<Group> userGroups, String soeId) {
		try {
			subLogger.info("getTaskizeUserGroups :: started");
			List<TaskizeParticipantsContactMapping> taskizeParticipantContactMappingList = QMACacheFactory.getCache()
					.getConfigById("taskizeParticipantsContactMapping").getTaskizeParticipantsContactMapping();
			if (taskizeParticipantContactMappingList != null) {
				List<Long> taksizeDlList = taskizeParticipantContactMappingList.stream()
						.map(TaskizeParticipantsContactMapping::getQmaDlId).distinct().collect(Collectors.toList());
				subLogger.info("getTaskizeUserGroups :: taksizeDlList :: {} taskizeParticipantsContactMapping :: {}",
						taksizeDlList.size(), taskizeParticipantContactMappingList.size());

				for (Group grp : userGroups) {
					if (taksizeDlList.contains(grp.getId())) {
						grp.setStreamId("Taskize");
					}
				}
			} else {
				subLogger.warn("getTaskizeUserGroups :: group not found for :: {}",soeId);
			}
			subLogger.info("getTaskizeUserGroups :: ended");
		} catch (Exception e) {
			subLogger.error("getTaskizeUserGroups :: exception while updating flag for taskize user :: {}, :: {} ", soeId, e);
		}
	}

/*	private void setSortedRequestTypesForGroupList(List<Group> userGroups)
	{
		for (Group grp : userGroups)
		{
			GenericUtility.getCaseInsensitiveSortedList(grp.requestTypes);
			
		}
		
	}*/

	private List<Group> getSortedUserGroups(List<Group> userGroups)//Sonar fix - Reduce this anonymous class number of lines max 20
	{
		if(userGroups==null){
			return userGroups;
		}
		Collections.sort(userGroups, new Comparator<Object>()
		{
			//Sonar fix -- use override annotation on overridden method
			@Override
			public int compare(final Object o1, final Object o2)
			{
				final String obj1 = ((Group) o1).getGroupName().toUpperCase();
				final String obj2 = ((Group) o2).getGroupName().toUpperCase();

				if (obj1 == obj2)
					return 0;
				if (obj1 == null)
					return -1;
				if (obj2 == null)
					return 1;
				return obj1.compareTo(obj2);
			}
		});
		return userGroups;
	}

	private List<FavoriteContact> getSortedFavoritesByName(List<FavoriteContact> favorites)//Sonar fix - Reduce this anonymous class number of lines max 20
	{
		if(favorites==null){
			return favorites;
		}
		Collections.sort(favorites, new Comparator<Object>()
		{
			//Sonar fix -- use override annotation on overridden method
			@Override
			public int compare(final Object o1, final Object o2)
			{
				final String obj1 = ((FavoriteContact) o1).getName().toUpperCase();
				final String obj2 = ((FavoriteContact) o2).getName().toUpperCase();

				if (obj1 == obj2)
					return 0;
				if (obj1 == null)
					return -1;
				if (obj2 == null)
					return 1;
				return obj1.compareTo(obj2);
			}
		});
		//subLogger.info("favorites= " + favorites);
		return favorites;
	}

	public List<UserContextTO> getContextInfo(String userId) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("Inside UserDao.getContextInfo for userId= " + userId);
		try
		{
			User user = getUserById(userId);
			return getContextInfo(user);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getContextInfo", e);
			throw new CommunicatorException("Exception in getContextInfo",e);
		}
	}
	public List<UserContextTO> getContextInfo(User user) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		
		List<UserContextTO> userContextTOList = new ArrayList<UserContextTO>();
		try
		{
			if (user != null)
			{
				subLogger.info("Inside UserDao.getContextInfo for userId= " + user.getId());
				Set<Long> userGrpsList = getUserGroupsList(user);
				QMACache qmaCache = QMACacheFactory.getCache();
				Map<String, User> userInfoMap = qmaCache.getUserInfoMap();
				Map<Long, List<String>> groupIdToUserListMap = qmaCache.getGroupIdToUserListMap();
				for (Long groupId : userGrpsList)
				{
					List<String> allMyGrpUsers = groupIdToUserListMap.get(groupId);//query.asList();
					if(allMyGrpUsers !=null)
					{
						UserContextTO userContextTO = new UserContextTO();
						List<UserGroupTO> assignUserList = new ArrayList<UserGroupTO>();
						for (String usrId : allMyGrpUsers)
						{
							if (null != userInfoMap && null != userInfoMap.get(usrId.toUpperCase()) && null != qmaCache.getUserInfoMap().get(usrId.toUpperCase()).getOutOfOffice() && !qmaCache.getUserInfoMap().get(usrId.toUpperCase()).getOutOfOffice())
							{
								UserGroupTO userTO = new UserGroupTO(userInfoMap.get(usrId.toUpperCase()).getName(), usrId, userInfoMap.get(usrId.toUpperCase()).getActive());
								assignUserList.add(userTO);
							}
						}
						getSortedUserGroupsTos(assignUserList);
						userContextTO.setAssignOwnerList(assignUserList);
						userContextTO.setGroupId(groupId);
						userContextTOList.add(userContextTO);
					}
				}
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getContextInfo", e);
			throw new CommunicatorException("Exception in getContextInfo",e);
		}
		return userContextTOList;
	}
	private List<User> getSortedGroupUsers(List<User> groupUsers)//Sonar fix - Reduce this anonymous class number of lines max 20
	{
		if(groupUsers==null){
			return groupUsers;
		}
		Collections.sort(groupUsers, new Comparator<Object>()
		{
			//Sonar fix -- use override annotation on overridden method
			@Override
			public int compare(final Object o1, final Object o2)
			{
				final String obj1 = ((User) o1).getName().toUpperCase();
				final String obj2 = ((User) o2).getName().toUpperCase();

				if (obj1 == obj2)
					return 0;
				if (obj1 == null)
					return -1;
				if (obj2 == null)
					return 1;
				return obj1.compareTo(obj2);
			}
		});
		return groupUsers;
	}
	private List<UserGroupTO> getSortedUserGroupsTos(List<UserGroupTO> usergroupTos)//Sonar fix - Reduce this anonymous class number of lines max 20
	{
		if(usergroupTos==null){
			return usergroupTos;
		}
		Collections.sort(usergroupTos, new Comparator<Object>()
		{
			//Sonar fix -- use override annotation on overridden method
			@Override
			public int compare(final Object o1, final Object o2)
			{
				final String obj1 = ((UserGroupTO) o1).getText().toUpperCase();
				final String obj2 = ((UserGroupTO) o2).getText().toUpperCase();

				if (obj1 == obj2)
					return 0;
				if (obj1 == null)
					return -1;
				if (obj2 == null)
					return 1;
				return obj1.compareTo(obj2);
			}
		});
		return usergroupTos;
	}

	/*public boolean addUserFolder(String userId, BasicDBObject inputJsonObjs)
	{

		UpdateOperations<User> ops = null;
		Query<User> query = null;
		User userObj = null;
		try
		{
			String folderName = inputJsonObjs.getString("folderName");
			subLogger.info("Inside UserDao.addUserFolder for userId= " + userId + " folderName=" + folderName);
			//Avoid Extra Spaces in the Folder Name
			folderName=folderName!=null?folderName.trim():folderName;
			if (!StringUtils.isEmpty(folderName))
			{
				ops = mongoDatastore.createUpdateOperations(User.class);

				// Find User Query
				query = mongoDatastore.createQuery(User.class).filter(
						"_id", userId);
				userObj = query.get();

				if (userObj != null && !StringUtils.isEmpty(folderName))
				{
					List<String> folders = userObj.getFolders();
					if (folders == null)
					{
						// First User Folder creation
						folders = new ArrayList<String>();
						folders.add(folderName);
						ops.set("folders", folders);
					}
					else
					{
						ops.add("folders", folderName, false);
					}
					mongoDatastore.update(query, ops);
				}
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getContextInfo", e);
			throw e;
		}
		return true;
	}*/

	public Boolean saveSignature(String soeId, BasicDBList inputJsonObjList) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("Inside UserDao.saveSignature for userId= " + soeId);
		Query<User> query = null;
		User userObj = null;
		Signature signature = null;
		List<Signature> signatureList = null;
		boolean isSignatureNewInqDefault = false;
		boolean isSignatureReplyDefault = false;
		String signatureNewInqDefaultValue = "";
		String signatureReplyDefaultValue = "";
		
		try
		{
			// save signature for the user
			query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
			userObj = query.get();
			if (userObj == null)
			{
				throw new CommunicatorException("No such user exists. Please contact Support.");
			}
			
			List<Preference> userPreferenceList = userObj.getPreferences();
			if(userPreferenceList!=null && !userPreferenceList.isEmpty()){
				for(Preference preference: userPreferenceList)
				{
					if("signatureNewInquiryId".equalsIgnoreCase(preference.getKey()))
					{
						signatureNewInqDefaultValue = preference.getValue();
					}
					else if("signatureReplyFwdId".equalsIgnoreCase(preference.getKey()))
					{
						signatureReplyDefaultValue = preference.getValue();
					}
				}
			}

			signatureList = new ArrayList<Signature>();
			for (Object inputJsonObj : inputJsonObjList)
			{
				String signatureName = ((BasicDBObject) inputJsonObj).getString(USER_VALIDATION_NAME_KEY);
				String signatureContent = ((BasicDBObject) inputJsonObj).getString("content");
				signature = new Signature(signatureName, signatureContent);
				signatureList.add(signature);
				//Check if any of the signature data is set as default.
				if(signatureName.equalsIgnoreCase(signatureNewInqDefaultValue))
				{
					isSignatureNewInqDefault = true;
				}
				
				if(signatureName.equalsIgnoreCase(signatureReplyDefaultValue))
				{
					isSignatureReplyDefault = true;
				}
			}
			
			//If the default signature is deleted, set the preference to None.
			if(!isSignatureNewInqDefault || !isSignatureReplyDefault)
			{
				userPreferenceList = unsetPreferenceValues(userPreferenceList,isSignatureNewInqDefault,isSignatureReplyDefault);
			}
			
			saveUserSignatureAndPreference(query, signatureList, userPreferenceList);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in saveSignature", e);
			throw new CommunicatorException("Exception in saveSignature");
		}
		return true;
	}

	/**
	 * @param query
	 * @param signatureList
	 * @param userPreferenceList
	 */
	private void saveUserSignatureAndPreference(Query<User> query, List<Signature> signatureList, List<Preference> userPreferenceList)
	{
		UpdateOperations<User> ops;
		if (!(signatureList.isEmpty()))
		{
			sortSignatureListByName(signatureList);
			
			ops = mongoDatastore.createUpdateOperations(User.class).set("signatures", signatureList).set(PREFERENCES, userPreferenceList);
		}
		else
		{
			ops = mongoDatastore.createUpdateOperations(User.class).unset("signatures").set(PREFERENCES, userPreferenceList);
		}
		mongoDatastore.update(query, ops);
	}

	/**
	 * @param signatureList
	 */
	private void sortSignatureListByName(List<Signature> signatureList)
	{
		//Sort by signature name
		signatureList.sort(new Comparator<Signature>()
		{
			public int compare(Signature signature1, Signature signature2)
			{

				String signatureName1 = signature1.getName().toUpperCase();
				String signatureName2 = signature2.getName().toUpperCase();

				// Sort ascending order
				return signatureName1.compareTo(signatureName2);
			}
		});
	}

	/**
	 * @param userPreferenceList
	 * @param isSignatureReplyDefault 
	 * @param isSignatureNewInqDefault 
	 * @return 
	 */
	private List<Preference> unsetPreferenceValues(List<Preference> userPreferenceList, boolean isSignatureNewInqDefault, boolean isSignatureReplyDefault)
	{
		for(Preference preference: userPreferenceList)
		{
			if(("signatureNewInquiryId".equalsIgnoreCase(preference.getKey()) && !isSignatureNewInqDefault) || ("signatureReplyFwdId".equalsIgnoreCase(preference.getKey()) && !isSignatureReplyDefault))
			{
				preference.setValue("None");
			}
		}
		
		return userPreferenceList;
	}

	public boolean saveUserDetail(String soeId, BasicDBObject inputJsonObjs) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			QMACache qmaCache = QMACacheFactory.getCache();
			Map<String, User> userInfoMap = qmaCache.getUserInfoMap();
			if (null == userInfoMap || soeId == null || null == userInfoMap.get(soeId.toUpperCase())) {
				subLogger.error("No Valid User found in QMA for {} ", soeId);
				throw new CommunicatorException("No Valid User found in QMA for soeId " + soeId);
			}
			List<Preference> userPrefList = new ArrayList<Preference>();
			// get All Preferences from UI code
			List<Preference> prefrence = (List<Preference>) inputJsonObjs.get("preference");
			String name = inputJsonObjs.getString(USER_VALIDATION_NAME_KEY);
			String emailId = inputJsonObjs.getString(EMAIL);
			boolean outOfOffice = inputJsonObjs.getBoolean(OUT_OF_OFFICE);
			boolean sendSecureEmail = inputJsonObjs.getBoolean(SEND_SECURE_EMAIL);
			boolean fitToMyResolution = inputJsonObjs.getBoolean(FIT_TO_MY_RESOLUTION);
			boolean disableAutoComplete = inputJsonObjs.getBoolean(DISABLE_AUTO_COMPLETE);
			boolean attachmentPwdProtectionFlag = inputJsonObjs.getBoolean(ATTACHMENT_PWD_PROTECTION_FLAG);
			BasicDBObject notifications =(BasicDBObject) inputJsonObjs.get(NOTIFICATIONS);
			BasicDBObject outOfOfficeSettings = (BasicDBObject) inputJsonObjs.get("outOfOfficeSettings");
			String isSymphonyEnabledForUser = null;
			if(null != inputJsonObjs.get("isSymphonyEnabledForUser")) {
				isSymphonyEnabledForUser = inputJsonObjs.getString("isSymphonyEnabledForUser");
			}
			
					
			if(outOfOfficeSettings != null) {
				String fromDate = "";
				if (null != outOfOfficeSettings.get(FROM_DATE_KEY)) {
					fromDate = outOfOfficeSettings.getString(FROM_DATE_KEY);
				}
				String toDate = "";
				if (null != outOfOfficeSettings.get(TO_DATE_KEY)) {
					toDate = outOfOfficeSettings.getString(TO_DATE_KEY);
				}
				outOfOfficeSettings = createOutOfOfficeSettings(outOfOfficeSettings);
				boolean outOfOfficeWithinDate = checkOutOfOfficeDate(outOfOfficeSettings, soeId);
				outOfOffice = outOfOfficeWithinDate;
				if(null != outOfOfficeSettings.get("notifyMyManager") && outOfOfficeSettings.getBoolean("notifyMyManager")
						&& null != outOfOfficeSettings.get(OUT_OF_OFFICE) && outOfOfficeSettings.getBoolean(OUT_OF_OFFICE))
				{
					sendEmailToManager(soeId, outOfOfficeSettings, fromDate, toDate);
				}
			}
			
			// Personal section - values
			Boolean isCalendarSubscribed = inputJsonObjs.getBoolean("isCalendarSubscribed");
			Boolean isPersonalEmailSubscribed = inputJsonObjs.getBoolean("isPersonalEmailSubscribed");
			Boolean isPersonalInfoEditedFlag = inputJsonObjs.getBoolean("isPersonalInfoEditedFlag");
			
			String exchPassword = null;
			String exchPasswordIV = null;
			if (null != inputJsonObjs.get("exchPassword")) {
				String encodedPwd = inputJsonObjs.getString("exchPassword");
				try {
					if (StringUtils.isNotBlank(encodedPwd)) {
						byte[] decodeExchPassword = Base64.getDecoder().decode(encodedPwd);
						String decodeExchPasswordStr = new String(decodeExchPassword, StandardCharsets.UTF_8);
						String[] encyptedPwd = encryptDecryptUtil.encryptInputString(decodeExchPasswordStr);

						if (null != encyptedPwd && encyptedPwd.length == 2) {
							exchPassword = encyptedPwd[0];
							exchPasswordIV = encyptedPwd[1];
						}
					}
				} catch (Exception ex) {
					subLogger.error("Exception in decoding and ecrypting the password ", ex);
				}
			}

			String exchUrl = null;
			if (null != inputJsonObjs.get("exchUrl")) {
				exchUrl = inputJsonObjs.getString("exchUrl");	
			}
			
			String exchDomain = null;
			if (null != inputJsonObjs.get("exchDomain")) {
				exchDomain = inputJsonObjs.getString("exchDomain");
			}
			
			subLogger.info("Inside UserDao.saveUserDetail for userId= " + soeId + " ,name=" + name + ", email=" + emailId);
			if (StringUtils.isBlank(name) || StringUtils.isBlank(emailId))
			{
				throw new CommunicatorException("Invalid Input for  saveUserDetail");
			}
			String key;
			String value;
			for (Object obj : prefrence)
			{
				DBObject uiPref = (DBObject) obj;
				key = (String) uiPref.get("key");
				value = (String) uiPref.get("value");
				Preference newPref = new Preference(key, value);
				userPrefList.add(newPref);
			}

			if(Objects.nonNull(userProfileMap) && Objects.nonNull(userProfileMap.get(soeId))) {
				subLogger.info("Restoring the User Name and Email as UI does not allows to change it.");
				UserTO userProfile = userProfileMap.get(soeId);
				name = userProfile.getUserName();
				emailId = userProfile.getEmail();
			}

			Query<User> query = mongoDatastore.createQuery(User.class).filter(
					"_id", soeId);
			UpdateOperations<User> ops = mongoDatastore.createUpdateOperations(User.class);
			ops.set(PREFERENCES, userPrefList);
			ops.set(USER_VALIDATION_NAME_KEY, name);
			ops.set(EMAIL, emailId);
			ops.set(OUT_OF_OFFICE, outOfOffice);
			ops.set(SEND_SECURE_EMAIL, sendSecureEmail);
			ops.set(FIT_TO_MY_RESOLUTION, fitToMyResolution);
			ops.set(DISABLE_AUTO_COMPLETE, disableAutoComplete);
			ops.set(ATTACHMENT_PWD_PROTECTION_FLAG, attachmentPwdProtectionFlag);
			if (notifications != null) {
				ops.set(NOTIFICATION_SETTINGS, notifications);
			}
			if (outOfOfficeSettings != null) {
				ops.set("outOfOfficeSettings", outOfOfficeSettings);
			}
			if (null != isSymphonyEnabledForUser) {
				ops.set("isSymphonyEnabledForUser", isSymphonyEnabledForUser);
			}
			if (null != isCalendarSubscribed) {
				ops.set("isCalendarSubscribed", isCalendarSubscribed);
			}

			if (null != isPersonalEmailSubscribed) {
				ops.set("isPersonalEmailSubscribed", isPersonalEmailSubscribed);
			}

			if(isPersonalInfoEditedFlag) {
				ops.set("isPersonalAccountActive", true);
				ops.set("isAuthenticationExpired", false);
			}

			if (null != exchUrl) {
				ops.set("exchUrl", exchUrl);
			}

			if (null != exchDomain) {
				ops.set("exchDomain", exchDomain);
			}
			
			mongoDatastore.update(query, ops);
			//Refresh userProfileMap with latest Details
			if(userProfileMap!=null && userProfileMap.get(soeId) !=null){
				UserTO userProfile=userProfileMap.get(soeId);
				userProfile.setPreferences(userPrefList);
				userProfileMap.put(soeId,userProfile);
			}
			
			// Get the MailBoxDLMapping and Update the MailBoxDLMapping
			MailBoxDLMapping mailBoxDLMapping = readerUtil.getMappingById(soeId);
			if (null != mailBoxDLMapping ) {
				if(isPersonalInfoEditedFlag && (Boolean.TRUE.equals(isPersonalEmailSubscribed) || Boolean.TRUE.equals(isCalendarSubscribed))) {
					mailBoxDLMapping.setConnectionURL(exchUrl);
					mailBoxDLMapping.setRegion(exchDomain);

					if (StringUtils.isNotEmpty(exchPassword)) {
						mailBoxDLMapping.setLoginSecretEnc(exchPassword);
						mailBoxDLMapping.setLoginSecretEncIV(exchPasswordIV);
						mailBoxDLMapping.setAuthenticationExpired(false); //This param will be used to personal db for starting mailbox
						mailBoxDLMapping.setToBeForceStarted(true); //This param will be used to personal db for starting mailbox
					}
					readerUtil.updateMailBoxMapping(mailBoxDLMapping);
					HazelCastCacheIncrementalLoad.refreshMailBoxDLMappings(soeId);
				}
			} else {
				if(isPersonalInfoEditedFlag && (Boolean.TRUE.equals(isPersonalEmailSubscribed) || Boolean.TRUE.equals(isCalendarSubscribed)) ) {
					addMailBoxDLMappingForUser(soeId,exchUrl,exchDomain,exchPassword,exchPasswordIV);
					HazelCastCacheIncrementalLoad.refreshMailBoxDLMappings(soeId);
				}
			}
			
			// Add the group if personal mail box is subscribed
			if (Boolean.TRUE.equals(isPersonalEmailSubscribed) && null != QMACacheFactory.getCache().getPersonalMailboxIdToGroupIdMap()) {
				Map<String, Long> personalMailboxIdToGroupIdMap = QMACacheFactory.getCache().getPersonalMailboxIdToGroupIdMap();
				subLogger.debug("From Hazelcast getPersonalMailboxIdToGroupIdMap:"+personalMailboxIdToGroupIdMap.size());
				if (!personalMailboxIdToGroupIdMap.containsKey(soeId)) {
					addPersonalGroup(soeId, name, emailId);
					//Sync xmc db user with personal db
					syncSmartCategoryMetadataForUser(soeId);
				}
			}

			if(isPersonalInfoEditedFlag) {
				syncUserDetailsToPersonalDb(soeId);
			}

			// C153176-6103 | Refresh the cache to all the servers.
			// CacheDAO.getInstance().reloadDbCollectionFromServer("cache");
			//CacheDAO.getInstance().getUserDetailsMap().get(soeId.toUpperCase()).setOutOfOffice(outOfOffice);
			//CacheDAO.getInstance().reloadUserDetailsMap();
			HazelCastCacheIncrementalLoad.refreshUserCache(soeId);
			
		}
		catch (Exception e)
		{
			subLogger.error("Exception in saveUserDetail", e);
			throw new CommunicatorException("Exception in saveUserDetail");
		}
		return true;
	}
	/**
	 * @param httpClient
	 * @param tokenEndPoint
	 * @return
	 */
	private String getAuthToken(HttpClient httpClient, String tokenEndPoint) {
		String qmaAuthorization = null;
		try {
			HttpGet getRequest = new HttpGet(tokenEndPoint);
			getRequest.addHeader(X_CITIPORTAL_LOGINID, QMA);
			HttpResponse response = httpClient.execute(getRequest);
			if (null != response) {
				Header[] auth = response.getHeaders(QMA_AUTHORIZATION);
				if(null != auth && auth.length > 0 ) {
					qmaAuthorization = auth[0].getValue();
				} else {
					subLogger.warn("Could not extrac QMA Authorization Token from Exchange Service.");
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception while getting auth token",e);
		}
		return qmaAuthorization;
	}

	/**
	 * @param soeId
	 */
	private void syncSmartCategoryMetadataForUser(String soeId) {
		try {
			Map<String, Object> qmaPersonalConfigMap = getQmaPersonalConfig();
			if (!qmaPersonalConfigMap.isEmpty()&& null != qmaPersonalConfigMap.get(TOKEN_END_POINT) && null != qmaPersonalConfigMap.get(SMART_CATEGORY_META_DATA_SYNC_END_POINT)){
				String tokenEndPoint = (String) qmaPersonalConfigMap.get(TOKEN_END_POINT);
				String smartCategoryMetaDataSyncEndPoint = (String) qmaPersonalConfigMap.get(SMART_CATEGORY_META_DATA_SYNC_END_POINT);
				HttpClient httpClient = HttpClientBuilder.create().build();
				String authToken = getAuthToken(httpClient, tokenEndPoint);
				if (!StringUtils.isEmpty(authToken)) {
					String response = startSync(httpClient, authToken, smartCategoryMetaDataSyncEndPoint,soeId);
					subLogger.info("dataSyncForUser: {}", (response.equals(TRUE)? "SUCCESS":"FAILED"));
				} else {
					subLogger.info("Auth token is null or empty");
				}
			} else {
				subLogger.info("smartCategoryMetaDataSyncEndPoint are missing in QmaPersonalConfig.");
			}
		}catch(Exception e) {
			subLogger.error("Exception in UserDAO#dataSyncBySoeId:{}", e);
		}	
	}
	/**
	 * @param httpClient
	 * @param token
	 * @param smartCategoryMetaDataSyncEndPoint
	 * @param soeId
	 * @return
	 */
	private String startSync(HttpClient httpClient, String token, String smartCategoryMetaDataSyncEndPoint, String soeId) {
		String extractedResponse = null;
		smartCategoryMetaDataSyncEndPoint = smartCategoryMetaDataSyncEndPoint+"/"+soeId;
		HttpGet getRequest = new HttpGet(smartCategoryMetaDataSyncEndPoint);
		getRequest.addHeader(X_CITIPORTAL_LOGINID, QMA);
		getRequest.addHeader(QMA_AUTHORIZATION, token);
		HttpResponse httpResponse = null;
		try {
			httpResponse = httpClient.execute(getRequest);
			if (null != httpResponse && null != httpResponse.getStatusLine() && httpResponse.getStatusLine().getStatusCode() != 200) {
				subLogger.warn("Request is not successful, status code :{}", httpResponse.getStatusLine().getStatusCode());
			} else {
				extractedResponse = extractResponse(httpResponse.getEntity());
			}
		} catch (IOException e) {
			subLogger.warn("Request is not successful, status code :{}",(null != httpResponse && null != httpResponse.getStatusLine())	? httpResponse.getStatusLine().getStatusCode(): "N/A");
		}
		return extractedResponse;
	}
	/**
	 * @param entity
	 * @return
	 */
	private String extractResponse(HttpEntity entity) {
		StringBuilder content = new StringBuilder();
		if (entity != null) {
			byte[] buffer = new byte[1024];
			InputStream inputStream = null;
			try {
				inputStream = entity.getContent();
			} catch (UnsupportedOperationException | IOException e) {
				subLogger.error("Exception while extracting response", e);
			}
			try (BufferedInputStream bis = new BufferedInputStream(inputStream)) {
				int bytesRead = 0;
				while ((bytesRead = bis.read(buffer)) != -1) {
					String chunk = new String(buffer, 0, bytesRead);
					content.append(chunk);
				}
			} catch (Exception e) {
				subLogger.error(" Error in SyncSmartCategoryMetaDataJob#extractResponse() :", e);
			}
		} else {
			subLogger.warn("Received either 'null' or 'empty' resposne from qma-exchange-services. Please validate qma-exchange-service logs.");
		}
		return content.toString();
	}
	/**
	 * @return
	 */
	private Map<String, Object> getQmaPersonalConfig() {
		Map<String, Object> qmaPersonalConfigMap = null;
		try {
			QMACache qmaCache = QMACacheFactory.getCache();
			if (null != qmaCache.getQmaPersonalConfig()) {
				qmaPersonalConfigMap = qmaCache.getQmaPersonalConfig();
			}
		} catch (Exception ex) {
			subLogger.error("Exception while getting qmaPersonalConfig from cache.", ex);
		}
		return qmaPersonalConfigMap;
	}
	/**
	 * Method to add personal group.
	 * 
	 * @param soeId
	 * @param name
	 * @param emailId
	 */
	private void addPersonalGroup(String soeId, String name, String emailId) {
		// Method to add new group.
		Group grp = new Group();
		grp.setActive(Boolean.TRUE);
		grp.setGroupType("personal");
		grp.setPersonalMailboxId(soeId);
		grp.setGroupName(name);
		grp.setGroupEmail(emailId);
		grp.setTags(Arrays.asList(new String[] {}));

		// Exchange related information.
		List<ExchangeFolder> exchFolder = new ArrayList<>();
		grp.setExchFolders((List) exchFolder);
		grp.setExchFolderHierarchySyncState(null);
		grp.setExchEmailSyncState(null);
		grp.setRequestTypes(Arrays.asList(new String[] {PERSONAL_EMAIL_REQUEST_TYPE}));
		com.citi.icg.qma.common.server.dao.HighlevelRequestType highlevelRequestType = new com.citi.icg.qma.common.server.dao.HighlevelRequestType();
		highlevelRequestType.setRequestType(PERSONAL_EMAIL_REQUEST_TYPE);
		highlevelRequestType.setHighlevelRequestType(HIGH_LEVEL_REQ_TYPE_GENERAL_QUERY);
		List<com.citi.icg.qma.common.server.dao.HighlevelRequestType> highlevelRequestTypeList = new ArrayList<com.citi.icg.qma.common.server.dao.HighlevelRequestType>();
		highlevelRequestTypeList.add(highlevelRequestType);
		grp.setRequestTypeMappings(highlevelRequestTypeList);
		grp.setCrtBy(soeId);
		grp.setModBy(soeId);
		List<String> allGroupEmails = new ArrayList<String>();
		allGroupEmails.add(soeId+"@XXXX.net");
		allGroupEmails.add(soeId+"@XXXX.com");
		allGroupEmails.add(soeId+"@XXXX.com");
		grp.setAllGroupEmailsFromCIMS(allGroupEmails);
		Date d = new Date();
		grp.setCrtDate(d);
		grp.setModDate(d);

		mongoDatastore.save(grp);

		//Assign the user to this group as group admin.
		groupDAO.assignUserToGroup(soeId, grp.id);
		
		//Refresh hazelcast group maps
		HazelCastCacheIncrementalLoad.refreshGroupInCache(grp.id);
	}

	private boolean checkOutOfOfficeDate(BasicDBObject outOfOfficeSettings, String soeId) {
		boolean checkOutOfOfficeDate = false;
		try {
			if (StringUtils.isNotEmpty(outOfOfficeSettings.getString(FROM_DATE_KEY)) && null != outOfOfficeSettings.get(FROM_DATE_KEY)) {
				Date fromDate = outOfOfficeSettings.getDate(FROM_DATE_KEY);
				Date sysDate = new Date();
				if (sysDate.compareTo(fromDate) >= 0 && null != outOfOfficeSettings.get(OUT_OF_OFFICE)
						&& outOfOfficeSettings.getBoolean(OUT_OF_OFFICE)) {
					checkOutOfOfficeDate = true;
					inquiryDAO.resetInquiryAssignmentForOOO(soeId);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception while checking OutOfOfficeDate", e);
		}
		return checkOutOfOfficeDate;
	}

	private void sendEmailToManager(String soeId, BasicDBObject outOfOfficeSettings, String fromDate,String toDate) {
		try {
			Query<User> query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
			List<User> user = query.asList();
			if (!user.isEmpty() && user.get(0) != null && null != user.get(0).getMgrEmail() && null != user.get(0).getEmail()) {
				String emailToRecipients = user.get(0).getMgrEmail();
				String from = user.get(0).getEmail();
				String subject = "OOO-" + user.get(0).getName()+ " " + fromDate + "-"+ toDate;
				String emailContent = outOfOfficeSettings.getString("responseTemplate");
				subLogger.info("Sending mail to manager : {} ; with subject: {} ;", emailToRecipients, subject);
				MailUtil.sendMail(from, subject, emailContent, true, null, emailToRecipients);
			}else {
				subLogger.info("Manager details are missing for userId:"+soeId);
			}
		} catch (Exception e) {
			subLogger.error("Error while sending email to manager" + e);
		}
	}

	public UserTO getUserData(String soeid, BasicDBObject inputJsonObj) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{

		subLogger.info("Inside UserDAO:getUserData - soeId= " + soeid + ", Input= " + inputJsonObj);

		User user = null;
		Query<User> query = null;
		UserTO userInfo = null;

		try
		{
			String userId = inputJsonObj.getString(USERID);
			
			//User ID Null Check 
			if(StringUtils.isBlank(userId))
			{
				subLogger.error("Invalid Input for getUserData- userId="+userId);
				throw new CommunicatorException("Invalid Input for getUserData- userId="+userId);
			}
			/*else
			{
				
				userId = userId.toLowerCase();
			}*/
			
			query = mongoDatastore.createQuery(User.class).filter("_id", userId.toLowerCase());
			user = query.first();
			if (user != null && user.getName() != null)
			{
				userInfo = new UserTO();
				userInfo.setUserId(user.getId());
				userInfo.setUserName(user.getName());
				userInfo.setEmail(user.getEmail());
				userInfo.setActive(user.getActive());
				userInfo.setPsL5(user.getPsL5());
				userInfo.setPsL6(user.getPsL6());
				userInfo.setPsL7(user.getPsL7());
				userInfo.setMsL6(user.getMsL6());
                userInfo.setGdActive(user.isGdActive());
				
				//Group roles to be added as a part of getUserData
				List<GroupRoleTO> rolesTO = new ArrayList<GroupRoleTO>();

				if (user.getGroupRoles() != null)
				{
					List<GroupRole> roles = user.getGroupRoles();

					for (GroupRole role : roles)
					{
						GroupRoleTO roleTo = new GroupRoleTO();
						roleTo.setGroupName(QMACacheFactory.getCache().getGroupIdToDBCodeMap().get(role.getGroupId() + ""));
						roleTo.setGroupRole(role.getRole());
						rolesTO.add(roleTo);
					}

				}
				userInfo.setGroupRoles(rolesTO);

				if(user.getAdminRoles()!=null)
					userInfo.setAdminRoles(user.getAdminRoles());

				userInfo.setPersonalEmailSubscribed(user.isPersonalEmailSubscribed());
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in UserDAO:getUserData", e);
			throw new CommunicatorException("Exception in UserDAO:getUserData");
		}

		return userInfo;
	}
	
	//Method to edit user folder. Replace the existing folder in User collection & Inquiry collection
	/* This is replaced by Tags
	public boolean editUserFolder(String userId, BasicDBObject inputJsonObjs) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		
		boolean success = true;
		DBCollection userCollection = null;
		DBCollection inquiryCollection = null;		
		
		try
		{
			String folderName = inputJsonObjs.getString("folderName");
			String newFolderName = inputJsonObjs.getString("newFolderName");
			subLogger.info("Inside UserDao.editUserFolder for userId= " + userId + " folderName=" + folderName);

			//If the folder name is invalid, stop processing further.
			if(StringUtils.isBlank(folderName) || StringUtils.isBlank(newFolderName))
			{
				subLogger.error("Invalid input for editUserFolder for user=" + userId);
				throw new CommunicatorException("Invalid input for editUserFolder.");
			}
			
			//Step 1 : Find the user collection and change the folder name.
			userCollection = mongoDatastore.getCollection(User.class);
			
			BasicDBObject userFolderObj = new BasicDBObject();
			userFolderObj.put("folders", folderName);
			
			DBObject updateUserFolderObj = new BasicDBObject();
			updateUserFolderObj.put("$set",new BasicDBObject("folders.$",newFolderName));
			
			userCollection.updateMulti(userFolderObj, updateUserFolderObj);
			
			//Step 2: Find the inquiry collections having the folder name and rename it.
			inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
			
			BasicDBObject folderObj = new BasicDBObject();
			folderObj.put(USERID, userId);
			folderObj.put("folderName", folderName);
			
			BasicDBObject filterInqQuery = new BasicDBObject();
			filterInqQuery.put("userFolders", new BasicDBObject("$elemMatch", folderObj));
			
			DBObject updateinquiryFolderObj = new BasicDBObject();
			updateinquiryFolderObj.put("$set",new BasicDBObject("userFolders.$.folderName",newFolderName));
			
			inquiryCollection.updateMulti(filterInqQuery, updateinquiryFolderObj);
			
		}
		catch (Exception e)
		{
			subLogger.error("Exception in editUserFolder", e);
			throw new CommunicatorException("Exception in editUserFolder");
		}
		
		return success;
	}

	
	 public boolean deleteUserFolder(String userId, BasicDBObject inputJsonObjs) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{

		UpdateOperations<User> ops = null;
		Query<User> query = null;
		User userObj = null;
		DBCollection inquiryCollection = null;

		try
		{
			String folderName = inputJsonObjs.getString("folderName");
			subLogger.info("Inside UserDao.deleteUserFolder for userId= " + userId + " folderName=" + folderName);

			// If the folder name is invalid, stop processing further.
			if (StringUtils.isBlank(folderName))
			{
				subLogger.error("Invalid input for deleteUserFolder for user=" + userId);
				throw new CommunicatorException("Invalid input for deleteUserFolder.");
			}
			ops = mongoDatastore.createUpdateOperations(User.class);

			// Step 1: Find the user collection and remove the folder.
			query = mongoDatastore.createQuery(User.class).filter("_id", userId);
			userObj = query.get();

			if (userObj != null)
			{
				if (!StringUtils.isEmpty(folderName))
				{
					ops.removeAll("folders", folderName);
				}
				mongoDatastore.update(query, ops);
			}

			// Step 2: Find the inquiries containing the folder name and unset them.
			inquiryCollection = mongoDatastore.getCollection(Inquiry.class);

			BasicDBObject folderObj = new BasicDBObject();
			folderObj.put(USERID, userId);
			folderObj.put("folderName", folderName);

			BasicDBObject filterInqQuery = new BasicDBObject();
			filterInqQuery.put("userFolders", new BasicDBObject("$elemMatch", folderObj));

			DBObject updateinquiryFolderObj = new BasicDBObject();
			updateinquiryFolderObj.put("$pull", new BasicDBObject("userFolders", folderObj));

			inquiryCollection.updateMulti(filterInqQuery, updateinquiryFolderObj);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getContextInfo", e);
			throw new CommunicatorException("Exception in getContextInfo");
		}
		return true;
	}*/
	
	public boolean saveUserAdminDetails(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException
	{
		UpdateOperations<User> ops = null;
		Query<User> query = null;
		User userObj = null;
		try
		{
			
			subLogger.info("Inside UserDao.saveUserAdminDetails for saving user admin details by {} ",soeId);
			QMACache qmaCache = QMACacheFactory.getCache();
			Map<String, User> userInfoMap = qmaCache.getUserInfoMap();
			if (null == userInfoMap || soeId == null || null == userInfoMap.get(soeId.toUpperCase())) {
				subLogger.error("No Valid User found in QMA for {} ", soeId);
				throw new CommunicatorException("No Valid User found in QMA for soeId " + soeId);
			}

			//Below check is updated because UI code allows User Admin screen and functions if user is having 'IS Admin' role or member added in Config.AdminRoles.userAdmin list.
			Config adminRoleConfig = qmaCache.getConfigById("AdminRoles");
			List<String> userAdminUserList = Objects.nonNull(adminRoleConfig)  && Objects.nonNull(adminRoleConfig.getUserAdmin()) ? adminRoleConfig.getUserAdmin() : new ArrayList<>();
			boolean hasAdminRole = Objects.nonNull(qmaCache.getUserInfoMap().get(soeId.toUpperCase()).getAdminRoles()) && qmaCache.getUserInfoMap().get(soeId.toUpperCase()).getAdminRoles().contains("IS Admin");
			hasAdminRole = !hasAdminRole ? userAdminUserList.contains(soeId) : hasAdminRole;
			if (! hasAdminRole) {
				subLogger.error("User {} doesn't have privilege to perform this action ", soeId);
				throw new CommunicatorException("User: " + soeId +" doesn't have privilege to perform this action");
			}

			String userId = inputJsonObj.getString(USERID);
			if(StringUtils.isNotBlank(userId)) {
				userId = userId.trim();
			}
			String userName = inputJsonObj.getString("userName");
			if(StringUtils.isNotBlank(userName)) {
				userName = userName.trim();
			}
			String userMail = inputJsonObj.getString("userEmail");
			if(StringUtils.isNotBlank(userMail)) {
				userMail = userMail.trim();
			}
			BasicDBList adminRoles =  (BasicDBList) inputJsonObj.get("adminRole");
			Boolean active = inputJsonObj.getBoolean(ACTIVE);
			
			if(StringUtils.isBlank(userId) || StringUtils.isBlank(userName) || StringUtils.isBlank(userMail))
			{
				subLogger.error("Invalid input for save admin details for user=" + userId);
				throw new CommunicatorException("Invalid input for saveUserAdminDetails.");
			}
			else
			{
				//convert to lowercase before saving
				userId = userId.toLowerCase();
			}
			
			query = mongoDatastore.createQuery(User.class).filter("_id", userId);
			userObj = query.get();
			
			if (userObj != null)
			{
				ops = mongoDatastore.createUpdateOperations(User.class);
				if(!active) {
					adminRoles = new BasicDBList();
				}
				ops.set(ADMIN_ROLES, adminRoles);
				ops.set(ACTIVE, active);
				
				// if Termination request comes from GIAM/EERS, we have to remove all group access for that specific user

				if(inputJsonObj.containsKey(REMOVE_LOGIN_KEY) && "true".equalsIgnoreCase(inputJsonObj.getString(REMOVE_LOGIN_KEY))) {
					ops.set(GROUP_ROLES, new BasicDBList());
				}
				
				mongoDatastore.update(query, ops);
			}
			else if(userObj == null)
			{
				User user = new User();
				user.setEmail(userMail);
				user.setId(userId);
				user.setName(userName);
				user.setCrtBy(soeId);
				user.setCrtDate(new Date());
				user.setActive(true);
				//Default Signature is set a blank
				user.setSignatures(new ArrayList<Signature>());
				if(adminRoles!=null && !adminRoles.isEmpty())//Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
				{
					List<String> admRole = new ArrayList<String>();
					for(Object adminRole:adminRoles)
					{
						admRole.add((String) adminRole);
					}
					user.setAdminRoles(admRole);
				}
				
				mongoDatastore.save(user);
			}
			updateUserAdminAuditLogs(soeId,  inputJsonObj, userObj);
			//CacheDAO.getInstance().reloadUserDetailsMap();
			HazelCastCacheIncrementalLoad.refreshUserCache(userId);
			
		}catch(Exception e){
			subLogger.error("Exception in UserDao.saveUserAdminDetails", e);
			throw new CommunicatorException(e.getMessage());
		}
		
		return true;
	}
	
	/**
	 * @param soeId
	 * @param inputJsonObj
	 * @param userObj
	 * @throws CommunicatorException
	 * Based on action prepare the data for UserAdminAudit Update
	 */
	public void updateUserAdminAuditLogs(String soeId, BasicDBObject inputJsonObj, User userObj)throws CommunicatorException
	{
		subLogger.info("Inside updateUserAdminAuditLogs for saving user admin Audit details");
		BasicDBList updatedAdminRoles = (BasicDBList) inputJsonObj.get(ADMIN_ROLE);
		Boolean updatedActiveFlag = inputJsonObj.getBoolean(ACTIVE);
		String actionPerformedOn = (String) inputJsonObj.get(USERID);
		
		StringBuilder action = new StringBuilder();
		StringBuilder change = new StringBuilder();
		StringBuilder previousValue  = new StringBuilder();
		StringBuilder newValue = new StringBuilder();
		StringBuilder comment = new StringBuilder();
		
		boolean userReactivated = false;
		//Update/Edit Action 
		if (null!=userObj) 
		{
			// Update user active flag
			if (null != userObj.getActive() )
			{
				if (!userObj.getActive().equals(updatedActiveFlag))
				{
					action = userObj.getActive()?action.append(ISA_USER_DISABLED):action.append(CREATE_ACTION);
					if(updatedActiveFlag) {
						userReactivated = true;
						change = change.append(USER_ADDED);			
						newValue = null != updatedAdminRoles && !updatedAdminRoles.isEmpty() ? newValue.append(GenericUtility.creatStringFromBasicDBList(updatedAdminRoles)):newValue.append("Business User");
						previousValue.append("");
						comment = comment.append(NEW_USER_ADDED);	
					} else {
						change =  change.length()>0 ? change.append(","+USER_DISABLED):change.append(USER_DISABLED);			
						previousValue = previousValue.length()>0 ?previousValue.append(",").append(userObj.getActive()):previousValue.append(userObj.getActive());
						newValue = newValue.length()>0 ? newValue.append(",").append(updatedActiveFlag):newValue.append(updatedActiveFlag);
						comment = change;
					}
						
				}
			}	
			else 
			{
				userReactivated = true;
				action =action.append(CREATE_ACTION);
				change = change.append(USER_ADDED);
				//newValue = newValue.append("");
				newValue = null != updatedAdminRoles && !updatedAdminRoles.isEmpty() ? newValue.append(GenericUtility.creatStringFromBasicDBList(updatedAdminRoles)):newValue.append("Business User");
				previousValue.append("");
				comment = comment.append(NEW_USER_ADDED);	
				
			}
			if(!userReactivated) {
			// Update admin role
			if (null!= userObj.getAdminRoles()) 
			{
				if (!userObj.getAdminRoles().equals(updatedAdminRoles))
				{
					action =action.length()>0 ? action.append(","+ISA_EDITUSER) : action.append(ISA_EDITUSER);
					change = change.length()>0 ? change.append(","+ACCESS):change.append(ACCESS);
					newValue = newValue.length()>0 ? newValue.append(",").append(GenericUtility.creatStringFromBasicDBList(updatedAdminRoles)):newValue.append(GenericUtility.creatStringFromBasicDBList(updatedAdminRoles));
					previousValue = previousValue.length()>0 ?previousValue.append(",").append(GenericUtility.createStringFromListofString(userObj.getAdminRoles())):previousValue.append(GenericUtility.createStringFromListofString(userObj.getAdminRoles()));
					comment = comment.length()>0 ? comment.append(",").append(ENTITLEMENT_CHANGED):comment.append(ENTITLEMENT_CHANGED);
				} 
				else if (updatedActiveFlag && userObj.getAdminRoles().isEmpty() && updatedAdminRoles.isEmpty())
				{
					action =action.length()>0 ? action.append(","+ISA_EDITUSER) : action.append(ISA_EDITUSER);
					change = change.length()>0 ? change.append(","+ACCESS):change.append(ACCESS);
					newValue = newValue.length()>0 ? newValue.append(",").append("Business User"):newValue.append("Business User");
					previousValue = previousValue.length()>0 ?previousValue.append(",").append(GenericUtility.createStringFromListofString(userObj.getAdminRoles())):previousValue.append(GenericUtility.createStringFromListofString(userObj.getAdminRoles()));
					comment = comment.length()>0 ? comment.append(",").append(ENTITLEMENT_CHANGED):comment.append(ENTITLEMENT_CHANGED);
				}
			}
			else
			{
				if(null != updatedAdminRoles && !updatedAdminRoles.isEmpty()) {
					action =action.length()>0 ? action.append(","+ISA_EDITUSER) : action.append(ISA_EDITUSER);
					change = change.length()>0 ? change.append(","+ACCESS):change.append(ACCESS);
					newValue = newValue.length()>0 ? newValue.append(",").append(GenericUtility.creatStringFromBasicDBList(updatedAdminRoles)):newValue.append(GenericUtility.creatStringFromBasicDBList(updatedAdminRoles));
					if(null != userObj.getAdminRoles()) {
						previousValue = previousValue.length()>0 ?previousValue.append(",").append(GenericUtility.createStringFromListofString(userObj.getAdminRoles())):previousValue.append(GenericUtility.createStringFromListofString(userObj.getAdminRoles()));
					} else {
						previousValue = previousValue.length()>0 ?previousValue.append(",").append(GenericUtility.createStringFromListofString(new ArrayList<String>())):previousValue.append(GenericUtility.createStringFromListofString(new ArrayList<String>()));
					}
					comment = comment.length()>0 ? comment.append(",").append(ENTITLEMENT_CHANGED):comment.append(ENTITLEMENT_CHANGED);
				} 
				else if(updatedActiveFlag && null != updatedAdminRoles && updatedAdminRoles.isEmpty()) {
					action =action.length()>0 ? action.append(","+ISA_EDITUSER) : action.append(ISA_EDITUSER);
					change = change.length()>0 ? change.append(","+ACCESS):change.append(ACCESS);
					newValue = newValue.length()>0 ? newValue.append(",").append("Business User"):newValue.append("Business User");
					if(null != userObj.getAdminRoles()) {
						previousValue = previousValue.length()>0 ?previousValue.append(",").append(GenericUtility.createStringFromListofString(userObj.getAdminRoles())):previousValue.append(GenericUtility.createStringFromListofString(userObj.getAdminRoles()));
					} else {
						previousValue = previousValue.length()>0 ?previousValue.append(",").append(GenericUtility.createStringFromListofString(new ArrayList<String>())):previousValue.append(GenericUtility.createStringFromListofString(new ArrayList<String>()));
					}
					comment = comment.length()>0 ? comment.append(",").append(ENTITLEMENT_CHANGED):comment.append(ENTITLEMENT_CHANGED);
				}
				
			}
			}
		}
		//Create new user Action
		else
		{
			action =action.append(CREATE_ACTION);
			change = change.append(USER_ADDED);
			//newValue = newValue.append("");
			newValue = null != updatedAdminRoles && !updatedAdminRoles.isEmpty() ? newValue.append(GenericUtility.creatStringFromBasicDBList(updatedAdminRoles)):newValue.append("Business User");
			previousValue.append("");
			comment = comment.append(NEW_USER_ADDED);
		}		
		updateUserAdminAudit( action.toString(), change.toString(), soeId, newValue.toString(),  previousValue.toString(), actionPerformedOn, comment.toString() );
		subLogger.info("UserAdminAudit updated");
	}
	
	
	/**
	 * @param action
	 * @param change
	 * @param actionPerformedBy
	 * @param newValue
	 * @param previousValue
	 * @param actionPerformedOn
	 * @param comment
	 * @throws CommunicatorException
	 * Update UserAdminAudit collection
	 */
	public void updateUserAdminAudit(String action, String change, String actionPerformedBy, String newValue, String previousValue, String  actionPerformedOn, String comment) throws CommunicatorException
	{
		try {
			UserAdminAudit userAdminAudit = new UserAdminAudit();
			userAdminAudit.setAction(action);
			userAdminAudit.setChange(change);
			userAdminAudit.setActionPerformedOn(actionPerformedOn);
			userAdminAudit.setComments(comment);
			userAdminAudit.setActionBy(actionPerformedBy);
			userAdminAudit.setCurrentValue(newValue);
			userAdminAudit.setPreviousValue(previousValue);
			userAdminAudit.setCrtDate(new Date());
			mongoDatastore.save(userAdminAudit);
		} 
		catch (Exception e) 
		{
			subLogger.error("Exception in UserDao.updateUserAdminAudit", e);
			throw new CommunicatorException("Exception in UserDao.updateUserAdminAudit");
		}
	}

	
	
	public boolean deleteUser(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one//Sonar Fix remove unused parameter
	{
		Query<User> query = null;
		User userObj = null;
		UpdateOperations<User> ops = null;
		try
		{
			subLogger.info("Inside UserDao.deleteUser for deleting user admin profile");
			String userId = inputJsonObj.getString(USERID);
			
			if(StringUtils.isBlank(userId))
			{
				subLogger.error("Invalid input for delete user for user=" + userId);
				throw new CommunicatorException("Invalid input for deleteUser.");
			}
			
			query = mongoDatastore.createQuery(User.class).filter("_id", userId);
			userObj = query.get();
			ops = mongoDatastore.createUpdateOperations(User.class);
			String action = ISA_USER_DISABLED;
			String actionDetails = "User Disabled";
			String comment = "User Disabled";
			String oldValue = "true";
			String newValue = "false";
			if (userObj != null)
			{
				ops.set(ACTIVE, false);
				//remove all roles once user is disabled or deleted
				BasicDBList adminRoles = new BasicDBList();
				ops.set(ADMIN_ROLES, adminRoles);
				mongoDatastore.update(query, ops);
				updateUserAdminAudit(action, actionDetails, soeId, newValue, oldValue, userId, comment);
				//CacheDAO.getInstance().reloadUserDetailsMap();
				HazelCastCacheIncrementalLoad.refreshUserCache(soeId);
				return true;
			}
			
			
		}catch(Exception e){
			subLogger.error("Exception in UserDao.deleteUser", e);
			throw new CommunicatorException("Exception in UserDao.deleteUser");
		}
		
		return false;
	}
	
	public UserTO getUserDataAdmin(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("Inside UserDao.getUserDataAdmin for getting user data");
		//Step1: call the xmc db getuserdata
		UserTO user = getUserData(soeId, inputJsonObj);
		
		try
		{
			if(user==null)
			{
				//Step 2: Call CIMS Webservice and get the user data
				//List<CorporateAddressBookTO> userList = addressBookDAO.getUserDetailsBySoeId(inputJsonObj);
				List<CorporateAddressBookTO> userList = CimsDAO.getInstance().getUserDetailsBySoeId(inputJsonObj);
				
				if(userList!=null && !(userList.isEmpty()) && userList.get(0)!=null)
				{
					String userId = inputJsonObj.getString(USERID);
					user = new UserTO();
					user.setUserId(userId);
					user.setUserName(userList.get(0).getName());
					user.setEmail(userList.get(0).getEmail());
					user.setLongDesc(userList.get(0).getLongDesc());
				}
				else if(userList==null)
				{
					subLogger.error("User not found in both cims and xmc");				
				}
			}
		}
		catch(Exception e)
		{
			subLogger.error("Exception occurred in CIMS Webservice call",e);
		}
		
		return user;
	}
	
	// Get the User details based on group id
	public List<UserTO> getGroupMemberListDetails(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		List<UserTO> userNameList = null;
		subLogger.info("Inside UserDao.getGroupMemberListDetails with soeid" + soeId + " and input data " + inputJsonObj);
		
		try
		{
		    String groupName = inputJsonObj.getString(GROUP_NAME_FIELD);
            Group dbGroup = null;

            if(groupName!=null)
            {
                GroupDAO groupDao = new GroupDAO();
                dbGroup = groupDao.getGroupInfo(groupName); 
            }

            if (groupName == null || dbGroup == null )
            {
                subLogger.error("Incorrect input request details with groupName:" + groupName);
            }
            else
            {
            	boolean cimsNewEndPoint = CimsDAO.getInstance().isCimsRestApiEnable();
            	if(cimsNewEndPoint) {
					Map<String, String> dlMembersMap = CimsDAO.getInstance().getDistributionListMembersbyMail(dbGroup.getGroupEmail(),
							"1", "1");
					if (dlMembersMap.size() == 0) {
						return userNameList;
					}
					userNameList = new ArrayList<UserTO>();
					for (Entry<String, String> entry : dlMembersMap.entrySet()) {
						UserTO userDetail = new UserTO();
						userDetail.setUserName(entry.getValue());
						userDetail.setEmail(entry.getKey());
						userNameList.add(userDetail);
					}
            	} 
            }
				
		}
		catch (Exception e)
		{
			subLogger.error("Exception in UserDao.getGroupMemberListDetails", e);
			throw new CommunicatorException("Exception in UserDao.getGroupMemberListDetails");
		}

		return userNameList;
	}

	/*
	 * ________________________________________Private methods starts here ___________________________________
	 */
	private List<ViewTO> getUserViewTOList(List<ViewConfig> views)
	{
		List<ViewTO> viewTOList = null;

		if (views == null || views.isEmpty())
		{
			return viewTOList;
		}
		viewTOList = new ArrayList<ViewTO>();
		for (ViewConfig viewConfig : views)
		{
			if (!StringUtils.isEmpty(viewConfig.getViewName()))
			{
				//Need view columns information as a part of userinfo.
				viewTOList.add(new ViewTO(viewConfig.getViewName(), viewConfig.getColumnsToShow()));
			}
		}

		//subLogger.info("User view information = "+viewTOList);
		return viewTOList;
	}

	/*private String getWebsocketHost()
	{
		//Sonar Fix remove unused variable
	//	String host = null;
	//	host = CacheDAO.getInstance().getDefaultStaticData().getMainWebsocketListenerHost();
		String appserverurl = System.getProperty("appserverurl");
		String wsHostURL = "wss://" + appserverurl + "/QMA/inquiryActions";
		subLogger.info("wsHostURL is: " + wsHostURL);
		return wsHostURL;
	}*/

	private List<GroupRoleTO> getUserGroupRole(List<GroupRole> groupRoles)
	{
		List<GroupRoleTO> usrGrpRoleTOs = new ArrayList<GroupRoleTO>();
		try
		{
			subLogger.info("Inside UserDao.getUserGroupRole for getting group Roles mapping for groups= "+groupRoles);
			if (groupRoles != null)
			{
				for (GroupRole groupRole : groupRoles)
				{
					if (QMACacheFactory.getCache().getGroupIdToDBCodeMap().get(groupRole.getGroupId() + "") != null)
					{
						GroupRoleTO groupRoleTo = new GroupRoleTO(QMACacheFactory.getCache().getGroupIdToDBCodeMap().get(groupRole.getGroupId() + ""), groupRole.getRole());
						groupRoleTo.setGroupId(groupRole.getGroupId());
						if (usrGrpRoleTOs.contains(groupRoleTo))
						{
							usrGrpRoleTOs.get(usrGrpRoleTOs.indexOf(groupRoleTo)).setGroupRole(usrGrpRoleTOs.get(usrGrpRoleTOs.indexOf(groupRoleTo)).getGroupRole() + " , " + groupRole.getRole());
						}
						else
						{
							usrGrpRoleTOs.add(groupRoleTo);
						}
					}
				}
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getUserGroupRole", e);
			throw e;
		}
		return usrGrpRoleTOs;
	}
	
	private void setAllTOCCGroupList(UserTO userTo)// Sonar Fix remove unused parameter
			throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		userTo.setAllActiveGroups(groupDAO.getAllActiveDBGroups());
		userTo.setAllToCcDBUsers(getAllActiveUsersIdName());
	}

	//Sonar Fix remove unused method
	/*private List<UserGroupTO> getAllExternalRecipients(List<Group> groupList)
			throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		List<UserGroupTO> ugList = new ArrayList<UserGroupTO>();
		
		//Check added to handle User not having any group roles-UI will display message to contact Group Admin
		if(groupList==null)
		{
			return ugList;
		}

		for (Group group : groupList)
		{
			//Add Recipients only if Predictive User Search is Turned On for Login User's Group
			boolean predictiveUserSrch=(group.getPredictiveRecipients()==null)?true:group.getPredictiveRecipients();
			List<String> myGrpRecipients=new ArrayList<>();
			if (predictiveUserSrch && group.recipients != null && !group.recipients.isEmpty())
			{
				myGrpRecipients.addAll(group.recipients);
			}
			//Sort the recipients
			myGrpRecipients=GenericUtility.getCaseInsensitiveSortedList(myGrpRecipients);
			
			for (String recp : myGrpRecipients)
			{
				UserGroupTO ugTO = new UserGroupTO(recp, recp);
				ugList.add(ugTO);
			}
		}
		return ugList;
	}*/

	public List<Template> getUserInquiryTemplates(String soeId)
	{
		List<Template> templateList = new ArrayList<>();
		Query<User> query = null;
		User user = null;
		
		try
		{
			query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
			user = query.get();
			if (user!=null && user.getTemplates()!= null)
			{
				templateList = getActiveTemplates(user.getTemplates());
			}
			
		}
		catch(Exception e)
		{
			subLogger.error("Exception in getUserInquiryTemplates", e);
			throw e;
		}
		
		return templateList;
	}

	public Boolean saveUserInquiryTemplates(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("Inside UserDAO:saveUserInquiryTemplates - soeId= " + soeId + ",Input= " + inputJsonObj);
		Template inputTemplate = new Template();
		String templateName = inputJsonObj.getString("templateName");
		String templateSubject = inputJsonObj.getString("templateSubject");
		String templateContent = inputJsonObj.getString("templateContent");
		List<String> deleTempGrpList = (List<String>) inputJsonObj.get("delTempGrpList");
		List<UserGroupTO> toList = null;
		List<UserGroupTO> ccList = null;
		List<UserGroupTO> shareToGroupList = null;
		if(inputJsonObj.get("toList") != null)
		{
			toList = createToCcList(inputJsonObj, "toList");
		}
		if(inputJsonObj.get("ccList") != null)
		{
			ccList = createToCcList(inputJsonObj, "ccList");
		}
		
		if(inputJsonObj.get("inqTemplateShareToGrp") != null)
		{
			shareToGroupList = createToCcList(inputJsonObj, "inqTemplateShareToGrp");
		}
		Boolean mergeRecipients = true;
		if(null != inputJsonObj.get("mergeRecipients") ) {
			mergeRecipients = inputJsonObj.getBoolean("mergeRecipients");
		} 
		boolean success = false;
		User user = null;
		Query<User> query = null;
		try
		{
			if(StringUtils.isBlank(templateName) || StringUtils.isBlank(templateContent))
			{
				subLogger.error("Invalid input for saveUserInquiryTemplates for user=" + soeId);
				throw new CommunicatorException("Invalid input for saveUserInquiryTemplates.");
			}
			
			inputTemplate.setTemplateName(templateName);
			inputTemplate.setTemplateContent(templateContent);
			inputTemplate.setTemplateSubject(templateSubject);
			inputTemplate.setToList(toList);
			inputTemplate.setCcList(ccList);			
			inputTemplate.setMergeRecipients(mergeRecipients);
			inputTemplate.setModifiedBy(soeId);
			inputTemplate.setModified(new Date());
			query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
			user = query.get();
			if(null != user)
			{
				success = saveUpdateTemplate(user, query, inputTemplate);
				saveGroupTemplate(shareToGroupList, inputTemplate);
				deleteTemplateForGrps(soeId, inputTemplate, deleTempGrpList);
			}
		}
		catch(Exception e)
		{
			subLogger.error("Exception in saveUserInquiryTemplates", e);
			throw new CommunicatorException("Exception in saveUserInquiryTemplates");
		}
		return success;
	}

	private void deleteTemplateForGrps(String soeId, Template inputTemplate, List<String> deleTempGrpList)
	{
		if(null != deleTempGrpList && !deleTempGrpList.isEmpty())
		{
			Date now = new Date();
			for (String grpId : deleTempGrpList)
			{
				if (null != grpId)
				{
					Long groupId = Long.valueOf(grpId);
					deleteGroupTemplate(soeId, inputTemplate, groupId, now);
				}

			}
		}
	}

	/*
	 * Method to save and share the template at group level.
	 * @param List<UserGroupTO> shareToGroupList
	 * @param Template templateToShare
	 * @return String 
	 */
	private boolean saveGroupTemplate(List<UserGroupTO> shareToGroupList, Template templateToShare)
	{
		boolean success = false;
		Query<Group> grpQuery;
		List<Long> grpIdList = new ArrayList<>();
		for (UserGroupTO uTo : shareToGroupList)
		{
			if (null != uTo)
			{
				String gCode = uTo.getText();
				if (null != gCode)
				{
					grpIdList.add(QMACacheFactory.getCache().getGroupCodeToIdMap().get(gCode.toUpperCase()));
				}
			}
		}
		if (!grpIdList.isEmpty())
		{
			grpQuery = mongoDatastore.createQuery(Group.class).field("_id").in(grpIdList);
			List<Group> groupList = grpQuery.asList();
			if (null != groupList && !groupList.isEmpty())
			{
				persistGroupTemplate(templateToShare, groupList);
				success=true;
			}
		}
		return success;

	}

	private void persistGroupTemplate(Template templateToShare, List<Group> groupList)
	{
		for (Group grp : groupList)
		{
			boolean updateTemplate = false;
			if (null == templateToShare.getShareToGrpList())
			{
				UserGroupTO sharedTempGrp = new UserGroupTO();
				sharedTempGrp.setText(grp.getGroupName());
				sharedTempGrp.setValue(grp.getId().toString());
				List<UserGroupTO> shareGrpList = new ArrayList<>();
				shareGrpList.add(sharedTempGrp);
				templateToShare.setShareToGrpList(shareGrpList);
			}
			if (null != grp.getTemplates())
			{
				List<Template> templates = grp.getTemplates();
				for (Template grpTemp : templates)
				{
					// compare two templates for equality.
					if (templateToShare.equals(grpTemp))
					{
						updateTemplate = true;
						updateTemplateData(templateToShare, grpTemp);
					}
				}
			}
			else
			{
				List<Template> grpTemplateList = new ArrayList<>();
				grp.setTemplates(grpTemplateList);
			}
			// Condition for adding new template
			if (!updateTemplate)
			{
				grp.getTemplates().add(templateToShare);
			}
			persist(grp);
			templateToShare.setShareToGrpList(null);
		}
	}

	private List<UserGroupTO> createToCcList(BasicDBObject inputJsonObj, String recipientCategory)
	{
		List<UserGroupTO> toCcList;
		toCcList = new ArrayList<>();
		JSONArray jsArray = new JSONArray(inputJsonObj.getString(recipientCategory));
		if (jsArray.length() > 0)
		{
			for (int i = 0; i < jsArray.length(); i++)
			{
				JSONObject jsonObj = jsArray.getJSONObject(i);
				UserGroupTO gUserTo = new UserGroupTO();
				gUserTo.setText(jsonObj.getString("text"));
				gUserTo.setValue(jsonObj.getString("value"));
				toCcList.add(gUserTo);
			}
		}
		return toCcList;
	}
	/**
	 * @param user 
	 * @param query
	 * @param newTemplate
	 * @param success
	 * save/update template data in user profile. 
	 */
	private boolean saveUpdateTemplate(User user, Query<User> query, Template newTemplate)
	{
		boolean success;
		boolean updateTemplate = false;
		UpdateOperations<User> updateOps;
		if (null != user.getTemplates())
		{
			for (Template dbTemplate : user.getTemplates())
			{
				// compare two templates for equality.
				if (newTemplate.equals(dbTemplate))
				{
					updateTemplate = true;
					updateTemplateData(newTemplate, dbTemplate);
				}
			}
		}
		else
		{
			List<Template> userTemplateList = new ArrayList<>();
			user.setTemplates(userTemplateList);
		}
		
		// Condition for adding new template
		if (!updateTemplate)
		{
			user.getTemplates().add(newTemplate);
		}

		// Condition for adding/updating template list
		updateOps = mongoDatastore.createUpdateOperations(User.class).set("templates", user.getTemplates());
		mongoDatastore.update(query, updateOps);
		success = true;
		return success;
	}
	
	/**
	 * @param source 
	 * @param target
	 * copy source data to target template
	 */
	private void updateTemplateData(Template source, Template target)
	{
		if (null != source && null != target)
		{
			target.setTemplateSubject(source.getTemplateSubject());
			target.setTemplateContent(source.getTemplateContent());
			target.setBccList(source.getBccList());
			target.setToList(source.getToList());
			target.setCcList(source.getCcList());
			target.setMergeRecipients(source.isMergeRecipients());
			target.setActive(true);
		}

	}
	
	public Boolean deleteInquiryTemplates(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("Inside deleteUserInquiryTemplates - soeId= " + soeId + ", Input= " + inputJsonObj);
		Template inputTemplate = new Template();
		String templateName = inputJsonObj.getString("templateName");
		boolean success = false;
		List<UserGroupTO> shareToGroupList = null;
		Date now = new Date();
		try
		{
			if (StringUtils.isBlank(templateName))
			{
				subLogger.error("Invalid input for deleteUserInquiryTemplates for user=" + soeId);
				throw new CommunicatorException("Invalid input for deleteUserInquiryTemplates.");
			}
			// Keeping this method for backword compatibility will remove it later once all the tempatles will move to group level.
			inputTemplate.setTemplateName(templateName);
			shareToGroupList = createToCcList(inputJsonObj, "inqTemplateShareToGrp");
			if (null != shareToGroupList && !shareToGroupList.isEmpty())
			{
				success = deleteGroupSharedTemplates(soeId,shareToGroupList, inputTemplate, now);
			}
			else
			{
				success = deleteUserTemplate(soeId, inputTemplate,now);
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in deleteUserInquiryTemplates", e);
			throw new CommunicatorException("Exception in deleteUserInquiryTemplates");
		}

		return success;
	}

	private boolean deleteUserTemplate(String soeId, Template inputTemplate, Date now)
	{
		boolean success = false;
		User user;
		Query<User> query;
		query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
		user = query.get();
		if(user!=null)
		{
			UpdateOperations<User> updateOps;
			boolean deleteTemplate = false;
			if(null != user.getTemplates())
			{
				for(Template userTemplate:user.getTemplates())
				{
					if(inputTemplate.equals(userTemplate))
					{
						userTemplate.setActive(false);
						userTemplate.setModifiedBy(soeId);
						userTemplate.setModified(now);
						deleteTemplate = true;
						break;
					}
				}
			}
			//Condition for deleting new template
			if(deleteTemplate)
			{
				// Condition for adding/updating template list
				updateOps = mongoDatastore.createUpdateOperations(User.class).set("templates", user.getTemplates());
				mongoDatastore.update(query, updateOps);
				success = true;
			}
		}
		return success;
	}
	
	/*
	 * This method will permanently delete template from user collection.
	 * @param soeId
	 * @param inputTemplate
	 * @param templateName
	 */
	private void hardDeleteUserTemplate(String soeId, Template inputTemplate, String templateName)
	{
		User user;
		Query<User> query;
		query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
		user = query.get();
		UpdateOperations<User> updateOps;
		boolean deleteTemplate = false;
		if (null != user && null != user.getTemplates())
		{
			for (Template userTemplate : user.getTemplates())
			{
				if (templateName.equalsIgnoreCase(userTemplate.getTemplateName()))
				{
					inputTemplate = userTemplate;
					deleteTemplate = true;
					break;
				}
			}
		}
		// Condition for deleting new template
		if (deleteTemplate)
		{
			user.getTemplates().remove(inputTemplate);
			// Condition for adding/updating template list
			updateOps = mongoDatastore.createUpdateOperations(User.class).set("templates", user.getTemplates());
			mongoDatastore.update(query, updateOps);
		}
	}
	
	private boolean deleteGroupSharedTemplates(String soeId, List<UserGroupTO> shareToGroupList, Template inputTemplate, Date now)
	{
		boolean success = false;
		for (UserGroupTO grp : shareToGroupList)
		{
			if (null != grp)
			{
				Long groupId = Long.valueOf(grp.getValue());
				if (null != groupId)
				{
					deleteGroupTemplate(soeId, inputTemplate, groupId, now);
				}
			}
		}
		return success;
	}

	private void deleteGroupTemplate(String soeId, Template inputTemplate, Long groupId, Date now)
	{
		Group group;
		Query<Group> grpQuery;
		grpQuery = mongoDatastore.createQuery(Group.class).filter("_id", groupId);
		group = grpQuery.get();
		if (group != null && group.getActive() && group.getTemplates() != null)
		{
			boolean deleteTemplate = false;
			UpdateOperations<Group> updateOps;
			for (Template grpTemplate : group.getTemplates())
			{
				if (inputTemplate.equals(grpTemplate))
				{
					grpTemplate.setActive(false);
					grpTemplate.setModifiedBy(soeId);
					grpTemplate.setModified(now);
					deleteTemplate = true;
					break;
				}
			}
			// Condition for deleting new template
			if (deleteTemplate)
			{
				// Condition for adding/updating template list
				updateOps = mongoDatastore.createUpdateOperations(Group.class).set("templates", group.getTemplates());
				mongoDatastore.update(grpQuery, updateOps);
			}
		}
	}

	public static Map<String, UserTO> getUserProfileMap() {
		return userProfileMap;
	}

	//Method to save columns to show for default boxes
	public Boolean saveUserDefaultBoxColumns(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("Inside saveUserDefaultBoxColumns - soeId= " + soeId + ",Input= " + inputJsonObj);

		User user = null;
		Query<User> query = null;
		List<ViewConfig> userViewColumnConfigList = null;
		ViewConfig viewConfig = null;
		boolean saveNewViewConfig = true;
		boolean success = false;
		
		try
		{
			String viewName = inputJsonObj.getString("viewName");
			if( StringUtils.isNotEmpty(viewName)  && viewName.equalsIgnoreCase(InquiryDAO.DEFAULT_VIEW_TYPE_ESCALATION_UI)){
				viewName =  InquiryDAO.DEFAULT_VIEW_TYPE_ESCALATION;
			}
			boolean isViewDefault = inputJsonObj.getBoolean("isViewDefault");
			BasicDBList inputJsonShowList = (BasicDBList) inputJsonObj.get("columnsToShow");
			List<ColumnDef> columnsToShow = GenericUtility.modifyCriteriaForDefaultBoxDBSave(inputJsonShowList);
			
			if(StringUtils.isBlank(viewName))
			{
				subLogger.error("Invalid input for saveUserDefaultBoxColumns for user=" + soeId);
				throw new CommunicatorException("Invalid input for saveUserDefaultBoxColumns.");
			}
			
			query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
			user = query.get();
			
			//Different cases for default boxes and other views
			if(user!=null && isViewDefault)
			{
				//Modify the column 
				userViewColumnConfigList = user.getCustomDefaultViews();
				if(userViewColumnConfigList!=null)
				{
					for(ViewConfig defaultBoxConfig:userViewColumnConfigList)
					{
						if(viewName.equalsIgnoreCase(defaultBoxConfig.getViewName()))
						{
							defaultBoxConfig.setColumnsToShow(columnsToShow);
							saveNewViewConfig = false;
							break;
						}
					}
					
					//Create new ViewConfig object in case no config is found for the input view name
					if(saveNewViewConfig)
					{
						viewConfig = new ViewConfig();
						viewConfig.setViewName(viewName);
						viewConfig.setColumnsToShow(columnsToShow);
						userViewColumnConfigList.add(viewConfig);
					}
				}
				else
				{
					//Create new List of ViewConfig if there are no View Config entries at all.
					userViewColumnConfigList =  new ArrayList<ViewConfig>();
					viewConfig = new ViewConfig();
					viewConfig.setViewName(viewName);
					viewConfig.setColumnsToShow(columnsToShow);
					userViewColumnConfigList.add(viewConfig);
					user.setCustomDefaultViews(userViewColumnConfigList);
				}
			}
			else if(user!=null && !isViewDefault)
			{
				//Add data to the existing view.
				userViewColumnConfigList = user.getViews();
                if(userViewColumnConfigList!=null)
                {
    				for(ViewConfig vConfig: userViewColumnConfigList)
    				{
    					if(viewName.equalsIgnoreCase(vConfig.getViewName()))
    					{
    						vConfig.setColumnsToShow(columnsToShow);
    						break;
    					}
    				}
                }
			}
			
			 if(user!=null)
			 {
				//Save after both the cases are done with.
					mongoDatastore.save(user);
					//saveUserDefaultBoxColumns
					HazelCastCacheIncrementalLoad.refreshUserCache(user.getId());
					//Refresh userProfileMap with latest Details
					if(userProfileMap!=null && userProfileMap.get(soeId)!=null){
						userProfileMap.get(soeId).setViewColumnDefs(userViewColumnConfigList);
					}
					
					success = true;
			 }
		}
		catch(Exception e)
		{
			subLogger.error("Exception in saveUserDefaultBoxColumns", e);
			throw new CommunicatorException("Exception in saveUserDefaultBoxColumns");
		}
		
		return success;
	}

	//Method to migrate Inquiry level View Preference to Group level
	private List<Preference> setGroupLevelViewPref(List<Preference> dbPreferencList)
	{
		List<Preference> userPreferencList = dbPreferencList;
		//Find Inquiry Level View Preference and Migrate to Group Level
		if(dbPreferencList != null && !dbPreferencList.isEmpty()){
			Preference inquiryLevelViewPref=null;
			//Find Inquiry level Preference
			for (Preference pref : userPreferencList) {
				if ("groupLevelViewId".equals(pref.getKey())
						&& QmaMailConstants.STRING_NO.equals(pref.getValue())) {
					inquiryLevelViewPref=pref;
					break;
				}

			}
			if(inquiryLevelViewPref!=null){
				userPreferencList.remove(inquiryLevelViewPref);
				userPreferencList.add(new Preference("groupLevelViewId", "Y"));
			}
		}
		return userPreferencList;
	}
	
	///delete all user associated contacts  from user group and save updated one 
	private void setSharedTopContactToGroupUser(Map<Long, BasicDBList> groupIdContactListMapListMap,String soeId,List<Long>groupIds)
	{
		 DBCollection groupCollection = mongoDatastore.getCollection(Group.class);
		 BasicDBObject favObj = new BasicDBObject();
		 //Login User SoeId is used to match & set createdBy later
		 //favObj.put(CREATED_BY, soeId);
		 
		 //1.Clear All Shared Contact for the login user soeId
		 clearUsersSharedGrpContacts(favObj, groupIds, groupCollection);
		 
		 //Save New Changes passed from UI for login user- soeId
		for (Map.Entry<Long, BasicDBList> entry : groupIdContactListMapListMap.entrySet()) 
		{
		  
		   BasicDBObject groupBaseId1 = new BasicDBObject();
		   groupBaseId1.put("_id",entry.getKey());
		   DBObject updateGroupfav = new BasicDBObject();
		   updateGroupfav.put("$addToSet", new BasicDBObject(FAVORITES, new BasicDBObject("$each",entry.getValue())));
		   groupCollection.update(groupBaseId1,updateGroupfav);
		   
		}
	}

	// delete all the contact list from user associated group created by log in user 
	private void clearUsersSharedGrpContacts(BasicDBObject favObj,List<Long> groupIds, DBCollection groupCollection) {
			
		   BasicDBObject groupBaseId = new BasicDBObject();
		   groupBaseId.put("_id",new BasicDBObject("$in",groupIds));
		   //groupBaseId.put(FAVORITES,new BasicDBObject("$elemMatch", favObj));
		   DBObject delteUserFavFromGrp = new BasicDBObject();
		   delteUserFavFromGrp.put("$pull", new BasicDBObject(FAVORITES, favObj));
		   groupCollection.updateMulti(groupBaseId, delteUserFavFromGrp);
	}

	/**
	 * @param groupIdContactListMapListMap
	 * @param favCnts
	 */
	// create a map with key groupId and value with top contacts  list 
	private void createMapWithGrpIdOfFavList(Map<Long, BasicDBList> groupIdContactListMapListMap,FavoriteContact favCnts) 
	{
		//List<FavoriteContact> favContactGroupList = new ArrayList<FavoriteContact>();
		String[] groupNameList = favCnts.getSharedToGroupsName().split(",");
		QMACache qmaCache = QMACacheFactory.getCache();
		Map<String, Long> groupCodeToIdMap = qmaCache.getGroupCodeToIdMap();
		for (int idx =0;idx<groupNameList.length;idx++)
		{
			BasicDBList favContactDBist = new BasicDBList();
			String groupName=groupNameList[idx];
			Long groupId = groupCodeToIdMap.get(groupName.toUpperCase());
			BasicDBObject favDBobj=new BasicDBObject();
			favDBobj.put(USER_VALIDATION_NAME_KEY, favCnts.getName());
			favDBobj.put(EMAIL, favCnts.getEmail());
			favDBobj.put("sharedToGroupsName", favCnts.getSharedToGroupsName());
			favDBobj.put("mapToGroupsName", favCnts.getMapToGroupsName());
			favDBobj.put(CREATED_BY, favCnts.getCreatedBy());
			favDBobj.put(CONTACT_PH_NO, favCnts.getContactPhNumber());
			favDBobj.put("contactAddress", favCnts.getContactAddress());
			favDBobj.put("contactNote", favCnts.getContactNote());
			if(groupIdContactListMapListMap.containsKey(groupId))
			{
				favContactDBist=groupIdContactListMapListMap.get(groupId);
				favContactDBist.add(favDBobj);
				groupIdContactListMapListMap.put(groupId, favContactDBist);
			}
			else
			{
				favContactDBist.add(favDBobj);
				groupIdContactListMapListMap.put(groupId,favContactDBist);
			}
			
		}
	}
	//merge user favorites and group level favorites with unk value .
  private void mergeUserAndGrpFav(List<Group>userGroups,List<FavoriteContact>userFavorites)
  {
	  for (Group gpr : userGroups) {
		  	if(null != gpr.getTemplates())
		  	{
		  		gpr.setTemplates(getActiveTemplates(gpr.getTemplates()));
		  	}
		  
			if (gpr!=null && gpr.getFavorites()!=null &&  !gpr.getFavorites().isEmpty())
			{
				//for matching favorites use override equal method in favorites class. make unique favorites of multiple shared group 
				userFavorites.removeAll(gpr.getFavorites());// first remove all matched entry present in user favorites of current group
				userFavorites.addAll(gpr.getFavorites());// add current group all favorites to user group 
			}

		}
  }
 
  public void updateUser(User user) throws CommunicatorException
	{
		try
		{
			mongoDatastore.save(user);
			//read and save groupInfo when inserted updated from main class
			HazelCastCacheIncrementalLoad.refreshUserCache(user.getId());
		}
		catch (Exception e)
		{
			subLogger.error("Exception in UserDAO.updateUser", e);
			throw new CommunicatorException("Exception in UserDAO.updateUser");
		}
	}

	// Changes to save User's Editor Style Preferences
	public boolean saveUserEditorPreferences(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException
	{
		boolean isEditorPreferencesUpdated = false;
		try
		{
			String editorFontName = inputJsonObj.getString(AppserverConstants.USER_FONT_NAME_PREF);
			String editorFontSize = inputJsonObj.getString(AppserverConstants.USER_FONT_SIZE_PREF);

			User user = getUserById(soeId, true);
			List<Preference> dbUserPreferences = user.getPreferences();

			//Creating new editor preferences, if user doesnt have preferences.
			if(dbUserPreferences==null)
			{
				dbUserPreferences = new ArrayList<Preference>();
				user.setPreferences(dbUserPreferences);
			}
			
			//Checking if editor preferences have been updated compared to those in DB
			boolean isFontNameUpdateReq = updateUserPreferenceList(AppserverConstants.USER_FONT_NAME_PREF, editorFontName, dbUserPreferences);
			boolean isFontSizeUpdateReq = updateUserPreferenceList(AppserverConstants.USER_FONT_SIZE_PREF, editorFontSize, dbUserPreferences);
			
			if(isFontNameUpdateReq || isFontSizeUpdateReq)
			{
				//Updating DB User Preference Data
				mongoDatastore.save(user);
				HazelCastCacheIncrementalLoad.refreshUserCache(user.getId());
				isEditorPreferencesUpdated = true;
				subLogger.info("Updated Editor Preferences for user: "+soeId+", FontName: "+editorFontName+", FontSize: "+editorFontSize);
				//Refresh userProfileMap with latest Details
				if(userProfileMap!=null && userProfileMap.get(soeId)!=null){
					userProfileMap.get(soeId).setPreferences(dbUserPreferences);
				}
			}
		}
		catch (Exception e)
		{
			subLogger.error("saveUserEditorPreferences--Error updating editor preferences for user: "+soeId,e);
		}
		
		return isEditorPreferencesUpdated;
	}

	private boolean updateUserPreferenceList(String preferenceKey, String preferenceValue, List<Preference> dbUserPreferenceList)
	{//Method to update the value of given user preference if it exists, else add new preference for the same.
	 //Returns true if DB update is required else returns false.
		
		boolean isPreferenceUpdateRequired = false;
		boolean isPreferenceUpdated = false;

		for (Preference preference : dbUserPreferenceList)
		{
			if (!StringUtils.isBlank(preferenceKey) && !StringUtils.isBlank(preferenceValue) && preferenceKey.equalsIgnoreCase(preference.getKey()))
			{

				isPreferenceUpdateRequired = preferenceValue.equalsIgnoreCase(preference.getValue()) ? false : true;
				preference.setValue(preferenceValue);
				isPreferenceUpdated = true;
				break;
			}
		}

		if (!StringUtils.isBlank(preferenceKey) && !StringUtils.isBlank(preferenceValue) && !isPreferenceUpdated)
		{
			//Adding new preference, if it doesnt already exist for given user in DB
			Preference newPreference = new Preference();
			newPreference.setKey(preferenceKey);
			newPreference.setValue(preferenceValue);
			dbUserPreferenceList.add(newPreference);
			isPreferenceUpdateRequired = true;
		}

		return isPreferenceUpdateRequired;
	}
	
	//[C153176-725] - Admin Menu Enhancements for config role and other role reviews
	//Method to populate adminRole details
	//[C153176-1193] - Optimize Login user info , Chart refresh time data
	private void populateConfigAdminRoles(UserTO userTO)
	{
		//Map<String, Config> configData  =  CacheDAO.getInstance().getConfigIdMap();
		//Config configAdminRoles = genricDAO.getConfigDetailsForId("AdminRoles");
		Config configAdminRoles = QMACacheFactory.getCache().getConfigById("AdminRoles");
		List<String> configUserAdminRoles = new ArrayList<String>();
		
		if (configAdminRoles.getAdminRoleList() != null && !configAdminRoles.getAdminRoleList().isEmpty())
		{
			userTO.setConfigDefaultAdminRoleList(configAdminRoles.getAdminRoleList());
		}
		if (GenericUtility.containsCaseInsensitive(userTO.getUserId(), configAdminRoles.getUserAdmin()))
		{
			configUserAdminRoles.add("userAdmin");
		}
		if (GenericUtility.containsCaseInsensitive(userTO.getUserId(), configAdminRoles.getGroupSetupAdmin()))
		{
			configUserAdminRoles.add("groupSetupAdmin");
		}
		if (GenericUtility.containsCaseInsensitive(userTO.getUserId(), configAdminRoles.getMgmtHierarchyAdmin()))
		{
			configUserAdminRoles.add("mgmtHierarchyAdmin");
		}
		if (GenericUtility.containsCaseInsensitive(userTO.getUserId(), configAdminRoles.getDbAdmin()))
		{
			configUserAdminRoles.add("dbAdmin");
		}
		if(!configUserAdminRoles.isEmpty())
		{
			userTO.setConfigUserAdminRoles(configUserAdminRoles);
		}
	}
	
	//[C153176-169] - Server-side export of inquiries
	//Returns required user preference value for given key
	public String getUserPreferenceValue(String soeId, String preferenceKey)
	{
		String preferenceValue = null;
		if(!StringUtils.isBlank(soeId) && !StringUtils.isBlank(preferenceKey) && userProfileMap!=null && userProfileMap.get(soeId)!=null)
		{
			List<Preference> userPreferenceList = userProfileMap.get(soeId).getPreferences();
			if(userPreferenceList!=null)
			{
				for(Preference userPreference : userPreferenceList)
				{
					if(userPreference!=null && preferenceKey.equalsIgnoreCase(userPreference.getKey()))
					{
						preferenceValue = userPreference.getValue();
						break;
					}
					
				}
			}
		}
		
		return preferenceValue;		
	}
	
	public String getUserDateFormatPreference(String soeId)
	{
		//Fetching date format as per user preference
		String dateFormat = getUserPreferenceValue(soeId, "dateFormatterSelectId");
		//Fetching default date format if user preference is not set
		if(StringUtils.isBlank(dateFormat) && QMACacheFactory.getCache().getDefaultDateFormate()!=null)
		{
			dateFormat = QMACacheFactory.getCache().getDefaultDateFormate();
		}
		return dateFormat;
	}
	
	/**
	 * @param staticData 
	 * @return
	 * Update to get MIS report Details Config Collection from Cache DAO
	 * [C153176-1193] - Optimize Login user info , Chart refresh time data
	 */
	public List<KeyValue> getMISReportData(StaticData staticData)
	{
		List<KeyValue> reportValueList;
		QMACache qmaCache = QMACacheFactory.getCache();
		if (null != staticData.getGenerateMISReportFromDB()
				&& staticData.getGenerateMISReportFromDB().equalsIgnoreCase(DATA_COPY_ORACLE)) {
			subLogger.info("MIS reports generating from Oracle DB");
			reportValueList = qmaCache.getConfigById(MIS_REPORTS).getQueryListOracle();
		}else if(null != staticData.getGenerateMISReportFromDB()
				&& staticData.getGenerateMISReportFromDB().equalsIgnoreCase(DATA_COPY_NETEZZA)) {
			subLogger.info("MIS reports generating from Netezza DB");
			reportValueList = qmaCache.getConfigById(MIS_REPORTS).getQueryList();
		}else{
			subLogger.info("MIS reports generating from default Netezza DB");
			reportValueList = qmaCache.getConfigById(MIS_REPORTS).getQueryList();
		}
		return reportValueList;
	}

	
	public boolean resetOutOfOffice(String soeId) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			boolean outOfOffice = false;
			subLogger.info("Inside UserDao.resetOutOfOffice for userId= " + soeId);
			Query<User> query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
			UpdateOperations<User> ops = mongoDatastore.createUpdateOperations(User.class);
			List<User> user = query.asList();
			if(!user.isEmpty() && user.get(0) !=null && user.get(0).getOutOfOfficeSettings() != null){
				ops.set("outOfOfficeSettings.outOfOffice", outOfOffice);
				ops.unset("outOfOfficeSettings.fromDate");
				ops.unset("outOfOfficeSettings.toDate");
			}
			ops.set(OUT_OF_OFFICE, outOfOffice);
			mongoDatastore.update(query, ops);
			// Refresh userProfileMap with latest Details
			if (userProfileMap != null && userProfileMap.get(soeId) != null)
			{
				UserTO userProfile = userProfileMap.get(soeId);
				userProfile.setOutOfOffice(false);
				userProfileMap.put(soeId, userProfile);
			}
			QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).setOutOfOffice(outOfOffice);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getContextInfo", e);
			throw new CommunicatorException("Exception in getContextInfo");
		}
		return true;
	}

	/**
	 * @param userName
	 * @return user 
	 */
	public User getUserByUserName(String userName)
	{
		User user = null;

		try
		{
			//String query = Pattern.quote(userName);
			Query<User> userQuery = mongoDatastore.createQuery(User.class).field(USER_VALIDATION_NAME_KEY).containsIgnoreCase(userName).retrievedFields(true, "_id").limit(1);
			user = userQuery.get();

			if (user == null)
			{
				subLogger.error("No Active User data found for userName =" + userName);
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getUserByUserName for  user=" + userName, e);
		}

		return user;
	}
	
	/**
	 * @param user
	 * @param userTo
	 */
	private void populateReleaseNotesDocument(User user, UserTO userTo, String fullPath)
	{
		try
		{
			userTo.setShowReleaseDocument(false);
			
			Config configData = genricDAO.getConfigDetailsForId("releaseNotes");
			if(null != configData )
			{
				String currentDocumentName = configData.getCurrentReleaseDocumentName();
				String viewedDocumentName = user.getViewedReleaseDocumentName();
				if(null!= currentDocumentName && (null == viewedDocumentName || !viewedDocumentName.equalsIgnoreCase(currentDocumentName)))
				{
					userTo.setShowReleaseDocument(true);
					userTo.setCurrentReleaseDocumentName(currentDocumentName);
				}				
			}
		}catch (Exception e)
		{
				subLogger.error("Exception in populateReleaseNotesDocument", e);			
		}
	}
	
	/**
	 * @param currentDocumentName
	 * @throws CommunicatorException 
	 */
	public File downloadReleaseNotesfromDB(String currentDocumentName) throws CommunicatorException {
		
		try
		{
			//Find the appropriate bucket and get the file 
			GridFS gridFSFile = new GridFS(mongoDatastore.getDB(),"releaseDocuments");
			GridFSDBFile dbFile = gridFSFile.findOne(currentDocumentName);
			
			if(dbFile == null)
			{
				subLogger.info("File Name not found= " + currentDocumentName);
				throw new CommunicatorException("Exception retrieving file in the method downloadReleaseNotesfromDB with File Name not found="+currentDocumentName);
			}
			
			File file = new File(currentDocumentName);
			dbFile.writeTo(file);
			return file;
			
		}
		catch(Exception e)
		{
			subLogger.info("Invalid data for downloadReleaseNotesfromDB with file name= " + currentDocumentName);
     	    throw new CommunicatorException("Exception retrieving group data in the method downloadReleaseNotesfromDB with filename:"+currentDocumentName+" and exception "+e);
		}
		
	}

	
	/**
	 * @param soeId
	 * @return
	 */
	public boolean updateViewedReleaseNotesDocument(String soeId) 
	{
		try
		{
			subLogger.info("Inside UserDao.updateViewedReleaseNotesVersion for userId= " + soeId);
			Config configData = genricDAO.getConfigDetailsForId("releaseNotes");
			
			if(null != configData )
			{
				String currentDocumentName = configData.getCurrentReleaseDocumentName();
				Query<User> query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
				UpdateOperations<User> ops = mongoDatastore.createUpdateOperations(User.class);			
				ops.set("viewedReleaseDocumentName",currentDocumentName);
				mongoDatastore.update(query, ops);
				
				subLogger.info("updated updateViewedReleaseNotesDocument = " + currentDocumentName + ", for soeId: " + soeId);
			}

		}
		catch (Exception e)
		{
			subLogger.error("Exception in updateViewedReleaseNotesDocument", e);			
		}
		
		return true;
		
	}
	
	/**
	 * This method uploads user profile picture
	 * @param profilePicFileStream
	 * @param soeId
	 * @return BasicDBObject
	 * @throws CommunicatorException
	 */
	public BasicDBObject saveUserProfilePic(InputStream profilePicFileStream, String soeId) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		boolean uploadFlag = false;
		try {
			Query<User> query = mongoDatastore.createQuery(User.class).filter(
					"_id", soeId);
			byte[] profilePicByteArr = IOUtils.toByteArray(profilePicFileStream);

			UpdateOperations<User> userOps = mongoDatastore.createUpdateOperations(User.class);
			userOps.set("profilePic", profilePicByteArr);
			mongoDatastore.update(query, userOps);
			//Refresh userProfileMap with latest Details
			if(userProfileMap!=null && userProfileMap.get(soeId) !=null ){
				UserTO userProfile=userProfileMap.get(soeId);
				userProfile.setProfilePic(profilePicByteArr);
				userProfileMap.put(soeId,userProfile);
				uploadFlag = true;
			}
			response.put("image", profilePicByteArr);
			response.put("uploadFlag", uploadFlag);
		} catch (Exception e) {
			subLogger.error("Exception while uploading profile picture in UserDAO#saveUserProfilePic()", e);
			response.put("image", "");
			response.put("uploadFlag", uploadFlag);
			throw new CommunicatorException("Exception while uploading profile picture in UserDAO#saveUserProfilePic() : " + e.getMessage());
		}
		return response;
	}
	
	/**
	 * This method retrieves user profile picture
	 * @param userSoeId
	 * @param type
	 * @return ResponseBuilder
	 */
	public ResponseBuilder retrieveProfilePicture(String soeID,String type, String userID, String dataType) throws CommunicatorException{
		String userSoeIdOrEmail = soeID;
		if( userID != null ) {
			userSoeIdOrEmail = userID;
		}
		InputStream is = null;
		File profilePicFile = null;
		String fileName = "userPic.png";
		try {
			subLogger.info("Retrieving user profile pic for user : " + userSoeIdOrEmail + " with type :" + dataType);
			profilePicFile = new File(fileName);
			byte[] profilePicByteArr = null;
			if(userProfileMap != null && userProfileMap.get(userSoeIdOrEmail) !=null && userProfileMap.get(userSoeIdOrEmail).getProfilePic() != null) {
				profilePicByteArr = userProfileMap.get(userSoeIdOrEmail).getProfilePic();
			} else {
				profilePicByteArr = getUserForProfilePicByteArr(userSoeIdOrEmail,dataType);
			}
			if(profilePicByteArr!=null && "inline".equalsIgnoreCase(type)){
				profilePicByteArr  = Base64.getEncoder().encode(profilePicByteArr);
			} else {
				subLogger.info("Using default image for user");
				File defaultImg = new File(Thread.currentThread().getContextClassLoader().getResource(AppserverConstants.DEFAULT_IMAGE).getFile());
				is = new FileInputStream(defaultImg);
				byte[] defaultImageByteArr = IOUtils.toByteArray(is);
				profilePicByteArr = Base64.getEncoder().encode(defaultImageByteArr);
			}
			FileUtils.writeByteArrayToFile(profilePicFile, profilePicByteArr);
			
		} catch (Exception e) {
			subLogger.error("Exception while retriving profile picture in UserDAO#retrieveProfilePicture() : ", e);
		} finally {
			if(is!=null){
				try {
					is.close();
				} catch (IOException e) {
					subLogger.error("Exception while retriving profile picture in UserDAO#retrieveProfilePicture() : ", e);
				}
			}
		}
		return Response.ok((Object) profilePicFile).header("Content-Disposition", "attachment; filename=" + fileName).header("Content-Length", String.valueOf(profilePicFile.length()));
	}

	/**
	 * This method gets the user profile pic byte array
	 * @param userIdOrEmail
	 * @param dataType
	 * @return
	 */
	private byte[] getUserForProfilePicByteArr(String userIdOrEmail,String dataType) {
		byte[] profilePicByteArr = null;
		User user = null;
		try {
			if("user".equalsIgnoreCase(dataType)){
				user = getUserById(userIdOrEmail);
			} else if("email".equalsIgnoreCase(dataType)){
				user = getUserByEmailId(userIdOrEmail.toLowerCase(),false);
				if(user == null) {
					subLogger.info("User not found with provided email id, trying to retrieve user with all valid citi domains.");
					String emailName = userIdOrEmail.substring(0,userIdOrEmail.indexOf('@'));
					user = getUserByDifferentCitiDomains(emailName);
				}
			}
			if( user != null ) {
				profilePicByteArr = user.getProfilePic();
			}
		} catch (Exception e) {
			subLogger.error("Exception while retriving profile picture in UserDAO#getUserForProfilePicByteArr() : ", e);
		}
		return profilePicByteArr;
	}

	/**
	 * This method tries to retrieve user with different citi domains
	 * @param emailName
	 * @return User
	 */
	private User getUserByDifferentCitiDomains(String emailName) {
		User user= null;
		try {
			List<String> citDomainEmails = new ArrayList<>();
			List <String> citiDomainEmailList  = genericDAO.getListOfCitiDomain();
			for(String currentDomain : citiDomainEmailList){
				String email = emailName.toUpperCase() + "@" + currentDomain;
				citDomainEmails.add(email);
			}
			if( !citDomainEmails.isEmpty() ) {
				user = findUserByMultipleCitiDomains(citDomainEmails,false);
			}
			if(user == null ){
				subLogger.info("User not found with with all valid citi domains to retrieve profile picture.");
			}
		} catch (Exception e) {
			subLogger.error("Exception while retriving profile picture in UserDAO#getUserByDifferentCitiDomains() : ", e);
		}
		return user;
	}
	
	/**
	 * This method is used to retrieve user details from CIMS
	 * @param soeID
	 * @param userID
	 * @return
	 */
	public UserTO getUserDataFromCIMS(String soeID, BasicDBObject request) throws CommunicatorException{
		UserTO userTO = new UserTO();
		try {
			String userIdOrEmail = request.getString("userID");
			String dataType = request.getString("dataType");
			if(userIdOrEmail!=null) {
				/*Currently user details are retrieved from QMA User collection.
				 * Going forward it will be collected from CIMS */
				User user = null;
				if("user".equalsIgnoreCase(dataType)){
					user = getUserById(userIdOrEmail);
				} else if("email".equalsIgnoreCase(dataType)){
					user = getUserByEmailId(userIdOrEmail.toLowerCase(),false);
					if(user == null) {
						subLogger.info("User not found with provided email id, trying to retrieve user with all valid citi domains.");
						String emailName = userIdOrEmail.substring(0,userIdOrEmail.indexOf('@'));
						user = getUserByDifferentCitiDomains(emailName);
					}
				}
				if( user != null) {
					userTO.setUserId( user.getId() != null ? user.getId() : AppserverConstants.N_A );
					userTO.setUserName( user.getName() != null ? user.getName() : AppserverConstants.N_A );
					userTO.setEmail( user.getEmail() != null ? user.getEmail() : AppserverConstants.N_A );
					userTO.setActive( user.getActive() ? true : false);
					userTO.setProfilePic( user.getProfilePic() != null ? user.getProfilePic() : null );
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception while retrieving user profile in  UserDAO#getUserDataFromCIMS() : ", e);
			throw new CommunicatorException("Exception while retrieving user profile in  UserDAO#getUserDataFromCIMS() : " + e.getMessage());
		}
		return userTO;
	}
	/*
	 * Method to add active templates
	 * @param templates
	 * @return activeTemplates
	 */
	private List<Template> getActiveTemplates(List<Template> templates)
	{
		List<Template> activeTemplates = new ArrayList<>();
		for (Template temp : templates)
		{
			if (null == temp.getActive() || temp.getActive())
			{
				activeTemplates.add(temp);
			}
		}

		return activeTemplates;
	}

	/**
	 * This method gets and validates list of users 
	 * @param soeId
	 * @param inputJsonObj
	 * @return BasicDBList
	 */
	public BasicDBObject validateBulkUsers(String soeId, BasicDBObject inputJsonObj) {
		BasicDBObject userValidation= new BasicDBObject();
		try {
			BasicDBList userValidationList = new BasicDBList();
			BasicDBList userIdList = (BasicDBList)inputJsonObj.get(USER_ID_LIST_KEY);
			if( null != userIdList && userIdList.size() > 0) {
				for( int i=0; i < userIdList.size(); i++) {
					String userId = (String)userIdList.get(i);
					validateUser(userValidationList, userId);
				}
				userValidation.put(VALIDATION_KEY, userValidationList);
			}
		} catch (Exception e) {
			subLogger.error("Exception while validating bulk user list in UserDAO#validateBulkUsers() : ",e);
		}
		return userValidation;
	}

	/**
	 * This method validates provided users
	 * @param userValidationList
	 * @param userId
	 */
	private void validateUser(BasicDBList userValidationList, String userId) {
		if(StringUtils.isNotEmpty(userId)){
			userValidationList.add(validateUserDetails(userId.toLowerCase()));
		}
	}

	/**
	 * This user validates individual user and returns validation result
	 * @param userId 
	 * @return BasicDBObject
	 */
	private BasicDBObject validateUserDetails(String userId) {
		BasicDBObject validationResult = new BasicDBObject();
		try {
			Query<User> query = this.mongoDatastore.createQuery(User.class)
					.filter("_id", new BasicDBObject("$regex", "^" + userId + "$").append("$options", "i"));
			User user = query.get();
			if (null != user && null != user.getName()) {
				validationResult.put(USERID, userId);
				validationResult.put(USER_VALIDATION_NAME_KEY, user.getName());
				if(user.getActive()) {
					validationResult.put(USER_VALIDATION_STATUS_KEY, "Valid");
					validationResult.put(USER_VALIDATION_REASON_KEY, "-");
				} else {
					validationResult.put(USER_VALIDATION_STATUS_KEY, "Invalid");
					validationResult.put(USER_VALIDATION_REASON_KEY, "User is Inactive.");
				}
				
			} else {
				validationResult.put(USERID, userId);
				validationResult.put(USER_VALIDATION_NAME_KEY, "Not available");
				validationResult.put(USER_VALIDATION_STATUS_KEY, "Invalid");
				validationResult.put(USER_VALIDATION_REASON_KEY, "User does not exist.");
			}
		} catch (Exception e) {
			subLogger.error("Exception while validating user " + userId + ":", e);
			validationResult.put(USERID, userId);
			validationResult.put(USER_VALIDATION_NAME_KEY, "Not available");
			validationResult.put(USER_VALIDATION_STATUS_KEY, "Invalid");
			validationResult.put(USER_VALIDATION_REASON_KEY, "User does not exist.");
		}
		return validationResult;
	}

	/**
	 * @param soeId
	 * @param request
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBObject saveMyCoverage(String soeId, String request) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			if (null != inputJsonObj.get(MY_COVERAGE)) {
				Query<User> query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
				UpdateOperations<User> userOps = mongoDatastore.createUpdateOperations(User.class);
				BasicDBList myCoverage = (BasicDBList) inputJsonObj.get(MY_COVERAGE);
				userOps.set(MY_COVERAGE, myCoverage);
				mongoDatastore.update(query, userOps);
				response.put(QmaMailConstants.SUCCESS_KEY, true);
				response.put(QmaMailConstants.MESSAGE_KEY, "My coverage saved successfully");
			} else {
				response.put(QmaMailConstants.SUCCESS_KEY, false);
				response.put(QmaMailConstants.MESSAGE_KEY, "My coverage request is invalid");
			}
		} catch (Exception e) {
			response.put(QmaMailConstants.SUCCESS_KEY, false);
			response.put(QmaMailConstants.MESSAGE_KEY, "My coverage save failed");
			throw new CommunicatorException("Exception while saving my coverage in UserDAO.saveMyCoverage : " + e);
		}
		return response;
	}
	
	public BasicDBObject createOutOfOfficeSettings(BasicDBObject outOfOfficeSettings) {
		
		try
		{
			String fromDate = outOfOfficeSettings.getString(FROM_DATE_KEY);
			String toDate = outOfOfficeSettings.getString(TO_DATE_KEY);
			SimpleDateFormat sDateFormat = new SimpleDateFormat("MM/dd/yyyy");
			sDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
			if (!StringUtils.isEmpty(fromDate)) {
				Date startDate = sDateFormat.parse(fromDate);
				outOfOfficeSettings.put(FROM_DATE_KEY, startDate);
			}else{
				outOfOfficeSettings.put(FROM_DATE_KEY, fromDate);
			}
			if (!StringUtils.isEmpty(toDate)) {
				Date endDate = sDateFormat.parse(toDate);
				outOfOfficeSettings.put(TO_DATE_KEY, endDate);
			}else{
				outOfOfficeSettings.put(TO_DATE_KEY, toDate);
			}
		}
		catch (ParseException e)
		{
		
			subLogger.error("Error while parsing date in createOutOfOfficeSettings",e);
			return null;
		}
		return outOfOfficeSettings;
	}

	/**
	 * Method save view filters
	 * @param soeId
	 * @param request
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBObject saveViewFilters(String soeId, String request) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			if (null != inputJsonObj && !inputJsonObj.isEmpty()) {
				response = validateSaveViewInput(inputJsonObj);
				
				if (response.getBoolean(QmaMailConstants.SUCCESS_KEY)) {
					Query<User> query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
					UpdateOperations<User> userOps = mongoDatastore.createUpdateOperations(User.class);
					userOps.add(VIEW_FILTERS, inputJsonObj);
					mongoDatastore.update(query, userOps);
					response.put(QmaMailConstants.SUCCESS_KEY, true);
					response.put(QmaMailConstants.MESSAGE_KEY, "View filters saved successfully");
				} else {
					return response;
				}
			} else {
				response.put(QmaMailConstants.SUCCESS_KEY, false);
				response.put(QmaMailConstants.MESSAGE_KEY, "View filters request is invalid");
			}
		} catch (Exception e) {
			response.put(QmaMailConstants.SUCCESS_KEY, false);
			response.put(QmaMailConstants.MESSAGE_KEY, "View filters save failed");
			throw new CommunicatorException("Exception while saving my coverage in UserDAO.saveViewFilters : " + e);
		}
		return response;
	}

	/**
	 * validate save filter request
	 * @param inputJsonObj
	 * @return
	 */
	private BasicDBObject validateSaveViewInput(BasicDBObject inputJsonObj) {
		BasicDBObject response = new BasicDBObject();
		if(null == inputJsonObj.get(VIEW_NAME) || StringUtils.isEmpty((String) inputJsonObj.get(VIEW_NAME))){
			response.put(QmaMailConstants.SUCCESS_KEY, false);
			response.put(QmaMailConstants.MESSAGE_KEY, "View filters request is invalid. View name can not be blank/null.");
		}else if(null == inputJsonObj.get(FILTER_NAME) || StringUtils.isEmpty((String) inputJsonObj.get(FILTER_NAME))){
			response.put(QmaMailConstants.SUCCESS_KEY, false);
			response.put(QmaMailConstants.MESSAGE_KEY, "View filters request is invalid. Filter name can not be blank/null.");
		}else if(null == inputJsonObj.get(FILETR_PARAMS)){
			response.put(QmaMailConstants.SUCCESS_KEY, false);
			response.put(QmaMailConstants.MESSAGE_KEY, "View filters request is invalid. Filter params can not be null.");
		}else if(null != inputJsonObj.get(FILETR_PARAMS)){
			BasicDBObject filterParamList = (BasicDBObject) inputJsonObj.get(FILETR_PARAMS);
			if(filterParamList.isEmpty()){
				response.put(QmaMailConstants.SUCCESS_KEY, false);
				response.put(QmaMailConstants.MESSAGE_KEY, "View filters request is invalid. Filter params can not be blank.");
			}else{
				response.put(QmaMailConstants.SUCCESS_KEY, true);
			}
		}else{
			response.put(QmaMailConstants.SUCCESS_KEY, true);
		}
		return response;
	}

	/**
	 * Get view filters by soeId
	 * @param soeId
	 * @return
	 */
	public BasicDBObject getViewFilters(String soeId) {
		BasicDBObject response = new BasicDBObject();
		try {
			Query<User> query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
			subLogger.info("fetching ViewFilters for : " + query);
			List<User> user = query.asList();
			if(!user.isEmpty() && user.get(0) !=null && user.get(0).getViewFilters() != null){
				List<ViewFilters> viewFiltersList = user.get(0).getViewFilters();
				BasicDBList list = new BasicDBList();
				for (ViewFilters viewFiltersObj : viewFiltersList) {
					BasicDBObject obj = new BasicDBObject();
					obj.put(VIEW_NAME, viewFiltersObj.getViewName());
					obj.put(FILTER_NAME, viewFiltersObj.getFilterName());
					obj.put(FILETR_PARAMS, viewFiltersObj.getFilterParams());
					list.add(obj);
				}
				response.put(QmaMailConstants.SUCCESS_KEY, true);
				response.put(VIEW_FILTERS, list);
			}
			else {
				subLogger.info("No view filters data for soeid : " + soeId);
				response.put(QmaMailConstants.SUCCESS_KEY, false);
				response.put(QmaMailConstants.MESSAGE_KEY, "View filters not found.");
			}
			
		} catch (Exception e) {
			response.put(QmaMailConstants.SUCCESS_KEY, false);
			response.put(QmaMailConstants.MESSAGE_KEY, "Exception while getting view filters data"); 
			subLogger.error(
					"Exception while getting view filters in getViewFilters : " + e);
		}
		return response;
	}

	/**
	 * This method is used to save Custom Columns For Default Views
	 * @param request
	 * @param soeId
	 * @return
	 * @throws CommunicatorException
	 */
	@SuppressWarnings("unchecked")
	public BasicDBObject saveCustomColumnsForDefaultViews(String request, String soeId) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			if (null != inputJsonObj && !inputJsonObj.isEmpty()) {
				response = validateSaveColumnConfig(inputJsonObj);
				
				if (response.getBoolean(QmaMailConstants.SUCCESS_KEY)) {
					Query<User> query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
					UpdateOperations<User> userOps = mongoDatastore.createUpdateOperations(User.class);
					BasicDBObject result = checkIfExists(inputJsonObj, soeId);
					List<CustomColumnsView> columnConfig = null;
					List<ViewConfig> userViews = null;
					if(null!=result.get("customColumnListNew")) {
						columnConfig = (List<CustomColumnsView>) result.get("customColumnListNew");
					}
					if(null!=result.get("updatedView")) {
						userViews =  (List<ViewConfig>) result.get("updatedView");
					}
					if(null!=columnConfig) {
						userOps.set(CUSTOM_COLUMNS_FOR_DEFAULT_VIEWS, columnConfig);
					}
					if(null!=userViews) {
						userOps.set(VIEWS, userViews);
					}
					mongoDatastore.update(query, userOps);
					response.put(QmaMailConstants.SUCCESS_KEY, true);
					response.put(QmaMailConstants.MESSAGE_KEY, "Column preferences saved successfully");
					if("individual".equalsIgnoreCase(inputJsonObj.getString(VIEW_NAME))){
						subLogger.info("Syncing user data as Individual user view is saved");
						syncUserDetailsToPersonalDb(soeId);
						HazelCastCacheIncrementalLoad.refreshUserCache(soeId);
					}
				} else {
					return response;
				}
			} else {
				response.put(QmaMailConstants.SUCCESS_KEY, false);
				response.put(QmaMailConstants.MESSAGE_KEY, "Column preferences request is invalid");
			}
		} catch (Exception e) {
			response.put(QmaMailConstants.SUCCESS_KEY, false);
			response.put(QmaMailConstants.MESSAGE_KEY, "Column preferences save failed");
			throw new CommunicatorException("Exception while saving column preferences in UserDAO.saveCustomColumnsForDefaultViews : " + e);
		}
		return response;
	}

	/**
	 * Check and replace in case duplicate
	 * @param inputJsonObj
	 * @param soeId
	 * @return
	 */
	private BasicDBObject checkIfExists(BasicDBObject inputJsonObj, String soeId) {
		String viewName=inputJsonObj.getString("viewName");
		Query<User> query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
		subLogger.info("fetching CustomColumnsForDefaultViews for : " + query);
		List<User> user = query.asList();
		List<CustomColumnsView> customColumnListNew = new ArrayList<>();
		if(!user.isEmpty() && user.get(0) !=null && user.get(0).getCustomColumnsForDefaultViews() != null){
			List<CustomColumnsView> customColumnListAll = user.get(0).getCustomColumnsForDefaultViews();
			for (CustomColumnsView customColumnViewLoop : customColumnListAll) {
				if (null != customColumnListAll && null != customColumnViewLoop.getViewName() 
						&& !customColumnViewLoop.getViewName().equalsIgnoreCase(viewName)) {
					customColumnListNew.add(customColumnViewLoop);
				}
			}
			addNewCustomColEntry(inputJsonObj, customColumnListNew);
		}else{
			addNewCustomColEntry(inputJsonObj, customColumnListNew);
		}
		
		BasicDBObject result = new BasicDBObject();
		boolean viewToBeUpdated = checkIfColumnsToShowExistisInViews(user, viewName);
		if(viewToBeUpdated) {
			result.put("updatedView", user.get(0).getViews());
		}
		result.put("customColumnListNew", customColumnListNew);
		return result;
	}

	private boolean checkIfColumnsToShowExistisInViews(List<User> user, String viewName) {
		boolean viewToBeUpdated = false;
		if(!user.isEmpty() && user.get(0) !=null && user.get(0).getViews() != null){
			List<ViewConfig> userViews = user.get(0).getViews();
			for (ViewConfig userView : userViews) {
				if (null != userView && null != userView.getViewName() 
						&& userView.getViewName().equalsIgnoreCase(viewName)) {
					if(null!=userView.getColumnsToShow()) {
						viewToBeUpdated = true;
						userView.setColumnsToShow(null);
						break;
					}
				}
			}
		}
		return viewToBeUpdated;
	}

	/**
	 * @param inputJsonObj
	 * @param customColumnListNew
	 */
	private void addNewCustomColEntry(BasicDBObject inputJsonObj, List<CustomColumnsView> customColumnListNew) {
		CustomColumnsView customColumnsView = new CustomColumnsView();
		customColumnsView.setViewName(inputJsonObj.getString("viewName"));
		List<Map<String, Object>> columnConfig = (List<Map<String, Object>>) inputJsonObj.get("columnConfig");
		customColumnsView.setColumnConfig(columnConfig);
		customColumnListNew.add(customColumnsView);
	}

	/**
	 * This method is used to validate request for Custom Columns For Default Views
	 * @param inputJsonObj
	 * @return
	 */
	private BasicDBObject validateSaveColumnConfig(BasicDBObject inputJsonObj) {
		BasicDBObject response = new BasicDBObject();
		if(null == inputJsonObj.get(VIEW_NAME) || StringUtils.isEmpty((String) inputJsonObj.get(VIEW_NAME))){
			response.put(QmaMailConstants.SUCCESS_KEY, false);
			response.put(QmaMailConstants.MESSAGE_KEY, "Column preferences request is invalid. View name can not be blank/null.");
		}else if(null == inputJsonObj.get(COLUMN_CONFIG)){
			response.put(QmaMailConstants.SUCCESS_KEY, false);
			response.put(QmaMailConstants.MESSAGE_KEY, "Column preferences request request is invalid. columnConfig can not be blank/null.");
		}else if (null != inputJsonObj.get(COLUMN_CONFIG)){
			BasicDBList columnList = (BasicDBList) inputJsonObj.get(COLUMN_CONFIG);
			if(columnList.isEmpty()){
				response.put(QmaMailConstants.SUCCESS_KEY, false);
				response.put(QmaMailConstants.MESSAGE_KEY, "Column preferences request request is invalid. columnConfig can not be blank/null.");
			}else{
				response.put(QmaMailConstants.SUCCESS_KEY, true);
			}
		}
		else{
			response.put(QmaMailConstants.SUCCESS_KEY, true);
		}
		return response;
	}

	/**
	 * This methos is used to get Custom Columns For Default Views if configured else fetch default all column from Config
	 * @param viewName
	 * @param soeId
	 * @param inputJsonObj 
	 * @return
	 */
	public BasicDBObject getCustomColumnsForDefaultViews(String viewName, String soeId) {
		BasicDBObject response = new BasicDBObject();
		try {
			Query<User> query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
			subLogger.info("fetching CustomColumnsForDefaultViews for : " + query);
			List<User> user = query.asList();
			if(!user.isEmpty() && user.get(0) !=null && user.get(0).getCustomColumnsForDefaultViews() != null){
				List<CustomColumnsView> customColumnListAll = user.get(0).getCustomColumnsForDefaultViews();
				//In case Potential Escalation view name changed to "Escalation" while getGridViewData
				//Reverted same to "Potential Escalation" as it is failing viewname comparison with saved custom column view name 
				if( StringUtils.isNotEmpty(viewName)  && InquiryDAO.DEFAULT_VIEW_TYPE_ESCALATION.equalsIgnoreCase(viewName)){
					viewName =  InquiryDAO.DEFAULT_VIEW_TYPE_ESCALATION_UI;
				}
				CustomColumnsView customColumn = populateCustomColumns(viewName, customColumnListAll);
				if(null != customColumn && null != customColumn.getColumnConfig()){
				response.put(QmaMailConstants.SUCCESS_KEY, true);
				response.put(COLUMN_CONFIG, DataConversionUtil.convertJavaObjectToJson(customColumn));
				}else{
					//check for search type view column for saved views
					/*if(null!=inputJsonObj && null!= inputJsonObj.get("viewType") && inputJsonObj.getInt("viewType")==-1 
							&& null!= inputJsonObj.get("myViewSearchInType") ) {
						String searchView = inputJsonObj.getString("myViewSearchInType");
						customColumn = populateCustomColumns(searchView, customColumnListAll);
						if(null != customColumn && null != customColumn.getColumnConfig()){
							customColumn.setViewName(searchView);
							response.put(QmaMailConstants.SUCCESS_KEY, true);
							response.put(COLUMN_CONFIG, DataConversionUtil.convertJavaObjectToJson(customColumn));
							return response;
							}
					}*/
					CustomColumnsView objCustomColumnsView = new CustomColumnsView();
					objCustomColumnsView.setViewName(viewName);
					//Map<String, Config> configData = CacheDAO.getInstance().getConfigIdMap();
					objCustomColumnsView.setColumnConfig(QMACacheFactory.getCache().getConfigById("masterColumnDefAgGrid").getMasterColumnDefAgGrid());
					response.put(QmaMailConstants.SUCCESS_KEY, true);
					response.put(COLUMN_CONFIG, DataConversionUtil.convertJavaObjectToJson(objCustomColumnsView));
				}
			}else{
				CustomColumnsView objCustomColumnsView = new CustomColumnsView();
				objCustomColumnsView.setViewName(viewName);
				//Map<String, Config> configData = CacheDAO.getInstance().getConfigIdMap();
				objCustomColumnsView.setColumnConfig(QMACacheFactory.getCache().getConfigById("masterColumnDefAgGrid").getMasterColumnDefAgGrid());
				response.put(QmaMailConstants.SUCCESS_KEY, true);
				response.put(COLUMN_CONFIG, DataConversionUtil.convertJavaObjectToJson(objCustomColumnsView));
			}
		} catch (Exception e) {
			response.put(QmaMailConstants.SUCCESS_KEY, false);
			response.put(QmaMailConstants.MESSAGE_KEY, "Exception while getting Column preferences data"); 
			subLogger.error(
					"Exception while getting Column preferences in getCustomColumnsForDefaultViews: " + e);
		}
		return response;
	}

	/**
	 * @param viewName
	 * @param customColumnListAll
	 * @param customColumnList
	 */
	private CustomColumnsView populateCustomColumns(String viewName, List<CustomColumnsView> customColumnListAll) {
		CustomColumnsView customColumnsView = new CustomColumnsView();
		for (CustomColumnsView customColumnViewLoop : customColumnListAll) {
			if (null != customColumnListAll && null != customColumnViewLoop.getViewName()
					&& customColumnViewLoop.getViewName().equalsIgnoreCase(viewName)) {
				customColumnsView = addColumnDisplayName(customColumnViewLoop);
				break;
			}/*else{
				CustomColumnsView objCustomColumnsView = new CustomColumnsView();
				objCustomColumnsView.setViewName(viewName);
				Map<String, Config> configData = CacheDAO.getInstance().getConfigIdMap();
				objCustomColumnsView.setColumnConfig(configData.get("masterColumnDefAgGrid").getMasterColumnDefAgGrid());
				customColumnsView = objCustomColumnsView;
			}*/
		}
		return customColumnsView;
	}

	/**
	 * This method used to add headers name to column config
	 * @param customColumnView
	 * @return
	 */
	private CustomColumnsView addColumnDisplayName(CustomColumnsView customColumnView) {
		CustomColumnsView customColumnViewLocal = new CustomColumnsView();
		List<Map<String, Object>> customColumnConfigList = new ArrayList<>();
		for(Map<String, Object> columnConfig: customColumnView.getColumnConfig()){
			Map<String, Object> columnConfigNew = new HashMap<>();
			if(columnConfigNew.containsKey(HEADER_NAME)){
				columnConfigNew.putAll(columnConfig);
			}else{
				columnConfigNew.putAll(columnConfig);
				Object headerName = getDisplyNameFromDefaultConfig(columnConfig.get(COL_ID));
				if(null != headerName){
					columnConfigNew.put(HEADER_NAME, headerName);
				}
				customColumnConfigList.add(columnConfigNew);
			}
		}
		customColumnViewLocal.setViewName(customColumnView.getViewName());
		customColumnViewLocal.setColumnConfig(customColumnConfigList);
		return customColumnViewLocal;
	}
	/**
	 * This method used to displayName from default column config
	 * @param colId
	 * @return
	 */
	private Object getDisplyNameFromDefaultConfig(Object colId) {
		List<Map<String, Object>> columnDefList = QMACacheFactory.getCache().getConfigById("masterColumnDefAgGrid").getMasterColumnDefAgGrid();
		for(Map<String, Object> columnMap:columnDefList){
			if(null != columnMap.get(COL_ID) && null != columnMap.get(HEADER_NAME) && columnMap.get(COL_ID).equals(colId)){
				return columnMap.get(HEADER_NAME);
			}
		}
		return null;
	}

	/**
	 * This method updates Citi Velocity WebSocket Updates config
	 * @param configIdMap
	 * @param userTo
	 */
	private void setCvWebSocketConfig(UserTO userTo) {
		if (null != QMACacheFactory.getCache().getConfigById(CV_WEBSOCKET_CONFIG_KEY))  {
			Map<String, Object> cvWebsocketConfig = QMACacheFactory.getCache().getConfigById(CV_WEBSOCKET_CONFIG_KEY).getCvWebsocketConfig();
			if ( null != cvWebsocketConfig && null != cvWebsocketConfig.get(QMA_WEB_SOCKET_END_POINT_KEY) && 
					null != cvWebsocketConfig.get(CV_STREAMING_TOKEN_URL_KEY)) {
				subLogger.info("**WebSocket :: QMA Websocket update is CV URL enabled in QMA1 for :" + userTo.getUserId() + " ? :" + cvWebsocketConfig.get(CV_WEBSOCKET_UPDATE_ENABLED_FOR_QMA1_KEY));
				subLogger.info("**WebSocket :: QMA Websocket update is CV URL enabled in QMA2 for :" + userTo.getUserId() + " ? :" + cvWebsocketConfig.get(CV_WEBSOCKET_UPDATE_ENABLED_KEY));
				subLogger.info("**WebSocket :: QMA Websocket URL for user :" + userTo.getUserId() + " is  :" + cvWebsocketConfig.get(QMA_WEB_SOCKET_END_POINT_KEY));
				subLogger.info("**WebSocket :: CV Streaming Token URL for user :" + userTo.getUserId() + " is  :" + cvWebsocketConfig.get(CV_STREAMING_TOKEN_URL_KEY));
				userTo.setCvWebsocketConfig(cvWebsocketConfig);
			} else {
				subLogger.info("**WebSocket :: No WebSocket configuration found for user :" + userTo.getUserId());
			}
		}
	}
	
				
	/** this method returns user auth key based on user's geid
	 * @param headers
	 * @return
	 */
	public String getUserAuthKey(HttpHeaders headers, String soeId)
	{
		String authKey = "";
		subLogger.info("In getUserAuthKey for soeId : "+soeId);
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet resultSet = null;
		try
		{
			String geid = GenericUtility.getGeidFromHeader(headers);
			
			if(StringUtils.isEmpty(geid)){
				subLogger.info("geid is blank from CV portal");
				return authKey;
			}
			OracleDBAuthKey odb = OracleDBAuthKey.getInstance();
			if(null == odb){
				subLogger.info("Smart Oracle instance failure ");
				return authKey;
			}
			conn = odb.getConnection();
			if(null == conn){
				subLogger.info("Oracle connection failure ");
				return authKey;
			}
			conn.setReadOnly(true);
			ps = conn.prepareStatement("select user_authkey from ENTL_USER_IMAGE where user_ge_id = ?");
	    	ps.setString(1, geid);
	    	resultSet = ps.executeQuery();
	    	  while (resultSet.next()) {
					authKey = resultSet.getString("user_authkey");
					subLogger.info("Result obtained with user auth key for soeId : "+ soeId+ " is " + authKey);
				}
		    if(!StringUtils.isEmpty(authKey)){
		    	saveUserAuthKey(soeId, authKey);
		    } else {
		    	subLogger.info("auth key is not available for soeId : "+ soeId+ " and Geid: " + geid);
		    }
		} catch (Exception e) {
			  subLogger.error("Exception occurred in getUserAuthKey : "+e);
		  } finally {
			  if(null != resultSet){
		    		try {
						resultSet.close();
						resultSet = null;
					} catch (SQLException e) {
						subLogger.error("Exception occurred in closing resultSet : "+e);
					} 
		    	}
			  if(null != ps){
		    		try {
						ps.close();
						ps = null;
					} catch (SQLException e) {
						subLogger.error("Exception occurred in closing prepare statement : "+e);
					} 
		    	}
			}
			
		return authKey;
	}
	
	private void saveUserAuthKey(String soeId, String userAuthKey){
		try {
			subLogger.info("Inside UserDao.saveUserAuthKey for userId= " + soeId);
			User query = mongoDatastore.createQuery(User.class).filter("_id", soeId).first();
			UpdateOperations<User> ops = mongoDatastore.createUpdateOperations(User.class);
			ops.set("userAuthKey", userAuthKey);
			mongoDatastore.update(query, ops);
		} catch (Exception e) {
			subLogger.error("Exception occurred in saveUserAuthKey for soeId :"+ soeId,e);
		}
	}
	
	/*
	 * C170665-508 add org admin role from user profile for hard code data point
	 */
	public boolean saveOrgAdminData(BasicDBObject inputJsonObj) throws CommunicatorException {
		Query<User> query = null;
		User userObj = null;
		boolean alreadyExist = false;
		boolean saveStatus = false;
		try {
			subLogger.info("Inside saveOrgAdminData for saving user admin details");
			String orgAdmin = (String) inputJsonObj.getString(USERID);
			String orgName = (String) inputJsonObj.getString("orgName");
			String crtBy = (String) inputJsonObj.getString("crtBy");
			if (StringUtils.isBlank(orgAdmin) || StringUtils.isBlank(orgName) || StringUtils.isBlank(crtBy)) {
				subLogger.error("Invalid input for save org admin details for user=" + orgAdmin);
				throw new CommunicatorException("Invalid input for saveOrgAdminData.");
			} else {
				orgAdmin = orgAdmin.toLowerCase();
			}
			query = mongoDatastore.createQuery(User.class).filter("_id", orgAdmin);
			userObj = query.get();
			List<OrgMetaDataAdminRole> orgAdminRoleList = userObj.getOrgAdminRole();
			if (orgAdminRoleList != null && orgAdminRoleList.size() > 0) {
				for (OrgMetaDataAdminRole obj : orgAdminRoleList) {
					if (obj.getOrgName().equalsIgnoreCase(orgName)) {
						alreadyExist = true;
					} else {
						alreadyExist = false;
					}
				}
				if (!alreadyExist) {
					OrgMetaDataAdminRole orgAdminRole = new OrgMetaDataAdminRole();
					orgAdminRole.setOrgName(orgName);
					orgAdminRole.setCrtBy(crtBy);
					Date crtDate = new Date();
					orgAdminRole.setCrtDate(crtDate);
					orgAdminRoleList.add(orgAdminRole);
					userObj.setOrgAdminRole(orgAdminRoleList);
					saveStatus = mongoDatastore.save(userObj) != null ? true : false;
				} else {
					saveStatus = alreadyExist;
				}
			} else {
				orgAdminRoleList = new ArrayList<>();
				OrgMetaDataAdminRole orgAdminRole = new OrgMetaDataAdminRole();
				orgAdminRole.setOrgName(orgName);
				orgAdminRole.setCrtBy(crtBy);
				Date crtDate = new Date();
				orgAdminRole.setCrtDate(crtDate);
				orgAdminRoleList.add(orgAdminRole);
				userObj.setOrgAdminRole(orgAdminRoleList);
				saveStatus = mongoDatastore.save(userObj) != null ? true : false;
			}
			updateUserAdminAuditLogs(crtBy, inputJsonObj, userObj);
			//CacheDAO.getInstance().reloadUserDetailsMap();
			HazelCastCacheIncrementalLoad.refreshUserCache(orgAdmin);
		} catch (Exception e) {
			subLogger.error("Exception in UserDao.saveUserAdminDetails", e);
			throw new CommunicatorException("Exception in UserDao.saveUserAdminDetails");
		}
		return saveStatus;
	}

	/*
	 * C170665-508 for delete org admin role from user profile in hard code data
	 * point
	 */
	
	public boolean deleteOrgAdminData(BasicDBObject inputJsonObj) throws CommunicatorException// Sonar Fix --
	{
		Query<User> query = null;
		User userObj = null;
		boolean saveStatus = false;
		int orgIndex=-1;
		try {
			subLogger.info("Inside deleteOrgAdminData for deleting org admin details");
			String orgAdmin = (String) inputJsonObj.getString(USERID);
			String orgName = (String) inputJsonObj.getString("orgName");
			String deletedBy = (String) inputJsonObj.getString("crtBy");
			if (StringUtils.isBlank(orgAdmin) && StringUtils.isBlank(deletedBy)) {
				subLogger.error("Invalid input for delete org admin details for user=" + orgAdmin);
				throw new CommunicatorException("Invalid input for deleteOrgAdminData.");
			} else {
				orgAdmin = orgAdmin.toLowerCase();
			}
			query = mongoDatastore.createQuery(User.class).filter("_id", orgAdmin);
			userObj = query.get();
			if (userObj != null) {
				List<OrgMetaDataAdminRole> orgAdminRoleList=userObj.getOrgAdminRole();
				if(orgAdminRoleList!=null && orgAdminRoleList.size()>0) {
					for(OrgMetaDataAdminRole obj:orgAdminRoleList) {
						if(obj.getOrgName().equalsIgnoreCase(orgName)) {
							orgIndex=orgAdminRoleList.indexOf(obj);
						}
					}
					if(orgIndex!=-1) {
						orgAdminRoleList.remove(orgIndex);
						userObj.setOrgAdminRole(orgAdminRoleList);
					}
					saveStatus = mongoDatastore.save(userObj) != null ? true : false;
				}else {
					saveStatus=false;
				}
			}
			updateUserAdminAuditLogs(deletedBy, inputJsonObj, userObj); //
			//CacheDAO.getInstance().reloadUserDetailsMap();
			HazelCastCacheIncrementalLoad.refreshUserCache(orgAdmin);

		} catch (Exception e) {
			subLogger.error("Exception in UserDao.deleteOrgAdminData", e);
			throw new CommunicatorException("Exception in UserDao.deleteOrgAdminData");
		}
		return saveStatus;
	}
	//C170665-185 method for get org name from group
	public String getOrgName(Group grp) {
		String orgHierarchyOrgName = "";
		String secondLevelHierarchyUserName = "";
		String orgName = "";
		try {
			ManagementHeirarchy heirarchy = grp.getHeirarchyData();
			if (heirarchy != null && heirarchy.getSecondLevelHeirarchy() != null
					&& heirarchy.getOrgHierarchy() != null) {
				List<HierarchyUserDetail> secondLevelHeirarchy = heirarchy.getSecondLevelHeirarchy();
				List<HierarchyOrgDetails> orgHierarchy = heirarchy.getOrgHierarchy();
				if (null != orgHierarchy && orgHierarchy.size() > 0 && null != secondLevelHeirarchy
						&& secondLevelHeirarchy.size() > 0) {
					for (HierarchyOrgDetails hierarchyOrgDetails : orgHierarchy) {// for org name
						if (hierarchyOrgDetails.getLevel().equalsIgnoreCase("L3")) {
							orgHierarchyOrgName = hierarchyOrgDetails.getOrgName();
							break;
						}
					}
					for (HierarchyUserDetail secondLevelData : secondLevelHeirarchy) {
						secondLevelHierarchyUserName = secondLevelData.getUserName();
					}
					orgName = orgHierarchyOrgName + "(" + secondLevelHierarchyUserName + ")";
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception has been UserDAO.getOrgName", e);
		}
		return orgName;
	}
    
     /*
      * method for sort metadata
      */
	public void sortMetaData(Group grp) {
		GenericUtility.getCaseInsensitiveSortedList(grp.getRequestTypes());
		GenericUtility.getCaseInsensitiveSortedList(grp.getTags());
		GenericUtility.getCaseInsensitiveSortedList(grp.getProcessingRegionList());
		GenericUtility.getCaseInsensitiveSortedList(grp.getRootCauseList());// C153176-1262 Root cause is not ordered
																			// alphabetically
		// C170665-10 | Sort the Root Cause list mapped with Request Type
		if (null != grp.getRequestTypeRootCauseMapping()) {
			for (Map.Entry<String, List<String>> entry : grp.getRequestTypeRootCauseMapping().entrySet()) {
				GenericUtility.getCaseInsensitiveSortedList(entry.getValue());
			}
		}
		grp.getRequestTypeMappings();
	}

    /*
     * method for get union of request type root cause mapping when org enable group level edit meta data
     */
    
	public Map<String, List<String>> getRequestTypeRootCauseMappingUnion(Organization organization, Group grp) {
		Map<String, List<String>> orgRequestTypeRootCauseMappingMap = organization.getRequestTypeRootCauseMapping();
		Map<String, List<String>> groupRequestTypeRootCauseMappingMap = grp.getRequestTypeRootCauseMapping();
		Map<String, List<String>> orgAndGroupUnionMap = orgRequestTypeRootCauseMappingMap;
		try {
			groupRequestTypeRootCauseMappingMap.forEach((key, value) -> {
				List<String> orgAndGroupRequestTypeRootCauseMappingList = new ArrayList<>();
				if (orgAndGroupUnionMap.containsKey(key)) {
					orgAndGroupRequestTypeRootCauseMappingList.addAll(orgAndGroupUnionMap.get(key));
					orgAndGroupRequestTypeRootCauseMappingList.addAll(groupRequestTypeRootCauseMappingMap.get(key));
					Set<String> orgAndGroupRequestTypeMappingSet = new HashSet(
							orgAndGroupRequestTypeRootCauseMappingList);
					List<String> orgAndGroupRequestTypeRootCauseMappingUnion = new ArrayList<>(
							orgAndGroupRequestTypeMappingSet);
					orgAndGroupUnionMap.put(key, orgAndGroupRequestTypeRootCauseMappingUnion);
				} else {
					orgAndGroupUnionMap.put(key, value);
				}
			});
		} catch (Exception e) {
			subLogger.error("Exception has been occured in UserDAO.getRequestTypeRootCauseMappingUnion" + e);
		}
		return orgAndGroupUnionMap;
	}
    
    /*
     * method for get union of org and group metadata when when org admin enable org group level edit meta data
     */
	public void getUnionOfOrgAndGroupMetaData(Organization organization, Group grp) {
		try {
			List<String> orgAndGroupRequestTypeList = new ArrayList();
			orgAndGroupRequestTypeList.addAll(organization.getRequestTypes());
			orgAndGroupRequestTypeList.addAll(grp.getRequestTypes());
			Set<String> orgAndGroupRequestTypeSet = new HashSet(orgAndGroupRequestTypeList);
			List<String> orgAndGroupRequestUnion = new ArrayList(orgAndGroupRequestTypeSet);
			// for union of high level request type mapping of org and group
			List<HighlevelRequestType> orgAndGroupHighLevelRequestList = new ArrayList<>();
			orgAndGroupHighLevelRequestList.addAll(organization.getHighLevelRequestTypeMapping());
			orgAndGroupHighLevelRequestList.addAll(grp.getRequestTypeMappings());
			Set<HighlevelRequestType> orgAndGroupHighLevelRequestSet = new HashSet(orgAndGroupHighLevelRequestList);
			List<HighlevelRequestType> orgAndGroupHighLevelRequestUnion = new ArrayList(orgAndGroupHighLevelRequestSet);
			// for union of root cause of org and group
			List<String> orgAndGroupRootCauseList = new ArrayList<>();
			orgAndGroupRootCauseList.addAll(organization.getRootCause());
			orgAndGroupRootCauseList.addAll(grp.getRootCauseList());
			Set<String> orgAndGroupRootCauseSet = new HashSet(orgAndGroupRootCauseList);
			List<String> orgAndGroupRootCauseUnion = new ArrayList(orgAndGroupRootCauseSet);
			// for Union of request type root cause mapping
			Map<String, List<String>> requestTypeRootCauseMappingUnion = getRequestTypeRootCauseMappingUnion(
					organization, grp);
			grp.setRequestTypes(orgAndGroupRequestUnion);
			grp.setRequestTypeMappings(orgAndGroupHighLevelRequestUnion);
			grp.setRootCauseList(orgAndGroupRootCauseUnion);
			grp.setRequestTypeRootCauseMapping(requestTypeRootCauseMappingUnion);
		} catch (Exception e) {
			subLogger.error("Exception has been occured in UserDAO.getUnionOfOrgAndGroupMetaData()" + e);
		}
	}
	public ManagementHeirarchy getMgmtHeirarchy(String userId, BasicDBObject inputJsonObj) {
		ManagementHeirarchy hierarchy = null;
		try {
			if (null != inputJsonObj.get(ID)) {
				userId = inputJsonObj.getString(ID);
			}
			hierarchy = GlobalDirectoryService.getInstance().getMangementHeirarchyBySoeId(userId);
			
		} catch (Exception ex) {
			subLogger.error("Exception in getMgmtHeirarchy:" + ex);
		}
		return hierarchy;
	}
	
	public String getContactSuggestion(String soeId, BasicDBObject inputJsonObj) {
		String suggestion = null;
		try {
			suggestion = GlobalDirectoryService.getInstance().getContactSuggestion(inputJsonObj);
			
		} catch (Exception ex) {
			subLogger.error("Exception in getContactSuggestion:" + ex);
		}
		return suggestion;
	}

	public String getContactInfo(String soeId, BasicDBObject inputJsonObj) {
		String suggestion = null;
		try {
			suggestion = GlobalDirectoryService.getInstance().getContactInfo(inputJsonObj);
			
		} catch (Exception ex) {
			subLogger.error("Exception in getContactInfo:" + ex);
		}
		return suggestion;
	}


	/**
	 * This method syncs user data from shared to personal
	 * @param soeId
	 */
	private void syncUserDetailsToPersonalDb(String soeId) {
		try {
			subLogger.info("Syncing User : {} data to personal DB", soeId);
			DataSyncDao.getInstance().syncDBById(soeId);
			subLogger.info("Data Sync Completed for User : {} ", soeId);
		} catch (Exception e) {
			subLogger.warn(" Data Sync failed for user : {} post profile update ", soeId);
		}
	}

	/**
	 * This method will onboard user mailbox to database.
	 * @param soeId
	 * @param exchUrl
	 * @param exchDomain
	 * @param exchPassword
	 * @param exchPasswordIV
	 */
	private void addMailBoxDLMappingForUser(String soeId, String exchUrl, String exchDomain, String exchPassword, String exchPasswordIV) {
		try {
			BasicDBObject request = new BasicDBObject();
			request.put("_id",soeId);
			request.put("region",exchDomain);
			request.put("connectionURL",exchUrl);
			request.put("mappingType","PERSONAL");
			request.put("secret",exchPassword);
			request.put("secretIV",exchPasswordIV);
			BasicDBObject response = ReaderUIOperationsDAO.getInstance().addReader(soeId,request);
			if( null != response && response.getBoolean("status")) {
				subLogger.info("User Mailbox Onboarded for user :{} : {}",soeId, response.getString("message"));
			} else {
				subLogger.warn("Failed to onboard user mailbox for : {} : {}", soeId, response.getString("message"));
			}
		} catch (Exception e) {
			subLogger.warn("Exception while adding mailbox dl mapping for user : {}", soeId, e);
		}
	}

	/**
	 * This method will update the user profile
	 * @param request
	 * @return BasicDBObject
	 */
	public BasicDBObject updateUserProfile(String request) {
		BasicDBObject result = new BasicDBObject();
		try {
			BasicDBObject requestObj = BasicDBObject.parse(request);
			String userId = requestObj.getString("userId");
			String isPersonalEmailSubscribedStr = requestObj.getString("personalEmailSubscribed");
			boolean isPersonalEmailSubscribed = Boolean.parseBoolean(isPersonalEmailSubscribedStr);
			if(StringUtils.isNotEmpty(userId) && isPersonalEmailSubscribed) {
				Query<User> query = mongoDatastore.createQuery(User.class)
						.filter("_id", userId).filter("active",true);
				User user = query.first();
				if(null != user) {
					UpdateOperations<User> updateOps = mongoDatastore.createUpdateOperations(User.class);
					updateOps.set("isPersonalEmailSubscribed", true);
					updateOps.set("isPersonalAccountActive", false);
					mongoDatastore.update(query, updateOps);
					result.put("success", true);
					result.put("message","User profile updated.");
				} else {
					result.put("success", false);
					result.put("message","No valid user found");
				}
			}
		} catch (Exception e) {
			subLogger.warn("Exception while updating user profile :" ,e );
			result.put("success", false);
			result.put("message","Issue while updating user profile");
		}
		return result;
	}

	/**
	 * This method will provide column config for individual view
	 * @param soeId
	 * @return BasicDBObject
	 */
	public BasicDBObject getColumnConfigForIndividualView(String soeId) {
		BasicDBObject response = new BasicDBObject();
		try {
			CustomColumnsView individualColumnConfig = new CustomColumnsView();
			individualColumnConfig.setViewName(QmaMailConstants.INDIVIDUAL_VIEW_NAME);
			QMACache cache = QMACacheFactory.getCache();
			User user = cache.getUserInfoMap().get(soeId.toUpperCase());
			if(null != user && null != user.getCustomColumnsForDefaultViews() && !user.getCustomColumnsForDefaultViews().isEmpty()) {
				List<CustomColumnsView> userDefaultViews = user.getCustomColumnsForDefaultViews();
				individualColumnConfig = populateCustomColumns(QmaMailConstants.INDIVIDUAL_VIEW_NAME, userDefaultViews);
			} else {
				Config masterColumnConfig = cache.getConfigById("masterColumnDefIndividual");
				if(null!= masterColumnConfig && null != masterColumnConfig.getMasterColumnDefIndividual() && !masterColumnConfig.getMasterColumnDefIndividual().isEmpty()) {
					individualColumnConfig.setColumnConfig(masterColumnConfig.getMasterColumnDefIndividual());
				}
			}
			response.put(QmaMailConstants.SUCCESS_KEY, true);
			response.put(COLUMN_CONFIG, DataConversionUtil.convertJavaObjectToJson(individualColumnConfig));
		} catch (Exception e){
			subLogger.warn("Exception while getting column config for individual view for user : {} : ", soeId,e);
			response.put(QmaMailConstants.SUCCESS_KEY, false);
			response.put(QmaMailConstants.MESSAGE_KEY, "Could not fetch individual column config data for user :" + soeId);
		}
		return response;
	}
	/**
	 * This method will return historical search keywords
	 * @param soeId
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBObject getSearchKeyWords(String soeId) throws CommunicatorException {
		BasicDBObject basicDBObject = new BasicDBObject();
		Map<String, String> searchKeywordsMap = new LinkedHashMap<>();
		long startTime = System.currentTimeMillis();
		try {
			Query<UserSearchData> query = mongoDatastore.createQuery(UserSearchData.class).filter(USERID, soeId);
			query.order("-crtDate");
			query.limit(1000);
			List<UserSearchData> userSearchData = query.asList();
			for(UserSearchData searchData: userSearchData) {
				searchKeywordsMap.put(searchData.getId().toString(),searchData.getSearchKeyword());
			}
		} catch (Exception e) {
			subLogger.warn("Error while fetching user search keywords.", e);
		}
		basicDBObject.put(DATA, searchKeywordsMap);
		subLogger.info("Total time to fetch user search keywords (millis):{}",System.currentTimeMillis() - startTime);
		return basicDBObject;

	}
	/**
	 * This method used to save user search details like new search keywords and feedback
	 * @param inputJsonObj
	 * @param soeId
	 */
	public BasicDBObject saveSmartSearchDetails(String request, String soeId) {
		BasicDBObject responseObject = new BasicDBObject();
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			UserSearchData userSearchData = new UserSearchData();
			if (null == inputJsonObj.get(SEARCH_KEY_ID)) {
				String solrSearchText = inputJsonObj.getString(SEARCH_KEYWORD);
				subLogger.info("New keyword:{}, for userId:{}",solrSearchText, soeId);
				userSearchData.setUserId(soeId);
				userSearchData.setSearchKeyword(solrSearchText);
				userSearchData.setCrtDate(new Date());
				Key<UserSearchData> userSearchDataKey = mongoDatastore.save(userSearchData);
				responseObject.put(DATA, "Search keyword saved successfully");
				responseObject.put(ID, userSearchDataKey.getId().toString());
			}else {
				String searchKeyId = inputJsonObj.getString(SEARCH_KEY_ID); 
				Query<UserSearchData> query = mongoDatastore.createQuery(UserSearchData.class).filter(ID,  new ObjectId(searchKeyId));
				userSearchData = query.get();
				UpdateOperations<UserSearchData> ops = mongoDatastore.createUpdateOperations(UserSearchData.class);
				ops.set(MOD_DATE, new Date());
				BasicDBObject feedBackObject = getUserFeedbackFromRequest(inputJsonObj);
				if(null != feedBackObject) {
					ops.set(USER_FEEDBACK,feedBackObject);	
				}
				mongoDatastore.update(query, ops);
				responseObject.put(DATA, "Thank You for submitting your feedback");
			}
		} catch (Exception ex) {
			responseObject.put(DATA, "FAILED");
			subLogger.warn("Exception while saving user search data:{}",ex.getMessage());
		}
		return responseObject;
	}

	/**
	 * @param requestObject
	 * @return
	 */
	private BasicDBObject getUserFeedbackFromRequest(BasicDBObject requestObject) {
		BasicDBObject feedbackObject = null;
		if(requestObject.containsField(USER_FEEDBACK)) {
			feedbackObject = (BasicDBObject) requestObject.get(USER_FEEDBACK);
		}
		return feedbackObject;
	}
	
	public synchronized boolean removeGroupEntitlementForUser(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {
		Query<User> query = null;
		User user = null;
		UpdateOperations<User> ops = null;
		try
		{
			subLogger.info("Inside UserDao.removeGroupEntitlementForUser for removing group roles for user: {}", soeId);
			String userId = inputJsonObj.getString(USERID);
			String groupName = inputJsonObj.getString(GROUP_NAME_FIELD);
            String groupRoleToRemove = inputJsonObj.getString("groupRole");
			String isTermination = inputJsonObj.getString(REMOVE_LOGIN_KEY);
			
			// C170665-4814
			subLogger.info("Before updating groupRoleToRemove :: {}", groupRoleToRemove);
			if(StringUtils.isNotBlank(groupRoleToRemove) && USER_GROUP_ROLE_STANDARD_USER.equalsIgnoreCase(groupRoleToRemove)) {
				groupRoleToRemove = USER_GROUP_ROLE_ANALYST;
			}
			subLogger.info("After updating groupRoleToRemove :: {}", groupRoleToRemove);
			
			if(StringUtils.isBlank(userId)) {
				subLogger.error("removeGroupEntitlementForUser - Invalid UserId");
				throw new CommunicatorException("removeGroupEntitlementForUser - Invalid UserId");
			}
			
			userId = userId.toLowerCase();
			
			Map<String, Long> groupCodeToIdMap = QMACacheFactory.getCache().getGroupCodeToIdMap();
			Long groupId = groupCodeToIdMap.get(groupName);
			if(null == groupId && !"true".equalsIgnoreCase(isTermination)){
				subLogger.error("Invalid input to remove group name: {}", groupName);
				throw new CommunicatorException("Invalid input to remove group name: " + groupName);
			}
			Map<String,User> userMap = QMACacheFactory.getCache().getUserInfoMap();
			if(StringUtils.isBlank(soeId) || null == userMap.get(userId.toUpperCase()))
			{
				subLogger.error("No valid user found in QMA: {} or {}", soeId,userId);
				throw new CommunicatorException("No valid user found in QMA: " + soeId + " or " + userId);
			}
			
			query = mongoDatastore.createQuery(User.class).filter("_id", userId);
			user = query.first();
			ops = mongoDatastore.createUpdateOperations(User.class);
			
			
			if (user != null) {
				List<GroupRole> existingGroupRoles = user.getGroupRoles();
				if(existingGroupRoles == null) {
					existingGroupRoles = new ArrayList<>();
				}
				
				String oldValue = "" + existingGroupRoles;
				
				ops.set(ACTIVE, user.getActive());
				ops.set("modBy", soeId);
				ops.set(MOD_DATE, new Date());
				
				if("true".equalsIgnoreCase(isTermination)) {
					// In case of Termination, remove all groups, admin roles and make the user inactive.
					ops.set(GROUP_ROLES, new BasicDBList());
					ops.set(ADMIN_ROLES, new BasicDBList());
					ops.set("active", false);
					
					String actionDetails = "Removed Groups - ALL";
					String newValue = "";
					
					mongoDatastore.update(query, ops);
					updateUserAdminAudit("IDM_DELETE_ENTITLEMENT_GROUP", actionDetails, soeId, newValue, oldValue, userId, "Group entitlement removed");
				} else {
					removeExistingGroups(soeId, query, user, ops, userId, groupRoleToRemove, groupId, existingGroupRoles);
				}
				HazelCastCacheIncrementalLoad.refreshUserCache(userId);
				return true;
			}
		}catch(Exception e){
			throw new CommunicatorException("Exception in UserDao.removeGroupEntitlementForUser " +e.getMessage());
		}
		
		return false;
	}

	/**
	 * @param soeId
	 * @param query
	 * @param user
	 * @param ops
	 * @param userId
	 * @param groupRoleToRemove
	 * @param groupId
	 * @param removedRoles
	 * @throws CommunicatorException
	 */
	private synchronized void removeExistingGroups(String soeId, Query<User> query, User user, UpdateOperations<User> ops, String userId, String groupRoleToRemove, Long groupId, List<GroupRole> existingGroupRoles) throws CommunicatorException {
		List<String> removedRoles = new ArrayList<>();
		
		String oldValue = "" + existingGroupRoles;
		subLogger.info("removeExistingGroups for User :: {}", user.getId());
		
		Iterator<GroupRole> itr = existingGroupRoles.iterator();
		while(itr.hasNext()) {
			GroupRole groupRole = itr.next();
			if(groupId.equals(groupRole.getGroupId()) && groupRoleToRemove.equalsIgnoreCase(groupRole.getRole())) {
				removedRoles.add(groupRole.getGroupId() +" - "+groupRole.getRole());
				itr.remove();
			}
		}
		
		String actionDetails = "Removed Roles- " + removedRoles;
		String newValue ="" + existingGroupRoles;
		ops.set(ACTIVE, user.getActive());
		ops.set("modBy", soeId);
		ops.set(MOD_DATE, new Date());
		ops.set(GROUP_ROLES, (existingGroupRoles.isEmpty()) ? new BasicDBList() : existingGroupRoles);
		mongoDatastore.update(query, ops);
		subLogger.info("removeExistingGroups :: After update");
		
		updateUserAdminAudit("IDM_DELETE_ENTITLEMENT_GROUP", actionDetails, soeId, newValue, oldValue, userId, "Group entitlement removed");
	}

	/**
	 * Helper method to check if email sharing is blocked for the group
	 *
	/**
	 * Helper method to check if email sharing is blocked for the group
	 */
	private boolean processGroupEmailSharing(String mapToGroupsName, String email) {
		Query<Group> queryGroup = this.mongoDatastore.createQuery(Group.class).filter(GROUP_NAME_FIELD, mapToGroupsName);
		Group group = queryGroup.get();

		if (group != null && Boolean.TRUE.equals(group.getIsEmailSharingBlocked())) {
			return GenericUtility.isCitiDomainEmail(email);

		}
		return true;
	}

}
