package com.citi.icg.qma.common.core.util;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * This class represents an average value.
 */
public class Average implements Serializable, Comparable
{
	private static final long serialVersionUID = 1000001L;
	
	// --- Instance Variables ---

	/** Total of values. */
	private double total = 0;

	/** Count of values. */
	private int count = 0;

	/** Min value observed. */
	private double min = 0;

	/** Max value observed. */
	private double max = 0;

	/** Holds Object array */
	private ArrayList list = new ArrayList();

	/** Date of the execution which took max. time **/
	private long maxDate;

	/** Last execution Date **/
	private long lastExeStartTime;

	/** Last event for this average **/

	/**
	 * Constructs an IcgAverage.
	 */
	public Average()
	{
	}

	/**
	 * Constructs an IcgAverage with the specified values.
	 */
	public Average(double total, int count)
	{
		this.total = total;
		this.count = count;
	}

	// --- Instance Methods ---

	/**
	 * Retrieves total of all values.
	 */
	public double getTotal()
	{
		return total;
	}

	/**
	 * Retrieves count of values.
	 */
	public int getCount()
	{
		return count;
	}

	/**
	 * Retrieves the minimum observed value.
	 */
	public long getMinInMilliseconds()
	{
		return TimeUnit.MILLISECONDS.convert((long) (min), TimeUnit.NANOSECONDS);
	}

	/**
	 * Retrieves the maximum observed value.
	 */
	public long getMaxInMilliseconds()
	{
		return TimeUnit.MILLISECONDS.convert((long) (max), TimeUnit.NANOSECONDS);
	}

	/**
	 * Retrieves the maximum observed value's Date.
	 */
	public String getMaxDate()
	{
		return DateUtil.formatDate(maxDate, DateUtil.SIMPLE_DATE_FORMAT_SS);
	}

	/**
	 * Adds a value to the average.
	 */
	public void add(double value)
	{
		setLastExecDate();

		if (count == 0)
			min = value;
		else
			min = Math.min(min, value);

		/*** Added By Nilesh ***/
		if (value > max)
		{
			setMaxExecDate();
		}
		/******/

		max = Math.max(max, value);

		total += value;
		count++;
	}

	/**
	 * Retrieves the average.
	 */
	public long getAverageInMilliseconds()
	{
		if (total == 0)
			return 0;

		return TimeUnit.MILLISECONDS.convert((long) (total / count), TimeUnit.NANOSECONDS);
	}

	/**
	 * It Sets the TimeStamp for the max. execution time taken for a particular
	 * execution
	 */
	private void setMaxExecDate()
	{
		maxDate = System.currentTimeMillis();
	}

	/**
	 * It Sets the TimeStamp for the last execution time for a particular
	 * execution
	 */
	private void setLastExecDate()
	{
		lastExeStartTime = System.currentTimeMillis();
	}

	/**
	 * It will sort the STATEMENT data as per No. execution count & Max.
	 * execution time
	 */
	//Sonar fix -- use override annotation on overridden method
  	@Override
  	public int compareTo(Object obj)
	{
		Average ia = (Average) obj;

		if (this.count > ia.count)
		{
			return -1;
		}
		else if (this.count < ia.count)
		{
			return 1;
		}
		else if ((this.count == ia.count) && (this.max > ia.max))//Sonar Fix -- Correct this "&" to "&&"
		{
			return -1;
		}
		else if ((this.count == ia.count) && (this.max < ia.max))//Sonar Fix -- Correct this "&" to "&&"
		{
			return 1;
		}
		return 0;
	}

	@Override
	public String toString()
	{
		DecimalFormat decimalFormatter = new DecimalFormat("#0.00");
		decimalFormatter.setGroupingSize(3);
		decimalFormatter.setGroupingUsed(true);
		return decimalFormatter.format(getAverageInMilliseconds());
	}

	public void addObject(Object ref)
	{
		list.add(ref);
	}

	public List getObjectList()
	{
		return list;
	}

	public String getLastExeStartTime()
	{
		return DateUtil.formatDate(lastExeStartTime, DateUtil.SIMPLE_DATE_FORMAT_SS);
	}

	public long getLastExeStartTimeLong()
	{
		return lastExeStartTime;
	}

	@Override  //Sonar fix -- use override equals if overriding compareTo
	public boolean equals(Object obj)
	{
		return super.equals(obj);
	}
	
	@Override  //Sonar fix -- use override hashcode if overriding equals
	public int hashCode()
	{
		return super.hashCode();
	}
}
