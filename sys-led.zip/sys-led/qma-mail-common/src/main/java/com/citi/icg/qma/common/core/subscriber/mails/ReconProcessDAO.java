package com.citi.icg.qma.common.core.subscriber.mails;


import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.subscriber.mails.entity.InquiryMail;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.persistence.MongoMorphiaDAO;


public class ReconProcessDAO extends MongoMorphiaDAO {
	
	private static Logger subLogger = LoggerFactory.getLogger(ReconProcessDAO.class);
	/**
	 * @param inquiryMail
	 * when the mail is received this method will update the ReconPreProcess collection
	 */
	public void updateReconPreProcess  (InquiryMail inquiryMail) 
	{
		String messageId  = inquiryMail.getEnvelope().getMessageId();
		try {
			
			subLogger.info("START: Recon Preprocess for message ID - {}",messageId);
			ReconPreProcess reconPreProces = new ReconPreProcess();
			reconPreProces.setMessageId(messageId);
			reconPreProces.setConversationRecipients(getRecipientList(inquiryMail));
			mongoDatastore.save(reconPreProces);
		} catch (Exception e) {
			subLogger.error("Issue in recon PreProcess for MessageId: {}",messageId);
		}
		subLogger.info("END: Recon Preprocess is updated.");
	}

	/**
	 * @param messageId
	 * @param conversationRecepients
	 * @param inquiryId
	 * once the incoming mail is processed this will update the ReconPostProcess collection
	 */
	public void updateReconPostProcess (String messageId, List<ConversationRecipient> conversationRecepients, Long inquiryId) 
	{
		try {
			subLogger.info("Start: Recon Postprocess for Message ID - {}",messageId);
			ReconPostProcess reconPostProces = new ReconPostProcess();
			reconPostProces.setMessageId(messageId);
			reconPostProces.setConversationRecipients(conversationRecepients);
			reconPostProces.setInquiryId(inquiryId);
			mongoDatastore.save(reconPostProces);
		} catch (Exception e) {
			subLogger.error("Issue in recon PostProcess for MessageId: {}",messageId);
		}
		subLogger.info("END: Recon Postprocess is updated.");
	}
	
	/**
	 * @param inquiryMail
	 * @return
	 * Creating recipient list for ReconPreProcess from InquiryMail.
	 * This will create From  To, Cc recipients and the bcc recipients will appear in 'TO' as Undisclosed recipients. 
	 */
	private List<ConversationRecipient> getRecipientList(InquiryMail inquiryMail)
	{
		subLogger.info(" START: Creating recipient List from InquiryMail ");
		
		List<ConversationRecipient> convRecipientList = new ArrayList<>();
		ConversationRecipient conversationRecipient;
		// FROM Recipient
		if (null != inquiryMail.getEnvelope().getFromAddress())
		{
			conversationRecipient = new ConversationRecipient();
			conversationRecipient.setEmailAddr(inquiryMail.getEnvelope().getFromAddress());
			conversationRecipient.setDisplayName(inquiryMail.getEnvelope().getFromName());
			conversationRecipient.setToFrom("FROM");
			convRecipientList.add(conversationRecipient);
		}
		//TO recipient and BCC will appear as undisclosed recipient.
		if(null != inquiryMail.getEnvelope().getToReceipentsAddresses() && 
				!inquiryMail.getEnvelope().getToReceipentsAddresses().isEmpty())
		{
			subLogger.info(" START:Adding TO recipient ");
			List <String> toRecipientAddressList = inquiryMail.getEnvelope().getToReceipentsAddresses();
			List <String> toRecipientNameList= inquiryMail.getEnvelope().getToReceipents();
			for (int i = 0; i < toRecipientAddressList.size(); i++)
			{
				conversationRecipient = new ConversationRecipient();
				conversationRecipient.setEmailAddr(toRecipientAddressList.get(i));
				if (toRecipientNameList.size()>i) 
				{
					conversationRecipient.setDisplayName(toRecipientNameList.get(i));
				}
				conversationRecipient.setToFrom("TO");
				
				convRecipientList.add(conversationRecipient);
			}
		}
		//CC recipient
		if (null != inquiryMail.getEnvelope().getCcReceipentsAddresses() &&
				!inquiryMail.getEnvelope().getCcReceipentsAddresses().isEmpty())
		{
			subLogger.info(" START:Adding CC recipient ");
			List <String> ccRecipientAddressList = inquiryMail.getEnvelope().getCcReceipentsAddresses();
			List <String> ccRecipientNameList= inquiryMail.getEnvelope().getCcReceipents();
			
			for (int i = 0; i < ccRecipientAddressList.size(); i++)
			{
				conversationRecipient = new ConversationRecipient();
				conversationRecipient.setEmailAddr(ccRecipientAddressList.get(i));
				if (ccRecipientNameList.size()>i) 
				{
					conversationRecipient.setDisplayName(ccRecipientNameList.get(i));
				}
				conversationRecipient.setToFrom("CC");
				convRecipientList.add(conversationRecipient);
			}
			
		}
		subLogger.info(" END: Creating recipient List from InquiryMail ");
		return convRecipientList;
	}
	
}
