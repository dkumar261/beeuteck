package com.citi.icg.qma.common.contact.exception;

public class BadRequestException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8720075108053382707L;

	public BadRequestException(String message) {
		super(message);
	}

}
