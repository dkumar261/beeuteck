package com.citi.icg.qma.cims.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DLPropRec {
	@JsonProperty("Guid")
	private String guid;
	@JsonProperty("Description")
	private String description;
	@JsonProperty("SamAccountName")
	private String samAccountName;
	@JsonProperty("DomainShort")
	private String domainShort;
	@JsonProperty("DomainLong")
	private String domainLong;
	@JsonProperty("Email")
	private String email;

    public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSamAccountName() {
		return samAccountName;
	}

	public void setSamAccountName(String samAccountName) {
		this.samAccountName = samAccountName;
	}

	public String getDomainShort() {
		return domainShort;
	}

	public void setDomainShort(String domainShort) {
		this.domainShort = domainShort;
	}

	public String getDomainLong() {
		return domainLong;
	}

	public void setDomainLong(String domainLong) {
		this.domainLong = domainLong;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
