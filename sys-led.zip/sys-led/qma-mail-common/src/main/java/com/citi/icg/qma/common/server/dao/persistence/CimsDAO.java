package com.citi.icg.qma.common.server.dao.persistence;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.time.Instant;
import java.util.*;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.cims.domain.GrpMemberRec;
import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.transferobject.CorporateAddressBookTO;
import com.citi.icg.qma.common.transferobject.UserTO;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;


import dev.morphia.query.Query;

public class CimsDAO extends MongoMorphiaDAO
{

	private final Logger logger = LoggerFactory.getLogger(CimsDAO.class);
	private static CimsDAO instance = null;
	private static final String USERID="userId";
	private static final String CIMS_CONFIG= "cimsConfig";
	private static final String PHONE="Phone";
	private static final String LDESC="Ldesc";
	private static final String LAST_NAME="LastName";
	private static final String FIRST_NAME="FirstName";
	private static final String EMAIL="Email";
	private static final String ERROR_LOG_MSG_FIND_DL_BYNAME="findDLByName";
	private static final String ERROR_LOG_MSG_RESPONSE_NOT_200="getDistributionListMembersbyMail response code is not 200";
	private static final String ERROR_LOG_MSG_API_RESPONSE="getDistributionListMembersbyMail API response: {}";
	public static synchronized CimsDAO getInstance()//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
	{

		if (instance == null) {
			instance = new CimsDAO();
		}
		return instance;
	}
	
	public List<CorporateAddressBookTO> getUserDetailsByName(String request) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		logger.info("Inside CimsDAO.getUserDetailsByName for getting user data with request :{}", request);
		BasicDBObject req = BasicDBObject.parse(request);

		String lastName = req.getString("lastName");
		String firstName = req.getString("firstName");
		List<CorporateAddressBookTO> emailList = new ArrayList<CorporateAddressBookTO>();

		logger.info("Inside CimsDAO.getUserDetailsByName -- first name is {} and last name is {}", firstName, lastName);

		List<BasicDBObject> userList;
		try {
			userList = getUserDataByNameFromCIMSMS(lastName.trim(), firstName.trim());
		} catch (Exception e) {
			throw new CommunicatorException("Error in CimsDAO.getUserDetailsByName", e);
		}

		if (userList != null && !userList.isEmpty())
		{
			for (BasicDBObject rc : userList)
            {
			    
			    if (rc != null)
		        {
			        emailList = createCorporateAddressBookTO(rc, emailList);
		        }else
		        {
		            logger.info("Inside CimsDAO.getUserDetailsByName -- record not found");
		        }
            }
		}
		else
		{
			logger.info("Inside CimsDAO.getUserDetailsByName Record Set not found");
		}
		
		return emailList;
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	private List<BasicDBObject> getUserDataByNameFromCIMSMS(String lastName, String firstName) {
		HttpClient httpClient = null;
		List<BasicDBObject> userList = null;
		try {
			httpClient = getHttpClient();
			String cimsRestApi = getCimsRestApi();
			HttpGet getRequest = new HttpGet(cimsRestApi+"/search/getUserDataByName?lastName="+lastName+"&&firstName="+firstName);
			addHeaderToGetRequest(getRequest);
			HttpResponse response = null;
			response = httpClient.execute(getRequest);
			StringBuilder content = new StringBuilder();
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				content = extractSearchResponse(entity);
				userList = DataConversionUtil.convertJsonToBasicDBObjectList(content.toString());
			} else {
				logger.info("getUserDataByNameFromCIMSMS response code is not 200");
			}
		} catch (Exception e) {
			logger.error("Exception in getUserDataByNameFromCIMSMS", e);
		}
		return userList;
	}
	private StringBuilder extractSearchResponse(HttpEntity entity) {
		StringBuilder content = new StringBuilder();
		byte[] buffer = new byte[1024];
		if (entity != null) {
			InputStream inputStream = null;
			try {
				inputStream = entity.getContent();
			} catch (Exception e) {
				logger.error(" Error in CimsDAO#extractSearchResponse() :", e);
			}
			try (BufferedInputStream bis = new BufferedInputStream(inputStream)) {
				int bytesRead = 0;
				while ((bytesRead = bis.read(buffer)) != -1) {
					String chunk = new String(buffer, 0, bytesRead);
					content.append(chunk);
				}
			} catch (Exception e) {
				logger.error(" Error in CimsDAO#extractSearchResponse() :", e);
			}
		}
		return content;
	}
	private void addHeaderToGetRequest(HttpGet getRequest) {
		getRequest.addHeader("Accept", "application/json");
	}
	
	private HttpClient getHttpClient() throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException {
		HttpClient httpClient = HttpClientBuilder.create().build();
		return httpClient;
	}

	public List<CorporateAddressBookTO> createCorporateAddressBookTO(BasicDBObject rc, List<CorporateAddressBookTO> emailList)
	{
            String name = rc.getString(FIRST_NAME) + " " + rc.getString(LAST_NAME);
            if(null != rc.get(LDESC) && StringUtils.isNotBlank(rc.getString(LDESC))) {
            	name = rc.getString(LDESC);
            }
            String mail = (String) rc.get(EMAIL);
            String department = (String) rc.get("GocLongDesc");
            String phone = (String) rc.get(PHONE);
            String country = (String) rc.get("Country");
          
            //If countryLong doesn't return a value, take country short value.
            if(StringUtils.isEmpty(country))
            {
                country = rc.getString("CountryName");
            }
            
            logger.debug("Name : {},Email : {},Department : {},country : {}", name, mail, department, country);
            
            emailList.add(new CorporateAddressBookTO(name, mail,department,phone,country));
	    
	    return emailList;
	}
	
	public List<CorporateAddressBookTO> getUserDetailsBySoeId(BasicDBObject inputJsonObj) throws CommunicatorException {
	    return getUserDetailsBySoeId( inputJsonObj, null);
	   
	}
	
	public List<CorporateAddressBookTO> getUserDetailsBySoeId(BasicDBObject inputJsonObj, Boolean primaryCheck) throws CommunicatorException
	{
		List<CorporateAddressBookTO> emailList = new ArrayList<CorporateAddressBookTO>();
		try
		{	
		    	boolean checkPrimary = primaryCheck == null ? false :true;
		    	List<BasicDBObject> user = null;
			String userId = inputJsonObj.getString(USERID);
			logger.info("Inside CimsDAO.getUserDataByName -- user Id is {}", userId);
			if(checkPrimary) {
			    user  = getPrimaryUserDataBySoeIdMS(userId.trim());
			}
			else {
			    user = getUserDataBySoeIdMS(userId.trim());
			}
			if (user != null)
			{
				for (BasicDBObject rc : user)
				{
					String name = rc.getString(FIRST_NAME) + " " + rc.getString(LAST_NAME);
					String mail = rc.getString(EMAIL);
					String phone = rc.getString(PHONE);
					String country = rc.getString("CountryLong");
					String department = null;
					String longDesc = null;  
					if(checkPrimary) {
					department = rc.getString("Deptname");
					longDesc  = rc.getString("LDesc");
					}
					if(!checkPrimary) {
					    department = rc.getString("Dept");
					    longDesc =	rc.getString(LDESC);
						}
					//If countryLong doesn't return a value, take country short value.
					if(StringUtils.isEmpty(country))
					{
						country = rc.getString("CountryShort");
					}
					
					if(!StringUtils.isEmpty(department) && department.contains("["))
					{
						department = department.substring(0,department.indexOf("["));
					}
					logger.info("Name : {},Email : {},Department : {},country : {},lDesc : {}", name, mail, department, country, longDesc );
					emailList.add(new CorporateAddressBookTO(name, mail,department,phone,country, longDesc));
				}
			}
			else
			{
				logger.info("Inside CimsDAO.getUserDataByName -- record set not found");
			}
		}
		catch (Exception e)
		{
			logger.error("Exception occurred in CIMS Webservice call",e);
			throw new CommunicatorException("Exception occurred in CIMS Webservice call", e);
		}
		
		return emailList;
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	private List<BasicDBObject> getPrimaryUserDataBySoeIdMS(String userId) {
		HttpClient httpClient = null;
		List<BasicDBObject> user = null;
		try {
		    
			httpClient = getHttpClient();
			String cimsRestApi = getCimsRestApi();
			HttpGet getRequest = new HttpGet(cimsRestApi+"/search/getPrimaryUserDataBySoeid?soeid="+userId);
			addHeaderToGetRequest(getRequest);
			HttpResponse response = null;
			response = httpClient.execute(getRequest);
			logger.info("chatroom list api response: {}",response.toString());
			StringBuilder content = new StringBuilder();
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				content = extractSearchResponse(entity);
				user = DataConversionUtil.convertJsonToBasicDBObjectList(content.toString());
			} else {
			   
				logger.info("getPrimaryUserDataBySoeId response code is not 200");
			}
		} catch (Exception e) {
			logger.error("Exception in getPrimaryUserDataBySoeId", e);
		}
		
		return user;
	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	private List<BasicDBObject> getUserDataBySoeIdMS(String userId) {
		HttpClient httpClient = null;
		List<BasicDBObject> user = null;
		try {
			httpClient = getHttpClient();
			String cimsRestApi = getCimsRestApi();
			HttpGet getRequest = new HttpGet(cimsRestApi+"/search/getUserDataBySoeid?soeid="+userId);
			addHeaderToGetRequest(getRequest);
			HttpResponse response = null;
			response = httpClient.execute(getRequest);
			logger.info("chatroom list api response: {}",response.toString());
			StringBuilder content = new StringBuilder();
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				content = extractSearchResponse(entity);
				user = DataConversionUtil.convertJsonToBasicDBObjectList(content.toString());
			} else {
				logger.info("getUserDataBySoeIdMS response code is not 200" );
			}
		} catch (Exception e) {
			logger.error("Exception in getUserDataBySoeIdMS", e);
		}
		
		return user;
	}
	
	@SuppressWarnings("deprecation")
	public BasicDBObject getUserDetailsBySoeIdMS(String userId) {
		HttpClient httpClient = null;
		BasicDBObject user = null;
		try {
			httpClient = getHttpClient();
			String cimsRestApi = getCimsRestApi();
			HttpGet getRequest = new HttpGet(cimsRestApi+"/search/getUserDetailsBySoeId?soeid="+userId);
			addHeaderToGetRequest(getRequest);
			HttpResponse response = null;
			response = httpClient.execute(getRequest);
			StringBuilder content = new StringBuilder();
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				content = extractSearchResponse(entity);
				user = BasicDBObject.parse(content.toString());
			} else {
				logger.info("getUserDetailsBySoeIdMS response code is not 200");
			}
		} catch (Exception e) {
			logger.error("Exception in getUserDetailsBySoeIdMS", e);
		}
		
		return user;
	}

	public List<CorporateAddressBookTO> getDLDetailsByName(String request) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		String dlName;
		List<BasicDBObject> dlDataList = null;
		List<CorporateAddressBookTO> emailList = new ArrayList<CorporateAddressBookTO>();
		BasicDBObject req = BasicDBObject.parse(request);
		dlName = req.getString("dlName");
		logger.info("DL name is {}", dlName);
		String [] dlArr = dlName.split(";");
		for(String dl : dlArr)
		{
			try
			{
				dlDataList = findDLByName(dl.trim());
			}
			catch (Exception e)
			{
				throw new CommunicatorException("Error in AddressBookDAO.getDLDetailsByName", e);
			}

			if (dlDataList != null)
			{
				
					for (BasicDBObject dlObject : dlDataList)
					{
						logger.info("Email is {} for DL input ={} with desc:{}", dlObject.get(EMAIL), dl, dlObject.get("Description"));
						emailList.add(new CorporateAddressBookTO(dlObject.getString("Description"), dlObject.getString(EMAIL)));
					}
				
			}
			else
			{
				logger.info("Inside AddressBookDAO.getDLDetailsByName -- Record not found");
			}
		}
		
		
		return emailList;
	}
	
	private List<BasicDBObject> findDLByName(String dlName) {
		HttpClient httpClient = null;
		List<BasicDBObject> dlList = null;
		try {
			httpClient = getHttpClient();
			String cimsRestApi = getCimsRestApi();
			HttpGet getRequest = new HttpGet(cimsRestApi + "/search/findDLByName?dlName=" + dlName);
			addHeaderToGetRequest(getRequest);
			HttpResponse response = httpClient.execute(getRequest);
			StringBuilder content = new StringBuilder();
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				content = extractSearchResponse(entity);
				dlList = DataConversionUtil.convertJsonToBasicDBObjectList(content.toString());
			} else {
				logger.info("findDLByName response code is not 200");
			}
		} catch (Exception e) {
			logger.error(ERROR_LOG_MSG_FIND_DL_BYNAME, e);
		}
		return dlList;
	}

	//[C153176-172] - Ability to enter SOEID only to bring up email address
	//Method to return List of user details for given list of soeids
	public List<UserTO> getUsersBySoeIdList(List<String> userIdList) throws CommunicatorException
	{
		List<UserTO> userDetailsList = new ArrayList<UserTO>();
		for(String userId : userIdList)
		{
			if(!StringUtils.isBlank(userId))
			{
				BasicDBObject user = new BasicDBObject();
				user.append(USERID, userId.trim());
				List<CorporateAddressBookTO> userList = getUserDetailsBySoeId(user);
				
				UserTO userDetails = new UserTO();
				userDetails.setUserId(userId);
				
				if(userList!=null && !(userList.isEmpty()) && userList.get(0)!=null)
				{					
					userDetails.setUserId(userId);
					userDetails.setUserName(userList.get(0).getName());
					userDetails.setEmail(userList.get(0).getEmail());
					userDetails.setLongDesc(userList.get(0).getLongDesc());
				}
				
				userDetailsList.add(userDetails);
			}
			
		}
		return userDetailsList;
	}
	
	public void updateAllUsersManagerDetailsByCIMSJob(List<String> receivedUserIdList) {		
		List<User> userList = new ArrayList<User>();
		if(Objects.nonNull(receivedUserIdList) && !receivedUserIdList.isEmpty()) {
			logger.info("Updating manager for specified users(count) : {}", receivedUserIdList.size());
			Query<User> query = mongoDatastore.createQuery(User.class).filter("active", true).filter("_id in ", receivedUserIdList);
			userList = query.asList();
			logger.info("Updating manager for filtered users(count) : {}", userList.size());
		} else {			
			Query<User> query = mongoDatastore.createQuery(User.class).filter("active", true);
			userList = query.asList();
			logger.info("Updating manager for all users(count) : {}", userList.size());
		}
		
		logger.info("Active User list size for UsersManagerDetailsUpdateCIMSJob:::{}", userList.size());
		if (!userList.isEmpty()) {
			Integer totalUsersToBeUpdated = userList.size();
			Integer currentIndex = 0;
			for (User user : userList) {
				currentIndex++;
				updateMangerOfUser(user, totalUsersToBeUpdated, currentIndex);
			}			
		}				
	}

	/**
	 * @param totalUsersToBeUpdated
	 * @param currentIndex
	 * @param user
	 * @return
	 */
	private void updateMangerOfUser(User user, Integer totalUsersToBeUpdated, Integer currentIndex) {
		String userId = user.getId();		
		if (StringUtils.isNotBlank(userId)) {
			Instant startExecute = Instant.now();
			try {
				// Pull User Information from CIMS
				BasicDBObject userRecord = getUserDetailsBySoeIdMS(userId);
				if (userRecord != null) {
					String firstName = userRecord.getString(FIRST_NAME);
					String lastName = userRecord.getString(LAST_NAME);
					String phone = userRecord.getString(PHONE);
					String managerId = userRecord.getString("DepartmentManagerSoeid"); // DirectManagerSoeId is not
																				// having data for all
																				// users.
					String department = userRecord.getString("GocLongDesc");
					String country = userRecord.getString("Country");
					String gocCode = userRecord.getString("GocCode");
					user.setGocCode(gocCode);
					String lDesc = getLDescFromCIMS(userId);
					if (null != lDesc) {
						user.setLongDesc(lDesc);
					}
					// Pull Manager Information from CIMS
					if (StringUtils.isNotBlank(managerId)) {
						BasicDBObject managerRecord = getUserDetailsBySoeIdMS(managerId);
						if (managerRecord != null) {
							String mgrName = managerRecord.getString(FIRST_NAME) + " "
									+ managerRecord.getString(LAST_NAME);
							String mgrEmail = managerRecord.getString(EMAIL);
							String mgrPhone = managerRecord.getString(PHONE);

							// Save User and Manager details in the User collection
							user.setFirstName(firstName);
							user.setLastName(lastName);
							user.setPhone(phone);
							user.setMgrName(mgrName);
							user.setMgrEmail(mgrEmail);
							user.setMgrPhone(mgrPhone);
							user.setDepartment(department);
							user.setCountry(country);
							mongoDatastore.save(user);
							long executeDuration = Duration.between(startExecute, Instant.now())
									.toMillis();
							logger.info(
									"updated manager for userId:{}, (" + currentIndex + "/"
											+ totalUsersToBeUpdated + "), time-taken:{}",
									userId, executeDuration);
						}
					}
				}
			} catch (Exception e) {
				logger.error("Exception in updateAllUsersManagerDetailsByCIMSJob while populating data from CIMS. ", e);
			}

		}
	}
	public String getLDescFromCIMS(String userId) {
	    return getLDescFromCIMS(userId,null);
	}
	
	public String getLDescFromCIMS(String userId, Boolean primaryCheck) {
		String lDesc = null;
		try {
			BasicDBObject inputJsonObj = new BasicDBObject();
			inputJsonObj.put(USERID, userId);
			List<CorporateAddressBookTO> addressBookAll = getUserDetailsBySoeId(inputJsonObj, primaryCheck);
			for (CorporateAddressBookTO addressBook : addressBookAll) {
				lDesc = addressBook.getLongDesc();
			}
		} catch (Exception e) {
			logger.error("Exception while getting lDesc:", e);
		}
		return lDesc;
	}
	
	private String getCimsRestApi() {
		String cimsRestApiEndPoint = null;
		try {
			QMACache qmaCache = QMACacheFactory.getCache();
			if (null != qmaCache.getConfigById(CIMS_CONFIG))
			{
				Config cimsConfig = qmaCache.getConfigById(CIMS_CONFIG);
				if (null != cimsConfig && null != cimsConfig.getCimsConfig()){
					Map<String, Object> cimsConfigObj = cimsConfig.getCimsConfig();
					cimsRestApiEndPoint = (String) cimsConfigObj.get("cimsRestApiEndPoint");
				}
			}
		} catch (Exception e) {
			logger.error("Exception in getCimsRestApi", e);
		}
		return cimsRestApiEndPoint;
	}
	
	public boolean isCimsRestApiEnable() {
		boolean cimsRestApiEnabled = false;
		try {
			QMACache qmaCache = QMACacheFactory.getCache();
			if (null != qmaCache.getConfigById(CIMS_CONFIG))
			{
				Config cimsConfig = qmaCache.getConfigById(CIMS_CONFIG);
				if (null != cimsConfig && null != cimsConfig.getCimsConfig()){
					Map<String, Object> cimsConfigObj = cimsConfig.getCimsConfig();
					cimsRestApiEnabled = (boolean) cimsConfigObj.get("cimsRestApiEnabled");
				}
			}
		} catch (Exception e) {
			logger.error("Exception in isCimsRestApiEnable",e);
		}
		return cimsRestApiEnabled;
	}

	public Map<String, String> getDistributionListMembersbyMail(String groupEmail, String maxRows, String findExactMail) {
		HttpClient httpClient = null;
		Map<String, String> dlList = new HashMap<>();
		try {
			httpClient = getHttpClient();
			String cimsRestApi = getCimsRestApi();
			HttpGet getRequest = new HttpGet(cimsRestApi + "/search/getDistributionListMembersbyMail?email="+groupEmail+"&maxRows="+maxRows+"&findExactMail="+findExactMail);
			addHeaderToGetRequest(getRequest);
			HttpResponse response = httpClient.execute(getRequest);
			StringBuilder content = new StringBuilder();
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				content = extractSearchResponse(entity);
				ObjectMapper objectMapper = new ObjectMapper();
				// Parse JSON array into a list of maps
				List<List<Map<String, String>>> list = objectMapper.readValue(content.toString(), new TypeReference<List<List<Map<String, String>>>>() {});
				List<Map<String, String>> flatList = new ArrayList<>();

				for (List<Map<String, String>> innerList : list) {
					flatList.addAll(innerList);
				}
				for (Map<String, String> item : flatList) {
					dlList.put(item.get("email"), item.get("name"));
				}
			} else {
				logger.info(ERROR_LOG_MSG_RESPONSE_NOT_200);
			}
		} catch (Exception e) {
			logger.error(ERROR_LOG_MSG_FIND_DL_BYNAME, e);
		}
		return dlList;
	}

	public Map<String, List<GrpMemberRec>> getDistributionListHeiracrchy(String groupName, String dlExactMatch, String maxResults) {
		HttpClient httpClient = null;
		Map<String, List<GrpMemberRec>> dlList = null;
		try {
			httpClient = getHttpClient();
			String cimsRestApi = getCimsRestApi();
			HttpGet getRequest = new HttpGet(cimsRestApi + "/search/getDistributionListHeiracrchy?dlName="+groupName+"&maxRows="+maxResults+"&exactMatch="+dlExactMatch);
			addHeaderToGetRequest(getRequest);
			HttpResponse response = httpClient.execute(getRequest);
			StringBuilder content = new StringBuilder();
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				content = extractSearchResponse(entity);
				logger.info("Extracted conent:{}",content.toString());
				dlList = (Map<String, List<GrpMemberRec>>) DataConversionUtil.convertJSONToJava(content.toString(), HashMap.class);
			} else {
				logger.info("getDistributionListMembersbyMail is failed(not 200) with status code {} for DL Name {}",response.getStatusLine().getStatusCode(),groupName);
			}
		} catch (Exception e) {
			logger.error(ERROR_LOG_MSG_FIND_DL_BYNAME, e);
		}
		return dlList;
	}

	public List<String> findAllGroupEmailsFromCIMS(String groupName) {
		HttpClient httpClient = null;
		List<String> dlList = null;
		try {
			httpClient = getHttpClient();
			String cimsRestApi = getCimsRestApi();
			HttpGet getRequest = new HttpGet(cimsRestApi + "/search/findAllGroupEmailsFromCIMS?dlName="+groupName);
			addHeaderToGetRequest(getRequest);
			HttpResponse response = httpClient.execute(getRequest);
			StringBuilder content = new StringBuilder();
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				content = extractSearchResponse(entity);
				dlList = (List<String>) DataConversionUtil.convertJSONToJava(content.toString(), Object.class);
			} else {
				logger.info(ERROR_LOG_MSG_RESPONSE_NOT_200);
			}
		} catch (Exception e) {
			logger.warn(ERROR_LOG_MSG_FIND_DL_BYNAME, e);
		}
		return dlList;
	}
	public List<String> getAllGroupEmailsFromProperties(String groupName) {
		HttpClient httpClient = null;
		List<String> dlList = null;
		try {
			httpClient = getHttpClient();
			String cimsRestApi = getCimsRestApi();
			HttpGet getRequest = new HttpGet(cimsRestApi + "/search/getAllGroupEmailsFromProperties?dlName="+groupName);
			addHeaderToGetRequest(getRequest);
			HttpResponse response = httpClient.execute(getRequest);
			StringBuilder content = new StringBuilder();
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				content = extractSearchResponse(entity);
				dlList = (List<String>) DataConversionUtil.convertJSONToJava(content.toString(), Object.class);
			} else {
				logger.info(ERROR_LOG_MSG_RESPONSE_NOT_200);
			}
		} catch (Exception e) {
			logger.warn(ERROR_LOG_MSG_FIND_DL_BYNAME, e);
		}
		return dlList;
	}

}

