package com.citi.icg.qma.common.server.dao.persistence;

import com.mongodb.DBObject;

public class MicroUiTO {
	
	private Long groupId;
	private String direction;
	private DBObject inquiry;
	
	public MicroUiTO() {
		super();
	}
	
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public DBObject getInquiry() {
		return inquiry;
	}
	public void setInquiry(DBObject inquiry) {
		this.inquiry = inquiry;
	}
}
