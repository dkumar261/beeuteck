package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.CappedAt;
import dev.morphia.annotations.Entity;
import microsoft.exchange.webservices.data.core.enumeration.notification.EventType;

@Entity(value = "IndividualFolderNotification", noClassnameStored = true, cap = @CappedAt(count = 5000, value = 500000))
public class IndividualFolderNotification extends BaseEntity {
    private String userId;
    private String folder;
    EventType eventType;
    private FolderAction action;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFolder() {
        return folder;
    }

    public void setFolder(String folder) {
        this.folder = folder;
    }

    public EventType getEventType() {
        return eventType;
    }

    public void setEventType(EventType eventType) {
        this.eventType = eventType;
    }

    public FolderAction getAction() {
        return action;
    }

    public void setAction(FolderAction action) {
        this.action = action;
    }

    public enum FolderAction {
        ADD, UPDATE, DELETE;
    }
}
