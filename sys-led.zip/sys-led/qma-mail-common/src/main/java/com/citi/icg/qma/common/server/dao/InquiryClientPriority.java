package com.citi.icg.qma.common.server.dao;

import java.util.Date;
import java.util.List;

import com.google.gson.annotations.SerializedName;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "InquiryClientPriority", noClassnameStored = true)
public class InquiryClientPriority{

	@Id
	private String id;
	private Long inquiryId;
	private Long assignedGroupId;
	private String clientPriority;
	private Date crtDate;
	private List<CustomClientCategoryDetails> customClientCategory;
	private String clientName;
	private String gpNum;
	private String gpName;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Long getInquiryId() {
		return inquiryId;
	}
	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}
	public Long getAssignedGroupId() {
		return assignedGroupId;
	}
	public void setAssignedGroupId(Long assignedGroupId) {
		this.assignedGroupId = assignedGroupId;
	}
	public String getClientPriority() {
		return clientPriority;
	}
	public void setClientPriority(String clientPriority) {
		this.clientPriority = clientPriority;
	}
	public Date getCrtDate() {
		return crtDate;
	}
	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}
	public List<CustomClientCategoryDetails> getCustomClientCategory() {
		return customClientCategory;
	}
	public void setCustomClientCategory(List<CustomClientCategoryDetails> customClientCategory) {
		this.customClientCategory = customClientCategory;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getGpNum() {
		return gpNum;
	}
	public void setGpNum(String gpNum) {
		this.gpNum = gpNum;
	}
	public String getGpName() {
		return gpName;
	}
	public void setGpName(String gpName) {
		this.gpName = gpName;
	}
	
	
}
