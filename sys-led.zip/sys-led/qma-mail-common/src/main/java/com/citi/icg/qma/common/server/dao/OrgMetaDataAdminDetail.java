package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

import dev.morphia.annotations.Embedded;

@Embedded
public class OrgMetaDataAdminDetail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3311474814757717391L;
	private String user;  // it is for user name like "XXXXX XXXXX"
	private String soeid; // for soeid like "XXXXXX"

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getSoeid() {
		return soeid;
	}

	public void setSoeid(String soeid) {
		this.soeid = soeid;
	}

}
