package com.citi.icg.qma.common.messagebus.entity;

public class EntityDetails {
	
	private String entityId;
	private String clientId;
	private String baseAccountNumber;
	public EntityDetails() {
		super();
	}
	public String getEntityId() {
		return entityId;
	}
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getBaseAccountNumber() {
		return baseAccountNumber;
	}
	public void setBaseAccountNumber(String baseAccountNumber) {
		this.baseAccountNumber = baseAccountNumber;
	}
	
	

}
