package com.citi.icg.qma.common.server.dao.entity;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "RoleDescription", noClassnameStored = true)
public class RoleDescription
{
	@Id
	private String functionCode;
	private String functionDescription;

	/**
	 * @param functionCode
	 * @param functionDescription
	 */
	public RoleDescription(String functionCode, String functionDescription)
	{
		super();
		this.functionCode = functionCode;
		this.functionDescription = functionDescription;
	}

	public RoleDescription()
	{
		super();
	}

	/**
	 * @return the functionCode
	 */
	public String getFunctionCode()
	{
		return functionCode;
	}

	/**
	 * @param functionCode
	 *            the functionCode to set
	 */
	public void setFunctionCode(String functionCode)
	{
		this.functionCode = functionCode;
	}

	/**
	 * @return the functionDescription
	 */
	public String getFunctionDescription()
	{
		return functionDescription;
	}

	/**
	 * @param functionDescription
	 *            the functionDescription to set
	 */
	public void setFunctionDescription(String functionDescription)
	{
		this.functionDescription = functionDescription;
	}

}
