package com.citi.icg.qma.common.server.util;

import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.citi.icg.qma.common.server.dao.ClientMapping;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

public class ClientMappingUtil {
	/**
	 * If email provided get ClientMapping by emailId, if only domain provided get it using domain.
	 * @param email
	 * @return
	 */
	public static ClientMapping getClientMappingByEmail(String email) {
		Map<String, ClientMapping> cmMap = QMACacheFactory.getCache().getClientMappingMap();
		ClientMapping clientMapping = null;
		if(null != cmMap && StringUtils.isNotBlank(email) && null != cmMap.get(email.toUpperCase())) {
			clientMapping = cmMap.get(email.toUpperCase());
		}else {		
			String emailDomain = getEmailDomain(email);
			if (cmMap != null) {
				clientMapping = cmMap.get(emailDomain);
			}
		}
		return clientMapping;
	}
	/**
	 * Get email domain from email
	 * @param email
	 * @return
	 */
	public static String getEmailDomain(String email)
	{
		String domain="";
		if(StringUtils.isNotBlank(email) && email.indexOf("@")>-1) {
			String[] parts = email.split("@");
			domain= parts[parts.length - 1].toUpperCase();
		}
		return domain;
	}


	public static String getClientNameFromEmail(String email) {
		String clientName = "";
		if (StringUtils.isNotBlank(email) && email.contains("@")) {
			String[] parts = email.split("@");
			clientName = parts[0];
		}
		return clientName;
	}
}
