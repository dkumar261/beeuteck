package com.citi.icg.qma.common.core.config;

import java.util.Properties;

/**
 * XM Configuration interface.
 */
public interface XmConfig
{
	String universalInboxUrl();

	String universalInboxUrlGEMS();

	String universalInboxUrlXMComm();

	String playIconURL();

	String gemurl();

	String gemsAppUrl();

	String xmCommUrl();

	String configPath();

	Properties XM_MESSAGE_BUS();

	Properties XMCommConfig();

	Properties XMWAPP_CONFIG();

	Properties CommandListener();

	Properties TML_CONFIG();

	Properties AUDIT_EMAIL();

	Properties EXCHANGESERVER_CONFIG();

	Properties ATTACHMENT_PATH();

	Properties DOGS_CONFIG();

	Properties ENRICHMENT_CONFIG();

	Properties AHINFO_QAS();

	Properties SOLR_DELTA_IMPORT();	
	
	Properties VOYAGER_CONFIG();
}
