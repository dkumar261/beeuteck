package com.citi.icg.qma.common.server.dao.persistence.oasys.payments;

public class OasysPaymentLine {

	private String accept;
	private String reject;
	private String rejectionReason;
	private String paymentEvaluationCode;
	private String reasonForDispute;
	private String comment;
	private String citiEntity;
	private String customerName;
	private String paymentDate;
	private String amount;
	private String currency;
	private String citiDirection;
	private String citiPaymentInstructions;
	private String customerPaymentInstructions;
	private String productClass;
	private String paymentCategories;
	private String tradeDate;
	private String citiReference;
	private String citiSystemRef;
	private String paymentID;
	

	public String getAccept() {
		return accept;
	}

	public void setAccept(String accept) {
		this.accept = accept;
	}

	public String getReject() {
		return reject;
	}

	public void setReject(String reject) {
		this.reject = reject;
	}

	public String getRejectionReason() {
		return rejectionReason;
	}

	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}

	public String getPaymentEvaluationCode() {
		return paymentEvaluationCode;
	}

	public void setPaymentEvaluationCode(String paymentEvaluationCode) {
		this.paymentEvaluationCode = paymentEvaluationCode;
	}

	public String getReasonForDispute() {
		return reasonForDispute;
	}

	public void setReasonForDispute(String reasonForDispute) {
		this.reasonForDispute = reasonForDispute;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getCitiEntity() {
		return citiEntity;
	}

	public void setCitiEntity(String citiEntity) {
		this.citiEntity = citiEntity;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCitiDirection() {
		return citiDirection;
	}

	public void setCitiDirection(String citiDirection) {
		this.citiDirection = citiDirection;
	}

	public String getCitiPaymentInstructions() {
		return citiPaymentInstructions;
	}

	public void setCitiPaymentInstructions(String citiPaymentInstructions) {
		this.citiPaymentInstructions = citiPaymentInstructions;
	}

	public String getCustomerPaymentInstructions() {
		return customerPaymentInstructions;
	}

	public void setCustomerPaymentInstructions(String customerPaymentInstructions) {
		this.customerPaymentInstructions = customerPaymentInstructions;
	}

	public String getProductClass() {
		return productClass;
	}

	public void setProductClass(String productClass) {
		this.productClass = productClass;
	}

	public String getPaymentCategories() {
		return paymentCategories;
	}

	public void setPaymentCategories(String paymentCategories) {
		this.paymentCategories = paymentCategories;
	}

	public String getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}

	public String getCitiReference() {
		return citiReference;
	}

	public void setCitiReference(String citiReference) {
		this.citiReference = citiReference;
	}

	public String getCitiSystemRef() {
		return citiSystemRef;
	}

	public void setCitiSystemRef(String citiSystemRef) {
		this.citiSystemRef = citiSystemRef;
	}

	public String getPaymentID() {
		return paymentID;
	}

	public void setPaymentID(String paymentID) {
		this.paymentID = paymentID;
	}

}