package com.citi.icg.qma.common.core;

public class XmException extends Exception
{
	private static final long serialVersionUID = -8284950551924944058L;

	public XmException()
	{
		super();
	}

	public XmException(String arg0, Throwable arg1)
	{
		super(arg0, arg1);
	}

	public XmException(String arg0)
	{
		super(arg0);
	}

	public XmException(Throwable arg0)
	{
		super(arg0);
	}
}
