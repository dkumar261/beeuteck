package com.citi.icg.qma.common.server.dao;

public enum NotificationTypeEnum
{
	USERNOTIFICATION,
	USERFEEDBACK;

	public String value()
	{
		return name();
	}

	public static NotificationTypeEnum fromValue(String notification)
	{
		return valueOf(notification);
	}
}
