package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

import dev.morphia.annotations.Embedded;

@Embedded
public class RuleCriteria implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6740983593119262102L;
	private String field;
	private String operators;
	private String value;
	public RuleCriteria() {
		super();
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getOperators() {
		return operators;
	}
	public void setOperators(String operators) {
		this.operators = operators;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public RuleCriteria(String field, String operators, String value) {
		super();
		this.field = field;
		this.operators = operators;
		this.value = value;
	}
}
