/**
 * 
 */
package com.citi.icg.qma.common.server.dao;

import java.util.Date;

import dev.morphia.annotations.Entity;

/**
 * 
 * This is created in order to use the existing inquiry object 
 * along with some archival and GDPR specific attributes.
 */
@Entity(value = "Inquiry", noClassnameStored = true)
public class ArchivedInquiry extends Inquiry {
	private String recordCode;
	private Date archivedOn;
	private boolean isSoftDeleted;
	private Date softDeletedDate;
	private boolean isLegalHold;
	private String legalHoldType;	
	
	
	public String getRecordCode() {
		return recordCode;
	}
	public void setRecordCode(String recordCode) {
		this.recordCode = recordCode;
	}
	public Date getArchivedOn() {
		return archivedOn;
	}
	public void setArchivedOn(Date archivedOn) {
		this.archivedOn = archivedOn;
	}
	public boolean isSoftDeleted() {
		return isSoftDeleted;
	}
	public Date getSoftDeletedDate() {
		return softDeletedDate;
	}
	public void setSoftDeletedDate(Date softDeletedDate) {
		this.softDeletedDate = softDeletedDate;
	}
	public boolean isLegalHold() {
		return isLegalHold;
	}
	public void setLegalHold(boolean isLegalHold) {
		this.isLegalHold = isLegalHold;
	}
	public String getLegalHoldType() {
		return legalHoldType;
	}
	public void setLegalHoldType(String legalHoldType) {
		this.legalHoldType = legalHoldType;
	}
	public void setSoftDeleted(boolean isSoftDeleted) {
		this.isSoftDeleted = isSoftDeleted;
	}
	
}
