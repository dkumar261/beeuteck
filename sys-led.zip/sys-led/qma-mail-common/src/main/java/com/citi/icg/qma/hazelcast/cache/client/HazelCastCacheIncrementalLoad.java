package com.citi.icg.qma.hazelcast.cache.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.GroupRole;
import com.citi.icg.qma.common.server.dao.MailBoxDLMapping;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.persistence.GroupDAO;
import com.citi.icg.qma.common.server.dao.persistence.MongoMorphiaDAO;
import com.citi.icg.qma.common.server.dao.persistence.UserDAO;
import com.citi.icg.qma.common.server.util.DedicatedReaderUtility;
import com.citi.icg.qma.common.transferobject.SymphonyUserMapTO;



public class HazelCastCacheIncrementalLoad extends MongoMorphiaDAO{

	private static final Logger logger = LoggerFactory.getLogger(HazelCastCacheIncrementalLoad.class);
	private static UserDAO userDAO = new UserDAO();
	private static GroupDAO groupDAO = new GroupDAO();
	private static final DedicatedReaderUtility readerUtil = DedicatedReaderUtility.getInstance();
	
	/**
	 * Refresh user data for a userId
	 * @param userId
	 * @throws CommunicatorException
	 */
	public static void refreshUserCache(String userId) {
		logger.info("Refreshing cache for user:"+userId);
		QMACache qmaCacheInstance = QMACacheFactory.getCache();
		User user = updateUserDetailsMap(userId, qmaCacheInstance);
		logger.info("User details map refreshed for userId:"+userId);
		updateGroupIdToUserListMap(user, qmaCacheInstance);
		logger.info("User group entitlements map refreshed for userId:"+userId);
		logger.info("Refresh cache completed for user:"+userId);
	}

	/**
	 * Refresh group data for a group
	 * @param groupId
	 * @throws CommunicatorException
	 */
	public static void refreshGroupInCache(Long groupId) {
		logger.info("Refreshing cache for group:"+groupId);
		QMACache qmaCacheInstance = QMACacheFactory.getCache();
		if(null != groupId) {
			Group group = updateGroupDetails(groupId, qmaCacheInstance);
			updateGroupDetailsActiveInactive(group, qmaCacheInstance);
			updateGroupIdUserList(groupId, qmaCacheInstance);	
		}
		logger.info("Refresh cache completed for group:"+groupId);
	}
		
	/**
	 * Refresh user data for a userId
	 * @param userId
	 * @param qmaCacheInstance 
	 * @return
	 * @throws CommunicatorException
	 */
	private static User updateUserDetailsMap(String userId, QMACache qmaCacheInstance) {
		User user = null;
		try {
			user = userDAO.getUserById(userId);
			if (null != user) {
				qmaCacheInstance.getUserInfoMap().put(user.getId().toUpperCase(), user);
				logger.info("Map refresh completed: getUserInfoMap()");
			}
		} catch (Exception e) {
			logger.warn("Error while updateUserDetailsMap"+e);
		}
		 return user;
	}
	
	/**
	 * Refresh entitlement for a user
	 * @param user
	 * @param qmaCacheInstance 
	 */
	private static void updateGroupIdToUserListMap(User user, QMACache qmaCacheInstance) {
		try {
			List<GroupRole> groupRoleList = new ArrayList<GroupRole>();
			if (null != user && null != user.getGroupRoles()) {
				groupRoleList = user.getGroupRoles();
				Map<Long, String> groupIdToCodeMap = qmaCacheInstance.getGroupIdToNameMap();
				Map<Long, List<String>> groupIdToUserListCache = qmaCacheInstance.getGroupIdToUserListMap();
				for (GroupRole grpRole : groupRoleList) {
					if (grpRole.getGroupId() != null && groupIdToCodeMap.get(grpRole.getGroupId()) != null) {
						if (groupIdToUserListCache.get(grpRole.getGroupId()) == null) {
							List<String> usrList = new ArrayList<String>();
							usrList.add(user.getId());
							qmaCacheInstance.getGroupIdToUserListMap().put(grpRole.getGroupId(), usrList);
						} else {
							List<String> usrList = groupIdToUserListCache.get(grpRole.getGroupId());
							if (!usrList.contains(user.getId())) {
								qmaCacheInstance.getGroupIdToUserListMap().get(grpRole.getGroupId()).add(user.getId());
							}
						}
					}
				}
				
			}
		} catch (Exception e) {
			logger.warn("Error while updateGroupIdToUserListMap"+e);
		}
	}
	/**
	 * Refresh user entitlement for a group
	 * @param groupId
	 * @param qmaCacheInstance 
	 * @throws CommunicatorException
	 */
	private static void updateGroupIdUserList(Long groupId, QMACache qmaCacheInstance) {
		try {
			logger.info("Refreshing getGroupIdToUserListMap() for groupId:"+groupId);
			List<String> userList = qmaCacheInstance.getGroupIdToUserListMap().get(groupId);
			for(String userId:userList) {
				User user = userDAO.getUserById(userId);
				updateGroupIdToUserListMap(user, qmaCacheInstance);
			}
			logger.info("Map refresh completed getGroupIdToUserListMap()");
		} catch (Exception e) {
			logger.warn("Error while updateGroupIdUserList"+e);
		}
	}
	//	Refresh a group data in All group cache(Active/Inactive)
	private static void updateGroupDetailsActiveInactive(Group group, QMACache qmaCacheInstance) {
		try {
			if(null != group && null != group.getGroupName()) {
				qmaCacheInstance.getGroupIdToCodeMapBothActiveInactive().put(group.getId().toString(), group.getGroupName());
				logger.info("Map refresh completed: getGroupIdToCodeMapBothActiveInactive()");
				String groupNameFromCache =qmaCacheInstance.getGroupIdToCodeMapBothActiveInactive().get(group.getId().toString());
				if(group.getGroupName().equalsIgnoreCase(groupNameFromCache)) {
					//Remove old group name from map if group name get changed
					qmaCacheInstance.getGroupCodeToIdMapBothActiveInactive().remove(groupNameFromCache.toUpperCase());
					logger.info("Removed from map getGroupCodeToIdMapBothActiveInactive as group name updated:"+groupNameFromCache);
				}
			}
			qmaCacheInstance.getGroupCodeToIdMapBothActiveInactive().put(group.getGroupName().toUpperCase(), group.getId());
			logger.info("Map refresh completed getGroupCodeToIdMapBothActiveInactive()");
			qmaCacheInstance.getGroupIdToEmailMapBothActiveInactive().put(group.getId().toString(), group.getGroupEmail());
			logger.info("Map refresh completed getGroupIdToEmailMapBothActiveInactive()");
		} catch (Exception e) {
			logger.warn("Error while updateGroupDetailsActiveInactive"+e);
		}
	}

	
	/**
	 * Refresh  Group Data for a group
	 * Refreshes Id, email, groupname, metadata, rules and other prefrences
	 * @param groupId
	 * @param qmaCacheInstance 
	 * @return
	 * @throws CommunicatorException
	 */
	private static Group updateGroupDetails(Long groupId, QMACache qmaCacheInstance) {
		Group group =null;
		try {
			group = groupDAO.getGroupDataById(groupId);
			if (null != group) {
				if(group != null && group.getActive() != null && group.getActive().booleanValue())
				{
					logger.info("Refreshing group maps for group:"+group.getGroupName());
					refreshGroupCodeAndGroupIdMaps(groupId, group, qmaCacheInstance);
					refreshGroupEmailMaps(group, qmaCacheInstance);
					refreshGroupForPersonal(group, qmaCacheInstance);
					refreshGroupOrgsMap(group, qmaCacheInstance);
					refreshHolidayAndShiftMap(group, qmaCacheInstance);
					refreshGroupRequestTypeMap(group, qmaCacheInstance);
					qmaCacheInstance.getAutoAssignmentEnabledGroupMap().put(group.getId(), group.getGroupName().toUpperCase());
					HazelCastLoadUtil.updateCustomClientCategory(group, qmaCacheInstance);
				}
			
			} else {
				logger.info("Group details are null for groupId:"+groupId);
			}
		} catch (Exception e) {
			logger.warn("Error while updateGroupDetails"+e);
		}
		return group;
	}

	/**
	 * @param group
	 * @param qmaCacheInstance 
	 */
	private static void refreshGroupRequestTypeMap(Group group, QMACache qmaCacheInstance) {
		logger.info("Refreshing map getGroupIdToRequestTypeMap()");
		try {
			if(null !=  group.getRequestTypes()) {
				qmaCacheInstance.getGroupIdToRequestTypeMap().put(group.getId(), group.getRequestTypes());
				logger.info("Map refresh completed: getGroupIdToRequestTypeMap()");
			}
		} catch (Exception e) {
			logger.warn("Error while refreshGroupRequestTypeMap"+e);
		}
	}

	/**
	 * @param group
	 * @param qmaCacheInstance 
	 */
	private static void refreshHolidayAndShiftMap(Group group, QMACache qmaCacheInstance) {
		logger.info("Refreshing map getGroupAgeConfigMap()");
		try {
			if(null != group.getId() && null != group.getHolidayAndShiftDetails() 
					&& group.getHolidayAndShiftDetails().isHolidayBasedAgeCalculation()) {
				qmaCacheInstance.getGroupAgeConfigMap().put(group.getId(), HazelCastLoadUtil.getGroupConfig(group));
				logger.info("Map refresh completed: getGroupAgeConfigMap(");
			}
		} catch (Exception e) {
			logger.warn("Error while refreshHolidayAndShiftMap"+e);
		}
	}

	/**
	 * @param group
	 * @param qmaCacheInstance 
	 */
	private static void refreshGroupOrgsMap(Group group, QMACache qmaCacheInstance) {
		logger.info("Refreshing map getOrgGroupMap()");
		try {
			Map<String, List<Group>> orgGroupMap = HazelCastLoadUtil.getOrgFromGroupMap(group);
			if(MapUtils.isNotEmpty(orgGroupMap)) {
				qmaCacheInstance.getOrgGroupMap().putAll(orgGroupMap);
				logger.info("Map refresh completed: getOrgGroupMap()");
			}
		} catch (Exception e) {
			logger.warn("error while refreshGroupOrgsMap"+e);
		}
	}

	/**
	 * @param groupId
	 * @param group
	 * @param qmaCacheInstance 
	 */
	private static void refreshGroupCodeAndGroupIdMaps(Long groupId, Group group, QMACache qmaCacheInstance) {
		try {
			QMACacheFactory.getCache().getAllGroupsMap().put(groupId, group);
			logger.info("Map refresh completed: getAllGroupsMap()");
			qmaCacheInstance.getGroupIdToCodeMap().put(groupId, group.getGroupName().toUpperCase());
			logger.info("Map refresh completed: getGroupIdToCodeMap()");
			qmaCacheInstance.getGroupIdToNameMap().put(groupId, group.getGroupName());
			logger.info("Map refresh completed: getGroupIdToNameMap()");
			if(null != group.getGroupName()) {
				String groupNameFromCache = qmaCacheInstance.getGroupIdToCodeMap().get(groupId);
				if(!group.getGroupName().equalsIgnoreCase(groupNameFromCache)) {
					//Remove old group name from map if group name get changed
					qmaCacheInstance.getGroupCodeToIdMap().remove(groupNameFromCache);
					logger.info("Removed from map getGroupCodeToIdMap as group name updated:"+groupNameFromCache);
				}
				qmaCacheInstance.getGroupCodeToIdMap().put(group.getGroupName().toUpperCase(),groupId);
				logger.info("Map refresh completed: getGroupCodeToIdMap()");
			}
			
			qmaCacheInstance.getGroupIdToRequestTypeMap().put(groupId, group.getRequestTypes());
			logger.info("Map refresh completed: getGroupIdToRequestTypeMap()");
			qmaCacheInstance.getGroupIdToDBCodeMap().put(group.getId().toString(), group.getGroupName());
			logger.info("Map refresh completed: getGroupIdToDBCodeMap()");
		} catch (Exception e) {
			logger.warn("Error refreshGroupCodeAndGroupIdMaps"+e);
		}
	}

	/**
	 * @param group
	 * @param qmaCacheInstance 
	 */
	private static void refreshGroupForPersonal(Group group, QMACache qmaCacheInstance) {
		try {
			if(!Objects.isNull(group.getGroupType()) && group.getGroupType().equalsIgnoreCase("personal")) {
				if(!qmaCacheInstance.getPersonalGroupIdList().contains(group.getId())) {
				qmaCacheInstance.getPersonalGroupIdList().add(group.getId());
				logger.info("Refreshed list getPersonalGroupIdList()");
				}
				qmaCacheInstance.getPersonalMailboxIdToGroupIdMap().put(group.getPersonalMailboxId(), group.getId());
				logger.info("Map refresh completed: getPersonalMailboxIdToGroupIdMap()");
			}
		} catch (Exception e) {
			logger.warn("Error while refreshGroupForPersonal"+e);
		}
	}

	/**
	 * @param group
	 * @param qmaCacheInstance 
	 */
	private static void refreshGroupEmailMaps(Group group, QMACache qmaCacheInstance) {
		try {
			if (null != group.getGroupEmail()){
				qmaCacheInstance.getGroupIdToEmailMap().put(group.getId(), group.getGroupEmail());
				logger.info("Map refresh completed: getGroupIdToEmailMap()");
				String groupEmailFromCache = qmaCacheInstance.getGroupIdToEmailMap().get(group.getId());
				if(!group.getGroupEmail().equalsIgnoreCase(groupEmailFromCache)) {
					//Remove old group email from map if group email get changed
					qmaCacheInstance.getEmailWithDomaintoGroupMap().remove(groupEmailFromCache.toUpperCase());
					logger.info("Removed old key from map getEmailWithDomaintoGroupMap as group email updated:"+groupEmailFromCache);
				}
				qmaCacheInstance.getEmailWithDomaintoGroupMap().put(group.getGroupEmail().toUpperCase(), group);
				logger.info("Map refresh completed: getEmailWithDomaintoGroupMap()");
			}
			if (null != group.getGroupEmail() && group.getGroupEmail().indexOf('@') > -1) {
				qmaCacheInstance.getGroupIdToEmailMap().put(group.getId(), group.getGroupEmail());
				logger.info("Map refresh completed: getGroupIdToEmailMap()");
				String groupEmailFromCache = qmaCacheInstance.getGroupIdToEmailMap().get(group.getId());
				if(!group.getGroupEmail().equalsIgnoreCase(groupEmailFromCache)) {
					//Remove old group email from map if group email get changed
					String groupEmailWithoutDomain = groupEmailFromCache.substring(0, group.getGroupEmail().indexOf('@')).toUpperCase();
					qmaCacheInstance.getGroupEmailToCodeMap().remove(groupEmailWithoutDomain);
					logger.info("Removed old key from map getGroupEmailToCodeMap as group email updated:"+groupEmailFromCache);
				}
				String groupEmail = group.getGroupEmail().substring(0, group.getGroupEmail().indexOf('@')).toUpperCase();
				qmaCacheInstance.getGroupEmailToCodeMap().put(groupEmail, group.getGroupName().toUpperCase());
				logger.info("Map refresh completed: getGroupEmailToCodeMap()");
			}
		} catch (Exception e) {
			logger.warn("Error while refreshGroupEmailMaps"+e);
		}
	}

	/**
	 * @param soeId
	 */
	public static void loadUserSymphonyIdToSoeIdMap(String soeId) {
		try {
			User user = userDAO.getUserById(soeId);
			if (null != user && null != user.getSymphonyId() && null != user.getId()) {
				SymphonyUserMapTO symphonyUserMapTO = new SymphonyUserMapTO();
				symphonyUserMapTO.setSoeId(user.getId());
				symphonyUserMapTO.setSymphonyEmailId(user.getSymphonyEmailId());
				symphonyUserMapTO.setSymphonyId(user.getSymphonyId());
				QMACacheFactory.getCache().getUserSymphonyIdToUserMap().put(user.getSymphonyId(), symphonyUserMapTO);
			}

		} catch (Exception ex) {
			logger.warn("Issue refresh getUserSymphonyIdToUserMap" + ex);
		}
	}

	public static void refreshMailBoxDLMappings(String soeId) {
		try {
			MailBoxDLMapping mailBoxDLMapping = readerUtil.getMappingById(soeId);
			if (null != mailBoxDLMapping && null != QMACacheFactory.getCache().getMailBoxDLMappingMap()) {
				QMACacheFactory.getCache().getMailBoxDLMappingMap().put(soeId.toUpperCase(), mailBoxDLMapping);
			}
		} catch (Exception ex) {
			logger.warn("Error while refreshMailBoxDLMappings:" + ex);
		}
	}

	public static void removeMailBoxDLMappings(String soeId) {
		try {
			QMACache qmaCache = QMACacheFactory.getCache();
			if (null != qmaCache.getMailBoxDLMappingMap() && null != qmaCache.getMailBoxDLMappingMap().get(soeId.toUpperCase())) {
				QMACacheFactory.getCache().getMailBoxDLMappingMap().remove(soeId.toUpperCase());
			}
		} catch (Exception ex) {
			logger.warn("Error while removeMailBoxDLMappings:" + ex);
		}
		
	}
	
}
