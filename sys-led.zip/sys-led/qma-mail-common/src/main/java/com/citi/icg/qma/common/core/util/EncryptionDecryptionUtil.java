package com.citi.icg.qma.common.core.util;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EncryptionDecryptionUtil
{

	private static final Logger logger = LoggerFactory.getLogger(EncryptionDecryptionUtil.class);
	private static EncryptionDecryptionUtil instance = null;
	
	private static final String AES_GCM_NO_PADDING = "AES/GCM/NoPadding";
	private static final int TAG_LENGTH_BIT = 128;
	private static final int IV_LENGTH_BYTE = 12;
    private static final int AES_KEY_SIZE = 256;
	
	public static synchronized EncryptionDecryptionUtil getInstance() {
		
				if (instance == null) {
					instance = new EncryptionDecryptionUtil();
				}
			
		return instance;
	}
	
	public static void main(String[] args) {
		
		EncryptionDecryptionUtil edUtil = new EncryptionDecryptionUtil();
		
		String[] output = edUtil.encryptInputString("Test");
		
		logger.info("encryptedStr : {}, IV : {} ", output[0], output[1]);
		
        String pText = "AES-GCM 256 Bit encryption!";
        logger.info("inputString : {} ",pText);
		
        String[] output3 = edUtil.encryptUsingAesGcm256(pText.getBytes(StandardCharsets.UTF_8));
        logger.info("encryptUsingAesGcm256 : {} ", output3[0]);
        
        String[] output4 = edUtil.decryptUsingAesGcm256(output3[0], output3[1]);
        logger.info("decryptUsingAesGcm256 : {}, IV : {} ", output4[0], output4[1]);
	}

	public String[] encryptInputString(String stringToBeEncrypted ) {
		
		String[] result = {"",""};
		
		try {
			SecureRandom random = new SecureRandom();

			byte[] applicationByteKey = Base64.decodeBase64(ApplicationConstants.APPLICATION_ENCRYPTION_KEY);
			Base64.encodeBase64String(applicationByteKey);

			byte[] iv = new byte[16];
			random.nextBytes(iv);

			String encryptedStr = encrypt(stringToBeEncrypted, applicationByteKey, iv);
			String base64ConvertedIV = Base64.encodeBase64String(iv); 
			result[0] = encryptedStr;
			result[1] = base64ConvertedIV;
		} catch (Exception e) {
			logger.error("Exception in encryptInputString:",e);
		}
		return result;
	}

	public String encrypt(String plainText, byte[] encKey, byte[] iv) {
		byte[] result = null;
		try {
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			SecretKeySpec key = new SecretKeySpec(encKey, "AES");
			cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));
			result = cipher.doFinal(plainText.getBytes());
		} catch (Exception e) {
			logger.error("Issue in EncryptUtil ",e);
		}
		return Base64.encodeBase64String(result);
	}

	public byte[] generateEncryptionKey() {
		byte[] encryptKey = new byte[16];
		SecureRandom random = new SecureRandom();
		random.nextBytes(encryptKey);
		return encryptKey;
	}
	
	public String getDecryptedPassword(String passwordEncStr,String passwordIVEncStr) {
		String decrPassword = "";
		try {
			decrPassword = DecryptionUtil.decrypt(passwordEncStr,
					passwordIVEncStr, ApplicationConstants.APPLICATION_ENCRYPTION_KEY);
			logger.info("Decryption successful");
		} catch (Exception e) {
			logger.error(
					"Invalid Password property for Decryption : " , e);
		}
		return decrPassword;
	}
	
	public String[] encryptUsingAesGcm256(byte[] plainText) {
		
		String[] result = {"", ""};
		logger.info("Start Method encryptUsingAesGcm256");
		try {
			 byte[] iv = CryptoUtils.getRandomNonce(IV_LENGTH_BYTE);
			 SecretKey aesSecretKey = CryptoUtils.getAESKeyFromPassword(AES_KEY_SIZE);
			 
			Cipher cipher = Cipher.getInstance(AES_GCM_NO_PADDING);
			cipher.init(Cipher.ENCRYPT_MODE, aesSecretKey, new GCMParameterSpec(TAG_LENGTH_BIT, iv));
			byte[] cipherText = cipher.doFinal(plainText);
			byte[] cipherTextWithIv = ByteBuffer.allocate(iv.length + cipherText.length)
	                .put(iv)
	                .put(cipherText)
	                .array();
			result[0] = Base64.encodeBase64String(cipherTextWithIv);
			result[1] = Base64.encodeBase64String(aesSecretKey.getEncoded());
		} catch (Exception e) {
			logger.error("Exception in encryptUsingAesGcm256 : ",e);
		}
		logger.info("End Method encryptUsingAesGcm256");
        return result;
	}
	
	public String[] decryptUsingAesGcm256(String cText, String aesSecretKeyStr) {
		String[] result = {"",""};
		logger.info("Start Method decryptUsingAesGcm256");
		try {
	        byte[] decode = Base64.decodeBase64(cText);
	        ByteBuffer bb = ByteBuffer.wrap(decode);
	        
	        byte[] iv = new byte[IV_LENGTH_BYTE];
	        bb.get(iv);
	        
	        byte[] cipherText = new byte[bb.remaining()];
	        bb.get(cipherText);
	        
	        byte[] aesSecretKey = Base64.decodeBase64(aesSecretKeyStr);
	        SecretKey originalKey = new SecretKeySpec(aesSecretKey, 0, aesSecretKey.length, "AES"); 
	        
	        Cipher cipher = Cipher.getInstance(AES_GCM_NO_PADDING);
	        cipher.init(Cipher.DECRYPT_MODE, originalKey, new GCMParameterSpec(TAG_LENGTH_BIT, iv));
	        
	        byte[] plainText = cipher.doFinal(cipherText);
	        
	        result[0] = new String(plainText, StandardCharsets.UTF_8);
	        result[1] = Base64.encodeBase64String(iv);
		} catch(Exception e) {
			logger.error("Exception in decryptUsingAesGcm256 : ",e);
		}
		logger.info("End Method decryptUsingAesGcm256");
        return result;
    }
}