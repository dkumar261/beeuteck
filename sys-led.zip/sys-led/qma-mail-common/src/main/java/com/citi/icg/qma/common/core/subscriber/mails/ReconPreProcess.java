package com.citi.icg.qma.common.core.subscriber.mails;

import java.util.List;

import com.citi.icg.qma.common.server.dao.BaseEntity;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;

import dev.morphia.annotations.CappedAt;
import dev.morphia.annotations.Entity;

@Entity(value = "ReconPreProcess", noClassnameStored = true, cap = @CappedAt(count = 5000, value = 500000))
public class ReconPreProcess extends BaseEntity {
	
	private String messageId;
	private List<ConversationRecipient> conversationRecipients;
	
	public ReconPreProcess(String messageId, List<ConversationRecipient> conversationRecipients) {
		super();
		this.messageId = messageId;
		this.conversationRecipients = conversationRecipients;
	}
	
	public ReconPreProcess() {
	}

	public String getMessageId() {
		return messageId;
	}
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	public List<ConversationRecipient> getConversationRecipients() {
		return conversationRecipients;
	}
	public void setConversationRecipients(List<ConversationRecipient> conversationRecipients) {
		this.conversationRecipients = conversationRecipients;
	}

}
