package com.citi.icg.qma.common.server.util;

public enum CustomClientCategoryEnum
{
	CONTAINS("Contains"),
	STARTSWITH("Starts With"),
	ENDSWITH("Ends With"),
	EQUALS("Equals"); 

	
	private String routingOperator;

    private CustomClientCategoryEnum(String routingOperator) {
        this.routingOperator = routingOperator;
    }

    public String getName() {
        return routingOperator;
    }
    
    public static CustomClientCategoryEnum fromString(String routingOperator) {
        for (CustomClientCategoryEnum b : CustomClientCategoryEnum.values()) {
          if (b.routingOperator.equalsIgnoreCase(routingOperator)) {
            return b;
          }
        }
        return null;
      }
    @Override
    public String toString() {
        return routingOperator;
    }

}
