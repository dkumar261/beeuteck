/**
 * 
 */
package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

import dev.morphia.annotations.Entity;

/**
 *  This class will hold the data for holiday master
 */
@Entity(value = "HolidayMaster", noClassnameStored = true)
public class HolidayMaster extends BaseEntity implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8598913683076089817L;
	private String type;
	private Date holidayDate;
	private String holidayDesc;
	private String countryCode;
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the holidayDate
	 */
	public Date getHolidayDate() {
		return holidayDate;
	}
	/**
	 * @param holidayDate the holidayDate to set
	 */
	public void setHolidayDate(Date holidayDate) {
		this.holidayDate = holidayDate;
	}
	/**
	 * @return the holidayDesc
	 */
	public String getHolidayDesc() {
		return holidayDesc;
	}
	/**
	 * @param holidayDesc the holidayDesc to set
	 */
	public void setHolidayDesc(String holidayDesc) {
		this.holidayDesc = holidayDesc;
	}
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
}
