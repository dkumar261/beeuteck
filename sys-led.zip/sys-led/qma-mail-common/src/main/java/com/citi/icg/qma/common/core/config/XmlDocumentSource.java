package com.citi.icg.qma.common.core.config;

import org.w3c.dom.Document;

public interface XmlDocumentSource
{
	Document getDocument();
}
