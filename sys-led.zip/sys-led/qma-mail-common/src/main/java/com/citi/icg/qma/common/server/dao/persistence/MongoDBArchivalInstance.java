package com.citi.icg.qma.common.server.dao.persistence;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.Map;

import javax.naming.CommunicationException;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.MailCommonUtil;
import com.citi.icg.qma.common.server.dao.BaseEntity;
import com.citi.icg.qma.common.server.dao.CyberArkConnectionActivityLog;
import com.citi.icg.qma.common.server.dao.CyberArkConnectionActivityLog.ConnectionType;
import com.citi.icg.qma.config.MongoDBConfig;
import com.citi.icg.qma.config.QmaMailConfigLoader;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.MongoClientURI;
import com.mongodb.ReadPreference;

import dev.morphia.Datastore;
import dev.morphia.Key;
import dev.morphia.Morphia;


/**
 * 
 * 
 *
 */
public class MongoDBArchivalInstance {
	
	private static final Logger logger = LoggerFactory.getLogger(MongoDBArchivalInstance.class);
	
	private static String dbName = null;
	private static String backupDBName = null;
	private static MongoDBArchivalInstance instance = null;
	private static Datastore datastore;
	private static Datastore secondaryDatastore;
	private static MongoClient mongoClient;
	private static MongoClient secondaryMongoClient;
	
	private MongoDBArchivalInstance() throws CommunicationException{
		
		MongoDBConfig mongoDBConfig = QmaMailConfigLoader.getConfig().getMongoDBConfig();
		MongoDBArchivalInstance.setDbName(mongoDBConfig.getArchivalDbName());
		backupDBName=mongoDBConfig.getArchivalBackupdbName();
		String clusterServers = mongoDBConfig.getMongoArchivalCluster();
		
		Builder builder = MailCommonUtil.configureMongoConnection(mongoDBConfig);
		

		/* Below map contains both credentials CyberArk Fetched as well as current static fetched from YAML file */
		Map<String, String> userNamePasswordMap=null;
		try {
			userNamePasswordMap = SecretServiceDAO.getInstance().getUserNamePasswordMap(mongoDBConfig,SecretServiceDAO.ARCHIVAL_DB_KEY, false); 
		} catch (Exception e) {
			logger.error(SecretServiceDAO.CA_ERROR_LOG_PREFIX_KEY+ "for component : " + mongoDBConfig.getServiceName(), e);
			SecretServiceDAO.getInstance().sendEmailToSupport(e.getMessage(),mongoDBConfig);
			System.exit(101);
		} 

		if(null != userNamePasswordMap && !userNamePasswordMap.isEmpty()) {
			
			String userName = userNamePasswordMap.get(SecretServiceDAO.CA_USER_NAME_KEY);
			String password = userNamePasswordMap.get(SecretServiceDAO.CA_PASSWORD_KEY);
			
			boolean isValidCyberArkConnectivity = false;
			/* 1. Check if CyberArk credentials are empty or not */
			if(StringUtils.isNotEmpty(userName) && StringUtils.isNotEmpty(password) && mongoDBConfig.isCyberArkEnabled()) {
				/* 2. if CyberArk credentials are not empty, connect using CyberArk credentials */
				connectToMongoDB(builder, clusterServers, userName, password, mongoDBConfig.getConnectionScheme());
				/* 3. Check if the connection is successful using CyberArk credentials */
				if( ! isValidCyberArkDBAuthetication(mongoDBConfig, ConnectionType.CYBERARK)) {
					/* 4. If connection is unsuccessful using CyberArk credentials  */
					logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"FAILED TO CONNECT TO DATABASE USING CYBERARK CREDENTIALS");
				} else {
					/* 4. Connection is successful using CyberArk credentials */
					logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"CONNECTED TO DATABASE USING CYBERARK CREDENTIALS");
					isValidCyberArkConnectivity = true;
				}
			} else {
				/* 2. CyberArk credentials are either empty or null or CyberArk connection usage is disabled */
				logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"CYBERARK DISABLE FOR CURRENT ENVIRONMENT OR CYBERARK CREDENTIALS ARE INVALID");
			}
			
			if(!isValidCyberArkConnectivity) {
				connectUsingNonCyberArkCredentials(builder, clusterServers, userNamePasswordMap,mongoDBConfig);
			}
			
		} else {
			String message = "UserName and password extracted empty or null. Please check urgently.";
			logger.error(message);
			SecretServiceDAO.getInstance().sendEmailToSupport(message,mongoDBConfig);
			System.exit(101);
		}
	}
	
	/**
	 * This method connects to database using static credentials
	 * @param builder
	 * @param clusterServers
	 * @param userNamePasswordMap
	 * @throws Exception
	 */
	private void connectUsingNonCyberArkCredentials(Builder builder, String clusterServers,
			Map<String, String> userNamePasswordMap,MongoDBConfig mongoDBConfig) {
		/* 1. Set the current static credentials read from YAML files to connect and try connecting again */
		String userName = userNamePasswordMap.get(SecretServiceDAO.USER_NAME_KEY);
		String password = userNamePasswordMap.get(SecretServiceDAO.PASSWORD_KEY);
		if(StringUtils.isNotEmpty(userName) && StringUtils.isNotEmpty(password)) {
			/* 2. Connect to DB using static credentials */
			connectToMongoDB(builder, clusterServers, userName, password, mongoDBConfig.getConnectionScheme());
			/* 3. Check if connection is successful using static credentials read from YAML file */
			if(validateNonCyberArkDBAuthetication(mongoDBConfig,ConnectionType.NON_CYBERARK)) {
				/* 4. Connection is successful using credentials read from YAML file */
				logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"CONNECTED TO DATABASE USING NON CYBERARK CREDENTIALS");
			} else {
				/* 4. Failed to connect even with static credentials. Need to send an email to Support with failure details */
				String errorMessage = SecretServiceDAO.CA_LOG_PREFIX_KEY+"FAILED TO CONNECT TO DATABASE USING NON CYBERARK CREDENTIALS, PLEASE VALIDATE CONNECTION PARAMETERS";
				logger.error(errorMessage);
				SecretServiceDAO.getInstance().sendEmailToSupport(errorMessage,mongoDBConfig);
			}
		} else {
			/* 2. Static credentials are not found, send an email to support with module name and details. */
			String errorMessage = SecretServiceDAO.CA_LOG_PREFIX_KEY+"NON CYBERARK CREDENTIALS ARE EITHER 'null' or 'empty'";
			logger.error(errorMessage);
			SecretServiceDAO.getInstance().sendEmailToSupport(errorMessage,mongoDBConfig);
		}
	}
	

	/**
	 * This method validates if the connection to DB is successful or not.
	 * NOTE : As connection to MongoDB is handled internally by demon thread, hence we can not get the real time exception of connection failure while establishing the connection.
	 * 		  We can only get to know about failure in connection when we try to fetch something or perform any CRUD operation on database. Hence below code for adding one document
	 *        in DBConnectionAudit for logging. 
	 * 
	 * @return boolean
	 */
	private boolean isValidCyberArkDBAuthetication(MongoDBConfig config, ConnectionType type) {
		boolean isValidDBAuthentication = false;
		Datastore store = getDataStore();
		if( null != store ) {
			CyberArkConnectionActivityLog audit = new CyberArkConnectionActivityLog(config.getServiceName(), type, getCurrentHost(), new Date());
			Key<CyberArkConnectionActivityLog> returnObj = store.save(audit);
			if(null!= returnObj && null != returnObj.getId()) {
				logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"DATABASE AUTHENTICATION SUCCESSFUL USING : {} ", type);
				logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"NEW DB AUDIT CREATED WITH ID : '{}' IN COLLECTION : '{}'", returnObj.getId(), returnObj.getCollection());
				isValidDBAuthentication = true;
			}
		}
		return isValidDBAuthentication;
	}
	
	
	/**
	 * This method validate if database connection using non cyberark credentials is used
	 * @param config
	 * @param type
	 * @return boolean
	 */
	private boolean validateNonCyberArkDBAuthetication(MongoDBConfig config, ConnectionType type) {
		boolean isValidDBAuthentication = false;
		Datastore store = getDataStore();
		if( null != store ) {
			CyberArkConnectionActivityLog audit = new CyberArkConnectionActivityLog(config.getServiceName(), type, getCurrentHost(), new Date());
			Key<CyberArkConnectionActivityLog> returnObj = store.save(audit);
			if(null!= returnObj && null != returnObj.getId()) {
				logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"DATABASE AUTHENTICATION SUCCESSFUL USING : {}", type);
				logger.info(SecretServiceDAO.CA_LOG_PREFIX_KEY+"NEW DB AUDIT CREATED WITH ID : '{}' IN COLLECTION : '{}'", returnObj.getId(), returnObj.getCollection());
				isValidDBAuthentication = true;
			}
		}
		return isValidDBAuthentication;
	}
	
	/**
	 * This method provides current host details
	 * @return
	 */
	private String getCurrentHost() {
		String host = "";
		try {
			InetAddress hostNameAdd = InetAddress.getLocalHost();
			host = null != hostNameAdd ? hostNameAdd.toString() : "";
		} catch (UnknownHostException e) {
			logger.error("Exception while retrieveing current host :", e);
		}
		return host;
	}


	/**
	 * This method takes care of establishing a connection to Mongo Database
	 * @param builder
	 * @param clusterServers
	 * @param userName
	 * @param password
	 */
	private void connectToMongoDB(Builder builder, String clusterServers, String userName, String password, String connectionScheme){
		
		logger.info("Connecting to " + dbName + " db, at " + clusterServers);
		MongoClientURI mcURI = new MongoClientURI(connectionScheme + "://" + userName + ":" + password + "@" + clusterServers, builder);
		logger.info("Cacerts Path before connecting to mongo: "+System.getProperty("javax.net.ssl.trustStore"));
		mongoClient = new MongoClient(mcURI);
		//mongoClient.setWriteConcern(WriteConcern.SAFE);
//			mongoClient.setWriteConcern(WriteConcern.NORMAL);
		Morphia morphia = new Morphia().mapPackage(BaseEntity.class.getPackage().getName());
		datastore = morphia.createDatastore(mongoClient, dbName);
		BaseEntity.setMongoDatastore(datastore);

		secondaryMongoClient = new MongoClient(mcURI);
		//secondaryMongoClient.setWriteConcern(WriteConcern.SAFE);
//			mongoClient.setWriteConcern(WriteConcern.NORMAL);
		Morphia secondaryMorphia = new Morphia().mapPackage(BaseEntity.class.getPackage().getName());
		secondaryDatastore = secondaryMorphia.createDatastore(secondaryMongoClient, dbName);
		//BaseEntity.setSecondaryMongoDatastore(secondaryDatastore);// TODO? CHECK IF REQUIRED, IN CASE OF MORPHIA

		logger.info("Connection to database '" + dbName + "' initialized");
			
	}

	/**
	 * This method defines the connection pool configuration for archival database
	 * @param builder
	 */
	private void setConnectionPoolConfig( Builder builder) {
		try {
			String dbpoolSize=System.getProperty("dbPoolSize");
			logger.debug("Current database connection pool size configured is  = " + dbpoolSize );
			if(StringUtils.isNotBlank(dbpoolSize)) {
				//builder.threadsAllowedToBlockForConnectionMultiplier(Integer.parseInt(dbpoolSize));
			}
		} catch( Exception e ) {
			logger.error("Exception while setting connection pool size for database : ", e);
		}
		
	}

	/**
	 * This method returns the singleton instance of database for provided database configuration
	 * @param databaseName
	 * @param backupDatabaseName
	 * @param loginFid
	 * @param loginSecret
	 * @param mongoCluster
	 * @return MongoDBInstance
	 */
	public static synchronized MongoDBArchivalInstance getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		if (instance == null) {
					try {
						instance = new MongoDBArchivalInstance();
					} catch (CommunicationException e) {
						logger.error("Error while initiating Archival DB :",e);
					}
				}
		return instance;
	}
	
	/**
	 * This method returns datastore for Morphia operations
	 * @return Datastore
	 */
	public Datastore getDataStore() {
		return datastore;
	}

	/**
	 * This method gets the DB for Mongo-JavaDriver operations.
	 * @return DB
	 */
	public DB getDB() {
		return mongoClient.getDB(dbName);
	}
	
	/**
	 * This method gets the secondary DB for Mongo-JavaDriver operations
	 * @return DB
	 */
	public DB getSecondaryDB() {
		
		DB db = secondaryMongoClient.getDB(dbName);
		db.setReadPreference(ReadPreference.secondaryPreferred());
		return db;
	}
	
	/**
	 * This method gets backup DB
	 * @return DB
	 */
	public DB getbackupDB() {
		DB db = mongoClient.getDB(backupDBName);
		return db;
	}
	
	
	/**
	 * This method closes Mongo client connections
	 */
	public static void closeDB() {
		try {
			if (mongoClient != null) {
				logger.info("Start Closing MongoClient Connections");
				mongoClient.close();
				instance = null;
				datastore = null;
				logger.info("End Closing MongoClient Connections");
			}
		} catch (Exception e) {
			logger.error("Exception in closing MongoClient Connection :", e );
		}
	}

	
	/**
	 * @return the dbName
	 */
	public static String getDbName() {
		return dbName;
	}

	/**
	 * @param dbName the dbName to set
	 */
	public static void setDbName(String dbName) {
		MongoDBArchivalInstance.dbName = dbName;
	}
}
