package com.citi.icg.qma.common.server.dao.persistence;

import static java.time.temporal.TemporalAdjusters.lastDayOfYear;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.Set;
import java.util.TimeZone;

//import javax.servlet.http.HttpServletRequest;

import com.citi.icg.qma.common.server.util.*;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.ApplicationConstants;
import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.core.util.DecryptionUtil;
import com.citi.icg.qma.common.core.util.QmaMailConstants;
import com.citi.icg.qma.common.server.dao.ClientAuthorization;
import com.citi.icg.qma.common.server.dao.ColumnDef;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.GFCDetails;
import com.citi.icg.qma.common.server.dao.GFCDetailsMapping;
import com.citi.icg.qma.common.server.dao.GFCId;
import com.citi.icg.qma.common.server.dao.GFPIDMapping;
import com.citi.icg.qma.common.server.dao.HolidayMaster;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.KeyValue;
import com.citi.icg.qma.common.server.dao.MISReportExclusionRecord;
import com.citi.icg.qma.common.server.dao.SequenceId;
import com.citi.icg.qma.common.server.dao.StaticData;
import com.citi.icg.qma.common.server.dao.TaskizeParticipantsContactMapping;
import com.citi.icg.qma.common.server.dao.UIConsoleLog;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.UserFeedback;
import com.citi.icg.qma.common.server.dao.Workflow;
import com.citi.icg.qma.common.transferobject.AssignedOwnersByAgeBandTO;
import com.citi.icg.qma.common.transferobject.ColumnDefUI;///[C153176-160] changes for saved search with work flow Criteria query
import com.citi.icg.qma.common.transferobject.GFCIDTO;
import com.citi.icg.qma.common.transferobject.OpenInquiryByGroup;
import com.citi.icg.qma.common.transferobject.RequestTypeByGroup;
import com.citi.icg.qma.exception.ApiAuthenticationException;
import com.citi.icg.qma.exception.ApiAuthorizationException;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.AggregationOptions;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.BulkWriteResult;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoException;
import com.mongodb.ReadPreference;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.model.GridFSUploadOptions;
import org.bson.Document;
import org.bson.types.ObjectId;

import dev.morphia.Datastore;
import dev.morphia.query.FindOptions;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

public class GenericDAO extends MongoMorphiaDAO implements IGraph {
	private static final String CORRECTION_DATA_ITEM_KEY = "correctionDataItem";
	private static final String RESOLVED = "Resolved";
	private static final DB database = MongoDB.instance().getDB();
	private static Datastore dataStore = MongoDB.instance().getDataStore();
	private static final MongoDatabase mongoDatabase = MongoDB.instance().getDatabase();
	private static final DB backupDatabase = MongoDB.instance().getbackupDB();
	private static final Logger subLogger = LoggerFactory.getLogger(GenericDAO.class);
	private static UserDAO userDao = new UserDAO();
	private static GroupDAO groupDao = new GroupDAO();
	private static final String REQUESTTYPE = "requestType";
	private static final String RELEASE_NOTE_PATH = "/QMA/releaseNotesDocuments/";
	private static final String RELEASE_NOTE_PATH_ECS = "/QMANAM1/releaseNotesDocuments/";
	private static final String CONTENT_TYPE = "contentType";
	private static final String MD5 = "md5";
	private static final String APPLICATION_PDF = "application/pdf";
	private static final String ALIASES = "aliases";
	private static final String RELEASE_DOCUMENTS = "releaseDocuments";
	private static final String ID = "_id";
	private static final String UNASSIGNED = "Unassigned";
	
	// query to get data from Inquiry_Aggregate_Chart_Data collection which is
	// created from Inquiry Collection by MongoInquiryChartDataCreationJob.
	private static String openInquiryByGroupStr = "[{$match: {'_id.assignedGroupId' : { $in:[55051]}, 'reloadCounter': [reloadCounter] }},{$group: {_id : {assignedGroupId : '$_id.assignedGroupId', 'rulesFlag' : '$_id.rulesFlag'}, 'count' : {$sum : '$COUNT'}}}]";
	private static String requestTypeByGroupStr = "[{$match: {'_id.assignedGroupId' : { $in:[55051]}, 'reloadCounter': [reloadCounter] }},{$group: {_id: {assignedGroupId : '$_id.assignedGroupId', requestType : '$_id.requestType', 'rulesFlag' : '$_id.rulesFlag'}, 'count' : {$sum : '$COUNT'}}}]";
	private static String assignedOwnersByAgeBandStr = "[{$match: {'_id.assignedGroupId' : { $in:[55051]}, 'reloadCounter': [reloadCounter]}}, {$group: {_id: {DAY:'$_id.DAY',MONTH:'$_id.MONTH',YEAR:'$_id.YEAR',assignedUserId : '$_id.assignedUserId', 'rulesFlag' : '$_id.rulesFlag'}, 'count' : {$sum : '$COUNT'}}}]";
	private static String assignedOwnersByAgeBandStrPerGroup = "[{$match: {'_id.assignedGroupId' : { $in:[55051]}, 'reloadCounter': [reloadCounter]}}, {$group: {_id: {DAY:'$_id.DAY',MONTH:'$_id.MONTH',YEAR:'$_id.YEAR',assignedUserId : '$_id.assignedUserId', 'rulesFlag' : '$_id.rulesFlag', assignedGroupId : '$_id.assignedGroupId'}, 'count' : {$sum : '$COUNT'}}}]";
	private static final int DATA_LIMIT = 5000;
	private static final String GFC_NAME = "GFCName";
	private static final String AUTOFWDDLS_MAPPING = "autoFwdDLsMapping";
	private static final String APP_API_SUBSCRIPTION_MAPPING = "applicationAPISubscription";
	private static final String REGISTERED_API_MAP = "registeredAPIMap";
	private static final String COUNTRY_CODE = "countryCode";
	private Long lastholidayMasterId = 0L;
	private Integer pageCount = 1;
	private LinkedHashSet<String> holidaySet = new LinkedHashSet<>();
	private BasicDBList allHolidayMasterList = new BasicDBList();

	private static final String GROUP_NAME = "groupName";
	private static final String GROUP_ID = "groupId";
	private static final String INQUIRY_ID = "inquiryId";
	private static final String CONV_ID = "convId";
	private static final String EXCLUSION_REPORT_NAME = "misExclusionReportName";
	private static final String EXCLUSION_REASON = "misExclusionReason";
	private static final String EXCLUSION_TIMELINE = "misExclusionTimelineInMonths";
	private static final String START_DATE = "misExclusionStartDate";
	private static final String END_DATE = "misExclusionEndDate";
	private static final String ACTIVE = "active";
	private static final String COMMENTS = "comments";
	private static final String EXCLUSION_DETAILS_ALREADY_PRESENT = "Exclusion Report Details already present";
	private static final String EXCLUSION_DETAILS_ADDED = "New Exclusion Report Details added";
	private static final String EXCLUSION_DETAILS_CANNOT_BE_EDITED = "Exclusion Report Details cannot be edited";

	private static final String GFCDETAILS_MAPPING_BACK_UP = "GFCDetailsMapping_Backup";
	private static final String GFCDETAILS_MAPPING = "GFCDetailsMapping";  
	
	private static final UserActivitiesDAO user_Activities_Dao = new UserActivitiesDAO();
	private static final String ASSIGNED_GROUPS = "assignedGroups";
	private BasicDBObject dashBoardSettings = new BasicDBObject();
	
	private BasicDBList allGFCMappingDetailsList = new BasicDBList();
	private static final Boolean IS_GROUP_ACTIVE = true;
	public List<ColumnDef> getMasterColumnDef() {
		StaticData staticData = mongoDatastore.find(StaticData.class).asList().get(0);

		return staticData.getMasterColumnDef();

	}

	public List<ColumnDefUI> getWorkFlowColumnDefUi() {
		StaticData staticData = mongoDatastore.find(StaticData.class).asList().get(0);

		return staticData.getViewWorkFlowColumn();
	}

	public Long getNextSequenceId(String collName) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a
																				// generic one
	{
		try {
			Long id;
			final Query<SequenceId> q = mongoDatastore.find(SequenceId.class, QmaMailConstants.MONGO_PK, collName);
			final UpdateOperations<SequenceId> uOps = mongoDatastore.createUpdateOperations(SequenceId.class).inc("value");
			SequenceId newId = mongoDatastore.findAndModify(q, uOps);

			if (newId == null) {
				newId = new SequenceId(collName);
				mongoDatastore.save(newId);
			}

			id = newId.getValue();
			return id;
		} catch (Exception e) {
			subLogger.error("Exception in GenericDAO.getNextSequenceId for collName=" + collName, e);
			throw new CommunicatorException("Exception in GenericDAO.getNextSequenceId for collName=" + collName, e);
		}
	}

	/*
	 * Decrement reloadCounter by one until data is found on
	 * Inquiry_Aggregate_Chart_Data (list is not null). scheduler job Updates -
	 * reload-counter in 'staticData' and 'Inquiry_Aggregate_Chart_Data' tables,
	 * both are separate transactions. Exceptional scenario : if update operation on
	 * Inquiry_Aggregate_Chart_Data fails then matching reloader counter won't be
	 * found in table. So decrement reloadCounter and try until data is found on
	 * Aggregate table.
	 * 
	 * @see com.citi.icg.qma.common.server.dao.persistence.IGraph1#
	 * getOpenInquiryByGroupsOnFly(java.lang.String)
	 */
	@Override
	public List<OpenInquiryByGroup> getOpenInquiryByGroupsOnFly(String soeId, boolean isQMA2Origin) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using
																																// a generic one
	{

		Long reloadCounter = getReloadCounterFromStaticData();
		List<OpenInquiryByGroup> valuesList = null;
		User user = userDao.getUserById(soeId);
		Set<Long> userGroupsList = userDao.getUserGroupsList(user,IS_GROUP_ACTIVE);
		if (userGroupsList == null || userGroupsList.isEmpty()) {
			subLogger.info("getOpenInquiryByGroupsOnFly for soeId = {}  , No valid groups found.", soeId);
			return valuesList;
		}

		int readChartDataTryCount = 2;
		while (reloadCounter != null) {
			valuesList = getOpenInquiryByGroupsOnFly(soeId, reloadCounter, userGroupsList, isQMA2Origin);

			if (valuesList != null && !valuesList.isEmpty()) {
				break;
			}

			if (readChartDataTryCount-- < 0) {
				subLogger.info("getOpenInquiryByGroupsOnFly for soeId = {} readChartDataTryCount exceeded, and is: {}", soeId, readChartDataTryCount);
				break;
			}

			reloadCounter--;

		}

		return valuesList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.citi.icg.qma.common.server.dao.persistence.IGraph1#
	 * getOpenInquiryByGroupsOnFly(java.lang.String)
	 */
	public List<OpenInquiryByGroup> getOpenInquiryByGroupsOnFly(String soeId, Long reloadCounter, Set<Long> userGroupsList, boolean isQMA2Origin) throws CommunicatorException// Sonar Fix -- Define and
																																												// throw a dedicated
																																												// exception instead of
																																												// using a generic one
	{
		ArrayList<OpenInquiryByGroup> valuesList = null;
		if (userGroupsList == null || userGroupsList.isEmpty()) {
			subLogger.info("getRequestTypesByGroupsOnFly for soeId = {} , No valid groups found.", soeId);
			return valuesList;
		}
		Set<Long> groupList = getAssignedGroupsfromDashboard(soeId, userGroupsList, isQMA2Origin);

		String finalQuery = openInquiryByGroupStr.replace("[55051]", "" + groupList.toString()).replace("[reloadCounter]", reloadCounter.toString());

		/*---- Start Migration --*/
		MongoCursor<DBObject> output = MongoDB.executeAggregatePipelineWithCursorReadPref("Inquiry_Aggregate_Chart_Data", finalQuery, ReadPreference.secondaryPreferred(),true,DBObject.class);
        /*---- End Migration --*/

	//DBCollection col = database.getCollection("Inquiry_Aggregate_Chart_Data");

	//subLogger.info("Data Fetched from Staging Table-reloadCounter = " + reloadCounter + " :: getOpenInquiryByGroupsOnFly query: " + query);
	// AggregationOutput output = col.aggregate(query,
	// ReadPreference.secondaryPreferred());
	/*AggregationOptions aggregationOptions = AggregationOptions.builder().build();
	Cursor output = col.aggregate(query, aggregationOptions, ReadPreference.secondaryPreferred());*/
	Map<Long, String> groupIdToCodeMap = QMACacheFactory.getCache().getGroupIdToCodeMap();
	Map<String, OpenInquiryByGroup> map = new HashMap<String, OpenInquiryByGroup>();
	Set<String> groupsList = new HashSet<String>();

	while (output.hasNext()) {
		DBObject result = output.next();
			DBObject dbObjectRow = (DBObject) result.get(QmaMailConstants.MONGO_PK);
			OpenInquiryByGroup g = new OpenInquiryByGroup();
			String assignedGroupId;
			boolean isNonInquiry = false;
			if (dbObjectRow != null && dbObjectRow.get("assignedGroupId") != null) {
				assignedGroupId = dbObjectRow.get("assignedGroupId").toString();
				String groupName = groupIdToCodeMap.get(Long.parseLong(assignedGroupId));

				// for the inactive groups, ther will not be any entry in cache groupIdToCodeMap
				if (groupName != null) {
					g.setGroup(groupName);
				} else {
					g.setGroup("Unassigned");
				}
				isNonInquiry = isNonInqiury(dbObjectRow);
				if (!isNonInquiry) {
					groupsList.add(g.getGroup());
				}
			}
			int count = Integer.valueOf(result.get("count").toString());
			String key = g.getGroup();
			// If isNonInqiry flag is true skip this record.
			if (!isNonInquiry) {
				if (map.get(key) != null) {
					OpenInquiryByGroup openInquiryByGroup = map.get(g.getGroup());
					openInquiryByGroup.setCount(openInquiryByGroup.getCount() + count);
				} else {
					OpenInquiryByGroup openInquiryByGroup = new OpenInquiryByGroup();
					openInquiryByGroup.setGroup(g.getGroup());
					openInquiryByGroup.setCount(count);
					map.put(key, openInquiryByGroup);
				}
			}
		}

		valuesList = new ArrayList<OpenInquiryByGroup>(map.values());
		return valuesList;
	}

	/*
	 * Decrement reloadCounter by one until data is found on
	 * Inquiry_Aggregate_Chart_Data (list is not null). scheduler job Updates -
	 * reload-counter in 'staticData' and 'Inquiry_Aggregate_Chart_Data' tables,
	 * both are separate transactions. Exceptional scenario : if update operation on
	 * Inquiry_Aggregate_Chart_Data fails then matching reloader counter won't be
	 * found in table. So decrement reloadCounter and try until data is found on
	 * Aggregate table.
	 * 
	 * @see com.citi.icg.qma.common.server.dao.persistence.IGraph1#
	 * getRequestTypesByGroupsOnFly(java.lang.String)
	 */
	@Override
	public List<RequestTypeByGroup> getRequestTypesByGroupsOnFly(String soeId, boolean isQMA2Origin) throws CommunicatorException {

		Long reloadCounter = getReloadCounterFromStaticData();
		List<RequestTypeByGroup> valuesList = null;
		User user = userDao.getUserById(soeId);
		Set<Long> userGroupsList = userDao.getUserGroupsList(user,IS_GROUP_ACTIVE);
		if (userGroupsList == null || userGroupsList.isEmpty()) {
			subLogger.info("getRequestTypesByGroupsOnFly for soeId = {} , No valid groups found.", soeId);
			return valuesList;
		}

		int readChartDataTryCount = 2;
		while (reloadCounter != null) {
			valuesList = getRequestTypesByGroupsOnFly(soeId, reloadCounter, userGroupsList, isQMA2Origin);

			if (valuesList != null && !valuesList.isEmpty()) {
				break;
			}
			if (readChartDataTryCount-- < 0) {
				subLogger.info("getRequestTypesByGroupsOnFly for soeId = {} readChartDataTryCount exceeded, and is: {}", soeId, readChartDataTryCount);
				break;
			}

			reloadCounter--;
		}

		return valuesList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.citi.icg.qma.common.server.dao.persistence.IGraph1#
	 * getRequestTypesByGroupsOnFly(java.lang.String)
	 */
	public List<RequestTypeByGroup> getRequestTypesByGroupsOnFly(String soeId, Long reloadCounter, Set<Long> userGroupsList, Boolean isQMA2Origin) throws CommunicatorException {
		List<RequestTypeByGroup> list = new ArrayList<RequestTypeByGroup>();
		if (userGroupsList == null || userGroupsList.isEmpty()) {
			subLogger.info("getAssignedOwnersByAgeBandListOnFly for soeId = " + soeId + " , No valid groups found.");
			return list;
		}

		Set<Long> groupList = getAssignedGroupsfromDashboard(soeId, userGroupsList, isQMA2Origin);

		Map<String, List<String>> groupRequestTypesMap = groupDao.getRequestTypesforGroups(groupList);

		String finalQuery = requestTypeByGroupStr.replace("[55051]", "" + groupList.toString()).replace("[reloadCounter]", reloadCounter.toString());
		/*---- Start Migration --*/
		MongoCursor<DBObject> output=MongoDB.executeAggregatePipelineWithCursorReadPref("Inquiry_Aggregate_Chart_Data", finalQuery, ReadPreference.secondaryPreferred(),true,DBObject.class);
        /*---- End Migration --*/

		//subLogger.info("reloadCounter = " + reloadCounter + " :: getRequestTypesByGroupsOnFly query: " + query);

		//DBCollection col = database.getCollection("Inquiry_Aggregate_Chart_Data");

		// AggregationOutput output =
		// col.aggregate(query,ReadPreference.secondaryPreferred());
		//AggregationOptions aggregationOptions = AggregationOptions.builder().build();
		//Cursor output = col.aggregate(query, aggregationOptions, ReadPreference.secondaryPreferred());

		Map<Long, String> groupIdToCodeMap = QMACacheFactory.getCache().getGroupIdToNameMap();
		boolean unassignedFlag;
		Map<String, RequestTypeByGroup> unassignedGroups = new HashMap<>();

		while (output.hasNext()) {
			DBObject result = output.next();
			DBObject dbObjectRow = (DBObject) result.get(QmaMailConstants.MONGO_PK);
			RequestTypeByGroup g = new RequestTypeByGroup();
			boolean isNonInquiry = isNonInqiury(dbObjectRow);
			// subLogger.info("isNonInquiry flag is" + isNonInquiry + " hence excluding this
			// record from RequestTypesByGroups chart.");
			// If isNonInqiry flag is true skip this record.
			if (!isNonInquiry) {
				unassignedFlag = false;
				String assignedGroupName = null;
				if (dbObjectRow.get("assignedGroupId") != null) {
					String assignedGroupId = dbObjectRow.get("assignedGroupId").toString();
					assignedGroupName = groupIdToCodeMap.get(Long.parseLong(assignedGroupId));
					g.setGroup(assignedGroupName);
					if (null == g.getGroup())
						g.setGroup("Unassigned");
				}

				// If dbObjectRow(REQUESTTYPE) == null or if dbObjectRow.requestType doesn't
				// belong to given group
				// then assign those recordsCount into *unAssigned(requestType) for given group,
				// recordCount is total of unassigned counts.
				// Example For group from DB : GroupName = AAAA , requestType = "test1","test2"
				// dbObject rec1: GroupName = AAAA , requestType = xxx and count = 10,
				// record 2: GroupName = AAAA , requestType = "test1" and count = 5,
				// record 3: GroupName = AAAA , requestType = null and count = 6,
				// result, GroupName = AAAA, requestType = "*Unassigned" , count = 16 (10+6)
				// (total of record1 and record 3)
				// result, GroupName = AAAA, requestType = "test1" , count = 5
				boolean resquestCheckFlag = null != assignedGroupName && null != groupRequestTypesMap.get(assignedGroupName)
						&& groupRequestTypesMap.get(assignedGroupName).contains(dbObjectRow.get(REQUESTTYPE));

				if (dbObjectRow.get(REQUESTTYPE) != null && resquestCheckFlag) {
					String requestType = dbObjectRow.get(REQUESTTYPE).toString();
					g.setRequestType(requestType);
				} else {
					unassignedFlag = true;
				}

				int count = 0;

				if (result.get("count") != null) {
					count = Integer.valueOf(result.get("count").toString());
					g.setCount(count);
				}

				if (unassignedFlag) {
					RequestTypeByGroup regGrouplc;
					if (null != unassignedGroups.get(assignedGroupName)) {
						regGrouplc = unassignedGroups.get(assignedGroupName);
						regGrouplc.setCount(regGrouplc.getCount() + count);
					} else {
						regGrouplc = new RequestTypeByGroup();
						regGrouplc.setCount(count);
						regGrouplc.setRequestType("Unassigned");
						regGrouplc.setGroup(assignedGroupName);
					}
					unassignedGroups.put(assignedGroupName, regGrouplc);
				} else {
					list.add(g);
				}
			}

		}
		for (Map.Entry<String, RequestTypeByGroup> grpentry : unassignedGroups.entrySet()) {
			list.add(grpentry.getValue());
		}
		Map<String, List<String>> groupRequestTypesMapFromDashboard = getRequestTypesMapFromDashboard(soeId, groupRequestTypesMap);
		List<RequestTypeByGroup> dashboardRequestTypeList = new ArrayList<>();
		for (RequestTypeByGroup requestTypeListObj : list) {
			if (null != groupRequestTypesMapFromDashboard && !groupRequestTypesMapFromDashboard.isEmpty()) {
				for (Map.Entry<String, List<String>> requesttypeMap : groupRequestTypesMapFromDashboard.entrySet()) {
					if (requestTypeListObj.getGroup().equals(requesttypeMap.getKey()) && requesttypeMap.getValue().contains(requestTypeListObj.getRequestType())
							&& !requestTypeListObj.getRequestType().equals("Unassigned")) {
						dashboardRequestTypeList.add(requestTypeListObj);
					}
				}
			}
		}
		if (null != dashboardRequestTypeList && !dashboardRequestTypeList.isEmpty()) {
			list = new ArrayList<>(dashboardRequestTypeList);
		}
		return getSortedAllRequestTypeByGroup(list);
	}

	/*
	 * Decrement reloadCounter by one until data is found on
	 * Inquiry_Aggregate_Chart_Data (list is not null). scheduler job Updates -
	 * reload-counter in 'staticData' and 'Inquiry_Aggregate_Chart_Data' tables,
	 * both are separate transactions. Exceptional scenario : if update operation on
	 * Inquiry_Aggregate_Chart_Data fails then matching reloader counter won't be
	 * found in table. So decrement reloadCounter and try until data is found on
	 * Aggregate table.
	 * 
	 * @see com.citi.icg.qma.common.server.dao.persistence.IGraph1#
	 * getAssignedOwnersByAgeBandListOnFly(java.lang.String)
	 */
	@Override
	public List<AssignedOwnersByAgeBandTO> getAssignedOwnersByAgeBandListOnFly(String soeId, Boolean includeGroupDetails, boolean isQMA2Origin) throws CommunicatorException// Sonar Fix -- Define and
																																											// throw a dedicated
																																											// exception instead of
																																											// using a generic one
	{

		Long reloadCounter = getReloadCounterFromStaticData();
		List<AssignedOwnersByAgeBandTO> valuesList = null;
		User user = userDao.getUserById(soeId);
		Set<Long> userGroupsList = userDao.getUserGroupsList(user,IS_GROUP_ACTIVE);
		if (userGroupsList == null || userGroupsList.isEmpty()) {
			subLogger.info("getAssignedOwnersByAgeBandListOnFly for soeId = {} , No valid groups found.", soeId);
			return valuesList;
		}
		int readChartDataTryCount = 2;
		while (reloadCounter != null) {
			valuesList = getAssignedOwnersByAgeBandListOnFly(soeId, reloadCounter, userGroupsList, includeGroupDetails, isQMA2Origin);

			if (valuesList != null && !valuesList.isEmpty()) {
				break;
			}
			if (readChartDataTryCount-- < 0) {
				subLogger.info("getAssignedOwnersByAgeBandListOnFly for soeId = {} readChartDataTryCount exceeded, and is: {}", soeId, readChartDataTryCount);
				break;
			}

			reloadCounter--;
		}

		return valuesList;
	}

	// Created ourselves..
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.citi.icg.qma.common.server.dao.persistence.IGraph1#
	 * getAssignedOwnersByAgeBandListOnFly(java.lang.String)
	 */
	public List<AssignedOwnersByAgeBandTO> getAssignedOwnersByAgeBandListOnFly(String soeId, Long reloadCounter, Set<Long> userGroupsList, Boolean includeGroupDetails, Boolean isQMA2Origin)
			throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a
										// generic one
	{
		ArrayList<AssignedOwnersByAgeBandTO> valuesList = null;
		if (userGroupsList == null || userGroupsList.isEmpty()) {
			subLogger.info("getAssignedOwnersByAgeBandListOnFly for soeId = {} , No valid groups found.", soeId);
			return valuesList;
		}

		String finalQuery = includeGroupDetails ? assignedOwnersByAgeBandStrPerGroup : assignedOwnersByAgeBandStr;
		Set<Long> groupList = getAssignedGroupsfromDashboard(soeId, userGroupsList, isQMA2Origin);

		finalQuery = finalQuery.replace("[55051]", "" + groupList.toString()).replace("[reloadCounter]", reloadCounter.toString());

		/*---- Start Migration --*/
		MongoCursor<DBObject> output=MongoDB.executeAggregatePipelineWithCursorReadPref("Inquiry_Aggregate_Chart_Data", finalQuery, ReadPreference.secondaryPreferred(),true,DBObject.class);
        /*---- End Migration --*/

	//subLogger.info("reloadCounter = " + reloadCounter + " :: getAssignedOwnersByAgeBandOnFly query: " + query);

	//DBCollection col = database.getCollection("Inquiry_Aggregate_Chart_Data");

	// AggregationOutput output =
	// col.aggregate(query,ReadPreference.secondaryPreferred());
	//AggregationOptions aggregationOptions = AggregationOptions.builder().build();
	//Cursor output = col.aggregate(query, aggregationOptions, ReadPreference.secondaryPreferred());

		List<String> bandList = creatListofBands();
		// Sonar Fix remove unused variable

		Map<String, AssignedOwnersByAgeBandTO> map = new HashMap<String, AssignedOwnersByAgeBandTO>();

		Set<String> userSetFromQuery = new HashSet<String>();
		Map<String, String> userIdNameMap = new HashMap();
		Map<Long, String> groupIdToCodeMap = QMACacheFactory.getCache().getGroupIdToNameMap();
		Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
		while (output.hasNext()) {
			DBObject result = output.next();
			DBObject dbObjectRow = (DBObject) result.get(QmaMailConstants.MONGO_PK);
			boolean isNonInquiry = isNonInqiury(dbObjectRow);
			// subLogger.info("isNonInquiry flag is"+isNonInquiry + " hence excluding this
			// record from getAssignedOwnersByAge chart.");
			// If isNonInqiry flag is true skip this record.
			if (!isNonInquiry) {
				int year = Integer.valueOf(dbObjectRow.get("YEAR").toString());
				int month = Integer.valueOf(dbObjectRow.get("MONTH").toString());
				int day = Integer.valueOf(dbObjectRow.get("DAY").toString());

				Calendar calendar = Calendar.getInstance();
				calendar.clear();
				calendar.set(Calendar.MONTH, month - 1); // here month will be month -1 as calendar uses like that..
				calendar.set(Calendar.YEAR, year);
				calendar.set(Calendar.DAY_OF_MONTH, day);
				Date createdDate = calendar.getTime();

				double daysElapsed = DateUtil.calculateAgeforGraphs(createdDate);
				// TODO : Days lapsed based on new age calculation

				String assignedUserId = dbObjectRow.get("assignedUserId") == null ? "Unassigned" : dbObjectRow.get("assignedUserId").toString();
				String assignedOwnerId = dbObjectRow.get("assignedUserId") == null ? "Unassigned" : dbObjectRow.get("assignedUserId").toString();

				User user = userInfoMap.get(assignedUserId.toUpperCase());

				if (user != null) {
					assignedUserId = user.getName();
				}
				int count = Integer.valueOf(result.get("count").toString());

				String band = null;
				bandList = creatListofBands();
				if (daysElapsed >= 0 && daysElapsed <= 1) {
					band = "1. 0-1 Days";
				} else if (daysElapsed >= 2 && daysElapsed <= 5) {
					band = "2. 2-5 Days";
				} else if (daysElapsed > 6 && daysElapsed <= 15) {
					band = "3. 6-15 Days";
				} else if (daysElapsed >= 16) {
					band = "4. 16+ Days";
				}
				String key = band + assignedUserId;
				String groupName = null;

				if (includeGroupDetails) {
					if (dbObjectRow.get("assignedGroupId") != null) {
						String assignedGroupId = dbObjectRow.get("assignedGroupId").toString();
						groupName = groupIdToCodeMap.get(Long.parseLong(assignedGroupId));

						// for the inactive groups, ther will not be any entry in cache groupIdToCodeMap
						if (groupName == null) {
							groupName = "Unassigned";
						}
						key = key + assignedGroupId;
					}
				}

				// subLogger.info("key : "+ key);
				userSetFromQuery.add(assignedUserId);
				userIdNameMap.put(assignedUserId, assignedOwnerId);

				if (map.get(key) != null) {
					AssignedOwnersByAgeBandTO assignedOwnersByAgeBand = map.get(key);
					assignedOwnersByAgeBand.setCount(assignedOwnersByAgeBand.getCount() + count);
				} else {
					AssignedOwnersByAgeBandTO assignedOwnersByAgeBand = new AssignedOwnersByAgeBandTO();
					assignedOwnersByAgeBand.setAgeBand(band);
					assignedOwnersByAgeBand.setAssignedOwner(assignedUserId);
					assignedOwnersByAgeBand.setAssignedOwnerId(assignedOwnerId);
					assignedOwnersByAgeBand.setCount(count);
					if (includeGroupDetails) {
						assignedOwnersByAgeBand.setGroup(groupName);
					}
					map.put(key, assignedOwnersByAgeBand);
				}
			}
		}

		fillMissingData(map, userSetFromQuery, bandList, userIdNameMap);
		Map<String, AssignedOwnersByAgeBandTO> assignedOwnerFromDashboard = getAssignedOwnerMapFromDashboard(soeId, map);
		if (null != assignedOwnerFromDashboard && !assignedOwnerFromDashboard.isEmpty()) {
			valuesList = new ArrayList<>(assignedOwnerFromDashboard.values());
		} else {
			valuesList = new ArrayList<>(map.values());
		}
		return valuesList;

	}

	public List<String> creatListofBands() {
		List<String> list = new ArrayList<String>();
		list.add("1. 0-1 Days");
		list.add("2. 2-5 Days");
		list.add("3. 6-15 Days");
		list.add("4. 16+ Days");

		return list;
	}

	void fillMissingData(Map<String, AssignedOwnersByAgeBandTO> map, Set<String> userSetFromQuery, List<String> bandList, Map<String, String> userIdNameMap) {
		for (String assignedUserId : userSetFromQuery) {
			for (int i = 0; i < bandList.size(); i++) {
				if (map.get(bandList.get(i) + assignedUserId) == null) {
					String key = bandList.get(i) + assignedUserId;
					AssignedOwnersByAgeBandTO assignedOwnersByAgeBand = new AssignedOwnersByAgeBandTO();
					assignedOwnersByAgeBand.setAgeBand(bandList.get(i));
					assignedOwnersByAgeBand.setAssignedOwner(assignedUserId);
					assignedOwnersByAgeBand.setAssignedOwnerId(userIdNameMap.get(assignedUserId));
					assignedOwnersByAgeBand.setCount(0);
					map.put(key, assignedOwnersByAgeBand);
				}
			}

		}
	}

	private List<RequestTypeByGroup> getSortedAllRequestTypeByGroup(List<RequestTypeByGroup> favorites) {
		if (favorites == null) {
			return favorites;
		}
		Collections.sort(favorites, new Comparator<RequestTypeByGroup>() {
			// Sonar fix -- use override annotation on overridden method
			@Override
			public int compare(final RequestTypeByGroup obj1, final RequestTypeByGroup obj2) {
				return obj1.getRequestType().compareTo(obj2.getRequestType());

			}
		});
		return favorites;

	}

	public static StaticData getStaticData() throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a
																			// generic one
	{
		StaticData staticData = null;
		subLogger.debug("getStaticData");
		Query<StaticData> query = MongoDB.instance().getDataStore().createQuery(StaticData.class);
		staticData = query.limit(1).get();

		return staticData;
	}

	/*
	 * For non inquiries this method will return true, false otherwise.
	 */
	boolean isNonInqiury(DBObject dbObjectRow) {
		boolean isNonInquiry = false;
		if (dbObjectRow != null && dbObjectRow.get("rulesFlag") != null) // Sonar Fix -- Collapsible "if" statements should be merged
		{
			// Logic to exclude non inquiries
			// if (dbObjectRow.get("rulesFlag") != null)
			// {
			DBObject obj = (DBObject) dbObjectRow.get("rulesFlag");
			Boolean val = (Boolean) obj.get("markAsNonInquiry");
			if (val != null && val)
				isNonInquiry = true;
			// }
		}
		return isNonInquiry;
	}

	/**
	 * This method is used to save the UI console logs.
	 * 
	 * @param soeId
	 * @param inputJsonObj
	 * @return
	 * @throws CommunicatorException
	 */
	public boolean saveUIConsoleLog(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {
		boolean isSaved = false;
		try {
			if (!StringUtils.isBlank(soeId)) {
				String uiConsoleLogAsString = (String) inputJsonObj.get("consoleLogArray");

				UIConsoleLog uiConsoleLog = new UIConsoleLog();
				uiConsoleLog.setUserId(soeId);
				uiConsoleLog.setUserLog(uiConsoleLogAsString);
				
				// Add user host information.
				String browser = (String) inputJsonObj.get("browser");
				if (!StringUtils.isEmpty(browser)) {
					uiConsoleLog.setBrowser(browser);
				}
				
				String userOs = (String) inputJsonObj.get("userOs");
				if (!StringUtils.isEmpty(userOs)) {
					uiConsoleLog.setOs(userOs);
				}
				
				String requestReceivedHost = (String) inputJsonObj.get("requestReceivedHost");
				if (!StringUtils.isEmpty(requestReceivedHost)) {
					uiConsoleLog.setRequestReceivedHost(requestReceivedHost);
				}
				
				String requesterHost = (String) inputJsonObj.get("requesterHost");
				if (!StringUtils.isEmpty(requesterHost)) {
					uiConsoleLog.setRequesterHost(requesterHost);
				}
				
				String origin = (String) inputJsonObj.get("origin");
				if (!StringUtils.isEmpty(origin)) {
					uiConsoleLog.setOrigin(origin);
				}

				MongoDB.instance().getDataStore().save(uiConsoleLog);
				isSaved = true;
			}
		} catch (Exception e) {
			subLogger.error("Exception in GenericDAO.saveUIConsoleLog", e);
			throw new CommunicatorException("Exception in GenericDAO.saveUIConsoleLog", e);
		}
		return isSaved;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.citi.icg.qma.common.server.dao.persistence.IGraph#
	 * getMaxChartDataInsertTime() XIRA - C153176-1193
	 */
	@Override
	public String getMaxChartDataInsertTime() throws CommunicatorException {
		Date insertTime = null;
		String insertTimeStr = null;
		insertTime = getInquiryAggregateChartData();
		if (null != insertTime) {
			subLogger.info("insertTime = " + getReloadCounterFromStaticData() + " :: in method getMaxChartDataInsertTime() ");
			String refreshTimeStr = insertTime.toString();
			SimpleDateFormat sourceDateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy");
			SimpleDateFormat targetDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			targetDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
			String formattedDate = DateUtil.changeDateStringFormat(refreshTimeStr, sourceDateFormat, targetDateFormat);
			insertTimeStr = "{ \"chartDataRefreshTime\":" + formattedDate.toString() + "}";
		}
		return insertTimeStr;
	}

	/**
	 * @return get InsertTime from Config table. XIRA - C153176-1193
	 */
	public Date getInquiryAggregateChartData() {
		Date insertTime = null;
		Config configData = getConfigDetailsForId("InquiryAggregateChartData");
		if (null != configData) {
			insertTime = configData.getInsertTime();
		}
		return insertTime;
	}

	public Long getReloadCounterFromStaticData() throws CommunicatorException {
		StaticData staticData = getStaticData();
		Long reloadCounter = staticData.getChartDataReloadMaxCounter();

		return reloadCounter;
	}

	// [C153176-725] - Admin Menu Enhancements for config role and other role
	// reviews
	// [C153176-544] - generalising the method to fetch Config details for a given
	// document id
	public Config getConfigDetailsForId(String id) {
		Query<Config> configQuery = mongoDatastore.createQuery(Config.class).filter(QmaMailConstants.MONGO_PK, id);
		Config config = new Config();

		if (configQuery != null && !configQuery.asList().isEmpty() && configQuery.asList().get(0) != null) {
			config = configQuery.asList().get(0);
		}
		return config;
	}

	/**
	 * @return List of Citidomain
	 */
	public List<String> getListOfCitiDomain() {
		// Map<String, Config> configData = CacheDAO.getInstance().getConfigIdMap();
		List<String> citidomainsList = null;
		QMACache qmaCache = QMACacheFactory.getCache();
		if (null != qmaCache.getConfigById("citiDomain")) {
			citidomainsList = qmaCache.getConfigById("citiDomain").getCitiDomains();
		}
		return citidomainsList;
	}

	/**
	 * @return
	 *
	 */
	public boolean getHighlevelRequestTypeFlag() {
		// Map<String, Config> configData = CacheDAO.getInstance().getConfigIdMap();
		boolean highlevelRequestTypeFlag = false;
		QMACache qmaCache = QMACacheFactory.getCache();
		if (null != qmaCache.getConfigById("highlevelRequestTypeIndicator")) {
			highlevelRequestTypeFlag = qmaCache.getConfigById("highlevelRequestTypeIndicator").isHighlevelRequestTypeFlag();
		}
		return highlevelRequestTypeFlag;
	}

	/**
	 * @return List of Highlevel Request Type [C153176-1563] - Request Types
	 *         normalization
	 */
	public List<String> getListOfHighlevelRequestTypes() {
		// Map<String, Config> configData = CacheDAO.getInstance().getConfigIdMap();
		List<String> highlevelRequestType = null;
		QMACache qmaCache = QMACacheFactory.getCache();
		if (null != qmaCache.getConfigById("highlevelReqestType")) {
			highlevelRequestType = qmaCache.getConfigById("highlevelReqestType").getHighlevelReqestTypes();
			Collections.sort(highlevelRequestType);
		}

		return highlevelRequestType;
	}

	public List<GFPIDMapping> getAllGfpIds(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {
		subLogger.info("Inside GenericDAO.getAllGfpIds - soeId= {}", soeId);
		Query<GFPIDMapping> gfpQuery = mongoDatastore.createQuery(GFPIDMapping.class);
		String gfpIdContainsFilter = inputJsonObj.getString("gfpIdMatch");
		if (StringUtils.isNotBlank(gfpIdContainsFilter)) {
			gfpQuery.criteria(QmaMailConstants.MONGO_PK).contains(gfpIdContainsFilter);
		}
		String[] retrivesFields = { QmaMailConstants.MONGO_PK, "gfpName" };
		gfpQuery.retrievedFields(true, retrivesFields);
		List<GFPIDMapping> gfpList = gfpQuery.asList();
		return gfpList;

	}

	public List<GFCIDTO> getAllGfcIds(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {
		subLogger.info("Inside GenericDAO.getAllGfcIds - soeId= {}", soeId);
		Query<GFPIDMapping> gfcQuery = mongoDatastore.createQuery(GFPIDMapping.class);
		buildCriteria(inputJsonObj, gfcQuery);
		String[] retrivesFields = { QmaMailConstants.MONGO_PK, "gfpName", "gfcIds" };
		gfcQuery.retrievedFields(true, retrivesFields);
		gfcQuery.order(QmaMailConstants.MONGO_PK).limit(DATA_LIMIT);
		List<GFPIDMapping> gfcDetailList = gfcQuery.asList();
		List<GFCIDTO> gfcIdTOList = new ArrayList<>();
		boolean filterOn = inputJsonObj.getBoolean("filterOnGfc");
		if (null != gfcDetailList && !gfcDetailList.isEmpty()) {
			for (GFPIDMapping gfpMapping : gfcDetailList) {
				if (filterOn) {
					populateGfcIdFromDB(gfcIdTOList, gfpMapping, inputJsonObj);
				} else {
					populateGfpIdFromDB(gfcIdTOList, gfpMapping, inputJsonObj);
				}
				if (gfcIdTOList.size() >= DATA_LIMIT) {
					break;
				}
			}
		}
		return gfcIdTOList;

	}

	private void buildCriteria(BasicDBObject inputJsonObj, Query<GFPIDMapping> query) {
		String filterType = inputJsonObj.getString("filterType");
		String filCriteria = inputJsonObj.getString("filCriteria");
		String filterVal = inputJsonObj.getString("filterVal");
		boolean ignoreCase = inputJsonObj.getBoolean("ignoreCase");
		if(null != filterType && null != filCriteria && null != filterVal) {
			if (CriteriaEnum.EQUALS.toString().equals(filterType)) {
				if (ignoreCase) {
					// Pattern pattern = Pattern.compile("^" + filterVal + "$",
					// Pattern.CASE_INSENSITIVE);
					query.criteria(filCriteria).equalIgnoreCase(filterVal);
				} else {
					query.criteria(filCriteria).equal(filterVal);
				}
			} else if (CriteriaEnum.CONTAINS.toString().equals(filterType)) {
				if (ignoreCase) {
					query.criteria(filCriteria).containsIgnoreCase(filterVal);
				} else {
					query.criteria(filCriteria).contains(filterVal);
				}
			} else if (CriteriaEnum.BEGINSWITH.toString().equals(filterType)) {
	
				if (ignoreCase) {
					query.criteria(filCriteria).startsWithIgnoreCase(filterVal);
				} else {
					query.criteria(filCriteria).startsWith(filterVal);
				}
			} else if (CriteriaEnum.ENDSWITH.toString().equals(filterType)) {
				if (ignoreCase) {
					query.criteria(filCriteria).endsWithIgnoreCase(filterVal);
				} else {
					query.criteria(filCriteria).endsWith(filterVal);
				}
			}
		}
	}

	private void populateGfpIdFromDB(List<GFCIDTO> gfcIdTOList, GFPIDMapping gfpMapping, BasicDBObject inputJsonObj) {
		for (GFCId dbGfcId : gfpMapping.getGfcIds()) {
			prepareGfIdList(gfcIdTOList, gfpMapping, dbGfcId);
			if (gfcIdTOList.size() >= DATA_LIMIT) {
				break;
			}

		}
	}

	private void populateGfcIdFromDB(List<GFCIDTO> gfcIdTOList, GFPIDMapping gfpMapping, BasicDBObject inputJsonObj) {
		String filterVal = inputJsonObj.getString("filterVal");
		String filterOnGfcId = inputJsonObj.getString("filterOnGfcId");
		String filterType = inputJsonObj.getString("filterType");
		String field = inputJsonObj.getString("field");
		String filterOnFieldVal = filterOnGfcId != null ? filterOnGfcId : filterVal;
		for (GFCId dbGfcId : gfpMapping.getGfcIds()) {
			if (StringUtils.isNotBlank(filterOnFieldVal)) {
				if (applyGfcFilterCriteria(dbGfcId, filterOnFieldVal, filterType, field)) {
					prepareGfIdList(gfcIdTOList, gfpMapping, dbGfcId);
					if (gfcIdTOList.size() >= DATA_LIMIT) {
						break;
					}
				}
			}
		}
	}

	private boolean applyGfcFilterCriteria(GFCId dbGfcId, String filterOn, String filterType, String field) {
		boolean gfcFilter = false;
		if (CriteriaEnum.BEGINSWITH.toString().equals(filterType)) {
			if (GFC_NAME.equals(field)) {
				gfcFilter = dbGfcId.getGfcName().toLowerCase().startsWith(filterOn.toLowerCase());
			} else {
				gfcFilter = dbGfcId.getGfcId().toLowerCase().startsWith(filterOn.toLowerCase());
			}
		} else if (CriteriaEnum.EQUALS.toString().equals(filterType)) {
			if (GFC_NAME.equals(field)) {
				gfcFilter = dbGfcId.getGfcName().equalsIgnoreCase(filterOn);
			} else {
				gfcFilter = dbGfcId.getGfcId().toLowerCase().equalsIgnoreCase(filterOn.toLowerCase());
			}
		} else if (CriteriaEnum.CONTAINS.toString().equals(filterType)) {
			if (GFC_NAME.equals(field)) {
				gfcFilter = dbGfcId.getGfcName().toLowerCase().contains(filterOn.toLowerCase());
			} else {
				gfcFilter = dbGfcId.getGfcId().toLowerCase().contains(filterOn.toLowerCase());
			}
		}
		return gfcFilter;
	}

	private void prepareGfIdList(List<GFCIDTO> gfcIdTOList, GFPIDMapping gfpMapping, GFCId dbGfcId) {
		GFCIDTO gfcIdTo = new GFCIDTO();
		gfcIdTo.setGfpId(gfpMapping.getId());
		gfcIdTo.setGfpName(gfpMapping.getGfpName());
		gfcIdTo.setGfcId(dbGfcId.getGfcId());
		gfcIdTo.setGfcName(dbGfcId.getGfcName());
		gfcIdTOList.add(gfcIdTo);
	}

	// [C153176-1014] - Add Escalation functionality
	// Method to load Config data into Cache
	public Map<String, Config> loadConfigDataFromDB() {
		Query<Config> query = mongoDatastore.createQuery(Config.class);
		List<Config> configDataList = query.asList();
		Map<String, Config> configIdMap = new HashMap<String, Config>();

		for (Config config : configDataList) {
			if (config != null) {
				configIdMap.put(config.getId(), config);
			}

		}
		return configIdMap;
	}

	public BasicDBObject getDBDocumentForID(BasicDBObject inputJsonObj) throws CommunicatorException {
		BasicDBObject doc = null;
		try {
			String collection = inputJsonObj.getString("collection");
			Object documentId = inputJsonObj.get("documentId");
			if (StringUtils.isNotBlank(collection)) {
				doc = (BasicDBObject) database.getCollection(collection).findOne(documentId);
			}
		} catch (Exception e) {
			subLogger.error("Exception in GenericDAO.getDBDocumentForID", e);
			throw new CommunicatorException("Exception in GenericDAO.getDBDocumentForID", e);
		}
		return doc;
	}

	public boolean updateDBCollectionDocument(BasicDBObject inputJsonObj) throws CommunicatorException {
		boolean isSaved = false;
		try {
			String collectionName = inputJsonObj.getString("collection");
			String jsonDoc = inputJsonObj.getString("jsonDoc");

			BasicDBObject updatedJsonDoc = BasicDBObject.parse(jsonDoc);
			Object docId = updatedJsonDoc.get(QmaMailConstants.MONGO_PK);

			database.getCollection(collectionName).update(new BasicDBObject(QmaMailConstants.MONGO_PK, docId), updatedJsonDoc);

			isSaved = true;
		} catch (Exception e) {
			subLogger.error("Exception in GenericDAO.updateDBCollectionDocument", e);
			throw new CommunicatorException("Exception in GenericDAO.updateDBCollectionDocument", e);
		}
		return isSaved;
	}

	/**
	 * @param collectionNameFromDB
	 * @param jobType
	 * @param todayDate
	 * 
	 */
	public void createBackupCollection(String collectionNameFromDB, String jobType, Date todayDate) throws CommunicatorException {

		String backupCollectionName = getBackupCollectionName(collectionNameFromDB, jobType, todayDate);

		subLogger.info("***** COLLECTION Name:{} and backupCollectionName::{}", collectionNameFromDB, backupCollectionName);

		List<DBObject> objects;
		DBCursor cursor = database.getCollection(collectionNameFromDB).find();
		objects = cursor.toArray();
		try {
			if (!objects.isEmpty()) {
				backupDatabase.getCollection(backupCollectionName).insert(objects);
			}

			subLogger.info("backup table is created for collection: {}, and backupcollection is:{}", collectionNameFromDB, backupCollectionName);

			// Index creation
			List<DBObject> indexes = database.getCollection(collectionNameFromDB).getIndexInfo();
			DBCollection backupCollection = backupDatabase.getCollection(backupCollectionName);

			for (DBObject index : indexes) {
				backupCollection.createIndex((BasicDBObject) index.get("key"), (String) index.get("name"));
			}

			subLogger.info("Index is created for backup table.");

		} catch (Exception ex) {
			subLogger.error("Issue in createBackupCollection" + ex.getMessage(), ex);
			throw new CommunicatorException("Exception in GenericDAO.createBackupCollection", ex);
		}

	}

	private String getBackupCollectionName(String collectionNameFromDB, String jobType, Date todayDate) {
		DateFormat timeStampFormat = new SimpleDateFormat("dd_MMM_yyyy_HH_mm_ss");
		String formattedTimestamp = timeStampFormat.format(todayDate);

		if (!"BACKEND".equals(jobType)) {
			// Group_UI_date
			return collectionNameFromDB + "_" + jobType + "_" + formattedTimestamp;
		} else {
			// Group_Date
			return collectionNameFromDB + "_" + formattedTimestamp;
		}

	}

	/**
	 * This method is used to drop a collection
	 * 
	 * @param collectionName
	 * @param subLogger
	 */
	public void dropCollection(String collectionName) {
		try {
			subLogger.info("Dropping collection before backup : {}", collectionName);
			MongoDB.instance().getDB().getCollection(collectionName).drop();
		} catch (MongoException e) {
			subLogger.error("Error in droping collection " + collectionName + " : ", e);
		}
	}

	/**
	 * This method is used to delete the Group
	 * 
	 * @param gfpid
	 */
	public void deleteGfpidMappingData(String gfpid) {
		try {
			mongoDatastore.delete(mongoDatastore.createQuery(GFPIDMapping.class).filter("id", gfpid));
		} catch (Exception e) {
			subLogger.error("Exception while deteting GFCID MAPPING data in GenericDAO#deleteGfpidMappingData()", e);
		}
	}

	public void updateConfigXStreamNetezzaJob(String configId, String collectionName, Date lastLoadTime) {
		Query<Config> query = mongoDatastore.createQuery(Config.class).filter("id", configId);
		String field = null;

		if (null != collectionName) {
			if ("actionStatistics".equals(collectionName)) {
				field = "netezzaJobActionStatisticsLastLoadTime";
			} else if ("messageSnapshot".equalsIgnoreCase(collectionName)) {
				field = "netezzaJobMessageSnapshotLastLoadTime";
			} else {
				field = "netezzaJobUserActivitiesLastLoadTime";
			}

			UpdateOperations<Config> ops = mongoDatastore.createUpdateOperations(Config.class).set(field, lastLoadTime);
			mongoDatastore.update(query, ops);
		}

		subLogger.info("updateConfigXStreamNetezzaJob updated config table Id :{} for field :{} with lastLoadTime is :{}", configId, field, lastLoadTime);

	}

	public Map<String, String> fetchMSExchangeServerConfigFromDB(Map<String, Config> configIdMap) {

		Map<String, String> exchangeServerConfigDetailsMap = new LinkedHashMap<String, String>();

		Config allkeyValues = configIdMap.get("msExchangeServerConfiguration");
		List<KeyValue> configList = allkeyValues.getMsExchangeServerConfigList();

		for (int i = 0; i < configList.size(); i++) {
			KeyValue configKeyValuePair = configList.get(i);
			exchangeServerConfigDetailsMap.put(configKeyValuePair.getKey(), configKeyValuePair.getValue());
		}

		return exchangeServerConfigDetailsMap;
	}

	public Map<String, Object> fetchNLPConfiguration() {
		Map<String, Object> nlpConfiguration = null;
		try {
			subLogger.info("Fetching NLP Configuration started.");
			Query<Config> nlpQuery = mongoDatastore.createQuery(Config.class);
			Config config = nlpQuery.get();
			nlpConfiguration = config.getNlpConfiguration();
			subLogger.info("Fetching NLP Configuration finished.");
		} catch (Exception e) {
			subLogger.error("Fetching NLP Configuration failed :", e);
		}
		return nlpConfiguration;
	}

	/**
	 * @param allToCCIncomingRecipientList
	 * @param subLogger
	 */
	public static Set<ConversationRecipient> addAutoFwdRecipients(Set<ConversationRecipient> allToCCIncomingRecipientList) {
		LinkedHashSet<ConversationRecipient> autoFwdRecipientList = new LinkedHashSet<>();
		// CacheDAO cacheDAO = CacheDAO.getInstance();
		// DLName -->List<AutoForwardedDL>
		// Map<String, Config> configData = cacheDAO.getConfigIdMap();
		try {
			// check mappings are available in DB
			QMACache qmaCache = QMACacheFactory.getCache();
			Map<String, Long> groupCodeToIdMap = qmaCache.getGroupCodeToIdMap();
			Map<Long, String> groupIdToEmailMap = qmaCache.getGroupIdToEmailMap();
			if (null != qmaCache.getConfigById(AUTOFWDDLS_MAPPING) && null != qmaCache.getConfigById(AUTOFWDDLS_MAPPING).getAutoFwdDLsMappings()
					&& !qmaCache.getConfigById(AUTOFWDDLS_MAPPING).getAutoFwdDLsMappings().isEmpty()) {
				List<String> finalFwdList = new ArrayList<>();
				Map<String, List<String>> autoFwdDLsMappings = qmaCache.getConfigById(AUTOFWDDLS_MAPPING).getAutoFwdDLsMappings();
				for (ConversationRecipient conversationRecipient : allToCCIncomingRecipientList) {
					// Get By Group/DL Name
					if (!("FROM").equalsIgnoreCase(conversationRecipient.getToFrom()) && conversationRecipient.getDisplayName() != null
							&& autoFwdDLsMappings.get(conversationRecipient.getDisplayName()) != null && !autoFwdDLsMappings.get(conversationRecipient.getDisplayName()).isEmpty()) {
						List<String> fwdDlsList = autoFwdDLsMappings.get(conversationRecipient.getDisplayName());
						for (String groupName : fwdDlsList) {
							ConversationRecipient conversationRecipientAutoFwd = new ConversationRecipient();
							conversationRecipientAutoFwd.setDisplayName(groupName);
							Long groupId = groupCodeToIdMap.get(groupName.toUpperCase());
							conversationRecipientAutoFwd.setGroupId(groupId);
							conversationRecipientAutoFwd.setEmailAddr(groupIdToEmailMap.get(groupId));
							conversationRecipientAutoFwd.setToFrom(conversationRecipient.getToFrom());

							// check duplicates recipient
							boolean isDuplicate = GenericUtility.checkDuplicates(allToCCIncomingRecipientList, groupName, conversationRecipient.getToFrom());
							if (!isDuplicate) {
								autoFwdRecipientList.add(conversationRecipientAutoFwd);
								finalFwdList.add(conversationRecipientAutoFwd.getDisplayName());
							}
						}
						subLogger.info("Fwded DL Names for {} : {}", conversationRecipient.getDisplayName(), finalFwdList);
					}

				}

			}

		} catch (Exception e) {
			subLogger.error("Fetching auto forward configuration failed", e);
		}
		return autoFwdRecipientList;
	}

	/**
	 * Authenticate and get user id from QMA Config DB
	 * 
	 * @param clientId
	 * @param clientSecretKey
	 * @param apiName
	 * @param subLogger
	 * @return
	 * @throws ApiAuthenticationException 
	 */
	public boolean getClientAppIdAfterAuthentication(String clientId, String clientSecretKey, String apiName) throws ApiAuthorizationException, ApiAuthenticationException {
		boolean isAuthorized = false;
		QMACache qmaCache = QMACacheFactory.getCache();
		if (null != qmaCache.getConfigById(APP_API_SUBSCRIPTION_MAPPING) && null != qmaCache.getConfigById(APP_API_SUBSCRIPTION_MAPPING).getAppConfig()) {
			// Get QMA Config for Application API Subscription
			List<ClientAuthorization> appConfig = qmaCache.getConfigById(APP_API_SUBSCRIPTION_MAPPING).getAppConfig();
			for (ClientAuthorization clientAuthorization : appConfig) {
				isAuthorized = authorizeRequest(clientAuthorization, clientId, clientSecretKey, apiName);
				if (isAuthorized) {
					break;
				}
			}
			if (!isAuthorized) {
				subLogger.error("API Subscription config not found for clientId:"+clientId +" and API:"+apiName);
				throw new ApiAuthorizationException("API Subscription config not found for clientId:"+clientId +" and API:"+apiName);
			}
		} else {
			subLogger.error("API Subscription config not found for clientId:{} and API:{}",clientId,apiName);
			throw new ApiAuthorizationException("API Subscription config not found for clientId:"+clientId +" and API:"+apiName);
		}
		return isAuthorized;
	}

	private boolean authorizeRequest(ClientAuthorization clientAuthorization, String clientId, String clientSecretKey, String apiName) throws ApiAuthenticationException, ApiAuthorizationException {
		boolean isAuthorized = false;
		if (clientAuthorization.getClientId().equals(clientId)) {
			String decrPassword = DecryptionUtil.decrypt(clientSecretKey, clientAuthorization.getClientSecretIV(), ApplicationConstants.APPLICATION_ENCRYPTION_KEY);
			if(null == decrPassword) {
				subLogger.info("Authentication failed. Incorrect password or client key.");
				throw new ApiAuthenticationException("Authentication failed. Incorrect password or client key.");
			}
			boolean isAuthorizedAPI = getAuthorizedAPI(clientAuthorization.getAuthorizedAPI(), apiName);
			if (decrPassword.equals(clientAuthorization.getQmaHandshakePwd()) && isAuthorizedAPI) {
				isAuthorized = true;
			}else {
				subLogger.info("Authentication failed. Incorrect password or client key.");
				throw new ApiAuthenticationException("Authentication failed. Incorrect password or client key.");
			}
		}
		return isAuthorized;
	}

	boolean getAuthorizedAPI(List<String> authorizedAPI, String apiName) throws ApiAuthorizationException {

		boolean isAuthorized = false;
		for (String apiCode : authorizedAPI) {
			isAuthorized = comapreWithRegisteredMap(apiCode, apiName);
			if (isAuthorized)
				break;
		}
		if(!isAuthorized) {
			subLogger.info("Api {}, is not registerd in the QMA",apiName);
			throw new ApiAuthorizationException("Api "+apiName+" is not registerd in the QMA");
		}
		return isAuthorized;
	}

	private boolean comapreWithRegisteredMap(String apiCode, String apiName) {
		boolean isAuthorized = false;
		QMACache qmaCache = QMACacheFactory.getCache();
		if (null != qmaCache.getConfigById(REGISTERED_API_MAP) && null != qmaCache.getConfigById(REGISTERED_API_MAP).getRegisteredAPIConfig()) {
			Map<String, Object> mapApi =qmaCache.getConfigById(REGISTERED_API_MAP).getRegisteredAPIConfig();
			for (Entry<String, Object> apiCodeFromMap : mapApi.entrySet()) {
				if (apiCodeFromMap.getValue().equals(apiName)) {
					isAuthorized = apiCode.equals(apiCodeFromMap.getKey());
					break;
				}

			}
		}
		return isAuthorized;
	}

	/**
	 * This method is used to display last updated holiday master date on UI
	 * 
	 * @return
	 * @throws CommunicatorException
	 */
	public String getLastUpdatedHolidayMasterDate() throws CommunicatorException {
		String lastUpdatedStr = "";
		StaticData staticData = getStaticData();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		if (null != staticData.getLastUpdatedHolidayMaster()) {
			Date dateLastUpdate = staticData.getLastUpdatedHolidayMaster();
			lastUpdatedStr = dateFormat.format(dateLastUpdate);
		}
		return lastUpdatedStr;
	}

	/**
	 * This method processes response code and specifies response message
	 * 
	 * @param statusCode
	 * @return
	 * @throws CommunicatorException
	 */
	BasicDBObject processResponseResult(int statusCode) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		response.put(QmaMailConstants.SUCCESS_KEY, true);
		if (statusCode == HttpStatus.SC_BAD_REQUEST) {
			/* Bad request */
			response.put(QmaMailConstants.MESSAGE_KEY, "Please provide correct request parameters and try again.");
		} else if (statusCode == HttpStatus.SC_INTERNAL_SERVER_ERROR) {
			/* Bad request */
			response.put(QmaMailConstants.MESSAGE_KEY, "Service is not available at the moment, Please try again later.");
		} else if (statusCode == HttpStatus.SC_UNAUTHORIZED) {
			/* Bad request */
			response.put(QmaMailConstants.MESSAGE_KEY, "Not authorized to make request, Please try again later.");
		} else {
			response.put(QmaMailConstants.MESSAGE_KEY, "Service is not available at the moment, Please contact Support.");
		}
		return response;
	}

	/**
	 * This method extract the response received from the CLC search service
	 * 
	 * @param content
	 * @param entity
	 * @throws IOException
	 */
	public StringBuilder extractSearchResponse(HttpEntity entity) throws IOException {
		StringBuilder content = new StringBuilder();
		byte[] buffer = new byte[1024];
		if (entity != null) {
			InputStream inputStream = entity.getContent();
			try (BufferedInputStream bis = new BufferedInputStream(inputStream)) {
				int bytesRead = 0;
				while ((bytesRead = bis.read(buffer)) != -1) {
					String chunk = new String(buffer, 0, bytesRead);
					content.append(chunk);
				}
			} catch (Exception e) {
				subLogger.error(" Error in CLCOperationsDAO#extractSearchResponse() :", e);
			}
		}
		return content;
	}

	/**
	 * method update HolidayMaster collection.
	 * 
	 * @param responseString
	 * @param subLogger
	 * @return
	 * @throws CommunicatorException
	 */
	public boolean updateHolidayMaster(String responseString) throws CommunicatorException {
		boolean success = false;
		try {
			// Clear all holidays from current date to end date and then insert
			clearHolidaysFromDateToEndDate();
			prepareHolidayMasterList(responseString);
			success = true;
			if (null != allHolidayMasterList && !allHolidayMasterList.isEmpty()) {
				DBCollection holidayMasterCollection = database.getCollection("HolidayMaster");
				BulkWriteOperation holidayMasterInsertOp = holidayMasterCollection.initializeOrderedBulkOperation();
				for (int i = 0; i < allHolidayMasterList.size(); i++) {
					DBObject dbobject = (DBObject) allHolidayMasterList.get(i);
					holidayMasterInsertOp.insert(dbobject);
				}
				holidayMasterInsertOp.execute();
			}
			if (allHolidayMasterList != null) {
				subLogger.info("Total no of records inserted into HolidayMaster:{}", allHolidayMasterList.size());
				allHolidayMasterList.clear();
			}
			updateIsFirstTimeUpload();
			updateLastImportedDate();
		} catch (IOException e) {
			subLogger.error("Error while preparing holiday data : ", e);
		}
		return success;
	}

	private void updateIsFirstTimeUpload() {
		try {
			String isFirstTimeUpload = QMACacheFactory.getCache().getConfigById(ISGCloudHolidaysUtil.ISG_CLOUD_HOLIDAYS_CONFIG).getIsgIsFirstTimeUpload();
			if ("Y".equalsIgnoreCase(isFirstTimeUpload)) {
				BasicDBObject updateIsFirstTimeUpload = new BasicDBObject();
				updateIsFirstTimeUpload.put("isgIsFirstTimeUpload", "N");
				BasicDBObject updateConfig = new BasicDBObject();
				updateConfig.put("$set", updateIsFirstTimeUpload);
				mongoDatastore.getCollection(Config.class).update(new BasicDBObject(ID, ISGCloudHolidaysUtil.ISG_CLOUD_HOLIDAYS_CONFIG), updateConfig);
				subLogger.info("First time updated flag set to N");
			}

		} catch (Exception e) {
			subLogger.error("Error while updating isFirstTimeUpload config.", e);
		}

	}

	private void clearHolidaysFromDateToEndDate() {
		try {
			String isFirstTimeUpload = QMACacheFactory.getCache().getConfigById(ISGCloudHolidaysUtil.ISG_CLOUD_HOLIDAYS_CONFIG).getIsgIsFirstTimeUpload();
			if ("N".equalsIgnoreCase(isFirstTimeUpload)) {
				Query<HolidayMaster> query = mongoDatastore.createQuery(HolidayMaster.class);
				query.and(query.criteria(ISGCloudHolidaysUtil.HOLIDAY_DATE).greaterThanOrEq(new Date()));
				LocalDate now = LocalDate.now();
				LocalDate endDate = now.with(lastDayOfYear());
				subLogger.info("Cleaning holidays from: {} to Date: {}", now, endDate);
				mongoDatastore.delete(query);
				subLogger.info("Holidays cleaning done..");
			}
		} catch (Exception e) {
			subLogger.error("Error while cleaning holidays..", e);
		}

	}

	private void updateLastImportedDate() {
		BasicDBObject updateTime = new BasicDBObject();
		updateTime.put("lastUpdatedHolidayMaster", new Date());
		BasicDBObject updateStaticData = new BasicDBObject();
		updateStaticData.put("$set", updateTime);
		mongoDatastore.getCollection(StaticData.class).update(new BasicDBObject(ID, 1), updateStaticData);
		subLogger.info("Import done successfully.");
	}

	/**
	 * method prepare HoldayMaster list from ISG cloud service
	 * 
	 * @param responseString
	 * @param subLogger
	 * @throws CommunicatorException
	 * @throws IOException
	 */
	public void prepareHolidayMasterList(String responseString) throws CommunicatorException, IOException {
		BasicDBObject responseFromISG = BasicDBObject.parse(responseString);
		BasicDBList holidayListFromISG = (BasicDBList) responseFromISG.get("results");
		BasicDBObject paging = (BasicDBObject) responseFromISG.get("paging");
		BasicDBList listHolidayMaster = new BasicDBList();
		BasicDBList listHolidayMasterDuplicates = new BasicDBList();
		if (lastholidayMasterId == 0) {
			getLastHolidaysId();
		}
		for (int i = 0; i < holidayListFromISG.size(); i++) {
			BasicDBObject basicDBObjectHoliday = (BasicDBObject) holidayListFromISG.get(i);
			lastholidayMasterId++;
			getHolidayMasterListFromObject(basicDBObjectHoliday, listHolidayMaster, listHolidayMasterDuplicates, lastholidayMasterId);
		}
		allHolidayMasterList.addAll(listHolidayMaster);
		subLogger.info("Page:" + pageCount + " [Total records fetched:" + holidayListFromISG.size() + "] [No of record inserted:" + listHolidayMaster.size() + "] [No of duplicates ignored:"
				+ listHolidayMasterDuplicates.size() + "]");
		if (null != paging) {
			pageCount++;
			String pageNextUrl = paging.getString("pageNext");
			String response = ISGCloudHolidaysUtil.getISGCloudHolidays(pageNextUrl);
			if (null != response) {
				this.prepareHolidayMasterList(response);
			}
		}
	}

	/**
	 * method get holiday object from basicDBObjectHoliday
	 * 
	 * @param basicDBObjectHoliday
	 * @param listHolidayMaster
	 * @param listHolidayMasterDuplicates
	 * @param id
	 */
	private void getHolidayMasterListFromObject(BasicDBObject basicDBObjectHoliday, BasicDBList listHolidayMaster, BasicDBList listHolidayMasterDuplicates, Long id) {
		try {
			SimpleDateFormat sDateFormat = new SimpleDateFormat(HolidaySync.DATE_FORMAT);
			sDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
			if (null != basicDBObjectHoliday) {
				String countryCode = basicDBObjectHoliday.getString(COUNTRY_CODE);
				String holidayDesc = basicDBObjectHoliday.getString(ISGCloudHolidaysUtil.HOLIDAY_DESC);
				String crtDateStr = basicDBObjectHoliday.getString(ISGCloudHolidaysUtil.HOLIDAY_DATE);
				String calendarTypeCode = basicDBObjectHoliday.getString(ISGCloudHolidaysUtil.TYPE);
				Date holidayDate = parseDate(sDateFormat, crtDateStr);

				DBObject dbObject = new BasicDBObject();
				dbObject.put(ISGCloudHolidaysUtil.ID, id);
				dbObject.put(COUNTRY_CODE, countryCode);
				dbObject.put(ISGCloudHolidaysUtil.HOLIDAY_DESC, holidayDesc);
				dbObject.put(ISGCloudHolidaysUtil.HOLIDAY_DATE, holidayDate);
				dbObject.put(ISGCloudHolidaysUtil.TYPE, calendarTypeCode);

				if (!checkDuplicates(countryCode, holidayDate)) {
					listHolidayMaster.add(dbObject);
					addToHolidaySet(countryCode, holidayDate);
				} else {
					listHolidayMasterDuplicates.add(dbObject);
					lastholidayMasterId--;
				}
			}
		} catch (Exception e) {
			subLogger.error("Error while creating holiday record :", e);
			lastholidayMasterId--;
		}
	}

	/**
	 * @param countryCode
	 * @param date
	 */
	public void addToHolidaySet(String countryCode, Date date) {
		SimpleDateFormat sDateFormatHolidaySet = new SimpleDateFormat(AppserverConstants.DATE_FORMAT_MM_DD_YYYY);
		holidaySet.add(countryCode + "_" + sDateFormatHolidaySet.format(date).trim());
	}

	/**
	 * method checks duplicate holidays
	 * 
	 * @param countryCode
	 * @param date
	 * @param listHolidayMaster
	 * @return
	 */
	boolean checkDuplicates(String countryCode, Date date) {
		SimpleDateFormat sDateFormat = new SimpleDateFormat(AppserverConstants.DATE_FORMAT_MM_DD_YYYY);
		boolean isDuplicate = false;
		if (holidaySet.contains(countryCode + "_" + sDateFormat.format(date).trim())) {
			return true;
		}
		return isDuplicate;
	}

	/**
	 * method parse date
	 * 
	 * @param sDateFormat
	 * @param date
	 * @return
	 */
	private Date parseDate(SimpleDateFormat sDateFormat, String date) {
		Date parsedDate = null;
		try {
			parsedDate = sDateFormat.parse(date);
			sDateFormat.applyPattern(AppserverConstants.DATE_FORMAT_MM_DD_YYYY);
			parsedDate = sDateFormat.parse(sDateFormat.format(parsedDate));
		} catch (ParseException e) {
			subLogger.error("error in pasrsing date", e);
		}
		return parsedDate;
	}

	/**
	 * method prepare holiday set from existing records
	 * 
	 * @return
	 * @throws CommunicatorException
	 */
	private void getLastHolidaysId() throws CommunicatorException {
		Query<HolidayMaster> query = null;
		SimpleDateFormat sDateFormat = new SimpleDateFormat(AppserverConstants.DATE_FORMAT_MM_DD_YYYY);
		try {
			query = mongoDatastore.createQuery(HolidayMaster.class).order("-" + ISGCloudHolidaysUtil.ID);
			DBCollection holidayMasterCollection = query.getCollection();
			DBCursor cursor = holidayMasterCollection.find();
			cursor.forEach(dbObject -> {
				HolidayMaster holidayMaster = new HolidayMaster();
				Long id = (Long) dbObject.get(ISGCloudHolidaysUtil.ID);
				holidayMaster.setId(id);
				String countryCode = (String) dbObject.get(COUNTRY_CODE);
				holidayMaster.setCountryCode(countryCode);
				Date holidayDate = (Date) dbObject.get(ISGCloudHolidaysUtil.HOLIDAY_DATE);
				holidayMaster.setHolidayDate(holidayDate);
				holidayMaster.setHolidayDesc((String) dbObject.get(ISGCloudHolidaysUtil.HOLIDAY_DESC));
				holidayMaster.setType((String) dbObject.get(ISGCloudHolidaysUtil.TYPE));
				holidaySet.add(countryCode + "_" + sDateFormat.format(holidayDate).trim());
				lastholidayMasterId = id;
			});
		} catch (Exception e) {
			subLogger.error("Exception in GenericDAO#getLastinsertedId :", e);
			throw new CommunicatorException("Could not locate last generated record id from Holiday Master. exiting");
		}
	}

	public BasicDBObject saveMISExclusionReportDetails(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {
		subLogger.info("Saving exclusion list to DB");
		BasicDBObject response = new BasicDBObject();

		String groupName = inputJsonObj.getString(GROUP_NAME);
		Integer groupId = Integer.parseInt(inputJsonObj.getString(GROUP_ID));
		String exclusionReportName = inputJsonObj.getString(EXCLUSION_REPORT_NAME);
		Integer exclusionTimeline = 1;
		String exclusionReason = inputJsonObj.getString(EXCLUSION_REASON);
		String exclusionEndDate = inputJsonObj.getString(END_DATE);
		String comments = inputJsonObj.getString(COMMENTS);

		String[] dateSubParts = exclusionEndDate.split("-");
		Calendar startCalender = Calendar.getInstance();
		startCalender.set(Calendar.HOUR_OF_DAY, 0);
		startCalender.set(Calendar.MINUTE, 0);
		startCalender.set(Calendar.SECOND, 0);
		startCalender.set(Calendar.MILLISECOND, 0);
		Calendar endCalender = Calendar.getInstance();
		endCalender.set(Calendar.HOUR_OF_DAY, 0);
		endCalender.set(Calendar.MINUTE, 0);
		endCalender.set(Calendar.SECOND, 0);
		endCalender.set(Calendar.MILLISECOND, 0);
		endCalender.set(Calendar.MONTH, Integer.parseInt(dateSubParts[0]) - 1);
		endCalender.set(Calendar.DATE, Integer.parseInt(dateSubParts[1]));
		endCalender.set(Calendar.YEAR, Integer.parseInt(dateSubParts[2]));

		Date startDate = startCalender.getTime();
		Date endDate = endCalender.getTime();

		MISReportExclusionRecord exclusionRecord = getRecordForReportNameAndGroupName(groupName, exclusionReportName, startDate, endDate, true);
		if (exclusionRecord != null) {
			if (exclusionRecord.getGroupName().equalsIgnoreCase(groupName) && exclusionRecord.getMisExclusionReportName().equalsIgnoreCase(exclusionReportName)
					&& exclusionRecord.getMisExclusionStartDate().toString().equalsIgnoreCase(startDate.toString())) {
				response.put(QmaMailConstants.MESSAGE_KEY, EXCLUSION_DETAILS_CANNOT_BE_EDITED);
			} else {
				response.put(QmaMailConstants.MESSAGE_KEY, EXCLUSION_DETAILS_ALREADY_PRESENT);
			}
			response.put(QmaMailConstants.SUCCESS_KEY, false);
		} else {
			exclusionRecord = new MISReportExclusionRecord();
			exclusionRecord.setActive(true);
			exclusionRecord.setComments(comments);
			exclusionRecord.setGroupName(groupName);
			exclusionRecord.setGroupId(groupId);
			exclusionRecord.setMisExclusionEndDate(endDate);
			exclusionRecord.setMisExclusionReason(exclusionReason);
			exclusionRecord.setMisExclusionReportName(exclusionReportName);
			exclusionRecord.setMisExclusionStartDate(startDate);
			exclusionRecord.setMisExclusionTimelineInMonths(exclusionTimeline);
			response.put(QmaMailConstants.MESSAGE_KEY, EXCLUSION_DETAILS_ADDED);
			response.put(QmaMailConstants.SUCCESS_KEY, true);
		}
		mongoDatastore.save(exclusionRecord);
		return response;
	}

	private MISReportExclusionRecord getRecordForReportNameAndGroupName(String groupName, String exclusionReportName, Date startDate, Date endDate, boolean active) {
		Query<MISReportExclusionRecord> query = null;
		MISReportExclusionRecord exclusionRecord = null;
		Date sDate = null;
		String timeFormat = "EEE MMM dd HH:mm:ss zzz yyyy";
		SimpleDateFormat sDateFormat = new SimpleDateFormat(timeFormat);
		try {
			sDate = sDateFormat.parse(startDate.toString());
		} catch (ParseException e) {
		    subLogger.warn("Exception in getRecordForReportNameAndGroupName", e);
		}
		query = mongoDatastore.createQuery(MISReportExclusionRecord.class).filter(GROUP_NAME, groupName).filter(EXCLUSION_REPORT_NAME, exclusionReportName).filter(START_DATE, sDate).filter(ACTIVE,
				active);
		query.order("-crtDate");
		exclusionRecord = query.get();
		if (exclusionRecord == null) {
			subLogger.info("No data found for the combination start date= {} and end date= {}", startDate, endDate);
		}
		return exclusionRecord;
	}

	public List<MISReportExclusionRecord> getMISExclusionRecords(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {
		String groupName = inputJsonObj.getString(GROUP_NAME);
		String exclusionReportName = inputJsonObj.getString(EXCLUSION_REPORT_NAME);
		return getRecordForMISExclusionFilters(groupName, exclusionReportName);
	}

	private List<MISReportExclusionRecord> getRecordForMISExclusionFilters(String groupName, String exclusionReportName) {
		Query query = null;

		if (StringUtils.isBlank(exclusionReportName))
			query = mongoDatastore.createQuery(MISReportExclusionRecord.class).filter(GROUP_NAME, groupName);
		else
			query = mongoDatastore.createQuery(MISReportExclusionRecord.class).filter(GROUP_NAME, groupName).filter(EXCLUSION_REPORT_NAME, exclusionReportName).retrievedFields(false,
					"misExclusionTimelineInMonths");
		query.order("-crtDate");
		List<MISReportExclusionRecord> exclusionRecordList = query.asList();
		if (exclusionRecordList == null) {
			subLogger.info("No data found for the combination group Name= {} and exclusion Report Name= {}", groupName, exclusionReportName);
		}
		return exclusionRecordList;
	}

	public BasicDBObject deactivateExclusion(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {

		BasicDBList list = (BasicDBList) inputJsonObj.get("idArray");
		List<Long> idList = new ArrayList<>();
		for (Object object : list) {
			idList.add(Long.valueOf(object.toString()));
		}
		BasicDBObject response = new BasicDBObject();
		for (int i = 0; i < idList.size(); i++) {
			Long id = idList.get(i);
			Query<MISReportExclusionRecord> unactiveQuery = mongoDatastore.createQuery(MISReportExclusionRecord.class).filter(ID, id);
			UpdateOperations<MISReportExclusionRecord> ops = mongoDatastore.createUpdateOperations(MISReportExclusionRecord.class).set("active", false);
			mongoDatastore.update(unactiveQuery, ops);
			response.put("exclusionIdList", idList);
		}
		response.put(QmaMailConstants.SUCCESS_KEY, true);
		return response;
	}

	public BasicDBObject createAndExecuteBulkGroupResolve(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();

		try {
			String groupName = inputJsonObj.getString(GROUP_NAME);
			Integer groupId = Integer.parseInt(inputJsonObj.getString(GROUP_ID));
			String startDate = inputJsonObj.getString("startDate");
			String comments = inputJsonObj.getString(COMMENTS);

			BasicDBObject status = executeBulkGroupResolve(groupId, startDate, comments);
			if (status.getBoolean("status")) {
				response.put(QmaMailConstants.SUCCESS_KEY, true);
				response.put(QmaMailConstants.MESSAGE_KEY, status.get("message"));
			} else {
				response.put(QmaMailConstants.SUCCESS_KEY, false);
				response.put(QmaMailConstants.MESSAGE_KEY, status.get("message"));
			}
		} catch (Exception e) {
			subLogger.error("Exception while executing bulk group resolve #createAndExecuteBulkGroupResolve " + e);
		}

		return response;
	}

	public BasicDBObject executeBulkGroupResolve(Integer groupId, String startDate, String comments) {
		boolean executionStatus = false;
		boolean executionStatusSingleWorkflow = false;
		boolean executionStatusMultipleWorkflow = false;
		boolean executionStatusOpenInquiry = false;
		BasicDBObject response = new BasicDBObject();
		try {

			executionStatusSingleWorkflow = executeQueryForSingleWorkflow(groupId, comments);
			if (executionStatusSingleWorkflow) {
				executionStatusMultipleWorkflow = executeQueryForMultipleWorkflow(groupId, comments);
				if (executionStatusMultipleWorkflow) {
					executionStatusOpenInquiry = executeQueryForOpenInquiry(groupId, comments);
				}
			}
			if (executionStatusSingleWorkflow && executionStatusMultipleWorkflow && executionStatusOpenInquiry) {
				executionStatus = true;
			}
			subLogger.info("Bulk Group Resolve successful");
			response.put("status", executionStatus);
			response.put("message", "Bulk Group Resolve successful");

		} catch (Exception e) {
			executionStatus = false;
			subLogger.error("Exception while executing bulk group resolve ", e);
			response.put("status", executionStatus);
			response.put("message", "Exception while executing bulk group resolve ");
		}

		return response;
	}

	private boolean executeQueryForOpenInquiry(Integer groupId, String comments) {
		boolean executionStatus = false;
		try {
			Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).field("status").equal("Open").field("workflows.assignedGroupId").equal(groupId);
			List<Inquiry> list = query.asList();
			for (int i = 0; i < list.size(); i++) {
				Inquiry inq = list.get(i);
				boolean isWorkflowResolved = checkIfAllWorkflowResolved(inq);
				if (isWorkflowResolved) {
					inq.setStatus(RESOLVED);
					inq.setUpdated(comments);
					Date currentTime = new Date();
					inq.setModDate(currentTime);
					mongoDatastore.save(inq);
					subLogger.info("Inquiry gets Resolved for multiple workflow");
				}
			}
			executionStatus = true;
		} catch (Exception e) {
			subLogger.error("Error while executing executeQueryForOpenInquiry ", e);
			executionStatus = false;
		}
		return executionStatus;
	}

	private boolean executeQueryForMultipleWorkflow(Integer groupId, String comments) {
		boolean executionStatus = false;
		try {
			String bulkGroupResolveQueryMulitpleWorkflow = "{'status' : 'Open' , 'workflows' : {'$elemMatch' : {'assignedGroupId' : { '$in' : [#groupId#]}, 'status' : 'Open'}}}";
			String finalQueryMulitpleWorkflow = bulkGroupResolveQueryMulitpleWorkflow.replace("#groupId#", "" + groupId);
			DBObject filterCmdMulitpleWorkflow = BasicDBObject.parse(finalQueryMulitpleWorkflow);
			BasicDBObject updateCmdMulitpleWorkflow = new BasicDBObject();
			updateCmdMulitpleWorkflow.put("workflows.$.status", RESOLVED);
			updateCmdMulitpleWorkflow.put("workflows.$.l3requestType", "Manually Closed");
			updateCmdMulitpleWorkflow.put("updated", comments);
			Date currentTime = new Date();
			updateCmdMulitpleWorkflow.put("workflows.$.modDate", currentTime);
			DBObject updateFinalMultipleWorkflow = new BasicDBObject();
			updateFinalMultipleWorkflow.put("$set", updateCmdMulitpleWorkflow);

			database.getCollection("Inquiry").updateMulti(filterCmdMulitpleWorkflow, updateFinalMultipleWorkflow);
			executionStatus = true;
			subLogger.info("Inquiry gets Resolved for multiple workflow");
		} catch (Exception e) {
			executionStatus = false;
			subLogger.error("Error while executing executeQueryForMultipleWorkflow " + e);
		}
		return executionStatus;
	}

	private boolean executeQueryForSingleWorkflow(Integer groupId, String comments) {
		boolean executionStatus = false;
		try {
			String bulkGroupResolveQuerySingleWorkflow = "{'status' : 'Open' , 'workflows' : {'$size':1, '$elemMatch' : {'assignedGroupId' : { '$in' : [#groupId#]}, 'status' : 'Open'}}}";
			String finalQuerySingleWorkflow = bulkGroupResolveQuerySingleWorkflow.replace("#groupId#", "" + groupId);
			DBObject filterCmdSingleWorkflow = BasicDBObject.parse(finalQuerySingleWorkflow);
			BasicDBObject updateCmdSingleWorkflow = new BasicDBObject();
			updateCmdSingleWorkflow.put("workflows.$.status", RESOLVED);
			updateCmdSingleWorkflow.put("workflows.$.l3requestType", "Manually Closed");
			updateCmdSingleWorkflow.put("status", RESOLVED);
			updateCmdSingleWorkflow.put("updated", comments);
			Date currentTime = new Date();
			updateCmdSingleWorkflow.put("workflows.$.modDate", currentTime);
			DBObject updateFinalSingleWorkflow = new BasicDBObject();
			updateFinalSingleWorkflow.put("$set", updateCmdSingleWorkflow);

			database.getCollection("Inquiry").updateMulti(filterCmdSingleWorkflow, updateFinalSingleWorkflow);
			executionStatus = true;
			subLogger.info("Inquiry gets Resolved for single workflow");
		} catch (Exception e) {
			executionStatus = false;
			subLogger.error("Error while executing executeQueryForSingleWorkflow ", e);
		}
		return executionStatus;
	}

	private boolean checkIfAllWorkflowResolved(Inquiry e) {
		boolean openWorkflow = true;
		List<Workflow> workflowsList = e.getWorkflows();

		for (int i = 0; i < workflowsList.size(); i++) {
			if (!RESOLVED.equalsIgnoreCase(workflowsList.get(i).getStatus())) {
				openWorkflow = false;
				break;
			}
		}
		return openWorkflow;
	}

	/**
	 * Get assigned group from dashboard settings if found else get default all
	 * assigned groups
	 * 
	 * @param soeId
	 * @param userGroupsList
	 * @return
	 * @throws CommunicatorException
	 */
	private Set<Long> getAssignedGroupsfromDashboard(String soeId, Set<Long> userGroupsList, boolean isQMA2Origin) throws CommunicatorException {
		Set<Long> groupList = userGroupsList;
		try {
//			if (!isQMA2Origin) {
//				return groupList;
//			}
			DashboardDAO dashBoardDAO = new DashboardDAO();
			dashBoardSettings = dashBoardDAO.getDashboardSettings(soeId);
			if (null != dashBoardSettings && null != dashBoardSettings.get(ASSIGNED_GROUPS)) {
				BasicDBList assignedGroupsList = (BasicDBList) dashBoardSettings.get(ASSIGNED_GROUPS);
				if (!assignedGroupsList.isEmpty()) {
					groupList = fillAssignedGroupsList(assignedGroupsList);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in GenericDAO.getAssignedGroupsfromDashboard for user:" + soeId, e);
			throw new CommunicatorException("Exception in GenericDAO.getAssignedGroupsfromDashboard", e);
		}
		return groupList;
	}

	/**
	 * This method is used to add all assigned groups to set.
	 * 
	 * @param assignedGroupsList
	 * @return
	 */
	private Set<Long> fillAssignedGroupsList(BasicDBList assignedGroupsList) {
		Set<Long> groupCodeList = new HashSet<>();
		QMACache qmaCache = QMACacheFactory.getCache();
		Map<String, Long> groupCodeToIdMap = qmaCache.getGroupCodeToIdMap();
		for (int i = 0; i < assignedGroupsList.size(); i++) {
			BasicDBObject assignedGroup = (BasicDBObject) assignedGroupsList.get(i);
			String groupName = assignedGroup.getString("groupName");
			if (null != groupName) {
				Long groupCode = groupCodeToIdMap.get(groupName.toUpperCase());
				groupCodeList.add(groupCode);
			}
		}
		return groupCodeList;
	}

	/**
	 * This method is used to get assigned request types from dashboard settings
	 * 
	 * @param soeId
	 * @param groupRequestTypesMap2
	 * @return
	 * @throws CommunicatorException
	 */
	private Map<String, List<String>> getRequestTypesMapFromDashboard(String soeId, Map<String, List<String>> groupRequestTypesMapAll) throws CommunicatorException {
		Map<String, List<String>> groupRequestTypesMap = new HashMap<>();
		try {
			if (null != dashBoardSettings && null != dashBoardSettings.get(ASSIGNED_GROUPS)) {
				BasicDBList assignedGroupsList = (BasicDBList) dashBoardSettings.get(ASSIGNED_GROUPS);
				if (!assignedGroupsList.isEmpty()) {
					prepareRequestTypesMap(groupRequestTypesMap, assignedGroupsList, groupRequestTypesMapAll);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in GenericDAO.getRequestTypesMapFromDashboard for user:" + soeId, e);
			throw new CommunicatorException("Exception in GenericDAO.getRequestTypesMapFromDashboard", e);
		}
		return groupRequestTypesMap;
	}

	/**
	 * This method is used to add request types to list
	 * 
	 * @param groupRequestTypesMap
	 * @param assignedGroupsList
	 * @param groupRequestTypesMapAll
	 */
	private void prepareRequestTypesMap(Map<String, List<String>> groupRequestTypesMap, BasicDBList assignedGroupsList, Map<String, List<String>> groupRequestTypesMapAll) {
		for (int i = 0; i < assignedGroupsList.size(); i++) {
			BasicDBObject assignedGroup = (BasicDBObject) assignedGroupsList.get(i);
			if (null != assignedGroup && null != assignedGroup.get("requestTypes") && null != assignedGroup.getString("groupName")) {
				BasicDBList requestTypesDBList = (BasicDBList) assignedGroup.get("requestTypes");
				List<String> requestTypesList = new ArrayList<>();

				for (Object el : requestTypesDBList) {
					requestTypesList.add((String) el);
				}
				String groupName = assignedGroup.getString("groupName");
				if (!requestTypesList.isEmpty()) {
					groupRequestTypesMap.put(groupName, requestTypesList);
				} else {
					groupRequestTypesMap.put(groupName, groupRequestTypesMapAll.get(groupName));
				}
			}
		}
	}

	/**
	 * This method is used to get all assigned owners for groups from dashboard
	 * settings.
	 * 
	 * @param soeId
	 * @param map
	 * @return
	 * @throws CommunicatorException
	 */
	private Map<String, AssignedOwnersByAgeBandTO> getAssignedOwnerMapFromDashboard(String soeId, Map<String, AssignedOwnersByAgeBandTO> map) throws CommunicatorException {
		Map<String, AssignedOwnersByAgeBandTO> assignedOwnerListAllGroups;
		try {
			assignedOwnerListAllGroups = null;
			if (null != dashBoardSettings && null != dashBoardSettings.get(ASSIGNED_GROUPS)) {
				BasicDBList assignedGroupsList = (BasicDBList) dashBoardSettings.get(ASSIGNED_GROUPS);
				if (!assignedGroupsList.isEmpty()) {
					assignedOwnerListAllGroups = addAssignedOwnersToList(assignedGroupsList, map);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in GenericDAO.getAssignedOwnerMapFromDashboard for soeId" + soeId, e);
			throw new CommunicatorException("Exception in GenericDAO.getAssignedOwnerMapFromDashboard", e);
		}
		return assignedOwnerListAllGroups;
	}

	/**
	 * This method is used to fill assigned owners list.
	 * 
	 * @param assignedGroupsList
	 * @param map
	 * @return
	 */
	private Map<String, AssignedOwnersByAgeBandTO> addAssignedOwnersToList(BasicDBList assignedGroupsList, Map<String, AssignedOwnersByAgeBandTO> map) {
		Map<String, AssignedOwnersByAgeBandTO> updatedMap = new HashMap<>();
		Map<String, Long> groupCodeToIdMap = QMACacheFactory.getCache().getGroupCodeToIdMap();
		Map<Long, List<String>> groupIdToUserListMap = QMACacheFactory.getCache().getGroupIdToUserListMap();
		Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
		for (int i = 0; i < assignedGroupsList.size(); i++) {
			BasicDBObject assignedGroup = (BasicDBObject) assignedGroupsList.get(i);
			if (null != assignedGroup.get("assignedOwner") && null != assignedGroup.getString("groupName")) {
				BasicDBList assignedOwnerList = (BasicDBList) assignedGroup.get("assignedOwner");
				String groupName = assignedGroup.getString("groupName");
				if (!assignedOwnerList.isEmpty()) {
					for (Object user : assignedOwnerList) {
						fillUpdatedAssignedOwnerMapByUser(map, updatedMap, user, groupName);
					}
				} else {
					QMACache qmaCache = QMACacheFactory.getCache();
					if(null != qmaCache && null != qmaCache.getGroupCodeToIdMap() && null !=  qmaCache.getGroupIdToUserListMap()) {
						Long groupId = qmaCache.getGroupCodeToIdMap().get(groupName.toUpperCase());
						List<String> assignedOwnerListFromCache = qmaCache.getGroupIdToUserListMap().get(groupId);
						if(null != assignedOwnerListFromCache) {
							for (String user : assignedOwnerListFromCache) {
								if(null != qmaCache.getUserInfoMap()) {
									User userDetails = qmaCache.getUserInfoMap().get(user.toUpperCase());
									if(null != userDetails) {
										fillUpdatedAssignedOwnerMapByUser(map, updatedMap, userDetails.getName(), groupName);
									}
								}
							}
						}
						fillUpdatedAssignedOwnerMapByUser(map, updatedMap, UNASSIGNED, groupName);
					}
				}
			}
		}
		return updatedMap;
	}

	/**
	 * @param map
	 * @param updatedMap
	 * @param el
	 * @param groupName
	 */
	private void fillUpdatedAssignedOwnerMapByUser(Map<String, AssignedOwnersByAgeBandTO> map, Map<String, AssignedOwnersByAgeBandTO> updatedMap, Object el, String groupName) {
		String assignedOwner = (String) el;
		for (Map.Entry<String, AssignedOwnersByAgeBandTO> entry : map.entrySet()) {
			AssignedOwnersByAgeBandTO assignedOwnersByAgeBand = entry.getValue();
			assignedOwnersByAgeBand.setGroup(groupName);
			if (assignedOwnersByAgeBand.getAssignedOwner().equals(assignedOwner)) {
				updatedMap.put(entry.getKey(), assignedOwnersByAgeBand);
			}
		}
	}

	/**
	 * This method access parameters from UI and generate feedback object to save it
	 * to DB
	 * 
	 * @param soeId
	 * @param inputJsonObj
	 * @return BasicDBObject
	 * @throws CommunicatorException
	 */
	public BasicDBObject saveUserAIMLFeedback(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();

		try {
			String correctionDataItem = inputJsonObj.getString(CORRECTION_DATA_ITEM_KEY);
			Long inquiryId = Long.parseLong(inputJsonObj.getString(INQUIRY_ID));
			Long convId = Long.parseLong(inputJsonObj.getString(CONV_ID));

			UserFeedback feedback = new UserFeedback(soeId, correctionDataItem, inquiryId, convId);

			boolean status = saveUserFeedback(feedback);
			if (status) {
				response.put(QmaMailConstants.SUCCESS_KEY, true);
				response.put(QmaMailConstants.MESSAGE_KEY, "User Feedback Captured Successfully.");
			} else {
				response.put(QmaMailConstants.SUCCESS_KEY, false);
				response.put(QmaMailConstants.MESSAGE_KEY, "Failed to capture User Feedback");
			}
		} catch (Exception e) {
			subLogger.error("Exception while capturing user feedback in GenericDAO#saveUserAIMLFeedback() ", e);
		}

		return response;
	}

	/**
	 * This method saves feedback record in database.
	 * 
	 * @param feedback
	 * @return boolean
	 */
	private boolean saveUserFeedback(UserFeedback feedback) {
		boolean status = false;
		try {
			dataStore.save(feedback);
			status = true;
		} catch (Exception e) {
			subLogger.error("Exception while saving in GenericDAO#saveUserFeedback() ", e);
			status = false;
		}
		return status;
	}

	public String getApplicationStatus() throws CommunicatorException {
		String applicationStatus = null;
		StaticData staticData = getStaticData();
		applicationStatus = staticData.getApplicationStatus();
		return applicationStatus;
	}

	/**
	 * Method to update GFC and GFP Details from AMCAR and AMC response.
	 * 
	 * @param responseString
	 * @throws CommunicatorException
	 */
	public void updateGFCDetails(String responseString) throws CommunicatorException {
		try {
			long startDate = System.currentTimeMillis();
			this.prepareGFCDetailsList(responseString);
			if (null != allGFCMappingDetailsList && !allGFCMappingDetailsList.isEmpty()) {
				DBCollection gfcDetailsMappingCollection = database.getCollection("GFCDetailsMapping");
				BulkWriteOperation gfcDetailsMappingInsertOp = gfcDetailsMappingCollection.initializeUnorderedBulkOperation();

				for (int i = 0; i < allGFCMappingDetailsList.size(); i++) {
					DBObject dbobject = (DBObject) allGFCMappingDetailsList.get(i);
					gfcDetailsMappingInsertOp.insert(dbobject);
				}
				BulkWriteResult result = gfcDetailsMappingInsertOp.execute();
				if (result.isAcknowledged()) {
					subLogger.info("GFC Details Mapping sync is completed");
					updateFirstTimeAndLastModified();
				}
			}
			long endDate = System.currentTimeMillis();
			long elapsed = (endDate - startDate) / 1000;
			if (allGFCMappingDetailsList != null) {
				allGFCMappingDetailsList.clear();
			}
			subLogger.info("Total no. of records inserted into GFCDetailsMapping: {}, Time Taken : {} Seconds", allGFCMappingDetailsList, elapsed ); // <-- sonar fix null pointer
		} catch (IOException e) {
			subLogger.error("Error while preparing GFC and GFP details data in GenericDAO#updateGFCDetails(): ", e);
			throw new CommunicatorException("Error while preparing GFC and GFP details data in GenericDAO#updateGFCDetails(): ", e);
		}
	}
	
	/**
	 * Method to create the backup of GFC Details Mapping collection before starting the job.
	 * 
	 * @throws CommunicatorException
	 */
	@SuppressWarnings("deprecation")
	public void createBackupCollection() throws CommunicatorException {
		try {
			database.getCollection(GFCDETAILS_MAPPING_BACK_UP).drop();
			subLogger.info("Creating backup collection: " + GFCDETAILS_MAPPING_BACK_UP);

			// Copying the data from Source collection to Backup.
			DBCollection source = mongoDatastore.getCollection(GFCDetailsMapping.class);
			AggregationOptions aggregationOptions = AggregationOptions.builder()
					.build();
			source.aggregate(Arrays.asList((DBObject) new BasicDBObject("$out", GFCDETAILS_MAPPING_BACK_UP)), aggregationOptions);

			//CacheDAO cacheDAO = CacheDAO.getInstance();
			//Map<String, Config> configData = cacheDAO.getConfigIdMap();
			Map<String, Object> isgCloudAmcarConfigMap = QMACacheFactory.getCache().getConfigById(ISGCloudAmcarUtil.ISG_CLOUD_AMCAR_CONFIG).getIsgCloudAmcarConfig();
			String isFirstTimeUpload = (String) isgCloudAmcarConfigMap.get(ISGCloudAmcarUtil.ISG_IS_FIRST_TIME_UPLOAD);

			if ("Y".equalsIgnoreCase(isFirstTimeUpload)) {
				// Clear the Source collection
				database.getCollection(GFCDETAILS_MAPPING).drop();
				subLogger.info("Clear the data of collection : "+ GFCDETAILS_MAPPING);
			}
			subLogger.info("Backup of collection : "+ GFCDETAILS_MAPPING + " is completed");
		} catch (Exception ex) {
			subLogger.error("Exception occurred in creating backup of a collection : " + GFCDETAILS_MAPPING_BACK_UP, ex);
			throw new CommunicatorException("Exception occurred in creating backup of a collection in GenericDAO#createBackupCollection() : " + ex);
		}
	}
	
	/**
	 * Method to update the AMCAR sync job status i.e. first time flag and Last Updated date.
	 */
	private void updateFirstTimeAndLastModified() {
		try {
			//CacheDAO cacheDAO = CacheDAO.getInstance();
			//Map<String, Config> configData = cacheDAO.getConfigIdMap();
			Map<String, Object> isgCloudAmcarConfigMap = QMACacheFactory.getCache().getConfigById(ISGCloudAmcarUtil.ISG_CLOUD_AMCAR_CONFIG).getIsgCloudAmcarConfig();
			String isFirstTimeUpload = (String) isgCloudAmcarConfigMap.get(ISGCloudAmcarUtil.ISG_IS_FIRST_TIME_UPLOAD);
			BasicDBObject updateAmcarConfig = new BasicDBObject();
			if ("Y".equalsIgnoreCase(isFirstTimeUpload)) {
				updateAmcarConfig.put("isgCloudAmcarConfig.isgIsFirstTimeUpload", "N");
				subLogger.info("First time updated flag set to N");
			}
			LocalDate today = LocalDate.now();
			Date lastUpdatedDate = Date.from(today.atStartOfDay(ZoneId.systemDefault()).toInstant());
			updateAmcarConfig.put("isgCloudAmcarConfig.lastUpdatedDate",lastUpdatedDate);
			BasicDBObject updateConfig = new BasicDBObject();
			updateConfig.put("$set", updateAmcarConfig);
			mongoDatastore.getCollection(Config.class).update(new BasicDBObject(ID, ISGCloudAmcarUtil.ISG_CLOUD_AMCAR_CONFIG), updateConfig);
			subLogger.info("lastUpdatedDate is update to : {}", new Date());
		} catch (Exception e) {
			subLogger.error("Error while updating updateFirstTimeAndLastModified config.", e);
		}
	}

	/**
	 * Method to prepare GFC/GFP Mapping from AMCAR response.
	 * 
	 * @param responseString
	 * @throws CommunicatorException
	 * @throws IOException
	 */
	public void prepareGFCDetailsList(String responseString) throws CommunicatorException, IOException {
		BasicDBObject responseFromISG = BasicDBObject.parse(responseString);
		BasicDBList gfcDetailsListFromISG = (BasicDBList) responseFromISG.get("results");
		BasicDBObject paging = (BasicDBObject) responseFromISG.get("paging");
		BasicDBList listGFCDetailsMapping = new BasicDBList();

		for (int i = 0; i < gfcDetailsListFromISG.size(); i++) {
			BasicDBObject basicDBObjectGFCDetail = (BasicDBObject) gfcDetailsListFromISG.get(i);
			getGFCDetailsListFromObject(basicDBObjectGFCDetail, listGFCDetailsMapping);
		}
		allGFCMappingDetailsList.addAll(listGFCDetailsMapping);
		subLogger.info("Page:" + pageCount + " [Total records fetched:" + gfcDetailsListFromISG.size() + "] [No of record inserted:" + listGFCDetailsMapping.size() + "]");

		if (null != paging) {
			pageCount++;
			String pageNextUrl = paging.getString("pageNext");
			String response = ISGCloudAmcarUtil.getISGCloudAmcarResults(pageNextUrl);
			if (null != response) {
				this.prepareGFCDetailsList(response);
			}
		}
	}

	/**
	 * Method to populate GFCDetailsMapping from the response got from AMCAR and AMC response.
	 * 
	 * @param basicDBObjectGFCDetail
	 * @param listGFCDetailsMapping
	 */
	private void getGFCDetailsListFromObject(BasicDBObject basicDBObjectGFCDetail, BasicDBList listGFCDetailsMapping) {
		try {
			if (null != basicDBObjectGFCDetail) {
				String gfcId = basicDBObjectGFCDetail.getString("GFCID");

				
				Query<GFCDetails> query = mongoDatastore.createQuery(GFCDetails.class).filter(ID, gfcId);
				@SuppressWarnings("deprecation")
				GFCDetails gfcRecord = query.get();
				if (null != gfcRecord) {
					DBObject dbObject = new BasicDBObject();
					
					String recordId = basicDBObjectGFCDetail.getString(ID);
					dbObject.put(ID, Long.valueOf(recordId));

					BasicDBObject dbGfpName = this.getGFCName(gfcRecord.getGfpId());

					// Grand Parent Details
					dbObject.put("grandParentNumber", dbGfpName.getString("GrandParentNumber"));
					dbObject.put("grandParentName", dbGfpName.getString("GrandParentName"));

					// Parent Details
					dbObject.put("gfpId", gfcRecord.getGfpId());
					dbObject.put("gfpName", dbGfpName.getString("GFCIDName"));

					// Child Details
					BasicDBObject dbGfcName = this.getGFCName(gfcId);
					dbObject.put("gfcId", gfcId);
					dbObject.put("gfcName", dbGfcName.getString("GFCIDName"));

					BasicDBObject alternateIdList = (BasicDBObject) basicDBObjectGFCDetail.get("AlternateIdList");
					BasicDBList acctDetailsList = (BasicDBList) alternateIdList.get("AlternateId");

					for (int i = 0; i < acctDetailsList.size(); i++) {
						BasicDBObject acctDetailObj = (BasicDBObject) acctDetailsList.get(i);
						String value = acctDetailObj.getString("value");
						String key = acctDetailObj.getString("name");

						switch (key) {
						case "SFSCNTRY":
							dbObject.put("accountCountry", value);
							break;
						case "SFSACCTNO":
							dbObject.put("skAccountNo", value);
							break;
						case "SFSBRANCH":
							dbObject.put("accountBranch", value);
							break;
						default:
							break;
						}
					}
					listGFCDetailsMapping.add(dbObject);
				}
			}
		} catch (Exception e) {
			subLogger.error("Error while creating GFC Details Mapping record in GenericDAO#getGFCDetailsListFromObject():", e);
		}
	}

	/**
	 * Method to get the GFCName based on GFCID from the AMC.
	 * 
	 * @param gfcId
	 * @return
	 * @throws IOException
	 */
	private BasicDBObject getGFCName(String gfcId) throws IOException {
		BasicDBObject basicDBObjectGFCName = null;
		String amcResponseString = ISGCloudAmcUtil.getISGCloudAmcResults(gfcId);
		BasicDBObject responseFromISG = BasicDBObject.parse(amcResponseString);
		BasicDBList gfcNameFromISG = (BasicDBList) responseFromISG.get("results");
		if (gfcNameFromISG.size() > 0) {
			basicDBObjectGFCName = (BasicDBObject) gfcNameFromISG.get(0);
		}
		return basicDBObjectGFCName;
	}
	
	/**
	 * Method to get all the GFC Details based on Criteria.
	 * 
	 * @param soeId
	 * @param inputJsonObj
	 * @return
	 * @throws CommunicatorException
	 */
	@SuppressWarnings("deprecation")
	public List<GFCIDTO> getAllGfcIdsQMA2(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {
		subLogger.info("Inside GenericDAO.getAllGfcIds - soeId= " + soeId + ", Input= " + inputJsonObj);
		boolean searchByAccount = inputJsonObj.getBoolean("accCriteria");
		Query<GFCDetailsMapping> gfcQuery = mongoDatastore.createQuery(GFCDetailsMapping.class);
		buildCriteriaQMA2(inputJsonObj, gfcQuery);
		gfcQuery.order("gfpId");
		gfcQuery.limit(DATA_LIMIT); // MongoDB throws an exception as data is huge in collection if not exact search.
		List<GFCDetailsMapping> gfcDetailList = gfcQuery.asList();
		List<GFCIDTO> gfcIdTOList = new ArrayList<>();
		if (null != gfcDetailList && !gfcDetailList.isEmpty()) {
			for (GFCDetailsMapping gfpMapping : gfcDetailList) {
				prepareGfIdListQMA2(gfcIdTOList, gfpMapping);
			}
		}

		if (!gfcIdTOList.isEmpty() && !searchByAccount) {
			Collection<GFCIDTO> uniquGfcIdTOList = gfcIdTOList.stream().<Map<String, GFCIDTO>>collect(HashMap::new, (m, e) -> m.put(e.getGfcId(), e), Map::putAll).values();
			return new ArrayList<GFCIDTO>(uniquGfcIdTOList);
		}
		return gfcIdTOList;
	}
	
	/**
	 * Method to build a criteria based on inputs.
	 * 
	 * @param inputJsonObj
	 * @param query
	 */
	private void buildCriteriaQMA2(BasicDBObject inputJsonObj, Query<GFCDetailsMapping> query) {
		String filterType = inputJsonObj.getString("filterType");
		String filCriteria = inputJsonObj.getString("filCriteria");
		String filterVal = inputJsonObj.getString("filterVal");
		boolean ignoreCase = inputJsonObj.getBoolean("ignoreCase");
		if("skAccountNo".equalsIgnoreCase(filCriteria)) {
			Set<String> searchKeys = getTirGramsForGFCDetails(filterVal);
			query.criteria("skAccountGrams").in(searchKeys);
		}
		if("gfcid".equalsIgnoreCase(filCriteria)) {
			Set<String> searchKeys = getTirGramsForGFCDetails(filterVal);
			query.criteria("gfcIdGrams").in(searchKeys);
		}
		
		if (CriteriaEnum.EQUALS.toString().equals(filterType)) {
			if (ignoreCase) {
				query.criteria(filCriteria).equalIgnoreCase(filterVal);
			} else {
				query.criteria(filCriteria).equal(filterVal);
			}
		} else if (CriteriaEnum.CONTAINS.toString().equals(filterType)) {
			if (ignoreCase) {
				query.criteria(filCriteria).containsIgnoreCase(filterVal);
			} else {
				query.criteria(filCriteria).contains(filterVal);
			}
		} else if (CriteriaEnum.BEGINSWITH.toString().equals(filterType)) {

			if (ignoreCase) {
				query.criteria(filCriteria).startsWithIgnoreCase(filterVal);
			} else {
				query.criteria(filCriteria).startsWith(filterVal);
			}
		} else if (CriteriaEnum.ENDSWITH.toString().equals(filterType)) {
			if (ignoreCase) {
				query.criteria(filCriteria).endsWithIgnoreCase(filterVal);
			} else {
				query.criteria(filCriteria).endsWith(filterVal);
			}
		}

		// Add the account branch as AND criteria.
		String accountBranch = inputJsonObj.getString("acctBranch");
		if (StringUtils.isNotBlank(accountBranch)) {
			Set<String> searchKeys = getTirGramsForGFCDetails(accountBranch);
			query.criteria("accountBranchGrams").in(searchKeys);
			query.criteria("accountBranch").contains(accountBranch);
		}
	}
	
	private Set<String> getTirGramsForGFCDetails(String filterVal) {
		Set<String> trigrams = new LinkedHashSet<>();
		if(StringUtils.isBlank(filterVal) || filterVal.length() < 3) {
			return trigrams;
		}
		String gram = filterVal.toLowerCase();
		List<String>  list = IntStream.range(0, gram.length() - 2)
	                .mapToObj(i -> gram.substring(i, i + 3))
	                .collect(Collectors.toList());
		trigrams.addAll(list);
        return trigrams;

		
	}

	/**
	 * Method to prepare list of GFC Details from the result returned from query.
	 * 
	 * @param gfcIdTOList
	 * @param gfpMapping
	 */
	private void prepareGfIdListQMA2(List<GFCIDTO> gfcIdTOList, GFCDetailsMapping gfpMapping) {
		GFCIDTO gfcIdTo = new GFCIDTO();
		gfcIdTo.setGfpId(gfpMapping.getGfpId());
		gfcIdTo.setGfpName(gfpMapping.getGfpName());
		gfcIdTo.setGfcId(gfpMapping.getGfcId());
		gfcIdTo.setGfcName(gfpMapping.getGfcName());
		gfcIdTo.setSkAccountNo(gfpMapping.getSkAccountNo());
		gfcIdTo.setBranch(gfpMapping.getAccountBranch());
		gfcIdTOList.add(gfcIdTo);
	}
	
	/**
	 * This method refresh cache bases on Collection name from each node
	 * @param collectionName
	 * @throws IOException
	 */
	public String reloadDbCollectionFromServer(String soeId, String cacheName){ 
		subLogger.info("GenericDAO#reloadDbCollectionFromServer init {}",soeId);
		
		String cacheRefreshUrl=""; 
		//cacheRefreshConfig
		//Static, /staticRefresh 
		//Config , /configRefresh 
		//Group , /groupDataRefresh
		
		QMACache qmaCache = QMACacheFactory.getCache();
		if (null != qmaCache.getConfigById("cacheRefreshConfig") && cacheName.equals("All")) {
			cacheRefreshUrl = qmaCache.getConfigById("cacheRefreshConfig").getFullRefreshUrl();
		}
		
		BasicDBObject responseResult = new BasicDBObject();
		BasicDBList content = new BasicDBList ();	
		try {
			if(!cacheRefreshUrl.isEmpty() ){
					cacheRefreshUrl = cacheRefreshUrl + "?soeId=" + soeId;
					content = makeHttpRequest(cacheRefreshUrl, content, cacheName,soeId);
			}else {
				responseResult.put(AppserverConstants.REFRESH_TYPE, cacheName);
				responseResult.put(AppserverConstants.SUCCESS_KEY, "FAIL");
				content.add(responseResult);
			}
							
		} catch (Exception e) {
			subLogger.error("Error while refreshing cache in GenericDAO#reloadDbCollectionFromServer() soeId: {}: , {}",soeId, e);
			responseResult.put(AppserverConstants.REFRESH_TYPE, cacheName);
			responseResult.put(AppserverConstants.SUCCESS_KEY, "FAIL");
			content.add(responseResult);
			
		}
		subLogger.info("GenericDAO#reloadDbCollectionFromServer done.");
		return content.toString();	
		
	}
	
	/**
	 * This method makes server request to refresh cache
	 * @param url
	 * @param content
	 * @return StringBuilder
	 * @throws IOException
	 */
	private BasicDBList makeHttpRequest(String url, BasicDBList content, String cacheName,String soeId){
		HttpClient httpClient = HttpClientBuilder.create().build();
		BasicDBObject responseResult = new BasicDBObject();
		try{
			if( httpClient != null && !StringUtils.isEmpty(url)) {	
				HttpGet getRequest = new HttpGet(url);																
				HttpResponse response = httpClient.execute(getRequest);
				if (response.getStatusLine().getStatusCode() != 200) {
					responseResult.put(AppserverConstants.REFRESH_TYPE, cacheName);
					responseResult.put(AppserverConstants.SUCCESS_KEY, "FAIL");
					subLogger.info("Cache failed to Refreshed for url: {}  for soeId: {}, with status code: {} message: {}", url,soeId, response.getStatusLine().getStatusCode(), response.getStatusLine().getReasonPhrase());
					content.add(responseResult);
				} else {
					HttpEntity entity = response.getEntity();
					responseResult.put(AppserverConstants.REFRESH_TYPE, cacheName);
					responseResult.put(AppserverConstants.SUCCESS_KEY, "SUCCESS");
					content.add(responseResult);
					subLogger.info("Cache Refreshed for soeId: {}, url: {}, Response: {} ",soeId,url,content);
				}
			} else {
				responseResult.put(AppserverConstants.REFRESH_TYPE, cacheName);
				responseResult.put(AppserverConstants.SUCCESS_KEY, "FAIL");
				subLogger.info("Cache failed to Refreshed for soeId: {}, url: {}, Response: {} ",soeId,url,content);
				content.add(responseResult);
			}
		} catch (Exception e) {
			subLogger.error("Error while refreshing cache for soeId:{} server: {} in GenericDAO#reloadDbCollectionFromServer() :{}",soeId,url, e);
			responseResult.put(AppserverConstants.REFRESH_TYPE, cacheName);
			responseResult.put(AppserverConstants.SUCCESS_KEY, "FAIL");
			content.add(responseResult);
		}
		return content;
	}	
	
	public List<TaskizeParticipantsContactMapping> getTaskizeParticipantsContactMapping() {
		List<TaskizeParticipantsContactMapping> taskizeParticipantContactMapping = new ArrayList<>();
		try {

			Config configData = QMACacheFactory.getCache().getConfigById("taskizeParticipantsContactMapping");
			if (null != configData) {
				taskizeParticipantContactMapping = configData.getTaskizeParticipantsContactMapping();
			}

		} catch (Exception e) {
			subLogger.warn("Error while populating {} :{}", "taskizeParticipantsContactMapping", e);
		}
		return taskizeParticipantContactMapping;
	}
	
	/**
	 * This method uploads the file to MongoDB using GridFS API
	 * @param releaseNoteInputStream
	 * @param fileName
	 */
	public boolean uploadReleaseNoteToMongo( InputStream releaseNoteInputStream, String fileName ) {
	    boolean success = false;
	    try {
	    	GridFSBucket gridBucket = GridFSBuckets.create( mongoDatabase, RELEASE_DOCUMENTS);
	    	GridFSUploadOptions options = new GridFSUploadOptions().chunkSizeBytes(261120).metadata(new Document(CONTENT_TYPE , APPLICATION_PDF).append(ALIASES,null).append(MD5, GenericUtility.calculateChecksum(releaseNoteInputStream)));
	    	ObjectId fileId = gridBucket.uploadFromStream(fileName, releaseNoteInputStream, options);
	    	success = true;
	    	subLogger.info("Release Notes file {} uploaded to MongoDB with fileId : {}", fileName, fileId);
	    }
	    catch(Exception e) {
	    	subLogger.error("Exception in Generic.uploadReleaseNoteToMongo", e);
	    }
	    return success;
	}
	
	/**
	 * This method updates the currentReleaseDocumentName in the Config Collection
	 * @param releaseNoteFileName
	 */
	public boolean updateReleaseNoteNameInConfig(String releaseNoteFileName ) {
	    boolean success = false;
	    try {
	        Query<Config> query = mongoDatastore.createQuery(Config.class).filter(ID, "releaseNotes");
	        UpdateOperations<Config> ops = mongoDatastore.createUpdateOperations(Config.class);			
	        ops.set("currentReleaseDocumentName",releaseNoteFileName);
	        mongoDatastore.update(query, ops);
	        success = true;
	        subLogger.info("Updated currentReleaseDocumentName in Config collection with value {}",releaseNoteFileName);
	    }
	    catch(Exception e) {
	    	subLogger.error("Exception in Generic.updateReleaseNoteNameInConfig", e);
	    }
	    return success;
	}
	/**
	 * This method adds the Release Note File to the whitelisted api's in the Config Collection
	 * @param releaseNoteFileName
	 */
	
	public boolean addReleaseNoteNameToWhiteListApi(String releaseNoteFileName ) {
	    boolean success = false;
	    List <String> values = new ArrayList<String>();
	    try {
		    Query<Config> query = mongoDatastore.createQuery(Config.class).filter(ID, "authConfig");
			UpdateOperations<Config> ops = mongoDatastore.createUpdateOperations(Config.class);	
			values.add(RELEASE_NOTE_PATH + releaseNoteFileName);
			values.add(RELEASE_NOTE_PATH_ECS + releaseNoteFileName);
			ops.addToSet("authConfig.whiteListedApis", values);
			mongoDatastore.update(query, ops);
			subLogger.info("Added {} {} to whitelisted api in authConfig for release note upload.", RELEASE_NOTE_PATH + releaseNoteFileName, RELEASE_NOTE_PATH_ECS + releaseNoteFileName );
			success = true;
	    }
	    catch(Exception e) {
		subLogger.error("Exception in Generic.addReleaseNoteNameToWhiteListApi", e);
	    }
	    return success;
	}
	
	public List<HolidayMaster> loadHolidayMasterFromDB() {
		return mongoDatastore.find(HolidayMaster.class).find(new FindOptions()).toList();
	}
}
