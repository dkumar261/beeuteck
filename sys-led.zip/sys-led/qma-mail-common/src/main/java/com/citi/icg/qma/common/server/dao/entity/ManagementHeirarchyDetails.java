package com.citi.icg.qma.common.server.dao.entity;

import java.io.Serializable;

public class ManagementHeirarchyDetails implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5367950549061622741L;
	private String appId;
	private Long id;
	private String organisation;
	private String firstLevelHeirarchyId;
	private String firstLevelHeirarchyName;
	private String secondLevelHeirarchyId;
	private String secondLevelHeirarchyName;
	private String gfcid;
	/**
	 * @return the appId
	 */
	public String getAppId()
	{
		return appId;
	}
	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId)
	{
		this.appId = appId;
	}
	/**
	 * @return the id
	 */
	public Long getId()
	{
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Long id)
	{
		this.id = id;
	}
	/**
	 * @return the organisation
	 */
	public String getOrganisation()
	{
		return organisation;
	}
	/**
	 * @param organisation the organisation to set
	 */
	public void setOrganisation(String organisation)
	{
		this.organisation = organisation;
	}
	/**
	 * @return the firstLevelHeirarchyId
	 */
	public String getFirstLevelHeirarchyId()
	{
		return firstLevelHeirarchyId;
	}
	/**
	 * @param firstLevelHeirarchyId the firstLevelHeirarchyId to set
	 */
	public void setFirstLevelHeirarchyId(String firstLevelHeirarchyId)
	{
		this.firstLevelHeirarchyId = firstLevelHeirarchyId;
	}
	/**
	 * @return the firstLevelHeirarchyName
	 */
	public String getFirstLevelHeirarchyName()
	{
		return firstLevelHeirarchyName;
	}
	/**
	 * @param firstLevelHeirarchyName the firstLevelHeirarchyName to set
	 */
	public void setFirstLevelHeirarchyName(String firstLevelHeirarchyName)
	{
		this.firstLevelHeirarchyName = firstLevelHeirarchyName;
	}
	/**
	 * @return the secondLevelHeirarchyId
	 */
	public String getSecondLevelHeirarchyId()
	{
		return secondLevelHeirarchyId;
	}
	/**
	 * @param secondLevelHeirarchyId the secondLevelHeirarchyId to set
	 */
	public void setSecondLevelHeirarchyId(String secondLevelHeirarchyId)
	{
		this.secondLevelHeirarchyId = secondLevelHeirarchyId;
	}
	/**
	 * @return the secondLevelHeirarchyName
	 */
	public String getSecondLevelHeirarchyName()
	{
		return secondLevelHeirarchyName;
	}
	/**
	 * @param secondLevelHeirarchyName the secondLevelHeirarchyName to set
	 */
	public void setSecondLevelHeirarchyName(String secondLevelHeirarchyName)
	{
		this.secondLevelHeirarchyName = secondLevelHeirarchyName;
	}
	
	/**
	 * @return the gfcid
	 */
	public String getGfcid()
	{
		return gfcid;
	}
	/**
	 * @param gfcid the gfcid to set
	 */
	public void setGfcid(String gfcid)
	{
		this.gfcid = gfcid;
	}
	/**
	 * @param appId
	 * @param id
	 * @param organisation
	 * @param firstLevelHeirarchyId
	 * @param firstLevelHeirarchyName
	 * @param secondLevelHeirarchyId
	 * @param secondLevelHeirarchyName
	 * @param thirdLevelHeirarchyId
	 * @param thirdLevelHeirarchyName
	 * @param gfcid
	 */
	public ManagementHeirarchyDetails(String appId, Long id, String organisation, String firstLevelHeirarchyId, String firstLevelHeirarchyName, String secondLevelHeirarchyId,
			String secondLevelHeirarchyName, String gfcid)
	{
		super();
		this.appId = appId;
		this.id = id;
		this.organisation = organisation;
		this.firstLevelHeirarchyId = firstLevelHeirarchyId;
		this.firstLevelHeirarchyName = firstLevelHeirarchyName;
		this.secondLevelHeirarchyId = secondLevelHeirarchyId;
		this.secondLevelHeirarchyName = secondLevelHeirarchyName;
		this.gfcid = gfcid;
	}
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return appId + "\t" + id + "\t" + organisation + "\t" + firstLevelHeirarchyId + "\t" + firstLevelHeirarchyName + "\t" + secondLevelHeirarchyId + "\t" +secondLevelHeirarchyName + "\t" + gfcid;
	}

}
