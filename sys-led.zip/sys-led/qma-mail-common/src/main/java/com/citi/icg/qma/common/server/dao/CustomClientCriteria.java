package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

import dev.morphia.annotations.Embedded;

@Embedded
public class CustomClientCriteria implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1694036024158711534L;
	private String categoryName;
	private String colorCode;
	private RuleCriteria rules;
	
	public CustomClientCriteria()
	{
		super();
	}

	public CustomClientCriteria(String categoryName, String colorCode, RuleCriteria rules) {
		super();
		this.categoryName = categoryName;
		this.colorCode = colorCode;
		this.rules = rules;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getColorCode() {
		return colorCode;
	}

	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}

	public RuleCriteria getRules() {
		return rules;
	}

	public void setRules(RuleCriteria rules) {
		this.rules = rules;
	}
}
