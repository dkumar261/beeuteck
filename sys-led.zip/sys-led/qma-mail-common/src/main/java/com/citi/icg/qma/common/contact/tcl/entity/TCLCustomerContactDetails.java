package com.citi.icg.qma.common.contact.tcl.entity;

public class TCLCustomerContactDetails {

	private String email;
	private TCLAssociatedFamilies[] associatedFamilies;
	public TCLCustomerContactDetails() {
		super();
		// Auto-generated constructor stub
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public TCLAssociatedFamilies[] getAssociatedFamilies() {
		return associatedFamilies;
	}
	public void setAssociatedFamilies(TCLAssociatedFamilies[] associatedFamilies) {
		this.associatedFamilies = associatedFamilies;
	}
	
}
