package com.citi.icg.qma.personal.exception;

public class ExchangeAuthenticationFailure extends Exception {


	private static final long serialVersionUID = 2846543383470653769L;

	/**
	 * @param message
	 * @param cause
	 */
	public ExchangeAuthenticationFailure(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public ExchangeAuthenticationFailure(String message) {
		super(message);
	}

}
