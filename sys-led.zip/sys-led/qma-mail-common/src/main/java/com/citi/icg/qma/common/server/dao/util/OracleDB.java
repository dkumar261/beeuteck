package com.citi.icg.qma.common.server.dao.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.encrypt.AesEncryptionUtil;

public class OracleDB
{
	
	private static final String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";
	private static Connection oracleDBConnection = null; 
	private static OracleDB INSTANCE = null;
	private static final Logger LOGGER = LoggerFactory.getLogger(OracleDB.class);
	private OracleDB(String env)
	{
		InputStream inputStream = null;
		try {
			Class.forName(ORACLE_DRIVER);
			if(StringUtils.isBlank(env)) {
				env = System.getProperty("icg.env");
			}
			String propFile = "oracledb-" + env + ".properties";
			LOGGER.info("Connecting from prop file:"+propFile);
			inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(propFile);
			Properties prop = new Properties();
			prop.load(inputStream);
			if(StringUtils.isNotEmpty(prop.getProperty("url")) 
					&& StringUtils.isNotEmpty(prop.getProperty("userName"))
					&& StringUtils.isNotEmpty(prop.getProperty("password"))) {
				String url = prop.getProperty("url");
				String userName = prop.getProperty("userName");
				String pwd =  AesEncryptionUtil.decrypt(prop.getProperty("password"));
				oracleDBConnection = DriverManager.getConnection(url,userName,pwd);
				if(oracleDBConnection!=null) {
					LOGGER.info("connection successful");
				}
			}else {
				LOGGER.info("Connection details missing in properties file:"+propFile);
				System.exit(0);
			}	
		}
		catch(Exception e) {
			LOGGER.error("Exception in getting Oracle DB connection:"+e);
			System.exit(0);
		}
	}
	
	public static synchronized OracleDB getInstance()//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
	{
		if (INSTANCE == null) {
			INSTANCE = new OracleDB(null);
		}
		return INSTANCE;
		
	}
	public static synchronized OracleDB getInstance(String env)//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
	{
		if (INSTANCE == null) {
			INSTANCE = new OracleDB(env);
		}
		return INSTANCE;
		
	}
	
	public Connection getConnection()
	{
		return oracleDBConnection;
	}
	
	
	public static void main(String[] args)
	{
		Connection conn=null;
		Statement statement=null;
		ResultSet resultSet=null;
		try
		{
			OracleDB ndb = OracleDB.getInstance();
			 conn = ndb.getConnection();
			 statement = conn.createStatement();
				String query = "select * from ACTIONSTATISTICS where userid='XXXXXX'";
				
				 resultSet = statement.executeQuery(query);
				
				while(resultSet.next())
				{
					String userName = resultSet.getString("username");
					String groupName = resultSet.getString("groupname");
					
					LOGGER.info("Result obtained with user name as "+userName+" and group name as "+groupName);
				}
			
			
			
		}
		catch (SQLException e)
		{
			LOGGER.info("Exception occurred "+e);
		}finally {
			if(null!=resultSet) {
				try {
					resultSet.close();
				} catch (SQLException e) {
					LOGGER.info("Exception occurred ",e);
				}
			}
			if(null!=statement) {
				try {
					statement.close();
				} catch (SQLException e) {
					LOGGER.info("Exception occurred ",e);
				}
			}
			if(null!=conn) {
				try {
					conn.close();
				} catch (SQLException e) {
					LOGGER.info("Exception occurred ",e);
				}
			}
				
		}
		
	}
	
	public void closeConnection()
	{
		try
		{
			if(oracleDBConnection!=null)
			{
				oracleDBConnection.close();
			}
		}
		catch(SQLException e)
		{
			LOGGER.info("Exception caught while closing the Netezza connection"+e);
		}
		
	}

}
