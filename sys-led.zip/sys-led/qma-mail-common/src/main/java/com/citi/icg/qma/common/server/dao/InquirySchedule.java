package com.citi.icg.qma.common.server.dao;

import java.util.Date;
import java.util.Map;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "InquirySchedule", noClassnameStored = true)
public class InquirySchedule {
	@Id
	private String id;
	private Map<String, ExecutionSchedule> schedules;
	private Date crtDate;
	private int noOfDaysInSingleBatchInDb;
	private int noOfBatchesIdentified;
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the schedules
	 */
	public Map<String, ExecutionSchedule> getSchedules() {
		return schedules;
	}
	/**
	 * @param schedule the schedule to set
	 */
	public void setSchedules(Map<String, ExecutionSchedule> schedules) {
		this.schedules = schedules;
	}
	/**
	 * @return the crtDate
	 */
	public Date getCrtDate() {
		return crtDate;
	}
	/**
	 * @param crtDate the crtDate to set
	 */
	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}
	/**
	 * @return the noOfDaysInSingleBatchInDb
	 */
	public int getNoOfDaysInSingleBatchInDb() {
		return noOfDaysInSingleBatchInDb;
	}
	/**
	 * @param noOfDaysInSingleBatchInDb the noOfDaysInSingleBatchInDb to set
	 */
	public void setNoOfDaysInSingleBatchInDb(int noOfDaysInSingleBatchInDb) {
		this.noOfDaysInSingleBatchInDb = noOfDaysInSingleBatchInDb;
	}
	/**
	 * @return the noOfBatchesIdentified
	 */
	public int getNoOfBatchesIdentified() {
		return noOfBatchesIdentified;
	}
	/**
	 * @param noOfBatchesIdentified the noOfBatchesIdentified to set
	 */
	public void setNoOfBatchesIdentified(int noOfBatchesIdentified) {
		this.noOfBatchesIdentified = noOfBatchesIdentified;
	}
	
	
	public static class ExecutionSchedule {
		private String scheduleName;
		private Date startDate;
		private Date endDate;
		private long timeTakenForExecutionInSec;
		private long noOfInquiryRecords;
		private long noOfInquiryWorkflowRecords;
		private long noOfInquiryWorkflowAuditRecords;
		
		/**
		 * @return the scheduleName
		 */
		public String getScheduleName() {
			return scheduleName;
		}
		/**
		 * @param scheduleName the scheduleName to set
		 */
		public void setScheduleName(String scheduleName) {
			this.scheduleName = scheduleName;
		}
		/**
		 * @return the startDate
		 */
		public Date getStartDate() {
			return startDate;
		}
		/**
		 * @param startDate the startDate to set
		 */
		public void setStartDate(Date startDate) {
			this.startDate = startDate;
		}
		/**
		 * @return the endDate
		 */
		public Date getEndDate() {
			return endDate;
		}
		/**
		 * @param endDate the endDate to set
		 */
		public void setEndDate(Date endDate) {
			this.endDate = endDate;
		}
		/**
		 * @return the timeTakenForExecutionInSec
		 */
		public long getTimeTakenForExecutionInSec() {
			return timeTakenForExecutionInSec;
		}
		/**
		 * @param timeTakenForExecutionInSec the timeTakenForExecutionInSec to set
		 */
		public void setTimeTakenForExecutionInSec(long timeTakenForExecutionInSec) {
			this.timeTakenForExecutionInSec = timeTakenForExecutionInSec;
		}
		/**
		 * @return the noOfInquiryRecords
		 */
		public long getNoOfInquiryRecords() {
			return noOfInquiryRecords;
		}
		/**
		 * @param noOfInquiryRecords the noOfInquiryRecords to set
		 */
		public void setNoOfInquiryRecords(long noOfInquiryRecords) {
			this.noOfInquiryRecords = noOfInquiryRecords;
		}
		/**
		 * @return the noOfInquiryWorkflowRecords
		 */
		public long getNoOfInquiryWorkflowRecords() {
			return noOfInquiryWorkflowRecords;
		}
		/**
		 * @param noOfInquiryWorkflowRecords the noOfInquiryWorkflowRecords to set
		 */
		public void setNoOfInquiryWorkflowRecords(long noOfInquiryWorkflowRecords) {
			this.noOfInquiryWorkflowRecords = noOfInquiryWorkflowRecords;
		}
		/**
		 * @return the noOfInquiryWorkflowAuditRecords
		 */
		public long getNoOfInquiryWorkflowAuditRecords() {
			return noOfInquiryWorkflowAuditRecords;
		}
		/**
		 * @param noOfInquiryWorkflowAuditRecords the noOfInquiryWorkflowAuditRecords to set
		 */
		public void setNoOfInquiryWorkflowAuditRecords(long noOfInquiryWorkflowAuditRecords) {
			this.noOfInquiryWorkflowAuditRecords = noOfInquiryWorkflowAuditRecords;
		}
	}
}
