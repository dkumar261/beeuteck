package com.citi.icg.qma.common.core.subscriber.mails.entity;

import com.citi.icg.qma.common.core.util.MailUtil;

public class Subject
{
	private static final String INQUIRY = "Inquiry Id:";
	private static final String EMPTY_SUBJECT = "Inquiry From : ";

	private boolean plain;
	private String originalSubject;
	private String threadTopic;
	private int inquiryId;

	

	public boolean isPlain()
	{
		return plain;
	}

	public String format(boolean reply)
	{
		String subject = null;
		if (reply)
		{
			subject = "RE: " + threadTopic;
		}
		else
		{
			subject = threadTopic;
		}
		subject = subject + " " + INQUIRY + inquiryId;

		return subject;
	}

	public static Subject parse(String threadTopic, String subjectStr, String from)
	{
		Subject subject = new Subject();
		String subStr = MailUtil.getUTFEncodedString(subjectStr);// Sonar Fix -- Method parameters, caught exceptions and foreach variables should not be reassigned
		if (subStr == null || subStr.trim().length() == 0)
		{
			subStr = EMPTY_SUBJECT + from;
		}

		if (subStr.indexOf(INQUIRY) != -1)
		{
			subject.plain = false;
			// parse inquiryId out
		}
		subject.originalSubject = subStr;
		subject.threadTopic = threadTopic;

		return subject;
	}

	public String getOriginalSubject()
	{
		return originalSubject;
	}

	public String getThreadTopic()
	{
		return threadTopic;
	}

	public int getInquiryId()
	{
		return inquiryId;
	}

	@Override
	public String toString()
	{
		return "Subject [plain=" + plain + ", originalSubject=" + originalSubject + ", threadTopic=" + threadTopic + ", inquiryId="
				+ inquiryId + "]";
	}

	//for kryo

	public Subject()
	{
		plain = true;
	}

	public static String getInquiry() {
		return INQUIRY;
	}

	public static String getEmptySubject() {
		return EMPTY_SUBJECT;
	}

	public void setPlain(boolean plain) {
		this.plain = plain;
	}

	public void setOriginalSubject(String originalSubject) {
		this.originalSubject = originalSubject;
	}

	public void setThreadTopic(String threadTopic) {
		this.threadTopic = threadTopic;
	}

	public void setInquiryId(int inquiryId) {
		this.inquiryId = inquiryId;
	}

}
