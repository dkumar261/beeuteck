package com.citi.icg.qma.common.core.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.*;
import java.util.Map.Entry;
import java.util.logging.Level;

import jakarta.activation.DataHandler;
import jakarta.activation.FileDataSource;
import jakarta.mail.*;
import jakarta.mail.internet.AddressException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;

import com.citi.icg.qma.common.auth.OAuth2TokenGenerator;
import com.citi.icg.qma.config.QmaMailConfigLoader;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.Group;

/**
 * Utility class to send email notifications.
 */
public class EmailUtil//removed the extends as MailUtil is having private constructor...
{

	/*Added character set */
	private static final String MIME_TEXT_PLAIN_CHAR_ENCODING = "text/plain; charset=UTF-8";
	private static final String MIME_TEXT_HTML_CHAR_ENCODING = "text/html; charset=UTF-8";
	private static final String MIME_TEXT_PLAIN = "text/plain";
	private static final String MIME_TEXT_HTML = "text/html";
	private static final String UTF8_ENCODING = "utf-8";
	
	//Sonar Fix remove unused varaible
	private static final String MIME_BINARY_MULTIPART = "application/octet-stream";

	/** Port. */
	private static final Integer PORT = Integer.valueOf(25);


	/**  Sentrion Relay Address **/
	private static final String AUDIT_RELAY_ADDR_KEY = "auditRelayAddr";
	
	private static final String SUCCESS_KEY ="SUCCESS";
	
	private static final String QMA_ICG_ENV="icg.env";

	private static final Logger logger = LoggerFactory.getLogger(EmailUtil.class);//Sonar Fix -- Standard outputs should not be used directly to log anything

	private  EmailUtil()
	{
		//Sonar fix - to hide the class having all methods and variables as static
	}

	/**
    * @deprecated
    */
	@Deprecated// Sonar Fix -- Add deprecated tag
	public static void sendEMail(InternetAddress fromAddress, String[] recipentsTo, String[] recipentsCc,
			String[] recipentsBcc, String from, String subject, String message,
			boolean htmlFormat, File attachment, boolean enableCharacterEncoding)
	{
		logger.info("Inside My sendemail********************");

		String fromMailBox = QmaMailConfigLoader.getConfig().getMBOX();
		if (null != fromMailBox) {
			logger.info("MBOX retrieved successfully");
		}
		Session session = MailCommonUtil.getSession(fromMailBox);

		InternetAddress[] addressTo = recipentsTo == null ? null
				: new InternetAddress[recipentsTo.length];//Sonar Fix - remove useless parenthesis
		InternetAddress[] addressCc = recipentsCc == null ? null
				: new InternetAddress[recipentsCc.length];//Sonar Fix - remove useless parenthesis
		InternetAddress[] addressBcc = recipentsBcc == null ? null
				: new InternetAddress[recipentsBcc.length];//Sonar Fix - remove useless parenthesis

		try
		{
			if(null != addressTo) {
				for (int i = 0; i < addressTo.length; i++)
				{
					addressTo[i] = new InternetAddress(recipentsTo[i]);
				}
			}
			

			if (addressCc != null)
			{
				for (int i = 0; i < addressCc.length; i++)
				{
					addressCc[i] = new InternetAddress(recipentsCc[i]);
				}
			}

			if (addressBcc != null)
			{
				for (int i = 0; i < addressBcc.length; i++)
				{
					addressBcc[i] = new InternetAddress(recipentsBcc[i]);
				}
			}

			Message msg = new MimeMessage(session);
			if (null != fromAddress) {
				msg.setFrom(fromAddress);
			} else {
				msg.setFrom(new InternetAddress(from));
			}

			msg.setRecipients(Message.RecipientType.TO, addressTo);
			if (addressCc != null)
			{
				msg.addRecipients(Message.RecipientType.CC, addressCc);
			}
			if (addressBcc != null)
			{
				msg.addRecipients(Message.RecipientType.BCC, addressBcc);
			}

			msg.setSubject(subject);
			msg.setSentDate(new Date());

			String messageMime = "";
			if(htmlFormat){
				if( enableCharacterEncoding){
					messageMime = MIME_TEXT_HTML_CHAR_ENCODING;
				} else {
					messageMime = MIME_TEXT_HTML;
				}
			} else {
				if( enableCharacterEncoding){
					messageMime = MIME_TEXT_PLAIN_CHAR_ENCODING;
				} else {
					messageMime = MIME_TEXT_PLAIN;
				}
			}
			
			
			if (attachment != null)
			{
				Multipart multipart = new MimeMultipart();
				if (message != null)
				{
					MimeBodyPart messageBodyPart = new MimeBodyPart();
					msg.setContent(message, messageMime);
					if(enableCharacterEncoding){
						messageBodyPart.setText(message,UTF8_ENCODING);
					} else {
						messageBodyPart.setText(message);
					}
					
					multipart.addBodyPart(messageBodyPart);
				}
				FileDataSource source = new FileDataSource(attachment)
				{
					@Override
					public String getContentType()
					{
						return MIME_BINARY_MULTIPART;
					}
				};
				MimeBodyPart attachmentBodyPart = new MimeBodyPart();
				attachmentBodyPart.setFileName(attachment.getName());
				attachmentBodyPart.setDataHandler(new DataHandler(source));
				multipart.addBodyPart(attachmentBodyPart);
				msg.setContent(multipart);
			}
			else
			{
				msg.setContent(message, messageMime);
			}
			logger.info("Before sending message");

			Transport.send(msg);
			logger.info("Message sent successfully");
		}
		catch (Exception mex)
		{
			//Sonar Fix -- Throwable.printStackTrace(...) should not be called
			logger.error(mex.getMessage(), mex);
		}
	}

	/**
	 * @return
	 */
	private static String getEmailHost() {
		String hostEnv = System.getProperty("host.env");
		String host = "localhost";
		if(hostEnv != null && (hostEnv.equalsIgnoreCase("container"))) {
			host = "XXXXX";
		}
		return host;
	}

	

	/**
	 * @deprecated
	 */
	@Deprecated// Sonar Fix -- Add deprecated tag...//Sonar fix -- type of object passed should be interface
	public static void sendMailWithMultipleFileAttachments(
                  List<String> recipentsTo, List<String> recipentsCc,
                  List<String> recipentsBcc, String from, String subject,
                  String message,										//Sonar fix - remove the unused parameter
                  Map<File, String> fileMap, Map<String, File> inlineFileMap, String references,
                  String fromUserName, boolean highImportance, final boolean isContentTypeJpeg, boolean enableCharacterEncoding) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
    {
           
           boolean isBbase64Encoding=false;
           
           sendMailWithMultipleFileAttachments(recipentsTo, recipentsCc, recipentsBcc, from, subject, message, fileMap, inlineFileMap, references, fromUserName, highImportance, isBbase64Encoding,false, isContentTypeJpeg,enableCharacterEncoding,null);
    }

	public static void sendMailWithMultipleFileAttachments(
			List<String> recipentsTo, List<String> recipentsCc,
			List<String> recipentsBcc, String from, String subject,
			String message,											//Sonar fix - remove the unused parameter
			Map<File, String> fileMap, Map<String, File> inlineFileMap, String references,
			String fromUserName, boolean highImportance, boolean isBbase64Encoding,boolean enableOnBehalfOf, final boolean isContentTypeJpeg,boolean enableCharacterEncoding, boolean cleanUpMailImgAttachments,Map<String, String> emailPropertiesMap) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		InternetAddress[] addressTo = recipentsTo == null ? null
				: new InternetAddress[recipentsTo.size()];//Sonar Fix - remove useless parenthesis
		InternetAddress[] addressCc = recipentsCc == null ? null
				: new InternetAddress[recipentsCc.size()];//Sonar Fix - remove useless parenthesis
		InternetAddress[] addressBcc = recipentsBcc == null ? null
				: new InternetAddress[recipentsBcc.size()];//Sonar Fix - remove useless parenthesis

		// Set Reply Now.
		InternetAddress[] toReply;
		InternetAddress fromAddr;
		try
		{
			if(addressTo != null && addressTo.length > 0)
			{
				for (int i = 0; i < addressTo.length; i++)
				{
					addressTo[i] = new InternetAddress(recipentsTo.get(i));
				}
			}

			if (addressCc != null && addressCc.length > 0)
			{
				for (int i = 0; i < addressCc.length; i++)
				{
					addressCc[i] = new InternetAddress(recipentsCc.get(i));
				}
			}

			if (addressBcc != null && addressBcc.length > 0)
			{
				for (int i = 0; i < addressBcc.length; i++)
				{
					addressBcc[i] = new InternetAddress(recipentsBcc.get(i));
				}
			}
			//Sonar Fix - remove unused private variables
			fromAddr = new InternetAddress(from);
			toReply = new InternetAddress[1];
			// Adding From DisplayName, needed for Xstream UI for Reply
			// This below code is used for replyTo functionality in external client.
			//Currently It will be enabled only when onbehalfof is switched off.
			toReply[0] = new InternetAddress(from);
		}
		catch (Exception e)
		{
			throw new CommunicatorException("Error in EmailUtil.sendMailWithMultipleFileAttachments method()" , e);
		}
		sendMailWithMultipleFileAttachments(addressTo, addressCc, addressBcc, fromAddr,subject, message, fileMap, inlineFileMap, references, fromUserName, highImportance, isBbase64Encoding,enableOnBehalfOf, toReply,isContentTypeJpeg,enableCharacterEncoding, cleanUpMailImgAttachments,null);
		
	}
	
	public static void sendMailWithMultipleFileAttachments(List<String> recipentsTo, List<String> recipentsCc, List<String> recipentsBcc, String from, String subject, String message,											//Sonar fix - remove the unused parameter
			Map<File, String> fileMap, Map<String, File> inlineFileMap, String references,
			String fromUserName, boolean highImportance, boolean isBbase64Encoding,boolean enableOnBehalfOf, final boolean isContentTypeJpeg,boolean enableCharacterEncoding,Map<String, String> emailPropertiesMap) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		sendMailWithMultipleFileAttachments(recipentsTo, recipentsCc, recipentsBcc, from, subject, message, fileMap, inlineFileMap, references, fromUserName, highImportance, isBbase64Encoding, enableOnBehalfOf, isContentTypeJpeg, enableCharacterEncoding, true,emailPropertiesMap);
	}
	
	public static void sendQMAGroupEmail(
			List<InternetAddress> recipentsTo, List<InternetAddress> recipentsCc,
			List<InternetAddress> recipentsBcc, InternetAddress from, String subject,
			String message,
			Map<File, String> fileMap, Map<String, File> inlineFileMap, String references,
			String fromUserName, boolean highImportance, boolean isBbase64Encoding,boolean enableOnBehalfOf, boolean isContentTypeJpeg,boolean enableCharacterEncoding,Map<String, String> emailPropertiesMap) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one ..also remove useless parameter
	{
		InternetAddress[] addressTo = recipentsTo == null ? new InternetAddress[0]
				: recipentsTo.toArray(new InternetAddress[0]);//Sonar Fix - remove useless parenthesis
		InternetAddress[] addressCc = recipentsCc == null ? new InternetAddress[0]
				: recipentsCc.toArray(new InternetAddress[0]);//Sonar Fix - remove useless parenthesis
		InternetAddress[] addressBcc = recipentsBcc == null ? new InternetAddress[0]
				: recipentsBcc.toArray(new InternetAddress[0]);//Sonar Fix - remove useless parenthesis
		// Set Reply Now.
		InternetAddress[] toReply = new InternetAddress[1];
		// Adding From DisplayName, needed for Xstream UI for Reply
		// This below code is used for replyTo functionality in external client.
		//Currently It will be enabled only when onbehalfof is switched off.
		try
		{
			toReply[0] = new InternetAddress(from.getAddress(), from.getPersonal());
		}
		catch (Exception e)
		{
			throw new CommunicatorException("Error in EmailUtil.sendMailWithMultipleFileAttachments method()e" , e);
		}
		sendEmailFromQMAWithAttachments(addressTo, addressCc, addressBcc, from, subject, message, fileMap, inlineFileMap, references, fromUserName, highImportance, isBbase64Encoding, enableOnBehalfOf, toReply, isContentTypeJpeg, enableCharacterEncoding, true,emailPropertiesMap);
		}
	public static void sendMailWithMultipleFileAttachments(
			List<InternetAddress> recipentsTo, List<InternetAddress> recipentsCc,
			List<InternetAddress> recipentsBcc, InternetAddress from, String subject,
			String message,
			Map<File, String> fileMap, Map<String, File> inlineFileMap, String references,
			String fromUserName, boolean highImportance, boolean isBbase64Encoding,boolean enableOnBehalfOf, boolean isContentTypeJpeg,boolean enableCharacterEncoding,Map<String, String> emailPropertiesMap) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one ..also remove useless parameter
	{
		InternetAddress[] addressTo = recipentsTo == null ? new InternetAddress[0]
				: recipentsTo.toArray(new InternetAddress[0]);//Sonar Fix - remove useless parenthesis
		InternetAddress[] addressCc = recipentsCc == null ? new InternetAddress[0]
				: recipentsCc.toArray(new InternetAddress[0]);//Sonar Fix - remove useless parenthesis
		InternetAddress[] addressBcc = recipentsBcc == null ? new InternetAddress[0]
				: recipentsBcc.toArray(new InternetAddress[0]);//Sonar Fix - remove useless parenthesis
		// Set Reply Now.
		InternetAddress[] toReply = new InternetAddress[1];
		// Adding From DisplayName, needed for Xstream UI for Reply
		// This below code is used for replyTo functionality in external client.
		//Currently It will be enabled only when onbehalfof is switched off.
		try
		{
			toReply[0] = new InternetAddress(from.getAddress(), from.getPersonal());
		}
		catch (Exception e)
		{
			throw new CommunicatorException("Error in EmailUtil.sendMailWithMultipleFileAttachments method()e" , e);
		}
		sendMailWithMultipleFileAttachments(addressTo, addressCc, addressBcc, from, subject, message, fileMap, inlineFileMap, references, fromUserName, highImportance, isBbase64Encoding, enableOnBehalfOf,toReply, isContentTypeJpeg,enableCharacterEncoding, true,emailPropertiesMap);
		}
	
	public static String sendEmail(String message, Throwable ex)
	{
		MailUtil.notifySupport(Level.INFO, "XMWorkstationServices", message,
				ex);
		return SUCCESS_KEY;
	}

	public static String sendEmail(String message)
	{
		MailUtil.notifySupport(Level.INFO, "XMWorkstationServices", message);
		return SUCCESS_KEY;
	}
	public static String sendEmailToSupport(InternetAddress from, String subject, String message, String supportEmail, Throwable ex)
	{
		logger.info("Inside sendEmail to Support util ############################################");
		String[] recipents = new String[] { supportEmail };

		String envSubStr =  Level.INFO + " ,"+ StringUtils.upperCase(Environment.getEnvironment()) + ", " + subject;

		StringBuilder envMessage = new StringBuilder();
		envMessage.append(message);
		
		if (ex != null)
		{
			envMessage.append("\nCause: " + ex.getCause());
			envMessage.append("\nMessage: " + ex.getLocalizedMessage());
				}
		

		sendEMail(from, recipents, null,null, supportEmail, envSubStr, envMessage.toString(),true, null,false);
			
		return SUCCESS_KEY;
	}
	
	public static void sendMailWithMultipleFileAttachments(
			InternetAddress[] addressTo, InternetAddress[] addressCc,
			InternetAddress[] addressBcc, InternetAddress from, String subject,//Sonar Fix remove unused parameter
			String message,
			//boolean htmlFormat,
			Map<File, String> fileMap, Map<String, File> inlineFileMap, String references,
			String fromUserName, boolean highImportance, boolean isBbase64Encoding, boolean enableOnBehalfOf,InternetAddress[] toReply, final boolean isContentTypeJpeg, final boolean enableCharacterEncoding, boolean cleanUpMailImgAttachments,Map<String, String> emailPropertiesMap) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		sendMailFromQMA(addressTo, addressCc, addressBcc, from, subject, message, fileMap, inlineFileMap, references, fromUserName, highImportance, isBbase64Encoding, enableOnBehalfOf, toReply, isContentTypeJpeg, enableCharacterEncoding, cleanUpMailImgAttachments
				,false,emailPropertiesMap);
	}
	
	public static void sendEmailFromQMAWithAttachments(
			InternetAddress[] addressTo, InternetAddress[] addressCc,
			InternetAddress[] addressBcc, InternetAddress from, String subject,//Sonar Fix remove unused parameter
			String message,
			//boolean htmlFormat,
			Map<File, String> fileMap, Map<String, File> inlineFileMap, String references,
			String fromUserName, boolean highImportance, boolean isBbase64Encoding, boolean enableOnBehalfOf,InternetAddress[] toReply, final boolean isContentTypeJpeg, final boolean enableCharacterEncoding, boolean cleanUpMailImgAttachments,Map<String,String> emailPropertiesMap) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		sendMailFromQMA(addressTo, addressCc, addressBcc, from, subject, message, fileMap, inlineFileMap, references, fromUserName, highImportance, isBbase64Encoding, enableOnBehalfOf, toReply, isContentTypeJpeg, enableCharacterEncoding, cleanUpMailImgAttachments
				,true,emailPropertiesMap);
	}
	
	private static void sendMailFromQMA(
			InternetAddress[] addressTo, InternetAddress[] addressCc,
			InternetAddress[] addressBcc, InternetAddress from, String subject,//Sonar Fix remove unused parameter
			String message,
			//boolean htmlFormat,
			Map<File, String> fileMap, Map<String, File> inlineFileMap, String references,
			String fromUserName, boolean highImportance, boolean isBbase64Encoding, boolean enableOnBehalfOf,InternetAddress[] toReply, final boolean isContentTypeJpeg, final boolean enableCharacterEncoding, boolean cleanUpMailImgAttachments
			,boolean groupEmailFrom,Map<String,String> emailPropertiesMap
			) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{

		String fromMailBox = QmaMailConfigLoader.getConfig().getMBOX();
		if (null != fromMailBox) {
			logger.info("MBOX retrieved successfully");
		}
		Session session = MailCommonUtil.getSession(fromMailBox);

		try
		{
			Message msg = new MimeMessage(session);
			
			if (groupEmailFrom) {
				msg.addHeader("Sender", from.getAddress());
				msg.addHeader("From", from.getAddress());
			} else {
				if (enableOnBehalfOf) {
					msg.setFrom(from);
					msg.addHeader("Sender", fromUserName);
					msg.addHeader("From", from.getAddress());
				} else {
					msg.setFrom(from);
					msg.setReplyTo(toReply);
				}
			}
			
			if (highImportance)
			{
				msg.setHeader("X-Priority", "1");
			}

			if(addressTo != null && addressTo.length > 0)
			{
				msg.setRecipients(Message.RecipientType.TO, addressTo);
			}
			
			if (addressCc != null && addressCc.length > 0)
			{
			
				msg.addRecipients(Message.RecipientType.CC, addressCc);
			}
			if (addressBcc != null && addressBcc.length > 0)
			{
				msg.addRecipients(Message.RecipientType.BCC, addressBcc);
			}
			logger.info("{} Email subject: {};",EmailUtil.class,subject);
			msg.setSubject(subject);
			msg.setSentDate(new Date());

			msg.setHeader("References", references);


			//Sonar Fix remove unused variable// htmlFormat ? MIME_TEXT_HTML :
												
				Multipart multipart = new MimeMultipart("related");
				if (message != null)
				{
					MimeBodyPart messageBodyPart = new MimeBodyPart();
					if(enableCharacterEncoding){
						messageBodyPart.setContent(message, MIME_TEXT_HTML_CHAR_ENCODING);
					} else {
						messageBodyPart.setContent(message, MIME_TEXT_HTML);
					}
					multipart.addBodyPart(messageBodyPart);
					
					//Sonar fix - remove the useless assignements
					
					for (Entry<String, File> entry : inlineFileMap.entrySet())
					{
						MimeBodyPart messageINLINEAttachmentBodyPart = new MimeBodyPart();
						String fileName = entry.getKey();
						File file = entry.getValue();
						FileDataSource source = new FileDataSource(file)
						{
							@Override
							public String getContentType()
							{
								if (isContentTypeJpeg)
								{
									logger.info(" Email Util InLine Attachement processing-Content Type set to image/jpeg");
									return "image/jpeg";
								}
								else
								{
									if(enableCharacterEncoding){
										return MIME_TEXT_HTML_CHAR_ENCODING;
									} else {
										return MIME_TEXT_HTML;
									}
									
								}
								

							}
						};
						messageINLINEAttachmentBodyPart.setFileName(fileName);
						messageINLINEAttachmentBodyPart
								.setDataHandler(new DataHandler(source));
						messageINLINEAttachmentBodyPart.setHeader("Content-ID",	"<"+fileName+">" );
						messageINLINEAttachmentBodyPart.setDisposition(Part.INLINE);
						multipart.addBodyPart(messageINLINEAttachmentBodyPart);
					}
					
				}
				Set<Entry<File, String>> st = fileMap.entrySet();
				for (Entry<File, String> attachment : st)
				{
					String fileName = attachment.getValue();
					File file = attachment.getKey();
					FileDataSource source = new FileDataSource(file)
					{
						@Override
						public String getContentType()
						{
							if(enableCharacterEncoding){
								return MIME_TEXT_HTML_CHAR_ENCODING;
							} else {
								return MIME_TEXT_HTML;
							}
						}
					};
					MimeBodyPart attachmentBodyPart = new MimeBodyPart();
					attachmentBodyPart.setFileName(fileName);
					attachmentBodyPart.setDataHandler(new DataHandler(source));
					attachmentBodyPart.setDisposition(Part.ATTACHMENT);
					
					if(isBbase64Encoding && fileName!=null && fileName.toUpperCase().endsWith(".PDF"))
					{
						attachmentBodyPart.setHeader("Content-Transfer-Encoding", "base64");
						attachmentBodyPart.setHeader("Content-type", "application/pdf; charset=utf-8");
					}
					
					multipart.addBodyPart(attachmentBodyPart);

				}
				
				msg.setContent(multipart);

			// Send the regular message
			

			boolean sendEmail=true;
			if(emailPropertiesMap != null){
				logger.info("Inside emailPropertiesMap");
				String env=System.getProperty(QMA_ICG_ENV);
				String relayOnly = emailPropertiesMap.get("isRelayOnly");
				Boolean isEmailAuditRequired = "Y".equals(emailPropertiesMap.get("isEmailAuditRequired"));
				if(isEmailAuditRequired && "Y".equalsIgnoreCase(relayOnly) && StringUtils.isNotBlank(env)  &&
						(env.toLowerCase().contains("dev") || env.toLowerCase().contains("uat"))){
					String relayAddress = emailPropertiesMap.get(AUDIT_RELAY_ADDR_KEY);
					logger.info("Email is blocked to send outside firm but relayed to address [{}]",relayAddress	);
					InternetAddress[] ccExtEmailCatch = new InternetAddress[1];
					// Automatically CC recipient to view inside QMA queue
					ccExtEmailCatch[0] = new InternetAddress(relayAddress, relayAddress);
					msg.addRecipients(Message.RecipientType.CC, ccExtEmailCatch);
					sendEmail=false;
				}
			}
			
			if (sendEmail) {
				logger.info("message size before sending: {}",msg.getSize());
				Transport.send(msg);
				logger.info("Message sent successfully");
			}
			
			relayEmailFeed(subject, emailPropertiesMap, msg);

		}
		catch (Exception mex)
		{
			throw new CommunicatorException("Issue in sending email", mex);//Sonar Fix -- define and throw dedicated Exception
		}
		finally
		{
			if (cleanUpMailImgAttachments)
			{
				cleanUpAttachedEmailFiles(fileMap);
				cleanUpEmailLocalFiles(inlineFileMap);
			}

		}
	}
	
	/**
	 * @param references
	 * @param isNewInquiry
	 * @param fromGroup
	 * @param inlineFileMap
	 * @param toListAddress
	 * @param finalContent
	 * @param subject
	 * @param fileMap
	 * @param charEncodingFlag
	 * @throws CommunicatorException
	 * @throws AddressException
	 * @throws UnsupportedEncodingException
	 */
	public static void sendEmailFromQMAGroup(String references, boolean isNewInquiry, Group fromGroup,
			LinkedHashMap<String, File> inlineFileMap, List<String> toListAddress, String finalContent, String subject,
			LinkedHashMap<File, String> fileMap, boolean charEncodingFlag)
			throws CommunicatorException, AddressException, UnsupportedEncodingException {
		logger.info("Start Method EmailUtil.sendEmailFromQMAGroup :: {}, {}, {}",isNewInquiry, subject, references);
		logger.info("sendEmailFromQMAGroup :: toListAddress:{}, from:{}",toListAddress, fromGroup.getGroupEmail());
				
		InternetAddress[] addressTo = toListAddress == null ? null : new InternetAddress[toListAddress.size()];
		
		if(addressTo != null && addressTo.length > 0) {
			for (int i = 0; i < addressTo.length; i++) {
				logger.info("sendMailWithMultipleFileAttachments :: recipentsTo :: {}",toListAddress.get(i));
				addressTo[i] = new InternetAddress(toListAddress.get(i));
			}
		}
		
		InternetAddress fromIA = new InternetAddress(fromGroup.getGroupEmail(), fromGroup.getGroupName());
		InternetAddress[] toReplyIA = new InternetAddress[1];
		toReplyIA[0] = new InternetAddress(fromGroup.getGroupEmail(), fromGroup.getGroupName());
		
		sendAutoResponseFromQMA(addressTo, null, null, fromIA, subject, finalContent, fileMap, inlineFileMap, references, fromGroup.getGroupName(),
				false, true, false, toReplyIA, true, charEncodingFlag, false,true,null);
		logger.info("End Method EmailUtil.sendEmailFromQMAGroup :: {}, {}, {}",isNewInquiry, subject, references);
	}
	
	private static void sendAutoResponseFromQMA(InternetAddress[] addressTo, InternetAddress[] addressCc,
			InternetAddress[] addressBcc, InternetAddress from, String subject, // Sonar Fix remove unused parameter
			String message, Map<File, String> fileMap, Map<String, File> inlineFileMap, String references,
			String fromUserName, boolean highImportance, boolean isBbase64Encoding, boolean enableOnBehalfOf,
			InternetAddress[] toReply, final boolean isContentTypeJpeg, final boolean enableCharacterEncoding,
			boolean cleanUpMailImgAttachments, boolean groupEmailFrom, Map<String, String> emailPropertiesMap)
			throws CommunicatorException { // Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
		logger.info("Inside sendAutoResponseFromQMA()");
		String fromMailBox = QmaMailConfigLoader.getConfig().getMBOX();
		if (null != fromMailBox) {
			logger.info("MBOX retrieved successfully");
		}
		Session session = MailCommonUtil.getSession(fromMailBox);

		try {
			Message msg = new MimeMessage(session);
			logger.info("sendAutoResponseFromQMA groupEmailFrom :: {}, {}, {}", groupEmailFrom, from.getPersonal(),
					from.getAddress());
			if (groupEmailFrom) {
				msg.setFrom(from);
				msg.setReplyTo(toReply);
			} else {
				if (enableOnBehalfOf) {
					msg.setFrom(from);
					msg.addHeader("Sender", fromUserName);
					msg.addHeader("From", from.getAddress());
				} else {
					msg.setFrom(new InternetAddress(fromUserName));
					msg.setReplyTo(toReply);
				}
			}

			if (highImportance) {
				msg.setHeader("X-Priority", "1");
			}

			if (addressTo != null && addressTo.length > 0) {
				msg.setRecipients(Message.RecipientType.TO, addressTo);
			}

			if (addressCc != null && addressCc.length > 0) {

				msg.addRecipients(Message.RecipientType.CC, addressCc);
			}
			if (addressBcc != null && addressBcc.length > 0) {
				msg.addRecipients(Message.RecipientType.BCC, addressBcc);
			}
			logger.info("{} Email subject: {};", EmailUtil.class, subject);
			msg.setSubject(subject);
			msg.setSentDate(new Date());

			msg.setHeader("References", references);

			// Sonar Fix remove unused variable// htmlFormat ? MIME_TEXT_HTML :

			Multipart multipart = new MimeMultipart("related");
			if (message != null) {
				MimeBodyPart messageBodyPart = new MimeBodyPart();
				if (enableCharacterEncoding) {
					messageBodyPart.setContent(message, MIME_TEXT_HTML_CHAR_ENCODING);
				} else {
					messageBodyPart.setContent(message, MIME_TEXT_HTML);
				}
				multipart.addBodyPart(messageBodyPart);

				// Sonar fix - remove the useless assignements

				for (Entry<String, File> entry : inlineFileMap.entrySet()) {
					MimeBodyPart messageINLINEAttachmentBodyPart = new MimeBodyPart();
					String fileName = entry.getKey();
					File file = entry.getValue();
					FileDataSource source = new FileDataSource(file) {
						@Override
						public String getContentType() {
							if (isContentTypeJpeg) {
								logger.info(" Email Util InLine Attachement processing-Content Type set to image/jpeg");
								return "image/jpeg";
							} else {
								if (enableCharacterEncoding) {
									return MIME_TEXT_HTML_CHAR_ENCODING;
								} else {
									return MIME_TEXT_HTML;
								}

							}

						}
					};
					messageINLINEAttachmentBodyPart.setFileName(fileName);
					messageINLINEAttachmentBodyPart.setDataHandler(new DataHandler(source));
					messageINLINEAttachmentBodyPart.setHeader("Content-ID", "<" + fileName + ">");
					messageINLINEAttachmentBodyPart.setDisposition(Part.INLINE);
					multipart.addBodyPart(messageINLINEAttachmentBodyPart);
				}

			}
			Set<Entry<File, String>> st = fileMap.entrySet();
			for (Entry<File, String> attachment : st) {
				String fileName = attachment.getValue();
				File file = attachment.getKey();
				FileDataSource source = new FileDataSource(file) {
					@Override
					public String getContentType() {
						if (enableCharacterEncoding) {
							return MIME_TEXT_HTML_CHAR_ENCODING;
						} else {
							return MIME_TEXT_HTML;
						}
					}
				};
				MimeBodyPart attachmentBodyPart = new MimeBodyPart();
				attachmentBodyPart.setFileName(fileName);
				attachmentBodyPart.setDataHandler(new DataHandler(source));
				attachmentBodyPart.setDisposition(Part.ATTACHMENT);
				// Sunil/Sumanth- we cannot do decoding of file, as it will, it not be
				// applicable to other files encoded/ unencoded.
				// SUNIL: may 9th 2018: base64 is enable in our app all the time now, fixing pdf
				// issue, where it says it is corrupted.
				if (isBbase64Encoding && fileName != null && fileName.toUpperCase().endsWith(".PDF")) {
					attachmentBodyPart.setHeader("Content-Transfer-Encoding", "base64");
					attachmentBodyPart.setHeader("Content-type", "application/pdf; charset=utf-8");
				}

				multipart.addBodyPart(attachmentBodyPart);

			}

			msg.setContent(multipart);

			// Send the regular message

			boolean sendEmail = true;
			if (emailPropertiesMap != null) {
				logger.info("Inside emailPropertiesMap not null");
				String env = System.getProperty(QMA_ICG_ENV);
				String relayOnly = emailPropertiesMap.get("isRelayOnly");
				Boolean isEmailAuditRequired = "Y".equals(emailPropertiesMap.get("isEmailAuditRequired"));
				if (isEmailAuditRequired && "Y".equalsIgnoreCase(relayOnly) && StringUtils.isNotBlank(env)
						&& (env.toLowerCase().contains("dev") || env.toLowerCase().contains("uat"))) {
					String relayAddress = emailPropertiesMap.get(AUDIT_RELAY_ADDR_KEY);
					logger.info("Email is blocked to send outside firm but relayed to address [{}]", relayAddress);
					InternetAddress[] ccExtEmailCatch = new InternetAddress[1];
					// Automatically CC recipient to view inside QMA queue
					ccExtEmailCatch[0] = new InternetAddress(relayAddress, relayAddress);
					msg.addRecipients(Message.RecipientType.CC, ccExtEmailCatch);
					sendEmail = false;
				}
			}
			logger.info("sendEmail: {}", sendEmail);
			if (sendEmail) {
				logger.info("message size before sending: {}", msg.getSize());
				Transport.send(msg);
				logger.info("Message sent successfully");
			}

			relayEmailFeed(subject, emailPropertiesMap, msg);

		} catch (Exception mex) {
			throw new CommunicatorException("Issue in sending email", mex);// Sonar Fix -- define and throw dedicated
																			// Exception
		} finally {
			if (cleanUpMailImgAttachments) {
				cleanUpAttachedEmailFiles(fileMap);
				cleanUpEmailLocalFiles(inlineFileMap);
			}

		}
	}

	private static void relayEmailFeed(String subject, Map<String, String> emailPropertiesMap, Message msg) {
		try {
			if (emailPropertiesMap != null) {
				String relayAddress = emailPropertiesMap.get(AUDIT_RELAY_ADDR_KEY);
				Boolean isEmailAuditRequired = "Y".equals(emailPropertiesMap.get("isEmailAuditRequired"));
				logger.info("Inside Relaying feed with isEmailAuditRequired : {} , env : {} , relayAddress : {}",isEmailAuditRequired,System.getProperty(QMA_ICG_ENV), relayAddress);
				// relay to sentrion
				if (isEmailAuditRequired && StringUtils.isNotBlank(relayAddress)) {
					// Construct the message - add headers required by
					// Orchestria:
					msg.setHeader("X-ORCH-Network", "QMA Email Tracker");
					msg.setHeader("X-ORCH-MessageType", "Email");
					msg.setHeader("x-sender", (StringUtils.isNotBlank(emailPropertiesMap.get("auditRelaySender")))?emailPropertiesMap.get(AUDIT_RELAY_ADDR_KEY):"XXXXX");

					msg.setHeader("x-receiver", relayAddress);
					Transport.send(msg, InternetAddress.parse(relayAddress, false));
					logger.info("[{}] Relaying feed Completed  to realyAddr : [{}] for Email subject: {};",System.getProperty(QMA_ICG_ENV),relayAddress,subject);

				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}
	
	public static void saveAuditEMLMessage(Message message) 
	{
		FileOutputStream fos=null;
		try{
			logger.info("Inside email auditing for subject: {};",message.getSubject());
		String path = System.getProperty("user.dir");
		Date dt = new Date();
		String name = path +"/FAILED_MESSAGES/"+"AUD_" +Math.random()+"_"+message.getMessageNumber() +".eml";
		File file = new File(name);
		fos = new FileOutputStream(file);
		//save email which has to be audited issues:
		message.writeTo(fos);
		fos.close();
		logger.info("Completed email auditing with {}",name);
		}catch (Exception mex)
		{
			logger.error(mex.getMessage(), mex);
		}finally{
			try{
			if(fos!=null)
				fos.close();
			}catch (Exception mex)
			{
				logger.error("Closing File writer "+mex.getMessage(), mex);
			}
		}
	}
	
	//Method delete files from local desk after the email sent out with attachments.
	private static void cleanUpEmailLocalFiles(Map<String, File> fileMap)
	{
		if (fileMap != null)
		{
			for (File attachment : fileMap.values())
			{
				if (null != attachment)
				{
					attachment.delete();
				}
			}
		}
	}
	
	/**
	 * @param fileMap
	 * This is used for deleting the attached file from local server after email being sent. 
	 * this is not for inline image 
	 */
	private static void cleanUpAttachedEmailFiles(Map<File, String> fileMap)
	{
		if (fileMap != null)
		{
			Set<Entry<File, String>> entrySet = fileMap.entrySet();
			for (Entry<File, String> attachment : entrySet)
			{
				if (null != attachment.getKey())
				{
					File file = attachment.getKey();
					file.delete();
				}
			}
		}
	}
	
	
}