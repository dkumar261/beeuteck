package com.citi.icg.qma.common.server.dao.persistence;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.CustomClientCriteria;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.GroupHolidayDetails;
import com.citi.icg.qma.common.server.dao.GroupRole;
import com.citi.icg.qma.common.server.dao.GroupRoutingAudit;
import com.citi.icg.qma.common.server.dao.HierarchyOrgDetails;
import com.citi.icg.qma.common.server.dao.HierarchyUserDetail;
import com.citi.icg.qma.common.server.dao.HighlevelRequestType;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.MISReportExclusionRecord;
import com.citi.icg.qma.common.server.dao.ManagementHeirarchy;
import com.citi.icg.qma.common.server.dao.MisReportConfig;
import com.citi.icg.qma.common.server.dao.RoutingCriteria;
import com.citi.icg.qma.common.server.dao.RuleAction;
import com.citi.icg.qma.common.server.dao.StaticData;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.UserReportRequest;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.common.server.util.GlobalDirectoryService;
import com.citi.icg.qma.common.transferobject.GroupRoleTO;
import com.citi.icg.qma.common.transferobject.GroupUserEntitlementsTO;
import com.citi.icg.qma.common.transferobject.UserGroupTO;
import com.citi.icg.qma.common.transferobject.UserTO;
import com.citi.icg.qma.hazelcast.cache.client.HazelCastCacheIncrementalLoad;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;

import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;
import dev.morphia.query.UpdateResults;

public class GroupDAO extends MongoMorphiaDAO
{
	
	private static final String EXCLUSION_REQUESTED_BY_GROUP_ADMIN = "Exclusion requested by group admin.";
	private static final String ENABLE_REPORTING = "enableReporting";
	private static final String ENABLE_REPORTING_FROM_DATE = "enableReportingFromDate";
	private static final String MIS_REPORT_CONFIG_CHANGED = "misReportConfigChanged";
	private static final String MIS_REPORT_CONFIG = "misReportConfig";
	private static final Logger subLogger = LoggerFactory.getLogger(GroupDAO.class);
	private static final String ADMIN = "Group Admin";
	private static final String ANALYST = "Analyst";
	private static final String PEER_REVIEWER = "Peer Reviewer";
	private static final String REQUEST_TYPES = "requestTypes";
	private  UserDAO userDAO = new UserDAO();
	private GlobalDirectoryService globalDirectoryService = GlobalDirectoryService.getInstance();
	private static final String EXPORT_CSV_DELIMITER=",";
	private static final String EXPORT_CSV_NEWLINE="\n";
	public static final String  GROUP_NAME = "groupName";	
	public static final String  GROUP_EMAIL = "groupEmail";
	public static final String  GROUP_COUNTRY = "country";
	public static final String  GROUP_TIMEZONE = "timeZone";
	public static final String  STATUS_ACTIVE = "active";
	private static final String SUPERVISOR = "Supervisor";
	private static final String USER_ID ="userId";
	private static final String USER_NAME ="userName";
	private static final String GROUP_ROLES = "groupRoles";
	private static final String GROUP_DETAILS_ALREADY_UPDATED = "Group deails updated by some other user.";
	
	
	private static final String USER_ROLE_KEY = "userRole";
	private static final String SOE_ID_KEY = "soeId";
	private static final String ROLE_KEY = "role";
	private static final String USER_LIST_KEY = "userList";
	private static final String GROUP_LIST_KEY = "groupList";
	private static final String ADD_TO_GROUP_KEY = "addToGroup";
	private static final String ASSIGNED_GROUPS = "assignedGroups";
	private static final String DASHBOARD_SETTINGS = "dashboardSettings";
	private static final String DATA_KEY = "data";
	private static final String GDPR_RECORD_TYPE_SEC330 = "SEC330";
	private static final String LABEL="label";
	private static final String NAME="name";

	private static final String VALUE="value";
	public static final UserDAO userDao = new UserDAO();

	private static final String SOEID_KEY = "SOEID";
	private static final String THIRD_LEVEL_HEIRARCHY = "thirdLevelHeirarchy";
	
	// C170665-4031 - Allow "Automated Response" for a DL to be more customizable by User
	private static final String CUSTOMIZED_AUTO_RESPONSE_ENABLED_KEY = "customizedAutoResponseEnabled";
	private static final String IS_CUSTOMIZED_AUTO_RESPONSE_ENABLED = "isCustomizedAutoResponseEnabled";
	private static final String CUSTOM_AUTO_RESPONSE_OPTIONS = "customAutoResponseOptions";

	private static final String ENABLE_AUTO_REPLY_SUGGESTION = "enableAutoReplySuggestion";

	
	public static final String  GROUP_TYPE = "groupType";
	public static final String  TASKIZE_GROUP_TYPE = "Taskize";
	
	public List<Group> getMyDBGroups(String soeid) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			User user = userDAO.getUserById(soeid);
			return getMyDBGroups(user);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in GroupDAO.getMyDBGroups", e);
			//throw e;
			throw new CommunicatorException("Exception in GroupDAO.getMyDBGroups", e);
		}
	}

	public List<Group> getMyDBGroups(User user) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			Set<Long> grpIdList = userDAO.getUserGroupsList(user);
			// Check added to handle User not having any group roles-UI will display message to contact Group Admin
			List<Group> grpList = new ArrayList<>();

			if (grpIdList != null && !grpIdList.isEmpty())
			{
				Query<Group> query = mongoDatastore.createQuery(Group.class).filter(STATUS_ACTIVE, true);
				query.criteria("id").in(grpIdList);
				// query.retrievedFields(true, "groupName", "requestTypes");

				grpList = query.find().toList();
				//subLogger.info("UserDao.MyGroups for soeId=" + user.getId() + " ,output=" + grpList);
			}

			return grpList;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in GroupDAO.getMyDBGroups", e);
			throw new CommunicatorException("Exception in GroupDAO.getMyDBGroups", e);
		}
	}
///  Show Inactive groups in 'Group Admin' screen start
	
	//get all active group 
	public List<UserGroupTO> getAllActiveDBGroups() throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
    {
           try
           {
                  //Get Active Groups Only
                  return getGroups(true);
           }
           catch (Exception e)
           {
                  subLogger.error("Exception in GroupDAO.getAllDBGroups", e);
                  throw new CommunicatorException("Exception in GroupDAO.getAllDBGroups", e);
           }
    }
	//get all (active+inactive)group
    public List<UserGroupTO> getAllDBGroups() throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
    {
           try
           {
                  //Get ALl Groups (active+inactive) 
                  return getGroups(false);
           }
           catch (Exception e)
           {
                  subLogger.error("Exception in GroupDAO.getAllDBGroups", e);
                 // throw e;
                  throw new CommunicatorException("Exception in GroupDAO.getAllDBGroups", e);
           }
    }
 //if activeGroupOnly=true Fetch active group only
 //if activeGroupOnly=false Fetch all (active +inactive) group.   
    private List<UserGroupTO> getGroups(Boolean activeGroupOnly)
    {
           List<UserGroupTO> list = new ArrayList<UserGroupTO>();
           Query<Group> query = mongoDatastore.createQuery(Group.class);
           if(activeGroupOnly){
                  query.filter(STATUS_ACTIVE, true);
           }
           String []retrivesFields ={GROUP_NAME,GROUP_EMAIL,STATUS_ACTIVE,GROUP_COUNTRY,GROUP_TIMEZONE, GROUP_TYPE};
           query.retrievedFields(true, retrivesFields);
           //query.retrievedFields(true, "groupEmail");
           query.order(GROUP_NAME);

           List<Group> groupList = query.find().toList();
           for (int i = 0; i < groupList.size(); i++)
           {
                  UserGroupTO vo = new UserGroupTO(groupList.get(i).getGroupName(), "" + groupList.get(i).getId());
                  vo.setEmail(groupList.get(i).getGroupEmail());
                  if(groupList.get(i).getActive()!=null)
                  {
                  vo.setActive(groupList.get(i).getActive());
                  }
                  vo.setCountry(groupList.get(i).getCountry());
                  vo.setTimeZone(groupList.get(i).getTimeZone());
                  
                  // C170665-4331
                  vo.setGroupType(groupList.get(i).getGroupType());
                  list.add(vo);
           }
           return list;
    }
    public List<UserGroupTO> getAllGroupsIdList(Boolean activeGroupOnly)
    {
           List<UserGroupTO> list = new ArrayList<UserGroupTO>();
           Query<Group> query = mongoDatastore.createQuery(Group.class);
           if(activeGroupOnly){
                  query.filter(STATUS_ACTIVE, true);
           }
           String []retrivesFields ={"_id"};
           query.retrievedFields(true, retrivesFields);
           //query.retrievedFields(true, "groupEmail");
          // query.order("groupName");
           List<Long> groupIDList = new ArrayList<Long>();
           List<Group> groupList = query.find().toList();
           for (int i = 0; i < groupList.size(); i++)
           {
        	   groupIDList.add(groupList.get(i).getId());
           }
           return list;
    }


	public List<String> getMyRequestTypes(Set<Long> groupIds) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		try
		{
			Query<Group> query = mongoDatastore.createQuery(Group.class).filter(STATUS_ACTIVE, true);
			query.criteria("id").in(groupIds);
			Set<String> requestTypeSet = new HashSet<String>();
			List<Group> groupList = query.find().toList();
			for (Group grp : groupList)
			{
				if (grp.getRequestTypes() != null)
				{
					requestTypeSet.addAll(grp.getRequestTypes());
				}
			}
			List<String> allRequestTypeList = new ArrayList<>(requestTypeSet);
			//Collections.sort(allRequestTypeList);
			GenericUtility.getCaseInsensitiveSortedList(allRequestTypeList);
			return allRequestTypeList;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in GroupDAO.getMyRequestTypes", e);
			//throw e;
			throw new CommunicatorException("Exception in GroupDAO.getMyRequestTypes", e);
		}
	}
	
	public List<Group> getGroupList(Set<Long> groupIds) throws CommunicatorException {
		try {
			Query<Group> query = mongoDatastore.createQuery(Group.class).filter(STATUS_ACTIVE, true);
			query.criteria("id").in(groupIds);
			Set<String> requestTypeSet = new HashSet<String>();
			List<Group> groupList = query.find().toList();
			return groupList;
		} catch (Exception e) {
			subLogger.error("Exception in GroupDAO.getGroupList", e);
			// throw e;
			throw new CommunicatorException("Exception in GroupDAO.getGroupList", e);
		}
	}

	public String getGroupByEmail(String email) throws CommunicatorException {
		try{
			Query<Group> query = mongoDatastore.createQuery(Group.class).filter(GROUP_EMAIL, email);
			List<Group> groupList = query.find().toList();
			return groupList.get(0).getGroupName();
		}catch (Exception e) {
			subLogger.error("Exception in GroupDAO.getGroupByEmail", e);
			// throw e;
			throw new CommunicatorException("Exception in GroupDAO.getGroupByEmail", e);
		}
	}

	//Called From GroupAdmin Screen
	public BasicDBObject saveGroupDetails(String soeId, BasicDBObject inputJsonObjList) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{

		Group group = null;
		BasicDBObject response = new BasicDBObject();
		try
		{
			String groupName = inputJsonObjList.getString(GROUP_NAME);
			QMACache qmaCache = QMACacheFactory.getCache();
			Map<String, User> userInfoMap = qmaCache.getUserInfoMap();
			if (null == userInfoMap || soeId == null || null == userInfoMap.get(soeId.toUpperCase())) {
				subLogger.error("No Valid User found in QMA for {} ", soeId);
				response.put(AppserverConstants.MESSAGE_KEY, "No Valid User " + soeId + " found in QMA");
				response.put(AppserverConstants.SUCCESS_KEY, false);
				return response;
			}
			if (null == qmaCache.getGroupCodeToIdMap()
					|| null == qmaCache.getGroupCodeToIdMap().get(groupName.toUpperCase())) {
				subLogger.error("No Valid Group found in QMA for {} ", groupName);
				response.put(AppserverConstants.MESSAGE_KEY, "No Valid Group" + groupName + " found in QMA");
				response.put(AppserverConstants.SUCCESS_KEY, false);
				return response;
			}
			boolean hasAdminRole = hasRoleToPerformAction(soeId, groupName, "Admin", qmaCache);
			if (!hasAdminRole) {
				subLogger.error("User {} doesn't have admin privilege to perform this action ", soeId);
				response.put(AppserverConstants.MESSAGE_KEY, "User doesn't have admnin privilege to perform this action ");
				response.put(AppserverConstants.SUCCESS_KEY, false);
				return response;
			}
			String lastDbVersion = inputJsonObjList.getString("version");
			// Get Group from DB
			Query<Group> queryGroup = mongoDatastore.createQuery(Group.class).filter(GROUP_NAME, groupName);
			group = queryGroup.get();
			if(null != lastDbVersion && null != group.getVersion() && !lastDbVersion.equals(group.getVersion().toString()))
			{
				response.put(AppserverConstants.MESSAGE_KEY, GROUP_DETAILS_ALREADY_UPDATED);
				response.put(AppserverConstants.SUCCESS_KEY, false);
				return response;
			}
			
			BasicDBList requestTypes = (BasicDBList) inputJsonObjList.get("requestTypeList");
			BasicDBList requestTypeMappings = (BasicDBList) inputJsonObjList.get("requestTypeMappings");
			BasicDBList domainList = (BasicDBList) inputJsonObjList.get("domainList");
			List<String> escKeywordList = (ArrayList<String>) inputJsonObjList.get("escKeywordList");
			Boolean domainReqd = inputJsonObjList.getBoolean("domainReqd");
			//[C153176-426] Ability to block adding external clients to 'Top Contacts',
			Boolean isEmailSharingBlocked = inputJsonObjList.getBoolean("isEmailSharingBlocked");
			
			Boolean attachmentIncluded = inputJsonObjList.getBoolean("attachmentIncluded");
			
			//Flag to indicate predictive ext user's email search
			Boolean predictiveRecipients = inputJsonObjList.getBoolean("predictiveRecipients");
			
			subLogger.info("Inside GroupDAO:saveGroupDetails - soeId= " + soeId + ", groupName= " + groupName);
			if (StringUtils.isBlank(groupName))
			{
				subLogger.info("Invalid input data for saveGroupDetails with groupName= " + groupName);
				throw new CommunicatorException("Invalid input data");// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
			}
			// Get all the user list
			BasicDBList analystToBeAdded = (BasicDBList) inputJsonObjList.get("analystAddList");
			BasicDBList adminToBeAdded = (BasicDBList) inputJsonObjList.get("adminAddList");
			BasicDBList peerRevToBeAdded = (BasicDBList) inputJsonObjList.get("peerRevAddList");
			BasicDBList analystToBeRemoved = (BasicDBList) inputJsonObjList.get("analystRemoveList");
			BasicDBList adminToBeRemoved = (BasicDBList) inputJsonObjList.get("adminRemoveList");
			BasicDBList peerRevToBeRemoved = (BasicDBList) inputJsonObjList.get("peerRevRemoveList");
			String disclaimer =  inputJsonObjList.getString("disclaimer");
			Date createdDate = new Date();
			BasicDBList tagsToBeAdded = (BasicDBList) inputJsonObjList.get("addGroupTags");
			BasicDBList tagsToBeRemoved = (BasicDBList) inputJsonObjList.get("deleteGroupTags");
			BasicDBList tagsToBeEdited = (BasicDBList) inputJsonObjList.get("editGroupTags");
			BasicDBList autoResponseDetails = (BasicDBList) inputJsonObjList.get("autoResponseDetails");
			BasicDBList userAssignmentExclusionList = (BasicDBList) inputJsonObjList.get("userAssignmentExclusionList");
			BasicDBList supervisorToBeAdded = (BasicDBList) inputJsonObjList.get("supervisorAddList");
			BasicDBList supervisorToBeRemoved = (BasicDBList) inputJsonObjList.get("supervisorRemoveList");
			//[C153176-777] - Add admin functionality for RootCause addition & updates to any group
			BasicDBList rootCauseList = (BasicDBList) inputJsonObjList.get("rootCauseList");
			Boolean isRootCauseMandatory = inputJsonObjList.getBoolean("isRootCauseMandatory");
			Boolean isRootCauseMandatoryWOReply = false;
			//Setting isRootCauseMandatoryWOReply only when isRootCauseMandatory is true
			if(isRootCauseMandatory)
			{
				isRootCauseMandatoryWOReply = inputJsonObjList.getBoolean("isRootCauseMandatoryWOReply");
			}
			
			BasicDBList subjectEscalationList = (BasicDBList) inputJsonObjList.get("subjectEscalationList");
			
			//[C153176-793] - Add 'Processing Region' as a drop-down in Group Admin screen
			BasicDBList processingRegionList = (BasicDBList) inputJsonObjList.get("processingRegionList");
			Boolean isProcessingRegionMandatory = inputJsonObjList.getBoolean("isProcessingRegionMandatory");
			Boolean isInquirySourceMandatory = inputJsonObjList.getBoolean("isInquirySourceMandatory"); //[C153176-854] - Add new drop-down: Inquiry Source
			Boolean isInqReferenceIdReq = inputJsonObjList.getBoolean("isInqReferenceIdReq"); //[C153176-853] - Add Inquiry ID in email
			Boolean enableXstreamIntegration = inputJsonObjList.getBoolean("enableXstreamIntegration");
			Boolean autoReplyEnable = inputJsonObjList.getBoolean("autoReplyEnable");
			Boolean isAutoResponseEnabledForInternalDomain = inputJsonObjList.getBoolean("isAutoResponseEnabledForInternalDomain");
			// QMA-1442 START - Enhancement for adding more info in the auto response template
			Boolean includeAssignedUserInfo = inputJsonObjList.getBoolean("includeAssignedUserInfo");
			Boolean includeUserContactInfo = inputJsonObjList.getBoolean("includeUserContactInfo");
			Boolean includeManagerContactInfo = inputJsonObjList.getBoolean("includeManagerContactInfo");
			// QMA-1442 END
			Boolean isGfidMandatory = inputJsonObjList.getBoolean("isGfidMandatory"); //[C153176-1030] - Make GFPID/GFCID mandatory with group preference
			Boolean isUINotificationPopupEnabled = inputJsonObjList.getBoolean("isUINotificationPopupEnabled");
			Boolean isTagMandatory = inputJsonObjList.getBoolean("isTagMandatory"); //[C153176-1035] - Make tag mandatory to resolve option
			Integer convCountThresholdForEscalation = inputJsonObjList.getInt("convCountThresholdForEscalation") > 0 ? inputJsonObjList.getInt("convCountThresholdForEscalation") : null;
			Integer responseTimeThresholdForEscalation = inputJsonObjList.getInt("responseTimeThresholdForEscalation") > 0 ? inputJsonObjList.getInt("responseTimeThresholdForEscalation") : null;
			Integer paResponseTimeThresholdForEscalation = inputJsonObjList.getInt("paResponseTimeThresholdForEscalation") > 0 ? inputJsonObjList.getInt("paResponseTimeThresholdForEscalation") : null;
			//[C170665-1719] DCC Requirement: Add Case status field
			Boolean enableInquirySubStatus = inputJsonObjList.getBoolean("enableInquirySubStatus");
			
			Boolean enableAutoReplySuggestion = inputJsonObjList.getBoolean(ENABLE_AUTO_REPLY_SUGGESTION);
			
			Boolean excludeMyGroupWhileReplyAll = inputJsonObjList.getBoolean("excludeMyGroupWhileReplyAll");
			
			Boolean includeMyGroupInCC = inputJsonObjList.getBoolean("includeMyGroupInCC");
			
			// C153176-5630 | Enable/disable client contact list visibility for group members
			Boolean hideClientList = inputJsonObjList.getBoolean("hideClientList");
			
			// C153176-6148 | Group configuration : Re-age need supervisor approval
			Boolean supervisiorApprovalForReage = inputJsonObjList.getBoolean("supervisiorApprovalForReage");
			
			// C170665-10 | Request Type and Root Cause Linking
			Boolean requestTypeRootCauseFilter = group.getRequestTypeRootCauseFilter();
			// C170665-279 | If user save group from QMA 1.0, this property is not present.
//			if (inputJsonObjList.containsField("requestTypeRootCauseFilter") && inputJsonObjList.getBoolean("isQMA2Origin")) {
				if (inputJsonObjList.containsField("requestTypeRootCauseFilter")) {
				requestTypeRootCauseFilter = inputJsonObjList.getBoolean("requestTypeRootCauseFilter");
			}
            //C170665-1634 - QMA Group Admin updates for Group Manager
            Boolean isGroupManagerAboveL7 = null;
			if (inputJsonObjList.containsField("isGroupManagerAboveL7")) {
				isGroupManagerAboveL7 = inputJsonObjList.getBoolean("isGroupManagerAboveL7");
			}
			
			// C170665-2709 - Saving managerSoeId on admin screen submit
 			String managerSoeId = null;
			if (inputJsonObjList.containsField("managerSoeId")) {
				managerSoeId = inputJsonObjList.getString("managerSoeId");
			}
						
			boolean isHolidayBasedAgeCalculation = inputJsonObjList.getBoolean("isHolidayBasedAgeCalculation");
			String groupCountryValue = inputJsonObjList.getString("groupCountryValue");
			String groupTimeZoneValue = inputJsonObjList.getString("groupTimeZoneValue");
			String groupShiftStartTime = inputJsonObjList.getString("groupShiftStartTime");
			String groupShiftEndTime = inputJsonObjList.getString("groupShiftEndTime");
			List<String> weekelyOff = (List<String>)inputJsonObjList.get("weekelyOff");
			//Management Heirarchy data.[C153176-1704]-Ability for Group Admins to change Group Manager.			
			BasicDBObject heirarchyData = (BasicDBObject) inputJsonObjList.get("heirarchyData");
			if(heirarchyData != null)
			{
			    Map<String, Object> globalDirConfig = globalDirectoryService.getGlobalDirectoryConfig();
				List<BasicDBObject> thirdLevelHeirarchy = GenericUtility.getJsonObjFromRequest(heirarchyData, THIRD_LEVEL_HEIRARCHY);
				String soeid = thirdLevelHeirarchy.get(0).getString(USER_ID);
				String userName = null;
				String apiResponse = globalDirectoryService.fetchUserDetailsFromGlobDir(soeid, SOEID_KEY, globalDirConfig);
				if(apiResponse!=null) {
				    userName = globalDirectoryService.getNameFromApiResponse(apiResponse);
				    subLogger.info("GroupDao.SaveGroupDetails : L7 Mananger name from GD {} for group  : {}", userName,groupName );
				    thirdLevelHeirarchy.get(0).put(USER_NAME, userName);
				    heirarchyData.put(THIRD_LEVEL_HEIRARCHY, thirdLevelHeirarchy);   
				}
				 if(apiResponse == null ) {
				     subLogger.info("Issue while calling GD API in GroupDAO.saveGroupDetails. Populating user name from User Collection");
				 }
			}
			//Validation for hierarchy data
			/*if(heirarchyData!=null)
			{
				//Need to make checks to prevent incorrect data save.
				List<String> organisation = (List<String>) heirarchyData.get("organisation");
				List<String> firstLevelHeirarchy = (List<String>) heirarchyData.get("secondLevelHeirarchy");
				List<String> secondLevelHeirarchy = (List<String>) heirarchyData.get("thirdLevelHeirarchy");
				List<String> thirdLevelHeirarchy = (List<String>) heirarchyData.get("thirdLevelHeirarchy");
				List<String> gfcId = (List<String>) heirarchyData.get("gfcid");
				
				//Validate hierarchy before save.
				hierarchyDataValidation(organisation,firstLevelHeirarchy,secondLevelHeirarchy,thirdLevelHeirarchy,gfcId);
			}*/
			
			if (requestTypes == null || requestTypes.isEmpty())
			{
				subLogger.info("Missing mandatory request type mapping for saveGroupDetails with groupName= " + groupName);
				//throw new CommunicatorException("Missing mandatory request type mapping");// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
				response.put(AppserverConstants.MESSAGE_KEY, "Missing mandatory request type mapping");
				response.put("validationMessage", true);
				response.put(AppserverConstants.SUCCESS_KEY, false);
				return response;
			}

			DBObject newGrpRole = createNewGroupRoleDBObject(soeId, group.id, createdDate);

			DBCollection userCollection = mongoDatastore.getCollection(User.class);
			// Users to be added
			if (analystToBeAdded != null)
				updateUserAdditionDetails(analystToBeAdded, userCollection, newGrpRole, ANALYST);
			if (adminToBeAdded != null)
				updateUserAdditionDetails(adminToBeAdded, userCollection, newGrpRole, ADMIN);
			if (peerRevToBeAdded != null)
				updateUserAdditionDetails(peerRevToBeAdded, userCollection, newGrpRole, PEER_REVIEWER);
			if (supervisorToBeAdded != null)
				updateUserAdditionDetails(supervisorToBeAdded, userCollection, newGrpRole, SUPERVISOR);
			// Users to be removed.
			if (analystToBeRemoved != null)
				updateUserRemoveDetails(group, analystToBeRemoved, userCollection, ANALYST);
			if (peerRevToBeRemoved != null)
				updateUserRemoveDetails(group, peerRevToBeRemoved, userCollection, PEER_REVIEWER);
			if (adminToBeRemoved != null)
				updateUserRemoveDetails(group, adminToBeRemoved, userCollection, ADMIN);
			if (supervisorToBeRemoved != null)
				updateUserRemoveDetails(group, supervisorToBeRemoved, userCollection, SUPERVISOR);
			
			if(tagsToBeAdded!=null)
				addGroupTags(soeId, group, tagsToBeAdded,queryGroup);
			if(tagsToBeRemoved!=null)
				deleteGroupTags(soeId, group, tagsToBeRemoved, queryGroup);
			if(tagsToBeEdited!=null)
				editGroupTags(group, tagsToBeEdited);
			
			Group uiGroupPreferences = new Group();
			uiGroupPreferences.setMakerCheckerRqd(domainReqd);
			uiGroupPreferences.setPredictiveRecipients(predictiveRecipients);
			uiGroupPreferences.setAttachmentBasedMakerChecker(attachmentIncluded);
			uiGroupPreferences.setIsEmailSharingBlocked(isEmailSharingBlocked);
			uiGroupPreferences.setIsRootCauseMandatory(isRootCauseMandatory);
			uiGroupPreferences.setIsProcessingRegionMandatory(isProcessingRegionMandatory);
			uiGroupPreferences.setIsInqSourceMandatory(isInquirySourceMandatory);
			uiGroupPreferences.setIsInqReferenceIdReq(isInqReferenceIdReq);
			uiGroupPreferences.setEnableXstreamIntegration(enableXstreamIntegration);
			uiGroupPreferences.setAutoReplyEnable(autoReplyEnable);
			// QMA-1442 START - Enhancement for adding more info in the auto response template
			uiGroupPreferences.setIncludeAssignedUserInfo(includeAssignedUserInfo);
			uiGroupPreferences.setIncludeUserContactInfo(includeUserContactInfo);
			uiGroupPreferences.setIncludeManagerContactInfo(includeManagerContactInfo);
			// QMA-1442 END
			uiGroupPreferences.setAutoResponseEnabledForInternalDomain(isAutoResponseEnabledForInternalDomain);
			uiGroupPreferences.setIsRootCauseMandatoryWOReply(isRootCauseMandatoryWOReply);
			uiGroupPreferences.setIsGfidMandatory(isGfidMandatory);
			uiGroupPreferences.setIsUINotificationPopupEnabled(isUINotificationPopupEnabled);
			/*[C153176-1035] - Make Tag mandatory to resolve*/
			uiGroupPreferences.setIsTagMandatory(isTagMandatory);
			uiGroupPreferences.setConvCountThresholdForEscalation(convCountThresholdForEscalation);
			uiGroupPreferences.setResponseTimeThresholdForEscalation(responseTimeThresholdForEscalation);
			//[C153176-1270] - Add Escalation criteria for 'Pending Approval' emails
			uiGroupPreferences.setPaResponseTimeThresholdForEscalation(paResponseTimeThresholdForEscalation);
			uiGroupPreferences.setExcludeMyGroupWhileReplyAll(excludeMyGroupWhileReplyAll);
			uiGroupPreferences.setIncludeMyGroupInCC(includeMyGroupInCC);
			// C153176-5630 | Enable/disable client contact list visibility for group members
			uiGroupPreferences.setHideClientList(hideClientList); 
			// C153176-6148 | Group configuration : Re-age need supervisor approval
			uiGroupPreferences.setSupervisiorApprovalForReage(supervisiorApprovalForReage);
			// C170665-10 | Request Type and Root Cause Linking
			uiGroupPreferences.setRequestTypeRootCauseFilter(requestTypeRootCauseFilter);
			//[C170665-1719] DCC Requirement: Add Case status field
			uiGroupPreferences.setEnableInquirySubStatus(enableInquirySubStatus);//[C170665-1719] DCC Requirement: Add Case status field
			uiGroupPreferences.setEnableAutoReplySuggestion(enableAutoReplySuggestion);
			if (null != isGroupManagerAboveL7) {
				uiGroupPreferences.setGroupManagerAboveL7(isGroupManagerAboveL7);
			}
			if (null != managerSoeId) {
				uiGroupPreferences.setManagerSoeId(managerSoeId);
			}
			GroupHolidayDetails groupHolidayDetails =  uiGroupPreferences.getHolidayAndShiftDetails();
			if(groupHolidayDetails==null){
				groupHolidayDetails = new GroupHolidayDetails();
			}
			groupHolidayDetails.setHolidayBasedAgeCalculation(isHolidayBasedAgeCalculation);
			groupHolidayDetails.setShiftStartTime(groupShiftStartTime);
			groupHolidayDetails.setShiftEndTime(groupShiftEndTime);
			groupHolidayDetails.setWeeklyOffDays(weekelyOff);
			uiGroupPreferences.setHolidayAndShiftDetails(groupHolidayDetails);
			uiGroupPreferences.setCountry(groupCountryValue);
			uiGroupPreferences.setTimeZone(groupTimeZoneValue);

			uiGroupPreferences.setEscKeywords(escKeywordList);
			
			List<CustomClientCriteria> customClientCategory = (List<CustomClientCriteria>) inputJsonObjList.get("customClientCategory");
			uiGroupPreferences.setCustomClientCategory(customClientCategory);
			
			// C170665-10 | Request Type and Root Cause Mapping
			Map<String, List<String>> requestTypeRootCauseMapping = group.getRequestTypeRootCauseMapping();
			// C170665-279 | If user save group from QMA 1.0, this property is not present.
//			if (inputJsonObjList.containsField("requestTypeRootCauseMapping") && inputJsonObjList.getBoolean("isQMA2Origin")) {
			if (inputJsonObjList.containsField("requestTypeRootCauseMapping")) {
				requestTypeRootCauseMapping = (Map<String, List<String>>) inputJsonObjList.get("requestTypeRootCauseMapping");
			}
			
			// C170665-4031 - Allow "Automated Response" for a DL to be more customizable by User
			boolean isCustomizedAutoResponseEnabled = false;
			if(inputJsonObjList.containsKey(CUSTOMIZED_AUTO_RESPONSE_ENABLED_KEY)){
				isCustomizedAutoResponseEnabled = inputJsonObjList.getBoolean(CUSTOMIZED_AUTO_RESPONSE_ENABLED_KEY);
			}
			
			String customAutoResponseOptions = "";
			if(inputJsonObjList.containsKey(CUSTOM_AUTO_RESPONSE_OPTIONS) && inputJsonObjList.getString(CUSTOM_AUTO_RESPONSE_OPTIONS) != null) {
				customAutoResponseOptions = inputJsonObjList.getString(CUSTOM_AUTO_RESPONSE_OPTIONS);
			}
			
			uiGroupPreferences.setRequestTypeRootCauseMapping(requestTypeRootCauseMapping);
			//Save auto assignment flag at group level.
			setAutoAssignmentPreference(inputJsonObjList, uiGroupPreferences,group);
			// Update Group Details .. makerCheckDomains,RequestTypes
			//Passing hierarchy data as null and Commenting method since hierachy for group admin is currently disabled.
			//[C153176-426] Ability to block adding external clients to 'Top Contacts',
			updateDBGroupDetails(requestTypes, domainList, uiGroupPreferences, queryGroup,disclaimer,heirarchyData,userAssignmentExclusionList,autoResponseDetails,rootCauseList,processingRegionList, requestTypeMappings,subjectEscalationList, isCustomizedAutoResponseEnabled, customAutoResponseOptions);
			if (heirarchyData !=null ){
				subLogger.info("Updated the hierarchy data succesfully.");
			}
			String [] retrivesFields ={AppserverConstants.VERSION};
			Query<Group> grpVersionQry = mongoDatastore.createQuery(Group.class).filter(AppserverConstants.MONGO_PK, group.id).retrievedFields(true, retrivesFields);
			Group grpVersion = grpVersionQry.get();
			response.put(AppserverConstants.SUCCESS_KEY, true);
			String version =  null != group.getVersion()?grpVersion.getVersion().toString():"";
			response.put(AppserverConstants.VERSION, version);
			
			//Remove group from dashboard settings, if group assignment removed.
			removeGroupFromDashboardSettings(groupName, soeId);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in GroupDAO.saveGroupDetails", e);
			throw new CommunicatorException("Exception in GroupDAO.saveGroupDetails", e);
		}

		return response;

	}

	private void setAutoAssignmentPreference(BasicDBObject inputJsonObjList, Group uiGroupPreferences, Group group) {
		if (inputJsonObjList.containsField("enableAutoAssignment") && inputJsonObjList.getBoolean("isQMA2Origin")) {
			boolean autoAssignmentPrefernce = inputJsonObjList.getBoolean("enableAutoAssignment");
			uiGroupPreferences.setEnableAutoAssignment(autoAssignmentPrefernce);	
		}
	}

	/**
	 * This method used to remove Assigned group from dashboard settings
	 * @param groupName
	 * @param soeId
	 * @throws CommunicatorException
	 */
	private void removeGroupFromDashboardSettings(String groupName, String soeId) throws CommunicatorException {
		QMACache qmaCache =  QMACacheFactory.getCache();
		try{
			Long groupId = qmaCache.getGroupCodeToIdMap().get(groupName.toUpperCase());
			if(null != groupId){
				List<String> userList = qmaCache.getGroupIdToUserListMap().get(groupId);
				if( null!= userList && !userList.contains(soeId)){
					updateDashboardSettings(soeId, groupId);
				}
			}
		}catch(Exception ex){
			subLogger.error("Exception in GroupDAO.saveGroupDetails while removing group from dashboard settings", ex);
			throw new CommunicatorException("Exception in GroupDAO.saveGroupDetails while removing group from dashboard settings", ex);
		}
	}

	private void updateDashboardSettingsForAdd(String soeId, Group group) throws CommunicatorException {
		BasicDBObject dashBoardSettings = DashboardDAO.getInstance().getDashboardSettings(soeId);
		if (null != dashBoardSettings ) {
			BasicDBList assignedGroupsList;
			if (null == dashBoardSettings.get(ASSIGNED_GROUPS))
				assignedGroupsList = new BasicDBList();
			else{
				assignedGroupsList = (BasicDBList) dashBoardSettings.get(ASSIGNED_GROUPS);
				if(assignedGroupsList.stream().anyMatch(ag -> {
					BasicDBObject agBd = (BasicDBObject) ag;
					return agBd.get(GROUP_NAME).equals(group.getGroupName());
				}))
					return;
			}
			BasicDBObject newAssignedGroup = new BasicDBObject();
			newAssignedGroup.put(GROUP_NAME, group.getGroupName());
			newAssignedGroup.put(REQUEST_TYPES, group.getRequestTypes());
			assignedGroupsList.add(newAssignedGroup);
			dashBoardSettings.put(ASSIGNED_GROUPS, assignedGroupsList);
			BasicDBObject dashboardSettingRequest = new BasicDBObject();
			dashboardSettingRequest.put(DASHBOARD_SETTINGS, dashBoardSettings);
			DashboardDAO.getInstance().saveDashboardSettings(soeId, dashboardSettingRequest.toString());
		}
	}

	/**
	 * This method is used to fetch dashboard and update settings for user
	 * @param soeId
	 * @param groupCode
	 * @throws CommunicatorException
	 */
	private void updateDashboardSettings(String soeId, Long groupCode) throws CommunicatorException {
		BasicDBObject dashBoardSettings = DashboardDAO.getInstance().getDashboardSettings(soeId);
		if (null != dashBoardSettings && null != dashBoardSettings.get(ASSIGNED_GROUPS)) {
			BasicDBList assignedGroupsList = (BasicDBList) dashBoardSettings.get(ASSIGNED_GROUPS);
			if (null != assignedGroupsList && !assignedGroupsList.isEmpty()) {
				removeUnAssignedGroupFromDashboard(soeId, groupCode, dashBoardSettings, assignedGroupsList);
			}
		}
	}

	/**
	 * This method removes unassigned group from dashboard settings
	 * @param soeId
	 * @param groupCode
	 * @param dashBoardSettings
	 * @param assignedGroupsList
	 * @param updatedGroupsList
	 * @throws CommunicatorException
	 */
	private void removeUnAssignedGroupFromDashboard(String soeId, Long groupCode, BasicDBObject dashboardSettingsAssigndGroup,
			BasicDBList assignedGroupsList) throws CommunicatorException {
		BasicDBList updatedGroupsList = new BasicDBList();
		QMACache qmaCache = QMACacheFactory.getCache();
		Map<String, Long> groupCodeToIdMap = qmaCache.getGroupCodeToIdMap();
		for (int i = 0; i < assignedGroupsList.size(); i++) {
			BasicDBObject assignedGroup = (BasicDBObject) assignedGroupsList.get(i);
			String groupNameDashboard = assignedGroup.getString(GROUP_NAME);
			if (!StringUtils.isEmpty(groupNameDashboard)) {
				Long groupCodeDashboard = groupCodeToIdMap.get(groupNameDashboard.toUpperCase());
				if(groupCode != groupCodeDashboard){
					updatedGroupsList.add(assignedGroup);
				}
			}
		}
		dashboardSettingsAssigndGroup.put(ASSIGNED_GROUPS, updatedGroupsList);
		BasicDBObject dashboardSettings = new BasicDBObject();
		dashboardSettings.put(DASHBOARD_SETTINGS, dashboardSettingsAssigndGroup);
		DashboardDAO.getInstance().saveDashboardSettings(soeId, dashboardSettings.toString());
	}

	private DBObject createNewGroupRoleDBObject(String soeId, Long groupId, Date currDate)
	{
		DBObject newGrpRole = new BasicDBObject();
		newGrpRole.put("groupId", groupId);
		newGrpRole.put("crtDate", currDate);
		newGrpRole.put("crtBy", soeId);
		return newGrpRole;
	}

	public List<UserTO> getGroupDetails(String groupName) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("Inside GroupDAO:getGroupDetails - for group : " + groupName);
		//Sonar fix - remove useless assignments
		
		if (StringUtils.isBlank(groupName))
		{
			subLogger.info("Invalid input data for saveGroupDetails with groupName= " + groupName);
			throw new CommunicatorException("Invalid input data for saveGroupDetails with groupName= " + groupName);
		}

		try
		{
			Query<Group> queryGroup = mongoDatastore.createQuery(Group.class).filter(GROUP_NAME, groupName);
			Group group = queryGroup.get();

			if (group == null)
			{
				subLogger.info("Invalid input data for saveGroupDetails with groupName= " + groupName);
				throw new CommunicatorException("Invalid input data. Please contact support.");// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
			}
			Long grpId = group.id;
			Query<User> queryUser = mongoDatastore.createQuery(User.class).filter("groupRoles.groupId", grpId).filter(STATUS_ACTIVE, true);
			List<User> userList = queryUser.find().toList();

			List<UserTO> userNameList = getUserNameList(groupName, grpId, userList);//Sonar fix - to reduce complexity less then 10
			userNameList = getUsersInOrder(userNameList);
			List<Group> grpList = new ArrayList<>();
			grpList.add(group);
			userNameList.get(0).setMyGroups(grpList);
			return userNameList;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in GroupDAO:getGroupDetails", e);
			throw new CommunicatorException("Exception in GroupDAO:getGroupDetails",e);
		}
	}
	
	public Group getGroupVersionDetails(String groupName) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("Inside GroupDAO:getGroupDetails - for group : " + groupName);
		//Sonar fix - remove useless assignments
		
		if (StringUtils.isBlank(groupName))
		{
			subLogger.info("Invalid input data for saveGroupDetails with groupName= " + groupName);
			throw new CommunicatorException("Invalid input data for saveGroupDetails with groupName= " + groupName);
		}

		try
		{
			 String [] retrivesFields ={GROUP_NAME, "version"};
			Query<Group> queryGroup = mongoDatastore.createQuery(Group.class).filter(GROUP_NAME, groupName).retrievedFields(true, retrivesFields);
			Group group = queryGroup.get();

			if (group == null)
			{
				subLogger.info("Invalid input data for saveGroupDetails with groupName= " + groupName);
				throw new CommunicatorException("Invalid input data. Please contact support.");// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
			}
			return group;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in GroupDAO:getGroupDetails", e);
			throw new CommunicatorException("Exception in GroupDAO:getGroupDetails",e);
		}
	}
	
	/*
	 * Method to fetch all the linked users for passed group list.
	 */
	public List<UserTO> getLinkedUsersForGroupList(List<BasicDBObject> groupList) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		subLogger.info("Inside GroupDAO:getGroupDetails");
		//Sonar fix - remove useless assignments
		try
		{
			Map<String, UserTO> userNameMap = new HashMap<String, UserTO>();
			List<Long> groupIds = new ArrayList<Long>();
			for(BasicDBObject groupInfo : groupList)
			{
				Long groupId =groupInfo.getLong("value");
				groupIds.add(groupId);
				
			}
			Query<User> queryUser = mongoDatastore.createQuery(User.class).field("groupRoles.groupId").in(groupIds);
			List<User> userList = queryUser.find().toList();
			for(User usr: userList)
			{
				if (usr != null && usr.getActive() != null && usr.getActive().booleanValue() && userNameMap.get(usr.getId()) == null)
				{
					UserTO userTo = new UserTO();
					userTo.setUserId(usr.getId());
					userTo.setUserName(usr.getName());
					userNameMap.put(usr.getId(), userTo);
				}
			}
			return getUsersInOrder(new ArrayList<UserTO>(userNameMap.values()));
		}
		catch (Exception e)
		{
			subLogger.error("Exception in GroupDAO:getGroupDetails", e);
			throw new CommunicatorException("Exception in GroupDAO:getGroupDetails",e);
		}
	}
	private List<UserTO> getUserNameList(String groupName, Long grpId, List<User> userList) 
	{
		List<UserTO> userNameList = new ArrayList<UserTO>();
		for (User user : userList)
		{
			UserTO userDetail = new UserTO();
			userDetail.setUserId(user.getId());
			userDetail.setUserName(user.getName());
			userDetail.setGroupRoles(new ArrayList<GroupRoleTO>());
			if (user.getGroupRoles() != null)
			{
				for (GroupRole grpRole : user.getGroupRoles())
				{
					// Filter & send the group role only for the input group name
					if (null != grpRole && null != grpRole.getGroupId() && grpRole.getGroupId().equals(grpId))
					{
						GroupRoleTO grpRoleUI = new GroupRoleTO();
						grpRoleUI.setGroupName(groupName);
						grpRoleUI.setGroupRole(grpRole.getRole());
						userDetail.getGroupRoles().add(grpRoleUI);
					}
				}
			}

			userNameList.add(userDetail);
		}
		return userNameList;
	}
	
//	private List<UserTO> getUserNameListWithoutGroup(List<User> userList) 
//	{
//		List<UserTO> userNameList = new ArrayList<UserTO>();
//		for (User user : userList)
//		{
//			if(user != null && !userNameList.contains(user))
//			{
//				UserTO userDetail = new UserTO();
//				userDetail.setUserId(user.getId());
//				userDetail.setUserName(user.getName());
//				userNameList.add(userDetail);
//			}
//		}
//		return userNameList;
//	}
	
	private List<UserTO> getUsersInOrder(List<UserTO> vos)
	{
		if (vos == null)
		{
			return vos;
		}
		Collections.sort(vos, new Comparator<UserTO>()
		{
			//Sonar fix -- use override annotation on overridden method
		  	@Override
		  	public int compare(final UserTO obj1, final UserTO obj2)
			{
				return obj1.getUserName().toLowerCase().compareTo(obj2.getUserName().toLowerCase());

			}
		});
		return vos;
	}
	
	//Method which takes groupRole list and does bulk update
	private void updateUserAdditionDetails(BasicDBList usersToBeAdded, DBCollection userCollection, List<DBObject> newGrpRoleList) throws CommunicatorException//Sonar Fix remove unused parameter
	{
		DBObject updateGroupRoleObj = new BasicDBObject();
		updateGroupRoleObj.put("$addToSet", new BasicDBObject(GROUP_ROLES, new BasicDBObject("$each",newGrpRoleList)));
		if(usersToBeAdded.size() > 0) {
			//excluse users who already has given entitlement
			BasicDBList userList = excludeUserIfAlreadyEntitledForRole(usersToBeAdded,newGrpRoleList);
			if(userList.size() >0 ) {
				DBObject updateQuery = new BasicDBObject();
				//updateQuery.put("_id", new BasicDBObject("$in", usersToBeAdded));
				updateQuery.put("_id", new BasicDBObject("$in", userList));

				// Bulk Update call, updates all User's group roles matching the condition
				userCollection.updateMulti(updateQuery, updateGroupRoleObj);
				refreshGroupEntitlements(userList);
			}
			for (Object userObj : userList) {
				User user = this.userDAO.getUserById(String.valueOf(userObj));

				String soeId = user.getId();

					Long groupId = null;
					for (DBObject grpRole : newGrpRoleList) {
						groupId = (Long) grpRole.get("groupId");

					}
					try {
						// Get dashboard settings for the user
						Map<String, Object> dashboardSettings = user.getDashboardSettings();
						if (dashboardSettings != null && Boolean.parseBoolean(dashboardSettings.getOrDefault("allGroupsSelected", "false").toString())) {
							this.updateDashboardSettingsForAdd(soeId, QMACacheFactory.getCache().getAllGroupsMap().get(groupId));
						}
					} catch (Exception e) {
						subLogger.error("Error updating dashboard settings for user: " + soeId, e);
					}

			}

		} else {
			subLogger.info("no user to update :"+usersToBeAdded.toString());
		}


		/*
		 * CacheDAO.getInstance().reloadCache();
		 * updateStaticDataGroupLastModifiedTimeToReloadServiceCache();
		 */
	}

	/**
	 * @param userList
	 */
	private void refreshGroupEntitlements(BasicDBList userList) {
		try {
			for (Object userId : userList) {
				if (null != userId) {
					HazelCastCacheIncrementalLoad.refreshUserCache(userId.toString());
				}
			}
		} catch (Exception e) {
			subLogger.warn("Error while refreshing user in hazelcast", e);
		}
	}
	
	private BasicDBList excludeUserIfAlreadyEntitledForRole(BasicDBList usersToBeAdded, List<DBObject> newGrpRoleList) {
		BasicDBList userList = new BasicDBList();
		try {
			subLogger.info("Inside excludeUserIfAlreadyEntitledForRole usersToBeAdded : "+ usersToBeAdded.toString() + ", "
		+ newGrpRoleList.get(0).get(ROLE_KEY).toString() + ", "+newGrpRoleList.get(0).get("groupId"));
			Query<User> query = null;
			List<User> userObjList = null;
			query = mongoDatastore.createQuery(User.class).field("_id").in(usersToBeAdded).project("groupRoles", true);
			userObjList = query.find().toList();
			for (User user : userObjList) {
				List<GroupRole> userGroupRoleList = user.getGroupRoles();
				boolean roleExists = false;
				if(null != userGroupRoleList && !userGroupRoleList.isEmpty()){
					for(GroupRole groupRole : userGroupRoleList) {
						if(groupRole.getRole().equalsIgnoreCase(newGrpRoleList.get(0).get(ROLE_KEY).toString())
								&&  Objects.equals(groupRole.getGroupId(),newGrpRoleList.get(0).get("groupId"))) {
							roleExists = true;
							subLogger.info("User already has grouprole : "+user.getId() + ", "+ groupRole.getRole()+", "+groupRole.getGroupId());
							break;
						}
					}
				}
				if(!roleExists) {
					userList.add(user.getId());
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in excludeUserIfAlreadyEntitledForRole", e);
		}
		return userList;
		
	}

	//Existing method drafted for Reusing the code
	private void updateUserAdditionDetails(BasicDBList usersToBeAdded, DBCollection userCollection, DBObject newGrpRole, String grpRole) throws CommunicatorException
	{
		List<DBObject> groupRoleList = new ArrayList<DBObject>();
		newGrpRole.put(ROLE_KEY, grpRole);
		groupRoleList.add(newGrpRole);
		
		updateUserAdditionDetails(usersToBeAdded, userCollection, groupRoleList);
	}
	
	
	private void updateUserGroupRemoveDetails(List<Group> groupList, BasicDBList analystToBeRemoved, String role) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one//Sonar Fix remove unused parameter
	{
		String userId = "";
		
		if(analystToBeRemoved!=null && !analystToBeRemoved.isEmpty())
		{
			userId = (String) analystToBeRemoved.get(0);
		}
		
		boolean isGroupRoleAnalyst = role.equalsIgnoreCase(ANALYST);
		
		Query<User> userQuery = mongoDatastore.createQuery(User.class).filter("_id", userId);
		User user = userQuery.get();
		
		if(user==null)
		{
			subLogger.info("Invalid input data for updateUserGroupRemoveDetails");
			throw new CommunicatorException("Invalid input data. Please contact support.");
		}
		
		List<GroupRole> groupRoles = user.getGroupRoles();
		
		if(groupRoles==null)
		{
			subLogger.info("Invalid input data for updateUserGroupRemoveDetails with user= " + userId);
			throw new CommunicatorException("Invalid input data. Please contact support.");
		}
		
		for(Iterator<GroupRole> iterator = groupRoles.iterator(); iterator.hasNext();)
		{
			GroupRole grpRole = iterator.next();
			for(Group grp:groupList)
			{
				boolean isAnalystMatch=isGroupRoleAnalyst && grp.id.intValue() == grpRole.getGroupId().intValue();
				boolean isNonAnalystRoleMatch= ! isGroupRoleAnalyst && (grp.id.intValue() == grpRole.getGroupId().intValue() && role.equalsIgnoreCase(grpRole.getRole()));
				if(isAnalystMatch || isNonAnalystRoleMatch)
				{
					iterator.remove();
					break;
				}
				
			}
		}
		
		user.setGroupRoles(groupRoles);
		mongoDatastore.save(user);
		//saveUser Group details bulk
		HazelCastCacheIncrementalLoad.refreshUserCache(userId);

	}

	private void updateUserRemoveDetails(Group group, BasicDBList analystToBeRemoved, DBCollection userCollection, String role)
	{
		DBObject updateQuery;
		DBObject updateGroupRoleObj;
		DBObject deleteGroupRole = new BasicDBObject();
		deleteGroupRole.put("groupId", group.id);
		// removed the check for Anlayst role as part of QMA-1057
		deleteGroupRole.put(ROLE_KEY, role);

		updateGroupRoleObj = new BasicDBObject();
		updateGroupRoleObj.put("$pull", new BasicDBObject(GROUP_ROLES, deleteGroupRole));

		updateQuery = new BasicDBObject();
		updateQuery.put("_id", new BasicDBObject("$in", analystToBeRemoved));

		// Bulk Update call, updates all User's group roles matching the condition
		userCollection.updateMulti(updateQuery, updateGroupRoleObj);

		//Remove Group from assigned Groups list
		analystToBeRemoved.forEach(id -> {
			try {
				this.removeGroupFromDashboardSettings(group.getGroupName(), id.toString());
			} catch (CommunicatorException e) {
				subLogger.error("Exception in removing group from dashboard setting assignedGroups list", e);
			}
		});
	}

	private void updateDBGroupDetails(BasicDBList requestTypes, BasicDBList domainList, Group uiGroupPreferences, 
			Query<Group> queryGroup, String disclaimer, BasicDBObject heirarchyData, BasicDBList userAssignmentExclusionList,
			BasicDBList autoResponseDetails, BasicDBList rootCauseList, BasicDBList processingRegionsList, BasicDBList requestTypeMappings, BasicDBList subjectEscalationList, boolean isCustomizedAutoResponseEnabled, String customAutoResponseOptions) throws CommunicatorException
	{
		UpdateOperations<Group> updateOps = mongoDatastore.createUpdateOperations(Group.class);
		
		Boolean domainReqd = null;
		Boolean predictiveRecipients = null;
		Boolean attachmentIncluded = null;
		Boolean isEmailSharingBlocked = null;
		Boolean isRootCauseMandatory = null;
		Boolean isProcessingRegionMandatory = null;
		Boolean isInquirySourceMandatory = null;
		Boolean enableInquirySubStatus = null;
		Boolean isInqReferenceIdReq = null;
		Boolean enableXstreamIntegration = null;
		Boolean autoReplyEnable = null;
		// QMA-1442 START - Enhancement for adding more info in the auto response template
		Boolean includeAssignedUserInfo = null;
		Boolean includeUserContactInfo = null;
		Boolean includeManagerContactInfo = null;
		// QMA-1442 END
		Boolean isRootCauseMandatoryWOReply = null;
		Boolean isGfidMandatory = null;
		Boolean isUINotificationPopupEnabled = null;
		/*[C153176-1035] - Make Tag mandatory to resolve*/
		Boolean isTagMandatory = null;
		Integer convCountThresholdForEscalation = null;
		Integer responseTimeThresholdForEscalation = null;
		Integer paResponseTimeThresholdForEscalation = null;
		Boolean excludeMyGroupWhileReplyAll = null;
		Boolean enableAutoAssignment = null;
		Boolean isAutoResponseEnabledForInternalDomain = null;

		// C153176-5630 | Enable/disable client contact list visibility for group members
		Boolean hideClientList = null;
		
		// C153176-6148 | Group configuration : Re-age need supervisor approval
		Boolean supervisiorApprovalForReage = null;
		
		// C170665-10 : Request Type and Root Cause enable flag.
		Boolean requestTypeRootCauseFilter = null;
		Map<String, List<String>> requestTypeRootCauseMapping = null;
		GroupHolidayDetails groupHolidayDetails = null;
		String country = null;
		String timeZone = null;
		List<CustomClientCriteria> customClientCategory = null;
        Boolean isGroupManagerAboveL7 = null;
        String managerSoeId = null;
        Boolean enableAutoReplySuggestion = null;
		if(uiGroupPreferences!=null)
		{
			domainReqd = uiGroupPreferences.getMakerCheckerRqd();
			predictiveRecipients = uiGroupPreferences.getPredictiveRecipients();
			attachmentIncluded = uiGroupPreferences.getAttachmentBasedMakerChecker();
			isEmailSharingBlocked = uiGroupPreferences.getIsEmailSharingBlocked();
			isRootCauseMandatory = uiGroupPreferences.getIsRootCauseMandatory();
			isProcessingRegionMandatory = uiGroupPreferences.getIsProcessingRegionMandatory();
			isInquirySourceMandatory = uiGroupPreferences.getIsInquirySourceMandatory();
			isInqReferenceIdReq = uiGroupPreferences.getIsInqReferenceIdReq();
			enableXstreamIntegration = uiGroupPreferences.getEnableXstreamIntegration();
			autoReplyEnable = uiGroupPreferences.getAutoReplyEnable();
			// QMA-1442 START - Enhancement for adding more info in the auto response template
			includeAssignedUserInfo = uiGroupPreferences.getIncludeAssignedUserInfo();
			includeUserContactInfo = uiGroupPreferences.getIncludeUserContactInfo();
			includeManagerContactInfo = uiGroupPreferences.getIncludeManagerContactInfo();
			// QMA-1442 END
			isRootCauseMandatoryWOReply = uiGroupPreferences.getIsRootCauseMandatoryWOReply();
			isGfidMandatory = uiGroupPreferences.getIsGfidMandatory();
			isUINotificationPopupEnabled = uiGroupPreferences.getIsUINotificationPopupEnabled();
			/*[C153176-1035] - Make Tag mandatory to resolve*/
			isTagMandatory = uiGroupPreferences.getIsTagMandatory();
			convCountThresholdForEscalation = uiGroupPreferences.getConvCountThresholdForEscalation();
			responseTimeThresholdForEscalation = uiGroupPreferences.getResponseTimeThresholdForEscalation();
			paResponseTimeThresholdForEscalation = uiGroupPreferences.getPaResponseTimeThresholdForEscalation();
			excludeMyGroupWhileReplyAll = uiGroupPreferences.getExcludeMyGroupWhileReplyAll();
			enableInquirySubStatus = uiGroupPreferences.getEnableInquirySubStatus();//[C170665-1719] DCC Requirement: Add Case status field
			enableAutoReplySuggestion = uiGroupPreferences.isEnableAutoReplySuggestion();
			isAutoResponseEnabledForInternalDomain = uiGroupPreferences.isAutoResponseEnabledForInternalDomain();
			// C153176-5630 | Enable/disable client contact list visibility for group members
			hideClientList = uiGroupPreferences.getHideClientList();
			// C153176-6148 | Group configuration : Re-age need supervisor approval
			supervisiorApprovalForReage = uiGroupPreferences.getSupervisiorApprovalForReage();
			
			// C170665-10 : Request Type and Root Cause enable flag.
			requestTypeRootCauseFilter = uiGroupPreferences.getRequestTypeRootCauseFilter();
			if (null != uiGroupPreferences.getRequestTypeRootCauseMapping()) {
				requestTypeRootCauseMapping = uiGroupPreferences.getRequestTypeRootCauseMapping();
			}
			
			groupHolidayDetails = uiGroupPreferences.getHolidayAndShiftDetails();
			country = uiGroupPreferences.getCountry();
			timeZone = uiGroupPreferences.getTimeZone();
			if(uiGroupPreferences.getEscKeywords()!=null){
				updateOps.set(AppserverConstants.ESC_KEYWORD, uiGroupPreferences.getEscKeywords());
			}
			customClientCategory =  uiGroupPreferences.getCustomClientCategory();
			enableAutoAssignment = uiGroupPreferences.isEnableAutoAssignment();
			isGroupManagerAboveL7 = uiGroupPreferences.isGroupManagerAboveL7();
			managerSoeId = uiGroupPreferences.getManagerSoeId();
			
		}
		
		// Update Domain required in group collection for selected groupName
		updateOps.set("makerCheckerRqd", domainReqd);
		// Update Domain required in group collection for selected groupName
		//[C153176-426] Ability to block adding external clients to 'Top Contacts',
		updateOps.set("isEmailSharingBlocked", isEmailSharingBlocked);

		// Update Request type in group collection for selected groupName
		if (requestTypes != null)
		{
			updateOps.set("requestTypes", requestTypes);
		}
		if (requestTypeMappings != null)
		{
			updateOps.set("requestTypeMappings", requestTypeMappings);
		}
		// Update Domain data in group collection for selected groupName
		if (domainList != null)
		{
			updateOps.set("makerCheckerDomains", domainList);
		}
		
		//[C153176-777] - Add admin functionality for RootCause addition & updates to any group
		updateOps.set("isRootCauseMandatory", isRootCauseMandatory);
		updateOps.set("isRootCauseMandatoryWOReply", isRootCauseMandatoryWOReply);
		// Update RootCause data in group collection for selected groupName
		if (rootCauseList != null)
		{
			updateOps.set("rootCauseList", rootCauseList);
		}
		// Update processing region in group collection for selected groupName
		updateOps.set("isProcessingRegionMandatory", isProcessingRegionMandatory);
		if (processingRegionsList != null)
		{
			updateOps.set("processingRegionList", processingRegionsList);
		}
		//Update Disclaimer in group collection for selected groupName
		if(disclaimer != null)
		{
			updateOps.set("disclaimer", disclaimer);
		}
		
		//Update Group Hierarchy in group collection for selected groupName
		//[C153176-1704]-Ability for Group Admin to change Group Manager.
		if(heirarchyData != null)
		{
			List<BasicDBObject> thirdLevelHeirarchy = GenericUtility.getJsonObjFromRequest(heirarchyData, THIRD_LEVEL_HEIRARCHY);
			updateOps.set("heirarchyData.thirdLevelHeirarchy", thirdLevelHeirarchy);
		}
		
		if (subjectEscalationList != null)
		{
			updateOps.set("subjectEscalationList", subjectEscalationList);
		}
		
		// Update predictiveRecipients flag in group  for selected groupName
		updateOps.set("predictiveRecipients", predictiveRecipients);
		// Update attachmentBasedMakerChecker flag in group  for selected groupName
		updateOps.set("attachmentBasedMakerChecker", attachmentIncluded);
		if(autoResponseDetails != null)
		{
			updateOps.set("autoResponseDetails", autoResponseDetails);
		}
		if(userAssignmentExclusionList != null)
		{
		updateOps.set("userAssignmentExclusionList", userAssignmentExclusionList);
		}	
		updateOps.set("isInquirySourceMandatory", isInquirySourceMandatory);
		updateOps.set("isAutoResponseEnabledForInternalDomain", isAutoResponseEnabledForInternalDomain);

		//[C170665-1719] DCC Requirement: Add Case status field
		updateOps.set("enableInquirySubStatus", enableInquirySubStatus);
		updateOps.set(ENABLE_AUTO_REPLY_SUGGESTION, enableAutoReplySuggestion);
		updateOps.set("isInqReferenceIdReq", isInqReferenceIdReq);
		updateOps.set("enableXstreamIntegration", enableXstreamIntegration);
		updateOps.set("autoReplyEnable", autoReplyEnable);
		// QMA-1442 START - Enhancement for adding more info in the auto response template
		updateOps.set("includeAssignedUserInfo", includeAssignedUserInfo);
		updateOps.set("includeUserContactInfo", includeUserContactInfo);
		updateOps.set("includeManagerContactInfo", includeManagerContactInfo);
		// QMA-1442 END

		updateOps.set("isGfidMandatory", isGfidMandatory);
		updateOps.set("isUINotificationPopupEnabled", isUINotificationPopupEnabled);
		/*[C153176-1035] - Make Tag mandatory to resolve*/
		updateOps.set("isTagMandatory", isTagMandatory);
		if(convCountThresholdForEscalation != null)
		{
			updateOps.set("convCountThresholdForEscalation", convCountThresholdForEscalation);
		}
		else
		{
			updateOps.unset("convCountThresholdForEscalation");
		}
		if(responseTimeThresholdForEscalation != null)
		{
			updateOps.set("responseTimeThresholdForEscalation", responseTimeThresholdForEscalation);
		}
		else
		{
			updateOps.unset("responseTimeThresholdForEscalation");
		}
		if(paResponseTimeThresholdForEscalation != null)
		{
			updateOps.set("paResponseTimeThresholdForEscalation", paResponseTimeThresholdForEscalation);
		}
		else
		{
			updateOps.unset("paResponseTimeThresholdForEscalation");
		}
		updateOps.set("excludeMyGroupWhileReplyAll", excludeMyGroupWhileReplyAll);
		updateOps.set("includeMyGroupInCC", uiGroupPreferences.isIncludeMyGroupInCC());
		// C153176-5630 | Enable/disable client contact list visibility for group members
		updateOps.set("hideClientList", hideClientList);
		
		// C153176-6148 | Group configuration : Re-age need supervisor approval
		updateOps.set("supervisiorApprovalForReage", supervisiorApprovalForReage);
		
		// C170665-10 : Request Type and Root Cause enable/disable flag.
		updateOps.set("requestTypeRootCauseFilter", requestTypeRootCauseFilter);
		
		updateOps.set("holidayAndShiftDetails", groupHolidayDetails);
		updateOps.set("country", country);
		updateOps.set("timeZone", timeZone);
		if(customClientCategory != null){
			updateOps.set("customClientCategory", customClientCategory);
		}
		// C170665-10 : Update the Request Type and Root Cause Mapping
		if (null != requestTypeRootCauseMapping && requestTypeRootCauseMapping.size() > 0) {
			updateOps.set("requestTypeRootCauseMapping", requestTypeRootCauseMapping);
		} else {
			updateOps.unset("requestTypeRootCauseMapping");
		}

		if(null != enableAutoAssignment) {
			updateOps.set("enableAutoAssignment", enableAutoAssignment);
		}
        if (null != isGroupManagerAboveL7) {
			updateOps.set("isGroupManagerAboveL7", isGroupManagerAboveL7);
		}
        if (null != managerSoeId) {
        	updateOps.set("managerSoeId", managerSoeId);
        }
        
        // C170665-4031 - Allow "Automated Response" for a DL to be more customizable by User
        updateOps.set(IS_CUSTOMIZED_AUTO_RESPONSE_ENABLED, isCustomizedAutoResponseEnabled);
        updateOps.set(CUSTOM_AUTO_RESPONSE_OPTIONS, customAutoResponseOptions != null ? customAutoResponseOptions : "");
        
		UpdateResults result = mongoDatastore.update(queryGroup, updateOps);
		//CacheDAO.getInstance().reloadCache(); // As discussed with sunil, need to reload cache Either for inactive flag change for existing group or whenever new group is added.	
		Long groupId = null;
		if(null != queryGroup) {
			groupId = queryGroup.get().getId();	
		}
		HazelCastCacheIncrementalLoad.refreshGroupInCache(groupId);
		updateStaticDataGroupLastModifiedTimeToReloadServiceCache();
	}
	
	// Called from Group Setup Screen
	public Map<String, Object> saveGroupAdminInfo(String soeId, BasicDBObject inputJsonObjList) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Map<String, Object> returnObject = new HashMap<>();
		Group group = null;
		try
		{
			Map<String, User> userInfoMap = QMACacheFactory.getCache().getUserInfoMap();
			if (null == userInfoMap || soeId == null || null == userInfoMap.get(soeId.toUpperCase())) {
				subLogger.error("No Valid User found in QMA for {} ", soeId);
				throw new CommunicatorException("User doesn't have privilege to perform this action");
			}
			Config configAdminRoles = QMACacheFactory.getCache().getConfigById("AdminRoles");
			if (null == configAdminRoles || !GenericUtility.containsCaseInsensitive(soeId, configAdminRoles.getGroupSetupAdmin())) {
				subLogger.error("User {} doesn't have group setup privilege to perform this action ", soeId);
				throw new CommunicatorException("User doesn't have group setup admin privilege to perform this action");
			}
			String groupName = inputJsonObjList.getString(GROUP_NAME); //This is from the Form			
			Boolean isNewlyAdded =  Boolean.parseBoolean(inputJsonObjList.getString("isNewlyAdded"));
			BasicDBList adminUserList = (BasicDBList) inputJsonObjList.get("adminUser");
			Boolean isInactive = inputJsonObjList.getBoolean("isInactive");
			String email = inputJsonObjList.getString("email");
			String country =inputJsonObjList.getString("groupCountry");
			String timeZone =inputJsonObjList.getString("groupTimeZone");
			String managerSoeId = inputJsonObjList.getString("managerSoeId");
			// Expand Group setup screen to add level 1, 2 and 3 owners.
			BasicDBObject heirarchyData = (BasicDBObject) inputJsonObjList.get("heirarchyData");
			ManagementHeirarchy heirarchy = new ManagementHeirarchy();

			// populate heirarchy object for group
			if (heirarchyData != null)
			{
				// Need to make checks to prevent incorrect data save.
				List<String> organisation = (List<String>) heirarchyData.get("organisation");
				@SuppressWarnings("unchecked")
				List<HierarchyUserDetail> firstLevelHeirarchy = (List<HierarchyUserDetail>) heirarchyData.get("firstLevelHeirarchy");
				List<HierarchyUserDetail> secondLevelHeirarchy = (List<HierarchyUserDetail>) heirarchyData.get("secondLevelHeirarchy");
				List<HierarchyUserDetail> thirdLevelHeirarchy = (List<HierarchyUserDetail>) heirarchyData.get(THIRD_LEVEL_HEIRARCHY);
				
				Map<String, Object> globalDirConfig = globalDirectoryService.getGlobalDirectoryConfig();
                List<BasicDBObject> thirdLevelHeirarchyObject = GenericUtility.getJsonObjFromRequest(heirarchyData, THIRD_LEVEL_HEIRARCHY);
				String soeid = thirdLevelHeirarchyObject.get(0).getString("userId");
				String userName = null;
				String apiResponse = globalDirectoryService.fetchUserDetailsFromGlobDir(soeid, SOEID_KEY, globalDirConfig);
				if(apiResponse!=null) {
				    userName = globalDirectoryService.getNameFromApiResponse(apiResponse);
				    subLogger.info("GroupDao.saveGroupAdminInfo : L7 Mananger name from GD {} for group  : {}", userName,groupName );
				    thirdLevelHeirarchyObject.get(0).put("userName",userName);
				    heirarchyData.put(THIRD_LEVEL_HEIRARCHY, thirdLevelHeirarchyObject);
				    thirdLevelHeirarchy = (List<HierarchyUserDetail>) heirarchyData.get(THIRD_LEVEL_HEIRARCHY);
				}
				 if(apiResponse == null ) {
				     subLogger.info("Issue while calling GD API in GroupDAO.saveGroupAdminInfo. Populating user name from User Collection");
				 }	
				List<String> gfcId = (List<String>) heirarchyData.get("gfcid");
				
				// Validate hierarchy before save.
				// hierarchyDataValidation(organisation,firstLevelHeirarchy,secondLevelHeirarchy,thirdLevelHeirarchy,gfcId);
				heirarchy.setOrganisation(organisation);	
				heirarchy.setFirstLevelHeirarchy(firstLevelHeirarchy);
				heirarchy.setSecondLevelHeirarchy(secondLevelHeirarchy);
				heirarchy.setThirdLevelHeirarchy(thirdLevelHeirarchy);
				if (null != heirarchyData.get("orgHierarchy") && heirarchyData.get("orgHierarchy") instanceof List) {
	                List<HierarchyOrgDetails> orgHierarchy = (List<HierarchyOrgDetails>) heirarchyData.get("orgHierarchy");
	                if(!orgHierarchy.isEmpty()) {
	                	heirarchy.setOrgHierarchy(orgHierarchy);
	                }
				}
				heirarchy.setGfcid(gfcId);
			}
            
			subLogger.info("Inside GroupDAO:saveGroupAdminInfo - soeId= " + soeId + ", groupName= " + groupName);
			// Avoid Extra Spaces in the Folder Name
			groupName = groupName != null ? groupName.trim() : groupName;
			if (StringUtils.isBlank(groupName))
			{
				subLogger.info("Invalid input data for saveGroupAdminInfo with groupName= " + groupName);
				throw new CommunicatorException("Invalid input data");// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
			}
			// Get all the user list
			Date createdDate = new Date();

			// Get Group from DB
			/*
			 * Query<Group> queryGroup = mongoDatastore.createQuery(Group.class).filter("groupName", groupName); group = queryGroup.get();
			 */

			//List<Group> groupList = getAllGroupsAsList(groupName);
			
		
			List<Group> groupListByGroupName= getAllGroupsAsList(groupName);
			 
			boolean saveNewgroup = false;
			subLogger.info("isNewlyAdded is"+isNewlyAdded);

			String groupType = (String) inputJsonObjList.getOrDefault(GROUP_TYPE, "");
			if(StringUtils.isNotEmpty(groupType) && TASKIZE_GROUP_TYPE.equals(groupType)) {
				if ((groupListByGroupName != null && !groupListByGroupName.isEmpty())) {
					for (Group localgrp : groupListByGroupName) {
						if ((localgrp.getGroupName().equalsIgnoreCase(groupName))) {
							group = localgrp;
						}
					}
				}
			} else {
				List<Group> groupListByEmail = getAllGroupsAsListByEmail(email);
				if ((groupListByGroupName != null && !groupListByGroupName.isEmpty())
						|| (groupListByEmail != null && !groupListByEmail.isEmpty())) {
					for (Group localgrp : groupListByGroupName) {
						if ((localgrp.getGroupName().toUpperCase().equals(groupName.toUpperCase()))) {
							group = localgrp;
						}
					}

					for (Group localgrp : groupListByEmail) {
						if ((localgrp.getGroupEmail().toUpperCase().equals(email.toUpperCase()))) //
						{
							group = localgrp;
						}
					}
				}
			}
			
			saveNewgroup=isNewlyAdded && group == null;
			if (isNewlyAdded && group !=null) 
			{
				subLogger.info("GroupName or emailId already exists " + groupName + ":"+ email);
				returnObject.put("success", false);
				returnObject.put("group", group);
				return returnObject;
			}

			if (saveNewgroup)
			{
				group = new Group();
				group.setModBy(soeId);
				group.setCrtBy(soeId);
				group.setModDate(createdDate);
				group.setCrtDate(createdDate);
				group.setGroupEmail(email);
				group.setActive(!isInactive);
				group.setGroupName(groupName);
				// Predictive User Search Turned on By Default for New Group
				group.setPredictiveRecipients(true);
				// Expand Group setup screen to add level 1, 2 and 3 owners.
				group.setHeirarchyData(heirarchy);
				// C153176-1267 Auto set maker-checker for new groups
				updateMakerCheckerBasedOnOrganisation(group, heirarchy);
			}
			else
			{
				group.setActive(!isInactive); 
				group.setModBy(soeId);
				group.setModDate(createdDate);
				group.setGroupEmail(email);
				// Expand Group setup screen to add level 1, 2 and 3 owners.
				group.setHeirarchyData(heirarchy);
			}
			group.setManagerSoeId(managerSoeId);
			group.setCountry(country);
			group.setTimeZone(timeZone);
			/* Setting default GDPR record type for all DL's in QMA */
			group.setRecordCode(GDPR_RECORD_TYPE_SEC330);
			
			if(StringUtils.isNotEmpty(groupType) && TASKIZE_GROUP_TYPE.equals(groupType)) {
				group.setGroupType(groupType);
				MisReportConfig misReportConfig = new MisReportConfig();
				misReportConfig.setEnableReporting(false);
				group.setMisReportConfig(misReportConfig);
			}
			
			if(null != inputJsonObjList.get(MIS_REPORT_CONFIG)) {
				BasicDBObject misSettings = (BasicDBObject) inputJsonObjList.get(MIS_REPORT_CONFIG);
				MisReportConfig misReportConfig  = convertJsonToObject(misSettings);
				//expecting MisReportConfigChanged flag from UI 
				boolean misReportConfigChanged = false;
				if (null != misSettings.get(MIS_REPORT_CONFIG_CHANGED)) {
					misReportConfigChanged = misSettings.getBoolean(MIS_REPORT_CONFIG_CHANGED);
				}
				if(misReportConfigChanged) {
					group.setMisReportConfig(misReportConfig);
					//save MISExclusion
					saveMISExclusion(group, soeId, misReportConfig.getEnableReportingFromDate());
				}
			}
			mongoDatastore.save(group);
			
			DBCollection userCollection = mongoDatastore.getCollection(User.class);
			// Users to be added
			DBObject newGrpRole = createNewGroupRoleDBObject(soeId, group.id, createdDate);
			DBObject newSupervisorRole = createNewGroupRoleDBObject(soeId, group.id, createdDate);
			if (adminUserList != null)
				updateUserAdditionDetails(adminUserList, userCollection, newGrpRole, ADMIN);
			if (heirarchy.getThirdLevelHeirarchy() != null && !heirarchy.getThirdLevelHeirarchy().isEmpty())
			{
				addSupervisorRole(group, heirarchyData, saveNewgroup, userCollection, newSupervisorRole);
			}
			// Cache reload should be the last step
			//HazelCastCacheIncrementalLoad.refreshGroupInCache(group.getId(), saveNewgroup);
			//CacheDAO.getInstance().reloadCache(); // As discussed with sunil, need to reload cache Either for inactive flag change for existing group or whenever new group is added.
			HazelCastCacheIncrementalLoad.refreshGroupInCache(group.getId());
			updateStaticDataGroupLastModifiedTimeToReloadServiceCache();
		}
		catch (Exception e)
		{
			subLogger.error("Exception in GroupDAO.saveGroupAdminInfo", e);
			throw new CommunicatorException("Exception in GroupDAO.saveGroupAdminInfo");
		}

		returnObject.put("success", true);
		returnObject.put("group", group);
		return returnObject;

	}

	private MisReportConfig convertJsonToObject(BasicDBObject misSettings) {
		MisReportConfig misSettingsObject  = new MisReportConfig();
		if (null != misSettings.get(ENABLE_REPORTING)) {
			misSettingsObject.setEnableReporting(misSettings.getBoolean(ENABLE_REPORTING));
		}
		if (null != misSettings.get(ENABLE_REPORTING_FROM_DATE) && !misSettingsObject.isEnableReporting()) {
			Date parsedDate = getEnableReportingFromDate(misSettings.getString(ENABLE_REPORTING_FROM_DATE));
			misSettingsObject.setEnableReportingFromDate(parsedDate);
		}else{
			misSettingsObject.setEnableReportingFromDate(null);
		}
		return misSettingsObject;
	}

	/**
	 * @param enableReportingFromDate
	 * This method used to convert string date MM/dd/yyyy to Date 
	 * @return
	 */
	private Date getEnableReportingFromDate(String enableReportingFromDate) {
		Date date = null;
		try {
			if (null != enableReportingFromDate) {
				String dateFromUi = enableReportingFromDate;
				DateFormat sDate = new SimpleDateFormat("MM/dd/yyyy");
				sDate.setTimeZone(TimeZone.getTimeZone("GMT"));
				Date formattedValue = sDate.parse(dateFromUi);
				date = formattedValue;
			} 
		}catch(Exception ex) {
			subLogger.error("Error while parsing UI date:", ex);
		}
		return date;
	}

	/**
	 * @param group
	 * @param soeId
	 * @param reportEndDate
	 * This method is used to save/update MISReportExclusionRecord 
	 */
	private void saveMISExclusion(Group group, String soeId, Date reportEndDate) {
		try {
			Query<MISReportExclusionRecord> query = mongoDatastore.createQuery(MISReportExclusionRecord.class).filter("groupId", group.getId().intValue()).filter("active", true);
			MISReportExclusionRecord misReportExclusion = query.first();
			if( null != misReportExclusion && group.getId().intValue() == misReportExclusion.getGroupId()) {
				if(null != reportEndDate && null !=  misReportExclusion.getMisExclusionEndDate() 
						&& reportEndDate.getTime() != misReportExclusion.getMisExclusionEndDate().getTime()) {
					misReportExclusion.setMisExclusionEndDate(reportEndDate);
					misReportExclusion.setMisExclusionTimelineInMonths(getMisExclusionTimelineInMonths(misReportExclusion));
				}else if(null == reportEndDate){
					misReportExclusion.setMisExclusionEndDate(new Date());
					misReportExclusion.setMisExclusionTimelineInMonths(getMisExclusionTimelineInMonths(misReportExclusion));
				}
				misReportExclusion.setComments(EXCLUSION_REQUESTED_BY_GROUP_ADMIN);
				misReportExclusion.setModDate(new Date());
				misReportExclusion.setModBy(soeId);
			} else {
				misReportExclusion = new MISReportExclusionRecord();
				misReportExclusion.setActive(true);
				misReportExclusion.setComments(EXCLUSION_REQUESTED_BY_GROUP_ADMIN);
				misReportExclusion.setCrtBy(soeId);
				misReportExclusion.setGroupId(group.getId().intValue());
				misReportExclusion.setGroupName(group.getGroupName());
				if (null != reportEndDate) {
					misReportExclusion.setMisExclusionEndDate(reportEndDate);
				} else {
					Calendar c = Calendar.getInstance();
					c.setTime(new Date());
					c.add(Calendar.YEAR, 50);
					misReportExclusion.setMisExclusionEndDate(c.getTime());
				}
				misReportExclusion.setMisExclusionStartDate(new Date());
				misReportExclusion.setMisExclusionTimelineInMonths(getMisExclusionTimelineInMonths(misReportExclusion));
				misReportExclusion.setMisExclusionReason(EXCLUSION_REQUESTED_BY_GROUP_ADMIN);
				misReportExclusion.setMisExclusionReportName("Daily report");
				misReportExclusion.setModBy(soeId);
			}
			mongoDatastore.save(misReportExclusion);
		} catch (Exception e) {
			subLogger.error("Exception while saving MISReportExclusionRecord:",e);
		}
	}

	/**
	 * @param misReportExclusion
	 * This method used to return date diff in months
	 * @return
	 */
	private Integer getMisExclusionTimelineInMonths(MISReportExclusionRecord misReportExclusion) {
		Integer timelineInMonths = 0;
		try {
			LocalDate startDate = new java.sql.Date(misReportExclusion.getMisExclusionStartDate().getTime()).toLocalDate();
			LocalDate endDate = new java.sql.Date(misReportExclusion.getMisExclusionEndDate().getTime()).toLocalDate();
			Period diff = Period.between(startDate.withDayOfMonth(1), endDate.withDayOfMonth(1));
			timelineInMonths = diff.getMonths();
		}catch(Exception ex) {
			subLogger.error("Exception while getMisExclusionTimelineInMonths", ex);
		}
		return timelineInMonths;
	}

	/*
	 * 
	/*
	 * This method will enable Attachment based maker checker for group if Maker-checker is mandatory for its organization 
	 */
	private void updateMakerCheckerBasedOnOrganisation(Group group, ManagementHeirarchy heirarchy)
	{
		if(group != null && heirarchy != null)
		{
			List<String> organisation = heirarchy.getOrganisation();
			if(organisation !=null && !organisation.isEmpty())
			{
				List<String> mandatoryOrgs = QMACacheFactory.getCache().getDefaultStaticData().getMakerCheckerMandatoryOrgs();
				if(mandatoryOrgs !=null && !mandatoryOrgs.isEmpty())
				{
					for(String org: organisation)
					{
						if(mandatoryOrgs.contains(org))
						{
							// AttachmentBasedMakerChecker Turned on for New Group
							group.setMakerCheckerRqd(true);
							group.setAttachmentBasedMakerChecker(true);
							break;
						}
					}
				}
				
			}
		}
	}
	
 /*
 * This method will be used to add Supervisor role in the user collection.
 */
	private void addSupervisorRole(Group group, BasicDBObject heirarchyData, boolean saveNewgroup, DBCollection userCollection, DBObject newSupervisorRole) throws CommunicatorException
	{
		List<BasicDBObject> thirdLevelHeirarchy = (List<BasicDBObject>) heirarchyData.get(THIRD_LEVEL_HEIRARCHY);
		if (saveNewgroup)
		{
			updateSupervisorRole(userCollection, newSupervisorRole, thirdLevelHeirarchy);
		}
		else
		{
			String userId = (String) thirdLevelHeirarchy.get(0).get(USER_ID);
			DBObject findQuery = new BasicDBObject();
			findQuery.put("_id", userId);
			findQuery.put("active", true);
			BasicDBObject userElemMatchQuery = new BasicDBObject("groupId", group.id);
			userElemMatchQuery.put(ROLE_KEY, SUPERVISOR);
			findQuery.put(GROUP_ROLES, new BasicDBObject(AppserverConstants.ELEMENT_MATCH, userElemMatchQuery));
			DBCursor cur = userCollection.find(findQuery);
			if (!cur.hasNext())
			{
				updateSupervisorRole(userCollection, newSupervisorRole, thirdLevelHeirarchy);
			}
		}
	}

	private void updateSupervisorRole(DBCollection userCollection, DBObject newSupervisorRole, List<BasicDBObject> thirdLevelHeirarchy) throws CommunicatorException {
		BasicDBList supervisorUserList = new BasicDBList();
		supervisorUserList.add(thirdLevelHeirarchy.get(0).get(USER_ID));
		updateUserAdditionDetails(supervisorUserList, userCollection, newSupervisorRole, SUPERVISOR);
	}

	//Method to validate hierarchydata
	private void hierarchyDataValidation(List<String> organisation, List<String> firstLevelHeirarchy, List<String> secondLevelHeirarchy, List<String> thirdLevelHeirarchy, List<String> gfcId) throws CommunicatorException
	{
		// Check if the organisation contains comma. If it does, replace it with an empty string.
		
		boolean invalidOrgData = organisation!=null && organisation.size()==1 && organisation.get(0)!=null && organisation.get(0).contains(",");
		boolean invalidFirstLevelData = firstLevelHeirarchy!=null && firstLevelHeirarchy.size()==1  && firstLevelHeirarchy.get(0)!=null && firstLevelHeirarchy.get(0).contains(",");
		boolean invalidSecondLevelData = secondLevelHeirarchy!=null && secondLevelHeirarchy.size()==1  && secondLevelHeirarchy.get(0)!=null && secondLevelHeirarchy.get(0).contains(",");
		boolean invalidThirdLevelData = thirdLevelHeirarchy!=null && thirdLevelHeirarchy.size()==1  && thirdLevelHeirarchy.get(0)!=null && thirdLevelHeirarchy.get(0).contains(",");
		boolean invalidGfcIdData = gfcId!=null && gfcId.size()==1 && gfcId.get(0)!=null  && gfcId.get(0).contains(",");
		
		if(invalidOrgData || invalidFirstLevelData || invalidSecondLevelData || invalidThirdLevelData || invalidGfcIdData)
		{
			subLogger.error("Error occured in saving hierarchy data. Incorrect hierarchy data entered. "
					+ "Input Details: Business Segment="+(organisation!=null?organisation:null)
					+", First Level hierarchy="+(firstLevelHeirarchy!=null?firstLevelHeirarchy:null)
					+", Second Level hierarchy="+(secondLevelHeirarchy!=null?secondLevelHeirarchy:null)
					+", Third Level hierarchy="+(thirdLevelHeirarchy!=null?thirdLevelHeirarchy:null)
					+", GfcId="+(gfcId!=null?gfcId:null));
			
			throw new CommunicatorException("Error occured in saving hierarchy data. Incorrect hierarchy data entered.");
		}

	}

	
	//Method to save Inquiry Rules for Groups
	public BasicDBObject saveInquiryGroupRules(String soeId, BasicDBObject inputJsonObjList) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		BasicDBObject response = new BasicDBObject();
		String groupName = (String) inputJsonObjList.get(GROUP_NAME);
		subLogger.info("Inside GroupDAO:saveInquiryGroupRules - soeId= " + soeId + ", groupName= " + groupName);
		//Sonar fix -- remvoe useless assignment
		BasicDBList routeList =  (BasicDBList) inputJsonObjList.get("criteriaList");
		String lastDbVersion = inputJsonObjList.getString("version");
		if (StringUtils.isBlank(groupName))
		{
			subLogger.info("Invalid input data for saveInquiryGroupRules with groupName= " + groupName);
			throw new CommunicatorException("Invalid input data for saveInquiryGroupRules with groupName= " + groupName);
		}
		try
		{
			Query<Group> query = mongoDatastore.createQuery(Group.class).filter(GROUP_NAME, groupName);
			Group group = query.get();

			if (group == null)
			{
				subLogger.info("Invalid Group data for saveInquiryGroupRules with groupName= " + groupName);
				throw new CommunicatorException("Invalid Group data");// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
			}

			if (null != lastDbVersion && null != group.getVersion()
					&& !lastDbVersion.equals(group.getVersion().toString())) {
				response.put(AppserverConstants.MESSAGE_KEY, GROUP_DETAILS_ALREADY_UPDATED);
				response.put(AppserverConstants.SUCCESS_KEY, false);
				return response;
			}

			//C153176-5633 regarding restore button implementation for restore rules
			List<RoutingCriteria> newRuleRouteCriteriaList = getRuleRouteCriteria(routeList);//sonar fix - to reduce complexity less then 10

			List<RoutingCriteria> backupRuleRouteCriteriaList = group.getRoutes(); // Always get the backup first

			if (backupRuleRouteCriteriaList != null && !backupRuleRouteCriteriaList.isEmpty()) {
				group.setBackupRoutes(backupRuleRouteCriteriaList);
				Date currentTime = new Date();
				group.setBackupRouteDate(currentTime);
			}

			if (!newRuleRouteCriteriaList.isEmpty()) {
				group.setRoutes(newRuleRouteCriteriaList);
				saveGroupRoutingAudit(newRuleRouteCriteriaList, group.getGroupName(), group.id, group.getGroupEmail(), soeId);
			} else {
				// If newRuleRouteCriteriaList is empty, delete all routes
				group.setRoutes(new ArrayList<>());
				saveGroupRoutingAudit(new ArrayList<>(), group.getGroupName(), group.id, group.getGroupEmail(), soeId);
			}
			group.setModBy(soeId);
			mongoDatastore.save(group);
			// create new rules
			HazelCastCacheIncrementalLoad.refreshGroupInCache(group.getId());
		//	StaticData staticData = mongoDatastore.createQuery(StaticData.class).limit(1).get();
		//	if(staticData != null)
			//{
		//		Date currentTime = new Date();
				////staticData.setGroupLastModifiedTime(currentTime);
			response.put(AppserverConstants.SUCCESS_KEY, true);
			String version =  null != group.getVersion()?group.getVersion().toString():"";
			response.put(AppserverConstants.VERSION, version);
			updateStaticDataGroupLastModifiedTimeToReloadServiceCache();
		//		mongoDatastore.save(staticData);
		//	}
			
		}
		catch(Exception e)
		{
			subLogger.error("Exception in GroupDAO.saveInquiryGroupRules", e);
			throw new CommunicatorException("Exception in GroupDAO.saveInquiryGroupRules");
		}
		
		return response;
	}
	
	
	public BasicDBObject saveGroupHighlevelRequestTypes(String soeId, BasicDBObject inputJsonObjList) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
		{
			BasicDBObject response = new BasicDBObject();
			String groupName = (String) inputJsonObjList.get(GROUP_NAME);
			BasicDBList requestTypeMappingList =  (BasicDBList) inputJsonObjList.get("reqList");
			
			try
			{
				Query<Group> query = mongoDatastore.createQuery(Group.class).filter(GROUP_NAME, groupName);
				Group group = query.get();
				List<HighlevelRequestType> highlevelrequestTypeList = getHighLevelRequestTypeList(requestTypeMappingList);//sonar fix - to reduce complexity less then 10
				
				List<String> reqTypeList = new ArrayList<>();
				for (HighlevelRequestType req :highlevelrequestTypeList)
				{
					reqTypeList.add(req.getRequestType());
				}
				group.setRequestTypes(reqTypeList);
				group.setRequestTypeMappings(highlevelrequestTypeList);
				mongoDatastore.save(group);
				// request type mappings
				HazelCastCacheIncrementalLoad.refreshGroupInCache(group.getId());
				response.put(AppserverConstants.SUCCESS_KEY, true);
			}
			catch(Exception e)
			{
				subLogger.error("Exception in GroupDAO.saveGroupRequestTypes", e);
				throw new CommunicatorException("Exception in GroupDAO.saveGroupRequestTypes");
			}
			
			return response;
		}
		
		
		private  List<HighlevelRequestType> getHighLevelRequestTypeList(BasicDBList requestTypeMappingList ) throws CommunicatorException
		{
			List<HighlevelRequestType> highlevelRequestTypeList = new ArrayList<>();
			for (Object obj : requestTypeMappingList)
			{
				HighlevelRequestType highlevelRequestType = buildHighlevelRequestTypeObject((BasicDBObject) obj);
				if (highlevelRequestType != null)
				{
					highlevelRequestTypeList.add(highlevelRequestType);
				}
			}
			return highlevelRequestTypeList;
		}

		
		private HighlevelRequestType buildHighlevelRequestTypeObject(BasicDBObject obj) throws CommunicatorException
		{
			try
			{
				String requestType = obj.getString("requestType");
				String highlevelRequestType = obj.getString("highlevelRequestType");
				HighlevelRequestType hr = new HighlevelRequestType(requestType,highlevelRequestType);
				return hr;
			}
			catch(Exception e)
			{
				subLogger.error("Exception in GroupDAO.buildHighlevelRequestTypeObject", e);
				throw new CommunicatorException("Exception in GroupDAO.buildHighlevelRequestTypeObject", e);
			}
		}

	/**
	 * @param ruleRouteCriteriaList
	 * @param groupName
	 * 
	 * Audit to be added for Routing Criteria
     * Audit maintains all the previous route criteria along with the newly added ones.
     * When there are 0 rules coming from the UI (all rules deleted/,0 rules saved) no audit data is appended.
     * maxRuleRouteCriteriaListLimit is set to max 5000, if exceeds max limit, this will remove old records and update DB
	 * @param soeId 
	 * @param string 
	 * @param id 
	 */
	private void saveGroupRoutingAudit(List<RoutingCriteria> ruleRouteCriteriaList, String groupName, Long groupId, String groupEmail, String soeId)
	{
		GroupRoutingAudit groupRoutingAudit = null;
		ArrayList<RoutingCriteria> routingCriteriaList = null;
		int maxRuleRouteCriteriaListLimit = getMaxRuleRouteCriteriaListLimitFromConfig();
		try {
			Query<GroupRoutingAudit> query = mongoDatastore.createQuery(GroupRoutingAudit.class).filter(GROUP_NAME,groupName);
			groupRoutingAudit = query.get();
			if (groupRoutingAudit == null) {
				subLogger.info("Invalid Group data for saveInquiryGroupRules with groupName= " + groupName);
				groupRoutingAudit = new GroupRoutingAudit(groupId, groupName, groupEmail, ruleRouteCriteriaList);
				groupRoutingAudit.setCrtBy(soeId);
			} else {
				
				if (groupRoutingAudit.getRoutesAudit() != null && !groupRoutingAudit.getRoutesAudit().isEmpty())
				{
					// [C153176-1144]-GroupAudit size restriction of latest 5000 records limit.
					if (groupRoutingAudit.getRoutesAudit().size() > maxRuleRouteCriteriaListLimit) {
						int elementsToRemovedCount = groupRoutingAudit.getRoutesAudit().size()
								- maxRuleRouteCriteriaListLimit;

						routingCriteriaList = new ArrayList<RoutingCriteria>();
						routingCriteriaList = (ArrayList<RoutingCriteria>) groupRoutingAudit.getRoutesAudit();

						routingCriteriaList.subList(0, elementsToRemovedCount).clear();
						routingCriteriaList.addAll(ruleRouteCriteriaList);
						groupRoutingAudit.setRoutesAudit(routingCriteriaList);
					} else 
					{
						groupRoutingAudit.getRoutesAudit().addAll(ruleRouteCriteriaList);
					}
				} else 
				{
					groupRoutingAudit.setRoutesAudit(ruleRouteCriteriaList);
				}

			}
		} catch (Exception e) {
			subLogger.error("Exception in GroupDAO.saveGroupRoutingAudit", e);
		}
		groupRoutingAudit.setModBy(soeId);
		mongoDatastore.save(groupRoutingAudit);
	}
	
	private  List<RoutingCriteria> getRuleRouteCriteria(BasicDBList routeList) throws CommunicatorException
	{
		List<RoutingCriteria> ruleRouteCriteriaList = new ArrayList<RoutingCriteria>();
		for (Object obj : routeList)
		{
			RoutingCriteria rc = buildRuleCriteriaObject((BasicDBObject) obj);
            ruleRouteCriteriaList.add(rc);
        }
		return ruleRouteCriteriaList;
	}
	
	
	
	private RoutingCriteria buildRuleCriteriaObject(BasicDBObject obj) throws CommunicatorException
	{
		try
		{
			subLogger.info("Inside buildRuleCriteriaObject building Rule routing Criteria");
			
			String from = obj.getString("from");
			String fromOperator = obj.getString("fromOperator");
			String subject = obj.getString("subject");
			String subjectOperator = obj.getString("subjectOperator");
				//Enhance the inquiry rules to include the TO field.
			String to = obj.getString("to");
			String toOperator = obj.getString("toOperator");
			Date createdTime = new Date();
			//[C153176-356] - Setting inquiry rules order
			int ruleOrder = obj.get("ruleOrder") != null ? (int) obj.get("ruleOrder") : 0;
			
			BasicDBObject action = (BasicDBObject) obj.get("actions");
			//build RuleAction obj
			Boolean markAsNonInquiry = action.getBoolean("markAsNonInquiry");
			boolean attachmentRule = obj.getBoolean("attachment");
			String assignToUserId = action.getString("assignToUserId");
			Boolean markForDeletion = action.getBoolean("markForDeletion");
			String assignRequestType = action.getString("assignRequestType");
			String assignToTag = action.getString("assignToTag");
			String assignGroup = action.getString("assignGroup");
			String assignProcessingRegion = action.getString("assignProcessingRegion");
			
			RuleAction actions = new RuleAction(assignToUserId, assignRequestType, markAsNonInquiry, markForDeletion, assignToTag, assignGroup,assignProcessingRegion);
				//Enhance the inquiry rules to include the TO field.
			RoutingCriteria rc = new RoutingCriteria(from,fromOperator,subject,subjectOperator, to ,toOperator,actions,createdTime,ruleOrder,attachmentRule);
			
			return rc;
		
		}
		catch(Exception e)
		{
			subLogger.error("Exception in GroupDAO.buildRuleCriteriaObject", e);
			//throw e;
			throw new CommunicatorException("Exception in GroupDAO.buildRuleCriteriaObject", e);
		}
	}
	
	private void updateStaticDataGroupLastModifiedTimeToReloadServiceCache()
	{
		// Added a new flag to realod the XsTream comm process cache.
		BasicDBObject refreshTime = new BasicDBObject();
		refreshTime.put("groupLastModifiedTime", new Date());
		BasicDBObject updateStaticData = new BasicDBObject();
		updateStaticData.put("$set", refreshTime);
		mongoDatastore.getCollection(StaticData.class).update(new BasicDBObject("_id", 1), updateStaticData);
	}

	//Method to add multiple groups to user profile in bulk.
	public Boolean saveUserGroupBulk(String soeId, BasicDBObject inputJsonObjList) throws CommunicatorException
	{
		boolean success = false;
		BasicDBList userIdToAdd = (BasicDBList) inputJsonObjList.get(USER_ID);
		String groupRole = inputJsonObjList.getString("groupRole");
		List<String> groupListToAdd = (List<String>) inputJsonObjList.get("groupListToAdd");
		List<String> groupListToRemove = (List<String>) inputJsonObjList.get("groupListToRemove");
		
		
		try
		{
			subLogger.info("Taking the list of groups and adding it to the user profile : "+userIdToAdd);
			Date createdDate = new Date();
			//sonar fix -- remove the useless assignments..
			DBCollection userCollection = mongoDatastore.getCollection(User.class);
			
			//Add and remove groups for user.
			QMACache qmaCache = QMACacheFactory.getCache();
			Map<String, Long> groupCodeToIdMap = qmaCache.getGroupCodeToIdMap();
			if (groupListToAdd != null && !groupListToAdd.isEmpty())//Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
			{
				List<DBObject> grpRoleList = new ArrayList<DBObject>();
				for (String group : groupListToAdd)
				{
					Long groupId = groupCodeToIdMap.get(group.toUpperCase());
					DBObject newGrpRole = createNewGroupRoleDBObject(soeId, groupId, createdDate);
					newGrpRole.put(ROLE_KEY, groupRole);
					grpRoleList.add(newGrpRole);
				}
				
				updateUserAdditionDetails(userIdToAdd, userCollection, grpRoleList);
				success = true;
			}
			
			if(groupListToRemove!=null && !groupListToRemove.isEmpty())//Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
			{
				List<Group> groupList = new ArrayList<Group>();
				for(String group:groupListToRemove)
				{
					Query<Group> queryGroup = mongoDatastore.createQuery(Group.class).filter(GROUP_NAME, group);
					Group grp = queryGroup.get();
					
					groupCodeToIdMap.get(group.toUpperCase());
					groupList.add(grp);
				
				}
				
				updateUserGroupRemoveDetails(groupList, userIdToAdd, groupRole);
				success = true;
			}
			
		}
		catch(Exception e)
		{
			subLogger.error("Exception in GroupDAO.saveUserGroupBulk", e);
			throw new CommunicatorException("Exception in GroupDAO.saveUserGroupBulk", e);
		}
		
		return success;
	}
	
	//Method to add tags to Group collection
	public boolean addGroupTags(String userId, Group group, BasicDBList tagNameList, Query query) throws CommunicatorException
	{

		UpdateOperations<Group> ops = null;
		List<String> tagList = new ArrayList<String>();
		
		try
		{
			for(Object tagObj:tagNameList)
			{
				tagList.add((String)tagObj);
			}
			
			for(String tagName:tagList)
			{
				subLogger.info("Inside UserDao.addGroupTags for userId= " + userId + " tagName=" + tagName);
				//Avoid Extra Spaces in the Tag Name
				tagName=tagName!=null?tagName.trim():tagName;
				if (!StringUtils.isEmpty(tagName))
				{
					ops = mongoDatastore.createUpdateOperations(Group.class);
	
					// Find Group Query
	
					if (group != null && !StringUtils.isEmpty(tagName))
					{
						List<String> tags = group.getTags();
						if (tags == null)
						{
							// First Group Tag creation
							tags = new ArrayList<String>();
							tags.add(tagName);
							ops.set("tags", tags);
						}
						else
						{
							ops.add("tags", tagName, false);
						}
						mongoDatastore.update(query, ops);
					}
				}
			
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in addGroupTags", e);
			//throw e;
			throw new CommunicatorException("Exception in addGroupTags", e);
		}
		return true; 
	}
	
	//TODO: Need to make changes to the below methods for tags
	// Method to edit Group Tags. Replace the existing tag in Group & Inquiry collection
	public boolean editGroupTags(Group group, BasicDBList tagNameList) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one//Sonar fix -- remove unused parameter
	{

		boolean success = true;
		DBCollection groupCollection = null;
		DBCollection inquiryCollection = null;
		List<BasicDBObject> tagObjList = new ArrayList<BasicDBObject>();
		String groupName = null;

		try
		{

			groupName = group.getGroupName();
			
			//Convert to basicdbobject
			for (Object tagList : tagNameList)
			{
				tagObjList.add((BasicDBObject) tagList);
			}

			for (BasicDBObject tagInputObj : tagObjList)
			{

				String tagName = tagInputObj.getString("tagName");
				String newTagName = tagInputObj.getString("newtagName");
				subLogger.info("Inside UserDao.editGroupTag for group= " + groupName + ", tagName=" + tagName);

				// If the group/tag name is invalid, stop processing further.
				if (StringUtils.isBlank(groupName) || StringUtils.isBlank(tagName) || StringUtils.isBlank(newTagName))
				{
					subLogger.error("Invalid input for editGroupTag for group=" + groupName);
					throw new CommunicatorException("Invalid input for editGroupTag.");// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
				}

				// Step 1 : Find the Group collection and change the folder name.
				groupCollection = mongoDatastore.getCollection(Group.class);

				BasicDBObject groupTagObj = new BasicDBObject();
				groupTagObj.put("tags", tagName);
				groupTagObj.put("_id", group.id);

				DBObject updateGroupTagObj = new BasicDBObject();
				updateGroupTagObj.put("$set", new BasicDBObject("tags.$", newTagName));

				groupCollection.updateMulti(groupTagObj, updateGroupTagObj);

				// Step 2: Find the inquiry collections having the folder name and rename it.
				inquiryCollection = mongoDatastore.getCollection(Inquiry.class);

				BasicDBObject tagObj = new BasicDBObject();
				tagObj.put("tag", tagName);
				tagObj.put("assignedGroupId", group.id);

				BasicDBObject filterInqQuery = new BasicDBObject();
				filterInqQuery.put("workflows", new BasicDBObject(AppserverConstants.ELEMENT_MATCH, tagObj));

				DBObject updateinquiryFolderObj = new BasicDBObject();
				updateinquiryFolderObj.put("$set", new BasicDBObject("workflows.$.tag", newTagName));

				Long currTimeInMill = new Date().getTime();
				inquiryCollection.updateMulti(filterInqQuery, updateinquiryFolderObj);

				int inqCountToBeModfied = inquiryCollection.find(filterInqQuery).count();
				subLogger.info("Time before update process started :" + currTimeInMill  + " milli seconds, Number of inquiries to be updated:"+ inqCountToBeModfied+",Total time taken to update: "+ (new Date().getTime() - currTimeInMill)  + " milli seconds");
			}

		}
		catch (Exception e)
		{
			subLogger.error("Exception in editGroupTags", e);
			throw new CommunicatorException("Exception in editGroupTags",e);
		}

		return success;
	}
	
	//Method to delete Group Tags
	public boolean deleteGroupTags(String userId, Group group, BasicDBList tagNameList, Query<Group> query) throws CommunicatorException// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{

		DBCollection inquiryCollection = null;
		List<String> deletedTagList = new ArrayList<String>();

		try
		{
			for (Object tagObj : tagNameList)
			{
			    deletedTagList.add((String) tagObj);
			}

            // Step 1: Find the group collection and remove the tag
            if (null!= group && !deletedTagList.isEmpty() )
            {
                // Load group from DB and do update operation
                Group dbGroup = getGroupInfo(group.getGroupName());
                removeTagsFromRoutes(dbGroup,deletedTagList);
            }
            
			for (String tagName : deletedTagList)
			{
				subLogger.info("Inside UserDao.deleteGroupTags for userId= " + userId + " tagName=" + tagName);

				// If the folder name is invalid, stop processing further.
				if (StringUtils.isBlank(tagName))
				{
					subLogger.error("Invalid input for deleteGroupTags for user=" + userId);
					throw new CommunicatorException("Invalid input for deleteGroupTags.");// Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
				}

				// Step 2: Find the inquiries containing the folder name and unset them.
				inquiryCollection = mongoDatastore.getCollection(Inquiry.class);

				BasicDBObject tagObj = new BasicDBObject();
				tagObj.put("tag", tagName);
				tagObj.put("assignedGroupId", group.id);
				
				BasicDBObject filterInqQuery = new BasicDBObject();
				filterInqQuery.put("workflows", new BasicDBObject(AppserverConstants.ELEMENT_MATCH, tagObj));

				DBObject updateinquiryFolderObj = new BasicDBObject();
				updateinquiryFolderObj.put("$unset", new BasicDBObject("workflows.$.tag", tagName));

				inquiryCollection.updateMulti(filterInqQuery, updateinquiryFolderObj);
			}
		}
		catch (Exception e)
		{
			subLogger.error("Exception in deleteGroupTags", e);
			throw new CommunicatorException("Exception in deleteGroupTags",e);
		}
		return true;
	}

	 /**
	 * remove tags from Inquiry rules
     * @param group
     * @param tagList
     */
	public void removeTagsFromRoutes(Group group, List<String> deletedTagList)
    {
    	if(null == group) {
    		return;
    	}
        List<RoutingCriteria> routesList = group.getRoutes();

        if ( null != group.getTags() && null != deletedTagList)
        {
            group.getTags().removeAll(deletedTagList);
            
            if(null != routesList) {
	            for (RoutingCriteria route : routesList)
	            {
	                RuleAction action = route.getActions();
	
	                if (deletedTagList.contains(action.getAssignToTag()))
	                {
	                    action.setAssignToTag(null);
	                }
	            }
            }
            
            mongoDatastore.save(group);
            //remove tags
            //HazelCastCacheIncrementalLoad.refreshGroupInCache(group.getId());
            updateStaticDataGroupLastModifiedTimeToReloadServiceCache();
        }
    }
    
	//Save master data 
	public Boolean saveManagementHeirarchy(String soeId,BasicDBObject inputJsonObjList) throws CommunicatorException {
		
		boolean success = true;
		BasicDBObject heirarchyData = null;
		
		try
		{
			heirarchyData  = (BasicDBObject) inputJsonObjList.get("heirarchyData");
			BasicDBObject usersDeleted = (BasicDBObject) inputJsonObjList.get("deleteList");
			BasicDBList orgDeleteList = (BasicDBList) usersDeleted.get("orgDeleteList");
			BasicDBList firstLevelHeirarchyDeleteList = (BasicDBList) usersDeleted.get("lev1DeleteList");
			BasicDBList secondLevelHeirarchyDeleteList = (BasicDBList) usersDeleted.get("lev2DeleteList");
			BasicDBList gfcidDeleteList = (BasicDBList) usersDeleted.get("gfcidDeleteList");
		
			if(orgDeleteList!=null && !orgDeleteList.isEmpty())
				deleteGroupHeirarchyData(orgDeleteList,"heirarchyData.organisation");
			
			if(firstLevelHeirarchyDeleteList!=null && !firstLevelHeirarchyDeleteList.isEmpty())
				deleteGroupHeirarchyData(firstLevelHeirarchyDeleteList,"heirarchyData.firstLevelHeirarchy");

			if(secondLevelHeirarchyDeleteList!=null && !secondLevelHeirarchyDeleteList.isEmpty())
				deleteGroupHeirarchyData(secondLevelHeirarchyDeleteList,"heirarchyData.secondLevelHeirarchy");
			
			if(gfcidDeleteList!=null && !gfcidDeleteList.isEmpty())
				deleteGroupHeirarchyData(gfcidDeleteList,"heirarchyData.gfcid");
			
			mongoDatastore.getCollection(ManagementHeirarchy.class).update(new BasicDBObject("_id",1),heirarchyData);
			
		}
		catch(Exception e)
		{
			throw new CommunicatorException("Exception in saving management heirarchy actioned by "+soeId,e);
		}
		
		return success;
	}

	private void deleteGroupHeirarchyData(BasicDBList usersDeleted, String level) 
	{
		DBCollection groupCollection;
		BasicDBObject updateObj;
		BasicDBObject filterObj;
		
		groupCollection = mongoDatastore.getCollection(Group.class);
		filterObj = new BasicDBObject(level, new BasicDBObject("$in", usersDeleted));
		//Update the field to empty array
		updateObj = new BasicDBObject(level, new Object[0]);
		BasicDBObject upObj = new BasicDBObject("$set",updateObj);
		
		groupCollection.updateMulti(filterObj, upObj);
	}

	//Get master data 
	public ManagementHeirarchy getManagementHeirarchy(String soeId) throws CommunicatorException 
	{
		ManagementHeirarchy managementHeirarchy = null;
		
		try
		{
			managementHeirarchy = mongoDatastore.createQuery(ManagementHeirarchy.class).filter("_id", 1).get();
		}
		catch(Exception e)
		{
			throw new CommunicatorException("Exception in getting management heirarchy actioned by :"+soeId,e);
		}
		return managementHeirarchy;
	}
	
	public Long saveGroupInfo(Group group) throws CommunicatorException
	{

		try
		{
			Long grpid = persist(group);
			return grpid;
		}
		catch (Exception e)
		{
			subLogger.error("Exception in GroupDAO.saveGroupInfo", e);
			throw new CommunicatorException("Exception in GroupDAO.saveGroupInfo",e);
		}	

	}
	
	public Group getGroupInfo(String groupName) throws CommunicatorException
	{
		Group group = null;
		try
		{
			//String query = Pattern.quote(groupName)+"$";
			//Query<Group> queryGroup = mongoDatastore.createQuery(Group.class).field(GROUP_NAME).containsIgnoreCase(query).limit(1);
			Query<Group> queryGroup = mongoDatastore.createQuery(Group.class).field(GROUP_NAME).endsWithIgnoreCase(groupName).limit(1);
			group = queryGroup.get();

		}
		catch (Exception e)
		{
			throw new CommunicatorException("Exception in getting groupName from Group Collection",e);
		}

		return group;
	}
	

	public List<Group> getAllGroupsAsList(String groupName) throws CommunicatorException
	{
		 List<Group> groupList = null;
		try
		{
			//String query = Pattern.quote(groupName)+"$";
			//Query<Group> queryGroup = mongoDatastore.createQuery(Group.class).field(GROUP_NAME).containsIgnoreCase(query);
			Query<Group> queryGroup = mongoDatastore.createQuery(Group.class).field(GROUP_NAME).endsWithIgnoreCase(groupName);
			groupList = queryGroup.find().toList();	

		}
		catch (Exception e)
		{
			throw new CommunicatorException("Exception in getting getAllGroupsAsList from Group Collection",e);
		}

		return groupList;
	}
	
	public List<Group> getAllGroupsAsListByEmail(String email) throws CommunicatorException
	{
		 List<Group> groupListByEmail = null;
		try
		{
			//String query = Pattern.quote(email)+"$";
			//Query<Group> queryGroup = mongoDatastore.createQuery(Group.class).field(GROUP_EMAIL).containsIgnoreCase(query);
			Query<Group> queryGroup = mongoDatastore.createQuery(Group.class).field(GROUP_EMAIL).endsWithIgnoreCase(email);
			//query = mongoDatastore.createQuery(User.class).filter("email", emailID);
			groupListByEmail = queryGroup.find().toList();	

		}
		catch (Exception e)
		{
			throw new CommunicatorException("Exception in getting getAllGroupsAsListByEmail from Group Collection",e);
		}

		return groupListByEmail;
	}

	public Group getGroupDataById(BasicDBObject inputJsonObjList) throws CommunicatorException {
		Group group = null;
		String groupName = inputJsonObjList.getString(GROUP_NAME);

		try {
			Query<Group> query = mongoDatastore.createQuery(Group.class).filter(GROUP_NAME, groupName);
			group = query.get();
		} catch (Exception e) {
			subLogger.info("Invalid data for getGroupDataById with groupName= {}",groupName);
			throw new CommunicatorException("Exception retrieving group data in the method getGroupDataById:" + e);
		}
		
		// C170665-4031 - Allow "Automated Response" for a DL to be more customizable by User
		QMACache qmaCache = QMACacheFactory.getCache();
		Config configById = qmaCache.getConfigById("AutoResponse");
		if (null != configById) {
			subLogger.info("getGroupDataById :: AutoResponse :: Not Null :: {}", configById);
			
			List<String> customKeywordsForAutoResponse = configById.getCustomKeywordsForAutoResponse();
			if(customKeywordsForAutoResponse != null) {
				
				subLogger.info("getGroupDataById :: customKeywordsForAutoResponse :: Not Null");
				group.setCustomKeywordsForAutoResponse(customKeywordsForAutoResponse);
			}
		}
		return group;
	}

	//Method to save MIS report data
	public List<DBObject> saveReportDataForMIS(BasicDBObject inputJsonObjList, String soeId) throws CommunicatorException
	{
		String reportType = "";
		String reportStartDate = null;
		String reportEndDate = null;
		Date startDate = null;
		Date endDate = null;
		UserReportRequest userReportRequest = null;
		BasicDBList groupList = null;
		List<String> groupListArray = new ArrayList<String>();
		List<DBObject> reportListForUser = new ArrayList<DBObject>();
		
		try
		{
			reportType = inputJsonObjList.getString("reportType");
			groupList = (BasicDBList) inputJsonObjList.get(GROUP_LIST_KEY);
			
			if(StringUtils.isBlank(reportType) || (groupList==null))
			{
				subLogger.error("Invalid input for request MIS Report for user=" + soeId);
				throw new CommunicatorException("Invalid input for request MIS Report.");
			}
			
			reportStartDate = inputJsonObjList.getString("startDate");
			  
			DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
			df1.setTimeZone(TimeZone.getTimeZone("GMT"));	
			startDate = df1.parse(reportStartDate);
			
			reportEndDate = inputJsonObjList.getString("endDate");
			endDate = df1.parse(reportEndDate);
			
			if(!groupList.isEmpty())
			{
				for(Object group:groupList)
				{
					groupListArray.add((String) group);
				}
			}
			
			if(!groupListArray.isEmpty())
			{
				userReportRequest = new UserReportRequest(soeId, reportType, startDate, endDate, groupListArray, false);
				mongoDatastore.save(userReportRequest);
			}
			else
			{
				subLogger.info("Invalid group data for saveReportDataForMIS with report type= " + reportType);
	     	    throw new CommunicatorException("Invalid group data in the method saveReportDataForMIS:");
			}
			
			//Get report data for the user
			reportListForUser = getMISReportDataForUser(soeId);
						
		}
		catch(Exception e)
		{
			subLogger.info("Invalid data for saveReportDataForMIS with report type= " + reportType);
     	    throw new CommunicatorException("Exception saving group data in the method saveReportDataForMIS:",e);
		}
		
		return reportListForUser;
	}
	
	public List<DBObject> getMISReportDataForUser(String soeId) throws CommunicatorException
	{
		
		List<DBObject> reportListForUser = new ArrayList<DBObject>();
		
		try
		{
			//Get report data for the user
			DBCollection userReqRport =  mongoDatastore.getCollection(UserReportRequest.class);
			
			reportListForUser = userReqRport.find(new BasicDBObject(USER_ID,soeId)).sort(new BasicDBObject("crtDate",-1)).limit(40).toArray();
			
		}
		catch(Exception e)
		{
			subLogger.info("Invalid data for getReportDataForMIS with soeid= " + soeId);
     	    throw new CommunicatorException("Exception retrieving report data in the method getReportDataForMIS:"+e);
		}
		
		return reportListForUser;
	}

	public boolean downloadReportDataForMIS(BasicDBObject inputJsonObjList, String soeId) throws CommunicatorException
	{
		String fileName = null;
		try
		{
			fileName = inputJsonObjList.getString("fileName");
			
			//Find the appropriate bucket and get the file 
			GridFS gridFSFile = new GridFS(mongoDatastore.getDB(),"misReport");
			
			GridFSDBFile dbFile = gridFSFile.findOne(fileName);
			
			if(dbFile == null)
			{
				subLogger.info("File Name not found= " + fileName+". User: "+soeId);
				throw new CommunicatorException("Exception retrieving file in the method downloadReportDataForMIS with File Name not found="+fileName);
			}
			File file=GenericUtility.createFile(fileName);
			dbFile.writeTo(file);
			
		}
		catch(Exception e)
		{
			subLogger.info("Invalid data for getReportDataForMIS with file name= " + fileName);
     	    throw new CommunicatorException("Exception retrieving group data in the method downloadReportDataForMIS with filename:"+fileName+" and exception "+e);
		}
		
		return true;
	}
	
	/**
	 * @param groupIds
	 * @return Map
	 * @throws CommunicatorException
	 */
	public Map<String,List<String>> getRequestTypesforGroups(Set<Long> groupIds) throws CommunicatorException
    {
        try
        {
            Map<String,List<String>> groupRequestTypesMap = new HashMap<>();
            String [] retrivesFields ={"requestTypes",GROUP_NAME};
            Set<String> requestTypeSet ;
            
            Query<Group> query = mongoDatastore.createQuery(Group.class).filter(STATUS_ACTIVE, true);
            query.criteria("id").in(groupIds);           
            query.retrievedFields(true, retrivesFields);
                        
            List<Group> groupList = query.find().toList();
            for (Group grp : groupList)
            {
                requestTypeSet = new HashSet<>();
                if (grp.getRequestTypes() != null)
                {
                    requestTypeSet.addAll(grp.getRequestTypes());
                }
                
                groupRequestTypesMap.put(grp.getGroupName(), new ArrayList<>(requestTypeSet));
            }
            return groupRequestTypesMap;
        }
        catch (Exception e)
        {
            subLogger.error("Exception in GroupDAO.getRequestTypesforGroups", e);
            throw new CommunicatorException("Exception in GroupDAO.getRequestTypesforGroups", e);
        }
    }

	//C153176-687 - XSC - Cannot download Rules PDF
	public File downloadReportDataForInquiryRules(BasicDBObject inputJsonObjList, String soeId) throws CommunicatorException, IOException
	{
		BufferedWriter bw = null;
		FileWriter fw = null;
		File file = null;
		
		try
		{
			String groupName = inputJsonObjList.getString(GROUP_NAME);
			List<RoutingCriteria> routes = new ArrayList<RoutingCriteria>();
			
			if(groupName==null)
			{
				subLogger.error("Exception occurred inside the method groupDao.downloadReportDataForInquiryRules. The group name should not be null.");
				throw new CommunicatorException("Exception occurred inside the method groupDao.downloadReportDataForInquiryRules. The group name should not be null.");
			}

			Group group = getGroupDataById(inputJsonObjList);
			
			if(group==null)
			{
				subLogger.debug("Group details not found in db for groupName:"+groupName);
				throw new CommunicatorException("Exception occurred inside the method groupDao.downloadReportDataForInquiryRules. Group details not found in db for groupName");
			}
			else
			{
				String fileName = "Inquiry Rules.csv";
				file = GenericUtility.createFile(fileName);
				
				if(!file.exists())
					file.createNewFile();
				
				fw = new FileWriter(file.getAbsoluteFile());
				bw = new BufferedWriter(fw);
				
				routes = group.getRoutes();
				createRuleReportForDownload(bw,groupName,routes);
			}
		}
		catch(Exception e)
		{
			subLogger.error("Exception occurred inside the method groupDao.downloadReportDataForInquiryRules for user: "+soeId, e);
			throw new CommunicatorException("Exception occurred inside the method groupDao.downloadReportDataForInquiryRules for user: "+soeId);
		}
		finally
		{
			if(bw!=null)
				bw.close();
			if(fw!=null)
				fw.close();
		}
		
		return file;
	}

	//Method to create rule report data file for user download
	private void createRuleReportForDownload(BufferedWriter bw, String groupName, List<RoutingCriteria> routes) throws IOException, CommunicatorException
	{
		
		//Create header for the file
		bw.write("Inquiry Rule List for "+groupName+EXPORT_CSV_NEWLINE+EXPORT_CSV_NEWLINE+"From Condition,From,Subject Condition,Subject,To Condition,To,Non-Inquiry,Assign To User,Assign Request Type,Assign To Tag,Assign Processing Region"+EXPORT_CSV_NEWLINE);
		
		if(routes!=null)
		{
			for(RoutingCriteria route:routes)
			{
				String emptyString = "";
				
				if(route==null)
				{
					subLogger.error("Exception occurred inside the method groupDao.createRuleReportForDownload. Routing criteria cannot be null.");
					throw new CommunicatorException("Exception occurred inside the method groupDao.createRuleReportForDownload. Routing criteria cannot be null");
				}
				
				String fromOperator = route.getFrom()!=null && emptyString.equalsIgnoreCase(route.getFrom())?emptyString:route.getFromOperator();
				String subjectOperator = route.getSubject()!=null && emptyString.equalsIgnoreCase(route.getSubject())?emptyString:route.getSubjectOperator(); 
				String toOperator = route.getTo()!=null && emptyString.equalsIgnoreCase(route.getTo())?emptyString:route.getToOperator();
				
				String fromToValueString = fromOperator+EXPORT_CSV_DELIMITER+'"'+route.getFrom()+'"'+EXPORT_CSV_DELIMITER+subjectOperator+EXPORT_CSV_DELIMITER+'"'+route.getSubject()+'"'+EXPORT_CSV_DELIMITER+toOperator+EXPORT_CSV_DELIMITER+'"'+route.getTo()+'"';
				fromToValueString = fromToValueString.replace("null", emptyString);
				bw.append(fromToValueString);
				
				RuleAction actions = route.getActions();
				String isNonInquiry = actions.getMarkAsNonInquiry().equals(Boolean.TRUE)?"YES":emptyString;
				
				if(actions!=null)
				{
					String actionValueString = EXPORT_CSV_DELIMITER+isNonInquiry+EXPORT_CSV_DELIMITER+actions.getAssignToUserId()+EXPORT_CSV_DELIMITER+'"'+actions.getAssignRequestType()+'"'+EXPORT_CSV_DELIMITER+'"'+actions.getAssignToTag()+'"'+EXPORT_CSV_DELIMITER+'"'+actions.getAssignProcessingRegion()+'"';
					actionValueString = actionValueString.replace("null", emptyString);
					bw.append(actionValueString);
				}
				
				bw.append(EXPORT_CSV_NEWLINE);
			}
		}
	}
	
	//[C153176-1072] - Escalate based on inquiry actions
	//Method to fetch the details of a list of group ids into a map.
	//SUNIL: TODO: 27 Sept 2018 Revisit Later for optimisation and cache usage
	public Map<Long,Group> getGroupEscalationDetailsById(List<Long> groupIdList)
	{
		Map<Long,Group> groupDetailsByIdMap = new HashMap<Long,Group>();
//		if(CollectionUtils.isNotEmpty(groupIdList))
		if(groupIdList!=null && !groupIdList.isEmpty())
		{
			Query<Group> query = mongoDatastore.createQuery(Group.class).filter(STATUS_ACTIVE, true);
			query.criteria("id").in(groupIdList);
			query.retrievedFields(true, "id", "groupName", "convCountThresholdForEscalation", "responseTimeThresholdForEscalation", "paResponseTimeThresholdForEscalation","subjectEscalationList");

			List<Group> groupList = query.find().toList();
			subLogger.debug("GroupDAO.getGroupEscalationDetailsById - group details fetched for list: "+groupIdList);
			
//			if(CollectionUtils.isNotEmpty(groupList))
			if(groupList!=null && !groupList.isEmpty())
			{
				for(Group group: groupList)
				{
					if(group!=null)
					{
						groupDetailsByIdMap.put(group.getId(), group);
					}
				}
			}
			
		}
		
		return groupDetailsByIdMap;
	}
	
	
	/**
	 * @return
	 * 
	 * Get maxRuleRouteCriteriaListLimit from Config Table.
	 */
	public int getMaxRuleRouteCriteriaListLimitFromConfig()
	{
		GenericDAO genricDAO = new GenericDAO();
		int maxRuleRouteCriteriaListLimit = 0 ;

		Config configData = genricDAO.getConfigDetailsForId(AppserverConstants.GROUP_CONFIG_ID);
		if (configData != null)
		{
			maxRuleRouteCriteriaListLimit = configData.getMaxRuleRouteCriteriaListLimit();
		}

		subLogger.info("maxRuleRouteCriteriaListLimit from config :" + maxRuleRouteCriteriaListLimit);
		
		return maxRuleRouteCriteriaListLimit;
	}

	/**
	 * @description : return BasicDBObject contains all active groups with users
	 *              entitled
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBObject getAllGroupsUserEntitlement() throws CommunicatorException {
		BasicDBObject basicDBObject = new BasicDBObject();
		long startTime = System.currentTimeMillis();
		basicDBObject.put("data", getAllActiveGroups());
		long estimatedTime = System.currentTimeMillis() - startTime;
		subLogger.info("Total time to fetch all active DL's and entitlements (millis):"+estimatedTime);
		return basicDBObject;

	}

	/**
	 * @description : fetch all active groups
	 * @return
	 * @throws CommunicatorException
	 */
	public List<GroupUserEntitlementsTO> getAllActiveGroups() throws CommunicatorException {
		List<GroupUserEntitlementsTO> list = new ArrayList<>();
		Map<Long, Group> groupMap = QMACacheFactory.getCache().getAllGroupsMap();
		for (Map.Entry<Long, Group> entry : groupMap.entrySet()) {
			GroupUserEntitlementsTO groupUserEntitlements = new GroupUserEntitlementsTO();
			Group group = entry.getValue();
			if (null != group && null != group.id && group.getActive()) {
				groupUserEntitlements.setActive(group.getActive());
				groupUserEntitlements.setGroupName(group.getGroupName());
				groupUserEntitlements.setGroupEmail(group.getGroupEmail());
				groupUserEntitlements.setHeirarchyData(group.getHeirarchyData());
				groupUserEntitlements.setRequestTypes(group.getRequestTypes());
				groupUserEntitlements.setUserEntitlements(getUserEntitlements(group.id));
				list.add(groupUserEntitlements);
			}
		}
		return list;
	}

	/**
	 * @description : filter all user as per groupId
	 * @param grpId
	 * @return
	 */
	List<GroupUserEntitlementsTO.UserGroupRoles> getUserEntitlements(Long groupId) {
		List<GroupUserEntitlementsTO.UserGroupRoles> userGroupRoleList = new ArrayList<>();
		QMACache qmaCache = QMACacheFactory.getCache();
		List<String> userList = qmaCache.getGroupIdToUserListMap().get(groupId);
		Map<String, User> userInfoMap = qmaCache.getUserInfoMap();
		if (null != userList) {
			for (String userId : userList) {
				GroupUserEntitlementsTO.UserGroupRoles userGroupRoles = new GroupUserEntitlementsTO.UserGroupRoles();
				User user = userInfoMap.get(userId.toUpperCase());
				if(user.getActive())
				{
					userGroupRoles.setId(userId);
					userGroupRoles.setName(user.getName());
					userGroupRoles.setGroupRoles(getGroupRoles(user, groupId));
					userGroupRoleList.add(userGroupRoles);
				}
			}
		}
		return userGroupRoleList;
	}

	/**
	 * @description : get group roles from user
	 * @param user
	 * @param grpId
	 * @return
	 */
	private Set<String> getGroupRoles(User user, Long id) {
		Set<String> groupRoleSet = new HashSet<>();
		if (null != user.getGroupRoles()) {
			for (GroupRole groupRole : user.getGroupRoles()) {
				if (null != groupRole.getGroupId() && groupRole.getGroupId().equals(id)) {
					groupRoleSet.add(groupRole.getRole());
				}
			}
		}
		return groupRoleSet;
	}

	
	/**
	 * This method initiates and assign provided group roles to users.
	 * @param soeId
	 * @param inputJsonObj
	 * @return BasicDBObject
	 */
	public BasicDBObject bulkAssignUsersToGroups(String soeId, BasicDBObject inputJsonObj) {
		BasicDBObject result = new BasicDBObject();
		try {
			if( inputJsonObj != null ) {
				BasicDBObject addToGroup = (BasicDBObject)inputJsonObj.get(ADD_TO_GROUP_KEY);
				BasicDBList groupList = (BasicDBList)addToGroup.get(GROUP_LIST_KEY);
				BasicDBList userList = (BasicDBList)addToGroup.get(USER_LIST_KEY);
				
				if( groupList != null && groupList.size() > 0 && userList != null && userList.size() > 0) {
					
					DBCollection userCollection = mongoDatastore.getCollection(User.class);
					
					addUsersToGroup(soeId, result, groupList, userList, userCollection);
					
				} else {
					result.put(AppserverConstants.SUCCESS_KEY, false);
					result.put(AppserverConstants.MESSAGE_KEY, "Invalid input data received !");
				}
			} else {
				result.put(AppserverConstants.SUCCESS_KEY, false);
				result.put(AppserverConstants.MESSAGE_KEY, "Invalid input data received !");
			}
		} catch (Exception e) {
			subLogger.error("Exception while assigning bulk users to multiple groups : ", e);
			result.put(AppserverConstants.SUCCESS_KEY, false);
			result.put(AppserverConstants.MESSAGE_KEY, "Problem while mapping users to group. Please try again later !");
		}
		return result;
	}

	/**
	 * This method will add users to the group
	 * @param soeId
	 * @param result
	 * @param groupList
	 * @param userList
	 * @param userCollection
	 */
	private void addUsersToGroup(String soeId, BasicDBObject result, BasicDBList groupList, BasicDBList userList,
			DBCollection userCollection) throws CommunicatorException {
		QMACache qmaCache = QMACacheFactory.getCache();
		Map<String, Long> groupCodeToIdMap = qmaCache.getGroupCodeToIdMap();
		for(int i=0;i<groupList.size();i++) {
			
			String groupName = (String) groupList.get(i);
			if(StringUtils.isNotEmpty(groupName) && null != groupCodeToIdMap.get(groupName.toUpperCase())) {
				Long grpId = groupCodeToIdMap.get(groupName.toUpperCase());

				DBObject analystGrpRole = createNewGroupRoleDBObject(soeId, grpId, new Date());
				List<DBObject> analystRole = addUserUserRole(analystGrpRole, ANALYST);
				
				DBObject adminGrpRole = createNewGroupRoleDBObject(soeId, grpId, new Date());
				List<DBObject> adminRole = addUserUserRole(adminGrpRole, ADMIN);
				
				DBObject peerRevGrpRole = createNewGroupRoleDBObject(soeId, grpId, new Date());
				List<DBObject> peerRevRole = addUserUserRole(peerRevGrpRole, PEER_REVIEWER);
				
				DBObject supervisorGrpRole = createNewGroupRoleDBObject(soeId, grpId, new Date());
				List<DBObject> supervisorRole = addUserUserRole(supervisorGrpRole, SUPERVISOR);
				
				BasicDBList analystToBeAdded = new BasicDBList();
				BasicDBList adminToBeAdded = new BasicDBList();
				BasicDBList peerRevToBeAdded = new BasicDBList();
				BasicDBList supervisorsToBeAdded = new BasicDBList();
				
				for(int j=0;j<userList.size();j++){
					BasicDBObject userObj = (BasicDBObject) userList.get(j);
					addUserRole(analystToBeAdded, adminToBeAdded, peerRevToBeAdded, supervisorsToBeAdded, userObj, grpId);
				}
				
				if (!analystToBeAdded.isEmpty()) {
					updateUserAdditionDetails(analystToBeAdded, userCollection, analystRole);
				}
				if (!adminToBeAdded.isEmpty()) {
					updateUserAdditionDetails(adminToBeAdded, userCollection, adminRole);
				}
				if (!peerRevToBeAdded.isEmpty()){
					updateUserAdditionDetails(peerRevToBeAdded, userCollection, peerRevRole);
				}
				if (!supervisorsToBeAdded.isEmpty()){
					updateUserAdditionDetails(supervisorsToBeAdded, userCollection, supervisorRole);
				}
			}
			result.put(AppserverConstants.SUCCESS_KEY, true);
			result.put(AppserverConstants.MESSAGE_KEY, "Group Roles mapped successfully !");
		}
	}


	/**
	 * This method adds provided role to group role structure
	 * @param groupRole
	 * @param role
	 * @return List<DBObject>
	 */
	private List<DBObject> addUserUserRole(DBObject groupRole, String role) {
		List<DBObject> roleToSet = new ArrayList<>();
		groupRole.put(ROLE_KEY, role);
		roleToSet.add(groupRole);
		return roleToSet;
	}

	/**
	 * This method identifies user depending on the role provided to that user.
	 * @param analystToBeAdded
	 * @param adminToBeAdded
	 * @param peerRevToBeAdded
	 * @param supervisorsToBeAdded
	 * @param userObj
	 * @param grpId 
	 */
	private void addUserRole(BasicDBList analystToBeAdded, BasicDBList adminToBeAdded, BasicDBList peerRevToBeAdded,
			BasicDBList supervisorsToBeAdded, BasicDBObject userObj, Long grpId) {
		if (null != userObj) {
			String userId = userObj.getString(SOE_ID_KEY);
			String grpRole = userObj.getString(USER_ROLE_KEY);
			if (StringUtils.isNotEmpty(userId) && StringUtils.isNotEmpty(grpRole)) {
				if (ANALYST.equalsIgnoreCase(grpRole) && !isAlreadyRoleAssigned(userId,grpId,ANALYST)) {
					analystToBeAdded.add(userId);
				} else if (ADMIN.equalsIgnoreCase(grpRole) && !isAlreadyRoleAssigned(userId,grpId,ADMIN)) {
					adminToBeAdded.add(userId);
				} else if (PEER_REVIEWER.equalsIgnoreCase(grpRole) && !isAlreadyRoleAssigned(userId,grpId,PEER_REVIEWER)) {
					peerRevToBeAdded.add(userId);
				} else if (SUPERVISOR.equalsIgnoreCase(grpRole) && !isAlreadyRoleAssigned(userId,grpId,SUPERVISOR)) {
					supervisorsToBeAdded.add(userId);
				}
			}
		}
	}

	/**
	 * Method check duplicates from group roles
	 * @param userId
	 * @param grpId
	 * @param role
	 * @return
	 */
	private boolean isAlreadyRoleAssigned(String userId, Long grpId, String role) {
		boolean isExists = false;
		try {
			User userDetails = QMACacheFactory.getCache().getUserInfoMap().get(userId.toUpperCase());
			List<GroupRole> userGroupRoles = new ArrayList<>();
			if(null != userDetails){
				userGroupRoles = userDetails.getGroupRoles();
			}
			for (GroupRole gropRoleObj : userGroupRoles) {
				if(null != gropRoleObj && grpId.equals(gropRoleObj.getGroupId()) && gropRoleObj.getRole().equals(role)){
					subLogger.debug("Group role already exists for userId:"+userId+": {groupId:"+grpId+ ", role:"+role+"}");
					isExists = true;
					break;
				}
			}
		} catch (Exception e) {
			subLogger.error("GroupDAO.isAlreadyRoleAssigned: error while checking duplicates"+e);
		}
		return isExists;
	}
	/**
	 * This method is used to get assigned groups for requested user
	 * @param request 
	 * @return
	 */
	public BasicDBObject getGroupEntitlementsByUser(String request) {
		BasicDBObject basicDBObject = new BasicDBObject();
		long startTime = System.currentTimeMillis();
		try {
			BasicDBObject inputJson = BasicDBObject.parse(request);
			QMACache qmaCache = QMACacheFactory.getCache();
			Map<Long, Group> allGroupsMap = qmaCache.getAllGroupsMap();
			if (null != inputJson.getString(SOE_ID_KEY)) {
				String soeId = inputJson.getString(SOE_ID_KEY);
				Set<Long> userGroupsList = userDAO.getUserGroupsList(soeId);
				BasicDBList responseList = new BasicDBList();
				if (null != userGroupsList) {
					for (Long groupCode : userGroupsList) {
						Group group = allGroupsMap.get(groupCode);
						BasicDBObject valueObject = new BasicDBObject();
						valueObject.put(GROUP_NAME, group.getGroupName());
						valueObject.put(GROUP_EMAIL, group.getGroupEmail());
						responseList.add(valueObject);
					}
				}
				basicDBObject.put(AppserverConstants.SUCCESS_KEY, true);
				basicDBObject.put(AppserverConstants.MESSAGE_KEY, "Successful");
				basicDBObject.put(DATA_KEY, responseList);
			}else{
				basicDBObject.put(AppserverConstants.SUCCESS_KEY, false);
				basicDBObject.put(AppserverConstants.MESSAGE_KEY, "Invalid input");
				basicDBObject.put(DATA_KEY, new BasicDBList());
			}
		} catch (Exception e) {
			basicDBObject.put(AppserverConstants.SUCCESS_KEY, false);
			basicDBObject.put(AppserverConstants.MESSAGE_KEY, "Exception while processing:"+e.getMessage());
			basicDBObject.put(DATA_KEY, new BasicDBList());
			subLogger.error("GroupDAO.getGroupsEntitlementsByUser:Exception while getGroupsEntitlementsByUser"+e);
		}
		long estimatedTime = System.currentTimeMillis() - startTime;
		subLogger.info("Total time to fetch all active DL's and entitlements (millis):"+estimatedTime);
		return basicDBObject;
	}
	
	/**
	 * Method to update the group recipient.
	 * 
	 * @param clientAddressObj - client address.
	 * @return true if updated successfully.
	 * 
	 * @throws CommunicatorException
	 */
	public Boolean updateGroupRecipient(BasicDBObject clientAddressObj) throws CommunicatorException {
		Boolean bSuccess = false;
		Long fromGroupId = clientAddressObj.getLong("groupId"); 
		try {
			String updatedEmail = clientAddressObj.getString("email"); 
			String recipientEmail = clientAddressObj.getString("name");
			boolean isDelete = clientAddressObj.getBoolean("isDelete");
			subLogger.info(" - updateGroupRecipient for Group Id= " + fromGroupId + " with updated email = " +  updatedEmail + " of email = " + recipientEmail);
			
			if (null != fromGroupId) {
				Group group = QMACacheFactory.getCache().getAllGroupsMap().get(fromGroupId);
				if (group != null) {
					List<String> groupRecipients = group.getRecipients();
					if (groupRecipients != null) {
						if (!isDelete) {
							int recipientIdx = groupRecipients.indexOf(recipientEmail);
							groupRecipients.set(recipientIdx, updatedEmail);
						} else {
							groupRecipients = groupRecipients.stream().filter(rec -> !rec.equalsIgnoreCase(recipientEmail)).collect(Collectors.toList());
						}
					}
					group.setRecipients(groupRecipients);
					mongoDatastore.save(group);

					// Reload the cache
					//CacheDAO.getInstance().reloadCache();
					HazelCastCacheIncrementalLoad.refreshGroupInCache(group.getId());
					bSuccess = true;
				}
			}
		} catch (Exception e) {
			subLogger.error(" Issue in updating the External recipients for Group id:  " + fromGroupId, e);
			throw new CommunicatorException(" Issue in updating External recipients for Group id: " + fromGroupId, e);
		}
		return bSuccess;
	}
	
	/**
	 * Method to save back inquiry group rules.
	 * 
	 * @param soeId
	 * @param group.
	 * @return group save status.
	 * 
	 * @throws CommunicatorException
	 */
	public BasicDBObject saveBackupInquiryGroupRules(String soeId, Group group) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		try {
			List<RoutingCriteria> backupRuleRouteCriteriaList = group.getBackupRoutes();
			group.setRoutes(backupRuleRouteCriteriaList);
			group.setBackupRoutes(null);
			group.setBackupRouteDate(null);
			group.setModBy(soeId);
			mongoDatastore.save(group);
			//saveBackupInquiryGroupRules
			HazelCastCacheIncrementalLoad.refreshGroupInCache(group.getId());
			saveGroupRoutingAudit(backupRuleRouteCriteriaList, group.getGroupName(), group.id, group.getGroupEmail(),soeId);
			response.put(AppserverConstants.SUCCESS_KEY, true);
			String version = null != group.getVersion() ? group.getVersion().toString() : "";
			response.put(AppserverConstants.VERSION, version);
			updateStaticDataGroupLastModifiedTimeToReloadServiceCache();
		} catch (Exception e) {
			subLogger.error("Exception in GroupDAO.saveBackupInquiryGroupRules", e);
			throw new CommunicatorException("Exception in GroupDAO.saveBackupInquiryGroupRules");
		}
		return response;
	}

	/**
	 * Method to assign the user to newly created personal group.
	 * 
	 * @param soeId
	 * @param groupId
	 */
	public void assignUserToGroup(String soeId, Long groupId) {
		try {
			DBCollection userCollection = mongoDatastore.getCollection(User.class);
			DBObject newGrpRole = createNewGroupRoleDBObject(soeId, groupId, new Date());

			BasicDBList adminUserList = new BasicDBList();
			adminUserList.add(soeId);
			if (adminUserList != null) {
				updateUserAdditionDetails(adminUserList, userCollection, newGrpRole, ADMIN);
			}
			// Cache reload should be the last step
			//CacheDAO.getInstance().reloadCache();
			HazelCastCacheIncrementalLoad.refreshGroupInCache(groupId);
			updateStaticDataGroupLastModifiedTimeToReloadServiceCache();
		} catch (Exception e) {
			subLogger.error("Exception in GroupDAO.assignUserToGroup", e);
		}
	}
	public Group getGroupDataById(Long groupId) throws CommunicatorException {

		Query<Group> query = null;
		Group group = null;
		try	{
			query = mongoDatastore.createQuery(Group.class).filter("_id", groupId);
			group = query.get();
		}
		catch (Exception e){
			subLogger.error("Exception in getGroupDataById for  user=" + groupId , e);
			throw new CommunicatorException("Exception in getGroupDataById for  user=" + groupId);
		}
		
		return group;
	}

	/**
	 * @param soeId
	 * @param groupName
	 * @param roleIdentifier
	 * @param qmaCache
	 * @return
	 */
	private boolean hasRoleToPerformAction(String soeId, String groupName, String roleIdentifier, QMACache qmaCache) {
		boolean hasRole = false;
		if (null == qmaCache || null == qmaCache.getGroupCodeToIdMap() || null == qmaCache.getUserInfoMap()
				|| null == groupName || soeId == null) {
			return hasRole;
		}
		Long groupId = qmaCache.getGroupCodeToIdMap().get(groupName.toUpperCase());
		List<GroupRole> groupRoles = qmaCache.getUserInfoMap().get(soeId.toUpperCase()).getGroupRoles();

		if (groupRoles != null && groupId != null) {
			for (GroupRole groupRole : groupRoles) {
				if (groupId.equals(groupRole.getGroupId()) && groupRole.getRole().contains(roleIdentifier)) {
					hasRole = true;
					break;
				}

			}
		}
		return hasRole;
	}
	
	/**
	 * @description : validate if user is part of all groups in request
	 * @return
	 * @throws CommunicatorException
	 */
	public boolean isAllGroupsAssigned(BasicDBObject inputJsonObjList,String soeId) throws CommunicatorException {
		boolean isAllGroupsAssigned = false;
		 BasicDBList list = (BasicDBList) inputJsonObjList.get("groupList");
		 Set<String> userGroupsList = getUserGroups(soeId);
		 for(Object grpName: list) {
			 // Group matchedGrp = QMACacheFactory.getCache().getAllGroupsMap().values().stream().filter((g->g.getGroupName().equalsIgnoreCase((String) grpName))).findFirst().orElse(null);
			 String matchedGrp = userGroupsList.stream().filter((g->g.equalsIgnoreCase((String) grpName))).findFirst().orElse(null);			 
		     if(matchedGrp == null) {
				 isAllGroupsAssigned =  false;
				 break;
		     } else {
				 isAllGroupsAssigned = true;
	 	     }
		     
		}
		return isAllGroupsAssigned;
	}
	private static Set<String> getUserGroups(String soeId) throws CommunicatorException {
        Set<String> userGroupsList = null;
        User user = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase());
        if (null != user ) {
            try {
                /* Already existing function to get all assigned groups of user which fetches data from HazelCast Cache */
                userGroupsList = userDao.getUserGroupsNames(user,true);
            } catch (Exception e) {
                throw new CommunicatorException("Exception in getUserGroups",e);
            }
        } else {
        	subLogger.warn("User {} information can not be verified.",soeId);
        }
        return userGroupsList;
    }
}
