package com.citi.icg.qma.common.core.util;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class GenericUtil
{
	private static final Logger logger =LoggerFactory.getLogger(GenericUtil.class);

	private GenericUtil(){
		//As this class is Util, so added making private constructor.
		//Sonar Fix -- Utility classes should not have public constructors 
	}
	
	// Password Decryption Util method
	public static String getDecryptedPassword(Properties prop)
	{
		String decrPassword = null;
		String passwordEncStr = null;
		String passwordIVEncStr = null;
		try
		{
			passwordEncStr = prop.getProperty("password");
			passwordIVEncStr = prop.getProperty("passwordIV");
			if (passwordEncStr == null && passwordIVEncStr == null)
			{
				passwordEncStr = prop.getProperty("PASSWORD");
				passwordIVEncStr = prop.getProperty("PASSWORDIV");
			}
			decrPassword = DecryptionUtil.decrypt(passwordEncStr,
					passwordIVEncStr, ApplicationConstants.APPLICATION_ENCRYPTION_KEY);
			logger.info("Decryption successfull");
		}
		catch (Exception e)
		{
			logger.error("Invalid Password property for Decryption");
		}
		return decrPassword;
	}
	public static void stopProcess(String processName,int exitCode)
	{
		logger.info("Stoping Process {} with exit code: {}",processName,exitCode);
		System.exit(exitCode);
	}

}
