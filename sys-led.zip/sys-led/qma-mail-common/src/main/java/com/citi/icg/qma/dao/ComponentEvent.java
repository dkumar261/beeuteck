package com.citi.icg.qma.dao;

import java.util.Date;

import dev.morphia.annotations.Embedded;

@Embedded
public class ComponentEvent {

	private String component;
	private String block;
	private String event;
	private String status;
	private Date time;
	private String details;
	private String hostname;
	private String level; 
	

	public final static String COMPONENT_READER = "READER";
	public final static String COMPONENT_CONTROLLER = "CONTROLLER";
	public final static String COMPONENT_PROCESSOR = "PROCESSOR";
	public final static String COMPONENT_SNAPSHOT = "SNAPSHOT";
	public final static String COMPONENT_REPLAY = "REPLAY";

	public final static String STARTED = "STARTED";
	public final static String FINISHED = "FINISHED";
	public final static String FAILED = "FAILED";
	public final static String NEW_INQUIRY = "NEW_INQUIRY";
	public final static String REPLY_INQUIRY = "REPLY_INQUIRY";
	public final static String SNAPSHOT_PRODUCE_STARTED = "SNAPSHOT_PRODUCE_STARTED";
	public final static String SNAPSHOT_PRODUCE_FINISHED = "SNAPSHOT_PRODUCE_FINISHED";
	public final static String CONTROLLER_PRODUCE_FINISHED = "CONTROLLER_PRODUCE_FINISHED";
	public final static String DUPLICATE_MESSAGE = "DUPLICATE_MESSAGE";
	public static final String OASYS_NLP_RESPONSE = "OASYS_NLP_RESPONSE";
	
	public final static String STATUS_ACTIVE = "ACTIVE";
	public final static String STATUS_INACTIVE = "INACTIVE";

	public final static String LEVEL_INFO = "INFO";
	public final static String LEVEL_WARN = "WARN";
	public final static String LEVEL_ERROR = "ERROR";
	
	public ComponentEvent() {
		super();
	}

	
	/*public ComponentEvent(String component, String block, String event, String status ,Date time, String hostname, String level, String details) {
		super();
		this.component = component;
		this.block = block;
		this.event = event;
		this.time = time;
		this.status = status;
		this.hostname = hostname;
		this.level = level;
		this.details = details;
	}*/

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	@Override
	public String toString() {
		return "ComponentEvent [component=" + component + ", block=" + block + ", event=" + event + ", status=" + status
				+ ", time=" + time + ", details=" + details + ", hostname=" + hostname + ", level=" + level + "]";
	}

	
	
}
