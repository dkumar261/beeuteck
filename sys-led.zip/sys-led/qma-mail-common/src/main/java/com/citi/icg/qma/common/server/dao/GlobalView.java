package com.citi.icg.qma.common.server.dao;
import dev.morphia.annotations.Entity;

@Entity(value = "GlobalView", noClassnameStored = false)
public class GlobalView extends BaseEntity
{

	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private String fieldName;
	private int fieldOrder;
	private Boolean fieldSortAscFlag;

//	crtDate
//	lastUpdtDate

	public GlobalView(String fieldName, int fieldOrder,
			Boolean fieldSortAscFlag)
	{
		super();
		this.fieldName = fieldName;
		this.fieldOrder = fieldOrder;
		this.fieldSortAscFlag = fieldSortAscFlag;
	}

	public GlobalView()
	{
		super();
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public int getFieldOrder() {
		return fieldOrder;
	}

	public void setFieldOrder(int fieldOrder) {
		this.fieldOrder = fieldOrder;
	}

	public Boolean getFieldSortAscFlag() {
		return fieldSortAscFlag;
	}

	public void setFieldSortAscFlag(Boolean fieldSortAscFlag) {
		this.fieldSortAscFlag = fieldSortAscFlag;
	}

}
