package com.citi.icg.qma.common.server.dao;

import java.util.Date;

import dev.morphia.annotations.Embedded;

@Embedded
public class WorkflowAudit
{
	private String userId;
	private Long groupId;
	private String action;
	private String actionDetails;
	private String modBy;
	private Date modDate;
	private String  tag;
	//Below variable added to be include groupname in audit object and kept private with getters & setters.
	private String groupName;
	private RulesFlag rulesFlag;
	private String forceUnlock;
	private String responseTimeEscalationReason;
	private String responseTimeEscalationFlag;
	private String ispendingApprovalEscalation;
	
	//[C153176-1014] - Add Escalation functionality
	private String isConvCountEscalation; //Queries exceeding number of conversations
	private String isClientChaseEscalation; //Queries chased by client
	private String isSubjectEscalation; //Email subject containing Escalation, Urgent etc.
	private String generalEscalationReason;
	
	
	public WorkflowAudit()
	{
	}

	public WorkflowAudit(String action, String actionDetails, Long groupId, String modBy, Date modDate, String userId)
	{
		this.action = action;
		this.actionDetails = actionDetails;
		this.groupId = groupId;
		this.modBy = modBy;
		this.modDate = modDate;
		this.setUserId(userId);
		this.setTag(tag);
	}

	public String getGroupName()
	{
		return groupName;
	}

	public void setGroupName(String groupName)
	{
		this.groupName = groupName;
	}

	public RulesFlag getRulesFlag()
	{
		return rulesFlag;
	}

	public void setRulesFlag(RulesFlag rulesFlag)
	{
		this.rulesFlag = rulesFlag;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getActionDetails() {
		return actionDetails;
	}

	public void setActionDetails(String actionDetails) {
		this.actionDetails = actionDetails;
	}

	public String getModBy() {
		return modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public Date getModDate() {
		return modDate;
	}

	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}

	public String getForceUnlock()
	{
		return forceUnlock;
	}

	public void setForceUnlock(String forceUnlock)
	{
		this.forceUnlock = forceUnlock;
	}

	public String getResponseTimeEscalationReason()
	{
		return responseTimeEscalationReason;
	}

	public void setResponseTimeEscalationReason(String responseTimeEscalationReason)
	{
		this.responseTimeEscalationReason = responseTimeEscalationReason;
	}

	public String getResponseTimeEscalationFlag()
	{
		return responseTimeEscalationFlag;
	}

	public void setResponseTimeEscalationFlag(String responseTimeEscalationFlag)
	{
		this.responseTimeEscalationFlag = responseTimeEscalationFlag;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getIsConvCountEscalation() {
		return isConvCountEscalation;
	}

	public void setIsConvCountEscalation(String isConvCountEscalation) {
		this.isConvCountEscalation = isConvCountEscalation;
	}

	public String getIsClientChaseEscalation() {
		return isClientChaseEscalation;
	}

	public void setIsClientChaseEscalation(String isClientChaseEscalation) {
		this.isClientChaseEscalation = isClientChaseEscalation;
	}

	public String getIsSubjectEscalation() {
		return isSubjectEscalation;
	}

	public void setIsSubjectEscalation(String isSubjectEscalation) {
		this.isSubjectEscalation = isSubjectEscalation;
	}

	public String getGeneralEscalationReason() {
		return generalEscalationReason;
	}

	public void setGeneralEscalationReason(String generalEscalationReason) {
		this.generalEscalationReason = generalEscalationReason;
	}

	public String getIspendingApprovalEscalation() {
		return ispendingApprovalEscalation;
	}

	public void setIspendingApprovalEscalation(String ispendingApprovalEscalation) {
		this.ispendingApprovalEscalation = ispendingApprovalEscalation;
	}
}
