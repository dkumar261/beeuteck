package com.citi.icg.qma.common.server.dao.persistence;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.Temporal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.citi.icg.xmw.ws.client.CIMSWSEntryPoint;
import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.transferobject.CorporateAddressBookTO;
import com.citi.icg.qma.common.transferobject.UserTO;
import com.mongodb.BasicDBObject;

//import Group.CIMSWebService.CIMS_DLPropRec_Type;
//import Group.CIMSWebService.DLPropRec;
//import User.CIMSWebService.CIMS_FindUserRec_Type;
//import User.CIMSWebService.CIMS_getPersonBySOEId_Type;
//import User.CIMSWebService.FindUserRec;
//import User.CIMSWebService.GetPersonBySOEId;
import dev.morphia.query.Query;

public class AddressBookDAO extends MongoMorphiaDAO
{
//
//	private static final Logger logger = LoggerFactory.getLogger(AddressBookDAO.class);
//	
//	public List<CorporateAddressBookTO> getUserDetailsByName(String request) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
//	{
//		logger.info("Inside AddressBookDAO.getUserDetailsByName for getting user data with request :" + request);
//		BasicDBObject req = BasicDBObject.parse(request);
//
//		String lastName = req.getString("lastName");
//		String firstName = req.getString("firstName");
//		GetPersonBySOEId[] record;
//
//		List<CorporateAddressBookTO> emailList = new ArrayList<CorporateAddressBookTO>();
//
//		logger.info("Inside AddressBookDAO.getUserDetailsByName -- first name is " + firstName + " and last name is " + lastName);
//
//		List<CIMS_getPersonBySOEId_Type> userList;
//		try {
//		    userList = CIMSWSEntryPoint.getUserDataByName(lastName.trim(), firstName.trim());
//		} catch (Exception e) {
//			throw new CommunicatorException("Error in AddressBookDAO.getUserDetailsByName", e);
//		}
//
//		if (userList != null && !userList.isEmpty())
//		{
//			for (CIMS_getPersonBySOEId_Type rc : userList)
//            {
//			    record = rc.getRetRecSet();
//			    
//			    if (record != null)
//		        {
//			        emailList = createCorporateAddressBookTO(record, emailList);
//		        }else
//		        {
//		            logger.info("Inside AddressBookDAO.getUserDetailsByName -- record not found");
//		        }
//            }
//		}
//		else
//		{
//			logger.info("Inside AddressBookDAO.getUserDetailsByName Record Set not found");
//		}
//		
//		return emailList;
//	}
//	
//	public List<CorporateAddressBookTO> createCorporateAddressBookTO(GetPersonBySOEId[] record, List<CorporateAddressBookTO> emailList)
//	{
//	    for (GetPersonBySOEId person : record)
//        {
//            String name = person.getFirstName() + " " + person.getLastName();
//            String mail = person.getEmail();
//            String department = person.getGocLongDesc();
//            String phone = person.getPhone();
//            String country = person.getCountry();
//          
//            //If countryLong doesn't return a value, take country short value.
//            if(StringUtils.isEmpty(country))
//            {
//                country = person.getCountryName();
//            }
//            
//            logger.debug("Name : " + name+",Email : " + mail+",Department : " + department+",phone : " + phone+",country : " + country);
//            
//            emailList.add(new CorporateAddressBookTO(name, mail,department,phone,country));
//        }
//	    
//	    return emailList;
//	}
//	
//	public List<CorporateAddressBookTO> getUserDetailsBySoeId(BasicDBObject inputJsonObj) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
//	{
//
//		List<CorporateAddressBookTO> emailList = new ArrayList<CorporateAddressBookTO>();
//		try
//		{
//			String userId = inputJsonObj.getString("userId");
//			FindUserRec[] record = null;
//
//			logger.info("Inside AddressBookDAO.getUserDataByName -- user Id is " + userId);
//
//			CIMS_FindUserRec_Type user = CIMSWSEntryPoint.getUserDataBySoeid(userId.trim());
//
//			if (user != null)
//			{
//				record = user.getRetRecSet();
//			}
//			else
//			{
//				logger.info("Record not found");
//			}
//
//			if (record != null)
//			{
//				for (FindUserRec rc : record)
//				{
//					String name = rc.getFirstName() + " " + rc.getLastName();
//					String mail = rc.getEmail();
//					String department = rc.getDept();
//					String phone = rc.getPhone();
//					String country = rc.getCountryLong();
//					String longDesc = rc.getLdesc();
//					
//					//If countryLong doesn't return a value, take country short value.
//					if(StringUtils.isEmpty(country))
//					{
//						country = rc.getCountryShort();
//					}
//					
//					if(!StringUtils.isEmpty(department) && department.contains("["))
//					{
//						department = department.substring(0,department.indexOf("["));
//					}
//					
//					logger.info("Name : " + name+",Email : " + mail+",Department : " + department+",phone : " + phone+",country : " + country+",lDesc : " + longDesc );
//					
//					emailList.add(new CorporateAddressBookTO(name, mail,department,phone,country, longDesc));
//				}
//			}
//			else
//			{
//				logger.info("Inside AddressBookDAO.getUserDataByName -- record set not found");
//			}
//		}
//		catch (Exception e)
//		{
//			logger.error("Exception occurred in CIMS Webservice call",e);
//			throw new CommunicatorException("Exception occurred in CIMS Webservice call", e);
//		}
//		
//		return emailList;
//	}
//
//	public List<CorporateAddressBookTO> getDLDetailsByName(String request) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
//	{
//		String dlName;
//		DLPropRec[] dlDataList = null;
//		List<CorporateAddressBookTO> emailList = new ArrayList<CorporateAddressBookTO>();
//
//		BasicDBObject req = BasicDBObject.parse(request);
//
//		dlName = req.getString("dlName");
//		logger.info("DL name is " + dlName);
//		String [] dlArr = dlName.split(";");
//		CIMS_DLPropRec_Type dlDataObject = null;
//		for(String dl : dlArr)
//		{
//			try
//			{
//				dlDataObject = CIMSWSEntryPoint.findDLByName(dl.trim());
//			}
//			catch (Exception e)
//			{
//				throw new CommunicatorException("Error in AddressBookDAO.getDLDetailsByName", e);
//			}
//
//			if (dlDataObject != null)
//			{
//				dlDataList = dlDataObject.getRetRecSet();
//				if (dlDataList == null)
//				{
//					logger.info("Data list is null");
//				}
//				else
//				{
//					for (int i = 0; i < dlDataList.length; i++)
//					{
//						logger.info("Email is " + dlDataList[i].getEmail() + " for DL input =" + dl + " with desc:" + dlDataList[i].getDescription());
//						emailList.add(new CorporateAddressBookTO(dlDataList[i].getDescription(), dlDataList[i].getEmail()));
//					}
//				}
//			}
//			else
//			{
//				logger.info("Inside AddressBookDAO.getDLDetailsByName -- Record not found");
//			}
//		}
//		
//		
//		return emailList;
//	}
//	
//	//[C153176-172] - Ability to enter SOEID only to bring up email address
//	//Method to return List of user details for given list of soeids
//	public List<UserTO> getUsersBySoeIdList(List<String> userIdList) throws CommunicatorException
//	{
//		List<UserTO> userDetailsList = new ArrayList<UserTO>();
//		for(String userId : userIdList)
//		{
//			if(!StringUtils.isBlank(userId))
//			{
//				BasicDBObject user = new BasicDBObject();
//				user.append("userId", userId.trim());
//				List<CorporateAddressBookTO> userList = getUserDetailsBySoeId(user);
//				
//				UserTO userDetails = new UserTO();
//				userDetails.setUserId(userId);
//				
//				if(userList!=null && !(userList.isEmpty()) && userList.get(0)!=null)
//				{					
//					userDetails.setUserId(userId);
//					userDetails.setUserName(userList.get(0).getName());
//					userDetails.setEmail(userList.get(0).getEmail());
//					userDetails.setLongDesc(userList.get(0).getLongDesc());
//				}
//				
//				userDetailsList.add(userDetails);
//			}
//			
//		}
//		return userDetailsList;
//	}
//	
//	public void updateAllUsersManagerDetailsByCIMSJob(List<String> receivedUserIdList) {		
//		List<User> userList = new ArrayList<User>();
//		if(Objects.nonNull(receivedUserIdList) && !receivedUserIdList.isEmpty()) {
//			logger.info("Updating manager for specified users(count) : " + receivedUserIdList.size());
//			Query<User> query = mongoDatastore.createQuery(User.class).filter("active", true).filter("_id in ", receivedUserIdList);
//			// query.retrievedFields(true, "_id");
//			userList = query.asList();
//			logger.info("Updating manager for filtered users(count) : " + userList.size());
//		} else {			
//			Query<User> query = mongoDatastore.createQuery(User.class).filter("active", true);
//			// query.retrievedFields(true, "_id");
//			userList = query.asList();
//			logger.info("Updating manager for all users(count) : " + userList.size());
//		}
//		
//		logger.info("Active User list size for UsersManagerDetailsUpdateCIMSJob:::" + userList.size());
//		if (!userList.isEmpty()) {
//			Integer totalUsersToBeUpdated = userList.size();
//			Integer currentIndex = 0;
//			for (User user : userList) {
//				currentIndex++;
//				updateMangerOfUser(user, totalUsersToBeUpdated, currentIndex);
//			}			
//		}				
//	}
//
//	/**
//	 * @param totalUsersToBeUpdated
//	 * @param currentIndex
//	 * @param user
//	 * @return
//	 */
//	private void updateMangerOfUser(User user, Integer totalUsersToBeUpdated, Integer currentIndex) {
//		String userId = user.getId();		
//		if (StringUtils.isNotBlank(userId)) {
//			Instant startExecute = Instant.now();
//			try {
//				// Pull User Information from CIMS
//				CIMS_getPersonBySOEId_Type personType = CIMSWSEntryPoint.getUserDetailsBySoeId(userId);
//				if (personType != null) {
//					GetPersonBySOEId[] person = personType.getRetRecSet();
//					if (person != null) {
//						for (GetPersonBySOEId userRecord : person) {
//							if (userRecord != null) {
//								String firstName = userRecord.getFirstName();
//								String lastName = userRecord.getLastName();
//								String phone = userRecord.getPhone();
//								String managerId = userRecord.getDepartmentManagerSoeid(); // DirectManagerSoeId is not
//																							// having data for all
//																							// users.
//								String department = userRecord.getGocLongDesc();
//								String country = userRecord.getCountry();
//								String gocCode = userRecord.getGocCode();
//								// String longDesc=userRecord.getGocLongDesc();
//								String manageSegL5 = userRecord.getManagedSegmentDescriptionlevel5();
//								String manageSegL6 = userRecord.getManagedSegmentDescriptionlevel6();
//								String manageSegL7 = userRecord.getManagedSegmentDescriptionlevel7();
//								user.setGocCode(gocCode);
//								user.setMsL5(manageSegL5);
//								user.setMsL6(manageSegL6);
//								user.setMsL7(manageSegL7);
//								// user.setLongDesc(longDesc);
//								String lDesc = getLDescFromCIMS(userId);
//								if (null != lDesc) {
//									user.setLongDesc(lDesc);
//								}
//								// Pull Manager Information from CIMS
//								if (StringUtils.isNotBlank(managerId)) {
//									CIMS_getPersonBySOEId_Type managerType = CIMSWSEntryPoint
//											.getUserDetailsBySoeId(managerId);
//									if (managerType != null) {
//										GetPersonBySOEId[] manager = managerType.getRetRecSet();
//										if (manager != null) {
//											for (GetPersonBySOEId managerRecord : manager) {
//												if (managerRecord != null) {
//													String mgrName = managerRecord.getFirstName() + " "
//															+ managerRecord.getLastName();
//													String mgrEmail = managerRecord.getEmail();
//													String mgrPhone = managerRecord.getPhone();
//
//													// Save User and Manager details in the User collection
//													user.setFirstName(firstName);
//													user.setLastName(lastName);
//													user.setPhone(phone);
//													user.setMgrName(mgrName);
//													user.setMgrEmail(mgrEmail);
//													user.setMgrPhone(mgrPhone);
//													user.setDepartment(department);
//													user.setCountry(country);
//													mongoDatastore.save(user);
//													long executeDuration = Duration.between(startExecute, Instant.now())
//															.toMillis();
//													logger.info(
//															"updated manager for userId:{}, (" + currentIndex + "/"
//																	+ totalUsersToBeUpdated + "), time-taken:{}",
//															userId, executeDuration);
//												}
//											}
//										}
//									}
//								}
//							}
//						}
//					}
//				}
//			} catch (Exception e) {
//				logger.error("Exception in updateAllUsersManagerDetailsByCIMSJob while populating data from CIMS. ", e);
//			}
//
//		}
//	}
//
//	private String getLDescFromCIMS(String userId) {
//		String lDesc = null;
//		try {
//			BasicDBObject inputJsonObj = new BasicDBObject();
//			inputJsonObj.put("userId", userId);
//			List<CorporateAddressBookTO> addressBookAll = getUserDetailsBySoeId(inputJsonObj);
//			for (CorporateAddressBookTO addressBook : addressBookAll) {
//				lDesc = addressBook.getLongDesc();
//			}
//		} catch (Exception e) {
//			logger.error("Exception while getting lDesc:", e);
//		}
//		return lDesc;
//	}
//
}
