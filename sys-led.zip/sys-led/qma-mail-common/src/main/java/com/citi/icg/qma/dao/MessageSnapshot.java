package com.citi.icg.qma.dao;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import jakarta.mail.internet.InternetAddress;

import com.citi.icg.qma.common.core.util.MsgSourceType;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;
import dev.morphia.annotations.PrePersist;

@Entity(value = "MessageSnapshot", noClassnameStored = true)
public class MessageSnapshot {
	
	@Id
	private String guid;
	private String messageId;
	private String subject;
	private InternetAddress[] from;
	private Date sentDate;
	private InternetAddress[] to;
	private InternetAddress[] cc;
	private InternetAddress[] bcc;
	private List<String> groupNames;
	private List<Long> groupIds;
	private String mailboxName;
	private boolean isDedicatedMailBox;
	private boolean isMailDroppedSecondForProcessingBCCRecipient;
	private boolean containsQmaBccRecipient;
	private Long inquiryId;
	private Long inquiryMessageRefId;
	private Long conversationId;
	private Action action;
	private int size;
	
	private boolean toBeProcessedAtController;
	private boolean toBeProcessed;
	
	private Date createDate;
	private Date modDate;
	
	private ProcessingStatus processingStatus;
	private List<ComponentEvent> events;
	private List<ComponentEvent> duplicateCheckEvents;
	
	private int processedCount;
	
	private String gridFSFilename;
	private String gridFSId;
	
	
	private ExchangeEventType exchEventType;
	private String exchItemId;
	private String exchOldItemId;
	private String exchFolder;
	private String exchFolderId;
	private String exchOldFolder;
	private String exchOldFolderId;
	private Boolean isRead;
	private Boolean isImportant;
	
	private MsgSourceType msgSourceType;

	 
	public MessageSnapshot() {
		super();
	}
	
	/**
	 * @param messageId
	 * @param subject
	 * @param from
	 * @param sentDate
	 * @param to
	 * @param cc
	 * @param bcc
	 * @param events
	 * @param toBeProcessed
	 */
	public MessageSnapshot(MsgSourceType msgSourceType, String guid, String messageId, String subject, InternetAddress[] from, Date sentDate,
			InternetAddress[] to, InternetAddress[] cc, InternetAddress[] bcc, List<ComponentEvent> events, boolean toBeProcessed) {
		super();
		this.msgSourceType = msgSourceType;
		this.guid = guid;
		this.messageId = messageId;
		this.subject = subject;
		this.from = from;
		this.sentDate = sentDate;
		this.to = to;
		this.cc = cc;
		this.bcc = bcc;
		this.events=events;
		this.toBeProcessed=toBeProcessed;
		this.toBeProcessedAtController=toBeProcessed;
		this.processedCount=0;
	}

	@Override
	public String toString() {
		return "MessageSnapshot [messageId=" + messageId + ", subject=" + subject + ", from=" + Arrays.toString(from)
				+ ", sentDate=" + sentDate + ", to=" + Arrays.toString(to) + ", cc=" + Arrays.toString(cc) + ", bcc="
				+ Arrays.toString(bcc) + ", groupNames=" + groupNames + ", groupIds=" + groupIds + ", mailboxName="
				+ mailboxName + ", inquiryId=" + inquiryId + ", inquiryMessageRefId=" + inquiryMessageRefId
				+ ", conversationId=" + conversationId + ", action=" + action + ", size=" + size
				+ ", toBeProcessedAtController=" + toBeProcessedAtController + ", toBeProcessed=" + toBeProcessed
				+ ", createDate=" + createDate + ", modDate=" + modDate + ", processingStatus=" + processingStatus
				+ ", events=" + events + ", duplicateCheckEvents=" + duplicateCheckEvents + ", processedCount="
				+ processedCount + ", gridFSFilename=" + gridFSFilename + ", gridFSId=" + gridFSId + "]";
	}

	@PrePersist
	public void prePersist()
	{
		this.createDate = (createDate == null) ? new Date() : createDate;
		this.modDate = (modDate == null) ? createDate : new Date();
	}
	
	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public InternetAddress[] getFrom() {
		return from;
	}

	public void setFrom(InternetAddress[] from) {
		this.from = from;
	}

	public Date getSentDate() {
		return sentDate;
	}

	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}

	public InternetAddress[] getTo() {
		return to;
	}

	public void setTo(InternetAddress[] to) {
		this.to = to;
	}

	public InternetAddress[] getCc() {
		return cc;
	}

	public void setCc(InternetAddress[] cc) {
		this.cc = cc;
	}

	public InternetAddress[] getBcc() {
		return bcc;
	}

	public void setBcc(InternetAddress[] bcc) {
		this.bcc = bcc;
	}

	public String getGridFSFilename() {
		return gridFSFilename;
	}

	public void setGridFSFilename(String gridFSFilename) {
		this.gridFSFilename = gridFSFilename;
	}

	public String getGridFSId() {
		return gridFSId;
	}

	public void setGridFSId(String gridFSId) {
		this.gridFSId = gridFSId;
	}

	public List<ComponentEvent> getEvents() {
		return events;
	}

	public void setEvents(List<ComponentEvent> events) {
		this.events = events;
	}

	public boolean isToBeProcessed() {
		return toBeProcessed;
	}

	public void setToBeProcessed(boolean toBeProcessed) {
		this.toBeProcessed = toBeProcessed;
	}

	public List<ComponentEvent> getDuplicateCheckEvents() {
		return duplicateCheckEvents;
	}

	public void setDuplicateCheckEvents(List<ComponentEvent> duplicateCheckEvents) {
		this.duplicateCheckEvents = duplicateCheckEvents;
	}

	public int getProcessedCount() {
		return processedCount;
	}

	public void setProcessedCount(int processedCount) {
		this.processedCount = processedCount;
	}

	public String getMailboxName() {
		return mailboxName;
	}

	public void setMailboxName(String mailboxName) {
		this.mailboxName = mailboxName;
	}

	public boolean isDedicatedMailBox() {
		return isDedicatedMailBox;
	}

	public void setDedicatedMailBox(boolean isDedicatedMailBox) {
		this.isDedicatedMailBox = isDedicatedMailBox;
	}

	public boolean isMailDroppedSecondForProcessingBCCRecipient() {
		return isMailDroppedSecondForProcessingBCCRecipient;
	}

	public void setMailDroppedSecondForProcessingBCCRecipient(boolean isMailDroppedSecondForProcessingBCCRecipient) {
		this.isMailDroppedSecondForProcessingBCCRecipient = isMailDroppedSecondForProcessingBCCRecipient;
	}

	public boolean isContainsQmaBccRecipient() {
		return containsQmaBccRecipient;
	}

	public void setContainsQmaBccRecipient(boolean containsQmaBccRecipient) {
		this.containsQmaBccRecipient = containsQmaBccRecipient;
	}

	public Long getInquiryId() {
		return inquiryId;
	}

	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}


	public boolean isToBeProcessedAtController() {
		return toBeProcessedAtController;
	}


	public void setToBeProcessedAtController(boolean toBeProcessedAtController) {
		this.toBeProcessedAtController = toBeProcessedAtController;
	}

	public Date getModDate() {
		return modDate;
	}


	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}


	public Date getCreateDate() {
		return createDate;
	}


	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}


	public ProcessingStatus getProcessingStatus() {
		return processingStatus;
	}


	public void setProcessingStatus(ProcessingStatus processingStatus) {
		this.processingStatus = processingStatus;
	}

	public Action getAction() {
		return action;
	}

	public void setAction(Action action) {
		this.action = action;
	}

	public Long getInquiryMessageRefId() {
		return inquiryMessageRefId;
	}

	public void setInquiryMessageRefId(Long inquiryMessageRefId) {
		this.inquiryMessageRefId = inquiryMessageRefId;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public Long getConversationId() {
		return conversationId;
	}

	public void setConversationId(Long conversationId) {
		this.conversationId = conversationId;
	}


	public List<String> getGroupNames() {
		return groupNames;
	}


	public void setGroupNames(List<String> groupNames) {
		this.groupNames = groupNames;
	}


	public List<Long> getGroupIds() {
		return groupIds;
	}


	public void setGroupIds(List<Long> groupIds) {
		this.groupIds = groupIds;
	}

	public ExchangeEventType getExchEventType() {
		return exchEventType;
	}


	public void setExchEventType(ExchangeEventType exchEventType) {
		this.exchEventType = exchEventType;
	}


	public String getExchItemId() {
		return exchItemId;
	}


	public void setExchItemId(String exchItemId) {
		this.exchItemId = exchItemId;
	}


	public String getExchOldItemId() {
		return exchOldItemId;
	}


	public void setExchOldItemId(String exchOldItemId) {
		this.exchOldItemId = exchOldItemId;
	}


	public String getExchFolder() {
		return exchFolder;
	}


	public void setExchFolder(String exchFolder) {
		this.exchFolder = exchFolder;
	}


	public String getExchFolderId() {
		return exchFolderId;
	}


	public void setExchFolderId(String exchFolderId) {
		this.exchFolderId = exchFolderId;
	}


	public String getExchOldFolder() {
		return exchOldFolder;
	}


	public void setExchOldFolder(String exchOldFolder) {
		this.exchOldFolder = exchOldFolder;
	}


	public String getExchOldFolderId() {
		return exchOldFolderId;
	}


	public void setExchOldFolderId(String exchOldFolderId) {
		this.exchOldFolderId = exchOldFolderId;
	}

	public Boolean getIsRead() {
		return isRead;
	}

	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}

	public Boolean getIsImportant() {
		return isImportant;
	}

	public void setIsImportant(Boolean isImportant) {
		this.isImportant = isImportant;
	}

	public String getGuid() {
		return guid;
	}


	public void setGuid(String guid) {
		this.guid = guid;
	}

	public MsgSourceType getMsgType() {
		return msgSourceType;
	}

	public void setMsgType(MsgSourceType msgType) {
		this.msgSourceType = msgType;
	}
	
}
