/**
 * 
 */
package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

/**
 * MailBoxDLMapping collection entity
 * 
 * 
 *
 */
@Entity(value = "MailBoxDLMapping", noClassnameStored = true)
public class MailBoxDLMapping implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4418407258394683537L;
	@Id
	private String id;
	private String mappedDL;
	private MailBoxMappingType mappingType;
	private long minMemoryRequirementInMB;
	private long maxMemoryRequirementInMB;
	private boolean isToBeForceStarted;
	private boolean isToBeForceStopped;
	private CurrentMailBoxRunStatus currentRunStatus;
	/* TODO : Below login attribute will bew removed once AD authentication will be in place */
	private String loginSecretEnc;
	private String loginSecretEncIV;
	private String connectionURL;
	private String region;
	private Date startedAt;
	private Date stoppedAt;
	private String startedOn;
	private ModifiedBy modBy;
	private Date modDate;
	private String allowedDomains;
	private long readerBatchSize;
	private ExchangeConfig exchangeConfig;
	private String crtBy;
	private Date crtDate;
	private String platform;
	private String readerClusterNodeName;
	private boolean isAuthenticationExpired;
	private String exchangeVersion;
	
	private long readerMaxRetryCount;
	private boolean isRetryEnabled;
	private long sleepTimeReaderProcessingRetry;
	private long sleepTimeReaderInitializationRetry;
	
	public MailBoxDLMapping() {/*Do nothing*/}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getMappedDL() {
		return mappedDL;
	}
	public void setMappedDL(String mappedDL) {
		this.mappedDL = mappedDL;
	}
	public MailBoxMappingType getMappingType() {
		return mappingType;
	}
	public void setMappingType(MailBoxMappingType mappingType) {
		this.mappingType = mappingType;
	}
	public long getMinMemoryRequirementInMB() {
		return minMemoryRequirementInMB;
	}
	public void setMinMemoryRequirementInMB(long minMemoryRequirementInMB) {
		this.minMemoryRequirementInMB = minMemoryRequirementInMB;
	}
	public long getMaxMemoryRequirementInMB() {
		return maxMemoryRequirementInMB;
	}
	public void setMaxMemoryRequirementInMB(long maxMemoryRequirementInMB) {
		this.maxMemoryRequirementInMB = maxMemoryRequirementInMB;
	}
	public boolean isToBeForceStarted() {
		return isToBeForceStarted;
	}
	public void setToBeForceStarted(boolean isToBeForceStarted) {
		this.isToBeForceStarted = isToBeForceStarted;
	}
	public boolean isToBeForceStopped() {
		return isToBeForceStopped;
	}
	public void setToBeForceStopped(boolean isToBeForceStopped) {
		this.isToBeForceStopped = isToBeForceStopped;
	}
	public CurrentMailBoxRunStatus getCurrentRunStatus() {
		return currentRunStatus;
	}
	public void setCurrentRunStatus(CurrentMailBoxRunStatus currentRunStatus) {
		this.currentRunStatus = currentRunStatus;
	}
	public String getLoginSecretEnc() {
		return loginSecretEnc;
	}

	public void setLoginSecretEnc(String loginSecretEnc) {
		this.loginSecretEnc = loginSecretEnc;
	}

	public String getLoginSecretEncIV() {
		return loginSecretEncIV;
	}

	public void setLoginSecretEncIV(String loginSecretEncIV) {
		this.loginSecretEncIV = loginSecretEncIV;
	}
	
	public String getConnectionURL() {
		return connectionURL;
	}
	public void setConnectionURL(String connectionURL) {
		this.connectionURL = connectionURL;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public Date getStartedAt() {
		return startedAt;
	}
	public void setStartedAt(Date startedAt) {
		this.startedAt = startedAt;
	}
	public Date getStoppedAt() {
		return stoppedAt;
	}
	public void setStoppedAt(Date stoppedAt) {
		this.stoppedAt = stoppedAt;
	}
	public String getStartedOn() {
		return startedOn;
	}
	public void setStartedOn(String startedOn) {
		this.startedOn = startedOn;
	}
	public ModifiedBy getModBy() {
		return modBy;
	}
	public void setModBy(ModifiedBy modBy) {
		this.modBy = modBy;
	}
	public Date getModDate() {
		return modDate;
	}
	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}
	
	public String getAllowedDomains() {
		return allowedDomains;
	}

	public void setAllowedDomains(String allowedDomains) {
		this.allowedDomains = allowedDomains;
	}

	public long getReaderBatchSize() {
		return readerBatchSize;
	}

	public void setReaderBatchSize(long readerBatchSize) {
		this.readerBatchSize = readerBatchSize;
	}

	public ExchangeConfig getExchangeConfig() {
		return exchangeConfig;
	}

	public void setExchangeConfig(ExchangeConfig exchangeConfig) {
		this.exchangeConfig = exchangeConfig;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Date getCrtDate() {
		return crtDate;
	}

	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}
	
	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public String getReaderClusterNodeName() {
		return readerClusterNodeName;
	}

	public void setReaderClusterNodeName(String readerClusterNodeName) {
		this.readerClusterNodeName = readerClusterNodeName;
	}

	public boolean isAuthenticationExpired() {
		return isAuthenticationExpired;
	}

	public void setAuthenticationExpired(boolean authenticationExpired) {
		isAuthenticationExpired = authenticationExpired;
	}


	public String getExchangeVersion() {
	    return exchangeVersion;
	}

	public void setExchangeVersion(String exchangeVersion) {
	    this.exchangeVersion = exchangeVersion;
	}


	public long getReaderMaxRetryCount() {
	    return readerMaxRetryCount;
	}

	public void setReaderMaxRetryCount(long readerMaxRetryCount) {
	    this.readerMaxRetryCount = readerMaxRetryCount;
	}


	public boolean isRetryEnabled() {
	    return isRetryEnabled;
	}

	public void setRetryEnabled(boolean isRetryEnabled) {
	    this.isRetryEnabled = isRetryEnabled;
	}


	public long getSleepTimeReaderProcessingRetry() {
	    return sleepTimeReaderProcessingRetry;
	}

	public void setSleepTimeReaderProcessingRetry(long sleepTimeReaderProcessingRetry) {
	    this.sleepTimeReaderProcessingRetry = sleepTimeReaderProcessingRetry;
	}


	public long getSleepTimeReaderInitializationRetry() {
	    return sleepTimeReaderInitializationRetry;
	}

	public void setSleepTimeReaderInitializationRetry(long sleepTimeReaderInitializationRetry) {
	    this.sleepTimeReaderInitializationRetry = sleepTimeReaderInitializationRetry;
	}


	public enum CurrentMailBoxRunStatus {
		STARTED, STOPPED;
	}
	public enum ModifiedBy {
		DEDICATED_STARTER,DEDICATED_STOPPER,DEDICATED_MONITOR,
		PERSONAL_STARTER,PERSONAL_STOPPER,PERSONAL_MONITOR,
		//DEDICATED_STARTER_ECS,DEDICATED_STOPPER_ECS,DEDICATED_MONITOR_ECS,
		MAILBOX_OWNER,SYSTEM_ADMIN
	}
	public enum MailBoxMappingType {

		DEDICATED(1, "Dedicated Mailbox Mapping for DL"), 
		SHARED(2, "Shared Mailbox Mapping for DL"), 
		PERSONAL(3, "Personal Mailbox Mapping for Individual");

		private final Integer value;
		private final String description;

		private static Map<Integer, MailBoxMappingType> valueToDescriptionMapping;

		private MailBoxMappingType(Integer value, String description) {
			this.value = value;
			this.description = description;
		}

		public Integer getValue() {
			return value;
		}

		public String getDescription() {
			return description;
		}

		public static MailBoxMappingType getMailBoxMapping(int mappingType) {
			if (valueToDescriptionMapping == null) {
				initMapping();
			}
			return valueToDescriptionMapping.get(mappingType);
		}

		private static void initMapping() {
			valueToDescriptionMapping = new HashMap<>();
			for (MailBoxMappingType s : values()) {
				valueToDescriptionMapping.put(s.value, s);
			}
		}
	}
	
	public static class ExchangeConfig implements Serializable {
		private static final long serialVersionUID = 1L;
		
		private String hostName;
		private String attachmentPath;
		private long waitTimeBetweenPoll;
		private String supportEmail;
		private long maxErrorEmailCount;
		private String exchangeWebServiceUrl;
		private String domain;
		private long version;
		
		public String getHostName() {
			return hostName;
		}
		public void setHostName(String hostName) {
			this.hostName = hostName;
		}
		public String getAttachmentPath() {
			return attachmentPath;
		}
		public void setAttachmentPath(String attachmentPath) {
			this.attachmentPath = attachmentPath;
		}
		public long getWaitTimeBetweenPoll() {
			return waitTimeBetweenPoll;
		}
		public void setWaitTimeBetweenPoll(long waitTimeBetweenPoll) {
			this.waitTimeBetweenPoll = waitTimeBetweenPoll;
		}
		public String getSupportEmail() {
			return supportEmail;
		}
		public void setSupportEmail(String supportEmail) {
			this.supportEmail = supportEmail;
		}
		public long getMaxErrorEmailCount() {
			return maxErrorEmailCount;
		}
		public void setMaxErrorEmailCount(long maxErrorEmailCount) {
			this.maxErrorEmailCount = maxErrorEmailCount;
		}
		public String getExchangeWebServiceUrl() {
			return exchangeWebServiceUrl;
		}
		public void setExchangeWebServiceUrl(String exchangeWebServiceUrl) {
			this.exchangeWebServiceUrl = exchangeWebServiceUrl;
		}
		public String getDomain() {
			return domain;
		}
		public void setDomain(String domain) {
			this.domain = domain;
		}
		public long getVersion() {
			return version;
		}
		public void setVersion(long version) {
			this.version = version;
		}
		
	}
}
