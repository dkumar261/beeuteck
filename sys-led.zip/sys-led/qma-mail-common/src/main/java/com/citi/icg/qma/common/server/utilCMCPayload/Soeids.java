package com.citi.icg.qma.common.server.utilCMCPayload;

public class Soeids
{
    private String srcSys;

    private String soeId;

    public String getSrcSys ()
    {
        return srcSys;
    }

    public void setSrcSys (String srcSys)
    {
        this.srcSys = srcSys;
    }

    public String getSoeId ()
    {
        return soeId;
    }

    public void setSoeId (String soeId)
    {
        this.soeId = soeId;
    }

    @Override
    public String toString()
    {
        return "InputForCMC [srcSys = "+srcSys+", soeId = "+soeId+"]";
    }
}
			
	