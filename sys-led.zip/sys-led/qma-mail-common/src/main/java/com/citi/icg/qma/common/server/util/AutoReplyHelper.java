package com.citi.icg.qma.common.server.util;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.EmailUtil;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.InquiryMessageRef;
import com.citi.icg.qma.common.server.dao.KeyValue;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.persistence.AttachmentDAO;
import com.citi.icg.qma.common.server.dao.persistence.InquiryDAO;
import com.citi.icg.qma.common.server.dao.persistence.MongoDB;
import com.citi.icg.qma.common.server.dao.persistence.MongoMorphiaDAO;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import dev.morphia.query.Query;

public class AutoReplyHelper extends MongoMorphiaDAO 
{
	public static final String ALL = "All";
	public static final String ON_RECEIPT_OF_NEW_EMAIL = "On Receipt of New Email";
	public static final String ON_USER_ASSIGNMENT = "On User Assignment";
	private static final String CUSTOM_AUTO_RESPONSE_NEW_INQUIRY = "customAutoResponseNewInquiry";
	private static final String CUSTOM_AUTO_RESPONSE_USER_ASSIGNMENT = "customAutoResponseUserAssignment";
	private static final String USER_CONTACT_NUMBER = "[user_contact_number]";
	private static final String MANAGER_NAME = "[manager_name]";
	private static final String MANAGER_EMAIL_ADDRESS = "[manager_email_address]";
	private static final String MANAGER_PHONE_NUMBER = "[manager_phone_number]";

	private static final Logger logger = LoggerFactory.getLogger(AutoReplyHelper.class);
	
	public boolean sendAutoReply(String soeId, Long fromGroupId,Long inquiryId, String origEmail, boolean isInquiryRefSent, String references, boolean isNewInquiry) throws CommunicatorException
	{
		boolean isAutoReplySent = false;
		String template = getAutoReplyTemplate();
		User user = null;
		if(StringUtils.isNotEmpty(soeId)) {
			user = getUserById(soeId);
		}
		
		//Group fromGroup = CacheDAO.getInstance().getAllGroupsMap().get(fromGroupId);
		Group fromGroup = fromGroupId==null?null:QMACacheFactory.getCache().getAllGroupsMap().get(fromGroupId);
		if(fromGroup == null) {
			isAutoReplySent = false;
			return isAutoReplySent;
		}
		
		// C170665-4031 - Allow "Automated Response" for a DL to be more customizable by User
		if(fromGroup != null && fromGroup.isCustomizedAutoResponseEnabled()) {
			logger.info("Before populateCustomizedAutoResponseTemplate");
			String customAutoResponseOptions = fromGroup.getCustomAutoResponseOptions();
			logger.info("Custom Auto Response for User Assignment is enabled for Group :: {}, customAutoResponseOptions :: {}", fromGroupId, customAutoResponseOptions);
			String customTemplate = "";
			List<KeyValue> autoResponseDetails = fromGroup.getAutoResponseDetails();
			
			Map<String, String> autoResponseTemplateMap = new HashMap<>();
			if (autoResponseDetails != null && ! autoResponseDetails.isEmpty()){
				for (KeyValue keyValue : autoResponseDetails) {
					autoResponseTemplateMap.put(keyValue.getKey(), keyValue.getValue());
				}
			}
			
			if(!isNewInquiry && (ON_USER_ASSIGNMENT.equalsIgnoreCase(customAutoResponseOptions) || ALL.equalsIgnoreCase(customAutoResponseOptions))) {
				logger.info("Custom Auto Response for User Assignment :: {}", customAutoResponseOptions);
				String inquiryIdStr = inquiryId == null ? "" : inquiryId.toString();
				customTemplate = autoResponseTemplateMap.getOrDefault(CUSTOM_AUTO_RESPONSE_USER_ASSIGNMENT, "");
				if(user != null) {
					List<String> missingAttributes = validateAttributes(user, customTemplate);
					if(!missingAttributes.isEmpty()) {
						logger.info("missingAttributes in user object :: {}, {}" ,user != null ? user.getId() : "" ,missingAttributes);
						isAutoReplySent = false;
						return isAutoReplySent;
					}
				}
				
				customTemplate = populateCustomizedAutoResponseTemplate(user, inquiryIdStr, customTemplate);
			} 
			else if(isNewInquiry && (ON_RECEIPT_OF_NEW_EMAIL.equalsIgnoreCase(customAutoResponseOptions) || ALL.equalsIgnoreCase(customAutoResponseOptions))) {
				logger.info("Custom Auto Response for New Email :: {}", customAutoResponseOptions);
				String inquiryIdStr = inquiryId == null ? "" : inquiryId.toString();
				customTemplate = autoResponseTemplateMap.getOrDefault(CUSTOM_AUTO_RESPONSE_NEW_INQUIRY, "");
				customTemplate = populateCustomizedAutoResponseTemplate(user, inquiryIdStr, customTemplate);
			} else {
				logger.info("Custom Auto Response Not Sent :: {}", fromGroupId);
				isAutoReplySent = false;
				return isAutoReplySent;
			}
			template = customTemplate;
		} else {
			if (user != null && (StringUtils.isBlank(user.getPhone()) || StringUtils.isBlank(user.getMgrEmail())
					|| StringUtils.isBlank(user.getMgrName()) || StringUtils.isBlank(user.getMgrPhone()))) {
				logger.info(
						"AutoReply not sent as User's Contact Or Manager's Details are not available. user is :: {}, {}, {}, {}, {}",
						user.getId(), user.getPhone(), user.getMgrEmail(), user.getMgrName(), user.getMgrPhone());
				isAutoReplySent = false;
				return isAutoReplySent;
			}
			logger.info("Before populateTemplate");
			template = populateTemplate(template,user, fromGroup);
		}
		
		template = template + "\n" + "___________________________________________________________________________________________________________\n";
		
	/*	Query<Conversation> query = mongoDatastore.createQuery(Conversation.class).filter("inquiryId", inquiryId)
				.order("-modDate").limit(1);
		Conversation conv = query.asList().get(0);*/
		//String comments = conv.getContent();
		
		String toEmailAddress = origEmail;
		logger.info("toEmailAddress1 :: {}", toEmailAddress);
		Conversation conv = getExternalClientLatestConversation(inquiryId, fromGroup);
		
		boolean isInternalQmaDL = false;
		if(conv == null) {
			isInternalQmaDL = true;
			logger.info("isInternalQmaDL :: {}",isInternalQmaDL);
			Map<String, Object> clientLatestConvMap = getInternalClientLatestConversation(inquiryId, fromGroup);
			conv = (Conversation) clientLatestConvMap.getOrDefault("clientLatestConv", null);
		}
		
		logger.info("toEmailAddress2 :: {}", toEmailAddress);
		
		String emailContent = GenericUtility.checkAndFetchConvContent(conv);
		logger.info("Conversation ID is -------> {}",(null == conv ? conv : conv.getId()));
		
		LinkedHashMap<String, File> inlineFileMap = new LinkedHashMap<String, File>();
		
		commentsWithImagePlaceholder(emailContent,inlineFileMap );
		
	//	List<ConversationRecipient> rec = conv.getRecipients();
	//	Iterator<ConversationRecipient> itr = rec.iterator();
//		String toEmailAddress = origEmail;
		
		/*while (itr.hasNext())
		{
			ConversationRecipient conversationRecipient = (ConversationRecipient) itr.next();
			if (conversationRecipient.getToFrom().equalsIgnoreCase("FROM"))
			{
				String fromUserId = conversationRecipient.getUserId();//getEmailAddr();
				if (fromUserId != null && fromUserId.contains("@"))
				{
					toEmailAddress = fromUserId;
					break;
				}
				User fromUser = CacheDAO.getInstance().getUserDetailsMap().get(fromUserId.toUpperCase());
				if (user != null)
				{
					toEmailAddress = fromUser.getEmail();
				}
				break;

			}
		}*/
	
		List<String> toListAddress = new ArrayList<String>();
		//toListAddress.add("XXXXXX@XXXX.XXXX.XXX"");// TODO:for testing, COMMENT LATER
		toListAddress.add(toEmailAddress); //TODO: ENABLE LATER.
		
		String finalContent = template + "\n" + getHeader(conv, isInternalQmaDL) + "\n"+ emailContent;
		
		if (!isInquiryRefSent)
		{
			String inquiryRef = InquiryDAO.INQUIRY_REF_ID_STRING.replace("[INQUIRY_ID]", "" + inquiryId);
			// conversationContent = !conversationContent.contains("<p id=\"inquiryRefId\"") ? conversationContent+inquiryRef : conversationContent;
			finalContent = finalContent + inquiryRef;
		}
		
		Long[] inquiryIdArray = new Long[1];
		inquiryIdArray[0]= inquiryId;
		
		if (references == null)
		{
			Map<Long, HashMap<String, String>> referencesAndLatestMsgIdForInquiryMap = getReferencesAndLatestMsgIdForInquiry(inquiryIdArray);
			HashMap<String, String> refMsgIdMap = referencesAndLatestMsgIdForInquiryMap.get(inquiryId);

			// String references = null;
			if (refMsgIdMap != null)
			{
				references = refMsgIdMap.get("references");
			}
		}
		String subject = (conv != null) ? conv.getSubject() : "";
	
		if ( StringUtils.isNotBlank(subject) && !subject.startsWith("RE:"))
		{
			subject = "RE:"+ subject;
		}
		
		LinkedHashMap<File, String> fileMap = new LinkedHashMap<File, String>();
		
		
		//System.out.println(getHeader(user.getEmail(), toEmailAddress, conv) + template + "\n" + comments);
		/*[C153176-823]:support for foreign language changes*/
		//StaticData staticData = CacheDAO.getInstance().getDefaultStaticData();
		//String characterEncoding = staticData.getEnableCharacterEncoding();
		String characterEncoding=QMACacheFactory.getCache().getEnableCharacterEncoding();
		boolean charEncodingFlag = false;
		if("Y".equalsIgnoreCase(characterEncoding)){
			charEncodingFlag=true;
		}
		
		// C170665-4031 - User is not available for New Inquiry Flow
		String senderEmail = "";
		if(user != null) {
			senderEmail = user.getEmail();
			
			logger.info("Before EmailUtil.sendMailWithMultipleFileAttachments1 :: {}, {}, {}",isNewInquiry, subject, references);
			logger.info("sendMailWithMultipleFileAttachments1 :: toListAddress:{}, from:{}, Sender:{}",toListAddress, fromGroup.getGroupEmail(), senderEmail);
			
			EmailUtil.sendMailWithMultipleFileAttachments(toListAddress, null, null, fromGroup.getGroupEmail(), subject, 
					finalContent,  fileMap, inlineFileMap,
					references, senderEmail, false, true,false,true,charEncodingFlag, null);
			logger.info("AutoReplyHelper.sendAutoReply :: After EmailUtil.sendMailWithMultipleFileAttachments");
			isAutoReplySent = true;
		} else {
			try {
				EmailUtil.sendEmailFromQMAGroup(references, isNewInquiry, fromGroup, inlineFileMap, toListAddress, finalContent,subject, fileMap, charEncodingFlag);
			} catch (Exception e) {
				isAutoReplySent = false;
				logger.error("Exception in sendEmailFromQMAGroup :: ",e);
			}
		}
		
		return isAutoReplySent;
	}

	private List<String> validateAttributes(User user, String customTemplate) {
		List<String> missingAttributes = new ArrayList<>();
		if(customTemplate.contains(USER_CONTACT_NUMBER) && StringUtils.isBlank(user.getPhone())) {
			missingAttributes.add(USER_CONTACT_NUMBER);
		}
		if(customTemplate.contains(MANAGER_NAME) && StringUtils.isBlank(user.getMgrName())) {
			missingAttributes.add(MANAGER_NAME);
		}
		if(customTemplate.contains(MANAGER_PHONE_NUMBER) && StringUtils.isBlank(user.getMgrPhone())) {
			missingAttributes.add(MANAGER_PHONE_NUMBER);
		}
		if(customTemplate.contains(MANAGER_EMAIL_ADDRESS) && StringUtils.isBlank(user.getMgrEmail())) {
			missingAttributes.add(MANAGER_EMAIL_ADDRESS);
		}
		return missingAttributes;
	}
	
	/**
	 * @param inquiryId
	 * @return
	 * retrieve the latest conversation for auto reply.
	 * We are using DBCursor instead of Mongo morphia in order to avoid large number of records.
	 * after getting the correct conversation Id we are hitting DB again to get the conversation object 
	 * [C153176-1587] - QMA Group Automated notification issue - Internal conversations is sent to external user
	 */
	private Conversation getExternalClientLatestConversation(Long inquiryId, Group fromGroup) {

		BasicDBObject elementMatchQuery = new BasicDBObject("toFrom", "FROM").append("emailAddr", new BasicDBObject("$exists", true));
		String PROJECTIONQUERY = "{ _id : 1,recipients : 1, modDate: 1}";
		DBObject projection = BasicDBObject.parse(PROJECTIONQUERY);
		BasicDBObject finalQuery = new BasicDBObject("inquiryId", inquiryId).append("recipients", new BasicDBObject("$elemMatch", elementMatchQuery));
		DBCursor cursorDoc = MongoDB.instance().getDB().getCollection("Conversation").find(finalQuery, projection).sort(new BasicDBObject("modDate", -1));
		
		
		Conversation clientLatestConv = null;
		long convId = 0;
		conversationLoop:
		while (cursorDoc.hasNext()) {
			DBObject convDbObj = cursorDoc.next();
			List<BasicDBObject> receipientList = (List<BasicDBObject>) convDbObj.get("recipients");
			QMACache qmaCache = QMACacheFactory.getCache();
			String externalRecepientMailId = null;
			for (BasicDBObject receipient : receipientList) {
				externalRecepientMailId = (String) receipient.get("emailAddr");
				if (null != externalRecepientMailId && externalRecepientMailId.contains("@") && GenericUtility.isAutoReplyEnabled(externalRecepientMailId, fromGroup, qmaCache)) {
					convId = (long) convDbObj.get("_id");
					Query<Conversation> convQuery = mongoDatastore.createQuery(Conversation.class).filter("_id",convId);
					clientLatestConv = convQuery.asList().get(0);
					break conversationLoop;
					
					/*clientLatestConv = new Conversation();
					System.out.println("conv Id ====>"+convId);
					clientLatestConv.setId(convId);
					clientLatestConv.setInquiryId(inquiryId);
					clientLatestConv.setAction(convDbObj.get("action").toString());
					clientLatestConv.setContent(convDbObj.get("content").toString());
					clientLatestConv.setSentDate((Date) convDbObj.get("sentDate"));
					clientLatestConv.setReceiptDate((Date) convDbObj.get("receiptDate"));
					clientLatestConv.setSubject(convDbObj.get("subject").toString());
					clientLatestConv.setAudFlag(convDbObj.get("audFlag").toString());
					clientLatestConv.setUrgentFlag(convDbObj.get("urgentFlag").toString());
					clientLatestConv.setCrtDate((Date) convDbObj.get("crtDate"));
					clientLatestConv.setModDate((Date) convDbObj.get("modDate"));
					clientLatestConv.setCrtBy(convDbObj.get("crtBy").toString());
					clientLatestConv.setModBy(convDbObj.get("modBy").toString());
					clientLatestConv.setRecipients(receipientList);*/

				}
			}

		}

		return clientLatestConv;
	}
	
	private Map<String, Object> getInternalClientLatestConversation(Long inquiryId, Group fromGroup) {
		logger.info("Start method getInternalClientLatestConversation");
		BasicDBObject elementMatchQuery = new BasicDBObject("toFrom", "FROM").append("groupId", new BasicDBObject("$exists", true));
		String PROJECTIONQUERY = "{ _id : 1,recipients : 1, modDate: 1}";
		DBObject projection = BasicDBObject.parse(PROJECTIONQUERY);
		BasicDBObject finalQuery = new BasicDBObject("inquiryId", inquiryId).append("recipients", new BasicDBObject("$elemMatch", elementMatchQuery));
		DBCursor cursorDoc = MongoDB.instance().getDB().getCollection("Conversation").find(finalQuery, projection).sort(new BasicDBObject("modDate", -1));
		
		
		Conversation clientLatestConv = null;
		Map<String, Object> clientLatestConvMap = new HashMap<>();
		long convId = 0;
		conversationLoop:
		while (cursorDoc.hasNext()) {
			DBObject convDbObj = cursorDoc.next();
			List<BasicDBObject> receipientList = (List<BasicDBObject>) convDbObj.get("recipients");
			QMACache qmaCache = QMACacheFactory.getCache();
			String internalRecepientMailId = null;
			logger.info("receipientList :: {}", receipientList != null ? receipientList.size() : null);
			for (BasicDBObject receipient : receipientList) {
				if(receipient != null && "FROM".equals(receipient.getString("toFrom"))) {
					Long fromGroupId = (Long) receipient.get("groupId");
					internalRecepientMailId = QMACacheFactory.getCache().getGroupIdToEmailMap().getOrDefault(fromGroupId, null);
					logger.info("getInternalClientLatestConversation :: internalRecepientMailId :: {}-{}", fromGroupId, internalRecepientMailId);
					if (null != internalRecepientMailId && internalRecepientMailId.contains("@") && GenericUtility.isAutoReplyEnabled(internalRecepientMailId, fromGroup, qmaCache)) {
						convId = (long) convDbObj.get("_id");
						Query<Conversation> convQuery = mongoDatastore.createQuery(Conversation.class).filter("_id",convId);
						clientLatestConv = convQuery.asList().get(0);
						clientLatestConvMap.put("clientLatestConv", clientLatestConv);
						clientLatestConvMap.put("internalRecepientMailId", internalRecepientMailId);
						break conversationLoop;
					}
				}
			}
		}
		logger.info("End method getInternalClientLatestConversation :: {}", clientLatestConv != null ? clientLatestConv.getId() : null);
		return clientLatestConvMap;
	}
	
	private String getHeader(Conversation conv, boolean isInternalQmaDL)
	{
		String header = "<br><br><br>";
		// header += "<br><br><br>"+ getActionSignature() +"<br>"+ getDisclaimerActionInquiry(selectedFromGroup)+"<br><br>";
		header += "<strong>From: </strong>" + getEmailDetailsByConversation(conv, "FROM", isInternalQmaDL) + "<br>";
		header += "<strong>Sent: </strong>" + conv.getModDate() + "<br>";
		header += "<strong>To: </strong>" + getEmailDetailsByConversation(conv, "TO", isInternalQmaDL) + "<br>";
		header += "<strong>Subject: </strong>" + conv.getSubject() + "<br><br>";
		return header;
	}
	public  Map<Long, HashMap<String, String>>  getReferencesAndLatestMsgIdForInquiry(Long[] inquiryIdArray) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		HashMap<Long, HashMap<String, String>> referencesAndLatestMsgIdForInquiryMap = new HashMap<Long, HashMap<String, String>>();
		
		
		try
		{
			Query<InquiryMessageRef> query = mongoDatastore.createQuery(InquiryMessageRef.class);
			
			query.filter("inquiryId in", inquiryIdArray);
			List<InquiryMessageRef> inquiryMessageRefList = query.asList();

			if ( inquiryMessageRefList != null && !inquiryMessageRefList.isEmpty() )//Sonar Fix -- Collection.isEmpty() should be used to test for emptiness
			{
				for (InquiryMessageRef inquiryMessageRef : inquiryMessageRefList)
				{
					HashMap<String, String>  refMsgMap = new HashMap<String, String>();
					
					String references = inquiryMessageRef.getReferences();
					String latestMessageId = inquiryMessageRef.getLatestMessageId();		
					
					refMsgMap.put("references", references);
					refMsgMap.put("latestMessageId", latestMessageId);
					
					referencesAndLatestMsgIdForInquiryMap.put(inquiryMessageRef.getInquiryId(),refMsgMap);

				}
			}

		}
		catch (Exception e)
		{
			logger.error(" Issue happened in method getReferencesForInquiry ", e);
			throw new CommunicatorException(" Issue happened in method getReferencesForInquiry ", e);
		}

		return referencesAndLatestMsgIdForInquiryMap;
	}
	private static File getDocumentFile(String docId,Logger logger) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one, XmException
	{
		File file = null;
		try
		{		
			AttachmentDAO attachmentDao = new AttachmentDAO();

			Map<String, Object> mongoDataMap = attachmentDao.getFile(docId);

			file = (File) mongoDataMap.get("fileObject");
			
		}
		catch (Exception e)
		{
			logger.error("Exception while reading file from Mongo DB.", e);
			
			throw new CommunicatorException(AutoReplyHelper.class + " Issue downloading file from Mongo DB , id is " + docId, e);
		}
		return file;
	}
	
	private static String commentsWithImagePlaceholder(String comments, Map<String, File> inlineFileMap) throws CommunicatorException
	{
		String token =GenericUtility.getAppServerContextFromDB()+"/rest/imageBrowser/image?path=";

		if (StringUtils.isBlank(comments) || !comments.contains(token))
		{
			return comments;
		}
		int ind = comments.indexOf(token);
		int startIndex = ind + token.length();
		int endIndex = startIndex + comments.substring(ind + token.length()).indexOf("\"");

		String docId = comments.substring(startIndex, endIndex);
		File file = getDocumentFile(docId,logger);
		
				
		inlineFileMap.put(file.getName(), file);

		String c = comments.substring(0, ind) + "cid:" + file.getName() + "\">";
		//Replaced unwanted content from image url.
		c=replaceBetween(c,c.indexOf("src="),c.indexOf("cid:"),"src=\"");
		endIndex = startIndex + comments.substring(startIndex).indexOf("/>") + 2;

		return c + commentsWithImagePlaceholder(comments.substring(endIndex), inlineFileMap);
	}
	
    private static String replaceBetween(String comments, int startIndex, int endIndex, String replaceStr)
    {
    	if(endIndex >-1 && startIndex >-1 && (endIndex-startIndex)<50)//make changes  on the basis of server name when required to remove non-relative part of url 
    	{
    	   return comments.substring(0, startIndex) + replaceStr + comments.substring(endIndex);
    	}
    	else
    	{
    		return comments;	
    	}
    }
	
	private String getAutoReplyTemplate()
	{
		Query<Config> adminRoleQuery = mongoDatastore.createQuery(Config.class).filter("_id", "AutoResponse");
		String template = null;
		
		if(adminRoleQuery!=null && !adminRoleQuery.asList().isEmpty() && adminRoleQuery.asList().get(0)!=null)
		{
			template = adminRoleQuery.asList().get(0).getTemplate();
		}
		
		return template;
	}
	
	private String populateCustomizedAutoResponseTemplate(User user, String inquiryId, String customTemplate) {
		customTemplate = customTemplate.replace("[user_firstname user_lastname]",(user == null || user.getName() == null) ? "" : user.getName());
		customTemplate = customTemplate.replace("[user_firstname]", (user == null || user.getFirstName() == null) ? "" : user.getFirstName());
		customTemplate = customTemplate.replace("[user_lastname]", (user == null || user.getLastName() == null) ? "" : user.getLastName());
		customTemplate = customTemplate.replace(USER_CONTACT_NUMBER, (user == null || user.getPhone() == null) ? "" : user.getPhone());
		customTemplate = customTemplate.replace(MANAGER_NAME, (user == null || user.getMgrName() == null) ? "" : user.getMgrName());
		customTemplate = customTemplate.replace(MANAGER_PHONE_NUMBER, (user == null || user.getMgrPhone() == null) ? "" :user.getMgrPhone() );
		customTemplate = customTemplate.replace(MANAGER_EMAIL_ADDRESS, (user == null || user.getMgrEmail() == null) ? "" : user.getMgrEmail());
		customTemplate = customTemplate.replace("[inquiry_id]", inquiryId);
		return customTemplate;
	}
	
	private String populateTemplate(String template, User user, Group fromGroup)
	{
		List<KeyValue> autoResponseDetails = fromGroup.getAutoResponseDetails(); 
		String groupSignature="";
		if (autoResponseDetails != null && ! autoResponseDetails.isEmpty())
		{
			for (KeyValue item : autoResponseDetails)
			{
				String key = item.getKey();
				String value = item.getValue();
				if ("groupName".equalsIgnoreCase(key)  && StringUtils.isNotBlank(value))
				{
					
					groupSignature=value;
					
				}
			}
		
		}
		template = template.replace("[group_signature]", groupSignature);
		template = template.replace("[user_firstname user_lastname]", user.getName() == null ? "" : user.getName());
		template = template.replace("[user_firstname]", user.getFirstName() == null? "" : user.getFirstName());
		template = template.replace(USER_CONTACT_NUMBER, user.getPhone() == null? "" : user.getPhone());
		template = template.replace(MANAGER_NAME, user.getMgrName() == null ? "" : user.getMgrName());
		template = template.replace(MANAGER_PHONE_NUMBER, user.getMgrPhone() == null ? "" :user.getMgrPhone() );
		template = template.replace(MANAGER_EMAIL_ADDRESS, user.getMgrEmail() == null ? "" : user.getMgrEmail());
	
		
		return template;
	}
	
	private User getUserById(String soeId) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		Query<User> query = null;
		User user = null;
		try
		{
			query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
			
			user = query.get();
			if (user == null)
			{
				logger.error("No Active User data found for userId=" + soeId);
				throw new CommunicatorException("Invalid UserId. Pl"
						+ "ease contact support.");
			}
		}
		catch (Exception e)
		{
			logger.error("Exception in getUserById for  user=" + soeId , e);
			throw new CommunicatorException("Exception in getUserById for  user=" + soeId);
		}
		
		return user;
	}
	
	public String getEmailDetailsByConversation(Conversation conversation, String type, boolean isInternalQmaDL) {
		logger.info("Start Method getEmailDetailsByConversation :: isInternalQmaDL-{}, type-{}",isInternalQmaDL, type);
		String email = null;

		int i = 0;

		for (ConversationRecipient conversationRecipient : conversation.getRecipients()) {
			logger.info("Inside conversation.getRecipients()");
			if (conversationRecipient != null && type.equalsIgnoreCase(conversationRecipient.getToFrom())) {
				logger.info("conversationRecipient.getEmailAddr() :: {}", conversationRecipient.getEmailAddr());
				if (i == 0) {
					if(isInternalQmaDL) {
						String emailAddress = QMACacheFactory.getCache().getGroupIdToEmailMap().getOrDefault(conversationRecipient.getGroupId(), null);
						logger.info("isInternalQmaDL :: {}, {}",conversationRecipient.getGroupId(), emailAddress);
						email = conversationRecipient.getDisplayName() + "<" + emailAddress + ">";
					} else {
						email = conversationRecipient.getDisplayName() + "<" + conversationRecipient.getEmailAddr() + ">";
					}
					if (type.equals("FROM")) {
						break;
					}
				} else {
					if(isInternalQmaDL) {
						String emailAddress = QMACacheFactory.getCache().getGroupIdToEmailMap().getOrDefault(conversationRecipient.getGroupId(), null);
						email = email + ";" + conversationRecipient.getDisplayName() + "<" + emailAddress + ">";
					} else {
						email = email + ";" + conversationRecipient.getDisplayName() + "<" + conversationRecipient.getEmailAddr() + ">";
					}
				}
			}

		}
		logger.info("End Method getEmailDetailsByConversation");
		return email;

	}
	public void prepareTOCCList(ConversationRecipient conversationRecipient, String toCc, List<String> toCcListAddress) throws CommunicatorException//Sonar Fix -- Define and throw a dedicated exception instead of using a generic one
	{
		if (conversationRecipient != null && toCc.equalsIgnoreCase(conversationRecipient.getToFrom()))
		{
			String email = conversationRecipient.getEmailAddr();
			try
			{
				email = GenericUtility.getValidEmail(email);
			}
			catch (Exception e)
			{
				logger.error("Issue in email replace method, email is: " + email,e );
			}
			
			// External Email address case... displayName,email are same
			if (email != null)
			{
				logger.info(toCc+" group DL :::" + email);
				// In case of external email pass email in both
				toCcListAddress.add(email);
			}
		}
	}
	
	
	

}
