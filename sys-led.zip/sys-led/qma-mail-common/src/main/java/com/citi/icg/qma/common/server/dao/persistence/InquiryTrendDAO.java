package com.citi.icg.qma.common.server.dao.persistence;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.InquiryTrendChartData;
import com.citi.icg.qma.common.server.dao.Workflow;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

import dev.morphia.query.Query;

public class InquiryTrendDAO extends MongoMorphiaDAO{
	
	private static final String STATUS = "status";
	private static final String CRT_DATE = "crtDate";
	private static final String MOD_DATE = "modDate";
	private static final String RE_AGE_DATE = "reAgeDate";
	private static final Logger subLogger = LoggerFactory.getLogger(InquiryTrendDAO.class);
	private static InquiryTrendDAO instance = null;
	private static final String ASSIGNED_GROUP_ID_KEY = "assignedGroupId";
	

	public static synchronized InquiryTrendDAO getInstance()//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
	{
		if (instance == null) {
			instance = new InquiryTrendDAO();
		}
		return instance;
	}
	
	/**
	 * To insert/update count in inquiry trend chart collection
	 * @param groupId
	 */
	public void insertInquiryTrendData(Long groupId, List<Workflow> workFlowList, Object actionTime)
	{
		subLogger.info("InquiryTrendDAO.class #insertInquiryTrendData  group Id: " + groupId);
		try
		{
			
			if (groupId != null)
			{
				
				Date ldateCal = getCalenderDate();
				InquiryTrendChartData inquiryTrendObj;
				
				Query<InquiryTrendChartData> query = mongoDatastore.createQuery(InquiryTrendChartData.class).filter("groupId", groupId).filter("date", ldateCal);
				inquiryTrendObj = query.first();
				
				//check for non inquiry 
				Workflow workflowObj = getWorkflowForGroupId(groupId, workFlowList);
				boolean isNonInquiry = null!=workflowObj && null!=workflowObj.getRulesFlag() && workflowObj.getRulesFlag().getMarkAsNonInquiry();
				subLogger.info("groupId : "+groupId+" and non inquiry flag : "+isNonInquiry);
				
				inquiryTrendObj = updateInquiryCount(groupId, ldateCal, inquiryTrendObj, isNonInquiry);
				
				setInquiryTimeFrameData(groupId, workflowObj, actionTime, inquiryTrendObj, isNonInquiry);
				
				
				persist(inquiryTrendObj);
				
				subLogger.info("Data save for group name: "+inquiryTrendObj.getGroupName() + " and date : "+inquiryTrendObj.getDate());
			}
			else
			{
				subLogger.info("group id is not valid");
			}

		}
		catch (Exception e)
		{
			subLogger.error("Exception in InquiryTrendDAO.insertInquiryTrendData", e);
		}
	}

	/**
	 * @param groupId
	 * @param ldateCal
	 * @param inquiryTrendObj
	 * @param isNonInquiry 
	 * @return
	 */
	private InquiryTrendChartData updateInquiryCount(Long groupId, Date ldateCal,
			InquiryTrendChartData inquiryTrendObj, boolean isNonInquiry) {
		if(inquiryTrendObj != null){
			subLogger.info("updating count for " + " - group Id: " + groupId + " and date :" + ldateCal);
			long dbCount = 0;
			if(isNonInquiry) {
				dbCount = inquiryTrendObj.getNonInquiryCount();
				dbCount = dbCount + 1;
				inquiryTrendObj.setNonInquiryCount(dbCount);
			} else {
				dbCount = inquiryTrendObj.getCount();
				dbCount = dbCount + 1;
				inquiryTrendObj.setCount(dbCount);
			}
		} else{
			subLogger.info("inserting count for " + " - group Id: " + groupId + " and date :" + ldateCal);
			//CacheDAO cacheDao = CacheDAO.getInstance();
			String groupName = QMACacheFactory.getCache().getGroupIdToNameMap().get(groupId);
			inquiryTrendObj = new InquiryTrendChartData();
			inquiryTrendObj.setGroupId(groupId);
			inquiryTrendObj.setGroupName(groupName);
			inquiryTrendObj.setDate(ldateCal);
			if(isNonInquiry) {
				inquiryTrendObj.setNonInquiryCount(1);
			} else {
				inquiryTrendObj.setCount(1);
			}
			
		}
		return inquiryTrendObj;
	}

	/**
	 * @param groupId
	 * @param workflowObj
	 * @param actionTime
	 * @param inquiryTrendObj
	 * @param isNonInquiry 
	 */
	private void setInquiryTimeFrameData(Long groupId, Workflow workflowObj, Object actionTime, InquiryTrendChartData inquiryTrendObj, boolean isNonInquiry) throws CommunicatorException {
		
		try {
			//Workflow workflowObj = getWorkflowForGroupId(groupId, workflowObj);
			if(workflowObj != null && workflowObj.getAssignedGroupId() != null){
				
				BasicDBObject bdoWorkflow = getWorkflowDetails(workflowObj);
				
				long inquiryAge = GenericUtility.getAgeOfAnInquiry(bdoWorkflow);
				String ageKey = getAgeBand(inquiryAge);
				String timeKey = getTimeFrame(actionTime); 
				if(!StringUtils.isEmpty(ageKey) && !StringUtils.isEmpty(timeKey)){
					setInquiryTrendTimeAndAge(ageKey, timeKey, inquiryTrendObj, isNonInquiry);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in InquiryTrendDAO.setInquiryTimeFrameData", e);
			throw new CommunicatorException("Exception in InquiryTrendDAO.setInquiryTimeFrameData", e);
		}
	}

	/**
	 * @param workflowObj
	 * @return
	 */
	private BasicDBObject getWorkflowDetails(Workflow workflowObj) throws CommunicatorException {
		BasicDBObject bdoWorkflow = new BasicDBObject();
		try {
		    	
			bdoWorkflow.put(ASSIGNED_GROUP_ID_KEY, workflowObj.getAssignedGroupId());
			bdoWorkflow.put(RE_AGE_DATE, workflowObj.getReAgeDate());
			bdoWorkflow.put(MOD_DATE, workflowObj.getModDate());
			bdoWorkflow.put(CRT_DATE, workflowObj.getCrtDate());
			bdoWorkflow.put(STATUS, workflowObj.getStatus());
		
		} catch (Exception e) {
			subLogger.error("Exception in InquiryTrendDAO.getWorkflowDetails", e);
			throw new CommunicatorException("Exception in InquiryTrendDAO.getWorkflowDetails", e);
		}
		return bdoWorkflow;
	}

	/**
	 * @param ageBandKey
	 * @param timeFrameKey
	 * @param inquiryTrendObj
	 * @param isNonInquiry 
	 */
	private void setInquiryTrendTimeAndAge(String ageKey, String timeKey, InquiryTrendChartData inquiryTrendObj, boolean isNonInquiry) throws CommunicatorException {
		try {
			Map<String,Object> timeFrameObj = null;;
			if(isNonInquiry) {
				timeFrameObj = inquiryTrendObj.getNonInquiryTimeFrame();
				timeFrameObj = updateTimeFrameObject(ageKey, timeKey, timeFrameObj);
				inquiryTrendObj.setNonInquiryTimeFrame(timeFrameObj);
			} else {
				timeFrameObj = inquiryTrendObj.getTimeFrame();
				timeFrameObj = updateTimeFrameObject(ageKey, timeKey, timeFrameObj);
				inquiryTrendObj.setTimeFrame(timeFrameObj);
			}
			
		} catch (Exception e) {
			subLogger.error("Exception in setInquiryTrendTimeFrame while setting age band and time frame :",e);
			throw new CommunicatorException("Exception in setInquiryTrendTimeFrame while setting age band and time frame", e);
		}
	}

	/**
	 * @param ageKey
	 * @param timeKey
	 * @param timeFrameObj
	 * @return
	 * @throws CommunicatorException
	 */
	private Map<String, Object> updateTimeFrameObject(String ageKey, String timeKey, Map<String, Object> timeFrameObj)
			throws CommunicatorException {
		BasicDBObject timeObj;
		if(null != timeFrameObj){
			if(null != timeFrameObj.get(timeKey)){
				timeObj = (BasicDBObject) timeFrameObj.get(timeKey);
				initializeTimeKey(ageKey, timeObj);
			} else {
				BasicDBObject ageBandObj = new BasicDBObject();
				ageBandObj.put(ageKey, 1);
				timeFrameObj.put(timeKey, ageBandObj);
			}
		} else {
			timeFrameObj = initializeTimeFrame(ageKey, timeKey);
		}
		return timeFrameObj;
	}

	/**
	 * @param ageKey
	 * @param count
	 * @param timeObj
	 */
	private void initializeTimeKey(String ageKey, BasicDBObject timeObj) throws CommunicatorException{
		try {
			if(null != timeObj.get(ageKey)){
				int count = (int) timeObj.get(ageKey);
				count = count + 1;
				timeObj.put(ageKey, count);
			} else {
				timeObj.put(ageKey, 1);
			}
		} catch (Exception e) {
			subLogger.error("Exception in initializeTimeKey :",e);
			throw new CommunicatorException("Exception in initializeTimeKey", e);
		}
	}

	/**
	 * @param ageKey
	 * @param timeKey
	 * @return
	 */
	private Map<String, Object> initializeTimeFrame(String ageKey, String timeKey) throws CommunicatorException {
		Map<String, Object> timeFrameObj;
		timeFrameObj = new HashMap<>();
		try {
			BasicDBObject ageBandObj = new BasicDBObject();
			ageBandObj.put(ageKey, 1);
			timeFrameObj.put(timeKey, ageBandObj);
		} catch (Exception e) {
			subLogger.error("Exception in initializeTimeFrame :",e);
			throw new CommunicatorException("Exception in initializeTimeFrame", e);
		}
		return timeFrameObj;
	}
	
	/**
	 * To get time frame using action time
	 * @param actionTime
	 * @return
	 */
	private String getTimeFrame(Object actionTime) throws CommunicatorException{
		String timeFrame = null;
		try {
			if(actionTime != null){
				Date dActionTime = (Date) actionTime;
				Calendar dateCal = Calendar.getInstance();
				dateCal.setTimeZone(TimeZone.getTimeZone("GMT"));
				dateCal.setTime(dActionTime);
				int hrs = dateCal.get(Calendar.HOUR_OF_DAY);
				if(hrs>=8 && hrs<12){
					timeFrame = "8to12";
				} else if(hrs>=12 && hrs<16){
					timeFrame = "12to4";
				} else if(hrs>=16 && hrs<20){
					timeFrame = "4to8";
				} else {
					timeFrame = "other";
				} 
			}
		} catch (Exception e) {
			subLogger.error("Exception in getTimeFrame action time  :"+actionTime,e);
			throw new CommunicatorException("Exception in getTimeFrame action time", e);
		}
		return timeFrame;
		
	}

	/**
	 * To get age band based on inquiry age
	 * @param inquiryAge
	 * @return
	 */
	private String getAgeBand(long inquiryAge) throws CommunicatorException {
		String ageBand = null;
		try {
			if(inquiryAge>=0 && inquiryAge<=1){
				ageBand = "0to1";
			} else if(inquiryAge>=2 && inquiryAge<=5){
				ageBand = "2to5";
			} else if(inquiryAge>=6 && inquiryAge<=15){
				ageBand = "6to15";
			} else if(inquiryAge>=16){
				ageBand = "gt16";
			}
		} catch (Exception e) {
			subLogger.error("Exception in getAgeBand inquiryAge  :"+inquiryAge,e);
			throw new CommunicatorException("Exception in getAgeBand inquiryAge", e);
		}
		return ageBand;
	}


	private Workflow getWorkflowForGroupId(Long groupId, List<Workflow> workFlowList) {
		Workflow workflowObj = new Workflow();
		if(!workFlowList.isEmpty()){
			for(Workflow workflow : workFlowList){
				Long assignedGroupId = workflow.getAssignedGroupId();
				String direction = workflow.getDirection();
				if(assignedGroupId != null && !StringUtils.isEmpty(direction) && StringUtils.equalsIgnoreCase(direction, "IN") && assignedGroupId.longValue() == groupId.longValue()){
					workflowObj = workflow;
					break;
				}
			}
		} else{
			subLogger.info("workflow list is empty");
		}
		return workflowObj;
	}

	/**
	 * @return current date 
	 */
	private Date getCalenderDate() {
		Calendar dateCal = Calendar.getInstance();
		dateCal.setTimeZone(TimeZone.getTimeZone("GMT"));
		dateCal.set(Calendar.HOUR_OF_DAY, 0);
		dateCal.set(Calendar.MINUTE, 0);
		dateCal.set(Calendar.SECOND, 0);
		dateCal.set(Calendar.MILLISECOND, 0);
		return dateCal.getTime();
	}
	
	/**
	 * Method to save action data in Inquiry trend chart data collection
	 * @param actionStatisticsObj
	 */
	public void saveTrendChartData(DBObject actionStatisticsObj, List<Workflow> workFlowList){
		try {
			subLogger.info("InquiryTrendDAO.saveTrendChartData");
			Object actionTime = actionStatisticsObj.get("actionTime");
			@SuppressWarnings("unchecked")
			List<BasicDBObject> recipients = (List<BasicDBObject>) actionStatisticsObj.get("recipients");
			for(BasicDBObject recipient : recipients){
				String groupId = recipient.getString("groupId");
				String toFrom = recipient.getString("toFrom");
				
				if(!StringUtils.isEmpty(groupId) && !StringUtils.isEmpty(toFrom) && !"FROM".equals(toFrom)){
					
					insertInquiryTrendData(Long.parseLong(groupId), workFlowList, actionTime);
				}
				
			}
		} catch (Exception e) {
			subLogger.error("Exception in InquiryTrendDAO.saveTrendChartData", e);
		}
	}
	
}
