package com.citi.icg.qma.common.core.subscriber.mails.entity;

import java.io.InputStream;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

@XStreamAlias("entry")
public class Attachment
{

	@XStreamOmitField
	private transient InputStream inputStream;
	@XStreamAlias("string")
	private String documentId;

	@XStreamAlias("string")
	private String fileName;

	public Attachment(String fileName, InputStream inputStream, String documentId)
	{
		this.fileName = fileName;
		this.inputStream = inputStream;
		this.documentId = documentId;
	}

	public Attachment(String fileName, InputStream inputStream)
	{
		this.fileName = fileName;
		this.inputStream = inputStream;
	}

	public String getDocumentId()
	{
		return documentId;
	}

	public void setDocumentId(String documentId)
	{
		this.documentId = documentId;
	}

	public String getFileName()
	{
		return fileName;
	}

	public InputStream getInputStream()
	{
		return inputStream;
	}
	
	//for kryo
	public Attachment() {
		super();
	}

	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	

	
	

}
