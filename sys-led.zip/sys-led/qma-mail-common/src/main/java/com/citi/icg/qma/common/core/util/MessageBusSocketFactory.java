package com.citi.icg.qma.common.core.util;

import java.io.File;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

public final class MessageBusSocketFactory {
	
	private static SSLConnectionSocketFactory socketFactory = null;
	
	private static final Logger subLogger = LoggerFactory.getLogger(MessageBusSocketFactory.class);
	
	
	private static final String CERT_FILENAME_KEY = "certFileName";
	private static final String ENCRYPTED_PASSWORD_KEY = "encryptedPassword";
	private static final String ENC_IV_PASSWORD_KEY = "passwordIVEncStr";
	
	private static final String CONFIG_MESSAGE_BUS_CONFIGURATION_KEY = "messageBusConfigMap";
	
	private MessageBusSocketFactory(){
		
	}
	
	/**
	 * This method provides singleton instance of SSLConnectionSocketFactory
	 * @return
	 */
	public static synchronized SSLConnectionSocketFactory getInstance(String certPath) {
		
				if (socketFactory == null) {
					try {
						String certFileName = getMessageBusConfigForKey(CERT_FILENAME_KEY);
						String encryptedPassword = getMessageBusConfigForKey(ENCRYPTED_PASSWORD_KEY);
						String passwordIVEncStr = getMessageBusConfigForKey(ENC_IV_PASSWORD_KEY);
						String certPassword = EncryptionDecryptionUtil.getInstance().getDecryptedPassword(encryptedPassword, passwordIVEncStr);
						
						String xmcEnvironment = System.getProperty(AppserverConstants.ENV_PARAM_KEY);
						
						if(StringUtils.isNotEmpty(certFileName) && StringUtils.isNotEmpty(certPassword)) {
							subLogger.info("Message bus :: ENV : {}, Message bus CERT FILE : {}, Message bus password :{} ",xmcEnvironment,certFileName, certPassword );

							String currentDirectory = certPath + certFileName;
							subLogger.info("CurrentDirectory: {}", currentDirectory);
							File file = new File(currentDirectory);

							subLogger.info("cert file       : [{}]", file.getAbsolutePath());
							
							SSLContextBuilder sslContextBuilder = SSLContextBuilder
					                .create()
					                .loadKeyMaterial(file, certPassword.toCharArray(), certPassword.toCharArray());
					              
							
							socketFactory = new SSLConnectionSocketFactory(sslContextBuilder.build());
							
							subLogger.info("Message Bus :: Environment is :{} using SSL enabled HttpClient.",xmcEnvironment);
							
						} else {
							subLogger.info("Message Bus :: Environment is :{} Not able to identify certificate paramteres from database.",xmcEnvironment);
						} 
					} catch (Exception e) {
						subLogger.warn("Message Bus :: Error while creating http client in SSLConnectionSocketFactory#getInstance() : ",e);
					}
				}
		return socketFactory;
	}
	
	/**
	 * This function provide value from Message bus config for requested key
	 * @param key
	 * @return Object
	 */
	private static String getMessageBusConfigForKey(String key) {
		String value = null;
		Map<String, Object> messageBusConfig = null;
		try {
			QMACache qmaCache = QMACacheFactory.getCache();
			if(null != qmaCache.getConfigById(CONFIG_MESSAGE_BUS_CONFIGURATION_KEY)) {
				messageBusConfig = qmaCache.getConfigById(CONFIG_MESSAGE_BUS_CONFIGURATION_KEY).getMessageBusConfigMap();
			}
			if( messageBusConfig != null && !StringUtils.isEmpty(key) ) {
				value = (String) messageBusConfig.get(key);
			}
		} catch (Exception e) {
			subLogger.warn("Error while retrieving value from Messagebus config :" , e );
		}
		return value;
	}

}
