package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

import com.citi.icg.qma.dao.ExchangeEventType;
import dev.morphia.annotations.Embedded;

@Embedded
public class ExchangeRecipient implements Serializable
{
	private static final long serialVersionUID = 8514818355953893305L;
	
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private Long groupId;
	private String userId;
	private String exchItemId;
	private String exchFolder;
	private String exchFolderId;

	private String retainedExchItemId;
	private String retainedExchFolder;
	private String retainedExchFolderId;
	private ExchangeEventType retainedOnEventType;

	public ExchangeRecipient()
	{

	}

	public ExchangeRecipient(Long groupId, String userId)
	{
		super();
		this.groupId = groupId;
		this.userId = userId;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getExchItemId() {
		return exchItemId;
	}

	public void setExchItemId(String exchItemId) {
		this.exchItemId = exchItemId;
	}

	public String getExchFolder() {
		return exchFolder;
	}

	public void setExchFolder(String exchFolder) {
		this.exchFolder = exchFolder;
	}

	public String getExchFolderId() {
		return exchFolderId;
	}

	public void setExchFolderId(String exchFolderId) {
		this.exchFolderId = exchFolderId;
	}

	public String getRetainedExchItemId() {
		return retainedExchItemId;
	}

	public void setRetainedExchItemId(String retainedExchItemId) {
		this.retainedExchItemId = retainedExchItemId;
	}

	public String getRetainedExchFolder() {
		return retainedExchFolder;
	}

	public void setRetainedExchFolder(String retainedExchFolder) {
		this.retainedExchFolder = retainedExchFolder;
	}

	public String getRetainedExchFolderId() {
		return retainedExchFolderId;
	}

	public void setRetainedExchFolderId(String retainedExchFolderId) {
		this.retainedExchFolderId = retainedExchFolderId;
	}

	public ExchangeEventType getRetainedOnEventType() {
		return retainedOnEventType;
	}

	public void setRetainedOnEventType(ExchangeEventType retainedOnEventType) {
		this.retainedOnEventType = retainedOnEventType;
	}

}
