package com.citi.icg.qma.performance.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.EmailUtil;

public class BulkMailGen {

	public static void main(String args[]) throws CommunicatorException {
		

		String subject = args[0];

		String c = args[1];
		int count = Integer.valueOf(c);

		String to=args[2];
		
		//java -cp qma-mail-common-0.0.1-SNAPSHOT.jar com.citi.icg.qma.performance.utils.BulkMailGen "Testign bulk mail" 2 "XXXXXX@XXXX.XXXX.XXX"
		

		ArrayList<String> toListAddress = new ArrayList<>();
		toListAddress.add(to);
		// toListAddress.add("XXXXXX@XXXX.XXXX.XXX"");
		// toListAddress.add("XXXXXX@XXXX.XXXX.XXX");

		LinkedHashMap<String, File> inlineFileMap = new LinkedHashMap<String, File>();
		LinkedHashMap<File, String> fileMap = new LinkedHashMap<File, String>();

		for (int i = 0; i < count; i++) {

			String subjectWithCounter = subject + ":" + i;

			String message = "<HTML> <HEAD>  <TITLE> HI </TITLE>  <META NAME=\"Generator\" CONTENT=\"EditPlus\">  <META NAME=\"Author\" CONTENT=\"\">  <META NAME=\"Keywords\" CONTENT=\"\">  <META NAME=\"Description\" CONTENT=\"\"> </HEAD>"
					+ " <BODY>  " + subjectWithCounter + "</BODY></HTML>";

//			EmailUtil.sendMailWithMultipleFileAttachments(toListAddress, null, null, "XXXXXX@XXXX.XXXX.XXX"",
//					subjectWithCounter, message, fileMap, inlineFileMap, null, "XXXXXX@XXXX.XXXX.XXX"", false, true,
//					false, false, false);
			/*
			 *
			 * sendMailWithMultipleFileAttachments(
			 * List<String> recipentsTo,
			 * List<String> recipentsCc, 
			 * List<String> recipentsBcc, 
			 * String from,
			 * String subject,
			 *  String message,
			 *   Map<File, String> fileMap,
			 * Map<String, File> inlineFileMap, 
			 *  String references,
			 *   String fromUserName, 
			 *   boolean highImportance, 
			 *   boolean isBbase64Encoding,
			 * boolean enableOnBehalfOf,
			 *  boolean isContentTypeJpeg,
			 *   boolean enableCharacterEncoding) throws CommunicatorException
			 */

		}

	}

}
