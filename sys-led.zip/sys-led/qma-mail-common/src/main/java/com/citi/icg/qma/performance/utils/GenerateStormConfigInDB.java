package com.citi.icg.qma.performance.utils;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.persistence.MongoMorphiaDAO;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

public class GenerateStormConfigInDB {
	private static final Logger logger = LoggerFactory.getLogger(GenerateStormConfigInDB.class);
	
	private static Map<String, Object> controllerConfig = null;
	

	
	public static void load() {
		
		//MongoMorphiaDAO dao = new MongoMorphiaDAO();
		Config config=QMACacheFactory.getCache().getConfigById("qmaStormConfig");;//dao.mongoDatastore.get(Config.class, "qmaStormConfig");
		//config=config==null?new Config():config;
		//config.setId("qmaStormConfig");
	
//		Map<String, Object> map = config.getQmaStormConfig();
		
	/*	BasicDBObject obj=new BasicDBObject();
		obj.put("parallelism_hint", 19);
		obj.put("keyValueList", gewLIst());
		
		
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("processorTopologyConfig", obj);
		map.put("controllerTopologyConfig", obj);
		map.put("snapshotTopologyConfig", obj);
		config.setQmaStormConfig(map);
		dao.mongoDatastore.save(config);*/
		
		Map<String, Object> map = config.getQmaStormConfig();
		BasicDBObject controllerTopologyConfig=(BasicDBObject) map.get("controllerTopologyConfig");
		Map<String, Object> m=getGeneratedMap((BasicDBList) controllerTopologyConfig.get("keyValueList"));
		controllerConfig=m;
		
		m.forEach((k,v)->{
	
		});
	}
	
	public static Map<String, Object> getConf(){
		load();
		return controllerConfig;
		
	}
	
	private static Map<String, Object> getGeneratedMap(BasicDBList list){
		Map<String, Object> map =new HashMap<String, Object>();
		for (Object object : list) {
			String key=(String) ((BasicDBObject)object).get("key");
			Object value=((BasicDBObject)object).get("value");
			map.put(key, value);
		}
		return map;
	}
	
	private static BasicDBList gewLIst() {
		Map<String,Object> map=getMaap();
		BasicDBList list=new BasicDBList();
		for (String key : map.keySet()) {
			BasicDBObject object=new BasicDBObject();
			object.put("key", key);
			object.put("value", map.get(key));
			list.add(object);
			//list.add(new KeyValueObject(key,));
		}
		return list;
	}
	private static Map<String,Object> getMaap() {
		
		Map<String,Object> map=new HashMap<>();
		
		map.put("topology.workers", 10);
		map.put("topology.worker.max.heap.size.mb", "-Xms2g -Xmx4g");
		map.put("topology.message.timeout.secs", 120);
		
		map.put("topology.worker.max.heap.size.mb", 4096);
		map.put("topology.max.spout.pending", 100);
		map.put("topology.backpressure.enable", true);
		map.put("topology.enable.message.timeouts",false);
		
		
		return map;
	}
}
