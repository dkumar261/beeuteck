package com.citi.icg.qma.common.server.dao.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.GenericUtil;

public class NetezzaDB
{
	
	private static final String NETEZZA_DRIVER = "org.netezza.Driver";
	private static Connection netezzaDBConnection = null; 
	private static NetezzaDB INSTANCE = null;
	private static final Logger LOGGER = LoggerFactory.getLogger(NetezzaDB.class);
	private NetezzaDB()
	{
		
		InputStream inputStream = null;
		
		try
		{
			Class.forName(NETEZZA_DRIVER);
			String xmcEnvironment = System.getProperty("icg.env");
			String propFile = "netezzadb-" + xmcEnvironment + ".properties";
			inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(propFile);
			Properties prop = new Properties();

			prop.load(inputStream);
			String url = prop.getProperty("url");
			String userName = prop.getProperty("userName");
			
			//String pwdEnc = prop.getProperty("password");
			//String pwdIVEnc = prop.getProperty("passwordIV");
			String password = GenericUtil.getDecryptedPassword(prop);
			
		//	String pwd = prop.getProperty("password");
			netezzaDBConnection = DriverManager.getConnection(url,userName,password);
			
			
			if(netezzaDBConnection!=null)
			{
				LOGGER.info("connection successful");
			}
			
		}
		catch(Exception e)
		{
			LOGGER.info("Exception caught in netezza"+e);
		}

	}
	
	public static synchronized NetezzaDB getInstance()//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
	{
		if (INSTANCE == null) {
			INSTANCE = new NetezzaDB();
		}
		return INSTANCE;
		
	}
	
	public Connection getConnection()
	{
		return netezzaDBConnection;
	}
	
	
	public static void main(String[] args)
	{
		
		try
		{
			NetezzaDB ndb = NetezzaDB.getInstance();
			Connection conn = ndb.getConnection();
			Statement statement = conn.createStatement();
				String query = "select * from ACTIONSTATISTICS where userid='XXXXXX'";
				
				ResultSet resultSet = statement.executeQuery(query);
				
				while(resultSet.next())
				{
					String userName = resultSet.getString("username");
					String groupName = resultSet.getString("groupname");
					
					LOGGER.info("Result obtained with user name as "+userName+" and group name as "+groupName);
			}
			
			
			
		}
		catch (SQLException e)
		{
			LOGGER.info("Exception occurred "+e);
		}
		
	}
	
	public void closeConnection()
	{
		try
		{
			if(netezzaDBConnection!=null)
			{
				netezzaDBConnection.close();
			}
		}
		catch(SQLException e)
		{
			LOGGER.info("Exception caught while closing the Netezza connection"+e);
		}
		
	}

}
