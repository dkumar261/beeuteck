package com.citi.icg.qma.common.server.dao;

import java.util.Date;

import org.bson.types.ObjectId;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "AutoAssignedInquiry", noClassnameStored = true)
public class AutoAssignedInquiry {
	@Id
	private ObjectId id;
	private Long inquiryId;
	private Date autoAssignStartTime;
	private Date autoAssignEndTime;
	private String actionBy;
	private Long assignedGroupId;
	private boolean processedFlag;
	public ObjectId getId() {
		return id;
	}
	public void setId(ObjectId id) {
		this.id = id;
	}
	public Long getInquiryId() {
		return inquiryId;
	}
	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}
	public Date getAutoAssignStartTime() {
		return autoAssignStartTime;
	}
	public void setAutoAssignStartTime(Date autoAssignStartTime) {
		this.autoAssignStartTime = autoAssignStartTime;
	}
	public Date getAutoAssignEndTime() {
		return autoAssignEndTime;
	}
	public void setAutoAssignEndTime(Date autoAssignEndTime) {
		this.autoAssignEndTime = autoAssignEndTime;
	}
	public String getActionBy() {
		return actionBy;
	}
	public void setActionBy(String actionBy) {
		this.actionBy = actionBy;
	}
	public Long getAssignedGroupId() {
		return assignedGroupId;
	}
	public void setAssignedGroupId(Long assignedGroupId) {
		this.assignedGroupId = assignedGroupId;
	}
	public boolean isProcessedFlag() {
		return processedFlag;
	}
	public void setProcessedFlag(boolean processedFlag) {
		this.processedFlag = processedFlag;
	}
	
}
