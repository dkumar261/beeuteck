package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

public class OrgPreferences implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8085637171287011714L;
	private String enableGroupLevelOverride;
	private String enableInquirySubStatus;

	public String getEnableGroupLevelOverride() {
		return enableGroupLevelOverride;
	}

	public void setEnableGroupLevelOverride(String enableGroupLevelOverride) {
		this.enableGroupLevelOverride = enableGroupLevelOverride;
	}

	public String getEnableInquirySubStatus() {
		return enableInquirySubStatus;
	}

	public void setEnableInquirySubStatus(String enableInquirySubStatus) {
		this.enableInquirySubStatus = enableInquirySubStatus;
	}
}
