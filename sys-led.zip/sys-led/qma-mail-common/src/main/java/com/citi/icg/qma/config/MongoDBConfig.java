package com.citi.icg.qma.config;

public class MongoDBConfig {

	private String mongoCluster;
	private String mongoSecondaryCluster;
	private String userName;
	private String password;
	private String passwordIV;
	private String dbName;
	private String backupdbName;
	
	private String mongoArchivalCluster;
	private String archivalUserName;
	private String archivalPassword;
	private String archivalPasswordIV;
	private String archivalDbName;
	private String archivalBackupdbName;
	private String archivalDbFidUserName;
	
	private String secretRetrivalEndpoint;
	private String secretRetrivalEndpointEcs;
	private String dbFidUserName;
	private String dbFidSecondaryUserName;
	private boolean cyberArkEnabled;
	private String serviceName;
	
	private String secondaryDbName;

	private String encryptionKeyNickName;
	private String connectionScheme;
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMongoCluster() {
		return mongoCluster;
	}

	public void setMongoCluster(String mongoCluster) {
		this.mongoCluster = mongoCluster;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPasswordIV() {
		return passwordIV;
	}

	public void setPasswordIV(String passwordIV) {
		this.passwordIV = passwordIV;
	}

	public String getDbName() {
		return dbName;
	}

	public void setDbName(String dbName) {
		this.dbName = dbName;
	}

	public String getBackupdbName() {
		return backupdbName;
	}

	public void setBackupdbName(String backupdbName) {
		this.backupdbName = backupdbName;
	}

	public String getMongoArchivalCluster() {
		return mongoArchivalCluster;
	}

	public void setMongoArchivalCluster(String mongoArchivalCluster) {
		this.mongoArchivalCluster = mongoArchivalCluster;
	}

	public String getArchivalUserName() {
		return archivalUserName;
	}

	public void setArchivalUserName(String archivalUserName) {
		this.archivalUserName = archivalUserName;
	}

	public String getArchivalPassword() {
		return archivalPassword;
	}

	public void setArchivalPassword(String archivalPassword) {
		this.archivalPassword = archivalPassword;
	}

	public String getArchivalPasswordIV() {
		return archivalPasswordIV;
	}

	public void setArchivalPasswordIV(String archivalPasswordIV) {
		this.archivalPasswordIV = archivalPasswordIV;
	}

	public String getArchivalDbName() {
		return archivalDbName;
	}

	public void setArchivalDbName(String archivalDbName) {
		this.archivalDbName = archivalDbName;
	}

	public String getArchivalBackupdbName() {
		return archivalBackupdbName;
	}

	public void setArchivalBackupdbName(String archivalBackupdbName) {
		this.archivalBackupdbName = archivalBackupdbName;
	}

	public String getArchivalDbFidUserName() {
		return archivalDbFidUserName;
	}

	public void setArchivalDbFidUserName(String archivalDbFidUserName) {
		this.archivalDbFidUserName = archivalDbFidUserName;
	}

	public String getSecretRetrivalEndpoint() {
		return secretRetrivalEndpoint;
	}

	public void setSecretRetrivalEndpoint(String secretRetrivalEndpoint) {
		this.secretRetrivalEndpoint = secretRetrivalEndpoint;
	}
	
	public String getSecretRetrivalEndpointEcs() {
		return secretRetrivalEndpointEcs;
	}

	public void setSecretRetrivalEndpointEcs(String secretRetrivalEndpointEcs) {
		this.secretRetrivalEndpointEcs = secretRetrivalEndpointEcs;
	}

	public String getDbFidUserName() {
		return dbFidUserName;
	}

	public void setDbFidUserName(String dbFidUserName) {
		this.dbFidUserName = dbFidUserName;
	}

	public boolean isCyberArkEnabled() {
		return cyberArkEnabled;
	}

	public void setCyberArkEnabled(boolean cyberArkEnabled) {
		this.cyberArkEnabled = cyberArkEnabled;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getSecondaryDbName() {
		return secondaryDbName;
	}

	public void setSecondaryDbName(String secondaryDbName) {
		this.secondaryDbName = secondaryDbName;
	}

	public String getEncryptionKeyNickName() {
		return encryptionKeyNickName;
	}

	public void setEncryptionKeyNickName(String encryptionKeyNickName) {
		this.encryptionKeyNickName = encryptionKeyNickName;
	}

	public String getMongoSecondaryCluster() {
		return mongoSecondaryCluster;
	}

	public void setMongoSecondaryCluster(String mongoSecondaryCluster) {
		this.mongoSecondaryCluster = mongoSecondaryCluster;
	}

	public String getDbFidSecondaryUserName() {
		return dbFidSecondaryUserName;
	}

	public void setDbFidSecondaryUserName(String dbFidSecondaryUserName) {
		this.dbFidSecondaryUserName = dbFidSecondaryUserName;
	}
	
	/**
	 * Retrieves the Connection String Scheme.
	 *
	 * @return the Connection String Scheme as a {@code String}
	 */
	public String getConnectionScheme() {
		return connectionScheme;
	}

	public void setConnectionScheme(String connectionScheme) {
		this.connectionScheme = connectionScheme;
	}

}
