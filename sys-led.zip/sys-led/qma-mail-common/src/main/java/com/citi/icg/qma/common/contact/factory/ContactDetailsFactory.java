package com.citi.icg.qma.common.contact.factory;


import com.citi.icg.qma.common.contact.exception.BadRequestException;
import com.citi.icg.qma.common.contact.tcl.TCLContactDetails;

public class ContactDetailsFactory {
	
	public static final String SOURCE_TCL="TCL";
	
	private static ContactDetails instanceObject;
	
	public ContactDetails getInstance(String source) throws BadRequestException {
		
		return ContactDetailsFactory.getInstant(source);
	}
	
	public static ContactDetails getInstant(String source) throws BadRequestException{
		if(SOURCE_TCL.equalsIgnoreCase(source)) {
			if(null != instanceObject)
				return instanceObject;
			instanceObject = new TCLContactDetails();
		}else 
			throw new BadRequestException("Unknow source "+ source);
		
		return instanceObject;
	}

}
