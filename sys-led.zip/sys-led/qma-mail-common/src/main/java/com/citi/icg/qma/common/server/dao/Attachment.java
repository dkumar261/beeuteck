package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Embedded;

/**
 * 
 *
 */
@Embedded
public class Attachment
{
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private String id;
	private String name;
	private String secure;
	private String fileInfo;
	//QMA-977 To display file size along with attachments.
	private double fileSize;
	// is secured(pa-ss-wd protected) by QMA or not . If document is protected by QMA then isSecuredBy is Y and fileInfo will have file information.
	//(if document is manually secured(pa-ss-wd protected protected) by User then fileInfo and isSecuredBy is null).
	private String isSecuredByQMA;
	
	//For storing external docID like taskize documentID in QMA�
	private String externalDocID;
	
	public Attachment()
	{
		super();
	}

	public Attachment(String name, String attachmentId)
	{
		super();
		this.name = name;
		this.id = attachmentId;
	}

	public Attachment(String name, String attachmentId, String secure)
	{
		super();
		this.name = name;
		this.id = attachmentId;
		this.secure = secure;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return "{" +
				"id='" + id + '\'' +
				", name='" + name + '\'' +
				'}';
	}

	public String getId() {
		return id;
	}

	/**
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	public String getSecure()
	{
		return secure;
	}

	public void setSecure(String secure)
	{
		this.secure = secure;
	}

	public String getFileInfo()
	{
		return fileInfo;
	}

	public void setFileInfo(String fileInfo)
	{
		this.fileInfo = fileInfo;
	}

	public double getFileSize() { return fileSize; }

	public void setFileSize(double fileSize) { this.fileSize = fileSize; }

	public String getIsSecuredByQMA()
	{
		return isSecuredByQMA;
	}

	public void setIsSecuredByQMA(String isSecuredByQMA)
	{
		this.isSecuredByQMA = isSecuredByQMA;
	}

	public String getExternalDocID() {
		return externalDocID;
	}

	public void setExternalDocID(String externalDocID) {
		this.externalDocID = externalDocID;
	}
}
