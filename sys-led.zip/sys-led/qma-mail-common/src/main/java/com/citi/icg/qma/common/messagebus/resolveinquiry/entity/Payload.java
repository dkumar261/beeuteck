package com.citi.icg.qma.common.messagebus.resolveinquiry.entity;

public class Payload {
	
	private Long inquiryId;
	private String clientId;
	private String conversationId;
	private EntityDetails[] entityDetails;
	private String comments;
	
	public Payload() {
		super();
		// Auto-generated constructor stub
	}
	public Long getInquiryId() {
		return inquiryId;
	}
	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public EntityDetails[] getEntityDetails() {
		return entityDetails;
	}
	public void setEntityDetails(EntityDetails[] entityDetails) {
		this.entityDetails = entityDetails;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getConversationId() {
		return conversationId;
	}
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}
}
