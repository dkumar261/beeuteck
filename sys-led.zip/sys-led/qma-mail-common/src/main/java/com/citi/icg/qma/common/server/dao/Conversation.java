package com.citi.icg.qma.common.server.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Transient;

@Entity(value = "Conversation", noClassnameStored = true)
public class Conversation extends BaseEntity
{

	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private Long inquiryId;
	private String action;
	private String content;
	private boolean isEncryptedContent;
	private List<Attachment> attachments; // modified Sunil 17 August
	private Date sentDate;
	private Date receiptDate;
	private String subject;
	private String audFlag;
	private String modByName; // while saving data , set it for conversation..
	private String urgentFlag; // MOVED FROM INQUIRY SUNIL : 26 AUG
	private String approvalBypassed; // 6.Create a column in conversations table called 'Approval Bypassed' ... as per the discussion & mail on Wednesday, November 04, 2015 11:31 PM Maker Checker Demo
	private Boolean inActive;// Inactive conversations won't be displayed in UI, Used as channel to route internal group emails
	private String latestMsgRef;// Email Msg Ref to Track Internal Group Email Conv
	private List<ConversationRecipient> recipients;
	private String isS3Migrated = null;
	private String bubbleContent;
	private Long parentConversationId;

	private String memo;
	private List<String> readBy;
	private String suggestionStatus;
	private boolean isSuggestionAvailable;
	private boolean isNLPDataStampedAtConv;	
	private String custodySuggestionIndicator;
	private String settlementsSuggestionIndicator;
	private boolean autoAssignmentAvailable;
	private List<ConversationRecipient> nominatedRecipients;
	private List<ExchangeRecipient> exchangeRecipients;
	private String autoAssigned;
	private String conversationIV;
	private String conversationPreviewText;
	private boolean isContentArchivedToS3;
	private String contentS3UUID;
	private Map<String,String> latestExchangeItemIds;
	@Transient
	private String userExchangeFolderName;
	private String intentSuggestionName;
	private String intentTimeToVD;
	private boolean intentSuggestionAvailable;
	@Transient
	private String intentSuggestionIndicator;

	// C170665-3794 - to check if duplicate conversation is not created for Taskize
	private String taskizeContentId;

	private String userIntentSuggestionName;

	
	public Conversation()
	{
		super();
	}


	public Boolean getInActive()
	{
		return inActive;
	}

	public void setInActive(Boolean inActive)
	{
		this.inActive = inActive;
	}

	public String getLatestMsgRef()
	{
		return latestMsgRef;
	}

	public void setLatestMsgRef(String latestMsgRef)
	{
		this.latestMsgRef = latestMsgRef;
	}

	public Long getInquiryId() {
		return inquiryId;
	}

	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public List<Attachment> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<Attachment> attachments) {
		this.attachments = attachments;
	}

	public Date getReceiptDate() {
		return receiptDate;
	}

	public void setReceiptDate(Date receiptDate) {
		this.receiptDate = receiptDate;
	}

	public Date getSentDate() {
		return sentDate;
	}

	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public boolean isEncryptedContent() {
		return isEncryptedContent;
	}

	public void setEncryptedContent(boolean encryptedContent) {
		isEncryptedContent = encryptedContent;
	}

	public String getAudFlag() {
		return audFlag;
	}

	public void setAudFlag(String audFlag) {
		this.audFlag = audFlag;
	}

	public String getUrgentFlag() {
		return urgentFlag;
	}

	public void setUrgentFlag(String urgentFlag) {
		this.urgentFlag = urgentFlag;
	}

	public List<ConversationRecipient> getRecipients() {
		return recipients;
	}

	public void setRecipients(List<ConversationRecipient> recipients) {
		this.recipients = recipients;
	}

	public String getApprovalBypassed() {
		return approvalBypassed;
	}

	public void setApprovalBypassed(String approvalBypassed) {
		this.approvalBypassed = approvalBypassed;
	}


	public String getIsS3Migrated()
	{
		return isS3Migrated;
	}


	public void setIsS3Migrated(String isS3Migrated)
	{
		this.isS3Migrated = isS3Migrated;
	}
	
	public String getBubbleContent() {
		return bubbleContent;
	}


	public void setBubbleContent(String bubbleContent) {
		this.bubbleContent = bubbleContent;
	}


	public Long getParentConversationId() {
		return parentConversationId;
	}


	public void setParentConversationId(Long parentConversationId) {
		this.parentConversationId = parentConversationId;
	}


	public String getModByName() {
		return modByName;
	}


	public void setModByName(String modByName) {
		this.modByName = modByName;
	}


	public String getMemo() {
		return memo;
	}


	public void setMemo(String memo) {
		this.memo = memo;
	}


	public List<String> getReadBy() {
		return readBy;
	}


	public void setReadBy(List<String> readBy) {
		this.readBy = readBy;
	}


	public String getSuggestionStatus() {
		return suggestionStatus;
	}


	public void setSuggestionStatus(String suggestionStatus) {
		this.suggestionStatus = suggestionStatus;
	}


	public boolean isSuggestionAvailable() {
		return isSuggestionAvailable;
	}


	public void setSuggestionAvailable(boolean isSuggestionAvailable) {
		this.isSuggestionAvailable = isSuggestionAvailable;
	}


	public boolean isNLPDataStampedAtConv() {
		return isNLPDataStampedAtConv;
	}


	public void setNLPDataStampedAtConv(boolean isNLPDataStampedAtConv) {
		this.isNLPDataStampedAtConv = isNLPDataStampedAtConv;
	}


	public String getCustodySuggestionIndicator() {
		return custodySuggestionIndicator;
	}


	public void setCustodySuggestionIndicator(String custodySuggestionIndicator) {
		this.custodySuggestionIndicator = custodySuggestionIndicator;
	}


	public String getSettlementsSuggestionIndicator() {
		return settlementsSuggestionIndicator;
	}


	public void setSettlementsSuggestionIndicator(String settlementsSuggestionIndicator) {
		this.settlementsSuggestionIndicator = settlementsSuggestionIndicator;
	}


	public List<ConversationRecipient> getNominatedRecipients() {
		return nominatedRecipients;
	}

	public void setNominatedRecipients(List<ConversationRecipient> nominatedRecipients) {
		this.nominatedRecipients = nominatedRecipients;
	}


	public boolean isAutoAssignmentAvailable() {
		return autoAssignmentAvailable;
	}

	public void setAutoAssignmentAvailable(boolean autoAssignmentAvailable) {
		this.autoAssignmentAvailable = autoAssignmentAvailable;
	}


	public List<ExchangeRecipient> getExchangeRecipients() {
		return exchangeRecipients;
	}


	public void setExchangeRecipients(List<ExchangeRecipient> exchangeRecipients) {
		this.exchangeRecipients = exchangeRecipients;
	}


	public String getAutoAssigned() {
		return autoAssigned;
	}


	public void setAutoAssigned(String autoAssigned) {
		this.autoAssigned = autoAssigned;
	}


	public String getConversationIV() {
		return conversationIV;
	}


	public void setConversationIV(String conversationIV) {
		this.conversationIV = conversationIV;
	}

	public String getConversationPreviewText() {
		return conversationPreviewText;
	}

	public void setConversationPreviewText(String conversationPreviewText) {
		this.conversationPreviewText = conversationPreviewText;
	}


	public boolean isContentArchivedToS3() {
		return isContentArchivedToS3;
	}


	public void setContentArchivedToS3(boolean isContentArchivedToS3) {
		this.isContentArchivedToS3 = isContentArchivedToS3;
	}


	public String getContentS3UUID() {
		return contentS3UUID;
	}


	public void setContentS3UUID(String contentS3UUID) {
		this.contentS3UUID = contentS3UUID;
	}
	
	
	public Map<String, String> getLatestExchangeItemIds() {
		return latestExchangeItemIds;
	}

	public void setLatestExchangeItemIds(Map<String, String> latestExchangeItemIds) {
		this.latestExchangeItemIds = latestExchangeItemIds;
	}

	public String getUserExchangeFolderName() {
		return userExchangeFolderName;
	}

	public void setUserExchangeFolderName(String userExchangeFolderName) {
		this.userExchangeFolderName = userExchangeFolderName;
	}

	public String getIntentSuggestionName() {
		return intentSuggestionName;
	}


	public void setIntentSuggestionName(String intentSuggestionName) {
		this.intentSuggestionName = intentSuggestionName;
	}


	public String getIntentSuggestionIndicator() {
		return intentSuggestionIndicator;
	}


	public void setIntentSuggestionIndicator(String intentSuggestionIndicator) {
		this.intentSuggestionIndicator = intentSuggestionIndicator;
	}


	public String getIntentTimeToVD() {
		return intentTimeToVD;
	}


	public void setIntentTimeToVD(String intentTimeToVD) {
		this.intentTimeToVD = intentTimeToVD;
	}


	public boolean isIntentSuggestionAvailable() {
		return intentSuggestionAvailable;
	}


	public void setIntentSuggestionAvailable(boolean intentSuggestionAvailable) {
		this.intentSuggestionAvailable = intentSuggestionAvailable;
	}



	public String getTaskizeContentId() {
		return taskizeContentId;
	}


	public void setTaskizeContentId(String taskizeContentId) {
		this.taskizeContentId = taskizeContentId;
	}

	
	

	public String getUserIntentSuggestionName() {
		return userIntentSuggestionName;
	}


	public void setUserIntentSuggestionName(String userIntentSuggestionName) {
		this.userIntentSuggestionName = userIntentSuggestionName;
	}


}
