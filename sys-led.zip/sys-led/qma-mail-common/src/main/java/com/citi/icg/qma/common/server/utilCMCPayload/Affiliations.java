package com.citi.icg.qma.common.server.utilCMCPayload;

public class Affiliations
{
    private String loginId;

    private String loginName;

    private String name;

    public String getLoginId ()
    {
        return loginId;
    }

    public void setLoginId (String loginId)
    {
        this.loginId = loginId;
    }

    public String getLoginName ()
    {
        return loginName;
    }

    public void setLoginName (String loginName)
    {
        this.loginName = loginName;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    @Override
    public String toString()
    {
        return "InputForCMC [loginId = "+loginId+", loginName = "+loginName+", name = "+name+"]";
    }
}
