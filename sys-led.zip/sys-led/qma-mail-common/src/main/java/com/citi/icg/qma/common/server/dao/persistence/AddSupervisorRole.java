package com.citi.icg.qma.common.server.dao.persistence;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.HierarchyUserDetail;
import com.citi.icg.qma.common.server.dao.ManagementHeirarchy;
import com.citi.icg.qma.common.server.dao.User;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import dev.morphia.Datastore;
import dev.morphia.query.Query;

public class AddSupervisorRole extends MongoMorphiaDAO
{
	private Datastore dataStore; //sonar fix renamed for Child class fields should not shadow parent class fields 
	private static final String SUPERVISOR = "Supervisor";
	private static final String GROUP_ROLES = "groupRoles";

	public AddSupervisorRole()
	{
		dataStore = MongoDB.instance().getDataStore();
	}

	public static void main(String[] args)
	{
		AddSupervisorRole supervisorRole = new AddSupervisorRole();
		supervisorRole.addSupervisorRole();
	}

	private void addSupervisorRole()
	{

		Date currDate = new Date();
		List<Group> groupList;
		String[] projectionArr = { "_id", "heirarchyData" };
		Query<Group> query = dataStore.createQuery(Group.class).filter("active", true).retrievedFields(true, projectionArr);
		groupList = query.asList();
		for (Group group : groupList)
		{
			ManagementHeirarchy heirarchy = group.getHeirarchyData();
			if (heirarchy != null && heirarchy.getThirdLevelHeirarchy() != null && !heirarchy.getThirdLevelHeirarchy().isEmpty())
			{
				HierarchyUserDetail thirdLevelHierarchy = heirarchy.getThirdLevelHeirarchy().get(0);
				checkThirdLevelHeirarchyAndAddRole(currDate, group, thirdLevelHierarchy);
			}
		}
	}

	private void checkThirdLevelHeirarchyAndAddRole(Date currDate, Group group, HierarchyUserDetail thirdLevelHierarchy)
	{
		if (thirdLevelHierarchy != null && !StringUtils.isBlank(thirdLevelHierarchy.getUserId()))
		{
			String userId = thirdLevelHierarchy.getUserId();
			DBCollection userCollection = dataStore.getCollection(User.class);
			DBObject findQuery = new BasicDBObject();
			findQuery.put("_id", userId);
			findQuery.put("active", true);
			BasicDBObject userElemMatchQuery = new BasicDBObject("groupId", group.id);
			userElemMatchQuery.put("role", SUPERVISOR);
			findQuery.put(GROUP_ROLES, new BasicDBObject(AppserverConstants.ELEMENT_MATCH, userElemMatchQuery));
			DBCursor cur = userCollection.find(findQuery);
			if (!cur.hasNext())
			{
				DBObject newRoleSupervisor = createSupervisorRoleDBObject(userId, group.id, currDate);
				List<DBObject> groupRoleList = new ArrayList<>();
				groupRoleList.add(newRoleSupervisor);
				updateSupervisorRole(userCollection, groupRoleList, userId);
			}

		}
	}

	private DBObject createSupervisorRoleDBObject(String soeId, Long groupId, Date currDate)
	{
		DBObject newSupervisorRole = new BasicDBObject();
		newSupervisorRole.put("groupId", groupId);
		newSupervisorRole.put("crtDate", currDate);
		newSupervisorRole.put("crtBy", soeId);
		newSupervisorRole.put("role", SUPERVISOR);
		return newSupervisorRole;
	}

	private void updateSupervisorRole(DBCollection userCollection, List<DBObject> newGrpRoleList, String soeId)
	{
		DBObject updateGroupRoleObj = new BasicDBObject();
		updateGroupRoleObj.put("$addToSet", new BasicDBObject(GROUP_ROLES, new BasicDBObject("$each", newGrpRoleList)));
		DBObject updateQuery = new BasicDBObject();
		updateQuery.put("_id", soeId);
		userCollection.update(updateQuery, updateGroupRoleObj);
	}
}
