package com.citi.icg.qma.common.contact.tcl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.core.util.CLCSocketFactory;
import com.citi.icg.qma.common.contact.exception.UnauthorizedException;
import com.citi.icg.qma.common.contact.factory.ContactDetails;
import com.citi.icg.qma.common.contact.tcl.entity.TCLContactData;
import com.citi.icg.qma.common.contact.tcl.entity.TCLContacts;
import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.persistence.QMAContact;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;

public class TCLContactDetails implements ContactDetails {

	private static final Logger subLogger = LoggerFactory.getLogger(TCLContactDetails.class);
	private static final String CONFIG_TCL_CONFIGURATION_KEY = "TCLConfiguration";
	private Map<String, Object> tclConfig;
 
	private static final String TCL_CONTACT_URL = "tcl-contact-url-new";
	private static final String CERT_FILENAME_KEY = "certFileName";
	private static final String CERT_CONF_KEY = "certConf";
	private static final String CONFIG_CLC_CONFIGURATION_KEY = "clcConfiguration";
	private static final String SEARCH_ID_KEY = "id";
	private static final String ADVANCE_SEARCH_ID_KEY = "advanceSearchId";
	private static final String SEARCH_VALUE_KEY = "value";
	private static final String SEARCH_CONDITION_KEY = "condition";
	private static final String TCL_RFEPORT_KEY = "report_type_id";
	private static final String TCL_PAGE_SIZE = "page_size";
	private static final String TCL_PAGE_INDEX = "page_index";
	private static final String TCL_USER_TYPE = "userType";
	private static final String TCL_SERVICE_ID= "serviceId";
	private static final String TCL_TAXID_KEY = "taxId";
	private static final String TCL_EMAIL_KEY = "email";
	private static final String TCL_PRODUCT_FAMILY_KEY = "productFamily";
	private static final String TCL_EQUALS_KEY = "equals";
	private static final String TCL_FILETR_PARAMS = "filter_params";
	private static final String REQUEST_PARAMS_KEY = "requestParams";
	

	public List<QMAContact> getSearchContactDetails(String soeId, BasicDBObject inputJsonObj,BasicDBObject outputBuilderObj)
			throws CommunicatorException, UnauthorizedException {
		subLogger.info("In TCLContactDetails.getTCLSearchContactDetails for soeId: {} ", soeId);
		//get TCL Config from cache
		getTCLConfig();
		//Validate input parameter for search
		boolean isValidInput = validateInputRequest(inputJsonObj,outputBuilderObj);
		if(!isValidInput) {
			return new ArrayList<>();
		}
		//prepare request body
		StringEntity input = buildStringEntity(inputJsonObj,soeId);
		
		//fetch contact data from tcl
		JSONObject jsonResponseFromTcl = getContactSearchData(soeId,input);
		
		//Convert TCL contact to QMA contact
		if(null != jsonResponseFromTcl) {
			TCLContacts tclContact;
			try {
				tclContact = (TCLContacts) DataConversionUtil.convertJSONToJava(jsonResponseFromTcl.toString(),
						TCLContacts.class);
				return convertTCLContactToQMAConatct(tclContact);
			} catch (IOException e) {
				throw new CommunicatorException(e.getMessage(),e);
			}
		}
		return new ArrayList<>();
	}

	private boolean validateInputRequest(BasicDBObject inputJsonObj,BasicDBObject outputBuilderObj) {
		boolean isValidInput = false;
		String taxId = inputJsonObj.getString(TCL_TAXID_KEY);
		String email = inputJsonObj.getString(TCL_EMAIL_KEY);
		String productFamily = inputJsonObj.getString(TCL_PRODUCT_FAMILY_KEY);
		
		if (StringUtils.isBlank(taxId) && StringUtils.isBlank(email) && StringUtils.isBlank(productFamily)) {
			outputBuilderObj.put("BadRequest", "Please provide correct search criteria and try again.");
		}else {
			isValidInput = true;
		}
		return isValidInput;
	}

	private JSONObject getContactSearchData(String soeId,StringEntity input) throws CommunicatorException {
		subLogger.info("In TCLContactDetails.getContactSearchData by soeId: {}", soeId);
		Long startTime = Instant.now().toEpochMilli();
		subLogger.info("TCLContactDetails.getContactSearchData starts: {}  in Milli Seconds",startTime);
		CloseableHttpResponse response = null;
		JSONObject contactListJson = null;
		CloseableHttpClient httpClient = null;
		HttpPost requestPost = null;
		subLogger.info("tcl contact url: {}",tclConfig.get(TCL_CONTACT_URL));
		try {
			httpClient = getHttpClientForTCL();
			if (httpClient != null) {
				requestPost = new HttpPost(modifyURL((String)tclConfig.get(TCL_CONTACT_URL)));

				requestPost.setEntity(input);
				requestPost.setHeader("accept", "application/json");
				requestPost.setHeader("content-type", "application/json"); 
				
				response = httpClient.execute(requestPost);
				
				subLogger.info("TCLContactDetails.getContactSearchData ends: surrentTime: {}, Time taken: {}",Instant.now().toEpochMilli(), (Instant.now().toEpochMilli() - startTime));
				int statusCode = response.getStatusLine().getStatusCode();
				subLogger.info("In TCLContactDetails.getContactSearchData response from TCL: {}",
						statusCode);

				if (HttpStatus.SC_OK == statusCode) {
					contactListJson = extractTclResponse(response);
				} else if (HttpStatus.SC_UNAUTHORIZED == statusCode) {
					subLogger.error("TCL: Uaauthorised: {}",extractTclResponse(response));
					throw new UnauthorizedException(statusCode + "Unauthorised");
				} else{
					subLogger.error("TCL: Error: {}",extractTclResponse(response));
					throw new CommunicatorException(statusCode +" "+ extractTclResponse(response));
				}
			} else {
				subLogger.error("httpClient is null");
				throw new CommunicatorException("Service not available at the moment, Please contact Support.");
			}
		} catch (Exception e) {
			throw new CommunicatorException(e.getMessage());
		}finally {
			try {
				if (null != httpClient) {
					httpClient.close();
				}
				if (null != response) {
					response.close();
				}
			} catch (IOException e) {
				subLogger.error("Exception while closing resources: ", e);
			}
		}
		subLogger.info("TCLContactDetails.getContactSearchData ends: {}, diff: {}  in Milli Seconds",Instant.now().toEpochMilli(), (startTime - Instant.now().toEpochMilli()));
		return contactListJson;
	}
	
	private StringEntity buildStringEntity(BasicDBObject inputObj, String soeId) throws CommunicatorException {
		subLogger.info("In TCLContactDetails.buildStringEntity by soeId: {}", soeId);
		try {
			BasicDBObject request = new BasicDBObject();
			request.put(TCL_RFEPORT_KEY, getTCLRequestParams(TCL_RFEPORT_KEY));

			BasicDBList searchCriteria = buildFilterParams(inputObj);

			request.put(TCL_FILETR_PARAMS, searchCriteria);

			String pageSize = inputObj.getString("pageSize");
			if (!StringUtils.isBlank(pageSize)) {
				request.put(TCL_PAGE_SIZE, pageSize);
			} else {
				request.put(TCL_PAGE_SIZE, getTCLRequestParams(TCL_PAGE_SIZE));
			}

			String pageIndex = inputObj.getString("pageIndex");
			if (!StringUtils.isBlank(pageIndex)) {
				request.put(TCL_PAGE_INDEX, pageIndex);
			} else {
				request.put(TCL_PAGE_INDEX, getTCLRequestLongParams(TCL_PAGE_INDEX));
			}

			request.put(TCL_USER_TYPE, getTCLRequestParams(TCL_USER_TYPE));
			request.put(TCL_SERVICE_ID, getTCLRequestParams(TCL_SERVICE_ID));
			
			subLogger.info("Request paramters for TCL : {}", request);
			
			return new StringEntity(request.toJson());
		} catch (Exception e) {
			throw new CommunicatorException(e.getMessage(), e);
		}
	}

	private BasicDBList buildFilterParams(BasicDBObject inputObj) {
		BasicDBList searchCriteria = new BasicDBList();
		if (StringUtils.isNotBlank(inputObj.getString(TCL_TAXID_KEY))) {
			searchCriteria.add(getSearchObj(TCL_TAXID_KEY, inputObj.getString(TCL_TAXID_KEY), TCL_EQUALS_KEY));
		}
		if (StringUtils.isNotBlank(inputObj.getString(TCL_EMAIL_KEY))) {
			if (StringUtils.isNotBlank(inputObj.getString(SEARCH_CONDITION_KEY))) {
				if("endsWith".equalsIgnoreCase(inputObj.getString(SEARCH_CONDITION_KEY))) {
					String value = "'" + TCL_EMAIL_KEY + "'" + " LIKE " + "'*" + inputObj.getString(TCL_EMAIL_KEY) +  "'";
					BasicDBObject obj = new BasicDBObject();
					obj.put(SEARCH_ID_KEY, getTCLRequestParams(ADVANCE_SEARCH_ID_KEY));
					obj.put(SEARCH_VALUE_KEY, value);
					obj.put(SEARCH_CONDITION_KEY, "");
					searchCriteria.add(obj);
				}else {
					searchCriteria.add(getSearchObj(TCL_EMAIL_KEY, inputObj.getString(TCL_EMAIL_KEY),
							inputObj.getString(SEARCH_CONDITION_KEY)));
				}
			}else{
				searchCriteria.add(getSearchObj(TCL_EMAIL_KEY, inputObj.getString(TCL_EMAIL_KEY), TCL_EQUALS_KEY));
			}
				
		}
		if (StringUtils.isNotBlank(inputObj.getString(TCL_PRODUCT_FAMILY_KEY))) {
			searchCriteria.add(
					getSearchObj(TCL_PRODUCT_FAMILY_KEY, inputObj.getString(TCL_PRODUCT_FAMILY_KEY), TCL_EQUALS_KEY));
		}
		return searchCriteria;
	}
     
    
	BasicDBObject getSearchObj(String field, String value, String condition) {
		BasicDBObject obj = new BasicDBObject();
		obj.put(SEARCH_ID_KEY, field);
		obj.put(SEARCH_VALUE_KEY, value);
		if (StringUtils.isNotBlank(condition)) {
			obj.put(SEARCH_CONDITION_KEY, condition);
		} else {
			obj.put(SEARCH_CONDITION_KEY, TCL_EQUALS_KEY);
		}

		return obj;
	}

	private String getTCLRequestParams(String key) {
		String value = "";
		if (StringUtils.isNotBlank(key)) {

			Map<String, String> requestParams = (Map<String, String>) tclConfig.get((REQUEST_PARAMS_KEY));
			if (requestParams != null && !requestParams.isEmpty() && requestParams.containsKey(key)) {
				value = requestParams.get(key);
			}
		}
		return value;
	}
	
	private Long getTCLRequestLongParams(String key) {
		Long value = null;
		if (StringUtils.isNotBlank(key)) {

			Map<String, Long> requestParams = (Map<String, Long>) tclConfig.get((REQUEST_PARAMS_KEY));
			if (requestParams != null && !requestParams.isEmpty() && requestParams.containsKey(key)) {
				value = requestParams.get(key);
			}
		}
		return value;
	}
	
	private CloseableHttpClient getHttpClientForTCL()
			throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
		CloseableHttpClient httpClient = null;
		try {
			String certFileName = getCLCCertConfig(CERT_FILENAME_KEY);

			String xmcEnvironment = System.getProperty(AppserverConstants.ENV_PARAM_KEY);

			if (StringUtils.isNotEmpty(certFileName)) {
				SSLConnectionSocketFactory socketFactory = CLCSocketFactory.getInstance();
				if (null != socketFactory) {
					httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).disableCookieManagement()
							.build();
					subLogger.info(
							"TCL :: Environment is : {} using two-way SSL enabled HttpClient.",xmcEnvironment);
				}
			} else {
				subLogger.info("TCL :: Environment is : {} Not able to identify certificate paramteres from database.",xmcEnvironment);
				httpClient = HttpClientBuilder.create().build();
			}

		} catch (Exception e) {
			subLogger.error("TCL :: Error while creating http client in CLCOperationsDAO#getHttpClientSSLEnabled() : ",
					e);
		}
		return httpClient;
	}

	private String getCLCCertConfig(String key) {
		String value = "";
		Map<String, String> certConfig = (Map<String, String>) getCLCConfigForKey(CERT_CONF_KEY);
		if (certConfig != null && !certConfig.isEmpty() && certConfig.containsKey(key)) {
			value = certConfig.get(key);
		}
		return value;
	}
	private JSONObject extractTclResponse(HttpResponse response) throws IOException {
		JSONObject result = new JSONObject();
		HttpEntity entity = response.getEntity();
		subLogger.info("response.entity: {},entity.getContentLength(): {}, number of bytes that can be read : {} ", response.getEntity(),entity.getContentLength(),entity.getContent().available());
		if (entity.getContentLength() != 0) {
			subLogger.info("response.entity: {}", response.getEntity());
			result = new JSONObject(convertStreamToString(entity.getContent()));
			subLogger.info("Content: {}", result);
		}
		return result;
	}
	
	private Object getCLCConfigForKey(String key) {
		Object value = null;
		Map<String, Object> clcConfig = null;
		try {
			if(null != QMACacheFactory.getCache().getConfigById(CONFIG_CLC_CONFIGURATION_KEY)) {
				Config configData = QMACacheFactory.getCache().getConfigById(CONFIG_CLC_CONFIGURATION_KEY);
				if(null != configData) {
					clcConfig = configData.getClcConfiguration();
				}
				if( clcConfig != null && !StringUtils.isEmpty(key) ) {
					value = clcConfig.get(key);
				}
			}
		} catch (Exception e) {
			subLogger.error("Error while retrieving value from CLC config :" , e );
		}
		return value;
	}

	//Retrieves TCLConfiguration from DB
	private void getTCLConfig() throws CommunicatorException {
		try {
			if (null != QMACacheFactory.getCache().getConfigById(CONFIG_TCL_CONFIGURATION_KEY)) {
				Config configData = QMACacheFactory.getCache().getConfigById(CONFIG_TCL_CONFIGURATION_KEY);
				if (null != configData) {
					tclConfig = configData.getTCLConfiguration();
				}
				if(null == tclConfig) {
					subLogger.error("tclConfig is null:");
					throw new CommunicatorException("Error while retrieving TCL config");
				}
			}
		} catch (Exception e) {
			subLogger.error("Error while retrieving value for TCL config :", e);
			throw new CommunicatorException("Error while retrieving TCL config");
		}
	}

	// encoding URL
	private String modifyURL(String url) throws CommunicatorException {
		URL newUrl;
		URI uri;
		try {
			newUrl = URI.create(url).toURL();
			uri = new URI(newUrl.getProtocol(), newUrl.getUserInfo(), newUrl.getHost(), newUrl.getPort(),
					newUrl.getPath(), newUrl.getQuery(), newUrl.getRef());
		} catch (MalformedURLException | URISyntaxException e) {
			throw new CommunicatorException("Exception in modifyURL " + e);
		}
		return uri.toASCIIString();
	}
	
	private List<QMAContact> convertTCLContactToQMAConatct(TCLContacts tclContact) {
		subLogger.info("In TCLContactDetails.ConvertTCLContactToQMAConatct");
		List<QMAContact> tmpQmaContactList = new ArrayList<>();
		subLogger.info("tclContact.getData().length :{}",tclContact.getData().length);
		TCLContactData[] data= tclContact.getData(); 
		
		for(TCLContactData tclContactData: data) {
			QMAContact qmaContact = setInitialEmptyQMAContact();
			qmaContact.setFamilyName(tclContactData.getProductFamily());
			qmaContact.setFirstName(tclContactData.getEmail());
			qmaContact.setEmail(tclContactData.getEmail());
			qmaContact.setTaxId(tclContactData.getTaxId());
			qmaContact.setClientName(tclContactData.getCustName());
			qmaContact.setClientID(tclContactData.getCustId());
			tmpQmaContactList.add(qmaContact);
		}
		return tmpQmaContactList;
	}

	// initialize the contact received from TCL to empty contact at the beginning
	private QMAContact setInitialEmptyQMAContact() {
		QMAContact qmaContact = new QMAContact();
		qmaContact.setClientID("");
		qmaContact.setClientName("");
		qmaContact.setEmail("");
		qmaContact.setFirstName("");
		qmaContact.setJobTitle("");
		qmaContact.setLastName("");
		qmaContact.setManagementId("");
		qmaContact.setPhone("");
		qmaContact.setSrcSysId("");
		qmaContact.setType("");
		qmaContact.setMnemonic("");
		qmaContact.setTaxId("");
		qmaContact.setFamilyName("");
		return qmaContact;
	}

	
	// HTTP Response to string conversion
	private static String convertStreamToString(InputStream is) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			subLogger.debug(e.toString());
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				subLogger.debug(e.toString());
			}
		}
		return sb.toString();
	}
	
}
