package com.citi.icg.qma.exception;

public class QMAKafkaException extends Exception {

	private static final long serialVersionUID = 1L;

	public QMAKafkaException(String message, Throwable e) {
		super(message, e);
	}

	public QMAKafkaException(Throwable e) {
		super(e);
	}

	public QMAKafkaException(String message) {
		super(message);
	}
}
