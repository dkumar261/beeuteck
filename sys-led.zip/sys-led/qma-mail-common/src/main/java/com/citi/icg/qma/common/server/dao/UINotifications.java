package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.*;

@Entity(value = "UINotifications", noClassnameStored = true, cap = @CappedAt(count = 5000, value = 500000))
public class UINotifications extends BaseEntity
{
	private Long inquiryId;
	private String action;

	private String processFlag;

	public UINotifications()
	{
		super();
	}

	public Long getInquiryId() {
		return inquiryId;
	}

	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getProcessFlag() {
		return processFlag;
	}

	public void setProcessFlag(String processFlag) {
		this.processFlag = processFlag;
	}
	
	
}
