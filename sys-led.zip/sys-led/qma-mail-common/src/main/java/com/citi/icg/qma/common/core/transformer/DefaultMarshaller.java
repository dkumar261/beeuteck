package com.citi.icg.qma.common.core.transformer;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.exolab.castor.xml.XMLContext;

import com.citi.icg.qma.common.core.util.ExceptionUtil;

public class DefaultMarshaller {

	private final Class<?> classType;

	public DefaultMarshaller(Class<?> classType) {
		this.classType = classType;
	}

	/**
	 * Marshals a bean with optional validation.
	 *
	 * @param bean     bean to be marshalled
	 * @param validate indicates if the validation should be done before marshalling
	 * @return marshalled XML
	 * @throws TransformationExcept if marshalling fails
	 */
	public String marshal(Object bean, boolean validate) throws TransformationExcept {
		try (Writer writer = new StringWriter()) {
			var marshaller = new org.exolab.castor.xml.Marshaller(writer);
			marshaller.setValidation(validate);
			marshaller.marshal(bean);
			return writer.toString();
		} catch (MarshalException | ValidationException e) {
			throw new TransformationExcept(ExceptionUtil.getInstance().getRootCause(e));
		} catch (IOException e) {
			throw new TransformationExcept("AbstractMarshaller: couldn't marshal", e);
		}
	}

	/**
	 * Unmarshals XML into an object with optional validation.
	 *
	 * @param xml      XML to be unmarshalled
	 * @param validate indicates if the validation should be done before unmarshalling
	 * @return unmarshalled object
	 * @throws TransformationExcept if unmarshalling fails
	 */
	public Object unmarshal(String xml, boolean validate) throws TransformationExcept {
		try (var reader = new StringReader(xml)) {
			var unmarshaller = new Unmarshaller(classType);
			unmarshaller.setValidation(validate);
			return unmarshaller.unmarshal(reader);
		} catch (MarshalException | ValidationException e) {
			throw new TransformationExcept(ExceptionUtil.getInstance().getRootCause(e));
		}
	}

	/**
	 * Unmarshals XML into an object using a generic XMLContext with optional validation.
	 *
	 * @param xml      XML to be unmarshalled
	 * @param validate indicates if the validation should be done before unmarshalling
	 * @return unmarshalled object
	 * @throws TransformationExcept if unmarshalling fails
	 */
	public Object genericUnmarshal(String xml, boolean validate) throws TransformationExcept {
		try (var reader = new StringReader(xml)) {
			var xmlContext = new XMLContext();
			var unmarshaller = xmlContext.createUnmarshaller();
			unmarshaller.setClass(classType);
			unmarshaller.setValidation(validate);
			return unmarshaller.unmarshal(reader);
		} catch (Exception e) {
			throw new TransformationExcept(ExceptionUtil.getInstance().getRootCause(e));
		}
	}
}
