package com.citi.icg.qma.common.server.dao;

import java.util.Date;

import org.bson.types.ObjectId;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "UserActivities", noClassnameStored = true)
public class UserActivities
{
	@Id
	private ObjectId id;
	private String userId;
	private String actionType;
	private String description;
	private Date actionTime;
	private Long responseTimeInMills;
	private String browser;
	private String os;
	private String requestReceivedHost;
	private String requesterHost;
	private String origin;
	
	private String requestUrl; // QMA-1742
	private String sourceOrigin; // QMA-1742
	
	// C153176-5849 | Email as chat feature adoption audit information.
	private String viewName;
	private String viewType;

	public UserActivities()
	{
	}

	public UserActivities(String userId, String actionType, String description, Date actionTime)
	{
		super();
		this.userId = userId;
		this.actionType = actionType;
		this.description = description;
		this.actionTime = actionTime;
	}

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getActionTime() {
		return actionTime;
	}

	public void setActionTime(Date actionTime) {
		this.actionTime = actionTime;
	}

	public Long getResponseTimeInMills()
	{
		return responseTimeInMills;
	}

	public void setResponseTimeInMills(Long responseTimeInMills)
	{
		this.responseTimeInMills = responseTimeInMills;
	}

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	
	public String getRequestReceivedHost() {
		return requestReceivedHost;
	}

	public void setRequestReceivedHost(String requestReceivedHost) {
		this.requestReceivedHost = requestReceivedHost;
	}

	public String getRequesterHost() {
		return requesterHost;
	}

	public void setRequesterHost(String requesterHost) {
		this.requesterHost = requesterHost;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}
	
	public String getRequestUrl() {
		return requestUrl;
	}

	public void setRequestUrl(String requestUrl) {
		this.requestUrl = requestUrl;
	}

	public String getSourceOrigin() {
		return sourceOrigin;
	}

	public void setSourceOrigin(String sourceOrigin) {
		this.sourceOrigin = sourceOrigin;
	}
}
