package com.citi.icg.qma.common.server.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.NLPConstants;
import com.citi.icg.qma.common.server.dao.AutoRouting;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.Intents;
import com.citi.icg.qma.common.server.dao.NLPSuggestionRecord;
import com.citi.icg.qma.common.server.dao.NLPTags;
import com.citi.icg.qma.common.server.dao.Workflow;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.DBObject;

public class AutoRoutingUtil {
	private static final Logger logger = LoggerFactory.getLogger(AutoRoutingUtil.class);
	
	/**
	 * This method is used to parse NLP response and set autoRouting details 
	 * @param inputJsonObj
	 * @param sugRecord
	 */
	public static void setAutoRoutingFromNLPResponse(BasicDBObject inputJsonObj, NLPSuggestionRecord sugRecord) {
		AutoRouting autoRouting = AutoRoutingUtil.getNlpTagsList(inputJsonObj);
		boolean isTagsNonEmpty = null != autoRouting && null != autoRouting.getNlpTags() && !autoRouting.getNlpTags().isEmpty();
		if(isTagsNonEmpty)
		sugRecord.setAutoRouting(autoRouting);
	}
	/**
	 * Check configuration and get forwardTo tags list from response 
	 * @param inputJsonObj
	 * @param string 
	 * @param sugRecord
	 * @return 
	 */
	public static AutoRouting getNlpTagsList(BasicDBObject inputJsonObj) {
		AutoRouting autoRouting = new AutoRouting();
		try {
 				autoRouting.setNlpTags(prepareTagsListFromResponse(inputJsonObj));
			}catch(Exception ex) {
			logger.error("Error while updating tags:",ex);	
		}
		return autoRouting;
	}
	/**
	 * This method used to iterate through response and prepare forwardTo type tags list
	 * @param inputJsonObj
	 * @param sugRecord
	 * @return 
	 */
	public static List<NLPTags> prepareTagsListFromResponse(BasicDBObject inputJsonObj) {
		List<NLPTags> nlpTagsList = null;
		if(null != inputJsonObj.get(NLPConstants.TAGS)) {
			logger.info("Upadting tags:"+inputJsonObj.get(NLPConstants.TAGS).toString());
			nlpTagsList = new ArrayList<NLPTags>();
			BasicDBList tags = (BasicDBList) inputJsonObj.get(NLPConstants.TAGS);
			Map<String, Long> groupMap = QMACacheFactory.getCache().getGroupCodeToIdMap();
			for(int i=0;i<tags.size();i++) {
				NLPTags nlpTags = new NLPTags();
				BasicDBObject tagObject = (BasicDBObject) tags.get(i);
				if(tagObject.containsField(NLPConstants.CATEGORY) && tagObject.containsField(NLPConstants.TYPE)
						&& tagObject.containsField(NLPConstants.SCORE) && tagObject.containsField(NLPConstants.CONFIDENCE)
						&& NLPConstants.NLP_TAGS_TYPE_FORWARD_TO.equalsIgnoreCase(tagObject.getString(NLPConstants.TYPE))) {
					addToTagList(nlpTagsList, groupMap, nlpTags, tagObject);
				}
			}
		}
		return nlpTagsList;
	}

	/**
	 * This method used to add valid tags to tagList
	 * @param nlpTagsList
	 * @param groupMap
	 * @param nlpTags
	 * @param tagObject
	 * @return
	 */
	private static void addToTagList(List<NLPTags> nlpTagsList, Map<String, Long> groupMap, NLPTags nlpTags,
			BasicDBObject tagObject) {
		if (StringUtils.isNotEmpty(tagObject.getString(NLPConstants.CATEGORY))
				&& StringUtils.isNotEmpty(tagObject.getString(NLPConstants.TYPE))
				&& StringUtils.isNotEmpty(tagObject.getString(NLPConstants.CONFIDENCE))
				&& tagObject.get(NLPConstants.SCORE) != "") {
			nlpTags.setCategory(tagObject.getString(NLPConstants.CATEGORY));
			getGroupIdByName(groupMap, nlpTags);
			nlpTags.setType(tagObject.getString(NLPConstants.TYPE));
			nlpTags.setScore(tagObject.getDouble(NLPConstants.SCORE));
			nlpTags.setConfidence(tagObject.getString(NLPConstants.CONFIDENCE));
			nlpTagsList.add(nlpTags);
		}
	}
	/**
	 * This method used to get groupId from groupMap
	 * @param groupMap
	 * @param nlpTags
	 */
	private static void getGroupIdByName(Map<String, Long> groupMap, NLPTags nlpTags) {
		if (null != groupMap.get(nlpTags.getCategory().toUpperCase())) {
			Long groupId = groupMap.get(nlpTags.getCategory().toUpperCase());
			nlpTags.setGroupId(groupId);
		}
	}
	
	/**
	 * 
	 * @param sugRecord
	 * @param inquiry
	 * @return
	 * @throws NlpAutoAssignmentValidationException 
	 */
	public static void validateAutoRouting(NLPSuggestionRecord sugRecord, Inquiry inquiry) throws NlpAutoAssignmentValidationException {
		String validationMessage = NLPConstants.NLP_AUTO_ASSIGNMENT_VALIDATION_SUCCESS;
		if (null != sugRecord.getAutoRouting() && null != sugRecord.getAutoRouting().getNlpTags() 
				&& !sugRecord.getAutoRouting().getNlpTags().isEmpty() ){
			validationMessage = checkResponseWithForwardTo(sugRecord.getAutoRouting().getNlpTags());
			if(!NLPConstants.NEW_INQUIRY.equalsIgnoreCase(inquiry.getAction())) {
				validationMessage = "INVALID_ACTION_"+inquiry.getAction();
			}
			if(null != sugRecord.getValidToCcGroupIds() && sugRecord.getValidToCcGroupIds().size() <= 2 ) {
				validationMessage = "VALID_GROUPS_NOT_MORE_THAN_2";
			}
			if (NLPConstants.NLP_AUTO_ASSIGNMENT_VALIDATION_SUCCESS.equalsIgnoreCase(validationMessage)) {
				validationMessage = checkDLExclution(sugRecord.getValidToCcGroupIds());
			}
			
		}else {
			logger.info("NLP tags are empty.");
		}
		
		if (!NLPConstants.NLP_AUTO_ASSIGNMENT_VALIDATION_SUCCESS.equalsIgnoreCase(validationMessage)) {
			throw new NlpAutoAssignmentValidationException(validationMessage);
		}		
	}

	
	/**
	 * @param validToCcGroupIds
	 * @return
	 */
	private static String checkDLExclution(List<Long> validToCcGroupIds) {
		String dlExclutionValidationMsg = NLPConstants.NLP_AUTO_ASSIGNMENT_VALIDATION_SUCCESS;
		Map<String, Object> nlpConfig = QMACacheFactory.getCache().getNlpConfiguration();
		if (null != nlpConfig && null != nlpConfig.get("disableAutoRoutingGroups")) {
			List<String> exclusionDLList = (List<String>) nlpConfig.get("disableAutoRoutingGroups");
			if(!exclusionDLList.isEmpty()) {
				logger.info("DL exclusion list:"+exclusionDLList);
				dlExclutionValidationMsg = checkToCcDLInExclusionList(validToCcGroupIds, exclusionDLList);
			}
		}
		return dlExclutionValidationMsg;
	}
	/**
	 * @param validToCcGroupIds
	 * @param exclusionDLList
	 * @return
	 */
	private static String checkToCcDLInExclusionList(List<Long> validToCcGroupIds, List<String> exclusionDLList) {
		String dlExclutionValidationMsg = NLPConstants.NLP_AUTO_ASSIGNMENT_VALIDATION_SUCCESS;
		for (String groupName : exclusionDLList) {
			Long groupIdFromExclusion = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
			if (null != groupIdFromExclusion) {
				if (validToCcGroupIds.contains(groupIdFromExclusion)) {
					logger.info("DL exclusion criteria met for DL:"+groupName);
					dlExclutionValidationMsg = "DL_EXCLUSION_CRITERIA_MET";
					break;
				}
			}
		}
		return dlExclutionValidationMsg;
	}
	private static String checkResponseWithForwardTo(List<NLPTags> nlpTags) {
		String nlpTagsTypValidationMsg = NLPConstants.NLP_AUTO_ASSIGNMENT_VALIDATION_SUCCESS;
		for(NLPTags tag:nlpTags) {
			if(!NLPConstants.NLP_TAGS_TYPE_FORWARD_TO.equalsIgnoreCase(tag.getType())) {
				nlpTagsTypValidationMsg = "INVALID_NLP_TAG_TYPE_"+tag.getType();
				break;
			}
		}
		return nlpTagsTypValidationMsg;
	}
	/**
	 * This method is used to get highest 2 tags from tag list and update workflow
	 * @param sugRecord
	 * @return 
	 * @throws NlpAutoAssignmentValidationException 
	 */
	public static List<Long> getAutoRoutingGroups(NLPSuggestionRecord sugRecord) throws NlpAutoAssignmentValidationException {
		try {
			List<NLPTags> confLevelTagList = new ArrayList<>();
			List<Long> autoRoutingGroupIds = new ArrayList<>();
			Map<String, Object> nlpConfig = QMACacheFactory.getCache().getNlpConfiguration();
			BasicDBObject autoForwardConfig = (BasicDBObject) nlpConfig.get(NLPConstants.AUTO_ROUTING_CONFIG);
			List<String> confidenceLevels = getConfidenceLevels(autoForwardConfig);
			String excludeConfigLevelForNewDL="LOW";	
			List<Long> newAAGroupIdsexcludedWithMinusConfidence = new ArrayList<>();
				for (NLPTags nlpTag : sugRecord.getAutoRouting().getNlpTags()) {
					//Gather all Low -1 score tag for AA exclusion as they are new DL
					if(excludeConfigLevelForNewDL.equalsIgnoreCase(nlpTag.getConfidence())&& 0>nlpTag.getScore()) {
						newAAGroupIdsexcludedWithMinusConfidence.add(nlpTag.getGroupId());
					}else if (null != confidenceLevels && confidenceLevels.contains(nlpTag.getConfidence())) {
					confLevelTagList.add(nlpTag);
					}
					
			}
			//List<NLPTags> finalTagList = sortAndReturnHighestTwo(highScoreList);
			List<NLPTags> finalTagList = sortAndReturnSelectionLevel(confLevelTagList, autoForwardConfig);
			autoRoutingGroupIds = getAutoRoutingGroupsIds(finalTagList, autoForwardConfig);
			//Add new DL's with less than zero score to retain ownership if we have any autorouting dl's.
			if(null !=autoRoutingGroupIds && ! autoRoutingGroupIds.isEmpty()) {
				autoRoutingGroupIds.addAll(newAAGroupIdsexcludedWithMinusConfidence);
			}
			return autoRoutingGroupIds;
		} catch (NlpAutoAssignmentValidationException e) {
			throw new NlpAutoAssignmentValidationException(e.getMessage());
		}
		catch (Exception e) {
			logger.error("Error while sorting tags" + e);
		}
		return null;
	}
	/**
	 * This method used to get confidence levels from config
	 * @param autoForwardConfig 
	 * @return
	 */
	private static List<String> getConfidenceLevels(BasicDBObject autoForwardConfig) {
		List<String> confidenceLevels = new ArrayList<>();
		if(null != autoForwardConfig.get(NLPConstants.RECOM_CONFIDENCE_LEVEL)) {
			String confidenceLevel = autoForwardConfig.getString(NLPConstants.RECOM_CONFIDENCE_LEVEL);
			if(NLPConstants.HIGH_CONFIDENCE.equalsIgnoreCase(confidenceLevel)) {
				confidenceLevels.add(NLPConstants.HIGH_CONFIDENCE);
			}else if (NLPConstants.MEDIUM_CONFIDENCE.equalsIgnoreCase(confidenceLevel)){
				confidenceLevels.add(NLPConstants.HIGH_CONFIDENCE);
				confidenceLevels.add(NLPConstants.MEDIUM_CONFIDENCE);
			}else if(NLPConstants.LOW_CONFIDENCE.equalsIgnoreCase(confidenceLevel)) {
				confidenceLevels.add(NLPConstants.HIGH_CONFIDENCE);
				confidenceLevels.add(NLPConstants.MEDIUM_CONFIDENCE);
				confidenceLevels.add(NLPConstants.LOW_CONFIDENCE);
			}else {
				confidenceLevels.add(NLPConstants.HIGH_CONFIDENCE);
			}
		}
		return confidenceLevels;
	}
	private static List<Long> getAutoRoutingGroupsIds(List<NLPTags> finalTagListList, BasicDBObject autoForwardConfig) throws NlpAutoAssignmentValidationException {
		List<Long> autoFwdedGroupsIds = new ArrayList<Long>();
		boolean matchMinConfidenceAA=false;
		String minConfLevel = autoForwardConfig.getString(NLPConstants.ATLEAST_1_CONFIDENCE_LEVEL);
		for (NLPTags tags : finalTagListList) {
			if (null != tags.getGroupId()) {
				autoFwdedGroupsIds.add(tags.getGroupId());
			}
			if (!matchMinConfidenceAA && tags.getConfidence().equalsIgnoreCase(minConfLevel)) {
				matchMinConfidenceAA = true;
			}
		}
		// New code to block AA if atleast 1 high criteria not met before applying
		if (null != minConfLevel && !matchMinConfidenceAA) {
			String validationMessage = "ATLEAST_ONE_CONFIDENCE_LEVEL_LESS_THAN_THRESHHOLD" + "_" + minConfLevel;
			throw new NlpAutoAssignmentValidationException(validationMessage);
		}
		return autoFwdedGroupsIds;
	}

	/**
	 * This method used to sort highest 2 score tags
	 * @param nlpTagsList
	 * @return
	 */
	private static List<NLPTags> sortAndReturnHighestTwo(List<NLPTags> nlpTagsList) {
		if (nlpTagsList.size() >= 2) {
			Collections.sort(nlpTagsList, new Comparator<NLPTags>() {
				@Override
				public int compare(NLPTags tag1, NLPTags tag2) {
					return Double.compare(tag2.getScore(), tag1.getScore());
				}
			});
			return new ArrayList<>(nlpTagsList.subList(0, 2));
		} else {
			return nlpTagsList;
		}
	}
	/**
	 * This method used to sort highest 2 score tags
	 * @param nlpTagsList
	 * @param autoForwardConfig 
	 * @return
	 * @throws NlpAutoAssignmentValidationException 
	 */
	private static List<NLPTags> sortAndReturnSelectionLevel(List<NLPTags> nlpTagsList, BasicDBObject autoForwardConfig) throws NlpAutoAssignmentValidationException {
		int selectionLevel = 0;
		if(null != autoForwardConfig.get(NLPConstants.SELECTION_LEVEL)) {
			selectionLevel = autoForwardConfig.getInt(NLPConstants.SELECTION_LEVEL);
		}
		if ( null != nlpTagsList && !nlpTagsList.isEmpty()
				&& selectionLevel > 0  && nlpTagsList.size() > selectionLevel) {
			Collections.sort(nlpTagsList, new Comparator<NLPTags>() {
				@Override
				public int compare(NLPTags tag1, NLPTags tag2) {
					return Double.compare(tag2.getScore(), tag1.getScore());
				}
			});
			return new ArrayList<>(nlpTagsList.subList(0, selectionLevel));
		} else if (null != nlpTagsList && !nlpTagsList.isEmpty()
				&& selectionLevel > 0  && nlpTagsList.size() < selectionLevel){
				
			// Atleast top 2(selectionLevel) should be in the tag list otherwise return blank which means no AA
			String validationMessage = "VALID_CONFIDENCE_LEVEL_LESS_THAN_THRESHHOLD"+"_"+selectionLevel;
			throw new NlpAutoAssignmentValidationException(validationMessage);
			//return new ArrayList<NLPTags>();
		}else {
			return nlpTagsList;
		}
	}
	/**
	 * This method is used to add all non matched workflows into bulk operations.
	 * @param autoFwdedGroupsIds
	 * @param bulkInquiryUpdOp
	 * @param currentTime
	 * @param inquiry
	 * @param workflow
	 */
	public static void prepareBulkUpdateOperations(BulkWriteOperation bulkInquiryUpdOp,	Date currentTime, Inquiry inquiry, Workflow workflow) {
		DBObject inquiryUpdateDBObj = new BasicDBObject();
		if (null == workflow.getRulesFlag()) {
			logger.info("Applying mark as non inquiry for workflow assigned group" + workflow.getAssignedGroupId());
			inquiryUpdateDBObj.put(NLPConstants.WORKFLOWS_MODIFIED_BY, NLPConstants.SYSTEM_USER);
			inquiryUpdateDBObj.put(NLPConstants.WORKFLOWS_MODIFIED_DATE, currentTime);
			bulkWorkflowUpdateForAutoAssignment(inquiry, inquiryUpdateDBObj, currentTime, workflow.getAssignedGroupId(),bulkInquiryUpdOp);
			updateAuditForAutoAssignment(inquiry, currentTime, bulkInquiryUpdOp, workflow.getAssignedGroupId());
		} else {
			logger.info("Workflow already moved to non inquiry due to regular rules:" + workflow.getAssignedGroupId());
		}
	}

	/**
	 * This method is used to update WorkflowAudit and add into bulk operaations
	 * @param inquiry
	 * @param currentTime
	 * @param bulkInquiryUpdOp
	 * @param assignedGroupId
	 */
	private static void updateAuditForAutoAssignment(Inquiry inquiry, Date currentTime, BulkWriteOperation bulkInquiryUpdOp, Long assignedGroupId) {
		DBObject workflowAudit = createWorkFlowsAudit(assignedGroupId, "NLP - Auto Assignment", currentTime);
		DBObject updateWorkAuditFields = new BasicDBObject();
		updateWorkAuditFields.put("$push", new BasicDBObject(NLPConstants.WORKFLOW_AUDIT, workflowAudit));
		BasicDBObject findWorkAuditflowQuery = new 	BasicDBObject();
		findWorkAuditflowQuery.put(NLPConstants.ID_KEY, inquiry.id);
		bulkInquiryUpdOp.find(findWorkAuditflowQuery).update(updateWorkAuditFields);	
	}
	/**
	 * This method creates workflow audit object
	 * @param groupId
	 * @param action
	 * @param actionDesc
	 * @param currentTime
	 * @return
	 */
	private static DBObject createWorkFlowsAudit(Long groupId, String action, Date currentTime)
	{
		DBObject workflowAudit = new BasicDBObject();
		workflowAudit.put(NLPConstants.ACTION_KEY, action);
		workflowAudit.put(NLPConstants.GROUP_ID_KEY, groupId);
		String actionDesc = "Non Inquiry Assigned for Group";
		if (null != QMACacheFactory.getCache().getGroupIdToNameMap()) {
			String groupCode = QMACacheFactory.getCache().getGroupIdToNameMap().get(groupId);
			workflowAudit.put(NLPConstants.GROUP_NAME, groupCode);
			actionDesc = actionDesc.concat(" ["+groupCode+"]");			
		}
		workflowAudit.put(NLPConstants.ACTION_DETAILS, actionDesc);
		//workflowAudit.put(NLPConstants.USER_ID, NLPConstants.SYSTEM_USER);
		workflowAudit.put(NLPConstants.MOD_BY, NLPConstants.SYSTEM_USER);
		workflowAudit.put(NLPConstants.MOD_DATE, currentTime);
		return workflowAudit;
	}
	/**
	 * This method is used to update workflow and add into bulk operations
	 * @param inquiry
	 * @param inquiryUpdateDBObj
	 * @param currentTime
	 * @param assignedGroupId
	 * @param bulkInquiryUpdOp
	 */
	private static void bulkWorkflowUpdateForAutoAssignment(Inquiry inquiry, DBObject inquiryUpdateDBObj, Date currentTime, Long assignedGroupId,
			BulkWriteOperation bulkInquiryUpdOp) {
		DBObject findWorkflowQuery = prepareFindQuery(inquiry.id, assignedGroupId);
		inquiryUpdateDBObj.put(NLPConstants.WORKFLOWS_LAST_ACTION_BY, NLPConstants.SYSTEM_USER);
		inquiryUpdateDBObj.put(NLPConstants.WORKFLOWS_LAST_ACTION_TIME, currentTime);
		inquiryUpdateDBObj.put(NLPConstants.WORKFLOWS_$_RULES_FLAG, createRulesObject());
		DBObject updateDBFields = new BasicDBObject();
		updateDBFields.put("$set", inquiryUpdateDBObj);
		bulkInquiryUpdOp.find(findWorkflowQuery).update(updateDBFields);
	}

	/**
	 * Create inquiry rule object set inquiry as non inquiry
	 * @return
	 */
	private static BasicDBObject createRulesObject() {
		BasicDBObject rulesObject = new BasicDBObject();
		rulesObject.put(NLPConstants.MARK_AS_NON_INQUIRY, true);
		rulesObject.put(NLPConstants.RULE_TYPE, NLPConstants.AUTO_ASSIGNMENT_RULE);
		return rulesObject;
	}
	/**
	 * This method is used to prepare find query for inquiry and and workflow with assigned group id
	 * @param id
	 * @param fromGroupId
	 * @return
	 */
	private static DBObject prepareFindQuery(Long id, Long fromGroupId)
	{
		BasicDBObject workflowCriteria = new BasicDBObject();
		DBObject updateQuery = new BasicDBObject();
		updateQuery.put(NLPConstants.ID_KEY, id);
		workflowCriteria.put(NLPConstants.ASSIGNED_GROUPID, fromGroupId);
		updateQuery.put(NLPConstants.WORKFLOWS, new BasicDBObject("$elemMatch", workflowCriteria));
		return updateQuery;

	}
	public static List<Long> addAutoAssignedGroupsForAutoRouting() {
		List<Long> autoRoutingGroupIds =new ArrayList<Long>();
		if(null != QMACacheFactory.getCache().getAutoAssignmentEnabledGroupMap()) {
			Map<Long, String> autoAssignmentGropusMap = QMACacheFactory.getCache().getAutoAssignmentEnabledGroupMap();
			autoRoutingGroupIds = new ArrayList<>(autoAssignmentGropusMap.keySet());
		}
		logger.info("Auto routing enabled for groups:"+autoRoutingGroupIds.toString());
		return autoRoutingGroupIds;
	}
	
	public static void setIntentsFromNlpResponse(BasicDBObject inputJsonObj,NLPSuggestionRecord sugRecord) {
		sugRecord.setIntentList(prepareIntentsListFromResponse(inputJsonObj));
		sugRecord.setIntentSuggested(inputJsonObj.getBoolean(NLPConstants.SUGGESTED_INTENT_KEY));
		sugRecord.setIntentValueDates((getSortedTimeVD((List<String>)inputJsonObj.get(NLPConstants.VALUE_DATES_KEY)))); 
		sugRecord.setIntentMessage(inputJsonObj.getString(NLPConstants.INTENT_MESSAGE_KEY));
		sugRecord.setIntentReturnCode(inputJsonObj.getString(NLPConstants.INTENT_RETURN_CODE_KEY));
		if (null != inputJsonObj.get(NLPConstants.STATISTICS)
				&& !inputJsonObj.getString(NLPConstants.STATISTICS).isEmpty()) {
			Map<String, Object> intentStatistics = (Map<String, Object>) inputJsonObj.get(NLPConstants.STATISTICS);
			if(null != intentStatistics) {
				sugRecord.setIntentStatistics(intentStatistics);
			}
		}
	}

	public static List<String> getSortedTimeVD(List<String> datestring) {
		List<Date> sortedDates = new ArrayList<>();
		List<String> sortedStringDates = new ArrayList<>();
		try {
		if(null == datestring) {
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
		for(String date: datestring) {
			sortedDates.add(sdf.parse(date));
		}
	    Collections.sort(sortedDates, (s1, s2) -> s2.compareTo(s1));
	    sortedStringDates = sortedDates.stream().map((date) -> sdf.format(date)).collect(Collectors.toList());
	    logger.info("sortedDates: {}", sortedDates);
		}catch(Exception e) {
			logger.warn("Error while parsing date: ",e);
		}
		return sortedStringDates;
	}
	public static List<Intents> prepareIntentsListFromResponse(BasicDBObject inputJsonObj){
		List<Intents> nlpIntentsList = new ArrayList<>();
		if(null != inputJsonObj.get(NLPConstants.INTENTS)) {
			BasicDBList intents = (BasicDBList) inputJsonObj.get(NLPConstants.INTENTS);
			for(int i=0;i<intents.size();i++) {
				Intents nlpIntent = new Intents();
				BasicDBObject intentObject = (BasicDBObject) intents.get(i);
				if(intentObject.containsField(NLPConstants.SENTENCE) && intentObject.containsField(NLPConstants.INTENT) 
						&& intentObject.containsField(NLPConstants.PROBABILITY) && intentObject.containsField(NLPConstants.INDEX)) {
					addToIntentList(nlpIntentsList, nlpIntent, intentObject);
				}
				
			}
		}
		return nlpIntentsList.stream().sorted((o1, o2)->o2.getProbability().
                compareTo(o1.getProbability())).
                collect(Collectors.toList());
	}
	
	private static void addToIntentList(List<Intents> nlpIntentsList,Intents nlpIntent,BasicDBObject intentObject) {
		if (StringUtils.isNotEmpty(intentObject.getString(NLPConstants.SENTENCE))
				&& StringUtils.isNotEmpty(intentObject.getString(NLPConstants.INTENT))
				&& intentObject.get(NLPConstants.PROBABILITY) != null && intentObject.get(NLPConstants.PROBABILITY) != ""
				&& intentObject.get(NLPConstants.INDEX) != null && intentObject.get(NLPConstants.INDEX) != "") {
			nlpIntent.setSentence(intentObject.getString(NLPConstants.SENTENCE));
			nlpIntent.setIntent(intentObject.getString(NLPConstants.INTENT));
			nlpIntent.setProbability(intentObject.getInt(NLPConstants.PROBABILITY));
			nlpIntent.setIndex(intentObject.getInt(NLPConstants.INDEX));
			nlpIntentsList.add(nlpIntent);
		}
	}
}
