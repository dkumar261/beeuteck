/*
 * package com.citi.icg.qma.common.core.util;
 * 
 * import java.io.File; import java.io.FileInputStream; import
 * java.io.FileNotFoundException; import java.util.ArrayList; import
 * java.util.List; import java.util.Optional;
 * 
 * import org.apache.commons.compress.utils.FileNameUtils; import
 * org.apache.poi.ooxml.POIXMLDocument; import
 * org.apache.poi.xslf.usermodel.XSLFSlideShow; import
 * org.apache.poi.xssf.usermodel.XSSFWorkbook; import
 * org.apache.poi.xwpf.usermodel.XWPFDocument; import
 * org.openxmlformats.schemas.officeDocument.x2006.customProperties.CTProperty;
 * import org.slf4j.Logger; import org.slf4j.LoggerFactory;
 * 
 * public interface FileDataClassificationUtil { public static final String
 * MS_DOCX_EXTENSION = "docx"; public static final String MS_EXCEL_EXTENSION =
 * "xlsx"; public static final String MS_PPT_EXTENSION = "pptx"; static final
 * Logger logger = LoggerFactory.getLogger(FileDataClassificationUtil.class);
 * 
 * 
 * 
 * // Method which take files and return their data classification label name
 * public static List<String> readFileDataClassificationProperties(List<File>
 * fileList) { List<String> msipLabels = new ArrayList<String>(); POIXMLDocument
 * poiXMLDocument = null;
 * org.openxmlformats.schemas.officeDocument.x2006.customProperties.CTProperties
 * ctProperties = null; if (fileList.isEmpty()) return null; try { for (File
 * file : fileList) { poiXMLDocument = getPOIXMLDocumentByFileType(file); if
 * (null != poiXMLDocument && null != poiXMLDocument.getProperties() && null !=
 * poiXMLDocument.getProperties().getCustomProperties()) { ctProperties =
 * poiXMLDocument.getProperties().getCustomProperties().getUnderlyingProperties(
 * ); Optional<CTProperty> p = ctProperties.getPropertyList().stream()
 * .filter(ctProperty -> ctProperty.getName().startsWith("MSIP_Label_") &&
 * ctProperty.getName().endsWith("_Name")) .findAny(); if (p.isPresent())
 * msipLabels.add(p.get().getLpwstr());
 * 
 * } else { return null; } poiXMLDocument = null;
 * 
 * } } catch (Exception e) { logger.error("Error in reading MSIP label name ",
 * e.getMessage()); e.printStackTrace(); return null; } return msipLabels;
 * 
 * }
 * 
 * public static String readMSIPLabelValue(File file) throws Exception {
 * POIXMLDocument poiXMLDocument = null; String msipLabelValue = null;
 * org.openxmlformats.schemas.officeDocument.x2006.customProperties.CTProperties
 * ctProperties = null; try { poiXMLDocument =
 * getPOIXMLDocumentByFileType(file); if (null != poiXMLDocument && null !=
 * poiXMLDocument.getProperties() && null !=
 * poiXMLDocument.getProperties().getCustomProperties()) { ctProperties =
 * poiXMLDocument.getProperties().getCustomProperties().getUnderlyingProperties(
 * ); Optional<CTProperty> msipProperty =
 * ctProperties.getPropertyList().stream() .filter(ctProperty ->
 * ctProperty.getName().startsWith("MSIP_Label_") &&
 * ctProperty.getName().endsWith("_Name")) .findAny(); if
 * (msipProperty.isPresent()) msipLabelValue = msipProperty.get().getLpwstr(); }
 * 
 * } catch (Exception e) { logger.error("Invalid file"); throw e; } return
 * msipLabelValue; }
 * 
 * public static POIXMLDocument getPOIXMLDocumentByFileType(File file) throws
 * Exception { POIXMLDocument poiXMLDocument = null; FileInputStream
 * fileInputStream = null; try { if (file.isFile()) { String fileType =
 * FileNameUtils.getExtension(file.getName()); if (!fileType.isEmpty()) { if
 * (MS_DOCX_EXTENSION.equalsIgnoreCase(fileType)) { fileInputStream = new
 * FileInputStream(file); poiXMLDocument = new XWPFDocument(fileInputStream);
 * fileInputStream.close(); return poiXMLDocument; } else if
 * (MS_EXCEL_EXTENSION.equalsIgnoreCase(fileType)) { poiXMLDocument = new
 * XSSFWorkbook(file); return poiXMLDocument; } else if
 * (MS_PPT_EXTENSION.equalsIgnoreCase(fileType)) { poiXMLDocument = new
 * XSLFSlideShow(file.getAbsolutePath()); return poiXMLDocument; } else { //
 * file should be of type docx,xslx,pptx and pdf return poiXMLDocument; } } else
 * { return poiXMLDocument; } } else { throw new
 * FileNotFoundException("File is not found or invalid file"); } } catch
 * (Exception e) { e.printStackTrace(); throw e; } } }
 */