package com.citi.icg.qma.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;

import com.citi.icg.qma.common.core.util.QmaMailConstants;
import com.citi.icg.qma.exception.QmaInitializationException;

/**
 * Reads YAML file and loads Config into QmaMailConfig Object
 */
public class QmaMailConfigLoader {

	private static final Logger logger = LoggerFactory.getLogger(QmaMailConfigLoader.class);
	private static QmaMailConfig config;

	public static synchronized QmaMailConfig getConfig() {
		if (config == null) {
					String configFile = System.getProperty(QmaMailConstants.QMA_MAIL_CONFIG_FILE);
					if(null != configFile) {
						logger.info("YamlCheck : config file location ["+configFile+"]");
						try {
							config = load(configFile);
						} catch (FileNotFoundException e) {
							throw new QmaInitializationException("YamlCheck : File not found at ["+configFile+"]", e);
						}
					}else {
						try {
							String environment = System.getProperty("icg.env");
							configFile = "qma-mail-config-" + environment + ".yaml";
							logger.info(" Loading yaml for " + environment + "from communicator-ui file name is:" + configFile);
							config = loadFromUi(configFile);
						} catch (FileNotFoundException e) {
							throw new QmaInitializationException("YamlCheck : File not found at ["+configFile+"]", e);
						}
					}
					logger.info("YamlCheck : mail-app-config-initialization-complete");
				}
				logger.info("Printing System properties after initilizing config : ");
				initCommonPropertiesAtJVMLevel();
			
		return config;
	}

	private static void initCommonPropertiesAtJVMLevel() {
		try {
			InetAddress address = InetAddress.getLocalHost();
			System.setProperty("qma.current.machine.ip", address.getHostAddress());
			System.setProperty("qma.current.machine.hostname", address.getCanonicalHostName());
		} catch (UnknownHostException e1) {
			String errorMsg = "Exception occurred while initializing properties at JVM system level viz. [qma.current.machine.ip, qma.current.machine.hostname]";
			logger.error(errorMsg, e1);
		}
	}

	private static QmaMailConfig load(String filename) throws FileNotFoundException {
		Yaml yaml = new Yaml();
		InputStream is = new FileInputStream(filename);
		config = yaml.loadAs(is, QmaMailConfig.class);		
		logger.info("YamlCheck : " +ReflectionToStringBuilder.toString(config, ToStringStyle.MULTI_LINE_STYLE));
		initializeTruststoreConfig();
		return config;
	}

	private static QmaMailConfig loadFromUi(String filename) throws FileNotFoundException {
		Yaml yaml = new Yaml();
		InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(filename);
		config = yaml.loadAs(is, QmaMailConfig.class);		
		logger.info("YamlCheck : " +ReflectionToStringBuilder.toString(config, ToStringStyle.MULTI_LINE_STYLE));
		initializeTruststoreConfig();
		return config;
	}

	private static void initializeTruststoreConfig() throws FileNotFoundException {
		String providedTruststore = System.getProperty("javax.net.ssl.trustStore");
		if("test".equalsIgnoreCase(System.getProperty("icg.env")))
			return;
		if (StringUtils.isNotBlank(providedTruststore) && (new File(providedTruststore)).exists() ) {
			logger.info("provided(as system property javax.net.ssl.trustStore) trustStore file : [{}]", providedTruststore);
		} else {
			String trustStoreFile = config.getMongoCertsLocation();
			if (StringUtils.isNotBlank(trustStoreFile)) {
				if ( (new File(trustStoreFile)).exists()) {
					System.setProperty("javax.net.ssl.trustStore", trustStoreFile);
				} else {
					throw new FileNotFoundException("The configured truststore file not found at ["+trustStoreFile+"]");
				}			
			}
            else {
				throw new QmaInitializationException("Please provide location of truststore file");
			}
		}
		
	}
}
