package com.citi.icg.qma.common.server.dao.persistence.oasys.payments;

import java.util.List;

public class ClcOasysResponse {

	private String qmaRequestId;
	private List<OasysPaymentStatus> paymentStatus;

	public String getQmaRequestId() {
		return qmaRequestId;
	}

	public void setQmaRequestId(String qmaRequestId) {
		this.qmaRequestId = qmaRequestId;
	}

	public List<OasysPaymentStatus> getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(List<OasysPaymentStatus> paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

}
