package com.citi.icg.qma.common.messagebus.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.Instant;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.core.util.MessageBusSocketFactory;
import com.citi.icg.qma.common.messagebus.entity.Data;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

public class MessageBusUtil { 
	private static final Logger subLogger = LoggerFactory.getLogger(MessageBusUtil.class);
	private static final String BRAZIL_FX_CONFIG = "brazilFxConfig";
	
	public static boolean publishMessageToMessageBus(Data dataToPublish, String eventId, String messageKey, String eventAuditId,String certPath) throws CommunicatorException {
		return publishMessageBus(dataToPublish,eventId,messageKey,eventAuditId,certPath);
	}
	
	public static boolean publishMessageToMessageBus(Data dataToPublish, String eventId, String messageKey,String certPath) throws CommunicatorException {
		return publishMessageBus(dataToPublish,eventId,messageKey,null,certPath);
	}
	
	public static boolean publishMessageBus(Data dataToPublish, String eventId, String messageKey, String eventAuditId,String certPath) throws CommunicatorException {
		subLogger.info("Publishing event to message bus for inquiryId: {}, coversationId: {}",
				 dataToPublish.getPayload().getInquiryId(),dataToPublish.getPayload().getConversationId());
		Long startTime = Instant.now().toEpochMilli();
		subLogger.info("In MessageBusUtil.publishMessageToMessageBus starts: {}",startTime);
		Boolean messagePublished = false;
		CloseableHttpResponse response = null;
		HttpPost request = null;
		try (CloseableHttpClient  httpClient = getHttpClient(certPath)){
			if(null == httpClient) {
				subLogger.warn("HttpClient for message bus is null");
				return false;
			}
			JSONObject item = new JSONObject();
			item.put("dataToPublish",DataConversionUtil.convertJavaObjectToJson(dataToPublish));
			item.put("eventId", eventId);
			item.put("messageKey",messageKey);
			item.put("eventAuditId", eventAuditId);
			request = new HttpPost(getQMAkafkaServiceUrl());

			request.setEntity(new StringEntity(item.toString()));
			request.setHeader("accept", "application/json");
			request.setHeader("content-type", "application/json");

			response = httpClient.execute(request);

			subLogger.info("In InquiryDao.publishMessageToMessageBus response from Kafka service: {}",
					response.getStatusLine().getStatusCode());
			if (response.getStatusLine().getStatusCode() == 200) {
					JSONObject content = extractResponse(response);
					if("EVENT_PUBLISHED".equalsIgnoreCase(content.get("status").toString()))
						messagePublished = true;
					else
						messagePublished = false;
			} else {
				JSONObject content = extractResponse(response);
				subLogger.warn("Response from Kafka service: {}", content);
			}
			subLogger.info("In MessageBusUtil.publishMessageToMessageBus ends: currentTime: {}, time taken: {}",Instant.now().toEpochMilli(),(Instant.now().toEpochMilli() - startTime));
		}catch(Exception e) {
			subLogger.warn("Exception in MessageBusUtil.publishMessageToMessageBus: {}", e);
			throw new CommunicatorException("Error in connecting kafka service: " + e.getMessage());
		} finally {
			if(null != response) {
				try {
					response.close();
				} catch (IOException e) {
					subLogger.warn("Exception in MessageBusUtil.publishMessageToMessageBus: {}", e);
				}
			}
			if(null != request) {
				request.releaseConnection();
			}
		}
		return messagePublished;
	}
	
	private static CloseableHttpClient getHttpClient(String certPath) {
		CloseableHttpClient httpClient = null ;
		try {
			
			String xmcEnvironment = System.getProperty(AppserverConstants.ENV_PARAM_KEY);
			
			SSLConnectionSocketFactory socketFactory = MessageBusSocketFactory.getInstance(certPath);
			if(null!= socketFactory) {
				httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).disableCookieManagement().build();
				subLogger.info("Message Bus :: Environment is :{} using one-way SSL enabled HttpClient.",xmcEnvironment);
			} 
		
				
		} catch (Exception e) {
			subLogger.warn("Message Bus :: Error while creating http client in MessageBusUtil#getHttpClient() : ",e);
		}
		return httpClient;
		
	}

	
	
	private static JSONObject extractResponse(HttpResponse response) throws IOException {
		JSONObject result = new JSONObject();
		HttpEntity entity = response.getEntity();
		subLogger.info("response.entity: {},entity.getContentLength(): {}, number of bytes that can be read : {} ", response.getEntity(),entity.getContentLength(),entity.getContent().available());
		if (entity.getContentLength() != 0) {
			result = new JSONObject(convertStreamToString(entity.getContent()));
			subLogger.info("Content: {}", result);
		}
		return result;
	}
	
	private static String convertStreamToString(InputStream is) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}
		} catch (IOException e) {
			subLogger.debug(e.toString());
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				subLogger.debug(e.toString());
			}
		}
		return sb.toString();
	}
	
	protected static String getQMAkafkaServiceUrl(){
		String qmaServiceURL = null;
		try {
			if (null != QMACacheFactory.getCache().getConfigById(BRAZIL_FX_CONFIG)) {
				Config configData = QMACacheFactory.getCache().getConfigById(BRAZIL_FX_CONFIG);
				if (null != configData) {
					qmaServiceURL = (String) configData.getMessageBusPublisherURL();
				}
			}
		} catch (Exception e) {
			subLogger.warn("Error while populating {} : {}",BRAZIL_FX_CONFIG, e);
		}
		return qmaServiceURL;
	}
	

}
