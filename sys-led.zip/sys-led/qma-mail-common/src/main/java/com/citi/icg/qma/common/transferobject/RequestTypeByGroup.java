package com.citi.icg.qma.common.transferobject;

public class RequestTypeByGroup
{
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private String group;
	private int count;
	private String requestType;
	
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	
}
