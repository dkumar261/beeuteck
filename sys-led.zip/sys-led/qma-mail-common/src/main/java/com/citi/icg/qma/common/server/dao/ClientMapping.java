package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

/**
 * ClientMapping collection Entity
 * 
 *
 */
@Entity(value = "ClientMapping", noClassnameStored = true)
public class ClientMapping implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3041528260979785291L;
	@Id
	private String id;
	private String clientName;
	private String gpNum;
	private String gpName;
	private String clientCategory;
	private String source;
	private Date modDate;
	/**
	 * Default constructor
	 */
	public ClientMapping()
	{
		super();
	}
	
	/**
	 * Constructor with all fields
	 */
	public ClientMapping(String id, String clientName, String gpNum, String gpName, String clientCategory,
			String source, Date modDate) {
		super();
		this.id = id;
		this.clientName = clientName;
		this.gpNum = gpNum;
		this.gpName = gpName;
		this.clientCategory = clientCategory;
		this.source = source;
		this.modDate = modDate;
	}

	public String getId()
	{
		return id;
	}
	public void setId(String id)
	{
		this.id = id;
	}
	public String getClientName()
	{
		return clientName;
	}
	public void setClientName(String clientName)
	{
		this.clientName = clientName;
	}
	public String getGpNum()
	{
		return gpNum;
	}
	public void setGpNum(String gpNum)
	{
		this.gpNum = gpNum;
	}
	public String getGpName()
	{
		return gpName;
	}
	public void setGpName(String gpName)
	{
		this.gpName = gpName;
	}

	public String getClientCategory() {
		return clientCategory;
	}

	public void setClientCategory(String clientCategory) {
		this.clientCategory = clientCategory;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Date getModDate() {
		return modDate;
	}

	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}

	@Override
	public String toString()
	{
		return "ClientMapping [id=" + id + ", clientName=" + clientName + ", gpNum=" + gpNum + ", gpName=" + gpName + ", clientCategory=" + clientCategory + ", source=" + source + "]";
	}

}
