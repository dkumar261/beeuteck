package com.citi.icg.qma.common.transferobject;

public class CorporateAddressBookTO
{

	private String name;
	private String email;
	private String department;
	private String phone;
	private String country;
	private String longDesc;
	public CorporateAddressBookTO()
	{
	}
	
	public CorporateAddressBookTO(String name, String email)
	{
		super();
		this.name = name;
		this.email = email;
	}

	public CorporateAddressBookTO(String name, String email, String department, String phone, String country)
	{
		super();
		this.name = name;
		this.email = email;
		this.department = department;
		this.phone = phone;
		this.country = country;
	}
	public CorporateAddressBookTO(String name, String email, String department, String phone, String country, String longDesc)
	{
		super();
		this.name = name;
		this.email = email;
		this.department = department;
		this.phone = phone;
		this.country = country;
		this.longDesc = longDesc;
	}
	/**
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * @return the email
	 */
	public String getEmail()
	{
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email)
	{
		this.email = email;
	}

	/**
	 * @return the department
	 */
	public String getDepartment()
	{
		return department;
	}

	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department)
	{
		this.department = department;
	}

	/**
	 * @return the phone
	 */
	public String getPhone()
	{
		return phone;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone)
	{
		this.phone = phone;
	}

	/**
	 * @return the country
	 */
	public String getCountry()
	{
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country)
	{
		this.country = country;
	}

	public String getLongDesc() {
		return longDesc;
	}

	public void setLongDesc(String longDesc) {
		this.longDesc = longDesc;
	}

}
