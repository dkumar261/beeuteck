package com.citi.icg.qma.common.core.util;

public class ApplicationConstants
{
	private ApplicationConstants(){};//Sonar fix - to hide the class having all methods and variables as static
	
	// Added to decrypt the encrypted passwords
	public static final String APPLICATION_ENCRYPTION_KEY = "heyQI0JfwINcT3M0WAwOXA==";
	public static final String DETERMINISTIC_ENCRYPTION_MODE = "DETERMINISTIC";
	public static final String RANDOMIZED_ENCRYPTION_MODE = "RANDOMIZED";

}
