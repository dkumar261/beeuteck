package com.citi.icg.qma.common.server.aws.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.s3.AmazonS3;
import com.citi.icg.qma.common.server.dao.persistence.AttachmentDAO;
import com.citi.icg.qma.common.server.dao.persistence.MongoDB;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.WriteConcern;
import com.mongodb.gridfs.GridFSDBFile;

import dev.morphia.Datastore;
import dev.morphia.Morphia;
import dev.morphia.mapping.Mapper;

public class MongoToS3WriterHelperFsFiles implements Runnable
{

	private List<GridFSDBFile> mongoIdsChunkList;
	private static final Logger logger = LoggerFactory.getLogger(MongoToS3WriterHelperFsFiles.class);
	private static final DB database = MongoDB.instance().getDB();
	private static final Datastore mongoDatastore = MongoDB.instance().getDataStore();
	public static volatile Long totalProcessedCount =0L; 
	public static volatile int s3MigratedDocssize =0;
	public static volatile int mongoDeletedDocsSize =0;


	// private static AtomicInteger totalDocumentCount = new AtomicInteger();

	public MongoToS3WriterHelperFsFiles(List<GridFSDBFile> mongoIdsChunkList) throws IOException
	{

		this.mongoIdsChunkList = mongoIdsChunkList;
	}

	@Override
	public void run()
	{
		try
		{
			logger.info("Processing no of mongoIds :" + mongoIdsChunkList.size());
			fetchConversationforInquiryIds(mongoIdsChunkList);
			// logger.info("******************  TOTAL DOCUMENTS :" + totalDocumentCount);

		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
		}

	}

	/**
	 * @param convbw2
	 * @param convbw2
	 * @param <T>
	 * @param inquiryIdsOf100
	 * @throws IOException
	 */
	private void fetchConversationforInquiryIds(List<GridFSDBFile> mongoIdsChunkList)
	{

		AWSUtility awsUtility = new AWSUtility();
		AmazonS3 amazonS3 = awsUtility.getConnection();
		AttachmentDAO attachDao = new AttachmentDAO();

		Long successfulMigration = 0L;
		Long failureMigration = 0L;
		String mongoId  = null;
		List<S3MigratedDocsFsFiles> s3MigratedDocsFsFilesList = new ArrayList<S3MigratedDocsFsFiles>();
		List<String> mongoDeletedList = new ArrayList<String>();

		for (int i = 0; i < mongoIdsChunkList.size(); i++)
		{
			try
			{
				// SUNIL : keep continue this process even if issue happens.
				// TODO: ADD ENTRY IN MongoToS3MigratedDocumentDetails
				//String docId = mongoIdsChunkList.get(i);
				GridFSDBFile gridFSDBFile = mongoIdsChunkList.get(i);
				mongoId = "" + gridFSDBFile.getId();
				
				//Map<String, Object> downloadedFileMap = attachDao.getFileForS3Migration(gridFSDBFile, mongoId, log);
				File file = attachDao.createFile(gridFSDBFile, mongoId);
				//File file = (File) downloadedFileMap.get("fileObject");
				Date uploadOn = gridFSDBFile.getUploadDate();//(Date) downloadedFileMap.get("uploadOn");
				Long size = gridFSDBFile.getLength();//(Long) downloadedFileMap.get("size");
				//String md5 = gridFSDBFile.getMD5();//(String) downloadedFileMap.get("md5");
				String type = gridFSDBFile.getContentType();//(String) downloadedFileMap.get("type");
				String fileName = gridFSDBFile.getFilename();//(String) downloadedFileMap.get("name");

				// write to S3 storgae
				//SUNIL : 20 april 2018, boolean is not trusted here as per testing.
				//boolean writeS3Flag = awsUtility.writeObject(amazonS3, mongoId, file); 
				awsUtility.writeObject(amazonS3, mongoId, file);
				logger.info("Copied in S3 sotrage succesfully, mongoId is: " + mongoId + "  name is:" + fileName);

				// deletefromMongoDb();
				file.delete();// delete file always on hard disk
				//if (writeS3Flag)
				{
					//mongoDatastore.save(new S3MigratedDocsFsFiles(fileName, mongoId, uploadOn, md5, type, size)); // contained all migrated data
					s3MigratedDocsFsFilesList.add(new S3MigratedDocsFsFiles(fileName, mongoId, uploadOn, null, type, size)); // contained all migrated data
					
					// convIdswithAttachments.add(conversationId);
					attachDao.deleteFile(mongoId);
					mongoDeletedList.add(mongoId);

					logger.info("deleted file in mongdb and locally too, mongoId is: " + mongoId + "  name is:" + fileName);
					successfulMigration++;
				}

			}
			catch (Exception e)
			{
				failureMigration++;
				logger.error("Issue in data migration, mongoId is: " + mongoId, e);
			}
		}
		try
		{
			logger.info("s3MigratedDocsFsFilesList batch size to be saved is: " + s3MigratedDocsFsFilesList.size());
			saveS3MigratedDocs(s3MigratedDocsFsFilesList);
			logger.info("batch Entry success to S3MigratedDocs, mongoId  is: " + mongoId + "  name is:" + s3MigratedDocsFsFilesList.get(0));
		}
		catch (Exception e)
		{
			logger.info("Issue batch Entry failed to S3MigratedDocs, mongoId  is: " + mongoId + "  name is:" + s3MigratedDocsFsFilesList.get(0));
		}
		
		updateCounts(s3MigratedDocsFsFilesList.size(), mongoDeletedList.size());
		
		
		
		logger.info("successfulMigration docs in batch: " + successfulMigration + "  , failureMigration Docs in batch:" + failureMigration);
		
		logger.info("Count stats are s3MigratedDocssize= "+ s3MigratedDocssize + "  , mongoDeletedDocsSize= " + mongoDeletedDocsSize);
	}
	


	private synchronized void updateCounts(int s3MigratedDocssize1, int mongoDeletedDocsSize1 )
	{
		s3MigratedDocssize = s3MigratedDocssize + s3MigratedDocssize1;
		mongoDeletedDocsSize = mongoDeletedDocsSize + mongoDeletedDocsSize1;

		
	}

	public void saveS3MigratedDocs(List<S3MigratedDocsFsFiles> s3MigratedDocsFsFilesList)
	// generic one
	{
		Morphia morphia = new Morphia();
		Mapper mapper = morphia.getMapper();
		List<DBObject> s3MigratedDocsFsFilesDBObjectList = new ArrayList<DBObject>();
		DBCollection s3MigratedDocsFsFilesCollection = mongoDatastore.getCollection(S3MigratedDocsFsFiles.class);

		for (int indx = 0; indx < s3MigratedDocsFsFilesList.size(); indx++)
		{
			S3MigratedDocsFsFiles s3MigratedDocsFsFiles = s3MigratedDocsFsFilesList.get(indx);
			// UINotifications uiNotifications = saveInquiryToPublishInBulk(id, userAction, userId);

			s3MigratedDocsFsFilesDBObjectList.add(mapper.toDBObject(s3MigratedDocsFsFiles));

		}
		s3MigratedDocsFsFilesCollection.insert(s3MigratedDocsFsFilesDBObjectList, WriteConcern.ACKNOWLEDGED);

	}

}
