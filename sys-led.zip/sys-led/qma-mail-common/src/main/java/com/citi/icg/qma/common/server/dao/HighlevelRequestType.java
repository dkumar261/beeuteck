package com.citi.icg.qma.common.server.dao;
import java.io.Serializable;

import dev.morphia.annotations.Embedded;

@Embedded
public class HighlevelRequestType implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5016472252515358132L;

	private String 	requestType;
	
	private String 	highlevelRequestType;
	
		public HighlevelRequestType()
	{
		super();
	}

	public HighlevelRequestType(String requestType, String highlevelRequestType)
	{
		super();
		
		this.requestType = requestType;
		this.highlevelRequestType = highlevelRequestType;
		
	}


	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getHighlevelRequestType() {
		return highlevelRequestType;
	}

	public void setHighlevelRequestType(String highlevelRequestType) {
		this.highlevelRequestType = highlevelRequestType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((highlevelRequestType == null) ? 0 : highlevelRequestType.hashCode());
		result = prime * result + ((requestType == null) ? 0 : requestType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HighlevelRequestType other = (HighlevelRequestType) obj;
		if (highlevelRequestType == null) {
			if (other.highlevelRequestType != null)
				return false;
		} else if (!highlevelRequestType.equals(other.highlevelRequestType))
			return false;
		if (requestType == null) {
			if (other.requestType != null)
				return false;
		} else if (!requestType.equals(other.requestType))
			return false;
		return true;
	}
}
