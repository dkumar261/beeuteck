package com.citi.icg.qma.common.core.util;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Password decryption utility
 */
public class DecryptionUtil
{
	
	private static final Logger logger = LoggerFactory.getLogger(DecryptionUtil.class);
	
	/**
	 * Base constructor
	 */
	private DecryptionUtil() { }

	/**
	 * decrypt - utility method to invoke for password decryption 
	 * @param encString
	 * @param encStringIV
	 * @param applicationEnckey
	 * @return
	 */
	public static String decrypt(String encString, String encStringIV, String applicationEnckey)  {
		String outputValue = null;
		byte[] encStringSend = null;
		
		logger.info("Inside the decryption Util");
		
		try {
			encStringSend = Base64.decodeBase64(encString);
			byte[] out = performDecryption(encStringIV, applicationEnckey).doFinal(encStringSend);
			outputValue = new String(out, "UTF-8");			
		} catch (Exception e) {
			logger.error("Error in DecryptionUtil.decrypt method - ",e );
		}
		return outputValue;

	}

	private static Cipher performDecryption(String stringIV, String stringEncKey)  
			throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, InvalidAlgorithmParameterException {

		byte[] encKey = Base64.decodeBase64(stringEncKey);
		byte[] iv = Base64.decodeBase64(stringIV);

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		SecretKeySpec key = new SecretKeySpec(encKey, "AES");
		cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
		return cipher;
	}
}