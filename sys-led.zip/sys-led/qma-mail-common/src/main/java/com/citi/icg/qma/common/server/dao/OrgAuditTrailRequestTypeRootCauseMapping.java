package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.List;

public class OrgAuditTrailRequestTypeRootCauseMapping implements Serializable {

	private static final long serialVersionUID = 9161330392785720464L;
	private String requestType;
	private List<String> rootCause;
	private String statusIndicator;

	public OrgAuditTrailRequestTypeRootCauseMapping() {
		super();
	}

	public OrgAuditTrailRequestTypeRootCauseMapping(String requestType, List<String> rootCause,
			String statusIndicator) {
		super();
		this.requestType = requestType;
		this.rootCause = rootCause;
		this.statusIndicator = statusIndicator;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public List<String> getRootCause() {
		return rootCause;
	}

	public void setRootCause(List<String> rootCause) {
		this.rootCause = rootCause;
	}

	public String getStatusIndicator() {
		return statusIndicator;
	}

	public void setStatusIndicator(String statusIndicator) {
		this.statusIndicator = statusIndicator;
	}

}
