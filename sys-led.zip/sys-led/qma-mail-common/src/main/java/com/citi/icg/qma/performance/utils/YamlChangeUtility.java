package com.citi.icg.qma.performance.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;

import com.citi.icg.qma.config.ConfluentKafkaConfig;
import com.citi.icg.qma.config.HazelcastConfig;
import com.citi.icg.qma.config.MongoDBConfig;
import com.citi.icg.qma.config.QmaMailConfig;

public class YamlChangeUtility {
	
	
	private static final Logger logger = LoggerFactory.getLogger(YamlChangeUtility.class);

	public static void main(String[] args) throws FileNotFoundException {
		
		String fileName="qma-mail-config.yaml";
		String folderRoot="C:\\Users\\XXXXXX\\git\\";
		String envPath="src\\main\\resources\\env\\";
		List<String> projects=new ArrayList<>();
		List<String> envs=new ArrayList<>();
		
		//envs.add("dev");
		envs.add("uat");
		//envs.add("prod");
		//envs.add("cob");
		projects.add("qma-cache-service");
		projects.add("qma-replay-service");
		projects.add("qma-mail-reader");
		projects.add("qma-mail-controller");
		projects.add("qma-mail-processor");
		projects.add("qma-snapshot-service");
//		
		for(String proj:projects){
			for(String env:envs){
				String path=folderRoot+proj+"\\"+envPath+env+"\\"+fileName;
				
				
				QmaMailConfig initialConfig=load(path);
				//do some changes
				/*ConfluentKafkaConfig o = initialConfig.getConfluentKafkaConfig();
				o.setBrokerCluster("sd-acf5-a16b:9092,sd-9dde-a59b:9092,sd-c279-3af4:9092");
				initialConfig.setConfluentKafkaConfig(o);
				*/
				HazelcastConfig hc = initialConfig.getHazelcastConfig();
				
				
				hc.setGroupName("qmauat");
				
				
				initialConfig.setHazelcastConfig(hc);
				initialConfig.setReaderDeleteMessages(true);
				initialConfig.setReaderbatchSize(4000);
				
				/*System.out.println(ReflectionToStringBuilder.toString(mongoDBConfig, ToStringStyle.MULTI_LINE_STYLE));
				mongoDBConfig.setBackupdbName(backupdbName);
				mongoDBConfig.*/
				
				saveYaml(path, initialConfig);
				
			}
		}
		
	}
	
	private static void saveYaml(String path,QmaMailConfig config) throws FileNotFoundException{
		 DumperOptions options = new DumperOptions();
	      options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
	      options.setPrettyFlow(true);
	      Yaml yaml = new Yaml(options);
	      
	      String output = yaml.dump(config);
	      
	      
	      try (PrintStream out = new PrintStream(new FileOutputStream(path))) {
	    	    out.print(output);
	      }
	      
	}
	
	private static QmaMailConfig load(String filename) throws FileNotFoundException {
		Yaml yaml = new Yaml();
		InputStream is = new FileInputStream(filename);
		QmaMailConfig config = yaml.loadAs(is, QmaMailConfig.class);		
		logger.debug("YamlCheck : " +ReflectionToStringBuilder.toString(config, ToStringStyle.MULTI_LINE_STYLE));
		
		return config;
	}

}
