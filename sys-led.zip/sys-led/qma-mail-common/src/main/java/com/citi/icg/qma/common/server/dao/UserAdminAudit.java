package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.CappedAt;
import dev.morphia.annotations.Entity;

@Entity(value = "UserAdminAudit", noClassnameStored = true, cap = @CappedAt(count = 5000, value = 500000))
public class UserAdminAudit extends BaseEntity{
	
	private String action;
	private String change;
	private String actionPerformedOn;
	private String previousValue;
	private String currentValue;
	private String comments;
	private String actionBy;
	
	
	public UserAdminAudit() {
		super();
	}
	
	public UserAdminAudit(String action, String change, String actionPerformedOn, String previousValue,
			String currentValue, String comments, String actionBy) {
		super();
		this.action = action;
		this.change = change;
		this.actionPerformedOn = actionPerformedOn;
		this.previousValue = previousValue;
		this.currentValue = currentValue;
		this.comments = comments;
		this.actionBy = actionBy;
	}



	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getPreviousValue() {
		return previousValue;
	}
	public void setPreviousValue(String previousValue) {
		this.previousValue = previousValue;
	}
	public String getCurrentValue() {
		return currentValue;
	}
	public void setCurrentValue(String currentValue) {
		this.currentValue = currentValue;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getActionBy() {
		return actionBy;
	}
	public void setActionBy(String actionBy) {
		this.actionBy = actionBy;
	}



	public String getChange() {
		return change;
	}



	public void setChange(String change) {
		this.change = change;
	}



	public String getActionPerformedOn() {
		return actionPerformedOn;
	}



	public void setActionPerformedOn(String actionPerformedOn) {
		this.actionPerformedOn = actionPerformedOn;
	}

}
