package com.citi.icg.qma.common.transferobject;

public class DashBoardCntTO
{
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private String category;
	private Long count;
	private Long unReadCount;
	public DashBoardCntTO()
	{

	}

	public DashBoardCntTO(String category, Long count,Long unReadCount)
	{
		super();
		this.category = category;
		this.count = count;
		this.unReadCount = unReadCount;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public Long getUnReadCount() {
		return unReadCount;
	}

	public void setUnReadCount(Long unReadCount) {
		this.unReadCount = unReadCount;
	}

}
