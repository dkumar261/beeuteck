package com.citi.icg.qma.common.core.util;

public class ExceptionUtil
{
	private static ExceptionUtil  exceptionUtil = null;
	
	public static ExceptionUtil getInstance()
	{
		if (exceptionUtil == null )
		{
			synchronized(ExceptionUtil.class)
			{
				if (exceptionUtil == null )
					return new ExceptionUtil();
			}
			
		}
				
		return exceptionUtil;
	}
	
	public   String getRootCause(Exception ex)
	{
		return ex.getMessage();
	}


}
