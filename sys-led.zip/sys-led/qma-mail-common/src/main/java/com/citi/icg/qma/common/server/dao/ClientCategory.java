package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

import dev.morphia.annotations.Embedded;

@Embedded
public class ClientCategory implements Serializable {
	
	private int id;
	private String categoryName;
	private String colorCode;
	
	public ClientCategory() {
		super();
	}

	public ClientCategory(int id, String categoryName, String colorCode) {
		super();
		this.id = id;
		this.categoryName = categoryName;
		this.colorCode = colorCode;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getColorCode() {
		return colorCode;
	}

	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}

}
