/**
 * 
 */
package com.citi.icg.qma.common.server.dao.persistence;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.core.util.QueryConstants;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.SymphonyDetails;
import com.citi.icg.qma.common.server.dao.SymphonyNotification;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.Workflow;
import com.citi.icg.qma.common.server.dao.WorkflowAudit;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.hazelcast.cache.client.HazelCastCacheIncrementalLoad;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;

import dev.morphia.Key;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

/**
 * 
 *
 */
public class SymphonyDAO extends MongoMorphiaDAO {

	private static String symphonyGroup = null;
	private static String symphonyBotName = null;
	private static String symphonyChatUrl = null;
	

	private static final Logger symphonyLogger = LoggerFactory.getLogger(SymphonyDAO.class);
	
	private static final InquiryCommonDAO inquiryCommonDAO = new InquiryCommonDAO();
	private static final InquiryDAO inquiryDao = new InquiryDAO();
	private static UserDAO userDao = new UserDAO();
	private static SymphonyDAO instance = null;
	
	public static synchronized SymphonyDAO getInstance()//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
	{
		if (instance == null) {
			initializeSymphonyGroupName();
			instance = new SymphonyDAO();
		}
		return instance;
	}
	
	@SuppressWarnings("unchecked")
	public boolean saveSymphonyDetails(String request, String soeId) {
		SymphonyDetails symphonyDetails = new SymphonyDetails();
		String symphonyStreamId = null;
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			if(null != inputJsonObj) {
				
				if(null!=inputJsonObj.get("symphonyStreamId")) {
					symphonyStreamId = inputJsonObj.getString("symphonyStreamId");
					symphonyDetails.setId(symphonyStreamId);
				}
				String chatroomName = null;
				if(null!=inputJsonObj.get("chatroomName")) {
					chatroomName = inputJsonObj.getString("chatroomName");
					symphonyDetails.setChatroomName(chatroomName);
				}
				List<String> memberList = null;
				if(null!=inputJsonObj.get("memberList")) {
					memberList = (List<String>) inputJsonObj.get("memberList");
					symphonyDetails.setMemberList(memberList);
				}
				List<Long> groupList = null;
				if(null!=inputJsonObj.get("groupList")) {
					groupList = (List<Long>) inputJsonObj.get("groupList");
					symphonyDetails.setGroupList(groupList);
				}
				symphonyDetails.setCrtBy(soeId);
				mongoDatastore.save(symphonyDetails);
			}
			return true;
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(symphonyLogger, "SymphonyDAO#saveSymphonyDetails() streamId= "+symphonyStreamId+" soeId = "+ soeId ,e);
			return false;
		}		
	}

	public DBObject getSymphonyDetails(String soeId, BasicDBObject inputJsonObj) {

		BasicDBObject SymphonyDetailsListObj = new BasicDBObject();
		try {
			@SuppressWarnings("unchecked")
			List<String> symphonyStreamIds = (List<String>) inputJsonObj.get("symphonyStreamId");
			Query<SymphonyDetails> query;
			List<SymphonyDetails> SymphonyDetailsList;
			query = mongoDatastore.createQuery(SymphonyDetails.class);
			query.criteria("_id").in(symphonyStreamIds);
			SymphonyDetailsList = query.find().toList();
			SymphonyDetailsListObj.put("SymphonyDetailsList", SymphonyDetailsList);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(symphonyLogger, "SymphonyDAO#getSymphonyDetails() soeId = "+ soeId ,e);
		}
		return SymphonyDetailsListObj;
	}
	
	public BasicDBObject saveSymphonyNotification(BasicDBObject inputJsonObj) {

		BasicDBObject result = new BasicDBObject();
		symphonyLogger.info("Symphony :: Inside saveSymphonyNotification");
		try {
			if(isSymphonyNotificationEnabled(symphonyLogger)) {
				SymphonyNotification symphonyNotification = new SymphonyNotification();
				if(null != inputJsonObj.get("conversationId")) {
					String conversationId = inputJsonObj.getString("conversationId");
					symphonyNotification.setConversationId(conversationId);
				}
				if(null != inputJsonObj.get("messageId")) {
					String messageId = inputJsonObj.getString("messageId");
					symphonyNotification.setMessageId(messageId);
				}
				if(null != inputJsonObj.get("fromUserProfile")) {
					Object fromUserProfile = inputJsonObj.getString("fromUserProfile");
					symphonyNotification.setFromUserProfile(fromUserProfile);
				}
				if(null != inputJsonObj.get("members")) {
					@SuppressWarnings("unchecked")
					List<String> members = (List<String>) inputJsonObj.get("members");
					symphonyNotification.setMembers(members);
				}
				if(null != inputJsonObj.get("sentTimestampUTC")) {
					String strSentTimestampUTC = inputJsonObj.getString("sentTimestampUTC");
					SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
					sDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
					Date sentTimestampUTC = sDateFormat.parse(strSentTimestampUTC);;
					symphonyNotification.setSentTimestampUTC(sentTimestampUTC);
				}
				if(null != inputJsonObj.get("isExternal")) {
					boolean isExternal = inputJsonObj.getBoolean("isExternal");
					symphonyNotification.setExternal(isExternal);
				}
				if(null != inputJsonObj.get("originalMessage")) {
					String originalMessage = inputJsonObj.getString("originalMessage");
					//symphonyNotification.setOriginalMessage(originalMessage);
				}
				if(null != inputJsonObj.get("markdownMessage")) {
					String markdownMessage = inputJsonObj.getString("markdownMessage");
					//symphonyNotification.setMarkdownMessage(markdownMessage);
				}
				mongoDatastore.save(symphonyNotification);
				result.put("saveStatus", true);
			} else {
				symphonyLogger.info("SymphonyDAO#saveSymphonyNotification() : Symphony notification is disabled, data will not process");
			}
			
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(symphonyLogger, "SymphonyDAO#saveSymphonyNotification()" ,e);
		}
		return result;
	}
	
	public BasicDBObject saveUserSymphonyId(BasicDBObject inputJson, String soeId){
		BasicDBObject result = new BasicDBObject();
		boolean flag = false;
		try {
			String symphonyId = inputJson.getString("symphonyId");
			String symphonyEmailId = inputJson.getString("symphonyEmailId");
			symphonyLogger.info("Inside SymphonyDAO.saveUserSymphonyId for userId= " + soeId);
			Query<User> query = mongoDatastore.createQuery(User.class).filter("_id", soeId);
			UpdateOperations<User> ops = mongoDatastore.createUpdateOperations(User.class);
			ops.set("symphonyId", symphonyId);
			ops.set("symphonyEmailId", symphonyEmailId);
			mongoDatastore.update(query, ops);
			flag = true;
			HazelCastCacheIncrementalLoad.loadUserSymphonyIdToSoeIdMap(soeId);
		} catch (Exception e) {
			symphonyLogger.error("Exception occurred in saveUserSymphonyId for soeId :"+ soeId,e);
		}
		result.put("status", flag);
		return result;
	}
	
	public BasicDBObject getSymphonyConversationByMessageId(String messageId, HttpClient httpClient, Logger sublogger) {
		long startTime = System.currentTimeMillis();
		BasicDBObject response = null;
		try {
			
			String symphonyConversationByMessageIdUrl = getSymphonyConversationByMessageIdUrl(messageId);
			//HttpClient httpClient = getHttpClient();
			HttpGet getRequest = new HttpGet(symphonyConversationByMessageIdUrl);
			addHeaderToGetRequest(getRequest);
			HttpResponse symphonyResponse = null;
			try {
				symphonyResponse = httpClient.execute(getRequest);
			} catch (Exception e) {
				sublogger.error("Symphony call failed while ececuting httpClient for soeId=", e);
			}
			sublogger.info("response: {}",(null == symphonyResponse ? symphonyResponse : symphonyResponse.toString())); //<-- sonar fix null pointer
			if (null != symphonyResponse && symphonyResponse.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = symphonyResponse.getEntity();
				StringBuilder content = extractSearchResponse(entity);
				sublogger.info("Content: "+content.toString());
				response = processResponse(content.toString(), null);
			} else {
				sublogger.info("Symphony call response code is not 200 to get symphonyId for soeId=");
			}
			//HttpHeaders requestHeader = getSymphonyRequestHeader();
			//HttpEntity<String> request = new HttpEntity<>(requestHeader);
			//response = restTemplate.exchange(symphonyChatUrl, HttpMethod.GET, request, String.class);
		} catch (Exception e) {
			sublogger.error("Exception in getSymphonyConversationByMessageId", e);
		}
		sublogger.info("time taken by getSymphonyConversationByMessageId method : "+(System.currentTimeMillis()-startTime)+" in ms");
		return response;
	}

	/**
	 * @param messageId 
	 * @return
	 */
	private String getSymphonyConversationByMessageIdUrl(String messageId) {
		String symphonyConversationByMessageId = symphonyChatUrl+"api/agent/v1/message/"+messageId;
		return symphonyConversationByMessageId;
	}
	
	private String getSymphonyStreamInfoUrl(String streamId) {
		String symphonyStreamInfoUrl = symphonyChatUrl+"api/pod/v3/room/"+streamId+"/info";
		return symphonyStreamInfoUrl;
	}
	
	private StringBuilder extractSearchResponse(HttpEntity entity) {
		StringBuilder content = new StringBuilder();
		byte[] buffer = new byte[1024];
		if (entity != null) {
			InputStream inputStream = null;
			try {
				inputStream = entity.getContent();
			} catch (Exception e1) {
				symphonyLogger.error(" Error in UserSymphonyIdUpdateJob#extractSearchResponse() :", e1);
			}
			try (BufferedInputStream bis = new BufferedInputStream(inputStream)) {
				int bytesRead = 0;
				while ((bytesRead = bis.read(buffer)) != -1) {
					String chunk = new String(buffer, 0, bytesRead);
					content.append(chunk);
				}
			} catch (Exception e) {
				symphonyLogger.error(" Error in UserSymphonyIdUpdateJob#extractSearchResponse() :", e);
			}
		}
		return content;
	}
	
	private BasicDBObject processResponse(String content, String soeId) {
		BasicDBObject obj = new BasicDBObject();
		try {
			symphonyLogger.info("Inside UserSymphonyIdUpdateJob.processResponse for userId= " + soeId);
			obj = BasicDBObject.parse(content);
			
		} catch (Exception e) {
			symphonyLogger.error("Exception occurred in processResponse for soeId :" + soeId, e);
		}
		return obj;

	}
	/*
	private HttpClient getHttpClient() throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException {
		SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, (x509CertChain, authType) -> true)
				.build();

		HttpClient httpClient = HttpClientBuilder.create().setSSLContext(sslContext)
				.setConnectionManager(new PoolingHttpClientConnectionManager(RegistryBuilder
						.<ConnectionSocketFactory>create().register("http", PlainConnectionSocketFactory.INSTANCE)
						.register("https", new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE))
						.build()))
				.build();
		return httpClient;
	}*/
	
	@SuppressWarnings("unchecked")
	public BasicDBObject createSymphonyChatRoom(String request, String soeId) {
		Inquiry inquiry = new Inquiry();
		BasicDBObject reponse = new BasicDBObject();
		String symphonyStreamId = null;
		try {
			Date currentDate = new Date();
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			if(null != inputJsonObj) {
				
				if(null!=inputJsonObj.get("symphonyStreamId")) {
					symphonyStreamId = inputJsonObj.getString("symphonyStreamId");
					inquiry.setSymphonyStreamId(symphonyStreamId);
				}
				String chatroomName = null;
				if(null!=inputJsonObj.get("chatroomName")) {
					chatroomName = inputJsonObj.getString("chatroomName");
					inquiry.setSymphonyChatroomName(chatroomName);
				}
				List<String> memberList = null;
				if(null!=inputJsonObj.get("allQmaUser")) {
					memberList = (List<String>) inputJsonObj.get("allQmaUser");
					inquiry.setSymphonyChatRoomMember(memberList);
					if(!memberList.contains(soeId)) {
						memberList.add(soeId);
					}
				} else {
					memberList = new ArrayList<>();
					memberList.add(soeId);
					inquiry.setSymphonyChatRoomMember(memberList);
				}
				List<Long> groupList = null;
				if(null!=inputJsonObj.get("groupList")) {
					groupList = (List<Long>) inputJsonObj.get("groupList");
					//inquiry.setAllToCCGrps(allToCCGrps.toString());
					inquiry.setGroupList(groupList);
				}
				List<String> externalUserList = null;
				if(null!=inputJsonObj.get("externalUserList")) {
					externalUserList = (List<String>) inputJsonObj.get("externalUserList");
					inquiry.setExternalUserList(externalUserList);
				}
				QMACache qmaCache = QMACacheFactory.getCache();
				Map<String, User> userInfoMap = qmaCache.getUserInfoMap();
				String userName = userInfoMap.get(soeId.toUpperCase()).getName();
				String userEmailId = userInfoMap.get(soeId.toUpperCase()).getEmail();
				Long symphonyGroupId = getSymphonyGroupId();
				addSymphonyInquiry(soeId, inquiry, currentDate, chatroomName, userName, userEmailId);
				addSymphonyWorkflow(soeId,symphonyGroupId, inquiry, currentDate);
				addSymphonyWorkflowAudit(inquiry, currentDate, userName, symphonyGroupId, "Symphony chatroom created", "Internal");
				//Long inquiryId = mongoDatastore.save(inquiry);
				Long inquiryId = persist(inquiry);
				inquiryCommonDAO.saveInquiryToPublish(inquiryId, inquiry.getAction(), soeId);
				reponse.put("status", true);
			}
			
			return reponse;
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(symphonyLogger, "SymphonyDAO#createSymphonyChatRoom() streamId= "+symphonyStreamId+" soeId = "+ soeId ,e);
			return null;
		}		
	}

	/**
	 * @return
	 */
	public Long getSymphonyGroupId() {
		return QMACacheFactory.getCache().getGroupCodeToIdMap().get(symphonyGroup.toUpperCase());
	}
	
	/**
	 * @return
	 */
	private static void initializeSymphonyGroupName() {
		if (null != QMACacheFactory.getCache().getConfigById("symphonyConfig"))
		{
			Config symphonyConfig = QMACacheFactory.getCache().getConfigById("symphonyConfig");
			if (null != symphonyConfig && null != symphonyConfig.getSymphonyConfig()){
				Map<String, Object> symphonyConfigObj = symphonyConfig.getSymphonyConfig();
				symphonyGroup = (String) symphonyConfigObj.get("symphonyGroup");
				symphonyBotName = (String) symphonyConfigObj.get("symphonyBot");
				symphonyChatUrl = (String) symphonyConfigObj.get("symphonyChatUrl");
			}
		}
	}

	/**
	 * @param soeId
	 * @param inquiry
	 * @param currentDate
	 * @param chatroomName
	 * @param userName
	 * @param userEmailId
	 */
	private void addSymphonyInquiry(String soeId, Inquiry inquiry, Date currentDate, String chatroomName,
			String userName, String userEmailId) {
		inquiry.setIsSymphonyChatroom("Y");
		String inquiryAction = "New Chatroom";
		inquiry.setStatus("Open");
		inquiry.setAction(inquiryAction);
		inquiry.setCrtBy(soeId);
		inquiry.setCrtDate(currentDate);
		inquiry.setModBy(soeId);
		inquiry.setModDate(currentDate);
		inquiry.setLatestUserId(soeId);
		inquiry.setLatestUserName(userName);
		inquiry.setLatestEmail(userEmailId);
		inquiry.setOrigSubject(chatroomName);
		inquiry.setSubject(chatroomName);
	}

	/**
	 * @param inquiry
	 * @param currentDate
	 * @param userName
	 * @param symphonyGroupId
	 */
	private void addSymphonyWorkflowAudit(Inquiry inquiry, Date currentDate, String userName, Long symphonyGroupId, String action, String actionDetails) {
		WorkflowAudit workflowAudit = new WorkflowAudit();
		workflowAudit.setUserId(userName);
		workflowAudit.setGroupId(symphonyGroupId);
		workflowAudit.setAction(action);
		workflowAudit.setActionDetails(actionDetails);
		workflowAudit.setModBy(userName);
		workflowAudit.setModDate(currentDate);
		workflowAudit.setGroupName(symphonyGroup);
		List<WorkflowAudit> workflowAuditList = new ArrayList<>();
		workflowAuditList.add(workflowAudit);
		inquiry.setWorkflowAudit(workflowAuditList);
	}

	/**
	 * @param soeId
	 * @param symphonyGroupId 
	 * @param inquiry
	 * @param currentDate
	 * @return
	 */
	private void addSymphonyWorkflow(String soeId, Long symphonyGroupId, Inquiry inquiry, Date currentDate) {
		Workflow workflow = new Workflow();
		String inquiryAction = "New Chatroom";
		workflow.setAction(inquiryAction);
		workflow.setAttchFlag("N");
		workflow.setAssignedGroupId(symphonyGroupId);
		workflow.setAssignedGroupName(symphonyGroup);
		workflow.setStatus("Open");
		workflow.setDirection("IN");
		workflow.setCrtBy(soeId);
		workflow.setCrtDate(currentDate);
		workflow.setModBy(soeId);
		workflow.setModDate(currentDate);
		List<Workflow> workflows = new ArrayList<>();
		workflows.add(workflow);
		inquiry.setWorkflows(workflows);
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public BasicDBObject addMember(String request, String soeId) {
		Inquiry inquiry = null;
		BasicDBObject response = new BasicDBObject();
		try {
			Date currentDate = new Date();
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			Long inquiryId = null;
			if(null != inputJsonObj) {
				
				if(null!=inputJsonObj.get("inquiryId")) {
					inquiryId = GenericUtility.getIdFromRequest(inputJsonObj, "inquiryId");
					inquiry = mongoDatastore.get(Inquiry.class, inquiryId);
				}
				List<String> allQmaUser = null;
				List<String> memberActionList = new ArrayList<>();
				List<Long> memberActionGroupList = new ArrayList<>();
				List<String> memberActionExternalList = new ArrayList<>();
				if(null!=inputJsonObj.get("allQmaUser")) {
					allQmaUser = (List<String>) inputJsonObj.get("allQmaUser");
					//to update audit
					List<String> symphonyChatroomMemberList = inquiry.getSymphonyChatRoomMember();
					if(null != allQmaUser && null != symphonyChatroomMemberList) {
						if(symphonyChatroomMemberList.size() < allQmaUser.size()) {
							for(String qmaUser : allQmaUser) {
								if(!symphonyChatroomMemberList.contains(qmaUser)) {
									memberActionList.add(qmaUser);
								}
							}
						} else {
							symphonyLogger.info("no update in member list");
						}
					}
					inquiry.setSymphonyChatRoomMember(allQmaUser);
				}
				
				List<Long> groupList = null;
				if(null!=inputJsonObj.get("groupList")) {
					List<Integer> grpInt = (List<Integer>) inputJsonObj.get("groupList");
					int nInts = grpInt.size();
					groupList = new ArrayList<Long>(nInts);
					for (int i=0;i<nInts;++i) {
						groupList.add(grpInt.get(i).longValue());
					}
					//to update audit
					List<Long> dbGroupList = inquiry.getGroupList();
					if(null != groupList && null != dbGroupList) {
						if(dbGroupList.size() < groupList.size()) {
							for(Long group : groupList) {
								if(!dbGroupList.contains(group)) {
									memberActionGroupList.add(group);
								}
							}
						} else {
							symphonyLogger.info("no update in group list");
						}
					}
					inquiry.setGroupList(groupList);
				}
				List<String> externalUserList = null;
				if(null!=inputJsonObj.get("externalUserList")) {
					externalUserList = (List<String>) inputJsonObj.get("externalUserList");
					//to update audit
					List<String> dbExternalUserList = inquiry.getExternalUserList();
					if(null != externalUserList && null != dbExternalUserList) {
						if(dbExternalUserList.size() < externalUserList.size()) {
							for(String externalUser : externalUserList) {
								if(!dbExternalUserList.contains(externalUser)) {
									memberActionExternalList.add(externalUser);
								}
							}
						} else {
							symphonyLogger.info("no update in external user list");
						}
					}
					inquiry.setExternalUserList(externalUserList);
				}
				String inquiryAction = "add member";
				inquiry.setAction(inquiryAction);
				inquiry.setModBy(soeId);
				inquiry.setModDate(currentDate);
				inquiry.setLatestUserId(soeId);
				String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
				String userEmailId = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getEmail();
				inquiry.setLatestUserName(userName);
				inquiry.setLatestEmail(userEmailId);
				
				Workflow workflow = inquiry.getWorkflows().get(0);
				workflow.setModBy(soeId);
				workflow.setModDate(currentDate);
				workflow.setAction(inquiryAction);
				List<Workflow> workflows = new ArrayList<>();
				workflows.add(workflow);
				inquiry.setWorkflows(workflows);
				
				WorkflowAudit workflowAudit = new WorkflowAudit();
				
				workflowAudit.setUserId(userName);
				workflowAudit.setAction("Member added to Symphony chatroom member : "+memberActionList.toString()
				+ " groupList: "+memberActionGroupList.toString()+" external user list: "+memberActionExternalList.toString());
				workflowAudit.setActionDetails("Internal");
				workflowAudit.setModBy(userName);
				workflowAudit.setModDate(currentDate);
				workflowAudit.setGroupName(symphonyGroup);
				List<WorkflowAudit> workflowAuditList = inquiry.getWorkflowAudit();
				if(null == workflowAuditList) {
					workflowAuditList = new ArrayList<>();
				}
				workflowAuditList.add(workflowAudit);
				inquiry.setWorkflowAudit(workflowAuditList);
				
				persist(inquiry);				
				inquiryCommonDAO.saveInquiryToPublish(inquiryId, inquiry.getAction(), soeId);
			}
			response.put("status", true);
			return response;
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(symphonyLogger, "SymphonyDAO#addMember() inquiryId= "+inquiry.getId()+" soeId = "+ soeId ,e);
			response.put("status", true);
			return response;
		}		
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public BasicDBObject removeMember(String request, String soeId) {
		Inquiry inquiry = null;
		BasicDBObject response = new BasicDBObject();
		try {
			Date currentDate = new Date();
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			Long inquiryId = null;
			if(null != inputJsonObj) {
				
				if(null!=inputJsonObj.get("inquiryId")) {
					inquiryId = GenericUtility.getIdFromRequest(inputJsonObj, "inquiryId");
					inquiry = mongoDatastore.get(Inquiry.class, inquiryId);
				}
				List<String> allQmaUser = null;
				List<String> memberActionList = new ArrayList<>();
				List<Long> memberActionGroupList = new ArrayList<>();
				List<String> memberActionExternalList = new ArrayList<>();
				if(null!=inputJsonObj.get("allQmaUser")) {
					allQmaUser = (List<String>) inputJsonObj.get("allQmaUser");
					//to update audit
					List<String> symphonyChatroomMemberList = inquiry.getSymphonyChatRoomMember();
					if(null != allQmaUser && null != symphonyChatroomMemberList) {
						if(symphonyChatroomMemberList.size() > allQmaUser.size()) {
							for(String qmaUser : symphonyChatroomMemberList) {
								if(!allQmaUser.contains(qmaUser)) {
									memberActionList.add(qmaUser);
								}
							}
						} else {
							symphonyLogger.info("no update in member list");
						}
					}
					inquiry.setSymphonyChatRoomMember(allQmaUser);
				}
				
				List<Long> groupList = null;
				if(null!=inputJsonObj.get("groupList")) {
					List<Integer> grpInt = (List<Integer>) inputJsonObj.get("groupList");
					int nInts = grpInt.size();
					groupList = new ArrayList<Long>(nInts);
					for (int i=0;i<nInts;++i) {
						groupList.add(grpInt.get(i).longValue());
					}
					//to update audit
					List<Long> dbGroupList = inquiry.getGroupList();
					if(null != groupList && null != dbGroupList) {
						if(dbGroupList.size() > groupList.size()) {
							for(Long group : dbGroupList) {
								if(!groupList.contains(group)) {
									memberActionGroupList.add(group);
								}
							}
						} else {
							symphonyLogger.info("no update in group list");
						}
					}
					inquiry.setGroupList(groupList);
				}
				List<String> externalUserList = null;
				if(null!=inputJsonObj.get("externalUserList")) {
					externalUserList = (List<String>) inputJsonObj.get("externalUserList");
					//to update audit
					List<String> dbExternalUserList = inquiry.getExternalUserList();
					if(null != externalUserList && null != dbExternalUserList) {
						if(dbExternalUserList.size() > externalUserList.size()) {
							for(String externalUser : dbExternalUserList) {
								if(!externalUserList.contains(externalUser)) {
									memberActionExternalList.add(externalUser);
								}
							}
						} else {
							symphonyLogger.info("no update in external user list");
						}
					}
					inquiry.setExternalUserList(externalUserList);
				}
				String inquiryAction = "remove member";
				inquiry.setAction(inquiryAction);
				inquiry.setModBy(soeId);
				inquiry.setModDate(currentDate);
				inquiry.setLatestUserId(soeId);
				String userName = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getName();
				String userEmailId = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase()).getEmail();
				inquiry.setLatestUserName(userName);
				inquiry.setLatestEmail(userEmailId);
				
				Workflow workflow = inquiry.getWorkflows().get(0);
				workflow.setModBy(soeId);
				workflow.setModDate(currentDate);
				workflow.setAction(inquiryAction);
				List<Workflow> workflows = new ArrayList<>();
				workflows.add(workflow);
				inquiry.setWorkflows(workflows);
				
				WorkflowAudit workflowAudit = new WorkflowAudit();
				workflowAudit.setUserId(userName);
				workflowAudit.setAction("Member removed from Symphony chatroom member : "+memberActionList.toString() + 
						" groupList: "+memberActionGroupList.toString()+" external user list: "+memberActionExternalList.toString());
				workflowAudit.setActionDetails("Internal");
				workflowAudit.setModBy(userName);
				workflowAudit.setModDate(currentDate);
				workflowAudit.setGroupName(symphonyGroup);
				List<WorkflowAudit> workflowAuditList = inquiry.getWorkflowAudit();
				if(null == workflowAuditList) {
					workflowAuditList = new ArrayList<>();
				}
				workflowAuditList.add(workflowAudit);
				inquiry.setWorkflowAudit(workflowAuditList);
				
				persist(inquiry);				
				inquiryCommonDAO.saveInquiryToPublish(inquiryId, inquiry.getAction(), soeId);
			}
			response.put("status", true);
			return response;
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(symphonyLogger, "SymphonyDAO#removeMember() inquiryId= "+inquiry.getId()+" soeId = "+ soeId ,e);
			response.put("status", true);
			return response;
		}
	}
	
	DBObject getSymphonyChatViewData(String soeId, BasicDBObject inputJsonObj, boolean isRetrieveAll, BufferedWriter bw) throws CommunicatorException
	{
		DBObject gridViewTO = null;
		try {
			String finalDefaultBoxCriteria = "{'status': 'Open', 'workflows': {'$elemMatch': {'status': 'Open', 'direction': 'IN', 'assignedGroupId': {'$in': [#SYMPHONYGROUPID#]}, 'rulesFlag': {'$exists': false}, 'snoozeAction': {'$exists': false}}}}";
			Long symphonyGroupId = getSymphonyGroupId();
			finalDefaultBoxCriteria = finalDefaultBoxCriteria.replaceAll("#SYMPHONYGROUPID#", symphonyGroupId.toString());
			BasicDBObject topCriteria = BasicDBObject.parse(finalDefaultBoxCriteria);
			symphonyLogger.info("getSymphonyChatViewData for soeId: "+soeId);
			String viewName = inputJsonObj.getString("viewName");
			gridViewTO = new BasicDBObject();
			if (inquiryDao.isGroupLevelGridView(soeId))
			{
				gridViewTO = inquiryDao.getGroupLevelGridViewData(gridViewTO, soeId, topCriteria, null,
						null, null, null, 0, "ChatView", false, isRetrieveAll, inputJsonObj, bw);
				if(null != inputJsonObj && null != inputJsonObj.get("categoryType")) {
					//modifyFinalUICriteriaForSystemCategory(gridViewTO, inputJsonObj, soeId);
				}
				gridViewTO.put("finalCriteria", GenericUtility.parseJsonInRelaxedMode((DBObject) gridViewTO.get("finalUICriteria")));
			}
		} catch (Exception e) {
			symphonyLogger.error("Exception in getSymphonyChatViewData for soeId: "+soeId, e);
			throw new CommunicatorException(e.toString());
		}
		
		return gridViewTO;

	}
	
	public boolean isCombinedViewRequired(String viewName, String soeid) {
		symphonyLogger.info("Inside isCombinedViewRequired to check if user is entitled to see combined view ");
		boolean flag = false;
		try {
			User userObj = QMACacheFactory.getCache().getUserInfoMap().get(soeid.toUpperCase());
			String userSymphonyId = userObj.getSymphonyId();
			String isSymphonyEnabledForUser = userObj.getIsSymphonyEnabledForUser();
			boolean isSymphonyEnabled = isSymphonyEnabled(symphonyLogger);
			if(isSymphonyEnabled && StringUtils.isNotBlank(userSymphonyId) && "Inbox".equalsIgnoreCase(viewName) && "Y".equalsIgnoreCase(isSymphonyEnabledForUser)) {
				flag = true;
			}
		} catch (Exception e) {
			symphonyLogger.error("Exception in isCombinedViewRequired for soeId :"+soeid, e);
		}
		return flag;
	}

	public List<BasicDBObject> getCombinedViewQuery(String viewName, String soeId) {
		try {
			String query = QueryConstants.COMBINED_VIEW_QUERY;
			Set<Long> userGroupsList = userDao.getUserGroupsList(soeId);
			
			// C170665-42 | Get the list of assigned group select in dash board setting.
			userGroupsList = inquiryDao.getAssignedGroupsfromDashboard(soeId, userGroupsList);
			
			if(StringUtils.isNotBlank(viewName) && SymphonyDAO.getInstance().isCombinedViewRequired(viewName, soeId) && !userGroupsList.isEmpty()) {
				Long symphonyGroupId = getSymphonyGroupId();
				userGroupsList.add(symphonyGroupId);
				symphonyLogger.info("Symphony:: added symphony groupId to combined view query : "+ symphonyGroupId);
			}
			query = query.replaceAll("#GROUPID#", userGroupsList.toString());
			query = query.replaceAll("#SOEID#", soeId);
			List<BasicDBObject> queryList = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(query));
			return queryList;
		} catch (CommunicatorException e) {
			symphonyLogger.error("Exception in getCombinedViewQuery for soeId :"+soeId, e);
			return null;
		}
	}
	
	public List<BasicDBObject> getChatViewQuery(String viewName, String soeId) {
		try {
			String query = QueryConstants.CHAT_VIEW_QUERY;
			Set<Long> userGroupsList = new HashSet<>();//userDao.getUserGroupsList(soeId);
			Long symphonyGroupId = getSymphonyGroupId();
			userGroupsList.add(symphonyGroupId);
			symphonyLogger.info("Symphony:: added symphony groupId to combined view query : "+ symphonyGroupId);
			query = query.replaceAll("#GROUPID#", userGroupsList.toString());
			query = query.replaceAll("#SOEID#", soeId);
			@SuppressWarnings({ "unchecked", "deprecation" })
			List<BasicDBObject> queryList = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(query));
			return queryList;
		} catch (Exception e) {
			symphonyLogger.error("Exception in getChatViewQuery for soeId :"+soeId, e);
			return null;
		}
	}
	
	public void updateMemberAndModDateFromSymphonyNotification(List<String> allQmaUsers, String streamId, String soeId, HttpClient httpClient, Logger logger) {
		Inquiry inquiry = null;
		logger.info("Inside updateMemberAndModDateFromSymphonyNotification for streamId: "+streamId);
		String action = null;
		try {
			Date currentDate = new Date();
			DBObject updateInquiryObj = new BasicDBObject();
			
			if(StringUtils.isNotBlank(streamId)) {
				Long symphonyGroupId = getSymphonyGroupId();
				Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("workflows.direction", "IN")
						.filter("workflows.assignedGroupId",symphonyGroupId).filter("symphonyStreamId",streamId);
				inquiry = query.first();
				if(null != inquiry) {
					updateInquiryStreamMapping(allQmaUsers, streamId, soeId, logger, inquiry, action, currentDate,
							updateInquiryObj, symphonyGroupId);
				} else {
					//create mapping
					inquiry = createInquiryStreamMapping(allQmaUsers, streamId, soeId, httpClient, logger);
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(logger, "SymphonyDAO#addMember() inquiryId= "+ (null == inquiry ? inquiry :inquiry.getId())+" soeId = "+ soeId+" streamId= "+streamId ,e); //<-- sonar fix null pointer
		}		
	}

	/**
	 * @param allQmaUsers
	 * @param streamId
	 * @param soeId
	 * @param httpClient 
	 * @param logger 
	 * @return
	 */
	private Inquiry createInquiryStreamMapping(List<String> allQmaUsers, String streamId, String soeId, HttpClient httpClient, Logger logger) {
		Inquiry inquiry;
		Long symphonyGroupId;
		logger.info("Inside createInquiryStreamMapping for soeId :"+soeId+" and streamId: "+streamId);
		inquiry = new Inquiry();
		try {
			BasicDBObject responseObj = getSymphonyStreamInfo(streamId, soeId, httpClient);
			String chatroomName = null;
			if(null != responseObj && null != responseObj.get("roomAttributes")) {
				BasicDBObject roomAttributes = (BasicDBObject) responseObj.get("roomAttributes");
				if(null != roomAttributes && null != roomAttributes.get("name")) {
					chatroomName = (String) roomAttributes.get("name");
				}
			}
			if(StringUtils.isNotBlank(streamId) && StringUtils.isNotBlank(chatroomName)) {
				inquiry.setSymphonyStreamId(streamId);
				inquiry.setSymphonyChatroomName(chatroomName);
				inquiry.setSymphonyChatRoomMember(allQmaUsers);
				//if crtBy is available then set it
				String userName = null;
				String userEmailId = null;
				Date crtDate = new Date();
				QMACache qmaCache = QMACacheFactory.getCache();
				Map<String, User> userInfoMap = qmaCache.getUserInfoMap();
				if(null != soeId && null != userInfoMap.get(soeId.toUpperCase())) {
					userName = userInfoMap.get(soeId.toUpperCase()).getName();
					userEmailId = userInfoMap.get(soeId.toUpperCase()).getEmail();
				}
				symphonyGroupId = qmaCache.getGroupCodeToIdMap().get(symphonyGroup.toUpperCase());
				addSymphonyInquiry(soeId, inquiry, crtDate, chatroomName, userName, userEmailId);
				addSymphonyWorkflow(soeId,symphonyGroupId, inquiry, crtDate);
				addSymphonyWorkflowAudit(inquiry, crtDate, userName, symphonyGroupId, "Symphony chatroom created outside QMA", "External");
				logger.info(streamId+" checking again for isChatroomIncludedInQma");
				boolean status = isChatroomIncludedInQma(streamId);//to double check if mapping exists
				if(!status) {
					Key<Inquiry> inquiryKey = mongoDatastore.save(inquiry);
					long inquiryId = (long) inquiryKey.getId();
					inquiryCommonDAO.saveInquiryToPublish(inquiryId, inquiry.getAction(), soeId);
				}
				
			}
		} catch (CommunicatorException e) {
			logger.error("Exception in createInquiryStreamMapping for soeId="+soeId+" and streamId="+streamId,e);
		}
		return inquiry;
	}
	
	private boolean isChatroomIncludedInQma(String streamId) {
		try {
			symphonyLogger.info("Inside isChatroomIncludedInQma for streamId : "+ streamId);
			Long symphonyGroupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(symphonyGroup.toUpperCase());
			Query<Inquiry> query = mongoDatastore.createQuery(Inquiry.class).filter("workflows.direction", "IN")
					.filter("workflows.assignedGroupId",symphonyGroupId).filter("symphonyStreamId",streamId);
			Inquiry inquiry = query.first();
			if(null != inquiry) {
				symphonyLogger.info(streamId + " mapping is already available");
				return true;
				
			}
		} catch (Exception e) {
			symphonyLogger.error("Exception occurred in isChatroomIncludedInQma for streamId :" + streamId, e);
		}
		symphonyLogger.info(streamId + " mapping is not available");
		return false;
	}

	/**
	 * @param allQmaUsers
	 * @param streamId
	 * @param soeId
	 * @param logger
	 * @param inquiry
	 * @param action
	 * @param currentDate
	 * @param updateInquiryObj
	 * @param symphonyGroupId
	 * @throws CommunicatorException
	 */
	private void updateInquiryStreamMapping(List<String> allQmaUsers, String streamId, String soeId, Logger logger,
			Inquiry inquiry, String action, Date currentDate, DBObject updateInquiryObj, Long symphonyGroupId)
			 {
		logger.info("Inside updateInquiryStreamMapping for streamId="+streamId);
		try {
			List<String> symphonyChatroomMemberList = inquiry.getSymphonyChatRoomMember();
			List<String> memberActionList = new ArrayList<>();
			if(null != allQmaUsers && null != symphonyChatroomMemberList) {
				if(symphonyChatroomMemberList.size() < allQmaUsers.size()) {
					for(String qmaUser : allQmaUsers) {
						if(!symphonyChatroomMemberList.contains(qmaUser)) {
							memberActionList.add(qmaUser);
						}
					}
					logger.info("new member to be added");
					action = "add";
				} else if(symphonyChatroomMemberList.size() > allQmaUsers.size()) {
					for(String qmaUser : symphonyChatroomMemberList) {
						if(!allQmaUsers.contains(qmaUser)) {
							memberActionList.add(qmaUser);
						}
					}
					logger.info("existing member to be removed");
					action = "remove";
				} else {
					logger.info("no update in member list");
				}
				
				updateInquiryObj.put("symphonyChatRoomMember", allQmaUsers);
			}
			if(null == symphonyChatroomMemberList) {
				symphonyChatroomMemberList = new ArrayList<>();
				symphonyChatroomMemberList.addAll(allQmaUsers);
				updateInquiryObj.put("symphonyChatRoomMember", allQmaUsers);
				memberActionList.addAll(allQmaUsers);
			}
			String inquiryAction = "message notification";
			
			String userName = "";
			String userEmailId = "";
			Map<String, User> userMap = QMACacheFactory.getCache().getUserInfoMap();
			if(StringUtils.isNotBlank(soeId) && null != userMap) {
				userName = userMap.get(soeId.toUpperCase()).getName();
				userEmailId = userMap.get(soeId.toUpperCase()).getEmail();
			}
			
			DBObject workflowAudit = new BasicDBObject();
			boolean isWorkflowAuditUpdateRequired = false;
			String inquiryActionDesc = null;
			if("add".equalsIgnoreCase(action)) {
				inquiryAction = "add member";
				inquiryActionDesc = "Member added to Symphony chatroom: "+memberActionList.toString();
				isWorkflowAuditUpdateRequired = true;
			} else if("remove".equalsIgnoreCase(action)) {
				inquiryAction = "remove member";
				inquiryActionDesc = "Member removed from Symphony chatroom: "+memberActionList.toString();
				isWorkflowAuditUpdateRequired = true;
			}
			workflowAudit.put("UserId",userName);
			workflowAudit.put("action",inquiryActionDesc);
			workflowAudit.put("actionDetails","Notification");
			workflowAudit.put("modBy",userName);
			workflowAudit.put("modDate",currentDate);
			workflowAudit.put("groupName",symphonyGroup);
			DBCollection inquiryCollection = mongoDatastore.getCollection(Inquiry.class);
			BulkWriteOperation bulkInquiryUpdOp = inquiryCollection.initializeOrderedBulkOperation();
			DBObject findINQuery = new BasicDBObject();
			findINQuery.put("_id", inquiry.getId());
			BasicDBObject workflowCriteria = new BasicDBObject();
			workflowCriteria.put("assignedGroupId", symphonyGroupId);
			findINQuery.put("workflows", new BasicDBObject("$elemMatch", workflowCriteria));
			
			updateInquiryObj.put("action", inquiryAction);
			updateInquiryObj.put("modBy", soeId);
			updateInquiryObj.put("modDate", currentDate);
			updateInquiryObj.put("latestUserName", userName);
			updateInquiryObj.put("latestEmail", userEmailId);
			
			updateInquiryObj.put("workflows.$.modBy", soeId);
			updateInquiryObj.put("workflows.$.modDate", currentDate);
			updateInquiryObj.put("workflows.$.action", inquiryAction);
			
			
			DBObject updateDBFields = new BasicDBObject();
			updateDBFields.put("$set", updateInquiryObj);
			if(isWorkflowAuditUpdateRequired) {
				updateDBFields.put("$push", new BasicDBObject("workflowAudit", workflowAudit));
			}
			bulkInquiryUpdOp.find(findINQuery).update(updateDBFields);
			bulkInquiryUpdOp.execute();
			logger.info("updated member for streamId="+streamId);
			inquiryCommonDAO.saveInquiryToPublish(inquiry.getId(), inquiry.getAction(), soeId);
			logger.info("pushed for notification streamId="+streamId);
		} catch (CommunicatorException e) {
			logger.error("Exception in updateInquiryStreamMapping for streamId="+streamId);
		}
	}

	/**
	 * @param streamId
	 * @param soeId
	 * @param httpClient 
	 */
	private BasicDBObject getSymphonyStreamInfo(String streamId, String soeId, HttpClient httpClient) {
		BasicDBObject responseObj = null;
		String symphonyChatroomInfoUrl = getSymphonyStreamInfoUrl(streamId);
		HttpGet getRequest = new HttpGet(symphonyChatroomInfoUrl);
		addHeaderToGetRequest(getRequest);
		HttpResponse response = null;
		try {
			response = httpClient.execute(getRequest);
		} catch (Exception e) {
			symphonyLogger.error(streamId+" getSymphonyStreamInfo while executing httpClient for soeId=" + soeId, e);
		}
		symphonyLogger.info(streamId+" streamifo list api response: ", (null == response ? response :response.toString())); //<-- sonar fix null pointer
		StringBuilder content = new StringBuilder();
		if (null != response && response.getStatusLine().getStatusCode() == 200) {
			HttpEntity entity = response.getEntity();
			content = extractSearchResponse(entity);
			symphonyLogger.info(streamId+" stream info api Content: "+content.toString());
			responseObj = processResponse(content.toString(), soeId);
		} else {
			symphonyLogger.info(streamId+" getSymphonyStreamInfo Symphony call response code is not 200 while getting symphony chatroom for soeId=" + soeId);
		}
		return responseObj;
	}
	
	private void addHeaderToGetRequest(HttpGet getRequest) {
		String jwt = com.citi.icg.qma.common.server.dao.util.JwtUtil.getInstance().getJwt(symphonyBotName);
		getRequest.addHeader("Authorization", "Bearer " + jwt);
		getRequest.addHeader("bot_name", symphonyBotName);
		getRequest.addHeader("Content-Type", "application/json");
	}

	public boolean isSymphonyNotificationEnabled(Logger subLogger) {
		subLogger.info("Symphony:: inside isSymphonyNotificationEnabled start");
		boolean flag = false;
		try {
			if (null != QMACacheFactory.getCache().getConfigById("symphonyConfig")) {
				Map<String, Object> symphonyConfig = QMACacheFactory.getCache().getConfigById("symphonyConfig").getSymphonyConfig();
				if ( null != symphonyConfig && null != symphonyConfig.get("symphonyEnabled") && null != symphonyConfig.get("isWebsocketNotificationEnabled")) {
					flag = (boolean)symphonyConfig.get("symphonyEnabled") && (boolean) symphonyConfig.get("isWebsocketNotificationEnabled");
				}
			}
		} catch (Exception e) {
			subLogger.error("Symphony:: Excpetion in isWebsocketNotificationEnabled", e);
		}
		subLogger.info("Symphony:: inside isSymphonyNotificationEnabled ends :" + flag);
		return flag;
	}
	
	public boolean isSymphonyEnabled(Logger subLogger) {
		subLogger.info("Symphony:: inside isSymphonyEnabled start");
		boolean flag = false;
		try {
			if ( null != QMACacheFactory.getCache().getConfigById("symphonyConfig")) {
				Map<String, Object> symphonyConfig = QMACacheFactory.getCache().getConfigById("symphonyConfig").getSymphonyConfig();
				if ( null != symphonyConfig && null != symphonyConfig.get("symphonyEnabled")) {
					flag = (boolean)symphonyConfig.get("symphonyEnabled");
				}
			}
		} catch (Exception e) {
			subLogger.error("Symphony:: Excpetion in isSymphonyEnabled", e);
		}
		subLogger.info("Symphony:: inside isSymphonyEnabled ends :" + flag);
		return flag;
	}

	public Inquiry getInquiryDetails(String soeId, Long inquiryId) { 
		Inquiry inq = null;
		try {
			if(null != inquiryId) {
				inq = inquiryDao.getInquiryById(inquiryId);
				if(null == inq) {
					symphonyLogger.info("no details found in db for inquiry id: "+inquiryId+" for soeId: "+soeId);
				}
			} else {
				symphonyLogger.info("inquiry id is null for soeId: "+soeId);
			}
			
		} catch (Exception e) {
			symphonyLogger.error("Symphony:: Exception in getInquiryDetails", e);
		}
		return inq;
	}
	
}