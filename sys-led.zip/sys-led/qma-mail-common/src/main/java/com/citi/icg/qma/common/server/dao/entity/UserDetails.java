package com.citi.icg.qma.common.server.dao.entity;

import java.io.Serializable;

public class UserDetails implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5633300498271126228L;
	private String id;
	private String lastName;
	private String firstName;
	private String email;
	private Boolean active;
	private String role;
	private String groupId;
	private String crtDate;
	private String crtBy;
    private String pipeWithQuotes = "\"|\"";
    
    private Boolean outOfOffice;
    private String mgrName;
    private String mgrPhone;
    private String mgrEmail;
    private String phone;
    private String department;
    private String country;
    private String hasSignature;
    private String hasNewMsgSign;
    private String hasResponseMsgSign;
    private String symphonyEnabled;
    private String managementSegmentL5;
    private String managementSegmentL6;
    private String managementSegmentL7;
    private String peopleHierarchyL5;
	private String peopleHierarchyL6;
	private String peopleHierarchyL7;
	private String gdActive;
	/**
	 * @return the id
	 */
	public String getId()
	{
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id)
	{
		this.id = id;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName()
	{
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName()
	{
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	/**
	 * @return the email
	 */
	public String getEmail()
	{
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email)
	{
		this.email = email;
	}

	/**
	 * @return the active
	 */
	public Boolean getActive()
	{
		return active;
	}

	/**
	 * @param active
	 *            the active to set
	 */
	public void setActive(Boolean active)
	{
		this.active = active;
	}

	/**
	 * @return the role
	 */
	public String getRole()
	{
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(String role)
	{
		this.role = role;
	}

	
	/**
	 * @return the groupId
	 */
	public String getGroupId()
	{
		return groupId;
	}

	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(String groupId)
	{
		this.groupId = groupId;
	}

	public String getHasSignature() {
		return hasSignature;
	}

	public void setHasSignature(String hasSignature) {
		this.hasSignature = hasSignature;
	}

	public String getHasNewMsgSign() {
		return hasNewMsgSign;
	}

	public void setHasNewMsgSign(String hasNewMsgSign) {
		this.hasNewMsgSign = hasNewMsgSign;
	}

	public String getHasResponseMsgSign() {
		return hasResponseMsgSign;
	}

	public void setHasResponseMsgSign(String hasResponseMsgSign) {
		this.hasResponseMsgSign = hasResponseMsgSign;
	}

	public String getSymphonyEnabled() {
		return symphonyEnabled;
	}

	public void setSymphonyEnabled(String symphonyEnabled) {
		this.symphonyEnabled = symphonyEnabled;
	}

	public String getManagementSegmentL6() {
		return managementSegmentL6;
	}

	public void setManagementSegmentL6(String managementSegmentL6) {
		this.managementSegmentL6 = managementSegmentL6;
	}

	public String getManagementSegmentL5() {
		return managementSegmentL5;
	}

	public void setManagementSegmentL5(String managementSegmentL5) {
		this.managementSegmentL5 = managementSegmentL5;
	}

	public String getManagementSegmentL7() {
		return managementSegmentL7;
	}

	public void setManagementSegmentL7(String managementSegmentL7) {
		this.managementSegmentL7 = managementSegmentL7;
	}

	public String getPeopleHierarchyL5() {
		return peopleHierarchyL5;
	}

	public void setPeopleHierarchyL5(String peopleHierarchyL5) {
		this.peopleHierarchyL5 = peopleHierarchyL5;
	}

	public String getPeopleHierarchyL6() {
		return peopleHierarchyL6;
	}

	public void setPeopleHierarchyL6(String peopleHierarchyL6) {
		this.peopleHierarchyL6 = peopleHierarchyL6;
	}

	public String getPeopleHierarchyL7() {
		return peopleHierarchyL7;
	}

	public void setPeopleHierarchyL7(String peopleHierarchyL7) {
		this.peopleHierarchyL7 = peopleHierarchyL7;
	}

	public String isGdActive() {
		return gdActive;
	}

	public void setGdActive(String gdActive) {
		this.gdActive = gdActive;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return "\"" + id + pipeWithQuotes + lastName + pipeWithQuotes + firstName + pipeWithQuotes + email + "\"|" + crtDate + "|\"" + crtBy + 
		        pipeWithQuotes + active + pipeWithQuotes  +role + pipeWithQuotes + groupId + pipeWithQuotes + outOfOffice + pipeWithQuotes + 
		        department + pipeWithQuotes + phone + pipeWithQuotes + country + pipeWithQuotes + 
		        mgrName + pipeWithQuotes +  mgrEmail + pipeWithQuotes +  mgrPhone 
		        + pipeWithQuotes + hasSignature + pipeWithQuotes + hasNewMsgSign + pipeWithQuotes + hasResponseMsgSign + pipeWithQuotes + symphonyEnabled + pipeWithQuotes + managementSegmentL5+ pipeWithQuotes + managementSegmentL6+ pipeWithQuotes + managementSegmentL7 
		        + pipeWithQuotes + peopleHierarchyL5 + pipeWithQuotes + peopleHierarchyL6 + pipeWithQuotes + peopleHierarchyL7 + pipeWithQuotes + gdActive +"\"";
	}

	/**
	 * @param appId
	 * @param id
	 * @param lastName
	 * @param firstName
	 * @param email
	 * @param active
	 * @param role
	 * @param groupId
	 */
	public UserDetails(String id, String lastName, String firstName, String email, String crtDate, String crtBy, Boolean active, String role, String groupId,
	        Boolean outOfOffice, String department, String phone, String country,String mgrName,String mgrPhone, String mgrEmail, String hasSignature, String hasNewMsgSign, String hasResponseMsgSign, String symphonyEnabled, String managementSegmentL5, String managementSegmentL6, String managementSegmentL7
	        , String peopleHierarchyL5, String peopleHierarchyL6, String peopleHierarchyL7, String gdActive)
	{
		super();
		this.id = id == null ? "" : id;
		this.lastName = lastName == null ? "" : lastName;
		this.firstName = firstName == null ? "" : firstName;
		this.email = email == null ? "" : email;
		this.active = active;
		this.role = role== null ? "" : role;
		this.groupId = groupId== null ? "" : groupId;
		this.crtDate = crtDate;
		this.crtBy = crtBy;		
		this.outOfOffice = outOfOffice;
        this.department = department;
		this.phone = phone;        
        this.country = country;
        this.mgrName = mgrName;  
        this.mgrEmail = mgrEmail;
        this.mgrPhone = mgrPhone;
        this.hasSignature = hasSignature;
        this.hasNewMsgSign = hasNewMsgSign;
        this.hasResponseMsgSign = hasResponseMsgSign;
        this.symphonyEnabled = symphonyEnabled;
        this.managementSegmentL5 = managementSegmentL5;
        this.managementSegmentL6 = managementSegmentL6;
        this.managementSegmentL7 = managementSegmentL7;
        this.peopleHierarchyL5 = peopleHierarchyL5;
        this.peopleHierarchyL6 = peopleHierarchyL6;
        this.peopleHierarchyL7 = peopleHierarchyL7;
        this.gdActive = gdActive;
	}

}
