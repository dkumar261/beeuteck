package com.citi.icg.qma.common.core.subscriber.mails;

public enum InquiryAction
{
	ORIGINATION,
	CITIRESPONSE,
	CLIENTRESPONSE
}
