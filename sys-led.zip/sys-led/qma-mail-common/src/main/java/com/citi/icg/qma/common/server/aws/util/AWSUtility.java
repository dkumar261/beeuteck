package com.citi.icg.qma.common.server.aws.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ListObjectsV2Request;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.citi.icg.qma.common.core.util.MailCommonUtil;
import com.citi.icg.qma.common.server.util.GenericUtility;


/**
 * Upload a file to an Amazon S3 bucket.
 *
 * This code expects that you have AWS credentials set up per: http://docs.aws.amazon.com/java-sdk/latest/developer-guide/setup-credentials.html
 */
public class AWSUtility
{

	private  String bucketName = null;
	private  String accessKeyName = null;
	private  String secretKeyName = null;
	private  String endPoint = null;
	private  String endPointRegion = null;

	private static final Logger logger = LoggerFactory.getLogger(AWSUtility.class);

	public static void main(String[] args) throws Exception
	{
		AWSUtility util = new AWSUtility();
		
		
		util.readObject(util.getConnection(), "XXXXX", "myfile1.pdf");
	}
	
	
	public AWSUtility()
	{
		String xmcEnvironment = System.getProperty("icg.env");
		String propFile = "aws-" + xmcEnvironment + ".properties";
		logger.info(" Loading properties for " + xmcEnvironment + "file name is" + propFile);
		InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(propFile);
		Properties prop = new Properties();

		try
		{
			prop.load(inputStream);
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
		    logger.warn("Exception in AWSUtility", e);
			// sendEmail // ITRS
		}
		this.bucketName = prop.getProperty("bucketName");
		this.accessKeyName = prop.getProperty("accessKeyName");
		this.secretKeyName = prop.getProperty("secretKeyName");
		this.endPoint = prop.getProperty("endPoint");
		this.endPointRegion = prop.getProperty("endPointRegion");
	}
	
	

	

	public AWSUtility(String bucketName, String accessKeyName, String secretKeyName, String endPoint,
			String endPointRegion) {
		this.bucketName = bucketName;
		this.accessKeyName = accessKeyName;
		this.secretKeyName = secretKeyName;
		this.endPoint = endPoint;
		this.endPointRegion = endPointRegion;
	}


	public AmazonS3 getConnection()
	{
		AmazonS3 s3Client = null;
		try
		{
			EndpointConfiguration endpointConfiguration = new EndpointConfiguration(endPoint, endPointRegion);
			

			BasicAWSCredentials awsCreds = new BasicAWSCredentials(accessKeyName, secretKeyName);
			s3Client = AmazonS3ClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(awsCreds))
					.withEndpointConfiguration(endpointConfiguration).withPathStyleAccessEnabled(true)
					.build();

		}
		catch (Exception e)
		{
		    logger.warn("Exception in getting AmazonS3 Connection", e);
		}
		return s3Client;
	}

	public void getBucketSummary(AmazonS3 s3Client)
	{

		//ObjectListing objects = listObjects(bucketName,prefix);
		ListObjectsV2Result result = s3Client.listObjectsV2(bucketName);
		List<S3ObjectSummary> objects = result.getObjectSummaries();
	//	System.out.println("size is" + objects.size() + "  result" + result.getMaxKeys());
		for (S3ObjectSummary os : objects)
		{
			//System.out.println(os.toString());
			logger.info("Keys is" + os.getKey());
		}
		
	}
	
	public void getBucketSummary2(AmazonS3 s3Client) throws IOException {
       
        try {
          
            final ListObjectsV2Request req = new ListObjectsV2Request().withBucketName(bucketName).withMaxKeys(2);
            ListObjectsV2Result result;
            do {               
               result = s3Client.listObjectsV2(req);
               
               for (S3ObjectSummary objectSummary : 
                   result.getObjectSummaries()) {
                  
               }
              
               req.setContinuationToken(result.getNextContinuationToken());
            } while(result.isTruncated() == true ); 
            
         } catch (Exception ase) {
        	 logger.error("Issue is",ase);
          
         }
    }

	
	

	public void writeObject(AmazonS3 s3Client, String fileId, File file)
	{
		//try
		//{
			s3Client.putObject(new PutObjectRequest(bucketName, fileId, file));
		//}
		//catch (Exception e)
		//{
		//	return false;
		//}

		//return true;
	}
	public boolean writeObject_donotuse(AmazonS3 s3Client, String fileId, File file)
	{
		try
		{
			s3Client.putObject(new PutObjectRequest(bucketName, fileId, file));
		}
		catch (Exception e)
		{
			return false;
		}

		return true;
	}
	
	public File readObject(AmazonS3 s3Client, String fileId, String fileName) throws Exception
	{
		S3Object o = s3Client.getObject(bucketName, fileId);
		//System.out.println("metadata is " + o.getObjectMetadata().getContentType());

		return writeFile(o,fileId, fileName);

	}

	public String readObject(AmazonS3 s3Client, String fileId) throws Exception
	{
		S3Object s3Obj = s3Client.getObject(bucketName, fileId);
		logger.info("***Content" + s3Obj.getObjectContent());
		String strObj = s3Client.getObjectAsString(bucketName, fileId);
		logger.info("***S3 data in String **** " + strObj);
		
		return strObj;
	}

	public boolean isObjectExistsInS3(AmazonS3 s3Client, String fileId) throws Exception
	{
		boolean isObjectExistsInS3 = false;
		try {
			S3Object o = s3Client.getObject(bucketName, fileId);
			if(null!= o && null != o.getObjectMetadata() && null != o.getObjectMetadata().getUserMetadata() 
					&& o.getObjectMetadata().getUserMetadata().size() > 0) {
				isObjectExistsInS3 = true;
				logger.info("File exists in S3 Store with id : {} ", fileId);
			}
			if(!isObjectExistsInS3) {
				logger.info("File does not exists in S3 Store with id : {} ", fileId);
			}
		} catch (Exception e) {
			logger.error("Exception while validating file Object in S3 Store for id : {} : ", fileId, e);
		}
		return isObjectExistsInS3;
	}

	private File writeFile(S3Object o, String fileId, String fileName) throws Exception
	{
		//logger.info(o.getObjectMetadata());
		String fileNameWithPath=fileName;
		
		if(StringUtils.isNotBlank(fileName) && !GenericUtility.isValidFileName(fileName)) {
			fileName = GenericUtility.sanitizeFileName(fileName);
		}
		String defaultFileCreationFolder=System.getProperty("defaultfilepath");
		
		if(StringUtils.isNotBlank(defaultFileCreationFolder)){
			fileNameWithPath=defaultFileCreationFolder+fileId +"_"+ fileName;
		}
		
		File file= null;
		//[C170665-1723] - SBT Path Traversal Issue Fixing
		if(GenericUtility.isValidPathForFileRead(fileNameWithPath)) {
			file = new File(fileNameWithPath);
		} else {
			logger.error("Error while validating path: {}",fileNameWithPath);
		}
		
		S3ObjectInputStream s3is = o.getObjectContent();
		FileOutputStream fos = new FileOutputStream(file);
		try {
	        byte[] read_buf = new byte[1024];
	        int read_len = 0;
			 while ((read_len = s3is.read(read_buf)) > 0)
	        {
	            fos.write(read_buf, 0, read_len);
	        }
		}
		finally{	        	
	        fos.close();      	
	        s3is.close();
		}
		return file;
	}
	
	//Trial only
	public boolean writeObjectWithMetadata(AmazonS3 s3Client, String fileId, File file)
	{
		try
		{
			Map<String, String> metaList = new HashMap<>();
		    metaList.put("x-amz-meta-example", "true"); 
		    metaList.put("name", "myfile222.csv");

		    ObjectMetadata medata = new ObjectMetadata(); 
		    medata.setUserMetadata(metaList); 
			String checksumMD5 = MailCommonUtil.calculateChecksum(file);
		    medata.setContentMD5(checksumMD5);
		   // medata.set
		    
			//s3Client.putObject(new PutObjectRequest(bucketName, fileId, file)).setMetadata(medata);
		    s3Client.putObject(new PutObjectRequest(bucketName, fileId, new FileInputStream (file), medata));
		    logger.info("writing done");
		}
		catch (Exception e)
		{
			logger.info(e.getMessage(), e);
			//e.printStackTrace();
			return false;
		}

		return true;
	}
	
	public boolean writeStringObject(AmazonS3 s3Client, String fileId,String content, Long inquiryId, Long conversationId) {
		try {
			Map<String, String> metaList = new HashMap<>();
		    metaList.put("inquiryId", inquiryId+""); 
		    metaList.put("conversationId", conversationId+"");
			byte[] contentBytes = content.getBytes(Charset.forName("UTF-8"));
			InputStream is = new ByteArrayInputStream(contentBytes);
			ObjectMetadata metadata = new ObjectMetadata();
	        metadata.setUserMetadata(metaList);
	        metadata.setContentMD5(new String(com.amazonaws.util.Base64.encode(DigestUtils.md5(content))));
	        metadata.setContentType("text/plain");
	        metadata.setContentLength(contentBytes.length);
			s3Client.putObject(new PutObjectRequest(bucketName, fileId, is, metadata));
		}catch (Exception e)
		{
			logger.info(e.getMessage(), e);
			return false;
		}
		
		return true;
	}

	public boolean deleteObject(String fileId) {
		try {
			AmazonS3 s3Client = getConnection();
			logger.info("Delete Object from object store  - bucketName {} , objectId {}", bucketName, fileId);
			s3Client.deleteObject(bucketName, fileId);
		} catch (Exception e) {
			logger.info(e.getMessage(), e);
			return false;
		}
		return true;
	}

	public boolean writeIndividualObject(AmazonS3 s3Client, String fileId, File file, String bucketName) {
		try {
			s3Client.putObject(new PutObjectRequest(bucketName, fileId, file));
		} catch (Exception e) {
			logger.error("Error while writting individual file on s3:",e);
			return false;
		}
		return true;
	}

	public boolean isIndividualObjectExistsInS3(AmazonS3 s3Client, String fileId, String bucketName) throws Exception
	{
		boolean isObjectExistsInS3 = false;
		try {		
			if(s3Client.doesObjectExist(bucketName, fileId)) {
				//writeFile(s3Client.getObject(bucketName, fileId), fileId, fileId);
				isObjectExistsInS3 = true;
			}else {
				logger.info("File does not exists in S3 Store with id : {} ", fileId);
			}
		} catch (Exception e) {
			logger.error("Exception while validating file Object in S3 Store for id : {} : ", fileId, e);
		}
		return isObjectExistsInS3;
	}
	
	public String getBucketName() {
		return bucketName;
	}


	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}


	public String getEndPointRegion() {
		return endPointRegion;
	}


	public void setEndPointRegion(String endPointRegion) {
		this.endPointRegion = endPointRegion;
	}
	
	

}
