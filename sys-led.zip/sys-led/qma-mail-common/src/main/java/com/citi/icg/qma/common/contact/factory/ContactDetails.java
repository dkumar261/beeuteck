package com.citi.icg.qma.common.contact.factory;

import java.util.List;

import com.citi.icg.qma.common.contact.exception.UnauthorizedException;
import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.persistence.QMAContact;
import com.mongodb.BasicDBObject;

public interface ContactDetails {

	public List<QMAContact> getSearchContactDetails(String soeId, BasicDBObject request, BasicDBObject outputBuilderObj)
			throws CommunicatorException, UnauthorizedException;
}
