package com.citi.icg.qma.common.core.transformer;

import java.util.HashMap;

import org.apache.commons.collections4.Transformer;
import org.slf4j.Logger;


/*
 * 
 * Neal Page: Cab! Cab!
 * Neal Page: Sir?
 * Neal Page: Sir? Sir?
 * Neal Page: Excuse me.
 * Neal Page: Could I appeal to your good nature and ask you for your cab?
 * Man getting into the cab : I don't have a good nature. Excuse me.
 * NP: Come on!
 * NP: Could I offer you $10 ?
 * NP: I'll give you $20 .
 * Man: I'll take  50.
 * NP: All right.
 * Man: Anyone who would pay $50  for a cab would certainly pay $75 .
 * NP: Not necessarily.
 * NP: All right,  75 .
 * NP: You're a thief.
 * Man: Close. I'm an attorney.
 */
public class TransformationManager
{
	private static TransformationManager self;

	private HashMap<String, Transformer> transformNameMap = new HashMap<>();

	public static synchronized TransformationManager getInstance()//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
	{
		if (self == null) {
			self = new TransformationManager();
		}
		return self;
	}

	public <T> T transform(String transformerClassName, Object object) throws TransformationExcept
	{

		T transformedObject = null;

		if ("NONE".equalsIgnoreCase(transformerClassName))
		{
			transformedObject = (T) object;
		}
		else
		{
			Transformer transformer = transformNameMap.get(transformerClassName);

			try
			{
				if (transformer == null)
				{
					transformer = (Transformer) Class.forName(transformerClassName).newInstance();

					transformNameMap.put(transformerClassName, transformer);

				}
			}
			catch (Exception e)
			{
				throw new TransformationExcept("Could not create a Transformer.", e);
			}
			
			transformedObject = (T) transformer.transform(object);

		}
		return transformedObject;

	}
}
