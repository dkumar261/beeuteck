package com.citi.icg.qma.common.server.dao.persistence.oasys.payments;

public class OasysPaymentStatus {

	private String paymentId;
	private Boolean status;
	private String comment;

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

}
