package com.citi.icg.qma.common.server.dao.persistence;

import java.util.List;
import java.util.UUID;

import com.mongodb.*;
import org.apache.commons.lang.StringUtils;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.subscriber.mails.MailConstants;
import com.citi.icg.qma.common.core.util.EmailUtil;
import com.citi.icg.qma.common.core.util.GenericUtil;
import com.citi.icg.qma.common.server.dao.AppUsers;
import com.citi.icg.qma.common.server.dao.BaseEntity;
import com.citi.icg.qma.exception.NonRecoverableDBException;

import dev.morphia.Datastore;
import dev.morphia.Key;
import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;
import dev.morphia.query.UpdateResults;

/**
 * The generic Persistence implementation, showing how to do persists/get/count/clera, various can be added...
 */
public class MongoMorphiaDAO implements IGenericBeanDAO
{
	private static Logger logger = LoggerFactory.getLogger(MongoMorphiaDAO.class);
	public final Datastore mongoDatastore;
	private static String supportEmail = "XXXX";
	public MongoMorphiaDAO()
	{
		mongoDatastore = MongoDB.instance().getDataStore();
	}

	public MongoMorphiaDAO(Datastore datastore) {
		mongoDatastore = datastore;
	}


	@Override
	public <E extends BaseEntity> E get(Class<E> clazz, final ObjectId id)
	{
		if ((clazz == null) || (id == null))
		{
			return null;
		}

		return mongoDatastore.find(clazz).field("id").equal(id).get();
	}

	@Override
	public <E extends BaseEntity> Long persist(E entity)
	{
		mongoDatastore.save(entity);
		return entity.getId();
	}

	@Override
	public <E extends BaseEntity> Long count(Class<E> clazz)
	{
		if (clazz == null)
		{
			return 0L;
		}

		return mongoDatastore.find(clazz).countAll();
	}

	@Override
	public <E extends BaseEntity> E clear(Class<E> clazz)
	{
		mongoDatastore.delete(mongoDatastore.createQuery(clazz));

		return null;
	}
	
	@Override
	public List<AppUsers> getAllAppUsers(Class clazz)
	{
		return mongoDatastore.find(clazz).asList();
	}
	@Override
	public void close()
	{

		mongoDatastore.getMongo().close();
	}

	public Datastore getMongoDatastore()
	{
		return mongoDatastore;
	}
	
	public <E extends BaseEntity> E get(Class<E> clazz, String fieldName, final String fieldValue) {
		if ((clazz == null) || StringUtils.isEmpty(fieldName) || StringUtils.isEmpty(fieldValue)) {
			return null;
		}
		Object fieldValueObj = fieldValue;
		if(fieldName.equals("_id")) {
			fieldValueObj = Long.valueOf(fieldValue);
		}
		return mongoDatastore.find(clazz).field(fieldName).equal(fieldValueObj).get();
	}
	
	
    public static <T> Key<T> saveWithRetry(Datastore datastore, final T entity) throws NonRecoverableDBException  {
        int retryCount = 0;
		do {
			try {
				return datastore.save(entity);				
			} catch (MongoException e) {
				UUID operationId = UUID.randomUUID();
				if (retryCount==0) {
					logger.error("MongoDB exception occurred [OperationID="+operationId+"][QmaMongoRetryCount="+retryCount+"] ", e);
				} else {
					logger.warn("Exception occurred while retrying MongoDB operation [OperationID="+operationId+"][QmaMongoOperationRetryCount="+retryCount+"] ", e);
				}
				
				if (e instanceof MongoSocketException || e instanceof MongoServerException || (e.getCause() != null && e.getCause().toString().contains("com.mongodb.MongoException$Network"))) {
					try {
						Thread.sleep(MailConstants.MONGO_RETRY_WAIT_INTERVAL_IN_MS);
					} catch (InterruptedException e1) {
						String msg = "Thread got interrupted while waiting(sleeping) before next retry of MongDB operation [OperationID="+operationId+"]";
						logger.error(msg);
						throw new NonRecoverableDBException(msg, e);
					}
					retryCount++;					
					if (retryCount > MailConstants.MONGO_RETRY_MAX_COUNT) {
						String msg = "Could not recover from MongoDB failure even after max retries["+MailConstants.MONGO_RETRY_MAX_COUNT+"] for operation [OperationID="+operationId+"]";
						logger.error(msg);
						throw new NonRecoverableDBException(msg, e);
					}
				} else {
					logger.warn("No retry will be attempted for this exception");
					throw e;
				}
			}
		} while (true);		
    } 
    
    
    public static <T> UpdateResults updateWithRetry(Datastore datastore, final Query<T> query, final UpdateOperations<T> ops, final boolean createIfMissing) throws NonRecoverableDBException {
    	int retryCount = 0;
		do {
			try {
				return datastore.update(query, ops, createIfMissing);				
			} catch (MongoException e) {
				UUID operationId = UUID.randomUUID();
				if (retryCount==0) {
					logger.error("MongoDB exception occurred [OperationID="+operationId+"][QmaMongoRetryCount="+retryCount+"] ", e);
				} else {
					logger.warn("Exception occurred while retrying MongoDB operation [OperationID="+operationId+"][QmaMongoOperationRetryCount="+retryCount+"] ", e);
				}
				
				if (e instanceof MongoSocketException || e instanceof MongoServerException || (e.getCause() != null && e.getCause().toString().contains("com.mongodb.MongoException$Network"))) {
					try {
						Thread.sleep(MailConstants.MONGO_RETRY_WAIT_INTERVAL_IN_MS);
					} catch (InterruptedException e1) {
						String msg = "Thread got interrupted while waiting(sleeping) before next retry of MongDB operation [OperationID="+operationId+"]";
						logger.error(msg);
						throw new NonRecoverableDBException(msg, e);
					}
					retryCount++;					
					if (retryCount > MailConstants.MONGO_RETRY_MAX_COUNT) {
						String msg = "Could not recover from MongoDB failure even after max retries["+MailConstants.MONGO_RETRY_MAX_COUNT+"] for operation [OperationID="+operationId+"]";
						logger.error(msg);
						throw new NonRecoverableDBException(msg, e);
					}
				} else {
					logger.warn("No retry will be attempted for this exception");
					throw e;
				}
			}
		} while (true);        
    }
    public void handleCriticalException(String processName, Throwable e, boolean alwaysNotifySupport, Long retryCount)
	{
		boolean isExInstanceOf = e instanceof MongoException || e instanceof ExceptionInInitializerError || e instanceof MongoSocketException;
		if (alwaysNotifySupport || isExInstanceOf || (e.getCause() != null && e.getCause().toString().contains("com.mongodb.MongoException$Network")))
		{

			logger.error(processName + " : Unexpected exception. DB has issues [" + (isExInstanceOf || (e.getCause() != null && e.getCause().toString().contains("com.mongodb.MongoException$Network")))
					+ "], Please checkwith MongoDB Team for DB issues, once up and ready please restart the process. QMA Services are being closed", e);
			if (retryCount == 0)
			{
				EmailUtil.sendEmailToSupport(null, processName + " :", " Unexpected exception, Please do log analysis and check with application, DBA team.",
						supportEmail, e);
			}
			else
			{
				EmailUtil.sendEmailToSupport(null,processName + " :",
						" Unexpected exception, Please do log analysis and check with application, DBA team. Tried running process for " + retryCount + " times",
						supportEmail, e);
			}
			GenericUtil.stopProcess(processName, -1);
		}
	}


	public void extractDBCollection(DBCollection collection) {
		boolean iscapped = collection.isCapped();
		// Check if the collection exists, and create it if it doesn't
		if (!iscapped) {
			ensureCaps(collection.getName());
		}
	}


	private void ensureCaps(String collName) {

		if (mongoDatastore.getDB().getCollectionNames().contains(collName)) {
			// Convert the existing collection to capped
			DBObject convertToCappedCommand = new BasicDBObject("convertToCapped", collName)
					.append("size", 500000) // 500KB size
					.append("max", 5000);    // max 5000 documents
			mongoDatastore.getDB().command(convertToCappedCommand);
		} else {
			mongoDatastore.ensureCaps();
		}
	}
}
