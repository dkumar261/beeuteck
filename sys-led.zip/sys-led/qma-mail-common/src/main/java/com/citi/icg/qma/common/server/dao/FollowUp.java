package com.citi.icg.qma.common.server.dao;

public class FollowUp
{
	//[C153176-1238]-Enable 'Follow-up' functionality: Used for setting follow up flag in initial stage, later will extend this object to support additional follow features.
	private String flag;

	public String getFlag()
	{
		return flag;
	}

	public void setFlag(String flag)
	{
		this.flag = flag;
	}
	
	
}
