package com.citi.icg.qma.common.server.dao.entity;

import java.util.Date;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

/**
 * ContactClientMaping collection Entity
 *
 *
 */
@Entity(value = "ContactClientMaping", noClassnameStored = true)
public class ContactClientMaping
{
    @Id
    private String id;//email address
    private String clientName;
    private String gpNum;
    private String gpName;
    private String clientIdType;
    private String gfcId;
    private String gfcName;
    private String contactSrc;
    private String note;
    private Date modDate;
    private String clientCategory;
    /**
     * Default constructor
     */
    public ContactClientMaping()
    {
        super();
    }

    /**
     * Constructor with all fields
     */
    public ContactClientMaping(String id, String clientName, String gpNum, String gpName, String clientIdType,
                               Date modDate) {
        super();
        this.id = id;
        this.clientName = clientName;
        this.gpNum = gpNum;
        this.gpName = gpName;
        this.clientIdType = clientIdType;
        this.modDate = modDate;
    }

    public String getId()
    {
        return id;
    }
    public void setId(String id)
    {
        this.id = id;
    }
    public String getClientName()
    {
        return clientName;
    }
    public void setClientName(String clientName)
    {
        this.clientName = clientName;
    }
    public String getGpNum()
    {
        return gpNum;
    }
    public void setGpNum(String gpNum)
    {
        this.gpNum = gpNum;
    }
    public String getGpName()
    {
        return gpName;
    }
    public void setGpName(String gpName)
    {
        this.gpName = gpName;
    }

    public String getGfcId() {
        return gfcId;
    }

    public void setGfcId(String gfcId) {
        this.gfcId = gfcId;
    }

    public String getClientIdType() {
        return clientIdType;
    }

    public void setClientIdType(String clientIdType) {
        this.clientIdType = clientIdType;
    }

    public Date getModDate() {
        return modDate;
    }

    public void setModDate(Date modDate) {
        this.modDate = modDate;
    }


    public String getGfcName() {
        return gfcName;
    }

    public void setGfcName(String gfcName) {
        this.gfcName = gfcName;
    }

    public String getContactSrc() {
        return contactSrc;
    }

    public void setContactSrc(String contactSrc) {
        this.contactSrc = contactSrc;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Override
    public String toString()
    {
        return "ClientMapping [id=" + id + ", clientName=" + clientName + ", gpNum=" + gpNum + ", gpName=" + gpName + ", clientIdType=" + clientIdType+ "]";
    }

    public String getClientCategory() {
        return clientCategory;
    }

    public void setClientCategory(String clientCategory) {
        this.clientCategory = clientCategory;
    }

}