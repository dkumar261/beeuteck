package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Date;

public class GroupRole implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2419084992726170226L;
	private Long groupId;
	private String role;// This can have 3 values ANALYST,ADMIN,MAKERCHECKER REVIEWER
	private Date crtDate;
	private String crtBy;

	public GroupRole()
	{

	}

	public GroupRole(Long groupId, String role, Date crtDate, String crtBy)
	{
		super();
		this.setGroupId(groupId);
		this.role = role;
		this.crtDate = crtDate;
		this.crtBy = crtBy;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Date getCrtDate() {
		return crtDate;
	}

	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((groupId == null) ? 0 : groupId.hashCode());
		result = prime * result + ((role == null) ? 0 : role.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;
		if (obj == null)
			return false;

		GroupRole other = (GroupRole) obj;

		if (groupId == null || role == null )
			return false;

		if (other.groupId !=null &&  other.role != null  && other.groupId.equals(groupId) && other.role.equals(role)) {
			return true;
		}

		return false;
	}
}
