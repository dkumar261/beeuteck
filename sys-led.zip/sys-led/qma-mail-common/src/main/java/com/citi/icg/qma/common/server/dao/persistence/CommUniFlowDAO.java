package com.citi.icg.qma.common.server.dao.persistence;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.commons.lang.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

public class CommUniFlowDAO extends MongoMorphiaDAO {
	private static final String CUF_LOG_PATTERN = "::CUF-LOG:: ";
	private static final String TOKEN_INVALID = "false";
	private static final String X_EXTERNAL_AUTH = "X-External-Auth";
	private static final String APPLICATION_JSON = "application/json";
	private static final String CONTENT_TYPE = "Content-Type";
	private static final String X_CITIPORTAL_LOGIN_ID = "XXXXX";
	private static final String X_EXTERNAL_NAME = "X-External-Name";
	private static final String X_EXTERNAL_SECRET_KEY = "X-External-SecretKey";
	private static final String X_EXTERNAL_ID = "X-External-Id";
	private static String commUniFlowServiceEndPoint = null;
	private static String xExternalId = null;
	private static String xExternalSecretKey = null;
	private static String xExternalName = null;
	private static String xExternalCsiId = null;
	private final Logger commUniFlowLogger = LoggerFactory.getLogger(CommUniFlowDAO.class);
	private static CommUniFlowDAO instance = null;
	private static String token = null;
	private static final String TOKEN_EXPR_GEN_AGAIN ="token expired, generating again ";
	private static final String SUCCESS ="success";
	private static final String RESPONSE_INFO ="response: {}";
	private static final String MESSAGE ="message";
	private static final String COMMON_UNI_FLOW_CONFIG ="commUniFlowConfig";
	private static final String CALLING_URL_INFO ="calling url:: {}";
	private static final String X_EXTERNAL_TOKEN_STATUS ="X-External-TokenStatus";
	private static final String USER_NOT_AUTHORIZED ="User not authorised, soeId: {}";
	private static final String SERVICE_NOT_AVAILABLE ="Service not available at the moment, Please contact Support.";
	private static final String CONTENT ="Content: {}";
	public static synchronized CommUniFlowDAO getInstance()//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
	{
		if (instance == null)
				{
					initializeCommUniFlowServiceUrl();
					instance = new CommUniFlowDAO();
				}
		return instance;
	}
	
	private static void initializeCommUniFlowServiceUrl() {
		QMACache qmaCache = QMACacheFactory.getCache();
		if (null != qmaCache.getConfigById(COMMON_UNI_FLOW_CONFIG))
		{
			Config commUniFlowConfig = qmaCache.getConfigById(COMMON_UNI_FLOW_CONFIG);
			if (null != commUniFlowConfig && null != commUniFlowConfig.getCommUniFlowConfig()){
				Map<String, Object> commUniFlowConfigObj = commUniFlowConfig.getCommUniFlowConfig();
				commUniFlowServiceEndPoint = (String) commUniFlowConfigObj.get("commUniFlowServiceEndPoint");
				xExternalId = (String) commUniFlowConfigObj.get("xExternalId");
				xExternalSecretKey = (String) commUniFlowConfigObj.get("xExternalSecretKey");
				xExternalName = (String) commUniFlowConfigObj.get("xExternalName");
				xExternalCsiId = (String) commUniFlowConfigObj.get("xExternalCsiId");
				token = (String) commUniFlowConfigObj.get("token");
			}
		}
	}
	
	@SuppressWarnings("deprecation")
	private HttpClient getHttpClient() throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException {
		SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, (x509CertChain, authType) -> true)
				.build();

		HttpClient httpClient = HttpClientBuilder.create().setSslcontext(sslContext)
				.setConnectionManager(new PoolingHttpClientConnectionManager(RegistryBuilder
						.<ConnectionSocketFactory>create().register("http", PlainConnectionSocketFactory.INSTANCE)
						.register("https", new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE))
						.build()))
				.build();
		return httpClient;
	}
	
	@SuppressWarnings("deprecation")
	private void generateToken(String soeId) {
		long startTime = System.currentTimeMillis();
		String response = null;
		try {
			String requestUrl = commUniFlowServiceEndPoint+"/bmw-referencedata/bmw-reference-data/generateToken";
			commUniFlowLogger.info(CUF_LOG_PATTERN+CALLING_URL_INFO,requestUrl);
			HttpClient httpClient = getHttpClient();
			HttpGet getRequest = new HttpGet(requestUrl);
			getCommUniFlowRequestHeader(false, getRequest, soeId);
			HttpResponse symphonyResponse = null;
			try {
				symphonyResponse = httpClient.execute(getRequest);
			} catch (Exception e) {
				commUniFlowLogger.error(CUF_LOG_PATTERN+"generateToken call failed while ececuting httpClient for soeId="+soeId, e);
			}
			if ( null != symphonyResponse && symphonyResponse.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = symphonyResponse.getEntity();
				StringBuilder content = extractSearchResponse(entity);
				BasicDBObject responseObj = BasicDBObject.parse(content.toString());
				if(null != responseObj && null != responseObj.get("reponse")){
					response = responseObj.getString("reponse");
					//save in config and update cache
					saveAndRefreshToken(response, soeId);
				}
				
			} else {
				commUniFlowLogger.info(CUF_LOG_PATTERN+"generateToken call response code is not 200  for soeId={}",soeId);
			}
		} catch (Exception e) {
			commUniFlowLogger.error(CUF_LOG_PATTERN+"Exception in generateToken", e);
		}
		commUniFlowLogger.info(CUF_LOG_PATTERN+"time taken by generateToken method : {} in ms",(System.currentTimeMillis()-startTime));
	}
	
	public boolean saveAndRefreshToken(String tokenResponse, String soeId){
		boolean flag = false;
		try {
			token = tokenResponse;
			commUniFlowLogger.info(CUF_LOG_PATTERN+"Inside saveAndRefreshToken for userId= {}", soeId);
			Query<Config> query = mongoDatastore.createQuery(Config.class).filter("_id", COMMON_UNI_FLOW_CONFIG);
			UpdateOperations<Config> ops = mongoDatastore.createUpdateOperations(Config.class);
			ops.set("commUniFlowConfig.token", token);
			mongoDatastore.update(query, ops);
			commUniFlowLogger.info(CUF_LOG_PATTERN+"Inside saveAndRefreshToken refreshing token for userId= {}", soeId);
			if (null != QMACacheFactory.getCache().getConfigById(COMMON_UNI_FLOW_CONFIG))
			{
				Config commUniFlowConfig = QMACacheFactory.getCache().getConfigById(COMMON_UNI_FLOW_CONFIG);
				if (null != commUniFlowConfig && null != commUniFlowConfig.getCommUniFlowConfig()){
					Map<String, Object> commUniFlowConfigObj = commUniFlowConfig.getCommUniFlowConfig();
					commUniFlowConfigObj.put("token", token);
					flag = true;
				}
			}
		} catch (Exception e) {
			commUniFlowLogger.error(CUF_LOG_PATTERN+"Exception occurred in saveAndRefreshToken for soeId :"+ soeId,e);
		}
		return flag;
	}
	
	private StringBuilder extractSearchResponse(HttpEntity entity) {
		StringBuilder content = new StringBuilder();
		byte[] buffer = new byte[1024];
		if (entity != null) {
			InputStream inputStream = null;
			try {
				inputStream = entity.getContent();
			} catch (Exception e1) {
				commUniFlowLogger.error(CUF_LOG_PATTERN+" Error in extractSearchResponse() :", e1);
			}
			try (BufferedInputStream bis = new BufferedInputStream(inputStream)) {
				int bytesRead = 0;
				while ((bytesRead = bis.read(buffer)) != -1) {
					String chunk = new String(buffer, 0, bytesRead);
					content.append(chunk);
				}
			} catch (Exception e) {
				commUniFlowLogger.error(CUF_LOG_PATTERN+" Error in extractSearchResponse() :", e);
			}
		}
		return content;
	}
	
	
	private void getCommUniFlowRequestHeader(boolean isTokenRequired, HttpRequestBase requestHeader, String soeId) {
		try {
			if(null != requestHeader) {
				requestHeader.addHeader(CONTENT_TYPE, APPLICATION_JSON);
				requestHeader.addHeader(X_EXTERNAL_ID, xExternalId);
				requestHeader.addHeader(X_EXTERNAL_SECRET_KEY, xExternalSecretKey);
				requestHeader.addHeader(X_EXTERNAL_NAME, xExternalName);
				requestHeader.addHeader(X_CITIPORTAL_LOGIN_ID, soeId);
				requestHeader.addHeader("X-External-CsiId", xExternalCsiId);
				if(isTokenRequired) {
					if(StringUtils.isBlank(token)) {
						generateToken(soeId);
					}
					requestHeader.addHeader(X_EXTERNAL_AUTH, token);
				}
			}
		} catch (Exception e) {
			commUniFlowLogger.error(CUF_LOG_PATTERN+"Exception in getCommUniFlowRequestHeader", e);
		}
	}
	@SuppressWarnings("deprecation")
	public BasicDBList getUserEntitlementById(String soeId, BasicDBObject inputJsonObj) {
		long startTime = System.currentTimeMillis();
		BasicDBList response = null;
		try {
			String requestUrl = commUniFlowServiceEndPoint+"/bmw-referencedata/bmw-reference-data/getUserEntitlementById";
			commUniFlowLogger.info(CUF_LOG_PATTERN+CALLING_URL_INFO,requestUrl);
			HttpClient httpClient = getHttpClient();
			HttpPost postRequest = new HttpPost(requestUrl);
			getCommUniFlowRequestHeader(true, postRequest, soeId);
			HttpResponse entitlementResponse = null;
			try {
				entitlementResponse = httpClient.execute(postRequest);
			} catch (Exception e) {
				commUniFlowLogger.error(CUF_LOG_PATTERN+"getUserEntitlementById call failed while ececuting httpClient for soeId="+soeId, e);
			}
			if (null != entitlementResponse && entitlementResponse.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = entitlementResponse.getEntity();
				StringBuilder content = extractSearchResponse(entity);
				response = DataConversionUtil.convertJsonToBasicDBList(content.toString());
			} else if (null != entitlementResponse && entitlementResponse.getStatusLine().getStatusCode() == 401) {
				Header[] responseHeader = entitlementResponse.getHeaders(X_EXTERNAL_TOKEN_STATUS);
				if(responseHeader.length > 0 && TOKEN_INVALID.equalsIgnoreCase(responseHeader[0].getValue())) {
					commUniFlowLogger.info(CUF_LOG_PATTERN+TOKEN_EXPR_GEN_AGAIN);
					 generateToken(soeId);
				} else {
					commUniFlowLogger.info(CUF_LOG_PATTERN+USER_NOT_AUTHORIZED,soeId);
				}
			} else {
				commUniFlowLogger.info(CUF_LOG_PATTERN+"getUserEntitlementById call response code is not 200  for soeId={}",soeId);
			}
		} catch (Exception e) {
			commUniFlowLogger.error(CUF_LOG_PATTERN+"Exception in getUserEntitlementById", e);
			if(null != response) {//sonar fix -null pointer
				response.put(SUCCESS, false);
				response.put(MESSAGE, SERVICE_NOT_AVAILABLE);
			}
			
		}
		commUniFlowLogger.info(CUF_LOG_PATTERN+"time taken by getUserEntitlementById method : {} in ms",(System.currentTimeMillis()-startTime));
		return response;
	}
	@SuppressWarnings("deprecation")
	public BasicDBList fetchOverdueData(String soeId, BasicDBObject inputJsonObj) {
		long startTime = System.currentTimeMillis();
		BasicDBList response = null;
		try {
			String requestUrl = commUniFlowServiceEndPoint+"/bmw-report/api/fetchOverdueData";
			commUniFlowLogger.info(CUF_LOG_PATTERN+CALLING_URL_INFO,requestUrl);
			HttpClient httpClient = getHttpClient();
			HttpPost postRequest = new HttpPost(requestUrl);
			getCommUniFlowRequestHeader(true, postRequest, soeId);
			HttpResponse entitlementResponse = null;
			try {
				if(null != inputJsonObj) {
					StringEntity input = new StringEntity(inputJsonObj.toJson());
					postRequest.setEntity(input);
				}
				entitlementResponse = httpClient.execute(postRequest);
			} catch (Exception e) {
				commUniFlowLogger.error(CUF_LOG_PATTERN+"fetchOverdueData call failed while ececuting httpClient for soeId="+soeId, e);
			}
			if (null != entitlementResponse && entitlementResponse.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = entitlementResponse.getEntity();
				StringBuilder content = extractSearchResponse(entity);
				response =  DataConversionUtil.convertJsonToBasicDBList(content.toString());
			} else if (null != entitlementResponse && entitlementResponse.getStatusLine().getStatusCode() == 401) {
				Header[] responseHeader = entitlementResponse.getHeaders(X_EXTERNAL_TOKEN_STATUS);
				if(responseHeader.length > 0 && TOKEN_INVALID.equalsIgnoreCase(responseHeader[0].getValue())) {
					commUniFlowLogger.info(CUF_LOG_PATTERN+TOKEN_EXPR_GEN_AGAIN);
					generateToken(soeId);
				} else {
					commUniFlowLogger.info(CUF_LOG_PATTERN+USER_NOT_AUTHORIZED,soeId);
				}
			} else {
				commUniFlowLogger.info(CUF_LOG_PATTERN+"fetchOverdueData call response code is not 200  for soeId={}",soeId);
			}
		} catch (Exception e) {
			commUniFlowLogger.error(CUF_LOG_PATTERN+"Exception in fetchOverdueData", e);
			if(null != response) {//sonar fix -null pointer
				response.put(SUCCESS, false);
				response.put(MESSAGE, SERVICE_NOT_AVAILABLE);
			}
			
		}
		commUniFlowLogger.info(CUF_LOG_PATTERN+"time taken by fetchOverdueData method : {} in ms",(System.currentTimeMillis()-startTime));
		return response;
	}
	@SuppressWarnings("deprecation")
	public DBObject loadRecentReports(String soeId, BasicDBObject inputJsonObj) {
		long startTime = System.currentTimeMillis();
		DBObject response = null;
		try {
			String requestUrl = commUniFlowServiceEndPoint+"/bmw-report/api/loadRecentReports";
			commUniFlowLogger.info(CUF_LOG_PATTERN+CALLING_URL_INFO,requestUrl);
			HttpClient httpClient = getHttpClient();
			HttpPost postRequest = new HttpPost(requestUrl);
			getCommUniFlowRequestHeader(true, postRequest, soeId);
			HttpResponse entitlementResponse = null;
			try {
				if(null != inputJsonObj) {
					StringEntity input = new StringEntity(inputJsonObj.toJson());
					postRequest.setEntity(input);
				}
				entitlementResponse = httpClient.execute(postRequest);
			} catch (Exception e) {
				commUniFlowLogger.error(CUF_LOG_PATTERN+"loadRecentReports call failed while ececuting httpClient for soeId="+soeId, e);
			}
			if (null != entitlementResponse && entitlementResponse.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = entitlementResponse.getEntity();
				StringBuilder content = extractSearchResponse(entity);
				response =  DataConversionUtil.convertJsonToBasicDBList(content.toString());
			} else if (null != entitlementResponse && entitlementResponse.getStatusLine().getStatusCode() == 401) {
				Header[] responseHeader = entitlementResponse.getHeaders(X_EXTERNAL_TOKEN_STATUS);
				if(responseHeader.length > 0 && TOKEN_INVALID.equalsIgnoreCase(responseHeader[0].getValue())) {
					commUniFlowLogger.info(CUF_LOG_PATTERN+TOKEN_EXPR_GEN_AGAIN);
					generateToken(soeId);
				} else {
					commUniFlowLogger.info(CUF_LOG_PATTERN+USER_NOT_AUTHORIZED,soeId);
				}
			} else {
				commUniFlowLogger.info(CUF_LOG_PATTERN+"loadRecentReports call response code is not 200  for soeId={}",soeId);
			}
		} catch (Exception e) {
			commUniFlowLogger.error(CUF_LOG_PATTERN+"Exception in loadRecentReports", e);
			if(null != response) {//sonar fix -null pointer
				response.put(SUCCESS, false);
				response.put(MESSAGE, SERVICE_NOT_AVAILABLE);
			}
		}
		commUniFlowLogger.info(CUF_LOG_PATTERN+"time taken by loadRecentReports method : {} in ms",(System.currentTimeMillis()-startTime));
		return response;
	}
	@SuppressWarnings("deprecation")
	public DBObject findWorkflowCountByStatus(String soeId, BasicDBObject inputJsonObj) {
		long startTime = System.currentTimeMillis();
		BasicDBObject response = null;
		try {
			String requestUrl = commUniFlowServiceEndPoint+"/bmw-report/api/findWorkflowCountByStatus";
			commUniFlowLogger.info(CUF_LOG_PATTERN+CALLING_URL_INFO,requestUrl);
			HttpClient httpClient = getHttpClient();
			HttpPost postRequest = new HttpPost(requestUrl);
			getCommUniFlowRequestHeader(true, postRequest, soeId);
			HttpResponse entitlementResponse = null;
			try {
				if(null != inputJsonObj) {
					StringEntity input = new StringEntity(inputJsonObj.toJson());
					postRequest.setEntity(input);
				}
				entitlementResponse = httpClient.execute(postRequest);
			} catch (Exception e) {
				commUniFlowLogger.error(CUF_LOG_PATTERN+"findWorkflowCountByStatus call failed while ececuting httpClient for soeId="+soeId, e);
			}
			if (null != entitlementResponse && entitlementResponse.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = entitlementResponse.getEntity();
				StringBuilder content = extractSearchResponse(entity);
				response =  BasicDBObject.parse(content.toString());
			} else if (null != entitlementResponse && entitlementResponse.getStatusLine().getStatusCode() == 401) {
				Header[] responseHeader = entitlementResponse.getHeaders(X_EXTERNAL_TOKEN_STATUS);
				if(responseHeader.length > 0 && TOKEN_INVALID.equalsIgnoreCase(responseHeader[0].getValue())) {
					commUniFlowLogger.info(CUF_LOG_PATTERN+TOKEN_EXPR_GEN_AGAIN);
					generateToken(soeId);
				} else {
					commUniFlowLogger.info(CUF_LOG_PATTERN+USER_NOT_AUTHORIZED,soeId);
				}
			} else {
				commUniFlowLogger.info(CUF_LOG_PATTERN+"findWorkflowCountByStatus call response code is not 200  for soeId={}",soeId);
			}
		} catch (Exception e) {
			commUniFlowLogger.error(CUF_LOG_PATTERN+"Exception in findWorkflowCountByStatus", e);
			if(null != response) {//sonar fix -null pointer
				response.put(SUCCESS, false);
				response.put(MESSAGE, SERVICE_NOT_AVAILABLE);
			}
			
		}
		commUniFlowLogger.info(CUF_LOG_PATTERN+"time taken by findWorkflowCountByStatus method : {} in ms",(System.currentTimeMillis()-startTime));
		return response;
	}
	@SuppressWarnings("deprecation")
	public DBObject loadWorkflowCountGraph(String soeId, BasicDBObject inputJsonObj) {
		long startTime = System.currentTimeMillis();
		BasicDBObject response = null;
		try {
			String requestUrl = commUniFlowServiceEndPoint+"/bmw-report/api/loadWorkflowCountGraph";
			commUniFlowLogger.info(CUF_LOG_PATTERN+CALLING_URL_INFO,requestUrl);
			HttpClient httpClient = getHttpClient();
			HttpPost postRequest = new HttpPost(requestUrl);
			getCommUniFlowRequestHeader(true, postRequest, soeId);
			HttpResponse entitlementResponse = null;
			try {
				if(null != inputJsonObj) {
					StringEntity input = new StringEntity(inputJsonObj.toJson());
					postRequest.setEntity(input);
				}
				entitlementResponse = httpClient.execute(postRequest);
			} catch (Exception e) {
				commUniFlowLogger.error(CUF_LOG_PATTERN+"loadWorkflowCountGraph call failed while ececuting httpClient for soeId="+soeId, e);
			}
			if (null != entitlementResponse && entitlementResponse.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = entitlementResponse.getEntity();
				StringBuilder content = extractSearchResponse(entity);
				response =  BasicDBObject.parse(content.toString());
			} else if (null != entitlementResponse && entitlementResponse.getStatusLine().getStatusCode() == 401) {
				Header[] responseHeader = entitlementResponse.getHeaders(X_EXTERNAL_TOKEN_STATUS);
				if(responseHeader.length > 0 && TOKEN_INVALID.equalsIgnoreCase(responseHeader[0].getValue())) {
					commUniFlowLogger.info(CUF_LOG_PATTERN+TOKEN_EXPR_GEN_AGAIN);
					generateToken(soeId);
				} else {
					commUniFlowLogger.info(CUF_LOG_PATTERN+USER_NOT_AUTHORIZED,soeId);
				}
			} else {
				commUniFlowLogger.info(CUF_LOG_PATTERN+"loadWorkflowCountGraph call response code is not 200  for soeId={}",soeId);
			}
		} catch (Exception e) {
			commUniFlowLogger.error(CUF_LOG_PATTERN+"Exception in loadWorkflowCountGraph", e);
			if(null != response) {//sonar fix -null pointer
				response.put(SUCCESS, false);
				response.put(MESSAGE, SERVICE_NOT_AVAILABLE);
			}
			
		}
		commUniFlowLogger.info(CUF_LOG_PATTERN+"time taken by loadWorkflowCountGraph method : {} in ms",(System.currentTimeMillis()-startTime));
		return response;
	}
	
}
