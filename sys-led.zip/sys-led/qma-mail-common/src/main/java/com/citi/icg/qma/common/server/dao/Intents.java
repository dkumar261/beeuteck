package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

public class Intents implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8163019633972663847L;
	String sentence;
	String intent;
	Integer probability;
	int index;
	public Intents() {
		super();
	}
	public String getSentence() {
		return sentence;
	}
	public void setSentence(String sentence) {
		this.sentence = sentence;
	}
	public String getIntent() {
		return intent;
	}
	public void setIntent(String intent) {
		this.intent = intent;
	}
	
	public Integer getProbability() {
		return probability;
	}
	public void setProbability(Integer probability) {
		this.probability = probability;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	@Override
	public String toString() {
		return "Intents [sentence=" + sentence + ", intent=" + intent + ", probability=" + probability + ", index="
				+ index + "]";
	}
	
	
	
	
}

