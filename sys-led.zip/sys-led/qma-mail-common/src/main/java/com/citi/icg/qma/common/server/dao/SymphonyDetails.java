package com.citi.icg.qma.common.server.dao;

import java.util.List;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "SymphonyDetails", noClassnameStored = true)
public class SymphonyDetails {
	@Id
	private String id;
	private String chatroomName;
	private List<String> memberList;
	private List<Long> groupList;
	private List<String> allQmaUser;
	private List<String> externalUser;
	private String crtBy;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCrtBy() {
		return crtBy;
	}
	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}
	public String getChatroomName() {
		return chatroomName;
	}
	public void setChatroomName(String chatroomName) {
		this.chatroomName = chatroomName;
	}
	public List<String> getMemberList() {
		return memberList;
	}
	public void setMemberList(List<String> memberList) {
		this.memberList = memberList;
	}
	public List<Long> getGroupList() {
		return groupList;
	}
	public void setGroupList(List<Long> groupList) {
		this.groupList = groupList;
	}
	public List<String> getAllQmaUser() {
		return allQmaUser;
	}
	public void setAllQmaUser(List<String> allQmaUser) {
		this.allQmaUser = allQmaUser;
	}
	public List<String> getExternalUser() {
		return externalUser;
	}
	public void setExternalUser(List<String> externalUser) {
		this.externalUser = externalUser;
	}
}
