package com.citi.icg.qma.common.messagebus.entity;

public class Recipient {


	private String emailAddr;
	private Long groupId;
	private String userId;
	private String displayName;

	public Recipient() {
		super();
	}

	public Recipient(String emailAddr, Long groupId, String userId, String displayName) {
		super();
		this.emailAddr = emailAddr;
		this.groupId = groupId;
		this.userId = userId;
		this.displayName = displayName;
	}

	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}


}
