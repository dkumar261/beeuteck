package com.citi.icg.qma.common.core.config;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

/**
 * This is the base class for all configuration classes, and provides common
 * functionality for them.
 */
public class Configuration extends XMLConfiguration implements XmlDocumentSource
{
	private static final String CONTAINER_INDEX_SUFFIX = ")";
	private static final String CONTAINER_INDEX_PREFIX = "(";
	private static final String CONTAINER_SEPARATOR = ".";
	private static final String ATTRIBUTE_PREFIX = "[";
	private static final String ATTRIBUTE_SUFFIX = "]";
	private static final String BLANK = "";

	/**
	 * Retrieves the name of the configuration file.
	 */
	public String getConfigurationName()
	{
		return ConfigUtil.getConfigName(this.getClass());

	}

	/**
	 * Retrieves the list of configuration entries that must exist and have a
	 * value.
	 */
	public String[] getRequiredEntries()
	{
		return ArrayUtils.EMPTY_STRING_ARRAY;//Sonar fix -- to return empty array instead of null
	}

	// --- Constructor(s) ---

	/**
	 * Constructs an IcgConfiguration.
	 */
	protected Configuration()
	{
		setDelimiterParsingDisabled(true);
	}

	// --- Static Methods ---

	/**
	 * Retrieves a list of missing entries. By default, this method iterates
	 * through the list of properties returned by the
	 * {@link #getRequiredEntries} method.
	 * 
	 * @return a list of missing entries.
	 */
	public List<String> getMissingEntries()
	{
		String[] requiredEntries = getRequiredEntries();

		ArrayList<String> missingEntries = new ArrayList<>();
		if (requiredEntries != null)
		{
			for (int ctr = 0; ctr < requiredEntries.length; ctr++)
			{
				if (!containsKey(requiredEntries[ctr]) || getProperty(requiredEntries[ctr]) == null)
				{
					missingEntries.add(requiredEntries[ctr]);
				}
			}
		}

		return missingEntries;
	}

	/**
	 * Prepends the root path to the specified path.
	 */
	protected String prependRootPath(String root, String path)
	{
		String rootTo = root;// Sonar Fix -- Method parameters, caught exceptions and foreach variables should not be reassigned 
		if (rootTo == null || path == null)
		{
			return path;
		}
		
		if (path.charAt(0) == '/')
		{
			return path;
		}
		if (!rootTo.endsWith("/"))
		{
			rootTo += "/";
		}
		return rootTo + path;
	}

	// CHECKSTYLE:OFF
	/*
	 * For a specific key ex; admin.tables.table.width get selectors the keys in
	 * different containers. <code> ex: <admin><tables> <table>
	 * <width>100</width> </table> <table> <width>50</width> </table>
	 * </tables></admin> </code> 1. admin.tables.table(0).width 2.
	 * admin.tables.table(1).width
	 */
	// CHECKSTYLE:ON
	public List<String> geKeysForAllContainers(String keyName)
	{
		List<String> keys = new ArrayList<>();
		getContainerKeysSelector(StringUtils.EMPTY, keyName, keys);
		return keys;
	}

	/*
	 * Utility method use be getKeySelector.
	 */
	private void getContainerKeysSelector(String startKeyContainer, String key, List<String> keys)
	{
		if (StringUtils.isBlank(key))
		{
			keys.add(startKeyContainer);
			return;
		}

		String nextKeyContainer = StringUtils.substringBefore(key, CONTAINER_SEPARATOR);
		String nextKeyContainerToProcess = startKeyContainer + CONTAINER_SEPARATOR + nextKeyContainer;
		String remainingContainer = StringUtils.substringAfter(key, CONTAINER_SEPARATOR);

		if (StringUtils.isBlank(startKeyContainer))
		{
			nextKeyContainerToProcess = nextKeyContainer;
		}
		int maxIndex = getMaxIndex(nextKeyContainerToProcess);
		
		//Take out the attribute from key and append after the array index. 
		// Eg., key=filters.filter[@class] should be converted into filters(0).filter(0)[@class], filters(0).filter(1)[@class]
		// Ultimately the attribute should be appended after the array.
		String attribute = getAttribute(nextKeyContainerToProcess);
		if (!StringUtils.isBlank(attribute))
			nextKeyContainerToProcess = nextKeyContainerToProcess.replace(attribute, BLANK);
		
		for (int i = 0; i <= maxIndex; i++)
		{
			getContainerKeysSelector(nextKeyContainerToProcess + CONTAINER_INDEX_PREFIX + i + CONTAINER_INDEX_SUFFIX + attribute,
					remainingContainer, keys);
		}
	}

	/**
	 * Utility method to parse the key that has attributes associated with it.
	 * Eg., <filter class="TEST"> </filter> the key should be filter[@class]
	 * This method retrieves the attribute "[@class]" out of the key
	 * @param key
	 * @return
	 */
	private String getAttribute(String key)
	{
		String attribute = BLANK;
		//Return the attribute if the key itself is not an attribute and key contains attribute.
		if (!key.startsWith(ATTRIBUTE_PREFIX) && key.contains(ATTRIBUTE_PREFIX) && key.contains(ATTRIBUTE_SUFFIX))
			attribute = key.substring(key.indexOf(ATTRIBUTE_PREFIX), key.indexOf(ATTRIBUTE_SUFFIX)+1);
		return attribute;
	}

}
