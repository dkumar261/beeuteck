package com.citi.icg.qma.cims.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GrpMemberRec {
	@JsonProperty("Domain")
	private String domain;
	@JsonProperty("SamAccountName")
	private String samAccountName;
	@JsonProperty("DisplayName")
	private String  displayName;
	@JsonProperty("DistinguishedName")
	private String distinguishedName;
	@JsonProperty("Guid")
	private String guid;
	@JsonProperty("ObjectType")
	private String objectType;
	@JsonProperty("GroupScope")
	private String groupScope;
	@JsonProperty("GroupSecType")
	private String groupSecType;
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getSamAccountName() {
		return samAccountName;
	}
	public void setSamAccountName(String samAccountName) {
		this.samAccountName = samAccountName;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getDistinguishedName() {
		return distinguishedName;
	}
	public void setDistinguishedName(String distinguishedName) {
		this.distinguishedName = distinguishedName;
	}
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	public String getGroupScope() {
		return groupScope;
	}
	public void setGroupScope(String groupScope) {
		this.groupScope = groupScope;
	}
	public String getGroupSecType() {
		return groupSecType;
	}
	public void setGroupSecType(String groupSecType) {
		this.groupSecType = groupSecType;
	}
	
}
