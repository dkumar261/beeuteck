package com.citi.icg.qma.common.server.dao;

public enum ProcessingStatus {
	
	OPEN, IN_PROGRESS, PROCESSED, WARNING, FAILED
}
