package com.citi.icg.qma.common.transferobject;

import java.util.List;

import com.citi.icg.qma.common.server.dao.FavoriteContact;
import com.citi.icg.qma.common.server.dao.Group;

public class InquiryTO
{
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private List<Group> myGroups;
	private List<UserGroupTO> allToCcDBUserGroups; // it will be combination of qs_user + qs_group...
	private List<FavoriteContact> myFavoriteContacts;
	private String userSignature;

	public InquiryTO()
	{
	}

	public InquiryTO(List<Group> myGroups, List<UserGroupTO> allToCcDBUserGroups, List<FavoriteContact> myFavoriteContacts, String userSignature)
	{
		super();
		this.myGroups = myGroups;
		this.allToCcDBUserGroups = allToCcDBUserGroups;
		this.myFavoriteContacts = myFavoriteContacts;
		this.userSignature = userSignature;
	}

	public List<Group> getMyGroups() {
		return myGroups;
	}

	public void setMyGroups(List<Group> myGroups) {
		this.myGroups = myGroups;
	}

	public List<UserGroupTO> getAllToCcDBUserGroups() {
		return allToCcDBUserGroups;
	}

	public void setAllToCcDBUserGroups(List<UserGroupTO> allToCcDBUserGroups) {
		this.allToCcDBUserGroups = allToCcDBUserGroups;
	}

	public List<FavoriteContact> getMyFavoriteContacts() {
		return myFavoriteContacts;
	}

	public void setMyFavoriteContacts(List<FavoriteContact> myFavoriteContacts) {
		this.myFavoriteContacts = myFavoriteContacts;
	}

	public String getUserSignature() {
		return userSignature;
	}

	public void setUserSignature(String userSignature) {
		this.userSignature = userSignature;
	}
}
