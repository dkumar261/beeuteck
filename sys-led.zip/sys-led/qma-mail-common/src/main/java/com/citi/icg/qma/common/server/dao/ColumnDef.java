package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

public class ColumnDef implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -9146595826650188578L;
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	// This object is now part of static Data and as well as embedded in viewconfig:// SUNIL 20Aug
	private String attributeName;
	private int displayOrder; // this is defined by user, so initially we will order it based on our UI. Later This will come from UI.
	private String displayName;
	private String dataType;
	private String defaultDisplay; // will be N or Y in DB , used for showing initially or not. By default should be "Y" in DB.
	private long width;
	private String disableFilter; // will be N or Y in DB , used for showing initially or not in filter columns.
	private String displayType;
	
	public ColumnDef()
	{

	}

	public ColumnDef(String attributeName, int displayOrder, String displayName, String dataType, String defaultDisplay, long width, String disableFilter)
	{
		super();
		this.attributeName = attributeName;
		this.displayOrder = displayOrder;
		this.displayName = displayName;
		this.dataType = dataType;
		this.defaultDisplay = defaultDisplay;
		this.width = width;
		this.disableFilter = disableFilter;
	}

	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public int getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(int displayOrder) {
		this.displayOrder = displayOrder;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getDefaultDisplay() {
		return defaultDisplay;
	}

	public void setDefaultDisplay(String defaultDisplay) {
		this.defaultDisplay = defaultDisplay;
	}

	public long getWidth()
	{
		return width;
	}

	public void setWidth(long width)
	{
		this.width = width;
	}

	public String getDisableFilter()
	{
		return disableFilter;
	}

	public void setDisableFilter(String disableFilter)
	{
		this.disableFilter = disableFilter;
	}

	public String getDisplayType()
	{
		return displayType;
	}

	public void setDisplayType(String displayType)
	{
		this.displayType = displayType;
	}

}
