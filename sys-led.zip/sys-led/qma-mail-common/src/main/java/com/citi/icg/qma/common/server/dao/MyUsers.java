package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Entity;

// test class, not for our db model
@Entity(value = "MyUsers", noClassnameStored = false)
public class MyUsers extends BaseEntity
{

	private String address;
	private String degree;
	private String firstName;
	private String lastName;
	private int age;

	private String address1;
	private String degree1;
	private String firstName1;
	private String lastName1;
	private int age1;

	private String address3;
	private String degree3;
	private String firstName3;
	private String lastName3;
	private int age3;

	private String address4;
	private String degree4;
	private String firstName4;
	private String lastName4;
	private int age4;

	public MyUsers()
	{
		super();
	}

	public MyUsers(String firstname, String lastName, int age)
	{

		this.firstName = firstname;
		this.lastName = lastName;
		this.age = age;

	}

	//Sonar Fix -- Constructor has parameters, which is greater than 7 authorized
	
	public String getAddress()
	{
		return address;
	}

	public void setAddress(String address)
	{
		this.address = address;
	}

	public String getDegree()
	{
		return degree;
	}

	public void setDegree(String degree)
	{
		this.degree = degree;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public int getAge()
	{
		return age;
	}

	public void setAge(int age)
	{
		this.age = age;
	}

	public String getAddress1()
	{
		return address1;
	}

	public void setAddress1(String address1)
	{
		this.address1 = address1;
	}

	public String getDegree1()
	{
		return degree1;
	}

	public void setDegree1(String degree1)
	{
		this.degree1 = degree1;
	}

	public String getFirstName1()
	{
		return firstName1;
	}

	public void setFirstName1(String firstName1)
	{
		this.firstName1 = firstName1;
	}

	public String getLastName1()
	{
		return lastName1;
	}

	public void setLastName1(String lastName1)
	{
		this.lastName1 = lastName1;
	}

	public int getAge1()
	{
		return age1;
	}

	public void setAge1(int age1)
	{
		this.age1 = age1;
	}

	public String getAddress3()
	{
		return address3;
	}

	public void setAddress3(String address3)
	{
		this.address3 = address3;
	}

	public String getDegree3()
	{
		return degree3;
	}

	public void setDegree3(String degree3)
	{
		this.degree3 = degree3;
	}

	public String getFirstName3()
	{
		return firstName3;
	}

	public void setFirstName3(String firstName3)
	{
		this.firstName3 = firstName3;
	}

	public String getLastName3()
	{
		return lastName3;
	}

	public void setLastName3(String lastName3)
	{
		this.lastName3 = lastName3;
	}

	public int getAge3()
	{
		return age3;
	}

	public void setAge3(int age3)
	{
		this.age3 = age3;
	}

	public String getAddress4()
	{
		return address4;
	}

	public void setAddress4(String address4)
	{
		this.address4 = address4;
	}

	public String getDegree4()
	{
		return degree4;
	}

	public void setDegree4(String degree4)
	{
		this.degree4 = degree4;
	}

	public String getFirstName4()
	{
		return firstName4;
	}

	public void setFirstName4(String firstName4)
	{
		this.firstName4 = firstName4;
	}

	public String getLastName4()
	{
		return lastName4;
	}

	public void setLastName4(String lastName4)
	{
		this.lastName4 = lastName4;
	}

	public int getAge4()
	{
		return age4;
	}

	public void setAge4(int age4)
	{
		this.age4 = age4;
	}

	@Override
	public String toString()
	{
		return "";
	}

}
