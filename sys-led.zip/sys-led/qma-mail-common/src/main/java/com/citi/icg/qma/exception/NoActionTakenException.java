package com.citi.icg.qma.exception;

public class NoActionTakenException extends Exception{

	private static final long serialVersionUID = 6764373549098168265L;

	public NoActionTakenException(String message) {
		super(message);
	}
}
