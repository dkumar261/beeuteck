package com.citi.icg.qma.common.core.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.citi.icg.qma.common.auth.OAuth2TokenGenerator;
import jakarta.mail.Authenticator;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.persistence.AttachmentDAO;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.config.MongoDBConfig;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClientOptions;
import com.mongodb.WriteConcern;
import com.mongodb.MongoClientOptions.Builder;

public class MailCommonUtil {
	private static final Logger logger = LoggerFactory.getLogger(MailCommonUtil.class);
	public static final String INVALID_EMAIL_PATTERN_BEFORE_DOMAIN = "[^a-zA-Z0-9!#$%&'*+-/=?^_`{|}~.]+";
	private static final String INLINE_IMAGE_PATTERN = "<img.*?>";
	private static final String IMAGE_FILEID_PATTERN = "path=.*?>";
	private static final AttachmentDAO aDao = new AttachmentDAO();
	public static final String INVALID_EMAIL_PATTERN_AFTER_DOMAIN = "[^\\w\\.\\-]";
	private static final String SMTP_HOST = "mail.smtp.host";

	/** SMTP host. */
	private static final String SMTP_PORT = "mail.smtp.port";

	private static final String SMTP_AUTH = "mail.smtp.auth";
	private static final String SMTP_STARTTLS = "mail.smtp.starttls.enable";
	private static final String SMTP_AUTH_MECHANISM = "mail.smtp.auth.mechanisms";
	
	private MailCommonUtil() {
		// As this class is Util, so added making private constructor.
		// Sonar Fix -- Utility classes should not have public constructors
	}

	// public static Logger getLogger()
	// {
	//// if (logger == null)
	//// {
	//// logger = Logger.getLogger("COMMON");
	//// }
	// return logger;
	//
	// }

	// public static Category getLogger(Object caller)
	// {
	// return getLogger(caller.getClass());
	// }

	// Password Decryption Util method
	public static String getDecryptedPassword(Properties prop) {
		String decrPassword = null;
		String passwordEncStr = null;
		String passwordIVEncStr = null;
		try {
			passwordEncStr = prop.getProperty("password");
			passwordIVEncStr = prop.getProperty("passwordIV");
			if (passwordEncStr == null && passwordIVEncStr == null) {
				passwordEncStr = prop.getProperty("PASSWORD");
				passwordIVEncStr = prop.getProperty("PASSWORDIV");
			}
			decrPassword = DecryptionUtil.decrypt(passwordEncStr, passwordIVEncStr,
					QmaMailConstants.APPLICATION_ENCRYPTION_KEY);
			logger.info("Decryption successfull");
		} catch (Exception e) {
			logger.error("Invalid Password property for Decryption");
		}
		return decrPassword;
	}

	public static void stopProcess(String processName, int exitCode, Logger subLogger) {
		subLogger.info("Stoping Process " + processName + " with exit code: " + exitCode);
		System.exit(exitCode);
	}


	public static List<BasicDBObject> getJsonObjFromRequest(BasicDBObject inputJsonObj, String inputFieldName)
			throws CommunicatorException// Sonar Fix -- Define and throw a
										// dedicated exception
	{

		List<BasicDBObject> valueList = new ArrayList<BasicDBObject>();
		Object list = inputJsonObj.get(inputFieldName);
		if (list instanceof List<?> inputList) {
			for (Object inputObj : inputList) {
				try {
					valueList.add((BasicDBObject) inputObj);
				} catch (Exception e) {
					// Try next object in the list
				}
			}
		}

		return valueList;
	}

	public static List<String> getCaseInsensitiveSortedList(List<String> stringList)// Sonar
																					// Fix
																					// -
																					// reduce
																					// the
																					// no
																					// of
																					// line
																					// of
																					// anonymous
																					// class
																					// max
																					// to
																					// 20
	{
		if (stringList == null || stringList.isEmpty()) {
			return stringList;
		}
		Collections.sort(stringList, new Comparator<String>() {
			@Override // Sonar fix -- Add the "@Override" annotation above this
						// method signature
			public int compare(final String o1, final String o2) {
				if (o1 == null)
					return -1;
				if (o2 == null)
					return 1;
				final String obj1 = o1.toUpperCase();
				final String obj2 = o2.toUpperCase();
				if (obj1 == obj2) {
					return 0;
				}
				return obj1.compareTo(obj2);
			}
		});
		return stringList;
	}

	public static File createFile(String fileName) {
		File file = null;
		String fileNameWithPath = fileName;
		String defaultFileCreationFolder = System.getProperty("defaultfilepath");
		if (StringUtils.isNotBlank(defaultFileCreationFolder)) {
			fileNameWithPath = defaultFileCreationFolder + fileName;
		}
		//[C170665-1723] - SBT Path Traversal Issue Fixing
		if(GenericUtility.isValidPathForFileRead(fileNameWithPath)) {
			file = new File(fileNameWithPath);
		}else
			logger.error("Error while Creating file: {}",fileNameWithPath);
		return file;
	}

	public static String getValidEmailWithoutDomain(String email) {
		String returnEmail = null;
		try {
			if (StringUtils.isNotBlank(email)) {
				String emailTrimed = email.trim();
				if (emailTrimed.startsWith("'") && emailTrimed.endsWith("'")) {
					emailTrimed = emailTrimed.substring(1, emailTrimed.length() - 1);
				}
				int lastIndexOfAtSymbol = emailTrimed.lastIndexOf('@');
				if (lastIndexOfAtSymbol > -1) {
					returnEmail = emailTrimed.substring(0, lastIndexOfAtSymbol)
							.replaceAll(INVALID_EMAIL_PATTERN_BEFORE_DOMAIN, "");
				}
			}
		} catch (Exception ex) {
			logger.warn("Error in getValidEmailWithoutDomain email address has issues. " + ex);
		}
		return returnEmail;
	}

	public static String calculateChecksum(File file) {
		String checksum = null;
		try {
			// Get file input stream for reading the file content
			FileInputStream fis = new FileInputStream(file);
			checksum = calculateChecksum(fis);
		} catch (IOException ioe) {
			logger.info("Error while calculating the checksum of file= " + file);
		}
		return checksum;
	}

	public static String calculateChecksum(InputStream in) throws IOException {
		String checkSum = null;
		if (in.markSupported()) {
			in.mark(Integer.MAX_VALUE);
			MessageDigest digest = getMessageDigest();
			// Create byte array to read data in chunks
			byte[] byteArray = new byte[1024];
			int bytesCount = 0;
			if(null == digest) {
				return checkSum;
			}
			// Read file data and update in message digest
			while ((bytesCount = in.read(byteArray)) != -1) {
				digest.update(byteArray, 0, bytesCount);
			}
			// Get the hash's bytes
			byte[] bytes = digest.digest();
			// This bytes[] has bytes in decimal format;
			// Convert it to hexadecimal format
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < bytes.length; i++) {
				sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
			}
			in.reset();
			checkSum = sb.toString();
		}
		logger.info("MD5 file checksum= " + checkSum);

		return checkSum;
	}

	public static MessageDigest getMessageDigest() {
		// Use MD5 algorithm
		MessageDigest md5Digest = null;
		try {
			md5Digest = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException nsae) {
			// TODO Auto-generated catch block
			logger.error("Error while loading the MD5 message digest " + nsae);
		}

		return md5Digest;
	}

	public static byte[] convertStringToHex(String str) {

		byte[] encodedHexB64 = null;
		try {
			byte[] decodedHex = Hex.decodeHex(str.toCharArray());
			encodedHexB64 = Base64.encodeBase64(decodedHex);

		} catch (Exception e) {
			logger.error("Error happened in Convert String to Hex Value ", e);
		}

		return encodedHexB64;
	}

	public static String replaceBaseTag(String content1) {
		String content = content1;
		// Sonar Fix -- Introduce a new variable instead of reusing the
		// parameter
		if (!StringUtils.isBlank(content))
			// [C153176-661] - Replacing <base> tag with <custombase> to prevent
			// application context being changed
			// [C153176-1668] - QMA screen is freezing when user is trying to
			// open particular email
			content = content1.replaceAll("<base", "<custombase").replaceAll("</base", "</custombase")
					.replaceAll("!\r\n", "");
		return content;
	}
	
	public static List<Map<String, Object>> getAllInlineAttachments(Conversation conv) {
		List<Map<String, Object>> attachments = null;
		if(conv != null && StringUtils.isNotEmpty(GenericUtility.checkAndFetchConvContent(conv))) {
			logger.info("getAllInlineAttachments() called for convId :" + conv.getId() + ", inquiryId : " + conv.getInquiryId());
			attachments = extractInlineAttachmentFromContents(GenericUtility.checkAndFetchConvContent(conv));
		}
		return attachments;
	}
	
	/**
	 * This method gets list of all inline attached files map for given contents
	 * @param attachments
	 * @param aDao
	 * @param logger
	 * @return List<Map<String, Object>>
	 */
	public static List<Map<String, Object>> extractInlineAttachmentFromContents(String currentContent) {
		List<Map<String, Object>> attachmentFiles = new ArrayList<>();
		if( null != currentContent && StringUtils.isNotBlank(currentContent) ) {
			List<String> fileIds = parseContentForInlineAttachment(currentContent);
			if(fileIds!=null && !fileIds.isEmpty()){
				attachmentFiles = getFiles(fileIds);
			}
		}
		return attachmentFiles;
	}

	/**
	 * This method extracts all the fileId associated with passed contents
	 * @param currentContent
	 * @param logger
	 * @return  List<String>
	 */
	private static List<String> parseContentForInlineAttachment(String currentContent) {
		List<String> fileIds = new ArrayList<>();
		if(currentContent!=null && StringUtils.isNotBlank(currentContent)){
			Pattern pattern = Pattern.compile(INLINE_IMAGE_PATTERN);
			Matcher matcher = pattern.matcher(currentContent);
			List<String> imageTags = new ArrayList<>();
			while (matcher.find()) {
				imageTags.add(matcher.group());
			}
			if(!imageTags.isEmpty()){
				fileIds = getFileIds(imageTags);
			} else {
				logger.info("No inline images found for given contents");
			}
		}
		return fileIds;
	}
	
	/**
	 * This method extract fileIds from provided image tags
	 * @param imageTags
	 * @return List<String>
	 */
	private static List<String> getFileIds(List<String> imageTags) {
		List<String> fileIds = new ArrayList<>();
		try {
			if(imageTags!=null && !imageTags.isEmpty()){
				for(String image : imageTags){
					Pattern pattern = Pattern.compile(IMAGE_FILEID_PATTERN);
					Matcher matcher = pattern.matcher(image);
					String fid = "";
					while (matcher.find()) {
						fid =  matcher.group();
						fid = fid.substring(fid.indexOf('=')+1, fid.indexOf("\">"));
					}
					if(StringUtils.isNotEmpty(fid)) {
						fileIds.add(fid);
					}
				}
			}
		} catch (Exception e) {
			logger.warn("Not able to extract file IDs from image tags");
		}
		return fileIds;
	}
	
	/**
	 * This function provides list of file maps for all provied fileIDs
	 * @param fileIds
	 * @param aDao
	 * @param logger
	 * @return List<Map<String, Object>>
	 */
	public static List<Map<String, Object>> getFiles(List<String> fileIds) {
		List<Map<String, Object>> files = new ArrayList<>();
		if(fileIds!=null && !fileIds.isEmpty()){
			for(String fileId : fileIds){
				Map<String, Object> fileMap = getFile(fileId);
				if(fileMap!=null && !fileMap.isEmpty()){
					files.add(fileMap);
				}
			}
		}
		return files;
	}
	
	/**
	 * This file returns a file map object for given file mongo id
	 * @param id
	 * @param aDao
	 * @param logger
	 * @return Map<String, Object>
	 */
	public static Map<String, Object> getFile(String id) {
		Map<String, Object> fileMap = null;
		try {
			if(!StringUtils.isEmpty(id)){
				fileMap = aDao.getFile(id);
				if( null != fileMap && !fileMap.isEmpty() ) {
					logger.info("File extracted for file id : " + id);
				}
			}
		} catch (CommunicatorException e) {
			logger.error(" Exception while retrieving file with id :" + id , e);
		}
		return fileMap;
	}
	
	public static String getValidEmail(String email)
	{
		String returnEmail = null;
		
		if (StringUtils.isNotBlank(email) && email.indexOf('@') != -1)
		{

			String emailTrimed=email.trim();
			if(emailTrimed.startsWith("'") && emailTrimed.endsWith("'")){
				emailTrimed=emailTrimed.substring(1,emailTrimed.length()-1);
			}
			int lastIndexOfAtSymbol = emailTrimed.lastIndexOf('@');

			String subStrNoDomain = emailTrimed.substring(0, lastIndexOfAtSymbol).replaceAll(INVALID_EMAIL_PATTERN_BEFORE_DOMAIN, "");

			String subStrOnlyDomain = emailTrimed.substring(lastIndexOfAtSymbol + 1, emailTrimed.length()).replaceAll(INVALID_EMAIL_PATTERN_AFTER_DOMAIN, "");

			returnEmail = subStrNoDomain + "@" + subStrOnlyDomain;

		}

		return returnEmail;
		
	}

	static Session getSession(String from) {
		Session session;
		Properties props = new Properties();
		try {
			String accessToken = OAuth2TokenGenerator.getAccessToken();
			logger.info("Access token fetched successfully");
			props.put(SMTP_HOST, "smtp.office365.com");
			props.put(SMTP_PORT, "587");
			props.put(SMTP_AUTH, "true");
			props.put(SMTP_STARTTLS, "true");
			props.put(SMTP_AUTH_MECHANISM, "XOAUTH2");

			session = Session.getInstance(props, new Authenticator() {
				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					// Use email and OAuth2 token for authentication
					return new PasswordAuthentication(from, accessToken);
				}
			});
		} catch (Exception e) {
			throw new RuntimeException("Issue encountered while generating token " +e);
		}
		session.setDebug(true);
		logger.info("Session established successfully");
		return session;
	}
	
	public static Builder configureMongoConnection(MongoDBConfig mongoDBConfig) {
		Builder builder = MongoClientOptions.builder();
		builder.socketTimeout(1600000);
		builder.connectTimeout(1200000);
		
		if(AppserverConstants.MONGODB.equals(mongoDBConfig.getConnectionScheme())) {
			builder.writeConcern(WriteConcern.W1);
			builder.sslInvalidHostNameAllowed(true);
		} else if(AppserverConstants.MONGODB_SRV.equals(mongoDBConfig.getConnectionScheme())) {
			builder.writeConcern(WriteConcern.MAJORITY);
			builder.retryWrites(true);
			builder.applicationName(mongoDBConfig.getServiceName());
			builder.sslEnabled(true);
		}
		return builder;
	}
	
	
}
