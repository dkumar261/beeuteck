package com.citi.icg.qma.common.server.utilCMCPayload;

public class Branches
{
    private String branchNumber;

    public String getBranchNumber ()
    {
        return branchNumber;
    }

    public void setBranchNumber (String branchNumber)
    {
        this.branchNumber = branchNumber;
    }

    @Override
    public String toString()
    {
        return "InputForCMC [branchNumber = "+branchNumber+"]";
    }
}
			
