package com.citi.icg.qma.common.server.dao.persistence;

import java.util.List;

import org.bson.types.ObjectId;

import com.citi.icg.qma.common.server.dao.AppUsers;
import com.citi.icg.qma.common.server.dao.BaseEntity;

/**
 * The generic Persistence interface - in our specific case this will be implemented by MongodbGenericPersistence.
 */
public interface IGenericBeanDAO
{

	<E extends BaseEntity> E get(Class<E> clazz, ObjectId id);

	<E extends BaseEntity> Long persist(E entity);

	<E extends BaseEntity> E clear(Class<E> clazz);

	<E extends BaseEntity> Long count(Class<E> clazz);

	List<AppUsers> getAllAppUsers(Class clazz); 
	
	void close();

}
