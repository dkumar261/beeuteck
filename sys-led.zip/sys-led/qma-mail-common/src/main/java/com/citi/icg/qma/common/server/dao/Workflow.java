package com.citi.icg.qma.common.server.dao;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.citi.icg.qma.common.server.util.SuggestionStatusIndicator;

import dev.morphia.annotations.Embedded;
import dev.morphia.annotations.Transient;

@Embedded
public class Workflow
{
	private String status;
	private Long assignedGroupId;
	private String assignedUserId;
	private Date originDate;
	private String crtBy;
	private Date crtDate;
	private String modBy;
	private Date modDate;
	
//	C153176-4401: received date not getting updated
	@Transient
	private Date modDateForActionStatistics;
	
	private String direction;
	private String requestType;
	private String stage;
	private String assignedUserName;
	// Release 1.2 Changes
	private String assignedGroupName;
	private String action;
	private String maker;
	private String tag;
	
	private Date reOpenDate;
	private RulesFlag rulesFlag;
	// change for link id
	private Long linkId;
	private Date lastActionTime;
	private String lastActionby;
	private Date resolveTime;
	private String resolver;
	private String rootCause;// [C153176-774] - Root cause for reaply/reply all resolve
	private String processingRegion;// [C153176-793] Add Processing Region as a drop-down in Group Admin screen
	private Long queryCount; // [C153176-852] Add new field 'Query Count'
	// C153176-818-Add 'Response Time'
	private Date latestConversationTime;
	private Long responseTimeQMA;
	private Integer replyCountQMA;
	// C153176-154 ActionStatistics Improvements-C153176-290
	private Integer prevResponseCntr;// Previous Response Counter before resolve

	// C153176-547-Show number of conversations for an inquiry in grid
	private int convCount;// Total no of conversation this group is involved

	private String inquirySource;// [C153176-854] - Add new drop-down: Inquiry Source
	private String inquirySubStatus; //[C170665-1719] DCC Requirement: Add Case status field
	private String isSubStatusPendingInternal; //[C170665-1719] DCC Requirement: Add Case status field
	private String prevInqSubStatus;//[C170665-1719] DCC Requirement: Add Case status field 
	private String inquiryRefSent = "N";
	private Integer clientChaseCounter; // [C153176-963] - Add 'Client Chase Counter'

	// C153176-981 Compute 'Avg Resolution Time' for workflow
	private Long totalResolveTimeQMA;
	private Integer resolveCountQMA;
	private String isLastConvToExtEmail; // [C153176-963] - Flag to determine if lastest conversation is sent to external email

	// C153176-875 Ability to lock an email from being resolved by another team member.
	private String lock ;
	private String lockedBy;
	private Date lockedDate;
	
	//[C153176-1014] - Add Escalation functionality
	private String isConvCountEscalation; //Queries exceeding n number of conversations
	private String isClientChaseEscalation; //Queries chased by client
	private String isSubjectEscalation; //Email subject containing Escalation, Urgent etc.
	private String generalEscalationReason;
	private String responseTimeEscalationReason;
	private Integer latestClientChaseCounter; //will count only the latest count and not aggregated one
	private Date responseTimeNextEscalation;
	private String responseTimeEscalationFlag; //Queries not responded to within n timeframe
	private String isManualEscalation;
	private String manualEscalationReason;
	
	private String soeId;
	private Integer prevConvCount;// Previous Response Counter before resolve
	private Boolean isMakerCheckerEnabled;
	private String workflowStatus;
	private FollowUp followUp; //[C153176-1238]-Enable 'Follow-up' functionality- Object to support follow up functionality.
	private Date reAgeDate;
	// [C153176-1270] - Add Escalation criteria for 'Pending Approval' emails
	private String ispendingApprovalEscalation;
	private Date reAgeSentDate;
	private Set<String> pendingExternalDomains;//C153176-1549
	@Transient
	private String uiWorkflowStatus;// [C153176-1549] Added as a transfer field. Not persisting it in DB
	
	private String suggestionIndicator = SuggestionStatusIndicator.N.toString();
	private String hasOwnership;
	private String resolvedByOtherGroupOwnership;

	// [C153176-1694] - Acknowledge Escalation flags
	private String isAckEscalation;
	private String ackEscalationBy;
	private Date ackEscalationTime;
	
	

	private boolean isEscalation; 
	private List<CustomClientCategoryDetails> customClientCategory;
	
	private List<Long> nominatedBy;
	private List<Long> nominatedTo;
	private String nominatingReason;
	private String nominationRejectionReason;
	private boolean hasNominatedOwnership;
	private Long unassignedTimeInMins;	
	private String snoozeDetails;
	//maintain flag to identify snoozed inquiry 
	private String snoozeAction;
	
	// C153176-5354 - Panorama feed
	private Long resolutionTimeInMinutes; // Total Resolve time consider working hours.
	private Long responseTimeInMinutes; // Total Response time consider working hours.
	private Date firstResponseTime; // Capture initial response time.
	private Long firstResponseInMinutes; // Initial response time consider working hours.
	
	private String attchFlag; //attachment flag

	// C153176-5891 | Average response time not calculated correctly
	private String isLatestResponseFromNonQMA; // If mail is sent from QMA or Not.
	private Date firstNonChaserResponseTimeByExternal; // When Client Sent the mail.
	private Long citiResponseTime;  // Total response time taken by CITI.
	private Integer citiReplyCountFromQMA; // Total number of reply from QMA.
	private List<String> personalFolders;
	
	// C153176-5977 | Nominate ownership : Resolution time getting considered from the time of ownership requested
	private Date ownershipAcceptedTime; // Nominate ownership acceptance time
	
	//C153176-6167 maintain flag to identify ever Inquiry snoozed
	private String isWorkflowEverSnoozed;
	
	private String resolveAllocation;
	//C170665-118 for time in queue
	private String isLatestReplyFromCurrentWorkflowGrp;
	private String autoAssigned;
	private String autoAssignedAction;
	private String latestConversationPreviewText;
	private String latestSenderDomain;
	private String latestExchangeItemId;
	private String intentSuggestionName;
	private String intentTimeToVD;
	private String userIntentSuggestionName;

	private boolean isNominatedOwnerChanged;
	
	public Workflow()
	{

	}

	public boolean isNominatedOwnerChanged() {
		return isNominatedOwnerChanged;
	}

	public void setNominatedOwnerChanged(boolean nominatedOwnerChanged) {
		isNominatedOwnerChanged = nominatedOwnerChanged;
	}

	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

	public String getDirection()
	{
		return direction;
	}

	public void setDirection(String direction)
	{
		this.direction = direction;
	}

	public Long getAssignedGroupId()
	{
		return assignedGroupId;
	}

	public void setAssignedGroupId(Long assignedGroupId)
	{
		this.assignedGroupId = assignedGroupId;
	}

	public String getAssignedUserId()
	{
		return assignedUserId;
	}

	public void setAssignedUserId(String assignedUserId)
	{
		this.assignedUserId = assignedUserId;
	}

	public Date getOriginDate()
	{
		return originDate;
	}

	public void setOriginDate(Date originDate)
	{
		this.originDate = originDate;
	}

	public String getCrtBy()
	{
		return crtBy;
	}

	public void setCrtBy(String crtBy)
	{
		this.crtBy = crtBy;
	}

	public Date getCrtDate()
	{
		return crtDate;
	}

	public void setCrtDate(Date crtDate)
	{
		this.crtDate = crtDate;
	}

	public String getModBy()
	{
		return modBy;
	}

	public void setModBy(String modBy)
	{
		this.modBy = modBy;
	}

	public Date getModDate()
	{
		return modDate;
	}

	public void setModDate(Date modDate)
	{
		this.modDate = modDate;
	}

	public String getRequestType()
	{
		return requestType;
	}

	public void setRequestType(String requestType)
	{
		if(StringUtils.isNotBlank(requestType) && requestType.length() > 350 )
		{
			try
			{
				requestType = requestType.substring(0,300);
				
			}catch (Exception e) 
			{
				//will not come here. Just extra safety.
			}
		
		}
		this.requestType = requestType;
	}

	public String getStage()
	{
		return stage;
	}

	public void setStage(String stage)
	{
		this.stage = stage;
	}

	
	public String getAssignedUserName()
	{
		return assignedUserName;
	}

	public void setAssignedUserName(String assignedUserName)
	{
		this.assignedUserName = assignedUserName;
	}

	public String getAssignedGroupName()
	{
		return assignedGroupName;
	}

	public void setAssignedGroupName(String assignedGroupName)
	{
		this.assignedGroupName = assignedGroupName;
	}

	public String getAction()
	{
		return action;
	}

	public void setAction(String action)
	{
		this.action = action;
	}

	public RulesFlag getRulesFlag()
	{
		return rulesFlag;
	}

	public void setRulesFlag(RulesFlag rulesFlag)
	{
		this.rulesFlag = rulesFlag;
	}

	public String getMaker()
	{
		return maker;
	}

	public void setMaker(String maker)
	{
		this.maker = maker;
	}

	public String getTag()
	{
		return tag;
	}

	public void setTag(String tag)
	{
		this.tag = tag;
	}

	public Date getReOpenDate()
	{
		return reOpenDate;
	}

	public void setReOpenDate(Date reOpenDate)
	{
		this.reOpenDate = reOpenDate;
	}

	public Long getLinkId()
	{
		return linkId;
	}

	public void setLinkId(Long linkId)
	{
		this.linkId = linkId;
	}

	public Integer getPrevResponseCntr()
	{
		return prevResponseCntr;
	}

	public void setPrevResponseCntr(Integer prevResponseCntr)
	{
		this.prevResponseCntr = prevResponseCntr;
	}

	public Date getLastActionTime()
	{
		return lastActionTime;
	}

	public void setLastActionTime(Date lastActionTime)
	{
		this.lastActionTime = lastActionTime;
	}

	public String getLastActionby()
	{
		return lastActionby;
	}

	public void setLastActionby(String lastActionby)
	{
		this.lastActionby = lastActionby;
	}

	public int getConvCount()
	{
		return convCount;
	}

	public void setConvCount(int convCount)
	{
		this.convCount = convCount;
	}

	public Date getResolveTime()
	{
		return resolveTime;
	}

	public void setResolveTime(Date resolveTime)
	{
		this.resolveTime = resolveTime;
	}

	public String getResolver()
	{
		return resolver;
	}

	public void setResolver(String resolver)
	{
		this.resolver = resolver;
	}

	public String getRootCause()
	{
		return rootCause;
	}

	public void setRootCause(String rootCause)
	{
		this.rootCause = rootCause;
	}

	public String getProcessingRegion()
	{
		return processingRegion;
	}

	public void setProcessingRegion(String processingRegion)
	{
		this.processingRegion = processingRegion;
	}

	public Long getQueryCount()
	{
		return queryCount;
	}

	public void setQueryCount(Long queryCount)
	{
		this.queryCount = queryCount;
	}

	public Long getResponseTimeQMA()
	{
		return responseTimeQMA;
	}

	public void setResponseTimeQMA(Long responseTimeQMA)
	{
		this.responseTimeQMA = responseTimeQMA;
	}

	public Integer getReplyCountQMA()
	{
		return replyCountQMA;
	}

	public void setReplyCountQMA(Integer replyCountQMA)
	{
		this.replyCountQMA = replyCountQMA;
	}

	public Date getLatestConversationTime()
	{
		return latestConversationTime;
	}

	public void setLatestConversationTime(Date latestConversationTime)
	{
		this.latestConversationTime = latestConversationTime;
	}

	public String getInquirySource()
	{
		return inquirySource;
	}

	public void setInquirySource(String inquirySource)
	{
		this.inquirySource = inquirySource;
	}

	public String getInquiryRefSent()
	{
		return inquiryRefSent;
	}

	public void setInquiryRefSent(String inquiryRefSent)
	{
		this.inquiryRefSent = inquiryRefSent;
	}

	public Long getTotalResolveTimeQMA()
	{
		return totalResolveTimeQMA;
	}

	public void setTotalResolveTimeQMA(Long totalResolveTimeQMA)
	{
		this.totalResolveTimeQMA = totalResolveTimeQMA;
	}

	public Integer getResolveCountQMA()
	{
		return resolveCountQMA;
	}

	public void setResolveCountQMA(Integer resolveCountQMA)
	{
		this.resolveCountQMA = resolveCountQMA;
	}

	public Integer getClientChaseCounter()
	{
		return clientChaseCounter;
	}

	public void setClientChaseCounter(Integer clientChaseCounter)
	{
		this.clientChaseCounter = clientChaseCounter;
	}

	public String getIsLastConvToExtEmail()
	{
		return isLastConvToExtEmail;
	}

	public void setIsLastConvToExtEmail(String isLastConvToExtEmail)
	{
		this.isLastConvToExtEmail = isLastConvToExtEmail;
	}

	public String getLock()
	{
		return lock;
	}

	public void setLock(String lock)
	{
		this.lock = lock;
	}

	public String getLockedBy()
	{
		return lockedBy;
	}

	public void setLockedBy(String lockedBy)
	{
		this.lockedBy = lockedBy;
	}

	public Date getLockedDate()
	{
		return lockedDate;
	}

	public void setLockedDate(Date lockedDate)
	{
		this.lockedDate = lockedDate;
	}
	public String getIsConvCountEscalation()
	{
		return isConvCountEscalation;
	}

	public void setIsConvCountEscalation(String isConvCountEscalation)
	{
		this.isConvCountEscalation = isConvCountEscalation;
	}

	public String getIsClientChaseEscalation()
	{
		return isClientChaseEscalation;
	}

	public void setIsClientChaseEscalation(String isClientChaseEscalation)
	{
		this.isClientChaseEscalation = isClientChaseEscalation;
	}

	public String getIsSubjectEscalation()
	{
		return isSubjectEscalation;
	}

	public void setIsSubjectEscalation(String isSubjectEscalation)
	{
		this.isSubjectEscalation = isSubjectEscalation;
	}

	public String getGeneralEscalationReason()
	{
		return generalEscalationReason;
	}

	public void setGeneralEscalationReason(String generalEscalationReason)
	{
		this.generalEscalationReason = generalEscalationReason;
	}

	public String getResponseTimeEscalationReason()
	{
		return responseTimeEscalationReason;
	}

	public void setResponseTimeEscalationReason(String responseTimeEscalationReason)
	{
		this.responseTimeEscalationReason = responseTimeEscalationReason;
	}

	public Integer getLatestClientChaseCounter()
	{
		return latestClientChaseCounter;
	}

	public void setLatestClientChaseCounter(Integer latestClientChaseCounter)
	{
		this.latestClientChaseCounter = latestClientChaseCounter;
	}

	public Date getResponseTimeNextEscalation()
	{
		return responseTimeNextEscalation;
	}

	public String getResponseTimeEscalationFlag()
	{
		return responseTimeEscalationFlag;
	}

	public void setResponseTimeNextEscalation(Date responseTimeNextEscalation)
	{
		this.responseTimeNextEscalation = responseTimeNextEscalation;
	}

	public void setResponseTimeEscalationFlag(String responseTimeEscalationFlag)
	{
		this.responseTimeEscalationFlag = responseTimeEscalationFlag;
	}

	public String getSoeId()
	{
		return this.soeId;
	}

	public void setSoeId(String soeId)
	{
		this.soeId=soeId;
	}

	public Integer getPrevConvCount()
	{
		return prevConvCount;
	}

	public void setPrevConvCount(Integer prevConvCount)
	{
		this.prevConvCount = prevConvCount;
	}

	public Boolean getIsMakerCheckerEnabled()
	{
		return isMakerCheckerEnabled;
	}

	public void setIsMakerCheckerEnabled(Boolean isMakerCheckerEnabled)
	{
		this.isMakerCheckerEnabled = isMakerCheckerEnabled;
	}

	public String getWorkflowStatus()
	{
		return workflowStatus;
	}

	public void setWorkflowStatus(String workflowStatus)
	{
		this.workflowStatus = workflowStatus;
	}

	public FollowUp getFollowUp()
	{
		return followUp;
	}

	public void setFollowUp(FollowUp followUp)
	{
		this.followUp = followUp;
	}

	public String getIspendingApprovalEscalation() {
		return ispendingApprovalEscalation;
	}

	public void setIspendingApprovalEscalation(String ispendingApprovalEscalation) {
		this.ispendingApprovalEscalation = ispendingApprovalEscalation;
	}

	public Date getReAgeDate()
	{
		return reAgeDate;
	}

	public void setReAgeDate(Date ageSplitDate)
	{
		this.reAgeDate = ageSplitDate;
	}

	public Date getReAgeSentDate()
	{
		return reAgeSentDate;
	}

	public void setReAgeSentDate(Date reAgeSentDate)
	{
		this.reAgeSentDate = reAgeSentDate;
	}

	/**
	 * @return the isManualEscalation
	 */
	public String getIsManualEscalation() {
		return isManualEscalation;
	}

	/**
	 * @param isManualEscalation the isManualEscalation to set
	 */
	public void setIsManualEscalation(String isManualEscalation) {
		this.isManualEscalation = isManualEscalation;
	}

	/**
	 * @return the manualEscalationReason
	 */
	public String getManualEscalationReason() {
		return manualEscalationReason;
	}

	/**
	 * @param manualEscalationReason the manualEscalationReason to set
	 */
	public void setManualEscalationReason(String manualEscalationReason) {
		this.manualEscalationReason = manualEscalationReason;
	}

	public Set<String> getPendingExternalDomains()
	{
		return pendingExternalDomains;
	}

	public void setPendingExternalDomains(Set<String> pendingExternalDomains)
	{
		this.pendingExternalDomains = pendingExternalDomains;
	}

	public String getUiWorkflowStatus()
	{
		return uiWorkflowStatus;
	}

	public void setUiWorkflowStatus(String uiWorkflowStatus)
	{
		this.uiWorkflowStatus = uiWorkflowStatus;
	}

	/**
	 * @return the suggestionIndicator
	 */
	public String getSuggestionIndicator() {
		return suggestionIndicator;
	}

	/**
	 * @param suggestionIndicator the suggestionIndicator to set
	 */
	public void setSuggestionIndicator(String suggestionIndicator) {
		this.suggestionIndicator = suggestionIndicator;
	}

	
	public String getHasOwnership() {
		return hasOwnership;
	}

	
	public void setHasOwnership(String hasOwnership) {
		this.hasOwnership = hasOwnership;
	}

	
	public String getResolvedByOtherGroupOwnership() {
		return resolvedByOtherGroupOwnership;
	}

	
	public void setResolvedByOtherGroupOwnership(String resolvedByOtherGroupOwnership) {
		this.resolvedByOtherGroupOwnership = resolvedByOtherGroupOwnership;
	}


	public String getIsAckEscalation()
	{
		return isAckEscalation;
	}

	public void setIsAckEscalation(String isAckEscalation)
	{
		this.isAckEscalation = isAckEscalation;
	}

	public String getAckEscalationBy()
	{
		return ackEscalationBy;
	}

	public void setAckEscalationBy(String ackEscalationBy)
	{
		this.ackEscalationBy = ackEscalationBy;
	}

	public Date getAckEscalationTime()
	{
		return ackEscalationTime;
	}

	public void setAckEscalationTime(Date ackEscalationTime)
	{
		this.ackEscalationTime = ackEscalationTime;
	}


	public boolean isEscalation()
	{
		return isEscalation;
	}

	public void setEscalation(boolean isEscalation)
	{
		this.isEscalation = isEscalation;
	}
	
	public List<CustomClientCategoryDetails> getCustomClientCategory() {
		return customClientCategory;
	}

	public void setCustomClientCategory(List<CustomClientCategoryDetails> customClientCategory) {
		this.customClientCategory = customClientCategory;
	}

	public Date getModDateForActionStatistics() {
		return modDateForActionStatistics;
	}

	public void setModDateForActionStatistics(Date modDateForActionStatistics) {
		this.modDateForActionStatistics = modDateForActionStatistics;
	}

	public List<Long> getNominatedBy() {
		return nominatedBy;
	}

	public void setNominatedBy(List<Long> nominatedBy) {
		this.nominatedBy = nominatedBy;
	}

	public List<Long> getNominatedTo() {
		return nominatedTo;
	}

	public void setNominatedTo(List<Long> nominatedTo) {
		this.nominatedTo = nominatedTo;
	}

	public String getNominatingReason() {
		return nominatingReason;
	}

	public void setNominatingReason(String nominatingReason) {
		this.nominatingReason = nominatingReason;
	}

	public String getNominationRejectionReason() {
		return nominationRejectionReason;
	}

	public void setNominationRejectionReason(String nominationRejectingReason) {
		this.nominationRejectionReason = nominationRejectingReason;
	}

	public boolean isHasNominatedOwnership() {
		return hasNominatedOwnership;
	}
	
	public void setHasNominatedOwnership(boolean hasNominatedOwnership) {
		this.hasNominatedOwnership = hasNominatedOwnership;
	}
	public Long getUnassignedTimeInMins() {
		return unassignedTimeInMins;
	}

	public void setUnassignedTimeInMins(Long unassignedTimeInMins) {
		this.unassignedTimeInMins = unassignedTimeInMins;
	}
	
	public String getSnoozeAction() {
		return snoozeAction;
	}

	public void setSnoozeAction(String snoozeAction) {
		this.snoozeAction = snoozeAction;
	}

	public Long getResolutionTimeInMinutes() {
		return resolutionTimeInMinutes;
	}

	public void setResolutionTimeInMinutes(Long resolutionTimeInMinutes) {
		this.resolutionTimeInMinutes = resolutionTimeInMinutes;
	}

	public Long getResponseTimeInMinutes() {
		return responseTimeInMinutes;
	}

	public void setResponseTimeInMinutes(Long responseTimeInMinutes) {
		this.responseTimeInMinutes = responseTimeInMinutes;
	}

	public Date getFirstResponseTime() {
		return firstResponseTime;
	}

	public void setFirstResponseTime(Date firstResponseTime) {
		this.firstResponseTime = firstResponseTime;
	}

	public Long getFirstResponseInMinutes() {
		return firstResponseInMinutes;
	}

	public void setFirstResponseInMinutes(Long firstResponseInMinutes) {
		this.firstResponseInMinutes = firstResponseInMinutes;
	}

	public String getAttchFlag() {
		return attchFlag;
	}

	public void setAttchFlag(String attchFlag) {
		this.attchFlag = attchFlag;
	}

	public String getIsLatestResponseFromNonQMA() {
		return isLatestResponseFromNonQMA;
	}

	public void setIsLatestResponseFromNonQMA(String isLatestResponseFromNonQMA) {
		this.isLatestResponseFromNonQMA = isLatestResponseFromNonQMA;
	}

	public Date getFirstNonChaserResponseTimeByExternal() {
		return firstNonChaserResponseTimeByExternal;
	}

	public void setFirstNonChaserResponseTimeByExternal(Date firstNonChaserResponseTimeByExternal) {
		this.firstNonChaserResponseTimeByExternal = firstNonChaserResponseTimeByExternal;
	}

	public Long getCitiResponseTime() {
		return citiResponseTime;
	}

	public void setCitiResponseTime(Long citiResponseTime) {
		this.citiResponseTime = citiResponseTime;
	}

	public Integer getCitiReplyCountFromQMA() {
		return citiReplyCountFromQMA;
	}

	public void setCitiReplyCountFromQMA(Integer citiReplyCountFromQMA) {
		this.citiReplyCountFromQMA = citiReplyCountFromQMA;
	}


	public String getSnoozeDetails() {
		return snoozeDetails;
	}

	public void setSnoozeDetails(String snoozeDetails) {
		this.snoozeDetails = snoozeDetails;
	}

	public Date getOwnershipAcceptedTime() {
		return ownershipAcceptedTime;
	}

	public void setOwnershipAcceptedTime(Date ownershipAcceptedTime) {
		this.ownershipAcceptedTime = ownershipAcceptedTime;
	}

	public String getIsWorkflowEverSnoozed() {
		return isWorkflowEverSnoozed;
	}

	public void setIsWorkflowEverSnoozed(String isWorkflowEverSnoozed) {
		this.isWorkflowEverSnoozed = isWorkflowEverSnoozed;
	}
	
	public List<String> getPersonalFolders() {
		return personalFolders;
	}

	public void setPersonalFolders(List<String> personalFolders) {
		this.personalFolders = personalFolders;

	}

	public String getResolveAllocation() {
		return resolveAllocation;
	}

	public void setResolveAllocation(String resolveAllocation) {
		this.resolveAllocation = resolveAllocation;
	}

	public String getIsLatestReplyFromCurrentWorkflowGrp() {
		return isLatestReplyFromCurrentWorkflowGrp;
	}

	public void setIsLatestReplyFromCurrentWorkflowGrp(String isLatestReplyFromCurrentWorkflowGrp) {
		this.isLatestReplyFromCurrentWorkflowGrp = isLatestReplyFromCurrentWorkflowGrp;
	}

	public String getAutoAssigned() {
		return autoAssigned;
	}

	public void setAutoAssigned(String autoAssigned) {
		this.autoAssigned = autoAssigned;
	}

	public String getAutoAssignedAction() {
		return autoAssignedAction;
	}

	public void setAutoAssignedAction(String autoAssignedAction) {
		this.autoAssignedAction = autoAssignedAction;
	}

	public String getLatestConversationPreviewText() {
		return latestConversationPreviewText;
	}

	public void setLatestConversationPreviewText(String latestConversationPreviewText) {
		this.latestConversationPreviewText = latestConversationPreviewText;
	}

	public String getLatestSenderDomain() {
		return latestSenderDomain;
	}

	public String getInquirySubStatus() {
		return inquirySubStatus;
	}

	public void setInquirySubStatus(String inquirySubStatus) {
		this.inquirySubStatus = inquirySubStatus;
	}

	public void setLatestSenderDomain(String latestSenderDomain) {
		this.latestSenderDomain = latestSenderDomain;
	}

	public String getLatestExchangeItemId() {
		return latestExchangeItemId;
	}

	public void setLatestExchangeItemId(String latestExchangeItemId) {
		this.latestExchangeItemId = latestExchangeItemId;
	}

	public String getIsSubStatusPendingInternal() {
		return isSubStatusPendingInternal;
	}

	public void setIsSubStatusPendingInternal(String isSubStatusPendingInternal) {
		this.isSubStatusPendingInternal = isSubStatusPendingInternal;
	}

	public String getPrevInqSubStatus() {
		return prevInqSubStatus;
	}

	public void setPrevInqSubStatus(String prevInqSubStatus) {
		this.prevInqSubStatus = prevInqSubStatus;
	}

	public String getIntentSuggestionName() {
		return intentSuggestionName;
	}

	public void setIntentSuggestionName(String intentSuggestionName) {
		this.intentSuggestionName = intentSuggestionName;
	}

	public String getIntentTimeToVD() {
		return intentTimeToVD;
	}

	public void setIntentTimeToVD(String intentTimeToVD) {
		this.intentTimeToVD = intentTimeToVD;
	}

	public String getUserIntentSuggestionName() {
		return userIntentSuggestionName;
	}

	public void setUserIntentSuggestionName(String userIntentSuggestionName) {
		this.userIntentSuggestionName = userIntentSuggestionName;
	}
}