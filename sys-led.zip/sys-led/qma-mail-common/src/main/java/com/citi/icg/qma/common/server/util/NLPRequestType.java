package com.citi.icg.qma.common.server.util;

public enum NLPRequestType {

	C("Custody"),// Global NLP request Type started with custody implementation
    S("MarketSecurity"), // NLP request from Security Services
    A("Autorouting"),
    I("IntentDetection"); // Customer Intent Detection
	
	private String nlpRequestType;

	NLPRequestType(String nlpRequestType) {
		this.nlpRequestType = nlpRequestType;
	}
	public String getNlpReqTypeName() {
        return nlpRequestType;
    }
}
