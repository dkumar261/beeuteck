package com.citi.icg.qma.common.messagebus.entity;

public class Attachments {

	private String id;
	private String name;
	private String downLoadLink;
	
	public Attachments() {
		super();
		// Auto-generated constructor stub
	}
	
	public Attachments(String id, String name, String downLoadLink) {
		super();
		this.id = id;
		this.name = name;
		this.downLoadLink = downLoadLink;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getDownLoadLink() {
		return downLoadLink;
	}

	public void setDownLoadLink(String downLoadLink) {
		this.downLoadLink = downLoadLink;
	}
}
