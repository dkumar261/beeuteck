package com.citi.icg.qma.common.messagebus.entity;


public class Payload {

	private Long inquiryId;
	private Long conversationId;
	private String subject;
	private String crtDate;
	private String action;
	private String status;
	private String clientId;
	private String clientName;
	private String downLoadEmailUri;
	private Recepients[] recipients;
	private Attachments[] attachments;
	private String[] baseAccounts; 
	private String entityType;
	private String[] entityIds;
	
	public Payload() {
		super();
	}
	public Long getInquiryId() {
		return inquiryId;		
	}
	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}
	public Long getConversationId() {
		return conversationId;
	}
	public void setConversationId(Long conversationId) {
		this.conversationId = conversationId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public Attachments[] getAttachments() {
		return attachments;
	}
	public void setAttachments(Attachments[] attachments) {
		this.attachments = attachments;
	}
	
	public String getCrtDate() {
		return crtDate;
	}
	public void setCrtDate(String crtDate) {
		this.crtDate = crtDate;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getDownLoadEmailUri() {
		return downLoadEmailUri;
	}
	public void setDownLoadEmailUri(String downLoadEmailUri) {
		this.downLoadEmailUri = downLoadEmailUri;
	}
	public Recepients[] getRecipients() {
		return recipients;
	}
	public void setRecipients(Recepients[] recipients) {
		this.recipients = recipients;
	}
	public String[] getBaseAccounts() {
		return baseAccounts;
	}
	public void setBaseAccounts(String[] baseAccounts) {
		this.baseAccounts = baseAccounts;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String[] getEntityIds() {
		return entityIds;
	}
	public void setEntityIds(String[] entityIds) {
		this.entityIds = entityIds;
	}
	
}
