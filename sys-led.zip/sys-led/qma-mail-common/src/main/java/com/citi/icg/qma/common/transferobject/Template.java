package com.citi.icg.qma.common.transferobject;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class Template implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6935344466205494956L;
	private String templateName;
	private String templateContent;
	
	//[C153176-1140]-Templates enhancement
	private String templateSubject;
	private List<UserGroupTO> toList;
	private List<UserGroupTO> ccList;
	private List<UserGroupTO> bccList;
	private List<UserGroupTO> shareToGrpList;
	private Boolean active;
	private Date modified;
	private String modifiedBy;
	private Boolean mergeRecipients;
	/**
	 * @return the templateName
	 */
	public String getTemplateName()
	{
		return templateName;
	}
	/**
	 * @param templateName the templateName to set
	 */
	public void setTemplateName(String templateName)
	{
		this.templateName = templateName;
	}
	/**
	 * @return the templateContent
	 */
	public String getTemplateContent()
	{
		return templateContent;
	}
	/**
	 * @param templateContent the templateContent to set
	 */
	public void setTemplateContent(String templateContent)
	{
		this.templateContent = templateContent;
	}
	
	/**
	 * @return the templateSubject
	 */
	public String getTemplateSubject()
	{
		return templateSubject;
	}
	/**
	 * @param templateSubject the templateSubject to set
	 */
	public void setTemplateSubject(String templateSubject)
	{
		this.templateSubject = templateSubject;
	}
	
	/**
	 * @return the toList
	 */
	public List<UserGroupTO> getToList()
	{
		return toList;
	}
	/**
	 * @param toList the toList to set
	 */
	public void setToList(List<UserGroupTO> toList)
	{
		this.toList = toList;
	}
	/**
	 * @return the ccList
	 */
	public List<UserGroupTO> getCcList()
	{
		return ccList;
	}
	/**
	 * @param ccList the ccList to set
	 */
	public void setCcList(List<UserGroupTO> ccList)
	{
		this.ccList = ccList;
	}
	/**
	 * @return the bccList
	 */
	public List<UserGroupTO> getBccList()
	{
		return bccList;
	}
	/**
	 * @param bccList the bccList to set
	 */
	public void setBccList(List<UserGroupTO> bccList)
	{
		this.bccList = bccList;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((templateName == null) ? 0 : templateName.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Template other = (Template) obj;
		if (templateName == null)
		{
			if (other.templateName != null)
				return false;
		}
		else if (!templateName.equalsIgnoreCase(other.templateName))
			return false;
		return true;
	}
	/**
	 * @return the shareToGrpList
	 */
	public List<UserGroupTO> getShareToGrpList()
	{
		return shareToGrpList;
	}
	/**
	 * @param shareToGrpList the shareToGrpList to set
	 */
	public void setShareToGrpList(List<UserGroupTO> shareToGrpList)
	{
		this.shareToGrpList = shareToGrpList;
	}
	/**
	 * @return the active
	 */
	public Boolean getActive()
	{
		return active;
	}
	/**
	 * @param active the active to set
	 */
	public void setActive(Boolean active)
	{
		this.active = active;
	}
	/**
	 * @return the modified
	 */
	public Date getModified()
	{
		return modified;
	}
	/**
	 * @param modified the modified to set
	 */
	public void setModified(Date modified)
	{
		this.modified = modified;
	}
	/**
	 * @return the modifiedBy
	 */
	public String getModifiedBy()
	{
		return modifiedBy;
	}
	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy)
	{
		this.modifiedBy = modifiedBy;
	}
	public Boolean isMergeRecipients() {
		return mergeRecipients;
	}
	public void setMergeRecipients(Boolean mergeRecipients) {
		this.mergeRecipients = mergeRecipients;
	}
	
	
}
