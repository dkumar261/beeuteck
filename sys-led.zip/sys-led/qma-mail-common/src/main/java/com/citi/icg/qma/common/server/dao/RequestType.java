package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Embedded;

@Embedded
public class RequestType
{
	private String reqType;//Sonar Fix -- Rename the field as it is same as hiding class name

	public String getRequestType() {
		return reqType;
	}

	public void setRequestType(String requestType) {
		this.reqType = requestType;
	}
	
	
}
