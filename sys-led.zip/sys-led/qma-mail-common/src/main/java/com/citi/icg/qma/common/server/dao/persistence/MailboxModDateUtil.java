package com.citi.icg.qma.common.server.dao.persistence;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

public class MailboxModDateUtil {
	
	private static final String DEFAULT = "Default";

	private static final String VIEWS_CONFIG = "viewsConfig";

	private static final String PERFORMANCE_FLAG = "performanceFlag";

	private static final String DEFAULT_VIEW_PERFORMANCE_CONFIG = "defaultViewPerformanceConfig";

	private static final String VIEW_NAME_SENT = "sent";

	private static final String VIEW_NAME_OUTBOX = "outbox";

	private static final String VIEW_NAME_RESOLVED = "resolved";

	private static final String IS_DATE_RANGE = "isDateRange";

	private static final Logger logger = LoggerFactory.getLogger(MailboxModDateUtil.class);
	
	private static final String VIEW_TYPE = "viewType";

	private static final String CUSTOM_VIEW = "CustomView";





	/**
	 * @param soeId
	 * @param inputJsonObj
	 * @param viewName
	 * @return 
	 */
	public static Date getModDateAsPerDateConfig(String soeId, BasicDBObject inputJsonObj, String viewName, boolean isOneDayCount) {
		Date dateRangeModDate = getDateRangeModDate(24);//Set default date 24 months data
		
		/*[C170665-1061] - get only today's count for resolved and sent*/
		if(isOneDayCount &&  StringUtils.isNotEmpty(viewName) && (VIEW_NAME_RESOLVED.equalsIgnoreCase(viewName)  || VIEW_NAME_SENT.equalsIgnoreCase(viewName)
					|| VIEW_NAME_OUTBOX.equalsIgnoreCase(viewName) ) ) {
			dateRangeModDate = GenericUtility.getTodaysDate();
			if(dateRangeModDate != null) {
				return dateRangeModDate;
			}
		}
		
		if(null != inputJsonObj && null != inputJsonObj.get(IS_DATE_RANGE)) {
			//if date range available in request from UI
			int dateRangeInMonths = inputJsonObj.getInt(IS_DATE_RANGE);
			if(0 < dateRangeInMonths) {
				dateRangeModDate = getDateRangeModDate(dateRangeInMonths);
			}
		}else {
			//If date not preset then check for user preference
			int dateRangeInMonths = getDateRangeFromUser(soeId, viewName, inputJsonObj);
			if(0 < dateRangeInMonths) {
				dateRangeModDate = getDateRangeModDate(dateRangeInMonths);
			}else {
				//Default date range from config
				if(null != inputJsonObj && null != inputJsonObj.get(VIEW_TYPE) && "-1".equals(inputJsonObj.get(VIEW_TYPE).toString())) {
					viewName = "CustomViews";
				}
				dateRangeInMonths = getDateConfigDefault(viewName);
				if(0 < dateRangeInMonths) {
					dateRangeModDate = getDateRangeModDate(dateRangeInMonths);
				}else {
					dateRangeInMonths = getDateConfigDefault(DEFAULT);
					if(0 < dateRangeInMonths) {
						dateRangeModDate = getDateRangeModDate(dateRangeInMonths);
					}
				}
			}
		}
		return dateRangeModDate;
	}
	

	public static int getDateConfigDefault(String viewName) {
		int noOfMonths = 0;
		try {
			Config config = null;
			if(null != QMACacheFactory.getCache().getConfigById(DEFAULT_VIEW_PERFORMANCE_CONFIG)){
				config = QMACacheFactory.getCache().getConfigById(DEFAULT_VIEW_PERFORMANCE_CONFIG);
			}
			boolean performanceFlag = false;
			Map<String, Object> defaultViewPerformanceConfig = null;
			if(null != config && null !=  config.getDefaultViewPerformanceConfig() 
					&& null != config.getDefaultViewPerformanceConfig().get(PERFORMANCE_FLAG) ){
				defaultViewPerformanceConfig = config.getDefaultViewPerformanceConfig();
				performanceFlag = (boolean) defaultViewPerformanceConfig.get(PERFORMANCE_FLAG);
			}
			BasicDBList viewsConfig = null;
			if(performanceFlag && null != defaultViewPerformanceConfig.get(VIEWS_CONFIG)){
				viewsConfig = (BasicDBList) defaultViewPerformanceConfig.get(VIEWS_CONFIG);
			}
			if(performanceFlag && null != viewsConfig && !viewsConfig.isEmpty()){
				noOfMonths = getNoOfMonthsForViews(viewName, viewsConfig, noOfMonths);
			}
			
		} catch (Exception e) {
			logger.warn("Some issue with getDateConfigDefault for viewName:"+viewName,e);
		}
		return noOfMonths;
	}
	/**
	 * @param dateRangeInMonths
	 * @return 
	 */
	public static Date getDateRangeModDate(int dateRangeInMonths) {
		Date calculatedTime = null;
		try {

			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.DAY_OF_MONTH, 1);
			cal.set(Calendar.HOUR, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.add(Calendar.MONTH, -dateRangeInMonths);
			calculatedTime = cal.getTime();
		} catch (Exception ex) {
			logger.warn("Issue in calculating date as per months provided dateRangeInMonths:"+dateRangeInMonths, ex);
		}
		return calculatedTime;
	}
	
	private static int getDateRangeFromUser(String soeId, String viewName, BasicDBObject inputJsonObj) {
		int dateRangeInMonths = 0;

		try {
			if(!StringUtils.isEmpty(soeId)) {
				User user = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase());
				if (null != user && null != user.getViewDateRangeConfig()) {
					List<Map<String, Object>> dateRangeList = user.getViewDateRangeConfig();
					if(null != inputJsonObj && null != inputJsonObj.get(VIEW_TYPE) && "-1".equals(inputJsonObj.get(VIEW_TYPE).toString())
							&& null != dateRangeList && dateRangeList.size() > 0) {
						for(Map<String, Object> viewConfig : dateRangeList) {
							if(null != viewConfig.get("viewName") && null != viewConfig.get("months") && CUSTOM_VIEW.equalsIgnoreCase(viewConfig.get("viewName").toString())) {
								dateRangeInMonths = (int) viewConfig.get("months");
								break;
							}
						}
					}
					else if (null != dateRangeList && dateRangeList.size() > 0) {
						for(Map<String, Object> viewConfig : dateRangeList) {
							if(null != viewConfig.get("viewName") && null != viewConfig.get("months") && viewName.equalsIgnoreCase(viewConfig.get("viewName").toString())) {
								dateRangeInMonths = (int) viewConfig.get("months");
								break;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			logger.warn("Facing problem while getDateRangeFromUser:"+soeId +" for viewName:"+ viewName, e);
		}
		return dateRangeInMonths;
	}
	
	/**
	 * @param viewName
	 * @param viewsConfig
	 * @param noOfMonths
	 * @param logger 
	 * @return
	 */
	public static int getNoOfMonthsForViews(String viewName, BasicDBList viewsConfig, int noOfMonths) {
		try {
			for(Object viewObj : viewsConfig) {
				if(null != viewObj) {
					String vName = null != ((BasicDBObject)viewObj).get("viewName") ? ((BasicDBObject)viewObj).getString("viewName") : "";
					if(viewName.equalsIgnoreCase(vName)) {
						noOfMonths = null != ((BasicDBObject)viewObj).get("months") ? ((BasicDBObject)viewObj).getInt("months") : 0;
						break;
					}
				}
			}
		} catch (Exception e) {
			logger.warn("Issue getting NoOfMonthsForViews for view : "+viewName, e);
		}
		return noOfMonths;
	}
}
