package com.citi.icg.qma.common.transferobject;

public class AssignedOwnersByAgeBandResponseTime
{
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private String ageBand;
	private int count;
	private String assignedOwner;
	private String group;
	
	public String getAgeBand() {
		return ageBand;
	}
	public void setAgeBand(String ageBand) {
		this.ageBand = ageBand;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getAssignedOwner() {
		return assignedOwner;
	}
	public void setAssignedOwner(String assignedOwner) {
		this.assignedOwner = assignedOwner;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}

}
