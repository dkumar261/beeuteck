package com.citi.icg.qma.common.server.dao;

public class GirdColumns
{

	String title;
	String field;
	int width;
	String type;
	String format;

	public GirdColumns(String title, String field, int width, String type, String format)
	{
		super();
		this.title = title;
		this.field = field;
		this.width = width;
		this.type = type;
		this.format = format;
	}

	public String getTitle()
	{
		return title;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public String getField()
	{
		return field;
	}

	public void setField(String field)
	{
		this.field = field;
	}

	public int getWidth()
	{
		return width;
	}

	public void setWidth(int width)
	{
		this.width = width;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getFormat()
	{
		return format;
	}

	public void setFormat(String format)
	{
		this.format = format;
	}

}