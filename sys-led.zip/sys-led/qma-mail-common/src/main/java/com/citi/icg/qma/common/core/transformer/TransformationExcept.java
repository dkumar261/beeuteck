package com.citi.icg.qma.common.core.transformer;

import org.apache.commons.collections4.FunctorException;

public class TransformationExcept extends FunctorException
{

    public TransformationExcept()
    {
        super();
    }

    public TransformationExcept(String arg0, Throwable arg1)
    {
        super(arg0, arg1);
    }

    public TransformationExcept(String arg0)
    {
        super(arg0);
    }

    public TransformationExcept(Throwable arg0)
    {
        super(arg0);
    }

}
