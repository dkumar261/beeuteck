package com.citi.icg.qma.common.server.dao;

import java.util.List;
import java.util.Set;

import com.citi.icg.qma.common.core.util.MsgSourceType;

import dev.morphia.annotations.Embedded;
import dev.morphia.annotations.Entity;

@Entity(value = "Inquiry", noClassnameStored = true)
public class Inquiry extends BaseEntity
{

	private String allToCCGrps;
	private String attchFlag;
	private String audFlag;
	private String latestEmail;
	private String latestGroup;
	private Long latestGroupId;
	private Long conversCount;
	private String latestUserId;
	private String latestUserName;
	private String action;
	private List<Note> userNotes;// This will not be part of migration
	private String status;
	private String latestToCCGroups;
	private String latestToCCUser;
	private Long nlpRPTCocnversationId;
	private Long nlpRPTSuggestionId;
	private boolean nlpRPTFreeze;

	private String notesFlag;
	private String openGroups;
	private String openUsers;
	private Long origGroupId;
	private String origGroupName;
	private String origSubject;
	private String origType;
	private String origEmail;
	private String origUserId;
	private String origUserName;
	private String origMessageId;
	private String recallInd;
	private String subject;
	private String urgentFlag;// It is available in conversation level also
	private List<UserFolders> userFolders;
	private List<String> readBy;
	private String recentConversationSnap;// 250 chars of latest conversation
	private String requestTypeStr; // Concatenation of all groups req types. Added 10th OCT
	private MsgSourceType sourceType;
	
	@Embedded
	private List<Workflow> workflows;

	@Embedded
	private List<WorkflowAudit> workflowAudit;

	private String clientName;
	private String gpNum;
	private String gpName;
	private String gfcid; //[C153176-918] - QMA GP Num column Refactoring	
	private String gfcName;
	
	// C170665-5 | Sk Account Number and Branch which getting populated from AMCAR
	private String skAccountNo;
	private String branch;
	
	private Long exceptionId;
	private Set<String> approvedExternalDomains;//C153176-1549
	private String clientPriority;
	private String nlpRPTType;
	
	private String memo;
	private String updated;
	private List<String> notify;
	private Long draftId;
	private String snoozedBy;
	private String snoozeDuration;
	//symphony sreamId
	private String symphonyStreamId;
	//symphony chatroom name
	private String symphonyChatroomName;
	//symphony chatroom member list
	private List<String> symphonyChatRoomMember;
	//to identify chatroom
	private String isSymphonyChatroom;
	
	//to store all the individual soeid list
	private List<String> memberList;
	//to store grouplist
	private List<Long> groupList;
	//to store exteranl user list
	private List<String> externalUserList;
	private boolean autoAssignmentAvailable;
	
	// to identify Taskize Bubble/Inquiry
	private String isTaskizeInquiry;
	private String bubbleId;
	private String origSrcSysId;
	//In future this field will be re-modified to use generic field like streamid
	private String taskizeInquiryId;
	
	public Inquiry()
	{
		super();
	}
	

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public List<String> getReadBy() {
		return readBy;
	}

	public void setReadBy(List<String> readBy) {
		this.readBy = readBy;
	}

	public List<Note> getUserNotes() {
		return userNotes;
	}

	public void setUserNotes(List<Note> userNotes) {
		this.userNotes = userNotes;
	}

	public Long getLatestGroupId() {
		return latestGroupId;
	}

	public void setLatestGroupId(Long latestGroupId) {
		this.latestGroupId = latestGroupId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getOrigGroupId() {
		return origGroupId;
	}

	public void setOrigGroupId(Long origGroupId) {
		this.origGroupId = origGroupId;
	}

	public String getOrigGroupName() {
		return origGroupName;
	}

	public void setOrigGroupName(String origGroupName) {
		this.origGroupName = origGroupName;
	}

	public String getOrigSubject() {
		return origSubject;
	}

	public void setOrigSubject(String origSubject) {
		this.origSubject = origSubject;
	}

	public String getOrigUserId() {
		return origUserId;
	}

	public void setOrigUserId(String origUserId) {
		this.origUserId = origUserId;
	}

	public String getOrigUserName() {
		return origUserName;
	}

	public void setOrigUserName(String origUserName) {
		this.origUserName = origUserName;
	}

	public String getOrigType() {
		return origType;
	}

	public void setOrigType(String origType) {
		this.origType = origType;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getLatestGroup() {
		return latestGroup;
	}

	public void setLatestGroup(String latestGroup) {
		this.latestGroup = latestGroup;
	}

	public String getNotesFlag() {
		return notesFlag;
	}

	public void setNotesFlag(String notesFlag) {
		this.notesFlag = notesFlag;
	}

	public String getLatestUserName() {
		return latestUserName;
	}

	public void setLatestUserName(String latestUserName) {
		this.latestUserName = latestUserName;
	}

	public String getLatestUserId() {
		return latestUserId;
	}

	public void setLatestUserId(String latestUserId) {
		this.latestUserId = latestUserId;
	}

	public String getLatestEmail() {
		return latestEmail;
	}

	public void setLatestEmail(String latestEmail) {
		this.latestEmail = latestEmail;
	}

	public String getAllToCCGrps() {
		return allToCCGrps;
	}

	public void setAllToCCGrps(String allToCCGrps) {
		this.allToCCGrps = allToCCGrps;
	}

	public String getAudFlag() {
		return audFlag;
	}

	public void setAudFlag(String audFlag) {
		this.audFlag = audFlag;
	}

	public String getOpenGroups() {
		return openGroups;
	}

	public void setOpenGroups(String openGroups) {
		this.openGroups = openGroups;
	}

	public String getAttchFlag() {
		return attchFlag;
	}

	public void setAttchFlag(String attchFlag) {
		this.attchFlag = attchFlag;
	}

	public String getUrgentFlag() {
		return urgentFlag;
	}

	public void setUrgentFlag(String urgentFlag) {
		this.urgentFlag = urgentFlag;
	}

	public String getRecentConversationSnap() {
		return recentConversationSnap;
	}

	public void setRecentConversationSnap(String recentConversationSnap) {
		this.recentConversationSnap = recentConversationSnap;
	}

	public String getOrigEmail() {
		return origEmail;
	}

	public void setOrigEmail(String origEmail) {
		this.origEmail = origEmail;
	}

	public String getRequestTypeStr() {
		return requestTypeStr;
	}

	public void setRequestTypeStr(String requestTypeStr) {
		this.requestTypeStr = requestTypeStr;
	}

	public String getOpenUsers() {
		return openUsers;
	}

	public void setOpenUsers(String openUsers) {
		this.openUsers = openUsers;
	}

	public String getLatestToCCUser() {
		return latestToCCUser;
	}

	public void setLatestToCCUser(String latestToCCUser) {
		this.latestToCCUser = latestToCCUser;
	}

	public String getLatestToCCGroups() {
		return latestToCCGroups;
	}

	public void setLatestToCCGroups(String latestToCCGroups) {
		this.latestToCCGroups = latestToCCGroups;
	}

	public Long getConversCount() {
		return conversCount;
	}

	public void setConversCount(Long conversCount) {
		this.conversCount = conversCount;
	}

	public String getRecallInd() {
		return recallInd;
	}

	public void setRecallInd(String recallInd) {
		this.recallInd = recallInd;
	}

	public List<UserFolders> getUserFolders() {
		return userFolders;
	}

	public void setUserFolders(List<UserFolders> userFolders) {
		this.userFolders = userFolders;
	}

	public List<WorkflowAudit> getWorkflowAudit() {
		return workflowAudit;
	}

	public void setWorkflowAudit(List<WorkflowAudit> workflowAudit) {
		this.workflowAudit = workflowAudit;
	}

	public List<Workflow> getWorkflows() {
		return workflows;
	}

	public void setWorkflows(List<Workflow> workflows) {
		this.workflows = workflows;
	}

	public String getClientName()
	{
		return clientName;
	}

	public void setClientName(String clientName)
	{
		this.clientName = clientName;
	}

	public String getGpNum()
	{
		return gpNum;
	}

	public void setGpNum(String gpNum)
	{
		this.gpNum = gpNum;
	}

	public String getGpName()
	{
		return gpName;
	}

	public void setGpName(String gpName)
	{
		this.gpName = gpName;
	}


	public String getGfcid()
	{
		return gfcid;
	}


	public void setGfcid(String gfcid)
	{
		this.gfcid = gfcid;
	}


	public String getGfcName()
	{
		return gfcName;
	}


	public void setGfcName(String gfcName)
	{
		this.gfcName = gfcName;
	}


	public Long getExceptionId()
	{
		return exceptionId;
	}


	public void setExceptionId(Long exceptionId)
	{
		this.exceptionId = exceptionId;
	}


	public Set<String> getApprovedExternalDomains()
	{
		return approvedExternalDomains;
	}


	public void setApprovedExternalDomains(Set<String> approvedExternalDomains)
	{
		this.approvedExternalDomains = approvedExternalDomains;
	}
	

	public Long getNlpRPTCocnversationId() {
		return nlpRPTCocnversationId;
	}


	public void setNlpRPTCocnversationId(Long nlpRPTCocnversationId) {
		this.nlpRPTCocnversationId = nlpRPTCocnversationId;
	}


	public boolean isNlpRPTFreeze() {
		return nlpRPTFreeze;
	}


	public void setNlpRPTFreeze(boolean nlpRPTFreeze) {
		this.nlpRPTFreeze = nlpRPTFreeze;
	}


	public Long getNlpRPTSuggestionId() {
		return nlpRPTSuggestionId;
	}


	public void setNlpRPTSuggestionId(Long nlpRPTSuggestionId) {
		this.nlpRPTSuggestionId = nlpRPTSuggestionId;
	}


	public String getClientPriority() {
		return clientPriority;
	}


	public void setClientPriority(String clientPriority) {
		this.clientPriority = clientPriority;
	}


	public String getNlpRPTType() {
		return nlpRPTType;
	}


	public void setNlpRPTType(String nlpRPTType) {
		this.nlpRPTType = nlpRPTType;
	}


	public String getMemo() {
		return memo;
	}


	public void setMemo(String memo) {
		this.memo = memo;
	}


	public String getUpdated() {
		return updated;
	}


	public void setUpdated(String updated) {
		this.updated = updated;
	}


	public List<String> getNotify() {
		return notify;
	}


	public void setNotify(List<String> notify) {
		this.notify = notify;
	}


	public Long getDraftId() {
		return draftId;
	}


	public void setDraftId(Long draftId) {
		this.draftId = draftId;
	}


	public String getSnoozedBy() {
		return snoozedBy;
	}


	public void setSnoozedBy(String snoozedBy) {
		this.snoozedBy = snoozedBy;
	}


	public String getSnoozeDuration() {
		return snoozeDuration;
	}


	public void setSnoozeDuration(String snoozeDuration) {
		this.snoozeDuration = snoozeDuration;
	}


	public String getSymphonyStreamId() {
		return symphonyStreamId;
	}


	public void setSymphonyStreamId(String symphonyStreamId) {
		this.symphonyStreamId = symphonyStreamId;
	}


	public String getSymphonyChatroomName() {
		return symphonyChatroomName;
	}


	public void setSymphonyChatroomName(String symphonyChatroomName) {
		this.symphonyChatroomName = symphonyChatroomName;
	}


	public List<String> getSymphonyChatRoomMember() {
		return symphonyChatRoomMember;
	}


	public void setSymphonyChatRoomMember(List<String> symphonyChatRoomMember) {
		this.symphonyChatRoomMember = symphonyChatRoomMember;
	}


	public String getIsSymphonyChatroom() {
		return isSymphonyChatroom;
	}


	public void setIsSymphonyChatroom(String isSymphonyChatroom) {
		this.isSymphonyChatroom = isSymphonyChatroom;
	}


	public List<String> getMemberList() {
		return memberList;
	}


	public void setMemberList(List<String> memberList) {
		this.memberList = memberList;
	}


	public List<Long> getGroupList() {
		return groupList;
	}


	public void setGroupList(List<Long> groupList) {
		this.groupList = groupList;
	}


	public List<String> getExternalUserList() {
		return externalUserList;
	}


	public void setExternalUserList(List<String> externalUserList) {
		this.externalUserList = externalUserList;
	}

	public String getOrigMessageId() {
		return origMessageId;
	}

	public void setOrigMessageId(String origMessageId) {
		this.origMessageId = origMessageId;
	}


	/**
	 * @return the skAccountNo
	 */
	public String getSkAccountNo() {
		return skAccountNo;
	}


	/**
	 * @param skAccountNo the skAccountNo to set
	 */
	public void setSkAccountNo(String skAccountNo) {
		this.skAccountNo = skAccountNo;
	}


	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}


	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}


	public MsgSourceType getSourceType() {
		return sourceType;
	}

	public void setSourceType(MsgSourceType sourceType) {
		this.sourceType = sourceType;
	}


	public boolean isAutoAssignmentAvailable() {
		return autoAssignmentAvailable;
	}


	public void setAutoAssignmentAvailable(boolean autoAssignmentAvailable) {
		this.autoAssignmentAvailable = autoAssignmentAvailable;
	}


	public String getIsTaskizeInquiry() {
		return isTaskizeInquiry;
	}


	public void setIsTaskizeInquiry(String isTaskizeInquiry) {
		this.isTaskizeInquiry = isTaskizeInquiry;
	}


	public String getBubbleId() {
		return bubbleId;
	}


	public void setBubbleId(String bubbleId) {
		this.bubbleId = bubbleId;
	}


	public String getTaskizeInquiryId() {
		return taskizeInquiryId;
	}

	public void setTaskizeInquiryId(String taskizeInquiryId) {
		this.taskizeInquiryId = taskizeInquiryId;
	}


	public String getOrigSrcSysId() {
		return origSrcSysId;
	}


	public void setOrigSrcSysId(String origSrcSysId) {
		this.origSrcSysId = origSrcSysId;
	}
}
