package com.citi.icg.qma.kafka;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.Session;
import jakarta.mail.internet.MimeMessage;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;


/*
 * Serializes and Deserializes Message using kryo
 */
public class QmaEmailMessageKryoCodec implements Serializer<QmaEmailMessage>,Deserializer<QmaEmailMessage>{
	
	private static final Logger log = LoggerFactory.getLogger(QmaEmailMessageKryoCodec.class);
	
	private ThreadLocal<Kryo> kryos = new ThreadLocal<Kryo>() {
		protected Kryo initialValue() {
			Kryo kryo = new Kryo();
			// TODO: why register so many ? 
//			kryo.addDefaultSerializer(POP3Message.class, new KryoInternalSerializer());
//			kryo.addDefaultSerializer(MimeMessage.class, new KryoInternalSerializer());
//			kryo.addDefaultSerializer(Message.class, new KryoInternalSerializer());
//			kryo.register(POP3Message.class,new KryoInternalSerializer());
//			kryo.register(MimeMessage.class, new KryoInternalSerializer());
//			kryo.register(Message.class, new KryoInternalSerializer());
			kryo.register(QmaEmailMessage.class, new QmaEmailMessageKryoInternalCodec());
			return kryo;
		};
	};

	@Override
	public void close() {

	}

	@Override
	public void configure(Map arg0, boolean arg1) {

	}

	@Override
	public byte[] serialize(String arg0, QmaEmailMessage message) {

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		// TODO Increase max size of Output
		Output output = new Output(4096, 4096);
		output.setOutputStream(out);
		kryos.get().writeObject(output, message);
		return out.toByteArray();
	}


	@Override
	public QmaEmailMessage deserialize(String arg0, byte[] bytes) {
//		QmaEmailMessage qmaEmailMessage = new QmaEmailMessage();
//		Input input = new Input(bytes);
//		String guid = kryos.get().readObject(input, String.class);
//		qmaEmailMessage.setGuid(guid);		
//		Message message = kryos.get().readObject(input, Message.class);
//		qmaEmailMessage.setMessage(message);
//		return qmaEmailMessage;
		
		QmaEmailMessage qmaEmailMessage = kryos.get().readObject(new Input(bytes), QmaEmailMessage.class);
		return qmaEmailMessage;
	}

	private static class QmaEmailMessageKryoInternalCodec extends com.esotericsoftware.kryo.Serializer<QmaEmailMessage> {

		@Override
		public void write(Kryo kryo, Output output, QmaEmailMessage qmaEmailMessage) {
			try {
				output.writeString(qmaEmailMessage.getGuid());
				Message email = qmaEmailMessage.getMessage();				
				email.writeTo(output);
			} catch (IOException e) {
				log.error("Error while Serializing ", e);
			} catch (MessagingException e) {
				log.error("Error while Serializing ", e);
			}
		}

		@Override
		public QmaEmailMessage read(Kryo kryo, Input input, Class<? extends QmaEmailMessage> type) {
			QmaEmailMessage qmaEmailMessage = new QmaEmailMessage();
			String guid = input.readString();
			qmaEmailMessage.setGuid(guid);
//			emailInputStream = input.read
			MimeMessage message = null;
			try {
				Properties props = new Properties();
				props.setProperty("mail.mime.address.strict", "false");
				props.setProperty("mail.mime.decodetext.strict", "false");
				Session session = Session.getDefaultInstance(props);				
				message = new MimeMessage(session, input);
				qmaEmailMessage.setMessage(message);
			} catch (Exception e) {
				log.error("Error while Serializing ", e);
			}
			return qmaEmailMessage;
		}





	}




}
