package com.citi.icg.qma.common.transferobject;

import java.io.Serializable;

public class SymphonyUserMapTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8231492811481591323L;
	private String symphonyId;
	private String symphonyEmailId;
	private String soeId;
	
	public String getSymphonyId() {
		return symphonyId;
	}
	public void setSymphonyId(String symphonyId) {
		this.symphonyId = symphonyId;
	}
	public String getSymphonyEmailId() {
		return symphonyEmailId;
	}
	public void setSymphonyEmailId(String symphonyEmailId) {
		this.symphonyEmailId = symphonyEmailId;
	}
	public String getSoeId() {
		return soeId;
	}
	public void setSoeId(String soeId) {
		this.soeId = soeId;
	}
}
