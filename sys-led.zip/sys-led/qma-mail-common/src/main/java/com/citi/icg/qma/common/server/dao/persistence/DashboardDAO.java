package com.citi.icg.qma.common.server.dao.persistence;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import com.citi.icg.qma.hazelcast.cache.client.HazelCastCacheIncrementalLoad;
import org.apache.commons.lang.StringUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.AppserverConstants;
import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.core.util.QueryConstants;
import com.citi.icg.qma.common.server.dao.ClientCategory;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.InquiryClientPriority;
import com.citi.icg.qma.common.server.dao.StaticData;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.ViewConfig;
import com.citi.icg.qma.common.server.dao.util.MailBoxCountExecutor;
import com.citi.icg.qma.common.server.util.AgeAndTimeUtils;
import com.citi.icg.qma.common.server.util.DateUtil;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.common.transferobject.DashBoardCntTO;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.AggregationOptions;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.Cursor;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.ReadPreference;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

public class DashboardDAO extends MongoMorphiaDAO {
	
	
	
	private static final int MAILBOX_STATS_THREAD_COUNT = 4;
	private static final String DEFAULT_VIEWS_IN_QMA = "defaultViewsInQMA";
	private static final String VIEW_TYPE_KEY = "viewType";
	private static final String UI_CRITERIA_DATE_FORMAT = "dd/MMM/yyyy";
	private static final String DECREASE_KEY = "down";
	private static final String INCREASE_KEY = "up";
	private static final String NOT_CHANGE_KEY = "-";
	private static final String PREVIOUS_DAY_COUNT_KEY = "previousDayCount";
	private static final String MY_VIEW_COUNTS_KEY = "myViewCounts";
	private static final String BOX_COUNTS_KEY = "boxCounts";
	private static final String OTHER = "other";
	private static final String _4TO8 = "4to8";
	private static final String _12TO4 = "12to4";
	private static final String GT30 = "gt30";
	private static final String GT15 = "gt15";
	private static final String GT5 = "gt5";
	private static final String LTE5 = "lte5";
	private static final String _8TO12 = "8to12";
	private static final Logger subLogger = LoggerFactory.getLogger(DashboardDAO.class);
	private static DashboardDAO instance = null;
	private static final DB database = MongoDB.instance().getDB();
	private static final UserDAO userDao = new UserDAO();
	private static final InquiryDAO inquiryDAO = new InquiryDAO();
	private static final Boolean ACTIVE = true;
	
		
	//private static final CacheDAO cacheDao = CacheDAO.getInstance();
	private static final String INQUIRY_TREND_CHART = "[{'$match': {'groupId': {'$in': [#groupId#]}"
+", 'date': {'$gte': {$date : #startDate#}, '$lte': {$date : #endDate#}}}}"
+",{'$project': {'groupId':1, 'date': '$date', 'count': '$count', 'nonInquiryCount':'$nonInquiryCount','_id': 0}}"
+", {'$sort': {'date': -1}}"
+", {'$group': {'_id': {'date': '$date'}, 'count': {'$sum': '$count'}, 'nonInquiryCount': {'$sum': '$nonInquiryCount'}}}"
+", {'$project': {'date': '$_id.date', 'count': '$count', 'nonInquiryCount':'$nonInquiryCount', '_id': 0}}"
+", {'$sort': {'date': -1}}"
+",{'$project': {'date': {'$dateToString': {'format': '%Y-%m-%d', 'timezone':'GMT', 'date': '$date'}}, 'count': '$count', 'nonInquiryCount': '$nonInquiryCount'}}"
+"]";
	
	private static final String INQUIRY_TREND_CHART_DATA_FOR_DATE = "[{'$match': {'groupId': {'$in': [#groupId#]}"
+", 'date': {'$gte': {$date : #startDate#}, '$lte': {$date : #endDate#}}}}"
+",{'$project': {'groupId':1, 'date': 1, 'count': 1,'timeFrame':1,'nonInquiryTimeFrame':1, '_id': 0}}"
+", {'$sort': {'date': -1}}]";
	
	/*private static final String INQUIRY_TREND_CHART = "["
			+"{ $match : {action : { $in : ['New Inquiry', 'NEW INQUIRY RESOLVE','REPLY', 'Reply Resolve', 'Reply ResolveAll', 'Forward', 'ReplyAll', 'ReplyAll Resolve', 'Reply']}"
			+"  	,actionTime : { $gte : {$date : #startDate#}, $lte : {$date : #endDate#}}"
			+"		,$or : [{groupId: {$in: [#groupId#]}}, {'recipients.groupId': {$in: [#groupId#]}}]}}"
			+",{ $unwind : {path : '$recipients', includeArrayIndex: 'recipientIndex', preserveNullAndEmptyArrays: true }}"
			+", { $project : {inquiryId : 1, action : 1, actionTime : 1, toFrom : { $cond: [ {$eq:['$recipientIndex', null]}, 'TO', '$recipients.toFrom' ] }"
			  	+", groupId : { $cond: [ {$eq:['$recipientIndex', null]}, '$groupId', '$recipients.groupId' ] }, recipientIndex : 1}}"
			+",{ $match : { groupId : { $in : [#groupId#]}, toFrom : { $not : { $in : ['FROM']}}}}"
			+",{ $group : { _id : { date : { $dateToString : { format : '%Y-%m-%d' , date : '$actionTime'}}} , count : { '$sum' : 1}}}"
			+",{ $project : { date : '$_id.date' , count : '$count' , '_id' : 0}}"
			+",{ $project : { date : { $dateFromString : { dateString : '$date'}} , count : '$count'}}" 
			+",{ $sort : { date : -1}} "
			+",{ $project : { date : { $dateToString : { format : '%Y-%m-%d' , date : '$date'}} , count : '$count'}}"
			+"]";*/
	
	
	private static final String UP_OR_DOWN_KEY = "upOrDown";
	private static final String PERCENT_WRT_PREV_DAY_KEY = "percentWrtPrevDay";
	private static final String GT30_KEY = "30+";
	private static final String GT15_KEY = "15+";
	private static final String GT5_KEY = "05+";
	private static final String LT5_KEY = "lt5";
	static final String CATEGORY_KEY = "category";
	private static final String AGE_IN_DAYS_KEY = "ageInDays";
	private static final String WORKFLOWS_KEY = "workflows";
	private static final String GROUP_ALL = "all";
	private static final String VIEW_POTENTIAL_ESCALATION = "Potential Escalation";
	private static final String VIEW_PENDING_APPROVAL = "Pending Approval";
	private static final String VIEW_RESOLVED = "Resolved";
	private static final String VIEW_INBOX = "Inbox";
	private static final String GROUP_NAME_KEY = "groupName";
	private static final String DASHBOARD_LAYOUT = "dashboardLayout";
	private static final String MESSAGE = "message";
	private static final String STATUS = "status";
	
	
	private static final String VIEW_OUTBOX = "Outbox";
	private static final String VIEW_NON_INQUIRIES = "Non Inquiries";
	private static final String VIEW_UNASSIGNED = "Unassigned";
	private static final String VIEW_ASSIGNED_TO_ME = "Assigned To Me";
	private static final String VIEW_SNOOZED = "Snoozed";
	private static final String VIEW_DRAFTS = "Drafts";
	private static final String QUERY_COUNT_KEY = "queryCount";
	private static final String QUERY_READ_COUNT_KEY = "readCount";
	private static final String MAIL_BOX_STAT_KEY = "mailBoxStat";
	private static final String INQUIRY_COLLECTION = "Inquiry";
	private static final String ID_KEY = "_id";
	private static final String VIEWS_VIEW_NAME_KEY = "views.viewName";
	
	private static final String ASSIGNED_GROUP_ID_KEY = "assignedGroupId";
	private static final String GROUP_KEY = "group";
	private static final String COUNT_KEY = "count";
	private static final String MAIN_GROUP_KEY = "main";
	private static final String BACKUP_GROUP_KEY = "backup";
	private static final String OPEN_INQUIRY_BY_GROUP_KEY = "openInquiryByGroup";
	private static final String PERCENTAGE_KEY = "percentage";
	private static final String AGE_KEY = "age";
	private static final String CLIENT_TYPE_UNRECOGNIZED_KEY = "UnRecognized";
	private static final String ALL_GROUPS_SELECTED = "allGroupsSelected";
	private static final String INTENSITY_HEAT_MAP_KEY = "intensityHeatMap";
	private static final String CLIENT_PRIORITY_KEY = "clientPriority";
	private static final String MAILBOX_STATS = "mailBoxStats";
	private static final String ASSIGNED_GROUPS = "assignedGroups";
	private static final String HEAT_MAP = "heatMap";
	private static final String DASHBOARD_SETTINGS = "dashboardSettings";
	private static final String TAG_LIMIT = "tagLimit";
	private static final String CLIENT_CATEGORY_NAME = "clientCategoryName";
	private static final String CLIENT_CATEGORY_CUSTOM = "custom";
	private static final String CATEGORY_TYPE = "categoryType";
	private static final String COUNT_UNREAD_KEY = "unReadCount";
	private static final String PLATINUM = "Platinum";
	private static final String SUPERCHARGE = "Supercharge";
	private static final String PRIORITY = "Priority";
	private static final String VIEW_FYI = "Auto Assign FYI";
	private static final String VIEW_PERSOANL_MAIL = "Personal Mail";
	private static final String TOTALCOUNT ="TOTAL_COUNT";
	private static String openInquiryByGroupStr = "[{$match: {'_id.assignedGroupId' : { $in:[#groupId#]}, 'reloadCounter': [reloadCounter] }},{$group: {_id : {assignedGroupId : '$_id.assignedGroupId','rulesFlag' : '$_id.rulesFlag'}, 'count' : {$sum : '$COUNT'}}}]";
	private static String assignedOwnersByAgeBandStrPerGroup = "[{$match: {'_id.assignedGroupId' : [#groupId#], 'reloadCounter': [reloadCounter]}}, {$group: {_id: {DAY:'$_id.DAY',MONTH:'$_id.MONTH',YEAR:'$_id.YEAR',assignedUserId : '$_id.assignedUserId', 'rulesFlag' : '$_id.rulesFlag', assignedGroupId : '$_id.assignedGroupId'}, 'count' : {$sum : '$COUNT'}}}]";
	private static String intensityHeatMapClientTypeCnt = "[ { '$match' : {'assignedGroupId' : { '$in' : [#groupId#]}} }]";
	private List<String> customCategoryList = null;
	private static final String _0TO1 = "0to1";
	private static final String _2to5 = "2to5";
	private static final String _6to15 = "6to15";
	private static final String GT16 = "gt16";

	public static synchronized DashboardDAO getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		if (instance == null) {
					instance = new DashboardDAO();
				}
		return instance;
	}
	
	/**
	 * Description : get data for inquiry trend chart
	 * @param soeId
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBObject getInquiryTrendChartData(String soeId, BasicDBObject inputJsonObj) throws CommunicatorException {

		BasicDBObject valuesList = new BasicDBObject();

		try {
			List<Long> userGroupsList = getUserAssignedGroupIds(soeId, inputJsonObj);
			if(userGroupsList != null && !userGroupsList.isEmpty()){
				valuesList = getInquiryTrendChartDataForGroups(soeId, userGroupsList);
			} else {
				subLogger.info("No valid groups found for  soeId = " + soeId);
			}
		} catch (Exception e) {
			subLogger.error("Exception in getInquiryTrendChartDataOnFly : " + e);
		}

		return valuesList;
	}

	/**
	 * @param soeId
	 * @param inputJsonObj
	 * @param valuesList
	 * @return
	 * @throws CommunicatorException
	 */
	private List<Long> getUserAssignedGroupIds(String soeId, BasicDBObject inputJsonObj)
			throws CommunicatorException {
		String groupName = inputJsonObj.getString(GROUP_NAME_KEY).trim();
		List<Long> userGroupsList = new ArrayList<>();
		if("All".equalsIgnoreCase(groupName)){
			Map<String, Object> dashboardSettings = getUserDashboardSettings(soeId);
			getUserGroups(userGroupsList, dashboardSettings);
			if (userGroupsList.isEmpty()) {
				getAllAssignedGroups(soeId, userGroupsList);
			}
			
			//userGroupsList = userDao.getUserGroupsList(soeId);
		} else {
			Long groupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
			if(groupId != null){
				userGroupsList.add(groupId);
			}
		}
		return userGroupsList;
	}

	/**
	 * Description : Gets inquiry count for assigned group
	 * @param soeId
	 * @param userGroupsList
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBObject getInquiryTrendChartDataForGroups(String soeId, List<Long> userGroupsList)
			throws CommunicatorException {
		BasicDBObject valuesList = null;
		try {
			Calendar endDateCal = Calendar.getInstance();
			endDateCal.setTimeZone(TimeZone.getTimeZone("GMT"));
			endDateCal.set(Calendar.HOUR_OF_DAY, 0);
			endDateCal.set(Calendar.MINUTE, 0);
			endDateCal.set(Calendar.SECOND, 0);
			endDateCal.set(Calendar.MILLISECOND, 0);

			Calendar startDateCal = Calendar.getInstance();
			startDateCal.setTimeZone(TimeZone.getTimeZone("GMT"));
			startDateCal.add(Calendar.YEAR, -1);
			//startDateCal.add(Calendar.MONTH, -1);
			startDateCal.set(Calendar.HOUR_OF_DAY, 0);
			startDateCal.set(Calendar.MINUTE, 0);
			startDateCal.set(Calendar.SECOND, 0);
			startDateCal.set(Calendar.MILLISECOND, 0);

			long lEndTime = endDateCal.getTimeInMillis();
			long lStartTime = startDateCal.getTimeInMillis();

			String finalQuery = INQUIRY_TREND_CHART
					.replace(QueryConstants.GROUP_ID_EXP, "" + userGroupsList.toString())
					.replace("#startDate#", "" + Long.toString(lStartTime))
					.replace("#endDate#", "" + Long.toString(lEndTime));
			/*---- Start Migration --*/
			MongoCursor<DBObject> cur = MongoDB.executeAggregatePipelineWithCursorReadPref("InquiryTrendChartData", finalQuery, ReadPreference.secondary(),true,DBObject.class);
	        /*---- End Migration --*/
			//subLogger.info("fetching Trend chart data for query : " + query);
			/*DBCollection col = database.getCollection("InquiryTrendChartData");
			AggregationOptions options = AggregationOptions.builder().allowDiskUse(true).build();
			Cursor cur = col.aggregate(query, options, ReadPreference.secondary());*/
			valuesList = new BasicDBObject();
			BasicDBList inquiryDataList = new BasicDBList();
			BasicDBList nonInquiryDataList = new BasicDBList();
			BasicDBList allInquiryDataList = new BasicDBList();
			String date = "";
			long inquiryCount = 0;
			long nonInquiryCount = 0;
			long allInquiryCount = 0;

			while (cur.hasNext()) {
				BasicDBObject o = (BasicDBObject) cur.next();
				//valuesList.add(o);
				date = null!=o && null!=o.get("date") ? o.getString("date") : "";
				inquiryCount = null!=o && null!=o.get("count") ? o.getLong("count") : 0;
				nonInquiryCount = null!=o && null!=o.get("nonInquiryCount") ? o.getLong("nonInquiryCount") : 0;
				allInquiryCount = inquiryCount + nonInquiryCount;
				inquiryDataList.add(new BasicDBObject("date",date).append("count",inquiryCount));
				nonInquiryDataList.add(new BasicDBObject("date",date).append("count",nonInquiryCount));
				allInquiryDataList.add(new BasicDBObject("date",date).append("count",allInquiryCount));
			}
			valuesList.put("inquiries", inquiryDataList);
			valuesList.put("noninquiries", nonInquiryDataList);
			valuesList.put("all", allInquiryDataList);
		} catch (Exception e) {
			subLogger.error("Exception while fetching records for Trend Chart in getInquiryTrendChartDataOnFly : " + e);
		}
		//subLogger.info("ValuesList"+valuesList);
		return valuesList;

	}
	
	/**
	 * Description : Gets inquiry count for assigned group
	 * @param inputDate
	 * @param userGroupsList
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBList getInquiryTrendChartDataForDateWithAge(String inputDate, List<Long> userGroupsList, String trendChartType)
			throws CommunicatorException {
		BasicDBList valuesList = null;
		try {
			SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			sDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
			Date date = sDateFormat.parse(inputDate);
			Calendar dateCal = Calendar.getInstance();
			dateCal.setTimeZone(TimeZone.getTimeZone("GMT"));
			dateCal.setTime(date);

			long lEndTime = dateCal.getTimeInMillis();
			long lStartTime = dateCal.getTimeInMillis();

			String finalQuery = INQUIRY_TREND_CHART_DATA_FOR_DATE
					.replace(QueryConstants.GROUP_ID_EXP, "" + userGroupsList.toString())
					.replace("#startDate#", "" + Long.toString(lStartTime))
					.replace("#endDate#", "" + Long.toString(lEndTime));
			//List<DBObject> query = (List<DBObject>) DataConversionUtil.convertJSONToJava(finalQuery, Object.class);

			subLogger.info("fetching Trend chart data for query : " + finalQuery);
			/*DBCollection col = database.getCollection("InquiryTrendChartData");
			AggregationOptions options = AggregationOptions.builder().allowDiskUse(true).build();
			Cursor cur = col.aggregate(query, options, ReadPreference.secondary());*/
			
	        /*---- Start Migration --*/
			MongoCursor<DBObject> cur=MongoDB.executeAggregatePipelineWithCursorReadPref("InquiryTrendChartData", finalQuery, ReadPreference.secondary(),true,DBObject.class);
	        /*---- End Migration --*/
			valuesList = new BasicDBList();

			while (cur.hasNext()) {
				BasicDBObject o = (BasicDBObject) cur.next();
				BasicDBObject timeframe;
				if("inquiries".equalsIgnoreCase(trendChartType) && o.get("timeFrame") != null){
					timeframe = (BasicDBObject) o.get("timeFrame");
					calculateAndSetTimeframeAndAge(valuesList, timeframe, null);
				} else if("noninquiries".equalsIgnoreCase(trendChartType) && o.get("nonInquiryTimeFrame") != null){
					timeframe = (BasicDBObject) o.get("nonInquiryTimeFrame");
					calculateAndSetTimeframeAndAge(valuesList, null,timeframe);
				} else if("all".equalsIgnoreCase(trendChartType) && null != o.get("timeFrame")) { // <-- sonar fix Correct one of the identical sub-expressions on both sides of operator "&&"
					timeframe = (BasicDBObject) o.get("timeFrame");
					BasicDBObject nonInquirytimeframe = (BasicDBObject) o.get("nonInquiryTimeFrame");
					
					calculateAndSetTimeframeAndAge(valuesList, timeframe, nonInquirytimeframe);
				}
				
				
			}
		} catch (Exception e) {
			subLogger.error("Exception while fetching records for Trend Chart in getInquiryTrendChartDataOnFly : " + e);
		}
		return valuesList;

	}

	/**
	 * @param valuesList
	 * @param cur
	 * @param timeframe 
	 * @param nonInquirytimeframe 
	 */
	private void calculateAndSetTimeframeAndAge(BasicDBList valuesList, BasicDBObject timeframe, BasicDBObject nonInquirytimeframe) {
		try {
			int count = 0 ;
			int nonInquiryCount = 0;
			int finalCount = 0;
			
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,_8TO12,_0TO1) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,_8TO12,_0TO1) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,_8TO12,_0TO1, finalCount);
			
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,_8TO12,_2to5) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,_8TO12,_2to5) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,_8TO12,_2to5, finalCount);
			
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,_8TO12,_6to15) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,_8TO12,_6to15) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,_8TO12,_6to15, finalCount);
			
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,_8TO12,GT16) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,_8TO12,GT16) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,_8TO12,GT16, finalCount);
			
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,_12TO4,_0TO1) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,_12TO4,_0TO1) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,_12TO4,_0TO1, finalCount);
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,_12TO4,_2to5) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,_12TO4,_2to5) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,_12TO4,_2to5, finalCount);
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,_12TO4,_6to15) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,_12TO4,_6to15) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,_12TO4,_6to15, finalCount);
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,_12TO4,GT16) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,_12TO4,GT16) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,_12TO4,GT16, finalCount);
			
			
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,_4TO8,_0TO1) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,_4TO8,_0TO1) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,_4TO8,_0TO1, finalCount);
			
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,_4TO8,_2to5) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,_4TO8,_2to5) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,_4TO8,_2to5, finalCount);
			
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,_4TO8,_6to15) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,_4TO8,_6to15) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,_4TO8,_6to15, finalCount);
			
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,_4TO8,GT16) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,_4TO8,GT16) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,_4TO8,GT16, finalCount);
			
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,OTHER,_0TO1) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,OTHER,_0TO1) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,OTHER,_0TO1, finalCount);
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,OTHER,_2to5) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,OTHER,_2to5) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,OTHER,_2to5, finalCount);
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,OTHER,_6to15) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,OTHER,_6to15) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,OTHER,_6to15, finalCount);
			count = null != timeframe ? getTimeFrameAndAgeCount(timeframe,OTHER,GT16) : 0;
			nonInquiryCount = null != nonInquirytimeframe ? getTimeFrameAndAgeCount(nonInquirytimeframe,OTHER,GT16) : 0;
			finalCount = count + nonInquiryCount;
			updateTimeFrameAndAgeCount(valuesList,OTHER,GT16, finalCount);
			
		} catch (Exception e) {
			subLogger.error("Exception in calculateAndSetTimeframeAndAge", e);
		}
		
		
	}
	/**
	 * @param valuesList
	 * @param string
	 * @param string2
	 */
	private int getTimeFrameAndAgeCount(BasicDBObject timeframe, String timekey, String ageBandKey) {

		BasicDBObject timekeyObject;
		int count = 0;
		try {
			if(timeframe.get(timekey) != null){
				timekeyObject = (BasicDBObject) timeframe.get(timekey);
				if(timekeyObject != null && timekeyObject.get(ageBandKey) != null){
					count = timekeyObject.getInt(ageBandKey);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in getTimeFrameAndAgeCount",e );
		}
		return count;
		
		
	}

	/**
	 * @param valuesList
	 * @param string
	 * @param string2
	 */
	private void updateTimeFrameAndAgeCount(BasicDBList valuesList, String timekey, String ageBandKey, int count) {
		try {
			if(valuesList.isEmpty()){
				BasicDBObject ageObj = new BasicDBObject();
				ageObj.put(ageBandKey, count);
				BasicDBObject timeObj = new BasicDBObject();
				timeObj.put(timekey, ageObj);
				valuesList.add(timeObj);
			} else {
				for(Object timeFrameObj : valuesList){
					setTimeframeAndAge(timekey, ageBandKey, count, timeFrameObj);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in updateTimeFrameAndAgeCount", e);
		}
	}

	/**
	 * @param timekey
	 * @param ageBandKey
	 * @param count
	 * @param timeFrameObj
	 */
	private void setTimeframeAndAge(String timekey, String ageBandKey, int count, Object timeFrameObj) {
		try {
			if(timeFrameObj != null){
				Object ageBandObj = ((BasicDBObject) timeFrameObj).get(timekey);
				if(ageBandObj != null){
					Object ageCount = ((BasicDBObject) ageBandObj).get(ageBandKey);
					updateAgeBand(ageBandKey, count, ageBandObj, ageCount);
				} else {
					BasicDBObject ageObj = new BasicDBObject();
					ageObj.put(ageBandKey, count);
					BasicDBObject timeObj = new BasicDBObject();
					timeObj.put(timekey, ageObj);
					((BasicDBObject) timeFrameObj).append(timekey, ageObj) ;
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in setTimeframeAndAge", e);
		}
	}

	/**
	 * @param ageBandKey
	 * @param count
	 * @param ageBandObj
	 * @param ageCount
	 */
	private void updateAgeBand(String ageBandKey, int count, Object ageBandObj, Object ageCount) {
		try {
			if(ageCount != null){
				((BasicDBObject) ageBandObj).put(ageBandKey,(int) ageCount+count) ;
			} else {
				
				((BasicDBObject) ageBandObj).append(ageBandKey, count) ;
			}
		} catch (Exception e) {
			subLogger.error("Exception in updateAgeBand", e);
		}
	}

	/**
	 * Description : gets inquiry count for age band for a date
	 * @param inputJsonObj
	 * @param soeId
	 * @return
	 */
	public BasicDBList getInquiryTrendChartDataForDate(BasicDBObject inputJsonObj, String soeId) {

		BasicDBList valuesList = new BasicDBList();

		try {
			String date = inputJsonObj.getString("date");
			String trendChartType = "inquiries";
			if(null != inputJsonObj.get("trendChartType")) {
				trendChartType = inputJsonObj.getString("trendChartType");
			}
			List<Long> userGroupsList = getUserAssignedGroupIds(soeId, inputJsonObj);
			if(userGroupsList != null && !userGroupsList.isEmpty()){
				valuesList = getInquiryTrendChartDataForDateWithAge(date, userGroupsList, trendChartType);
			} else {
				subLogger.info("No valid groups found for  soeId = " + soeId);
			}
		} catch (Exception e) {
			subLogger.error("Exception in getInquiryTrendChartDataForDate : " + e);
		}

		return valuesList;
	}
	
	/**
	 * Description : to get dashboard layout setting for user
	 * @param soeId
	 * @return
	 */
	public BasicDBObject getDashboardLayout(String soeId) {
		BasicDBObject response = new BasicDBObject();

		try {
			Query<User> query = mongoDatastore.createQuery(User.class).filter(
					ID_KEY, soeId);
			subLogger.info("fetching data for query : " + query);
			List<User> user = query.asList();
			if(!user.isEmpty() && user.get(0) !=null && user.get(0).getDashboardSettings() != null){
				subLogger.info("data : " + user.get(0).getDashboardSettings().get(DASHBOARD_LAYOUT));
				response.put(DASHBOARD_LAYOUT, user.get(0).getDashboardSettings().get(DASHBOARD_LAYOUT));
			} else {
				subLogger.info("No Dashboard data for soeid : " + soeId);
				response.put(DASHBOARD_LAYOUT, new BasicDBList());
			}
			
		} catch (Exception e) {
			response.put(STATUS, false);
			response.put(MESSAGE, "Exception while fetching dashboard settings data"); 
			subLogger.error("Exception while saving dashboard layout in saveDashboardLayout : " + e);
		}
		return response;
	}
	
	/**
	 * Description : to save dashboard layout setting for user
	 * @param inputJsonObj
	 * @param soeId
	 * @return
	 */
	public BasicDBObject saveDashboardLayout(BasicDBObject inputJsonObj, String soeId) {
		BasicDBObject response = new BasicDBObject();

		try {
			Query<User> query = mongoDatastore.createQuery(User.class).filter(
					ID_KEY, soeId);

			UpdateOperations<User> userOps = mongoDatastore.createUpdateOperations(User.class);
			userOps.set("dashboardSettings.dashboardLayout", inputJsonObj);
			mongoDatastore.update(query, userOps);
			response.put(STATUS, true);
			response.put(MESSAGE, "Dashboard Layout saved successfully"); 
		} catch (Exception e) {
			response.put(STATUS, false);
			response.put(MESSAGE, "Dashboard Layout saved failed"); 
			subLogger.error("Exception while saving dashboard layout in saveDashboardLayout : " + e);
		}
		return response;
	}
	
	/**
	 * This method return main groups and backup groups along with count of inquiries, percentage 
	 * @param soeId
	 * @return
	 * @throws CommunicatorException 
	 */
	@SuppressWarnings("deprecation")
	public BasicDBObject getOpenInquiryByGroup(String soeId) throws CommunicatorException {
		Long reloadCounter = getReloadCounterFromStaticData();	
		BasicDBObject output = new BasicDBObject();
		BasicDBObject openInquiryByGroup = new BasicDBObject();
		try {
		    	User user = userDao.getUserById(soeId);
			Set<Long> userGroupsList = userDao.getUserGroupsList(user,ACTIVE);
			if (userGroupsList == null || userGroupsList.isEmpty()) {
				subLogger.info("getOpenInquiryByGroup for soeId = " + soeId + " , No valid groups found.");
				output.put(MESSAGE, "No valid groups found for soeId:"+soeId);
				return output;
			}
			String groupList = getAssignedGroupsfromDashboard(soeId, userGroupsList);
			String finalQuery = openInquiryByGroupStr.replace(QueryConstants.GROUP_ID_EXP, "" + groupList).replace("[reloadCounter]", reloadCounter.toString());
			/*---- Start Migration --*/
			List<BasicDBObject> pipelines = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(finalQuery));
			AggregationOptions aggregationOptions = AggregationOptions.builder().build();
	        /*---- End Migration --*/
			DBCollection col = database.getCollection("Inquiry_Aggregate_Chart_Data");
			Cursor outputResult = col.aggregate(pipelines,aggregationOptions, ReadPreference.secondary());
			BasicDBList mainList = new BasicDBList();
			BasicDBList backupList = new BasicDBList();
			List<DBObject> dataList = new ArrayList<DBObject>();
			int totalNoOfInquiries = getTotalNoOfInquiries(outputResult,dataList);
			int countBackup=0;
			for (DBObject resultObj : dataList){
				DBObject dbObjectRow = (DBObject) resultObj.get(AppserverConstants.MONGO_PK);
				boolean isNonInquiry = isNonInqiury(dbObjectRow);
				if (!isNonInquiry) {
					BasicDBObject mainObject = new BasicDBObject();
					String assignedGroupId = dbObjectRow.get(ASSIGNED_GROUP_ID_KEY).toString();
					mainObject.put(ASSIGNED_GROUP_ID_KEY, assignedGroupId);
					String groupCode = QMACacheFactory.getCache().getGroupIdToNameMap().get(Long.valueOf(assignedGroupId));
					mainObject.put(GROUP_KEY, groupCode);
					int noOfInquiriesPerGroup = (int) resultObj.get(COUNT_KEY);
					float proportion = (float)noOfInquiriesPerGroup/totalNoOfInquiries;
					DecimalFormat df = new DecimalFormat("#.##");
					mainObject.put(PERCENTAGE_KEY, df.format(proportion * 100)+"%");
					mainObject.put(COUNT_KEY, resultObj.get(COUNT_KEY));
					mainObject.put("inquiryByGroup", getAssignedOwnersByAgeBandList(soeId,reloadCounter,assignedGroupId));
					// add condition for main vs backup group
					mainList.add(mainObject);
					if(countBackup == 0)
					{
						BasicDBObject backupObject = new BasicDBObject();
						backupObject.put(COUNT_KEY, resultObj.get(COUNT_KEY));
						backupObject.put(ASSIGNED_GROUP_ID_KEY, assignedGroupId);
						backupObject.put(GROUP_KEY, groupCode);
						backupObject.put(PERCENTAGE_KEY,"100%");
						backupObject.put("inquiryByGroup", getAssignedOwnersByAgeBandList(soeId,reloadCounter,assignedGroupId));
						backupList.add(backupObject);
						countBackup++;
					}
				}
			}
			openInquiryByGroup.put(MAIN_GROUP_KEY, mainList);
			openInquiryByGroup.put(BACKUP_GROUP_KEY, backupList);
			output.put(OPEN_INQUIRY_BY_GROUP_KEY, openInquiryByGroup);
		} catch (Exception e) {
			subLogger.error("Exception while fetching records for Chart in getOpenInquiryByGroup : " + e);
		}
		return output;
	}

	/**
	 * Get assigned group from dashboard settings if found else get default all assigned groups  
	 * @param soeId
	 * @param userGroupsList
	 * @return
	 * @throws CommunicatorException 
	 */
	public String getAssignedGroupsfromDashboard(String soeId, Set<Long> userGroupsList) throws CommunicatorException {
		String groupList = userGroupsList.toString();
		try {
			BasicDBObject dashBoardSettings = getDashboardSettings(soeId);
			if (null != dashBoardSettings && null != dashBoardSettings.get(ASSIGNED_GROUPS)) {
				BasicDBList assignedGroupsList = (BasicDBList) dashBoardSettings.get(ASSIGNED_GROUPS);
				if (!assignedGroupsList.isEmpty()) {
					List<Long> groupCodeList = new ArrayList<>();
					for (int i = 0; i < assignedGroupsList.size(); i++) {
						BasicDBObject assignedGroup = (BasicDBObject) assignedGroupsList.get(i);
						String groupName = assignedGroup.getString(GROUP_NAME_KEY);
						if (StringUtils.isNotBlank(groupName) && null!=QMACacheFactory.getCache() && null!=QMACacheFactory.getCache().getGroupCodeToIdMap()) {
							Long groupCode = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
							groupCodeList.add(groupCode);
						}
					}
					groupList = groupCodeList.toString();
				}
			}
		} catch (Exception e) {
			subLogger.warn("Exception in DashboardDAO.getAssignedGroupsfromDashboard for user:"+soeId, e);
		}
		return groupList;
	}

	/**
	 * Return total number of inquiries for the assigned group of soeid
	 * @param outputResult
	 * @return
	 */
	private int getTotalNoOfInquiries(Cursor outputResult,List<DBObject> dataList) {
		int totalCount = 1; //<-- sonar fix divident can not be zero
		while (outputResult.hasNext()) {
			DBObject resultObj = outputResult.next();
			dataList.add(resultObj);
			DBObject dbObjectRow = (DBObject) resultObj.get(AppserverConstants.MONGO_PK);
			boolean isNonInquiry = isNonInqiury(dbObjectRow);
			if (!isNonInquiry) {
				int noOfInquiries = (int) resultObj.get(COUNT_KEY);
				totalCount = totalCount + noOfInquiries;
			}
		}
		return totalCount;
	}

	/**
	 * @return reload counter
	 * @throws CommunicatorException
	 */
	public Long getReloadCounterFromStaticData() throws CommunicatorException
	{
		StaticData staticData = GenericDAO.getStaticData();
		return staticData.getChartDataReloadMaxCounter();
	}
	/**
	 * For non inquiries this method will return true, false otherwise.
	 * @param dbObjectRow
	 * @return
	 */
	boolean isNonInqiury(DBObject dbObjectRow) {
		boolean isNonInquiry = false;
		if (dbObjectRow != null && dbObjectRow.get("rulesFlag") != null) {
			DBObject obj = (DBObject) dbObjectRow.get("rulesFlag");
			Boolean val = (Boolean) obj.get("markAsNonInquiry");
			if (val != null && val)
				isNonInquiry = true;
		}
		return isNonInquiry;
	}

	/**
	 * @param soeId
	 * @param reloadCounter
	 * @param groupId
	 * @return list of inquiries count as per age band
	 * @throws CommunicatorException
	 */
	@SuppressWarnings("deprecation")
	public BasicDBList getAssignedOwnersByAgeBandList(String soeId, Long reloadCounter, String groupId) {
		BasicDBList ageBand = new BasicDBList();
		try {
			String finalQuery = assignedOwnersByAgeBandStrPerGroup;
			finalQuery = finalQuery.replace(QueryConstants.GROUP_ID_EXP, "" + groupId).replace("[reloadCounter]",
					reloadCounter.toString());
			/*---- Start Migration --*/
			MongoCursor<DBObject> output=MongoDB.executeAggregatePipelineWithCursorReadPref("Inquiry_Aggregate_Chart_Data", finalQuery, ReadPreference.secondary(),false,DBObject.class);
	        /*---- End Migration --*/
			//DBCollection col = database.getCollection("Inquiry_Aggregate_Chart_Data");
			//Cursor output = col.aggregate(query, null, ReadPreference.secondaryPreferred());
			int count30 = 0;
			int count15 = 0;
			int count5 = 0;
			int countLess5 = 0;
			while (output.hasNext()) {
				DBObject result = output.next();
				DBObject dbObjectRow = (DBObject) result.get(AppserverConstants.MONGO_PK);
				boolean isNonInquiry = isNonInqiury(dbObjectRow);
				if (!isNonInquiry) {
					int year = Integer.valueOf(dbObjectRow.get("YEAR").toString());
					int month = Integer.valueOf(dbObjectRow.get("MONTH").toString());
					int day = Integer.valueOf(dbObjectRow.get("DAY").toString());
					int noOfInquiriesForDate = Integer.valueOf(result.get(COUNT_KEY).toString());
					Calendar calendar = Calendar.getInstance();
					calendar.clear();
					calendar.set(Calendar.MONTH, month - 1);
					calendar.set(Calendar.YEAR, year);
					calendar.set(Calendar.DAY_OF_MONTH, day);
					Date createdDate = calendar.getTime();
					double daysElapsed = getInquiryAge(createdDate, groupId);
					if (daysElapsed > 30) {
						count30 = count30+noOfInquiriesForDate;
					} else if (daysElapsed > 15 && daysElapsed <= 30) {
						count15 = count15+noOfInquiriesForDate;
					} else if (daysElapsed > 5 && daysElapsed <= 15) {
						count5 = count5+noOfInquiriesForDate;
					}else{
						countLess5 = countLess5+noOfInquiriesForDate;
					}
				}
			}
			BasicDBObject ageBand30 = new BasicDBObject();
			ageBand30.put(AGE_KEY, "+30 Days");
			ageBand30.put(COUNT_KEY, count30);
			BasicDBObject ageBand15 = new BasicDBObject();
			ageBand15.put(AGE_KEY, "+15 Days");
			ageBand15.put(COUNT_KEY, count15);
			BasicDBObject ageBand5 = new BasicDBObject();
			ageBand5.put(AGE_KEY, "+05 Days");
			ageBand5.put(COUNT_KEY, count5);
			BasicDBObject ageBandLess5 = new BasicDBObject();
			ageBandLess5.put(AGE_KEY, "<=05 Days");
			ageBandLess5.put(COUNT_KEY, countLess5);
			ageBand.add(ageBand30);
			ageBand.add(ageBand15);
			ageBand.add(ageBand5);
			ageBand.add(ageBandLess5);

		} catch (Exception ex) {
			subLogger.error("Exception while getting age band:" + ex);
			ageBand = new BasicDBList();
		}
		return ageBand;
	}

	/**
	 * This method will calculate inquiry age in days.
	 * @param createdDate
	 * @param groupId
	 * @return int
	 */
	private int getInquiryAge(Date createdDate, String groupId) {
		int daysElapsed;
		Long grpId = Long.valueOf(groupId);
		if( grpId != null &&  null != QMACacheFactory.getCache().getGroupAgeConfigMap() 
				&& QMACacheFactory.getCache().getGroupAgeConfigMap().containsKey(grpId) ) {
			BasicDBObject workflow = new BasicDBObject();
			workflow.put("crtDate", createdDate);
			workflow.put("status", "open");
			daysElapsed = AgeAndTimeUtils.getOpenInquiryAge(workflow, QMACacheFactory.getCache().getGroupAgeConfigMap().get(grpId));
		} else {
			daysElapsed = (int) DateUtil.calculateAgeforGraphs(createdDate);
		}
		return daysElapsed;
	}
	
	public BasicDBObject getIntensityHeatMapCnt(String soeId) {
	    
	    return getIntensityHeatMapCnt(soeId,null);
	}
	
	/**
	 * This method fetch the data as per clientType from Inquiry.
	 * @param soeId
	 * @return BasicDBObject
	 */
	public BasicDBObject getIntensityHeatMapCnt(String soeId, Boolean active) {
		BasicDBObject inquiriesAsPerClientType = new BasicDBObject();
		BasicDBList clientType = new BasicDBList();
		Set<Long> platinqList = new HashSet<Long>();
		Set<Long> platgroupList = new HashSet<>();
		
		long startTime = System.currentTimeMillis();
		try
		{	
		    	boolean checkActiveInactive = active == null ? false :true;
		    	Set<Long> userGroupsList = new HashSet<Long>();
		    	if(checkActiveInactive) {
		    	    User user = userDao.getUserById(soeId);
		    	    userGroupsList = userDao.getUserGroupsList(user, ACTIVE);
		    	}
		    	else {
		    	    userGroupsList = userDao.getUserGroupsList(soeId);
		    	}
		    	
			if (userGroupsList == null || userGroupsList.isEmpty()) {
				subLogger.info("getIntensityHeatMapCnt for soeId = " + soeId + " , No valid groups found.");
				inquiriesAsPerClientType.put(MESSAGE, "No valid groups found for soeId:"+soeId);
				return inquiriesAsPerClientType;
			}
			String groupList = getAssignedGroupsfromDashboard(soeId, userGroupsList);
			StaticData staticData = GenericDAO.getStaticData();
			String finalQuery = intensityHeatMapClientTypeCnt.replace(QueryConstants.GROUP_ID_EXP, "" + groupList);
			List<BasicDBObject> pipelines = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(finalQuery));
			//subLogger.info("getIntensityHeatMapCnt query : " + pipelines);
			modifyQueryWithDateConfig(pipelines);
			MongoDatabase db = MongoDB.instance().getDatabase();
			MongoCollection<Document> collection = db.getCollection("InquiryClientPriority").withReadPreference(ReadPreference.secondary());
			
			List<DBObject> outputResult = collection.aggregate(pipelines,DBObject.class).allowDiskUse(false).into(new ArrayList<>());
			
			for(DBObject object : outputResult) {
						if(null!=object.get(CLIENT_PRIORITY_KEY)&&(PLATINUM.equalsIgnoreCase(object.get(CLIENT_PRIORITY_KEY).toString())
								|| SUPERCHARGE.equalsIgnoreCase(object.get(CLIENT_PRIORITY_KEY).toString()))) {
							Long inquiry =  (Long) object.get("inquiryId");
							platinqList.add(inquiry);
							platgroupList.add((Long)object.get(ASSIGNED_GROUP_ID_KEY));
						}
						
					}
			
			List<BasicDBObject> intensityHeatMapQuery = getIntensityHeatMapQuery(platinqList,platgroupList);
			List<BasicDBObject> intensityHeatMapQueryCnt =applyGroupByForTotalCount(intensityHeatMapQuery,soeId);
			BasicDBObject out= fetchTotalCount(intensityHeatMapQueryCnt);
			
			BasicDBObject objDashboardSettings = getDashboardSettings(soeId);
			fetchCountForDefaultCategoriesforHeatMapCount(clientType, outputResult, objDashboardSettings, staticData,out);
			fetchCustomClientCategories(clientType, outputResult, objDashboardSettings);
			subLogger.info("Time diff -  getIntensityHeatMapCntByGroup CountForDefaultCategories : groupId ["+groupList+"]-"+(System.currentTimeMillis() - startTime));
			inquiriesAsPerClientType.put(INTENSITY_HEAT_MAP_KEY, clientType);
		}
		catch (Exception e)
		{
			subLogger.error("Exception in getIntensityHeatMapCnt for user= " + soeId, e);
		}
		return inquiriesAsPerClientType;
	}

	private List<BasicDBObject> getIntensityHeatMapQuery(Set<Long> inqList, Set<Long> groupList) {
		List<BasicDBObject> queryList = null;
		try {
			BasicDBObject inquiryIdSearchCriteria = null;
			if(null != inqList && !inqList.isEmpty()){
				inquiryIdSearchCriteria = new BasicDBObject("_id", new BasicDBObject("$in", inqList));
			} 
			BasicDBObject versionMatchCriteria = null;
			if(null != groupList && !groupList.isEmpty()){
				versionMatchCriteria =  new BasicDBObject(WORKFLOWS_KEY, new BasicDBObject("$elemMatch", new BasicDBObject("status","Open")
						.append("direction","IN")
						.append(ASSIGNED_GROUP_ID_KEY, new BasicDBObject("$in",groupList))
						//.append("rulesFlag", new BasicDBObject("$exists",false))
						));
			} else {
				subLogger.info("groupList is blank in dashboarddao: ");
			}
			BasicDBList topLevelCriteriaList = new BasicDBList();
			if(null != versionMatchCriteria) {
				topLevelCriteriaList.add(inquiryIdSearchCriteria);//inquiryIdSearchCriteria
			}
			if(null != inquiryIdSearchCriteria) {
				topLevelCriteriaList.add(versionMatchCriteria);//versionMatchCriteria
			}
			BasicDBObject topMatchCriteria = new BasicDBObject();
			topMatchCriteria.append("$match", new BasicDBObject("$and",topLevelCriteriaList));
			queryList = new ArrayList<>();
			queryList.add(topMatchCriteria);
			
			BasicDBObject unwind = new BasicDBObject("$unwind","$workflows");
			queryList.add(unwind);
			
			String versionMatchDashboard  ="  { 'workflows.status' : 'Open', 'workflows.direction' : 'IN' ,'workflows.assignedGroupId' : { '$in' : #GROUPIDGRID#},'workflows.rulesFlag' : { '$exists' : false}}";
			String groupListString = (groupList != null) ? groupList.toString() : null;
			versionMatchDashboard = versionMatchDashboard.replace("#GROUPIDGRID#", groupListString);
			BasicDBObject versionMatchDashboardDbObject = BasicDBObject.parse(versionMatchDashboard);
			BasicDBObject versionCriteria = new BasicDBObject();
			versionCriteria.append("$match", versionMatchDashboardDbObject);
			queryList.add(versionCriteria);
			
			String strGroupCriteriaLevel1 = "{'$group': {'_id': {'inquiryId': '$_id', 'assignedGroupId': '$workflows.assignedGroupId'}, 'doc': {'$first': '$$ROOT'}}}";
			String strGroupCriteriaLevel2 =	"{'$replaceRoot': {'newRoot': '$doc'}}";
			
			@SuppressWarnings("deprecation")
			BasicDBObject groupLevelCriteriaLevel1 = BasicDBObject.parse(strGroupCriteriaLevel1);
			queryList.add(groupLevelCriteriaLevel1);
			@SuppressWarnings("deprecation")
			BasicDBObject groupLevelCriteriaLevel2 = BasicDBObject.parse(strGroupCriteriaLevel2);
			queryList.add(groupLevelCriteriaLevel2);
			
			} catch (Exception e) {
		subLogger.error("Exception in getIntensityHeatMapData DashboardDAO: ", e);
	}
	return queryList;
	}

		
		

	private BasicDBObject fetchTotalCount(List<BasicDBObject> query) {
		
		BasicDBObject cursorResultIntensity = new BasicDBObject();
		Cursor intesnsityCur =null;
		int totalCount = 0;
		try {
			DBCollection col = MongoDB.instance().getDB().getCollection(INQUIRY_COLLECTION);
			AggregationOptions options = AggregationOptions.builder().allowDiskUse(true).build();
			intesnsityCur = col.aggregate(query, options, ReadPreference.secondary());
			while (intesnsityCur.hasNext()) {
				BasicDBObject outputResult = (BasicDBObject) intesnsityCur.next();
				totalCount = null!=outputResult && null!=outputResult.get(TOTALCOUNT) ? outputResult.getInt(TOTALCOUNT) : 0;
			}
			subLogger.info("DashboardDAO fetchTotalCount {}", totalCount);
			cursorResultIntensity.put("totalRecords", totalCount);
		}finally {
			if(null!=intesnsityCur) {
				intesnsityCur.close();
			}
			
		}
		
		return cursorResultIntensity;
		
	}

	private List<BasicDBObject> applyGroupByForTotalCount(List<BasicDBObject> query,String soeId) {
		List<BasicDBObject> finalGetGridViewQueryWithGroupBy = query;
		String finalGetGridViewQuery = finalGetGridViewQueryWithGroupBy.toString();
		if(null!=finalGetGridViewQuery) {
			finalGetGridViewQuery = finalGetGridViewQuery.substring(0, finalGetGridViewQuery.length()-1)+","+QueryConstants.QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD+"]";
			finalGetGridViewQuery = finalGetGridViewQuery.replaceAll("#SOEID#", soeId);
		}
		finalGetGridViewQueryWithGroupBy = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(finalGetGridViewQuery));
		return finalGetGridViewQueryWithGroupBy;
	}

	private void modifyQueryWithDateConfig(List<BasicDBObject> query) {
		DBObject object = (DBObject) query.get(0).get(QueryConstants.MATCH_OPERATOR);
		//CacheDAO cacheDAO = CacheDAO.getInstance();
		if(null != QMACacheFactory.getCache().getConfigById("clientPriorityFromDate")
				&& null != QMACacheFactory.getCache().getConfigById("clientPriorityFromDate").getClientPriorityFromDate())
		{

			Date clientPriorityFromDate = QMACacheFactory.getCache().getConfigById("clientPriorityFromDate").getClientPriorityFromDate();
			//Date clientPriorityFromDate = getDateConfigForMailStats("Default");
			BasicDBObject dateCrit = new BasicDBObject("$gte",clientPriorityFromDate);
			object.put("crtDate",dateCrit);
		}
	}

	/**
	 * This Method returns all dashboard settings for the soeId  
	 * @param soeId
	 * @return
	 */
	public BasicDBObject getDashboardSettings(String soeId) {
		BasicDBObject response = new BasicDBObject();
		try {
			Query<User> query = mongoDatastore.createQuery(User.class).filter(
					ID_KEY, soeId);
			subLogger.info("fetching dashboard settings for : " + query);
			List<User> user = query.asList();
			if (!user.isEmpty() && null != user.get(0)) {
				User firstUser = user.get(0);
				List<String> keys = Arrays.asList(MAILBOX_STATS, ASSIGNED_GROUPS, HEAT_MAP);

				if (firstUser.getDashboardSettings() != null) {
					for (String key : keys) {
						if (firstUser.getDashboardSettings().containsKey(key)) {
							response.put(key, firstUser.getDashboardSettings().get(key));
						}
					}
				} else {
					subLogger.info("No Dashboard data for soeid : " + soeId);
					BasicDBList messages = new BasicDBList();
					BasicDBList myViews = new BasicDBList();
					BasicDBObject mailBoxStats = new BasicDBObject();
					mailBoxStats.put("messages", messages);
					mailBoxStats.put("myViews", myViews);
					response.put(MAILBOX_STATS, mailBoxStats);
					response.put(ASSIGNED_GROUPS, new BasicDBList());
					response.put(HEAT_MAP, new BasicDBList());
				}
			} else {
				throw new IllegalArgumentException("User not found on database");
			}
			
		} catch (Exception e) {
			response.put(STATUS, false);
			response.put(MESSAGE, e.getMessage());
			subLogger.error(
					"Exception while saving dashboard settings in getDashboardSettings, Reason: " + e.getMessage());
		}
		return response;
	}

	/**
	 * This method save mailBoxStats in dashboardSettings
	 * @param soeId
	 * @param request
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBObject saveDashboardSettings(String soeId, String request) throws CommunicatorException {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			if (null != inputJsonObj.get(DASHBOARD_SETTINGS)) {
				Query<User> query = mongoDatastore.createQuery(User.class).filter(ID_KEY, soeId);
				UpdateOperations<User> userOps = mongoDatastore.createUpdateOperations(User.class);
				BasicDBObject inputJsonObjSettings = (BasicDBObject) inputJsonObj.get(DASHBOARD_SETTINGS);
				if (null != inputJsonObjSettings.get(MAILBOX_STATS)) {
					BasicDBObject mailBOxStats = (BasicDBObject) inputJsonObjSettings.get(MAILBOX_STATS);
					userOps.set("dashboardSettings.mailBoxStats", mailBOxStats);
				}
				if (null != inputJsonObjSettings.get(ASSIGNED_GROUPS)) {
					BasicDBList assignedGroupsList = (BasicDBList) inputJsonObjSettings.get(ASSIGNED_GROUPS);
					userOps.set("dashboardSettings.assignedGroups", assignedGroupsList);
				}
				if (null != inputJsonObjSettings.get(HEAT_MAP)) {
					BasicDBList requestTypesList = (BasicDBList) inputJsonObjSettings.get(HEAT_MAP);
					userOps.set("dashboardSettings.heatMap", requestTypesList);
				}
				if (null != inputJsonObjSettings.get(ALL_GROUPS_SELECTED)) {
					boolean allGroupsSelected =  Boolean.parseBoolean(inputJsonObjSettings.get(ALL_GROUPS_SELECTED).toString());
					userOps.set("dashboardSettings.allGroupsSelected", allGroupsSelected);
				}
				mongoDatastore.update(query, userOps);
				response.put(STATUS, true);
				response.put(MESSAGE, "Dashboard Settings saved successfully");
				HazelCastCacheIncrementalLoad.refreshUserCache(soeId);
			} else {
				response.put(STATUS, false);
				response.put(MESSAGE, "Dashboard Settings request is invalid");
			}
		} catch (Exception e) {
			response.put(STATUS, false);
			response.put(MESSAGE, "Dashboard Settings save failed");
			subLogger.error("Exception while saving dashboard settings in DashboardDAO.saveDashboardSettings : " + e);
		}
		return response;

	}
	

	/**
	 * This method provides counts for all 
	 * @param soeId
	 * @return BasicDBObject
	 */
	public BasicDBObject getDashboardCounts(String soeId) {
		
		BasicDBObject response = new BasicDBObject();
		
		try {
			BasicDBList boxCounts = getDashboardBoxCount(soeId);
			response.put(BOX_COUNTS_KEY, boxCounts);
			
			/*
			 * Removed counts for custom views for performance impact
			 * BasicDBList viewCounts = getDashboardCustomViewCount(soeId);
			response.put(MY_VIEW_COUNTS_KEY, viewCounts);*/
			
		} catch (Exception e) {
			subLogger.error("Exception while getting dashboard count stats : ", e);
		}
		
		return response;
	}

	/**
	 * This method gets counts of all custom views
	 * @param soeId
	 * @return
	 */
	private BasicDBList getDashboardCustomViewCount(String soeId, BasicDBObject inputJsonObj) {
		BasicDBList userViewStats = new BasicDBList();
		try {
			List<Long> groupIds = new ArrayList<>();
			long startTime = System.currentTimeMillis();
			BasicDBList userViews = getUserViews(soeId);
			getAllAssignedGroups(soeId, groupIds);
			subLogger.debug("Total Time Diff for getting all assigned groups : " + (System.currentTimeMillis() - startTime) + " MS");
			getMyViewsDetails(groupIds, userViewStats, userViews, soeId, true, inputJsonObj);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(subLogger, "DashboardDAO#getDashboardCustomViewCount()", e);
		}
		return userViewStats;
	}

	/**
	 * @param soeId
	 * @param userViews
	 */
	private BasicDBList getUserViews(String soeId) {
		BasicDBList userViews = new BasicDBList();
		User user = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase());
		if( null != user.getViews() ) {
			List<ViewConfig> views = user.getViews();
			for(ViewConfig view : views){
				userViews.add(view.getViewName());
			}
		}
		return userViews;
	}

	/**
	 * @param soeId
	 * @return
	 */
	private BasicDBList getDashboardBoxCount(String soeId) {
		BasicDBList boxCounts = new BasicDBList();;
		try {
			List<DashBoardCntTO> dashboardCntList = inquiryDAO.getHomePageWidgetCount(soeId);
			if(null != dashboardCntList && !dashboardCntList.isEmpty()) {
				for(DashBoardCntTO cntTo : dashboardCntList) {
					BasicDBObject boxFinal = new BasicDBObject();
					BasicDBObject box = new BasicDBObject();
					box.put("count", cntTo.getCount());
					box.put("unReadCount", cntTo.getUnReadCount());
					boxFinal.put(cntTo.getCategory(), box);
					boxCounts.add(boxFinal);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in getDashboardBoxCount for soeId : "+ soeId, e);
		}
		return boxCounts;
	}
	
	

	public BasicDBObject getMailBoxStats(String soeId, String request)  {
		
		BasicDBObject response = new BasicDBObject();
		
		try {
			String inputDataRequest = request;
			if(StringUtils.isEmpty(inputDataRequest)) {
				inputDataRequest = "{}";
				//inputDataRequest = "{'groupName':'all'}";
			}
			
			BasicDBObject inputJsonObj = BasicDBObject.parse(inputDataRequest);
			
			List<Long> groupIds = new ArrayList<>();
			
			BasicDBList mailBoxStat = new BasicDBList();

			if( StringUtils.isNotEmpty(soeId) && null != inputJsonObj.getString(GROUP_NAME_KEY) ) {
				
				Map<String, Object> dashboardSettings = getUserDashboardSettings(soeId);
				
				if (null != dashboardSettings) {
					String groupName = inputJsonObj.getString(GROUP_NAME_KEY).trim();

					if (StringUtils.isNotEmpty(groupName) && !GROUP_ALL.equalsIgnoreCase(groupName)
							&& null != QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase())) {
						groupIds.add(QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase()));
					} else {
						getUserGroups(groupIds, dashboardSettings);
					}

					if (groupIds.isEmpty()) {
						getAllAssignedGroups(soeId, groupIds);
					}

					mailBoxStat = getMailBoxStatsForUser(soeId, groupIds, dashboardSettings, inputJsonObj);

					response.put(MAIL_BOX_STAT_KEY, mailBoxStat);
				}else{
					setDefaultMailboxstats(soeId, response, groupIds, mailBoxStat, inputJsonObj);
				}
				
			} else {
				setDefaultMailboxstats(soeId, response, groupIds, mailBoxStat, inputJsonObj);
			}
			
		} catch (Exception e) {
			subLogger.error("Exception while getting mailbox stats : ", e);
		}
		return response;
	}
	
	/** to return data for each mailbox
	 * @param soeId
	 * @param request
	 * @return
	 */
	public BasicDBObject getMailBoxStatsPerView(String soeId, String request)  {
		
		BasicDBObject response = new BasicDBObject();
		
		try {
			String inputDataRequest = request;
			if(StringUtils.isEmpty(inputDataRequest)) {
				inputDataRequest = "{}";
			}
			
			BasicDBObject inputJsonObj = BasicDBObject.parse(inputDataRequest);
			
			List<Long> groupIds = new ArrayList<>();
			
			BasicDBList mailBoxStat = new BasicDBList();

			if( StringUtils.isNotEmpty(soeId) ) {
				
				Map<String, Object> dashboardSettings = getUserDashboardSettings(soeId);
				
				if (null != inputJsonObj.get(GROUP_NAME_KEY) ) {
					String groupName = inputJsonObj.getString(GROUP_NAME_KEY).trim();

					if (StringUtils.isNotEmpty(groupName) && !GROUP_ALL.equalsIgnoreCase(groupName)
							&& null != QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase())) {
						groupIds.add(QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase()));
					} else {
						getUserGroups(groupIds, dashboardSettings);
					}

					if (groupIds.isEmpty()) {
						getAllAssignedGroups(soeId, groupIds);
					}
					//mailBoxStat = getMailBoxStatsForUser(soeId, groupIds, dashboardSettings, inputJsonObj);
					if(null != inputJsonObj && null != inputJsonObj.get("messages") 
							&& StringUtils.isNotEmpty(inputJsonObj.getString("messages"))) {
						String viewName = inputJsonObj.getString("messages");
						getViewStats(groupIds, mailBoxStat, viewName,soeId, inputJsonObj);
					} else if(null != inputJsonObj && null != inputJsonObj.get("myViews")
							&& StringUtils.isNotEmpty(inputJsonObj.getString("myViews"))) {
						String savedSearchName = inputJsonObj.getString("myViews");
						getMyViewDetailsStats(groupIds, mailBoxStat, soeId, true, savedSearchName, inputJsonObj);
					}
					response.put(MAIL_BOX_STAT_KEY, mailBoxStat);
				} else{
					subLogger.info(GROUP_NAME_KEY+" is Empty in getMailBoxStatsPerView");
				}
				
			} else {
				subLogger.info("soeId is Empty in getMailBoxStatsPerView");
			}
			
		} catch (Exception e) {
			subLogger.error("Exception in getMailBoxStatsPerView : ", e);
		}
		return response;
	}

/**
 * @param soeId
 * @param request
 * @return
 */
public BasicDBObject getMailBoxStatsWithExecutor(String soeId, String request)  {
		
		BasicDBObject response = new BasicDBObject();
		
		try {
			String inputDataRequest = request;
			if(StringUtils.isEmpty(inputDataRequest)) {
				inputDataRequest = "{}";
				//inputDataRequest = "{'groupName':'all'}";
			}
			
			BasicDBObject inputJsonObj = BasicDBObject.parse(inputDataRequest);
			
			List<Long> groupIds = new ArrayList<>();
			
			BasicDBList mailBoxStat = new BasicDBList();

			if( StringUtils.isNotEmpty(soeId) && null != inputJsonObj.getString(GROUP_NAME_KEY) ) {
				
				Map<String, Object> dashboardSettings = getUserDashboardSettings(soeId);
				
				if (null != dashboardSettings) {
					String groupName = inputJsonObj.getString(GROUP_NAME_KEY).trim();

					if (StringUtils.isNotEmpty(groupName) && !GROUP_ALL.equalsIgnoreCase(groupName)
							&& null != QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase())) {
						groupIds.add(QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase()));
					} else {
						getUserGroups(groupIds, dashboardSettings);
					}

					if (groupIds.isEmpty()) {
						getAllAssignedGroups(soeId, groupIds);
					}

					mailBoxStat = getMailBoxStatsForUserWithExecutor(soeId, groupIds, dashboardSettings, inputJsonObj);

					response.put(MAIL_BOX_STAT_KEY, mailBoxStat);
				}else{
					setDefaultMailboxstats(soeId, response, groupIds, mailBoxStat, inputJsonObj);
				}
				
			} else {
				setDefaultMailboxstats(soeId, response, groupIds, mailBoxStat, inputJsonObj);
			}
			
		} catch (Exception e) {
			subLogger.error("Exception while getting mailbox stats : ", e);
		}
		return response;
	}

	/**
	 * @param soeId
	 * @param response
	 * @param groupIds
	 * @param mailBoxStat
	 * @throws CommunicatorException
	 */
	private void setDefaultMailboxstats(String soeId, BasicDBObject response, List<Long> groupIds,
			BasicDBList mailBoxStat, BasicDBObject inputJsonObj) throws CommunicatorException {
		subLogger.info("No Dashboard settings available for user :" + soeId);
		setDefaultViews(soeId, groupIds, mailBoxStat, inputJsonObj);
		response.put(MAIL_BOX_STAT_KEY, mailBoxStat);
	}

	/**
	 * This method return user dashboard settings from database.
	 * @param soeId
	 * @return Map<String, Object> 
	 * @throws CommunicatorException 
	 */
	private Map<String, Object> getUserDashboardSettings(String soeId) {
		
		Map<String, Object> userDashboardSettings = null;
		
		try {
			if(StringUtils.isNotEmpty(soeId)){
				User user = userDao.getUserById(soeId);
				if( null != user && null != user.getDashboardSettings() ) {
					userDashboardSettings = user.getDashboardSettings();
				}
			} else {
				subLogger.warn("'soeId' is null or empty while getting user dashboard settings.");
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(subLogger, "DashboardDAO#getUserDashboardSettings()", e);
		}
		
		return userDashboardSettings;
	}

	/**
	 * This method will set default views for mail box stats
	 * @param soeId
	 * @param groupIds
	 * @param mailBoxStat
	 * @throws CommunicatorException
	 */
	private void setDefaultViews(String soeId, List<Long> groupIds, BasicDBList mailBoxStat, BasicDBObject inputJsonObj)
			throws CommunicatorException {
		getAllAssignedGroups(soeId, groupIds);
		BasicDBList messages = new BasicDBList();
		if(null != QMACacheFactory.getCache().getConfigById(DEFAULT_VIEWS_IN_QMA)) {
			List<String> defaultViewsForMailboxStats = QMACacheFactory.getCache().getConfigById(DEFAULT_VIEWS_IN_QMA).getDefaultViewsForMailboxStats();
			for(String viewName :defaultViewsForMailboxStats){
				messages.add(viewName);
			}
			getMessageDetails(groupIds, mailBoxStat, messages,soeId, inputJsonObj);
		}
	}
	
	/**
	 * @param soeId
	 * @param groupIds
	 * @param mailBoxStat
	 * @param threadService
	 * @param futures
	 * @throws CommunicatorException
	 */
	private void setDefaultViews(String soeId, List<Long> groupIds, BasicDBList mailBoxStat, ExecutorService threadService, List<Future<BasicDBList>> futures, BasicDBObject inputJsonObj)
			throws CommunicatorException {
		getAllAssignedGroups(soeId, groupIds);
		BasicDBList messages = new BasicDBList();
		if(null != QMACacheFactory.getCache().getConfigById(DEFAULT_VIEWS_IN_QMA)) {
			List<String> defaultViewsForMailboxStats = QMACacheFactory.getCache().getConfigById(DEFAULT_VIEWS_IN_QMA).getDefaultViewsForMailboxStats();
			for(String viewName :defaultViewsForMailboxStats){
				messages.add(viewName);
			}
			getMessageDetails(groupIds, mailBoxStat, messages,soeId, threadService, futures, inputJsonObj);
		}
	}

	/**
	 * This method collects all the assigned groups of provided user. 
	 * @param soeId
	 * @param groupIds
	 * @throws CommunicatorException
	 */
	void getAllAssignedGroups(String soeId, List<Long> groupIds) throws CommunicatorException {
		if(StringUtils.isNotEmpty(soeId)){
			User user = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase());
			if( null != user ){
				Set<Long> userGroupsList = userDao.getUserGroupsList(user);
				for(Long grpId : userGroupsList) {
					groupIds.add(grpId);
				}
			} else {
				subLogger.warn("User not found in cache for soeID : {}",soeId);
			}
		} else {
			subLogger.warn("'soeId' is either blank or empty.");
		}
	}

	/**
	 * This method collects list of groups assigned to user in dash-board settings.
	 * @param groupIds
	 * @param dashboardSettings
	 */
	private void getUserGroups(List<Long> groupIds, Map<String, Object> dashboardSettings) {
		
		if( null!= dashboardSettings && null!= dashboardSettings.get(AppserverConstants.DS_MY_ASSIGNED_GROUPS)) {
			BasicDBList assignedGrpData = (BasicDBList) dashboardSettings.get(AppserverConstants.DS_MY_ASSIGNED_GROUPS);
			if(null!= assignedGrpData){
				for(int i=0;i<assignedGrpData.size();i++){
					BasicDBObject currentGrp = (BasicDBObject)assignedGrpData.get(i);
					if(StringUtils.isNotEmpty(currentGrp.getString(GROUP_NAME_KEY)) &&
							null != QMACacheFactory.getCache().getGroupCodeToIdMap().get(currentGrp.getString(GROUP_NAME_KEY).toUpperCase())){
						groupIds.add(QMACacheFactory.getCache().getGroupCodeToIdMap().get(currentGrp.getString(GROUP_NAME_KEY).toUpperCase()));
					}
				}
			} else {
				subLogger.warn("No dashboard setting set for the current user");
			}
		}
	}

	/**
	 * This method provides list of mail box stats
	 * @param soeId
	 * @param groupIds
	 * @param dashboardSettings
	 * @return BasicDBList
	 */
	private BasicDBList getMailBoxStatsForUser(String soeId, List<Long> groupIds, Map<String, Object> dashboardSettings,BasicDBObject inputJsonObj) {
		BasicDBList mailBoxStats = new BasicDBList();
		try {
			if( null != dashboardSettings.get(AppserverConstants.DS_MAIL_BOX_STATS_KEY)) {
				BasicDBObject userMailBoxStatsSettings = (BasicDBObject)dashboardSettings.get(AppserverConstants.DS_MAIL_BOX_STATS_KEY);
				mailBoxStats = getUserMailBoxStats(userMailBoxStatsSettings, groupIds, soeId, inputJsonObj);
			} else {
				subLogger.info("No Mail Box Stats settings available in dashboard settings for user :" + soeId);
				setDefaultViews(soeId, groupIds, mailBoxStats, inputJsonObj);
			}
		} catch (Exception e) {
			subLogger.error("Exception in InquiryDAO:getMailBoxStatsForUser(): ",e);
		}
		return mailBoxStats;
	}
	
	/**
	 * @param soeId
	 * @param groupIds
	 * @param dashboardSettings
	 * @return
	 */
	private BasicDBList getMailBoxStatsForUserWithExecutor(String soeId, List<Long> groupIds, Map<String, Object> dashboardSettings, BasicDBObject inputJsonObj) {
		BasicDBList mailBoxStats = new BasicDBList();
		try {
			//initialize thread service and future
			List<Future<BasicDBList>> futures = new ArrayList<>();
			ExecutorService threadService = Executors.newFixedThreadPool(MAILBOX_STATS_THREAD_COUNT);
			if( null != dashboardSettings.get(AppserverConstants.DS_MAIL_BOX_STATS_KEY)) {
				BasicDBObject userMailBoxStatsSettings = (BasicDBObject)dashboardSettings.get(AppserverConstants.DS_MAIL_BOX_STATS_KEY);
				mailBoxStats = getUserMailBoxStats(userMailBoxStatsSettings, groupIds, soeId, threadService, futures, inputJsonObj);
			} else {
				subLogger.info("No Mail Box Stats settings available in dashboard settings for user :" + soeId);
				setDefaultViews(soeId, groupIds, mailBoxStats, threadService, futures, inputJsonObj);
			}
			//read value from future and shut down thread service
			readFutureAndStopExecutor(mailBoxStats, futures, threadService);
		} catch (Exception e) {
			subLogger.error("Exception in InquiryDAO:getMailBoxStatsForUser(): ",e);
		}
		return mailBoxStats;
	}

	/** this method read values from future and shutdown thread service
	 * @param mailBoxStats
	 * @param futures
	 * @param threadService
	 */
	private void readFutureAndStopExecutor(BasicDBList mailBoxStats, List<Future<BasicDBList>> futures,
			ExecutorService threadService) {
		try {
			shutDownExecutorService(threadService);
			for(Future<BasicDBList> fut : futures){
				subLogger.info("future gets : "+ fut.get());
		    	mailBoxStats.add(fut.get().get(0));
		    	subLogger.info("mailBoxStats gets : "+ mailBoxStats); 
			}
			
		} catch (Exception e) {
			subLogger.error("exception in readFutureAndStopExecutor ", e);
		}
	}
	
	/**
	 * This method initiates shut down of all the threads started
	 * 
	 * @param threadService
	 */
	private void shutDownExecutorService(ExecutorService threadService)
	{
		try
		{
			threadService.shutdown();
			/* Below code will wait till all threads completes execution */
			if (!threadService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS))
			{
				threadService.shutdown();
			}

		}
		catch (InterruptedException e)
		{
			threadService.shutdownNow();
			Thread.currentThread().interrupt();
		}
	}
	
	/**
	 * This method gets mail box stats of all qualified views
	 * @param userMailBoxStatsSettings
	 * @param groupIds
	 * @param soeId
	 * @return BasicDBList
	 */
	private BasicDBList getUserMailBoxStats(BasicDBObject userMailBoxStatsSettings, List<Long> groupIds, String soeId, BasicDBObject inputJsonObj) {
		
		BasicDBList mailBoxStats = new BasicDBList();
		BasicDBList messages = new BasicDBList();
		BasicDBList myViews = new BasicDBList();
		
		try {
			
			if ( null != userMailBoxStatsSettings ) {
				
				if(null!=userMailBoxStatsSettings.get(AppserverConstants.DS_MESSAGES)){
					messages = (BasicDBList) userMailBoxStatsSettings.get(AppserverConstants.DS_MESSAGES);
					getMessageDetails(groupIds, mailBoxStats, messages,soeId, inputJsonObj);
				}
				
				if(null!= userMailBoxStatsSettings.get(AppserverConstants.DS_MY_VIEWS)){
					myViews = (BasicDBList) userMailBoxStatsSettings.get(AppserverConstants.DS_MY_VIEWS);
					getMyViewsDetails(groupIds, mailBoxStats, myViews, soeId, false, inputJsonObj);
				}
			}
			
			if(messages.isEmpty() && myViews.isEmpty()) {
				setDefaultViews(soeId, groupIds, mailBoxStats, inputJsonObj);
			}
			
			
		} catch (Exception e) {
			subLogger.error("Exception while calculating mail box stats for user : ", e);
			
		}
		return mailBoxStats;
	}
	
/** this method get the mailbox stats using executor
 * @param userMailBoxStatsSettings
 * @param groupIds
 * @param soeId
 * @param threadService
 * @param futureList
 * @return
 */
private BasicDBList getUserMailBoxStats(BasicDBObject userMailBoxStatsSettings, List<Long> groupIds, String soeId, ExecutorService threadService, List<Future<BasicDBList>> futureList, BasicDBObject inputJsonObj) {
		
		BasicDBList mailBoxStats = new BasicDBList();
		BasicDBList messages = new BasicDBList();
		BasicDBList myViews = new BasicDBList();
		
		try {
			
			if ( null != userMailBoxStatsSettings ) {
				
				if(null!=userMailBoxStatsSettings.get(AppserverConstants.DS_MESSAGES)){
					messages = (BasicDBList) userMailBoxStatsSettings.get(AppserverConstants.DS_MESSAGES);
					//getMessageDetails(groupIds, mailBoxStats, messages,soeId);
					getMessageDetails(groupIds, mailBoxStats, messages,soeId, threadService, futureList, inputJsonObj);
				}
				
				if(null!= userMailBoxStatsSettings.get(AppserverConstants.DS_MY_VIEWS)){
					myViews = (BasicDBList) userMailBoxStatsSettings.get(AppserverConstants.DS_MY_VIEWS);
					//getMyViewsDetails(groupIds, mailBoxStats, myViews, soeId, false);
					getMyViewsDetails(groupIds, mailBoxStats, myViews, soeId, false,threadService, futureList, inputJsonObj);
				}
			}
			
			if(messages.isEmpty() && myViews.isEmpty()) {
				setDefaultViews(soeId, groupIds, mailBoxStats,threadService, futureList, inputJsonObj);
			}
			
		} catch (Exception e) {
			subLogger.error("Exception while calculating mail box stats for user : ", e);
			
		}
		return mailBoxStats;
	}

	
	/**
	 * This method gets mailbox stats or message views
	 * @param groupIds
	 * @param mailBoxStats
	 * @param messages
	 */
	void getMessageDetails(List<Long> groupIds, BasicDBList mailBoxStats, BasicDBList messages, String soeId, BasicDBObject inputJsonObj) {
		if(null != inputJsonObj && null != inputJsonObj.get("messages")) {
			String viewName = inputJsonObj.getString("messages");
			getViewStats(groupIds, mailBoxStats, viewName,soeId, inputJsonObj);
		}
		else if( null != messages && messages.size() > 0) {
			for(int i=0; i<messages.size(); i++) {
				String viewName = (String) messages.get(i);
				getViewStats(groupIds, mailBoxStats, viewName,soeId, inputJsonObj);
			}
			
		}
		
	}
	
	
	
	/**
	 * @param groupIds
	 * @param mailBoxStats
	 * @param messages
	 * @param soeId
	 * @param threadService
	 * @param futureList
	 */
	private void getMessageDetails(List<Long> groupIds, BasicDBList mailBoxStats, BasicDBList messages, String soeId, ExecutorService threadService, List<Future<BasicDBList>> futureList, BasicDBObject inputJsonObj) {
		
		if( null != messages && messages.size() > 0) {
			for(int i=0; i<messages.size(); i++) {
				String viewName = (String) messages.get(i);
				MailBoxCountExecutor callable = new MailBoxCountExecutor(true, groupIds, viewName, soeId, false, null, inputJsonObj);
				//getViewStats(groupIds, mailBoxStats, viewName,soeId);
				Future<BasicDBList> future = (Future<BasicDBList>) threadService.submit(callable);
				futureList.add(future);
				subLogger.info("future added for message view "+ viewName);
			}
			
			
		}
		
	}
	
	
	/**
	 * @param groupIds
	 * @param mailBoxStats
	 * @param myViews
	 * @param soeId
	 * @param isOnlyViewCountRequest
	 * @param threadService
	 * @param futureList
	 * @throws CommunicatorException
	 */
	private void getMyViewsDetails(List<Long> groupIds, BasicDBList mailBoxStats, BasicDBList myViews, String soeId, boolean isOnlyViewCountRequest, ExecutorService threadService, List<Future<BasicDBList>> futureList, BasicDBObject inputJsonObj) throws CommunicatorException {
		if( null != myViews && myViews.size() > 0) {
			for(int i=0; i<myViews.size(); i++){
				String savedSearchName = (String) myViews.get(i);
				MailBoxCountExecutor callable = new MailBoxCountExecutor(false, groupIds, null, soeId, isOnlyViewCountRequest, savedSearchName, inputJsonObj);
				//getMyViewDetailsStats(groupIds, mailBoxStats, soeId, isOnlyViewCountRequest, savedSearchName);
				Future<BasicDBList> future = (Future<BasicDBList>) threadService.submit(callable);
				futureList.add(future);
				subLogger.info("future added for my view "+ savedSearchName);
			}
		}
	}

	public void getMyViewDetailsStats(List<Long> groupIds, BasicDBList mailBoxStats, String soeId,
			boolean isOnlyViewCountRequest, String savedSearchName, BasicDBObject inputJsonObj) throws CommunicatorException {
		if(StringUtils.isNotEmpty(savedSearchName)){
			BasicDBObject boxData = new BasicDBObject();
			if(null != inputJsonObj && null != inputJsonObj.get("reqType") && "totalCount".equalsIgnoreCase(inputJsonObj.getString("reqType"))) {
				boxData = getSavedSearchDetails(savedSearchName.trim(),groupIds, soeId,false);
			}
			mailBoxStats.add(boxData);
		}
	}

	/**
	 * This method gets view stats
	 * @param groupIds
	 * @param mailBoxStats
	 * @param viewName
	 */
	public void getViewStats(List<Long> groupIds, BasicDBList mailBoxStats, String viewName, String soeId, BasicDBObject inputJsonObj) {
		if(StringUtils.isNotEmpty(viewName)){
			String viewQuery = getViewQuery(viewName.trim(),soeId);
			/*[C170665-1061] - get only today's count for resolved and sent*/
			long dateCriteria = 0L;
			if( StringUtils.isNotEmpty(viewName) && ( "resolved".equalsIgnoreCase(viewName)  || "sent".equalsIgnoreCase(viewName)
					|| "outbox".equalsIgnoreCase(viewName) ) ) {
				if("OUTBOX".equalsIgnoreCase(viewName)|| "sent".equalsIgnoreCase(viewName)) {
					viewQuery = viewQuery.substring(0, viewQuery.length()-1)+","+QueryConstants.QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD_OUT+"]";
				}else {
					viewQuery = viewQuery.substring(0, viewQuery.length()-1)+","+QueryConstants.QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD+"]";
				}
				Date today =  GenericUtility.getTodaysDate();
				if(null!= today) {
					dateCriteria = today.getTime();
					viewQuery = viewQuery.replaceAll("#MOD_DATE#", String.valueOf(dateCriteria));
				}
				
			} else {
				if("Pending Approval".equalsIgnoreCase(viewName)) {
					viewQuery = viewQuery.substring(0, viewQuery.length()-1)+","+QueryConstants.QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD_PENDING_APPROVAL+"]";
				}else if("Potential Escalation".equalsIgnoreCase(viewName)) {
					viewQuery = viewQuery.substring(0, viewQuery.length()-1)+","+QueryConstants.QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD_ESCALATION+"]";
				}else {
					viewQuery = viewQuery.substring(0, viewQuery.length()-1)+","+QueryConstants.QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD+"]";
				}
				String viewNameForModDate= viewName;
				try {
					Map<String, Integer> viewsSortedMapForUserId = inquiryDAO.getUserDateConfigForViewFromCache(soeId);
					if(null != viewsSortedMapForUserId && viewsSortedMapForUserId.size() > 0) {
						viewNameForModDate = (String) viewsSortedMapForUserId.keySet().toArray()[0];
					}
				} catch (Exception e) {
					subLogger.warn("Error while getting viewName from config:"+viewNameForModDate, e);
				}
				Date dateCriteriaDafault =  MailboxModDateUtil.getModDateAsPerDateConfig(soeId, inputJsonObj, viewNameForModDate,true);
				if(null != dateCriteriaDafault) {
					Long dateLong = dateCriteriaDafault.getTime();
					viewQuery = viewQuery.replaceAll("#MOD_DATE#", dateLong.toString());
				}
			}
			viewQuery = viewQuery.replaceAll("#SOEID#", soeId);
			
			if(StringUtils.isNotEmpty(viewQuery)){
				BasicDBObject boxData = new BasicDBObject();
				
				if(null != inputJsonObj && null != inputJsonObj.get("reqType") && "totalCount".equalsIgnoreCase(inputJsonObj.getString("reqType"))) {
					boxData = getDataForQuery(viewName, viewQuery, groupIds, soeId, false);
				} 
				mailBoxStats.add(boxData);
			}
		}
	}

	/**
	 * This method gets the view details
	 * @param groupName
	 * @param mailBoxStats
	 * @param myViews
	 * @throws CommunicatorException 
	 */
	void getMyViewsDetails(List<Long> groupIds, BasicDBList mailBoxStats, BasicDBList myViews, String soeId, boolean isOnlyViewCountRequest, BasicDBObject inputJsonObj) throws CommunicatorException {
		if(null != inputJsonObj && null != inputJsonObj.get("myViews")) {
			
			String savedSearchName = inputJsonObj.getString("myViews");
			getMyViewDetailsStats(groupIds, mailBoxStats, soeId, isOnlyViewCountRequest, savedSearchName, inputJsonObj);
		}
		else if( null != myViews && myViews.size() > 0) {
			for(int i=0; i<myViews.size(); i++){
				String savedSearchName = (String) myViews.get(i);
				getMyViewDetailsStats(groupIds, mailBoxStats, soeId, isOnlyViewCountRequest, savedSearchName, inputJsonObj);
			}
		}
	}
	
	


	/**
	 * This method identifies query for provided view.
	 * @param viewName
	 * @return String
	 */
	String getViewQuery(String viewName, String soeId) {
		
		String query = null; 
		
		switch (viewName) {
		case VIEW_INBOX:
			query = QueryConstants.INBOX_QUERY_FOR_MAILBOX_STATS;
			break;
		case VIEW_OUTBOX:
			query = QueryConstants.OUTBOX_QUERY_FOR_MAILBOX_STATS;
			break;
		case VIEW_RESOLVED:
			query = QueryConstants.RESOLVED_BOX_QUERY_FOR_MAILBOX_STATS;
			break;
		case VIEW_PENDING_APPROVAL :
			query = QueryConstants.PENDING_APPROVAL_QUERY_FOR_MAILBOX_STATS;
			break;
		case VIEW_POTENTIAL_ESCALATION :
			query = QueryConstants.POTENTIAL_ESCALATION_QUERY_FOR_MAILBOX_STATS;
			break;
		case VIEW_SNOOZED :
			query = QueryConstants.SNOOZED_QUERY_FOR_MAILBOX_STATS;
			break;
		case VIEW_ASSIGNED_TO_ME :
			query = QueryConstants.ASSIGNED_TO_ME_QUERY_FOR_MAILBOX_STATS;
			query = query.replace(QueryConstants.ASSIGNED_USER_ID_EXP, soeId);
			break;
		case VIEW_UNASSIGNED :
			query = QueryConstants.UNASSIGNED_QUERY_FOR_MAILBOX_STATS;
			break;
		case VIEW_NON_INQUIRIES :
			query = QueryConstants.NON_INQUIRY_QUERY_FOR_MAILBOX_STATS;
			break;
		case VIEW_FYI :
			query = QueryConstants.FYI_QUERY_FOR_MAILBOX_STATS;
			break;
		case VIEW_PERSOANL_MAIL :
			query = QueryConstants.PERSONAL_MAIL_QUERY_FOR_MAILBOX_STATS;
			break;
		/*case VIEW_DRAFTS :
			query = QueryConstants.DRAFTS_QUERY;
			query = query.replace(QueryConstants.ASSIGNED_USER_ID_EXP, soeId);
			break;*/
		default:
			break;
		}
		
		return query;
	}


	/**
	 * @param viewName
	 * @param soeId
	 * @return
	 */
	String getViewQueryForBoxCount(String viewName, String soeId) {
		
		String query = null; 
		
		switch (viewName) {
		case VIEW_INBOX:
			query = QueryConstants.INBOX_QUERY;
			break;
		case VIEW_OUTBOX:
			query = QueryConstants.OUTBOX_QUERY;
			break;
		case VIEW_RESOLVED:
			query = QueryConstants.RESOLVED_BOX_QUERY;
			break;
		case VIEW_PENDING_APPROVAL :
			query = QueryConstants.PENDING_APPROVAL_QUERY;
			break;
		case VIEW_POTENTIAL_ESCALATION :
			query = QueryConstants.POTENTIAL_ESCALATION_QUERY;
			break;
		case VIEW_SNOOZED :
			query = QueryConstants.SNOOZED_QUERY;
			break;
		case VIEW_ASSIGNED_TO_ME :
			query = QueryConstants.ASSIGNED_TO_ME_QUERY;
			query = query.replace(QueryConstants.ASSIGNED_USER_ID_EXP, soeId);
			break;
		case VIEW_UNASSIGNED :
			query = QueryConstants.UNASSIGNED_QUERY;
			break;
		case VIEW_NON_INQUIRIES :
			query = QueryConstants.NON_INQUIRY_QUERY;
			break;
		case VIEW_FYI :
			query = QueryConstants.FYI_QUERY_COUNT;
			break;
		case VIEW_PERSOANL_MAIL :
			query = QueryConstants.PERSONAL_MAIL_QUERY_COUNT;
			break;
		/*case VIEW_DRAFTS :
			query = QueryConstants.DRAFTS_QUERY;
			query = query.replace(QueryConstants.ASSIGNED_USER_ID_EXP, soeId);
			break;*/
		default:
			break;
		}
		
		return query;
	}
		
	/**
	 * This method gets stats data for provided query. 
	 * @param viewName
	 * @param inputQuery
	 * @param groupIds
	 * @return BasicDBObject
	 */
	BasicDBObject getDataForQuery(String viewName, String inputQuery, List<Long> groupIds, String soeId, boolean isOnlyViewCountRequest) {

		BasicDBObject data = new BasicDBObject();
		try {
			
			String finalQuery = inputQuery.replace(QueryConstants.GROUP_ID_EXP, groupIds.toString());
			
			List<BasicDBObject> finalQueryListObject = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(finalQuery));
			/*if("RESOLVED".equalsIgnoreCase(viewName) || "OUTBOX".equalsIgnoreCase(viewName)) {
				updateMailBoxStatQueryWithDateConfig(viewName, finalQueryListObject, subLogger);
			}*/
			finalQuery = finalQueryListObject.toString(); 
			//@SuppressWarnings({ "unchecked", "deprecation" })
			//List<DBObject> query = (List<DBObject>) JSON.parse(finalQuery);
			data =  getDataForQuery(viewName, finalQueryListObject,isOnlyViewCountRequest, groupIds, soeId);
			
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(subLogger, "DashboardDAO#getDataForQuery()", e);
		}
		return data;
	}

	/**
	 * @param viewName
	 * @param finalQueryListObject
	 * @param logger 
	 */
	public void updateMailBoxStatQueryWithDateConfig(String viewName, List<DBObject> finalQueryListObject, Logger logger) {
		try {
			DBObject topLevelCriteria = null;
			if(null != finalQueryListObject && null != finalQueryListObject.get(0) && null != finalQueryListObject.get(0).get("$match")) {
				topLevelCriteria = (DBObject) finalQueryListObject.get(0).get("$match");
				topLevelCriteria = InquiryExtendedDAO.getInstance().updateFinalCriteriaWithDateConfig(viewName, topLevelCriteria);
				BasicDBObject topLevelMatchCriteria = new BasicDBObject();
				topLevelMatchCriteria.put("$match",topLevelCriteria);
				finalQueryListObject.remove(0);
				finalQueryListObject.add(0, topLevelMatchCriteria);
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(logger, "DashboardDAO#updateMailBoxStatQueryWithDateConfig()", e);
		}
	}
	/**
	 * This method calculates age data for an inquiry
	 * @param viewName
	 * @param iterable
	 * @param groupIds 
	 * @return BasicDBObject
	 */
	private BasicDBObject calculateAndSetPercentIncereseDecreaseNew(String viewName, Iterable<DBObject> iterable,
			List<Long> groupIds, String soeId) {
		BasicDBObject viewData = new BasicDBObject();
		try {
			BasicDBObject statObject = getStatsFromData(iterable);
			viewData.put(CATEGORY_KEY, viewName);
			int totalCount = 0;
			int readCount = 0;
			int unReadCount = 0;
			if (null != statObject.get(QUERY_COUNT_KEY)) {
				totalCount = statObject.getInt(QUERY_COUNT_KEY);
				viewData.put(COUNT_KEY, totalCount);
			}
			if (null != statObject.get(QUERY_READ_COUNT_KEY)) {
				readCount = statObject.getInt(QUERY_READ_COUNT_KEY);
				unReadCount = totalCount - readCount;
				viewData.put(COUNT_UNREAD_KEY, unReadCount);
			}
			List<String> defaultViewsForMailboxStats = QMACacheFactory.getCache().getConfigById(DEFAULT_VIEWS_IN_QMA)
					.getDefaultViewNames();
			if (defaultViewsForMailboxStats.contains(viewName) && !VIEW_ASSIGNED_TO_ME.equalsIgnoreCase(viewName)) {
				calculateStatsUpDownPercentage(totalCount, groupIds, viewName, viewData, soeId);
			} else {
				calculatePercentageForMyViews(totalCount, viewName, viewData, soeId, groupIds);
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(subLogger, "DashboardDAO#calculateAndSetPercentIncereseDecrease()", e);
		}
		return viewData;
	}
	private void calculatePercentageForMyViews(int currentCount, String viewName, BasicDBObject viewData, String soeId, List<Long> groupIds) {
		float percentageCount = 0;
		float preCount = 0;
		Query<User> query = mongoDatastore.createQuery(User.class).filter(ID_KEY, soeId);
		User user = query.get();
		if (null != user.getPreviousDayBoxCount()) {
			String previousDayViewsCount = user.getPreviousDayBoxCount();
			BasicDBObject previousDayDbObject = BasicDBObject.parse(previousDayViewsCount);
			for(Long groupId:groupIds){
				if (null != previousDayDbObject && null != previousDayDbObject.get(viewName)
						&& previousDayDbObject.get(viewName) instanceof BasicDBObject
						&& null != ((BasicDBObject) previousDayDbObject.get(viewName)).get(groupId.toString())) {
					preCount = preCount + (int) ((BasicDBObject) previousDayDbObject.get(viewName)).get(groupId.toString());
				} else if (null != previousDayDbObject && null != previousDayDbObject.get(viewName) 
						&& (previousDayDbObject.get(viewName) instanceof Integer)) { // <-- sonar fix Correct one of the identical sub-expressions on both sides of operator "&&"
					preCount = preCount + (int) previousDayDbObject.get(viewName);
				}
			}
		}
		
		float diff = currentCount - preCount;
		if (currentCount != 0) {
			percentageCount = (diff * 100) / currentCount;
		}
		if(currentCount == 0) {
			percentageCount = (diff * 100) / 1;
		}
		if(preCount == 0){
			percentageCount = diff*100;
		}
		viewData.put(COUNT_KEY, currentCount);
		viewData.put(PREVIOUS_DAY_COUNT_KEY, preCount);
		if(diff == 0){
			viewData.put(PERCENT_WRT_PREV_DAY_KEY, percentageCount);
			viewData.put(UP_OR_DOWN_KEY, NOT_CHANGE_KEY );
		} else if(diff > 0){
			DecimalFormat df = new DecimalFormat();
			df.setMaximumFractionDigits(2);
			viewData.put(PERCENT_WRT_PREV_DAY_KEY, df.format(percentageCount));
			viewData.put(UP_OR_DOWN_KEY, INCREASE_KEY );
		}else {
			DecimalFormat df = new DecimalFormat();
			df.setMaximumFractionDigits(2);
			viewData.put(PERCENT_WRT_PREV_DAY_KEY, df.format(percentageCount*-1));
			viewData.put(UP_OR_DOWN_KEY, DECREASE_KEY );
		}

	}

	private void calculateStatsUpDownPercentage(int currentCount, List<Long> groupIds, String viewName, BasicDBObject viewData, String soeId) {
		float percentageCount=0;
		int prevDayViewCount=0;
		try {
			//TODO: add aggregate query to get count in single query
			for(Long groupId:groupIds){
				//Query<Group> query = mongoDatastore.createQuery(Group.class).filter("_id", groupId);
				Group group = QMACacheFactory.getCache().getAllGroupsMap().get(groupId);
				if (null != group && null != group.getPreviousDayBoxCount()) {
					BasicDBObject groupPreDayData = BasicDBObject.parse(group.getPreviousDayBoxCount());
					if (null != groupPreDayData && null != groupPreDayData.get(viewName)) {
						prevDayViewCount = prevDayViewCount + groupPreDayData.getInt(viewName);
					}
				}
			}	
			float diff = currentCount-prevDayViewCount;
			if(currentCount != 0){
				percentageCount = (diff*100)/currentCount;
			}
			if(currentCount == 0){
				percentageCount = (diff*100)/1;
			}
			if(prevDayViewCount == 0){
				percentageCount = diff*100;
			}
			viewData.put(COUNT_KEY, currentCount);
			viewData.put(PREVIOUS_DAY_COUNT_KEY, prevDayViewCount);
			if(diff == 0){
				viewData.put(PERCENT_WRT_PREV_DAY_KEY, percentageCount);
				viewData.put(UP_OR_DOWN_KEY, NOT_CHANGE_KEY );
			} else if(diff > 0){
				DecimalFormat df = new DecimalFormat();
				df.setMaximumFractionDigits(2);
				viewData.put(PERCENT_WRT_PREV_DAY_KEY, df.format(percentageCount));
				viewData.put(UP_OR_DOWN_KEY, INCREASE_KEY );
			}else {
				DecimalFormat df = new DecimalFormat();
				df.setMaximumFractionDigits(2);
				viewData.put(PERCENT_WRT_PREV_DAY_KEY, df.format(percentageCount*-1));
				viewData.put(UP_OR_DOWN_KEY, DECREASE_KEY );
			}
		} catch (Exception e) {
			subLogger.error("Error while calculateStatsUpDownPercentage: "+e);
		}
	}

	/**
	 * This method get stats for a query depending on age
	 * @param iterable
	 * @return BasicDBObject
	 */
	private BasicDBObject getStatsFromData(Iterable<DBObject> iterable) {
		BasicDBObject statObject = new BasicDBObject();
		for(DBObject object:iterable)
		{
			statObject.put(QUERY_COUNT_KEY, object.get("TOTAL_COUNT"));
			/* [C170665-1061] - get only today's count for resolved and sent */
			if(null!= object && null != object.get("TOTAL_READ_COUNT")) {
				statObject.put(QUERY_READ_COUNT_KEY, object.get("TOTAL_READ_COUNT"));
			}
		}
		return statObject;
	}

	/**
	 * This method gets age of an inquiry
	 * @param workflow
	 * @return long
	 */
	private long getAgeOfAnInquiry(BasicDBObject workflow) {
		long age = 0;
		
		if(null != workflow.get(ASSIGNED_GROUP_ID_KEY)){
			Object groupID = workflow.get(ASSIGNED_GROUP_ID_KEY);
			if( groupID != null && null != QMACacheFactory.getCache().getGroupAgeConfigMap()
					&& QMACacheFactory.getCache().getGroupAgeConfigMap().containsKey(groupID) ) {
				AgeAndTimeUtils.updateAgeData(groupID, workflow);
				age = workflow.getInt(AGE_IN_DAYS_KEY);
			} else {
				age = AgeAndTimeUtils.getAgeForNonHolidayConfig(workflow, "age");
			}
		}
		
		return age;
	}

		/**
	 * This method gets saved search details for a user
	 * @param viewName
	 * @param groupIds
	 * @param soeId
	 * @return BasicDBObject
	 * @throws CommunicatorException
	 */
private BasicDBObject getSavedSearchDetails(String viewName, List<Long> groupIds, String soeId, boolean isOnlyViewCountRequest) throws CommunicatorException {
		
		BasicDBObject savedSearchResult = new BasicDBObject();
		
		BasicDBList viewCriteria = getUserViewCriteria(viewName, soeId);
		
		if( null != viewCriteria && null != viewCriteria.get(0) && null != viewCriteria.get(1)){
		
			BasicDBObject queryCriteria = (BasicDBObject) viewCriteria.get(0);
			
			BasicDBObject viewCrit = new BasicDBObject(QueryConstants.MATCH_OPERATOR, (BasicDBObject) viewCriteria.get(1));
			inquiryDAO.getBsonObjForUserCtrWithDateObj(viewCrit, UI_CRITERIA_DATE_FORMAT);
			viewCriteria.remove(0);
			String testViewName = queryCriteria.getString(VIEW_TYPE_KEY);
			String viewQuery = getViewQuery(testViewName,soeId);
			//Long dateCriteria = getDateConfigForMailStats("CustomViews");
			//viewQuery = viewQuery.replaceAll("#MOD_DATE#", dateCriteria.toString());
			//For custom view viewType is -1 , it is used to get custom view date range from User preferences 
			BasicDBObject inputJsonObj = new BasicDBObject();
			inputJsonObj.put(VIEW_TYPE_KEY, "-1");
			Date dateCriteria =  MailboxModDateUtil.getModDateAsPerDateConfig(soeId, inputJsonObj, viewName,false);
			if(null != dateCriteria) {
				Long dateLong = dateCriteria.getTime();
				viewQuery = viewQuery.replaceAll("#MOD_DATE#", dateLong.toString());
			}
			String groupByQuery = "["+QueryConstants.QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD.replaceAll("#SOEID#", soeId)+"]";
					
			if(StringUtils.isNotEmpty(viewQuery)) {
				
				String finalQuery = viewQuery.replace(QueryConstants.GROUP_ID_EXP, groupIds.toString());
				
				List<BasicDBObject> query = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(finalQuery)); 
				query.add(viewCrit);
				List<BasicDBObject> groupCrit = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(groupByQuery)); 
//				List<DBObject> groupCrit = (List<DBObject>) DataConversionUtil.convertJSONToJavaSilently(groupByQuery, Object.class);
				query.addAll(groupCrit);
				
				savedSearchResult =  getDataForQuery(viewName, query, isOnlyViewCountRequest, groupIds, soeId);
			}
			
		}
		return savedSearchResult;
	}

	/**
	 * This method gets user view criteria for give user and view name
	 * @param viewName
	 * @param soeId
	 * @return BasicDBList
	 * @throws CommunicatorException
	 */
	BasicDBList getUserViewCriteria(String viewName, String soeId) throws CommunicatorException {
		
		ViewConfig userViewConfig = getUserViewConfigForViewName(soeId, viewName);
		
		@SuppressWarnings("deprecation")
		DBObject userViewCriteria = BasicDBObject.parse(userViewConfig.getCriteria());
		
		inquiryDAO.getBsonObjForUserCtrWithDateObj(userViewCriteria, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		
		@SuppressWarnings("deprecation")
		DBObject userViewDefaultCriteria = BasicDBObject.parse(userViewConfig.getDefaultCriteria());
		BasicDBList viewCriteria = null;
		if( userViewDefaultCriteria != null ) {
			viewCriteria = (BasicDBList) userViewDefaultCriteria.get(QueryConstants.AND_OPERATOR);
		}
		return viewCriteria;
	}

	/**
	 * This method gets data for provided query
	 * @param viewName
	 * @param query
	 * @param groupIds 
	 * @return BasicDBObject
	 */
	private BasicDBObject getDataForQuery(String viewName, List<BasicDBObject> query, boolean isOnlyViewCountRequest, List<Long> groupIds, String soeId) { 
		BasicDBObject result = new BasicDBObject();
		//DBCollection col = database.getCollection(INQUIRY_COLLECTION);
		//Cursor outputResult = col.aggregate(query, null, ReadPreference.secondaryPreferred());
	//	MongoDB.executeAggregatePipelineWithCursorReadPref(INQUIRY_COLLECTION,query,false,ReadPreference.secondaryPreferred());
//		MongoCursor<DBObject> outputResult= MongoDB.executeAggregatePipelineWithCursorReadPref(INQUIRY_COLLECTION, query, ReadPreference.secondaryPreferred(),false,DBObject.class);
		
		List<DBObject> outputResult = MongoDB.executeAggregatePipelineAndGetData(INQUIRY_COLLECTION, query, ReadPreference.secondary(),false,DBObject.class);
				
		if (null != outputResult) {
			if (isOnlyViewCountRequest) {
				result = getCountForView(viewName, outputResult);
			} else {
				//result = calculateAndSetPercentIncereseDecrease(viewName, outputResult.results(), groupIds, soeId);
				result = calculateAndSetPercentIncereseDecreaseNew(viewName, outputResult, groupIds, soeId);
			}
//			outputResult.close();
		}
		return result;
	}
	
	
	/**
	 * This method will provide counts for all the custome view boxes
	 * @param viewName
	 * @param iterable
	 * @param groupIds 
	 * @return
	 */
	private BasicDBObject getCountForView(String viewName, Iterable<DBObject> iterable) {
		BasicDBObject viewCount = new BasicDBObject();
		try {
			for(DBObject object:iterable){
				if(null != object.get(QUERY_COUNT_KEY)){
					viewCount.put(viewName, object.get(QUERY_COUNT_KEY));
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(subLogger, "DashboardDAO#getCountForView()", e);
		}
		return viewCount;
	}

	/**
	 * This method gets user view config for provided view name for a user from database 
	 * @param soeId
	 * @param viewName
	 * @return
	 * @throws CommunicatorException
	 */
	private ViewConfig getUserViewConfigForViewName(String soeId, String viewName) throws CommunicatorException {
		
		Query<User> query = mongoDatastore.createQuery(User.class).filter(ID_KEY, soeId).filter(VIEWS_VIEW_NAME_KEY, viewName);
		@SuppressWarnings("deprecation")
		User user = query.get();
		return getUserViewConfig(viewName, user);
	}
	
	/**
	 * This method provide user view config from database.
	 * @param viewName
	 * @param user
	 * @return ViewConfig
	 * @throws CommunicatorException
	 */
	private ViewConfig getUserViewConfig(String viewName, User user) throws CommunicatorException {
		ViewConfig viewConfig = null;
		if (user == null || user.getViews() == null) {
			return viewConfig;
		}
		
		for (ViewConfig vConfig : user.getViews()) {
			if (viewName.equals(vConfig.getViewName())) {
				viewConfig = vConfig;
				break;
			}
		}
		return viewConfig;
	}
	
	
	/**
	 * This method is used to get IntensityHeatMap count by group name 
	 * @param soeId
	 * @param request
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBObject getIntensityHeatMapCntByGroup(String soeId, String request) throws CommunicatorException {
		BasicDBObject inquiriesAsPerClientType = new BasicDBObject();
		BasicDBList clientType = new BasicDBList();
		StaticData staticData = GenericDAO.getStaticData();
		long startTime = System.currentTimeMillis();
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			if (null != inputJsonObj.get(GROUP_NAME_KEY)) {
				String groupName = inputJsonObj.getString(GROUP_NAME_KEY);
				Long groupCode = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
				Group group =  QMACacheFactory.getCache().getAllGroupsMap().get(groupCode);
				if (null != groupName && !"All".equalsIgnoreCase(groupName) && null != group && Boolean.TRUE.equals(group.getActive()) ) {
					String finalQuery = intensityHeatMapClientTypeCnt.replace("#groupId#", "" + groupCode);
					List<BasicDBObject> pipelines = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(finalQuery));
					//subLogger.info("getIntensityHeatMapCnt query : " + pipelines);
					modifyQueryWithDateConfig(pipelines);
					MongoDatabase db = MongoDB.instance().getDatabase();
					MongoCollection<Document> collection = db.getCollection("InquiryClientPriority").withReadPreference(ReadPreference.secondary());
					
//					MongoCursor<DBObject> outputResult=collection.aggregate(pipelines,DBObject.class).allowDiskUse(false).cursor();					
					List<DBObject> outputResult = collection.aggregate(pipelines,DBObject.class).into(new ArrayList<>());
					
					//DBCollection col = database.getCollection("InquiryClientPriority");
					//Cursor outputResult = col.aggregate(query, null, ReadPreference.secondaryPreferred());
					BasicDBObject objDashboardSettings = getDashboardSettings(soeId);
					fetchCountForDefaultCategories(clientType, outputResult, objDashboardSettings, staticData);
					fetchCustomClientCategories(clientType, outputResult, objDashboardSettings);
					subLogger.info("Time diff -  getIntensityHeatMapCntByGroup CountForDefaultCategories : groupId ["+groupCode+"]"+(System.currentTimeMillis() - startTime));
					inquiriesAsPerClientType.put(INTENSITY_HEAT_MAP_KEY, clientType);
					return inquiriesAsPerClientType;
				} else {
					inquiriesAsPerClientType = getIntensityHeatMapCnt(soeId, ACTIVE);
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in getIntensityHeatMapCntByGroup for user= " + soeId, e);
		}
	
		return inquiriesAsPerClientType;
	}

	/**
	 * This method is used to alphabetically sorting custom categories 
	 * @param customClientCategories
	 * @return
	 */
	private BasicDBList sortCustomClientCategories(BasicDBList customClientCategories) {
		BasicDBList customClientCategoriesSorted = new BasicDBList();
		try {
			if (null != customCategoryList) {
				Collections.sort(customCategoryList);
			}
			for (String ctegory : customCategoryList) {
				for (int i = 0; i < customClientCategories.size(); i++) {
					BasicDBObject basicDBObject = (BasicDBObject) customClientCategories.get(i);
					if (null != basicDBObject.get(ctegory)) {
						customClientCategoriesSorted.add(basicDBObject);
					}
				}
			}
		} catch (Exception e) {
			customClientCategoriesSorted = customClientCategories;
			subLogger.error("exception while sorting CustomClientCategories:",e);
		}
		return customClientCategoriesSorted;
	}

	/**
	 * This method is used to add color code to default categories from static data
	 * @param staticData
	 * @param defaultClientCategory
	 * @param basicDBObject
	 */
	private void addColorCodeToDefaultCategories(StaticData staticData, String defaultClientCategory,
			BasicDBObject basicDBObject) {
		try {
			if(null != staticData.getClientCategories()){
				List<ClientCategory> clientCategories = staticData.getClientCategories();
				for(ClientCategory clientCategory : clientCategories){
					if(defaultClientCategory.equalsIgnoreCase(clientCategory.getCategoryName())){
						basicDBObject.put("colorCode", clientCategory.getColorCode());
						break;
					}
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in addColorCodeToDefaultCategories:", e);
		}
	}

	/**
	 * @param clientType
	 * @param outputResult
	 * @param objDashboardSettings
	 * @param staticData2 
	 * @throws CommunicatorException
	 */
	private void fetchCountForDefaultCategories(BasicDBList clientType, List<DBObject> outputResult,
			BasicDBObject objDashboardSettings, StaticData staticData) throws CommunicatorException {
		
		Integer platinumCount =0;
		Integer priorityCount =0;
		Integer otherCount =0;
		for (DBObject resultObj : outputResult) {
				
				if(null != resultObj.get(CLIENT_PRIORITY_KEY) 
						&&( PLATINUM.equalsIgnoreCase((String) resultObj.get(CLIENT_PRIORITY_KEY))
								||  SUPERCHARGE.equalsIgnoreCase((String) resultObj.get(CLIENT_PRIORITY_KEY)))) {
					++platinumCount;
				}
			if(null != resultObj.get(CLIENT_PRIORITY_KEY) 
					&& PRIORITY.equalsIgnoreCase((String) resultObj.get(CLIENT_PRIORITY_KEY))) {
				++priorityCount;
			}else if(inquiryDAO.isOtherClientCategory(resultObj)) {
				++otherCount;
			}
		}
		BasicDBObject objectPlatinum = new BasicDBObject();
		objectPlatinum.put(PLATINUM, platinumCount);
		//objectPlatinum.put(PLATINUMRESOLVE, platinumResolveCount);
		addColorCodeToDefaultCategories(staticData, PLATINUM, objectPlatinum);
		addTagLimitForDefaultCategories(PLATINUM, objectPlatinum, objDashboardSettings);
		clientType.add(objectPlatinum);
		BasicDBObject objectPriority = new BasicDBObject();
		objectPriority.put(PRIORITY, priorityCount);
		addColorCodeToDefaultCategories(staticData, PRIORITY, objectPriority);
		addTagLimitForDefaultCategories(PRIORITY, objectPriority, objDashboardSettings);
		clientType.add(objectPriority);
		BasicDBObject objectOther = new BasicDBObject();
		objectOther.put("Other", otherCount);
		addColorCodeToDefaultCategories(staticData, "Other", objectOther);
		addTagLimitForDefaultCategories("Client", objectOther, objDashboardSettings);
		clientType.add(objectOther);		
}
	private void fetchCountForDefaultCategoriesforHeatMapCount(BasicDBList clientType, List<DBObject> outputResult,
			BasicDBObject objDashboardSettings, StaticData staticData, BasicDBObject out) throws CommunicatorException {
		
		Integer priorityCount =0;
		Integer otherCount =0;
		for (DBObject resultObj : outputResult) {
			if(null != resultObj.get(CLIENT_PRIORITY_KEY) 
					&& PRIORITY.equalsIgnoreCase((String) resultObj.get(CLIENT_PRIORITY_KEY))) {
				++priorityCount;
			}else if(inquiryDAO.isOtherClientCategory(resultObj)) {
				++otherCount;
			}
		}
		BasicDBObject objectPlatinum = new BasicDBObject();
		objectPlatinum.put(PLATINUM, out.get("totalRecords"));
		addColorCodeToDefaultCategories(staticData, PLATINUM, objectPlatinum);
		addTagLimitForDefaultCategories(PLATINUM, objectPlatinum, objDashboardSettings);
		clientType.add(objectPlatinum);
		BasicDBObject objectPriority = new BasicDBObject();
		objectPriority.put(PRIORITY, priorityCount);
		addColorCodeToDefaultCategories(staticData, PRIORITY, objectPriority);
		addTagLimitForDefaultCategories(PRIORITY, objectPriority, objDashboardSettings);
		clientType.add(objectPriority);
		BasicDBObject objectOther = new BasicDBObject();
		objectOther.put("Other", otherCount);
		addColorCodeToDefaultCategories(staticData, "Other", objectOther);
		addTagLimitForDefaultCategories("Client", objectOther, objDashboardSettings);
		clientType.add(objectOther);		
}

	/**
	 * This method is used to fetch custom category object from result set
	 * @param clientType
	 * @param outputResult
	 * @param objDashboardSettings
	 */
	private void fetchCustomClientCategories(BasicDBList clientType, List<DBObject> outputResult,
			BasicDBObject objDashboardSettings) {
		if (null != objDashboardSettings && null != objDashboardSettings.get(HEAT_MAP)) {
			BasicDBList customClientCategoryFinalList = new BasicDBList();
			BasicDBList heatMapList = (BasicDBList) objDashboardSettings.get(HEAT_MAP);
			customCategoryList = new ArrayList<>();
			for (Object heatMapObject : heatMapList) {
				BasicDBObject allHeapMapObject = (BasicDBObject) heatMapObject;
				if(null != allHeapMapObject.get(CATEGORY_TYPE) && "custom".equalsIgnoreCase((String) allHeapMapObject.get(CATEGORY_TYPE))){
					String customClientCategory = (String) allHeapMapObject.get("clientCategoryName");
					customCategoryList.add(customClientCategory);
					String customClientCategoryLimit = (String) allHeapMapObject.get("tagLimit");
					String customClientCategoryColorCode="";
					String customClientCategoryGroupName = (String) allHeapMapObject.get("groupName");
					long customClientCategoryGroupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(customClientCategoryGroupName.toUpperCase());
					int customClientCategoryCount = 0;
					BasicDBObject objectCustomClientCategory = new BasicDBObject();
					for (DBObject resultObj : outputResult) {
						Object objForAssignedGroupId = resultObj.get(ASSIGNED_GROUP_ID_KEY);
						if(null != objForAssignedGroupId && customClientCategoryGroupId == (long)objForAssignedGroupId){
							if(null != resultObj.get("customClientCategory")){
								BasicDBList customClientCategoryList = (BasicDBList) resultObj.get("customClientCategory");
								for(int i = 0; i <customClientCategoryList.size();i++){
									BasicDBObject clientCategory = (BasicDBObject) customClientCategoryList.get(i);
									if(null != clientCategory.get("categoryName") && customClientCategory.equals((String)clientCategory.get("categoryName"))){
										customClientCategoryColorCode = (String) clientCategory.get("colorCode");
										++customClientCategoryCount;
										break;
									}
								}
							}
						}
					}
					objectCustomClientCategory.put(customClientCategory, customClientCategoryCount);
					objectCustomClientCategory.put("colorCode", customClientCategoryColorCode);
					objectCustomClientCategory.put("tagLimit", customClientCategoryLimit);
					objectCustomClientCategory.put("groupName", customClientCategoryGroupName);
					customClientCategoryFinalList.add(objectCustomClientCategory);
				}
			}
			if(null != customCategoryList && !customCategoryList.isEmpty()){
				BasicDBList customClientCategoriesSorted = sortCustomClientCategories(customClientCategoryFinalList);
				clientType.addAll(customClientCategoriesSorted);
			}
		}
	}
	/**
	 * @param categoryKey
	 * @param defaultCategory
	 * @param objDashboardSettings
	 */
	private void addTagLimitForDefaultCategories(String categoryKey,BasicDBObject defaultCategory, BasicDBObject objDashboardSettings) {
		if (null != objDashboardSettings && null != objDashboardSettings.get(HEAT_MAP)) {
			BasicDBList heatMapList = (BasicDBList) objDashboardSettings.get(HEAT_MAP);
			if (!heatMapList.isEmpty()) {
				for (int i = 0; i < heatMapList.size(); i++) {
					BasicDBObject heatMapClientObj = (BasicDBObject) heatMapList.get(i);
					if (null != heatMapClientObj && null != heatMapClientObj.get(CLIENT_CATEGORY_NAME)) {
						String clientCategory = (String) heatMapClientObj.get(CLIENT_CATEGORY_NAME);
						if (clientCategory.equalsIgnoreCase(categoryKey) && null != heatMapClientObj.get(TAG_LIMIT)) {
							defaultCategory.put(TAG_LIMIT, heatMapClientObj.get(TAG_LIMIT));
							break;
						} else {
							defaultCategory.put(TAG_LIMIT, 0);
						}
					}
				}
			} else {
				defaultCategory.put(TAG_LIMIT, 0);
			}
		}
		
	}
	
	public boolean isMailBoxStatsExecutorFlag(){
		boolean isMailboxStatsExecutorFlag = false;
		isMailboxStatsExecutorFlag = QMACacheFactory.getCache().isMailboxStatsExecutorFlag();
		return isMailboxStatsExecutorFlag;
	}
	/**
	 * @param viewName
	 * @param finalCriteria
	 * @param logger 
	 * @return
	 */
	public Date getDateConfigForMailStats(String viewName) {
		Date calculatedTime = null;
		try {
			
			Config config = null;
			if(null != QMACacheFactory.getCache().getConfigById("defaultViewPerformanceConfig")){
				config = QMACacheFactory.getCache().getConfigById("defaultViewPerformanceConfig");
			}
			boolean performanceFlag = false;
			Map<String, Object> defaultViewPerformanceConfig = null;
			if(null != config && null !=  config.getDefaultViewPerformanceConfig() 
					&& null != config.getDefaultViewPerformanceConfig().get("performanceFlag") ){
				defaultViewPerformanceConfig = config.getDefaultViewPerformanceConfig();
				performanceFlag = (boolean) defaultViewPerformanceConfig.get("performanceFlag");
			}
			BasicDBList viewsConfig = null;
			if(performanceFlag && null != defaultViewPerformanceConfig.get("viewsConfig")){
				viewsConfig = (BasicDBList) defaultViewPerformanceConfig.get("viewsConfig");
			}
			int noOfMonths = 12; //Default months
			if(null != viewsConfig && !viewsConfig.isEmpty()){
				noOfMonths = getNoOfMonthsForViews(viewName, viewsConfig);
			}
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.DAY_OF_MONTH, 1);
			cal.set(Calendar.HOUR, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.add(Calendar.MONTH, -noOfMonths);
			calculatedTime = cal.getTime();
			
		} catch (Exception e) {
			subLogger.error("Exception in updateFinalCriteriaWithDateConfig ",e);
		}
		return calculatedTime;
	}
	
	
	/**
	 * @param viewName
	 * @param viewsConfig
	 * @param noOfMonths
	 * @param logger 
	 * @return
	 */
	private int getNoOfMonthsForViews(String viewName, BasicDBList viewsConfig) {
		int noOfMonths = 12; //Default months
		try {
			for(Object viewObj : viewsConfig) {
				if(null != viewObj) {
					String vName = null != ((BasicDBObject)viewObj).get("viewName") ? ((BasicDBObject)viewObj).getString("viewName") : "";
					if(viewName.equalsIgnoreCase(vName)) {
						noOfMonths = null != ((BasicDBObject)viewObj).get("months") ? ((BasicDBObject)viewObj).getInt("months") : 0;
						break;
					}
				}
			}
		} catch (Exception e) {
			subLogger.error("Exception in getNoOfMonthsForViews for view : "+viewName, e);
		}
		return noOfMonths;
	}
	

}
