package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.CappedAt;
import dev.morphia.annotations.Entity;

//@Entity(value = "InquiryAudit", noClassnameStored = true)
@Entity(value = "InquiryAudit", noClassnameStored = true, cap = @CappedAt(count = 5000, value = 500000))
public class InquiryAudit extends BaseEntity
{

	private String messageId;
	private String references;
	private Long inquiryId;
	private Long conversationId;
	/*
	 * public String mail; public String threadTopic; public String fromName; public String fromAddress; public String replyToAddress; public String toRecipients; public String toRecipientsAddresses;
	 * public String ccRecipients; public String ccRecipientsAddresses; public Date sentDate; public Date receiptDate; public String subject; public String subjectOriginal; public String
	 * subjectThreadTopic; public String subjectInquiryId; public String threadId;
	 */
	private String importance;
	private String direction;
	private String processFlag;
	private String mailContent; // sunil added 28 Oct

	public InquiryAudit()
	{

	}

	//Sonar Fix -- Constructor has parameters, which is greater than 7 authorized..not called so commented
	/*public InquiryAudit(String messageId, String references, Long inquiryId, Long conversationId, String importance, String direction, String processFlag, String mailContent)
	{
		super();
		this.messageId = messageId;
		this.references = references;
		this.inquiryId = inquiryId;
		this.conversationId = conversationId;
		this.importance = importance;
		this.direction = direction;
		this.processFlag = processFlag;
		this.mailContent = mailContent;
	}*/

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getReferences() {
		return references;
	}

	public void setReferences(String references) {
		this.references = references;
	}

	public Long getInquiryId() {
		return inquiryId;
	}

	public void setInquiryId(Long inquiryId) {
		this.inquiryId = inquiryId;
	}

	public Long getConversationId() {
		return conversationId;
	}

	public void setConversationId(Long conversationId) {
		this.conversationId = conversationId;
	}

	public String getImportance() {
		return importance;
	}

	public void setImportance(String importance) {
		this.importance = importance;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getProcessFlag() {
		return processFlag;
	}

	public void setProcessFlag(String processFlag) {
		this.processFlag = processFlag;
	}

	public String getMailContent() {
		return mailContent;
	}

	public void setMailContent(String mailContent) {
		this.mailContent = mailContent;
	}
	
}
