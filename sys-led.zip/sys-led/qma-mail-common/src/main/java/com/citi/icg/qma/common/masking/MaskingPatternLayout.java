package com.citi.icg.qma.common.masking;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.lang.StringUtils;

import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

import ch.qos.logback.classic.PatternLayout;
import ch.qos.logback.classic.spi.ILoggingEvent;

public class MaskingPatternLayout extends PatternLayout {
	private Pattern multilinePattern;
	private List<String> maskPatterns = new ArrayList<>();
	boolean isLogMaskingEnabled = true;
	private static final int MAX_MESSAGE_LENGTH = 2000;

	public void addMaskPattern(String maskPattern) {
		maskPatterns.add(maskPattern);
		multilinePattern = Pattern.compile(maskPatterns.stream().collect(Collectors.joining("|")), Pattern.MULTILINE);
		checkMaskingFlagChange();
	}

	@Override
	public String doLayout(ILoggingEvent event) {
		return maskMessage(super.doLayout(event));
	}

	private String maskMessage(String message) {

		if (multilinePattern == null || !isLogMaskingEnabled || StringUtils.length(message) > MAX_MESSAGE_LENGTH) {
			return message;
		}
		StringBuilder sb = new StringBuilder(message);
		Matcher matcher = multilinePattern.matcher(sb);
		while (matcher.find()) {
			IntStream.rangeClosed(1, matcher.groupCount()).forEach(group -> {
				if (matcher.group(group) != null) {
					IntStream.range(matcher.start(group), matcher.end(group)).forEach(i -> sb.setCharAt(i, '*'));
				}
			});
		}
		return sb.toString();
	}
	
	public void checkMaskingFlagChange() {
		ScheduledExecutorService executorService = null;
		try
		{
			executorService = Executors.newSingleThreadScheduledExecutor();
			executorService.scheduleAtFixedRate(() -> {
				isLogMaskingEnabled = QMACacheFactory.getCache().getDefaultStaticData().isLogMaskingEnabled() == null ? true : QMACacheFactory.getCache().getDefaultStaticData().isLogMaskingEnabled();
			}, 10, 5, TimeUnit.MINUTES);
		}
		catch(Exception ex) {
			isLogMaskingEnabled = true;
			if(executorService != null) {
				executorService.shutdown();
			}
		}
	}
}
