package com.citi.icg.qma.common.core.subscriber.mails;

public enum MailHeaders
{
	
	THREADTOPIC("Thread-Topic"),
	MESSAGEID("Message-ID"),
	THREADINDEX("Thread-Index"),
	IMPORTANCE("Importance"),
	REFERENCES("References"),
	INQUIRYID("InquiryId"),
	RESENTFORM("Resent-From");

	private String header;

	MailHeaders(String header)
	{
		this.header = header;
	}

	public String getName()
	{
		return header;
	}

	@Override
	public String toString()
	{
		return header;
	}
}
