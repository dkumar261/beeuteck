package com.citi.icg.qma.common.core.transformer;

public class TransformationConfigEntry
{
	String name = null;
    String sourceClassName = null;
    String destinationClassName = null;
    String transformerClassName = null;
    String paramClassName = null;
    
    public TransformationConfigEntry(	String name,
    									String sourceClassName, 
    									String destinationClassName,
    									String transformerClassName,
    									String paramClassName)
    {
    	this.name = name;
        this.sourceClassName = sourceClassName;
        this.destinationClassName = destinationClassName;
        this.transformerClassName = transformerClassName;
        this.paramClassName = paramClassName;
    }

	public String getSourceClassName()
	{
		return sourceClassName;
	}

	public void setSourceClassName(String sourceClassName)
	{
		this.sourceClassName = sourceClassName;
	}

	public String getDestinationClassName()
	{
		return destinationClassName;
	}

	public void setDestinationClassName(String destinationClassName)
	{
		this.destinationClassName = destinationClassName;
	}

	public String getTransformerClassName()
	{
		return transformerClassName;
	}

	public void setTransformerClassName(String transformerClassName)
	{
		this.transformerClassName = transformerClassName;
	}

	public String getParamClassName()
	{
		return paramClassName;
	}

	public void setParamClassName(String paramClassName)
	{
		this.paramClassName = paramClassName;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}
    
    
    
}
