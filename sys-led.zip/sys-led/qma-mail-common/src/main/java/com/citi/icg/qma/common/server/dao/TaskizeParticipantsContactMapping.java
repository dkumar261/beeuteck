package com.citi.icg.qma.common.server.dao;

import dev.morphia.annotations.Entity;

@Entity(value = "TaskizeParticipantsContactMapping", noClassnameStored = true)
public class TaskizeParticipantsContactMapping extends BaseEntity{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8614765663726498090L;
	private String displayName;
	private String organizationName;
	private String businessUnit;
	private String function;
	private String language;
	private Long qmaDlId;
	private String qmaDlName;
	private String qmaDlEmail;
	private boolean isCitiContact;
	public TaskizeParticipantsContactMapping() {
		super();
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getOrganizationName() {
		return organizationName;
	}
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	public String getFunction() {
		return function;
	}
	public void setFunction(String function) {
		this.function = function;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public Long getQmaDlId() {
		return qmaDlId;
	}
	public void setQmaDlId(Long qmaDlId) {
		this.qmaDlId = qmaDlId;
	}
	public String getQmaDlName() {
		return qmaDlName;
	}
	public void setQmaDlName(String qmaDlName) {
		this.qmaDlName = qmaDlName;
	}
	public String getQmaDlEmail() {
		return qmaDlEmail;
	}
	public void setQmaDlEmail(String qmaDlEmail) {
		this.qmaDlEmail = qmaDlEmail;
	}
	public boolean isCitiContact() {
		return isCitiContact;
	}
	public void setCitiContact(boolean isCitiContact) {
		this.isCitiContact = isCitiContact;
	}
	
}
