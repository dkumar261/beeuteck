package com.citi.icg.qma.common.server.dao;

import java.util.Date;

public class Note
{
	private String userId;
	private String userName;

	private Date commentDate;

	private String comments;

	public Note()
	{

	}

	public Note(String userId, String userName, Date commentDate, String comments)
	{
		super();
		this.userId = userId;
		this.userName = userName;
		this.commentDate = commentDate;
		this.comments = comments;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getCommentDate() {
		return commentDate;
	}

	public void setCommentDate(Date commentDate) {
		this.commentDate = commentDate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	

}
