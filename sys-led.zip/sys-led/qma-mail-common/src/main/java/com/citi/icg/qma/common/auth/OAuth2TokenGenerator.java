package com.citi.icg.qma.common.auth;

import com.citi.icg.qma.config.QmaMailConfigLoader;
import com.microsoft.aad.msal4j.ClientCredentialFactory;
import com.microsoft.aad.msal4j.ClientCredentialParameters;
import com.microsoft.aad.msal4j.ConfidentialClientApplication;
import com.microsoft.aad.msal4j.IAuthenticationResult;

import java.util.Collections;
import java.util.Set;

public class OAuth2TokenGenerator {

    public static String getAccessToken() throws Exception {
        String CLIENT_ID = QmaMailConfigLoader.getConfig().getAZURE_CLIENT_ID();
        String CLIENT_SECRET = QmaMailConfigLoader.getConfig().getAZURE_CLIENT_SECRET();
        String AUTHORITY = QmaMailConfigLoader.getConfig().getEX_SERVER_AUTHORITY_URL();
        String SCOPE = QmaMailConfigLoader.getConfig().getAZURE_SCOPE();

        System.clearProperty("javax.net.ssl.trustStore");
        IAuthenticationResult result = null;
        ConfidentialClientApplication app = ConfidentialClientApplication.builder(
                        CLIENT_ID,
                        ClientCredentialFactory.createFromSecret(CLIENT_SECRET))
                .authority(AUTHORITY)
                .build();

        Set<String> scopes = Collections.singleton(SCOPE);

        ClientCredentialParameters clientCredentialParam = ClientCredentialParameters.builder(scopes).build();

        result = app.acquireToken(clientCredentialParam).join();
        return result.accessToken();

    }
}
