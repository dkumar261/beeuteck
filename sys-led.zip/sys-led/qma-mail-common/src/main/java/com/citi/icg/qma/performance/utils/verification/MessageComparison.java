package com.citi.icg.qma.performance.utils.verification;

import java.util.List;

import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.Inquiry;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "MessageComparison", noClassnameStored = true)
public class MessageComparison {
	
	@Id
	private String messageId;
	
	private Boolean oldSynced; 
	private Boolean newSynced; 
	
	private String detailedStatus;
	private String matchingStatus;
	private List<String> matchingDetails; 
	
	private Inquiry newInquiry; 
	private Inquiry oldInquiry; 
		 
	private List<Conversation> newConversations;
	private List<Conversation> oldConversations;
	

	public static final String ATTEMPTED_FAILED="ATTEMPTED_FAILED";
	public static final String NOT_ATTEMPTED="NOT_ATTEMPTED";
	public static final String ATTEMPTED_SUCCESS="ATTEMPTED_SUCCESS";
	public static final String MATCHING_DONE="MATCHING_DONE";
	
	public static final String COMPLETE_MATCH="COMPLETE_MATCH";
	public static final String PARTIAL_MATCH_PROD_MOVED_FORWARD="PARTIAL_MATCH";
	public static final String FAILED_MATCH="FAILED_MATCH";
	public static final String UNKNOWN="UNKNOWN";
	
	public MessageComparison() {
		super();
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public Boolean getOldSynced() {
		return oldSynced;
	}

	public void setOldSynced(Boolean oldSynced) {
		this.oldSynced = oldSynced;
	}

	public Boolean getNewSynced() {
		return newSynced;
	}

	public void setNewSynced(Boolean newSynced) {
		this.newSynced = newSynced;
	}

	public Inquiry getNewInquiry() {
		return newInquiry;
	}

	public void setNewInquiry(Inquiry newInquiry) {
		this.newInquiry = newInquiry;
	}

	public Inquiry getOldInquiry() {
		return oldInquiry;
	}

	public void setOldInquiry(Inquiry oldInquiry) {
		this.oldInquiry = oldInquiry;
	}

	public List<Conversation> getNewConversation() {
		return newConversations;
	}

	public void setNewConversation(List<Conversation> newConversation) {
		this.newConversations = newConversation;
	}

	public List<Conversation> getOldConversation() {
		return oldConversations;
	}

	public void setOldConversation(List<Conversation> oldConversation) {
		this.oldConversations = oldConversation;
	}

	public String getDetailedStatus() {
		return detailedStatus;
	}

	public void setDetailedStatus(String detailedStatus) {
		this.detailedStatus = detailedStatus;
	}

	public List<String> getMatchingDetails() {
		return matchingDetails;
	}

	public void setMatchingDetails(List<String> matchingDetails) {
		this.matchingDetails = matchingDetails;
	}

	public String getMatchingStatus() {
		return matchingStatus;
	}

	public void setMatchingStatus(String matchingStatus) {
		this.matchingStatus = matchingStatus;
	}

	


}
