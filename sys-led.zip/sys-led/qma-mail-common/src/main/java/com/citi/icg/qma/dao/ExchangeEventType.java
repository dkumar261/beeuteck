package com.citi.icg.qma.dao;

public enum ExchangeEventType {
	/**
	 * The Status.
	 */
	Status,

	// This event indicates that a new e-mail message was received.
	/**
	 * The New mail.
	 */
	NewMail,

	// This event indicates that an item or folder has been deleted.
	/**
	 * The Deleted.
	 */
	Deleted,

	// This event indicates that an item or folder has been modified.
	/**
	 * The Modified.
	 */
	Modified,

	// This event indicates that an item or folder has been moved to another
	// folder.
	/**
	 * The Moved.
	 */
	Moved,

	// This event indicates that an item or folder has been copied to another
	// folder.
	/**
	 * The Copied.
	 */
	Copied,

	// This event indicates that a new item or folder has been created.
	/**
	 * The Created.
	 */
	Created,

	FreeBusyChanged

}