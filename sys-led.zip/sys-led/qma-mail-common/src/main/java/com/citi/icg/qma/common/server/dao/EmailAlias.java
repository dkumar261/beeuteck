package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.List;

import dev.morphia.annotations.Embedded;

//It is combination of XMC_EXT_GROUP_MAPPING and XMC_EXT_GROUP_MAP_DETAILS.
@Embedded
public class EmailAlias implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4955433123904760737L;
	// Sunil Changed : 11 August,
	// public String emailAlias; // Not needed, as comes from Group level data
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private String alias;
	// without @symbol added sunil 11 Aug
	private List<String> emails;

	public EmailAlias()
	{

	}

	public EmailAlias(String alias, List<String> emails)
	{
		super();
		this.alias = alias;
		this.emails = emails;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public List<String> getEmails() {
		return emails;
	}

	public void setEmails(List<String> emails) {
		this.emails = emails;
	}

}