package com.citi.icg.qma.common.core.subscriber.mails.entity;

public final class MailProperties
{
	private boolean authenticationRequired;
	private String userName;
	private String password;
	private boolean encrypted;
	private String encryptionType;

	private String hostName;
	private int portNo;

	private String protocol;
	private String protocolSocketFactoryClass;
	private boolean protocolSocketFactoryFallback;

	private String folderName;

	private long waitTimeBetweenPoll;

	public MailProperties()
	{
		authenticationRequired = true;
		encrypted = true;
		protocolSocketFactoryFallback = false;
	}

	@Override
	public String toString()
	{
		return "MailProperties [encrypted=" + encrypted + ", encryptionType=" + encryptionType + ", folderName=" + folderName
				+ ", hostName=" + hostName + ", password=" + password + ", portNo=" + portNo + ", protocol=" + protocol
				+ ", protocolSocketFactoryClass=" + protocolSocketFactoryClass + ", protocolSocketFactoryFallback="
				+ protocolSocketFactoryFallback + ", userName=" + userName + ", waitTimeBetweenPoll=" + waitTimeBetweenPoll + "]";
	}

	public String getUserName()
	{
		return userName;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public String getPassword()
	{
		return password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	public boolean isEncrypted()
	{
		return encrypted;
	}

	public void setEncrypted(boolean encrypted)
	{
		this.encrypted = encrypted;
	}

	public String getEncryptionType()
	{
		return encryptionType;
	}

	public void setEncryptionType(String encryptionType)
	{
		this.encryptionType = encryptionType;
	}

	public String getHostName()
	{
		return hostName;
	}

	public void setHostName(String hostName)
	{
		this.hostName = hostName;
	}

	public int getPortNo()
	{
		return portNo;
	}

	public void setPortNo(int portNo)
	{
		this.portNo = portNo;
	}

	public String getProtocol()
	{
		return protocol;
	}

	public void setProtocol(String protocol)
	{
		this.protocol = protocol;
	}

	public String getProtocolSocketFactoryClass()
	{
		return protocolSocketFactoryClass;
	}

	public void setProtocolSocketFactoryClass(String protocolSocketFactoryClass)
	{
		this.protocolSocketFactoryClass = protocolSocketFactoryClass;
	}

	public boolean isProtocolSocketFactoryFallback()
	{
		return protocolSocketFactoryFallback;
	}

	public void setProtocolSocketFactoryFallback(boolean protocolSocketFactoryFallback)
	{
		this.protocolSocketFactoryFallback = protocolSocketFactoryFallback;
	}

	public String getFolderName()
	{
		return folderName;
	}

	public void setFolderName(String folderName)
	{
		this.folderName = folderName;
	}

	public long getWaitTimeBetweenPoll()
	{
		return waitTimeBetweenPoll;
	}

	public void setWaitTimeBetweenPoll(long waitTimeBetweenPoll)
	{
		this.waitTimeBetweenPoll = waitTimeBetweenPoll;
	}

	public boolean isAuthenticationRequired()
	{
		return authenticationRequired;
	}

	public void setAuthenticationRequired(boolean authenticationRequired)
	{
		this.authenticationRequired = authenticationRequired;
	}

}
