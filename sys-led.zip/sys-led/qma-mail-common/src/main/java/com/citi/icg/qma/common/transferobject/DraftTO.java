package com.citi.icg.qma.common.transferobject;

import com.citi.icg.qma.common.server.dao.Draft;

public class DraftTO
{
	// Sonar Fix -- Make fields a static final constant or non-public and provide accessors if needed
	private Draft draft;


	public DraftTO()
	{

	}

	public DraftTO(Draft draft)
	{
		super();
		this.draft = draft;
	}

	public Draft getDraft() {
		return draft;
	}

	public void setDraft(Draft draft) {
		this.draft = draft;
	}

}
