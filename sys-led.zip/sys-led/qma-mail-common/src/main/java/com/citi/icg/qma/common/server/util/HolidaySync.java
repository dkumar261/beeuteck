package com.citi.icg.qma.common.server.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;


public class HolidaySync {
    private static final Logger logger = LoggerFactory.getLogger(HolidaySync.class);
    private static final String DATE = System.getProperty("HOLIDAY_DATE");
    private static final String DESC = System.getProperty("HOLIDAY_DESC");
    private static final String TYPE = System.getProperty("HOLIDAY_TYPE");
    private static final String COUNTRY_CODE = System.getProperty("COUNTRY_CODE");
    private static final String ITERATOR_OBJ_NAME = System.getProperty("HOLIDAY_ITERATOR");
    public static final String DATE_FORMAT = System.getProperty("DATE_FORMAT");

    private static boolean isJsonArray(String jsonResponse) {
        JsonElement holidayJson = JsonParser.parseString(jsonResponse);
        return holidayJson.isJsonArray();
    }

    public static JsonObject convertJsonToAnotherJsonObject(String jsonResponse) throws JsonProcessingException {
        JsonArray jsonResponseArr = convertJsonToAnotherJsonArray(jsonResponse);

        return convertJsonArrayToObject(jsonResponseArr);
    }

    public static JsonArray convertJsonToAnotherJsonArray(String jsonResponse) {
        List<Object> holidayEvents = new ArrayList<>();
        Object countryCode = null;
        try {
            if (isJsonArray(jsonResponse)) {
                holidayEvents = new ObjectMapper().readValue(jsonResponse, List.class);
            } else {
                Map<String, Object> result = new ObjectMapper().readValue(jsonResponse, HashMap.class);
                holidayEvents = (List<Object>) getValueFromMap(result, ITERATOR_OBJ_NAME);
                countryCode = getValueFromMap(result, COUNTRY_CODE);
            }
        } catch (JsonProcessingException ex) {
            logger.error("Unsupported Json processing of the response. Please validate the json response " +
                    ex.getMessage());
        }
        return mapListToJsonArray(holidayEvents, countryCode != null ? (String) countryCode : null);
    }

    public static JsonObject convertJsonArrayToObject(JsonArray jsonArray) {
        JsonObject holidayResponse = new JsonObject();
        holidayResponse.add("results", jsonArray);
        return holidayResponse;
    }

    private static Object getValueFromMap(final Map<String, Object> map, final String key) {
        try {
            final String[] tmpKeys = key.split("\\.");
            Map<String, Object> currentMap = map;
            for (int i = 0; i < tmpKeys.length - 1; i++) {
                currentMap = (Map<String, Object>) currentMap.get(tmpKeys[i]);
            }

            return currentMap.get(tmpKeys[tmpKeys.length - 1]);
        } catch (Exception exception) {
            return null;
        }
    }

    private static JsonArray mapListToJsonArray(List<Object> listOfObject, String countryCode) {
        JsonArray response = new JsonArray();
        listOfObject.forEach(holidayEvent -> {
            JsonObject holidayResponse = new JsonObject();
            LinkedHashMap<Object, Object> linkedHolidayEvent = (LinkedHashMap<Object, Object>) holidayEvent;
            holidayResponse.addProperty("holidayDate", String.valueOf(linkedHolidayEvent.get(DATE)));
            holidayResponse.addProperty("holidayDesc", String.valueOf(linkedHolidayEvent.get(DESC)));
            holidayResponse.addProperty("type", String.valueOf(linkedHolidayEvent.get(TYPE)));
            holidayResponse.addProperty("countryCode",
                    countryCode != null ? countryCode : String.valueOf(linkedHolidayEvent.get(COUNTRY_CODE)));
            response.add(holidayResponse);
        });
        return response;
    }
}
