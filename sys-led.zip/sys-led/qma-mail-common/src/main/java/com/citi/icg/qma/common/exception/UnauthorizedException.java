package com.citi.icg.qma.common.exception;


import org.apache.http.HttpStatus;

/**
 * 
 *
 */
public class UnauthorizedException extends QMAException {

	private static final int ERROR_CODE = HttpStatus.SC_UNAUTHORIZED;
	private static final String ERROR_CODE_DESCRIPTION = "Unauthorized";
	
	public UnauthorizedException(String message) {
		super(message,ERROR_CODE,ERROR_CODE_DESCRIPTION);
	}

	public UnauthorizedException(String message, Throwable cause) {
		super(message,cause,ERROR_CODE,ERROR_CODE_DESCRIPTION);
	}
}
