package com.citi.icg.qma.common.server.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.EncryptionDecryptionUtil;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.HierarchyUserDetail;
import com.citi.icg.qma.common.server.dao.ManagementHeirarchy;
import com.citi.icg.qma.common.server.dao.persistence.CacheDAO;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;


public class GlobalDirectoryService {
	
	private static final Logger logger = LoggerFactory.getLogger(GlobalDirectoryService.class);

	private static final String SEARCH_PARAMS_INFO_TYPE_MSH02 = "searchParamsInfoTypeMSH02";
	private static final String SEARCH_PARAMS_INFO_TYPE_PBH03 = "searchParamsInfoTypePBH03";
	private static final String SEARCH_PARAMS_INFO_TYPE_BASIC = "searchParamsInfoTypeBASIC";
	private static final String SEARCH_PARAMS_INFO_TYPE_BASIC_GEID = "searchParamsInfoTypeBASICGEID";
	private static final String CONTACT_INFO_CONFIG = "contactInfoConfig";
	private static final String BAR_SEPERATION_KEY = "|";
	private static final String BAR_SPLITTER_KEY = "\\|";
	private static final String PEOPLE_HIERARCHY_SEPERATION_KEY = "-->";
	private static final String CONTACT_INFO_END_POINT = "contactInfoEndPoint";
	private static final String AUID_GDIR_CONTANT_INFO = "auid";
	private static final String SOEID_KEY = "SOEID";
	private static final String GEID_KEY = "GEID";
	private static final String LEVEL_KEY = "[L";
	private static final String ORG_LEVEL_SEPERATION_KEY = "->";
	private static final String LEVEL6 = "L6";
	private static final String LEVEL5 = "L5";
	private static final String PBH_STRING = "PBH_String";
	private static final String PERSON = "Person";
	private static final String PEOPLE = "people";
	private static final String RESPONSE = "response";
	private static final List<Integer> RESPONSEERRORCODES = Arrays.asList(new Integer[] { 400, 403, 404, 206 });
	private static final String LOGMSG = "WS ResponseCode is ";
	private static final String ERRORCODE = "ERRORCODE:";
	private static final String GET = "GET";
	private static final String LEVEL1 = "L1";
	private static final String LEVEL2 = "L2";
	private static final String LEVEL3 = "L3";
	private static final Object LEVEL7 = "L7";
	private static final String GLOBAL_DIRECTORY_QUERY_STRING_SUGGESTION = "?Search=#SEARCHTEXT#";
	private static final String GLOBAL_DIRECTORY_QUERY_STRING_SUGGESTION_XML = "?SearchType=SEARCH&Name=#SEARCHTEXT#&FName=&LName=&ID=";
	private static final String GLOBAL_DIRECTORY_QUERY_STRING = "?SOEID=";
	private static final String GLOBAL_DIRECTORY_QUERY_STRING_XML = "?SearchType=SOEID&Name=&FName=&LName=&ID=";
	
	private static GlobalDirectoryService instance = null;
	public static synchronized GlobalDirectoryService getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		if (instance == null) {
			instance = new GlobalDirectoryService();
		}
		return instance;
	}
	/**
	 * Method to get the Group Management Hierarchy based on User SoeId.
	 * @param userId
	 * @param globalDirConfig
	 * @return
	 */
	public ManagementHeirarchy getMangementHeirarchyBySoeId(String userId) {
		ManagementHeirarchy hierarchy = null;
		try {
			Map<String, Object> globalDirConfig = getGlobalDirectoryConfig();
			if (!StringUtils.isEmpty(userId) && null != globalDirConfig) {
				logger.info("fetchUserDetailsFromGlobDir : " + userId);
				String apiResponse = fetchUserDetailsFromGlobDir(userId.toUpperCase(), SOEID_KEY, globalDirConfig);
				String geId = getGeIdFromApiResponse(apiResponse);
				hierarchy = getHierarchyData(globalDirConfig, geId);
			}
		} catch (Exception ex) {
			logger.error("Exception in getMangementHeirarchyBySoeId:" + ex);
		}
		return hierarchy;
	}
	
	private ManagementHeirarchy getHierarchyData(Map<String, Object> globalDirConfig, String geId) {
		ManagementHeirarchy hierarchy = null;
		if(null != geId) {
			hierarchy = new ManagementHeirarchy();
			getOrganisationFromGlobalDir(geId,globalDirConfig,hierarchy);
			prepareAndSaveManagerHierarchy(globalDirConfig, geId,hierarchy);
		}else {
			logger.info("User details not available");
		}
		return hierarchy;
	}
	
	/**
	 * This method prepare hierarchy data from global dir
	 * @param globalDirConfig
	 * @param geId
	 * @param groupId
	 * @param hierarchy 
	 */
	private void prepareAndSaveManagerHierarchy(Map<String, Object> globalDirConfig, String geId, ManagementHeirarchy hierarchy) {
		try {
			HashMap<String, String> geIdUserNameMap = fetchAndPrepareManagerHierarchyMap(globalDirConfig, geId);
			//People hierarchy fetched is  like userId-->Superior-->, we need it to reverse order so we 
			// can get L1<--L2<--L3<--L4<--L5<--L6 
			Map<String, String> reversedUserHashMap = getReverseMap(geIdUserNameMap);
			if(MapUtils.isNotEmpty(reversedUserHashMap)) {
				int level= 1;
				processHierarchyMap(globalDirConfig, hierarchy, reversedUserHashMap, level);
			}
		} catch (Exception e) {
			logger.error("Exception in prepareAndSaveManagerHierarchy:"+e);
		}
	}
	
	/**
	 * This method will prepare hierarchyMap from API response
	 * @param globalDirConfig
	 * @param hierarchy
	 * @param reversedUserHashMap
	 * @param level
	 */
	private void processHierarchyMap(Map<String, Object> globalDirConfig, ManagementHeirarchy hierarchy, Map<String, String> reversedUserHashMap, int level) {
		for (Entry<String, String> entry : reversedUserHashMap.entrySet()) {
			HierarchyUserDetail userDetails = new HierarchyUserDetail();
			if (reversedUserHashMap.size() > 6) {
				getHierarchyLevelsL5AndL6(hierarchy, level, entry, userDetails,globalDirConfig,reversedUserHashMap.size());
				level++;
			} else {
				getHierarchyTwoLevelsUp(hierarchy, level, entry, userDetails,globalDirConfig,reversedUserHashMap.size());
				level++;
			}
		}
	}
	
	/**
	 * API repose is from employee to higher level, same has reversed from L1 to user level
	 * @param geIdUserNameMap
	 * @return
	 */
	private Map<String, String> getReverseMap(HashMap<String, String> geIdUserNameMap) { 
		HashMap<String, String> geIdReverseUserNameMap = new LinkedHashMap<>();
        List<String> alKeys = new ArrayList<String>(geIdUserNameMap.keySet());
        Collections.reverse(alKeys);
        for(String key : alKeys){
        	geIdReverseUserNameMap.put(key, geIdUserNameMap.get(key));
        }
        return geIdReverseUserNameMap;
	}

	/**
	 * This method will return manager hierarchy 2 levels up
	 * @param hierarchy
	 * @param level
	 * @param entry
	 * @param userDetails
	 * @param globalDirConfig
	 * @param i 
	 */
	private void getHierarchyTwoLevelsUp(ManagementHeirarchy hierarchy, int level, Entry<String, String> entry,
			HierarchyUserDetail userDetails, Map<String, Object> globalDirConfig, int mapSize) {
		if (level == mapSize) {
			List<HierarchyUserDetail> thirdLevelHeirarchy = getHierarchyUserDetails(hierarchy, entry, userDetails,
					globalDirConfig);
			hierarchy.setThirdLevelHeirarchy(thirdLevelHeirarchy);
		}
		if (level == mapSize-1) {
			List<HierarchyUserDetail> secondLevelHeirarchy = getHierarchyUserDetails(hierarchy, entry, userDetails,
					globalDirConfig);
			hierarchy.setSecondLevelHeirarchy(secondLevelHeirarchy);
		}
		if (level == mapSize-2) {
			List<HierarchyUserDetail> firstLevelHeirarchy = getHierarchyUserDetails(hierarchy, entry, userDetails,
					globalDirConfig);
			hierarchy.setFirstLevelHeirarchy(firstLevelHeirarchy);
		}
	}
	
	/**
	 * This method will get user details from global dir
	 * @param hierarchy
	 * @param entry
	 * @param userDetails
	 * @param globalDirConfig
	 * @return
	 */
	private List<HierarchyUserDetail> getHierarchyUserDetails(ManagementHeirarchy hierarchy, Entry<String, String> entry,
			HierarchyUserDetail userDetails, Map<String, Object> globalDirConfig) {
		List<HierarchyUserDetail> hierarchyList = new ArrayList<>();
		try {
			String apiResponse = fetchUserDetailsFromGlobDir(entry.getKey().toString(), GEID_KEY, globalDirConfig);
			if (!StringUtils.isEmpty(apiResponse)) {
				String soeId = getSoeIdFromApiResponse(apiResponse);
				if(null != soeId) { //sonar fix -null pointer
					userDetails.setUserId(soeId.toLowerCase());
				}
				userDetails.setUserName(entry.getValue());
				hierarchyList.add(userDetails);
			}
		} catch (Exception e) {
			logger.error("exception in getHierarchyUserDetails"+e);
		}
		return hierarchyList;
	}
	
	/**
	 * This method will return hierarchy data 
	 * @param hierarchy
	 * @param level
	 * @param entry
	 * @param userDetails
	 * @param globalDirConfig
	 * @param i 
	 */
	private void getHierarchyLevelsL5AndL6(ManagementHeirarchy hierarchy, int level, Entry<String, String> entry, HierarchyUserDetail userDetails, Map<String, Object> globalDirConfig, int mapSize) {
		if (level == mapSize) {
			List<HierarchyUserDetail> thirdLevelHeirarchy = getHierarchyUserDetails(hierarchy, entry, userDetails, globalDirConfig);
			hierarchy.setThirdLevelHeirarchy(thirdLevelHeirarchy);
		}
		if (level == 5) {
			List<HierarchyUserDetail> firstLevelHeirarchy = getHierarchyUserDetails(hierarchy, entry, userDetails, globalDirConfig);
			hierarchy.setFirstLevelHeirarchy(firstLevelHeirarchy);
		}
		if (level == 6) {
			List<HierarchyUserDetail> secondLevelHeirarchy = getHierarchyUserDetails(hierarchy, entry, userDetails, globalDirConfig);
			hierarchy.setSecondLevelHeirarchy(secondLevelHeirarchy);
		}
	}
	
	/**
	 * Get organization details for user hierarchy
	 * @param geId
	 * @param globalDirConfig
	 * @param hierarchy 
	 * @return
	 */
	private void getOrganisationFromGlobalDir(String geId, Map<String, Object> globalDirConfig, ManagementHeirarchy hierarchy) {
		BasicDBObject contactInfo = (BasicDBObject) globalDirConfig.get(CONTACT_INFO_CONFIG);
		String auid = (String) contactInfo.get(AUID_GDIR_CONTANT_INFO);
		String endPointUrl = (String) contactInfo.get(CONTACT_INFO_END_POINT);
		String searchParamsInfoTypeMSH02 = (String) contactInfo.get(SEARCH_PARAMS_INFO_TYPE_MSH02);
		boolean enableNewRestEndPoint = contactInfo.getBoolean("enableNewRestEndPoint");
		String endPointUrl_xml = (String) contactInfo.get("contactInfoEndPoint_xml");
		String searchParamsInfoTypeMSH02_xml = (String) contactInfo.get("searchParamsInfoTypeMSH02_xml");
		String finalUrl = null;
		logger.info("GD:: enableNewRestEndPoint: "+enableNewRestEndPoint);
		if(enableNewRestEndPoint) {
			finalUrl = endPointUrl+searchParamsInfoTypeMSH02.replace("#geId#", geId).replace("#auid#", auid);
		} else {
			finalUrl = endPointUrl_xml+searchParamsInfoTypeMSH02_xml.replace("#geId#", geId).replace("#auid#", auid);
		}
		
		String apiResponse = null;
		try {	
			 apiResponse = doRequest(finalUrl, GET);
			 if(!StringUtils.isEmpty(apiResponse)) {
				 JSONObject object = convertStringToJson(apiResponse.trim());
				  Map<String, String> orgMap = parseApiResponseAndGetOrgMap(object);
				  List<com.citi.icg.qma.common.server.dao.HierarchyOrgDetails> orgHierarchyList = new ArrayList<>();
				  if(null != orgMap && !orgMap.isEmpty() && orgMap.containsKey(LEVEL5)) {//sonar fix -null pointer
					  com.citi.icg.qma.common.server.dao.HierarchyOrgDetails orgHierarchy = new com.citi.icg.qma.common.server.dao.HierarchyOrgDetails();
					  orgHierarchy.setLevel(LEVEL1);
					  orgHierarchy.setOrgName(orgMap.get(LEVEL5));
					  orgHierarchyList.add(orgHierarchy);
					}
				  if(null != orgMap && !orgMap.isEmpty() && orgMap.containsKey(LEVEL6)) {//sonar fix -null pointer
					  com.citi.icg.qma.common.server.dao.HierarchyOrgDetails orgHierarchy = new com.citi.icg.qma.common.server.dao.HierarchyOrgDetails();
					  orgHierarchy.setLevel(LEVEL2);
					  orgHierarchy.setOrgName(orgMap.get(LEVEL6));
					  orgHierarchyList.add(orgHierarchy);
					}
				  if(null != orgMap && !orgMap.isEmpty() && orgMap.containsKey(LEVEL7)) {//sonar fix -null pointer
					  com.citi.icg.qma.common.server.dao.HierarchyOrgDetails orgHierarchy = new com.citi.icg.qma.common.server.dao.HierarchyOrgDetails();
					  orgHierarchy.setLevel(LEVEL3);
					  orgHierarchy.setOrgName(orgMap.get(LEVEL7));
					  orgHierarchyList.add(orgHierarchy);
				  }
				  if(null != orgHierarchyList && !orgHierarchyList.isEmpty()) {
					  hierarchy.setOrgHierarchy(orgHierarchyList);
				  }
			 }
		} catch(Exception ex) {
			logger.error("Exception while preparing org hierarchy for geId:"+geId+"Error:"+ex);	
		}
	}
	/**
	 * Get org from JSON
	 * @param object
	 * @return
	 */
	private Map<String, String> parseApiResponseAndGetOrgMap(JSONObject object) {
		if(null != object.get(RESPONSE)) {
			JSONObject responseObject = (JSONObject) object.get(RESPONSE);
			if(responseObject.has(PEOPLE) && null != responseObject.get(PEOPLE) && !responseObject.get(PEOPLE).equals("")) {
				JSONObject peopleObject = (JSONObject) responseObject.get(PEOPLE);
				if(peopleObject.has(PERSON) && null != peopleObject.get(PERSON) && !peopleObject.get(PERSON).equals("")) {
					JSONObject personObject = (JSONObject) peopleObject.get(PERSON);
					String mshString = personObject.getString("MSH_String");
					return getLevelMapOrgFromResponseString(mshString);
				}
			}
		}
		return null;
	}
	
	/**
	 * Get level 6 org
	 * @param mshString
	 * @return
	 */
	private Map<String, String> getLevelMapOrgFromResponseString(String mshString) {
		Map<String, String> orgMap = new LinkedHashMap<>();
		if (!StringUtils.isEmpty(mshString) && mshString.contains(ORG_LEVEL_SEPERATION_KEY)) {
			String[] orgArray = mshString.split(ORG_LEVEL_SEPERATION_KEY);
			for (int i = 0; i < orgArray.length; i++) {
				String level = getLevel(i);
				// LEVEL_KEY = [L: defined [L because global directory missing some levels
				// defination e.g. L3 is defined like [l
				if (!StringUtils.isEmpty(orgArray[i]) && orgArray[i].contains(LEVEL_KEY)) {
					String organisation = orgArray[i].substring(0, orgArray[i].indexOf(LEVEL_KEY));
					orgMap.put(level, organisation);
				} else {
					String organisation = orgArray[i];
					orgMap.put(level, organisation);
				}
			}
		}
		return orgMap;
	}
	
	private String getLevel(int i) {
		switch(i) {
		case 0: return "L1";
		case 1: return "L2";
		case 2: return "L3";
		case 3: return "L4";
		case 4: return "L5";
		case 5: return "L6";
		case 6: return "L7";
		case 7: return "L8";
		case 8: return "L9";
		case 9: return "L10";
		default:return null;
		}
	}
	/**
	 * Get soeid from api response
	 * @param apiResponse
	 * @return
	 */
	private String getSoeIdFromApiResponse(String apiResponse) {
		JSONObject object = convertStringToJson(apiResponse.trim());
		if(null != object && null != object.get(RESPONSE)) {//sonar fix -null pointer
			JSONObject responseObject = (JSONObject) object.get(RESPONSE);
			if(null != responseObject.get(PEOPLE) && !responseObject.get(PEOPLE).equals("")) {
				JSONObject peopleObject = (JSONObject) responseObject.get(PEOPLE);
				if(null != peopleObject.get(PERSON)&& !peopleObject.get(PERSON).equals("")) {
					JSONObject personObject = (JSONObject) peopleObject.get(PERSON);
					return personObject.getString("SoeId");
				}
			}
		}
		return null;
	}
	
	/**
	 * Fetch hierarchy from global dir and prepare map
	 * @param globalDirConfig
	 * @param geId
	 * @return
	 */
	private HashMap<String, String> fetchAndPrepareManagerHierarchyMap(Map<String, Object> globalDirConfig, String geId) {
		try {
			if(null != geId) {
				String response = getManagerHirarchy(geId, globalDirConfig);
				JSONObject jsonObject = convertStringToJson(response);
				return prepareManagerHierarchyMap(jsonObject);
			}
		} catch (Exception e) {
			logger.error("Exception in fetchAndPrepareManagerHierarchyMap",e);
		}
		return null;
	}
	
	/**
	 * @param jsonObject
	 * @return
	 */
	private HashMap<String, String> prepareManagerHierarchyMap(JSONObject jsonObject) {
		if(null != jsonObject.get(RESPONSE)) {
			JSONObject responseObject = (JSONObject) jsonObject.get(RESPONSE);
			if(responseObject.has(PEOPLE) && null != responseObject.get(PEOPLE)  && !responseObject.get(PEOPLE).equals("")) {
				JSONObject peopleObject = (JSONObject) responseObject.get(PEOPLE);
				if(peopleObject.has(PERSON) && null != peopleObject.get(PERSON) && !peopleObject.get(PERSON).equals("")) {
					JSONObject personObject = (JSONObject) peopleObject.get(PERSON);
					String pbString = personObject.getString(PBH_STRING);
					return getMapFromResponseString(pbString);
				}
			}
		}
		return null;
	}

	/**
	 * @param pbString
	 * @return
	 */
	private HashMap<String, String> getMapFromResponseString(String pbString) {
		HashMap<String, String> geIdUserNameMap = new LinkedHashMap<>();
		if (!StringUtils.isEmpty(pbString) && pbString.contains(PEOPLE_HIERARCHY_SEPERATION_KEY)) {
			String[] hierarchyLevel = pbString.split(PEOPLE_HIERARCHY_SEPERATION_KEY);
			for (int i = 0; i < hierarchyLevel.length; i++) {
				String level = hierarchyLevel[i];
				if (level != null && level.contains(BAR_SEPERATION_KEY)) {
					String[] userArray = level.split(BAR_SPLITTER_KEY);
					String geId = userArray[0].trim();
					String username = userArray[1].trim();
					geIdUserNameMap.put(geId, username);
				}
			}
		}
		return geIdUserNameMap;
	}
	
	/**
	 * Global Dir API call
	 * @param geId
	 * @param globalDirConfig
	 * @return
	 */
	private String getManagerHirarchy(String geId, Map<String, Object> globalDirConfig) {
		BasicDBObject contactInfo = (BasicDBObject) globalDirConfig.get(CONTACT_INFO_CONFIG);
		String auid = (String) contactInfo.get(AUID_GDIR_CONTANT_INFO);
		String endPointUrl = (String) contactInfo.get(CONTACT_INFO_END_POINT);
		String searchParamsInfoTypePBH03 = (String) contactInfo.get(SEARCH_PARAMS_INFO_TYPE_PBH03);
		boolean enableNewRestEndPoint = contactInfo.getBoolean("enableNewRestEndPoint");
		String endPointUrl_xml = (String) contactInfo.get("contactInfoEndPoint_xml");
		String searchParamsInfoTypePBH03_xml = (String) contactInfo.get("searchParamsInfoTypePBH03_xml");
		String finalUrl = null;
		logger.info("GD:: enableNewRestEndPoint: "+enableNewRestEndPoint);
		if(enableNewRestEndPoint) {
			finalUrl = endPointUrl+searchParamsInfoTypePBH03.replace("#geId#", geId).replace("#auid#", auid);
		} else {
			finalUrl = endPointUrl_xml+searchParamsInfoTypePBH03_xml.replace("#geId#", geId).replace("#auid#", auid);
		}
		
		String apiResponse = null;
		try {	
			 apiResponse = doRequest(finalUrl, GET);
			 return apiResponse;
			 
		}catch(Exception ex) {
			logger.error(finalUrl +": Response:"+apiResponse);	
		}
		return apiResponse;
	}
	
	/**
	 * @param apiResponse
	 * @return
	 */
	private String getGeIdFromApiResponse(String apiResponse) {
		JSONObject object = convertStringToJson(apiResponse.trim());
		if(null != object && null != object.get(RESPONSE)) {//sonar fix -null pointer
			JSONObject responseObject = (JSONObject) object.get(RESPONSE);
			if(responseObject.has(PEOPLE) && null != responseObject.get(PEOPLE) && !responseObject.get(PEOPLE).equals("")) {
				JSONObject peopleObject = (JSONObject) responseObject.get(PEOPLE);
				if(peopleObject.has(PERSON) && null != peopleObject.get(PERSON) && !peopleObject.get(PERSON).equals("")) {
					JSONObject personObject = (JSONObject) peopleObject.get(PERSON);
					return personObject.get(GEID_KEY).toString();
				}
			}
		}
		return null;
	}
	/**
	 * API call to global dir to fetch BASIC user details
	 * @param id
	 * @param serachType
	 * @param globalDirConfig
	 * @return
	 */
	public String fetchUserDetailsFromGlobDir(String id, String serachType, Map<String, Object> globalDirConfig) {
		BasicDBObject contactInfo = (BasicDBObject) globalDirConfig.get(CONTACT_INFO_CONFIG);
		String auid = (String) contactInfo.get(AUID_GDIR_CONTANT_INFO);
		String endPointUrl = (String) contactInfo.get(CONTACT_INFO_END_POINT);
		String searchParamsInfoTypeBASIC = (String) contactInfo.get(SEARCH_PARAMS_INFO_TYPE_BASIC);
		String searchParamsInfoTypeBASICGEID = (String) contactInfo.get(SEARCH_PARAMS_INFO_TYPE_BASIC_GEID);
		boolean enableNewRestEndPoint = (boolean) contactInfo.get("enableNewRestEndPoint");
		String endPointUrl_xml = (String) contactInfo.get("contactInfoEndPoint_xml");
		String searchParamsInfoTypeBASIC_xml = (String) contactInfo.get("searchParamsInfoTypeBASIC_xml");
		String finalUrl = null;
		logger.info("GD:: enableNewRestEndPoint: "+enableNewRestEndPoint);
		if(enableNewRestEndPoint) {
			if(SOEID_KEY.equalsIgnoreCase(serachType)) {
				finalUrl = endPointUrl + searchParamsInfoTypeBASIC.replace("#id#", id).replace("#auid#", auid);
			} else if(GEID_KEY.equalsIgnoreCase(serachType)){
				finalUrl = endPointUrl + searchParamsInfoTypeBASICGEID.replace("#id#", id).replace("#auid#", auid);
			}
		} else {
			finalUrl = endPointUrl_xml + searchParamsInfoTypeBASIC_xml.replace("#serachType#", serachType).replace("#id#", id).replace("#auid#", auid);
		}
		
		String apiResponse = null;
		try {
			apiResponse = doRequest(finalUrl, GET);
		} catch (Exception ex) {
			logger.error(finalUrl + ": Response:" + apiResponse, ex);
		}
		return apiResponse;
	}
	/**
	 * @param urlString
	 * @param method
	 * @return
	 * @throws IOException
	 */
	public static String doRequest(String urlString, String method) {
		String responseString = null;
		logger.info("GD:: Global directory url :"+urlString+" for method : "+method);
		try {
			URL url = URI.create(urlString).toURL();
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod(method);
			conn.setDoOutput(true);
			Integer responseCode = conn.getResponseCode();
			if (responseCode == 200) {
				BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), Charset.forName("UTF-8")));
				String inputLine;
				StringBuilder response = new StringBuilder();
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
				responseString = response.toString();
			} else if (RESPONSEERRORCODES.contains(responseCode)) {
				logger.info(LOGMSG + responseCode + " is thrown by  Global Dir server and responseMsg is -"	+ conn.getResponseMessage());
				return null;
			} else { 
				logger.info(LOGMSG + responseCode + " is thrown by  Global Dir server and responseMsg is -"	+ conn.getResponseMessage());
				return "{" + ERRORCODE + responseCode + "}";
			}
		} catch (Exception e) {
			logger.error("Error while consuming global dir service:"+e);
		}
		return responseString;
	}
	/**
	 * @param apiResponse
	 * @return
	 */
	private static JSONObject convertStringToJson(String apiResponse) 
    {
        try {
        	JSONObject xmlJSONObj = XML.toJSONObject(apiResponse);
            return xmlJSONObj;
        } 
        catch (Exception e) {
            logger.info("Error while converting JSON :"+e);
        }
        return null;
    }

	public String getContactSuggestion(BasicDBObject obj) {
		try {
			Map<String, Object> globalDirectoryConfig = getGlobalDirectoryConfig();
			String searchText = obj.getString("searchText");
			String infoType = obj.getString("infoType");
			
			BasicDBObject contactInfoConfig = (BasicDBObject) globalDirectoryConfig.get("contactInfoConfig");
			String auId = contactInfoConfig.getString("auid");
			String gloablDirectoryQueryString = null;
			String gdirUrl = null;
			boolean enableNewRestEndPoint = contactInfoConfig.getBoolean("enableNewRestEndPoint");
			logger.info("GD:: enableNewRestEndPoint: "+enableNewRestEndPoint);
			if(enableNewRestEndPoint) {
				gdirUrl = contactInfoConfig.getString("contactInfoEndPoint");
				gloablDirectoryQueryString = GLOBAL_DIRECTORY_QUERY_STRING_SUGGESTION;
			} else {
				gdirUrl = contactInfoConfig.getString("contactInfoEndPoint_xml");
				gloablDirectoryQueryString = GLOBAL_DIRECTORY_QUERY_STRING_SUGGESTION_XML;
			}
			String usersUrl = gdirUrl+gloablDirectoryQueryString+"&AUID="+auId+"&InfoType="+infoType;
			usersUrl = usersUrl.replace("#SEARCHTEXT#", searchText);
			logger.info("GD:: getContactSuggestion => url : " + usersUrl);
			String data = doRequest(usersUrl, GET);
			return data;
		} catch (Exception e) {
			logger.error("Exception in getContactSuggestion", e);
		}
		return null;
	}

	public String getContactInfo(BasicDBObject obj) {
		String response = null;
		try {
			Map<String, Object> globalDirectoryConfig = getGlobalDirectoryConfig();
			String soeId = obj.getString("soeId");
			String infoType = obj.getString("infoType");
			String auId = null;
			BasicDBObject contactInfoConfig = (BasicDBObject) globalDirectoryConfig.get("contactInfoConfig");
			auId = contactInfoConfig.getString("auid");
			String gloablDirectoryQueryString = null;
			String gdirUrl = null;
			boolean enableNewRestEndPoint = contactInfoConfig.getBoolean("enableNewRestEndPoint");
			logger.info("GD:: enableNewRestEndPoint: "+enableNewRestEndPoint);
			if(enableNewRestEndPoint) {
				gdirUrl = contactInfoConfig.getString("contactInfoEndPoint");
				gloablDirectoryQueryString = GLOBAL_DIRECTORY_QUERY_STRING;
			} else {
				gdirUrl = contactInfoConfig.getString("contactInfoEndPoint_xml");
				gloablDirectoryQueryString = GLOBAL_DIRECTORY_QUERY_STRING_XML;
			}
			String usersUrl = gdirUrl+gloablDirectoryQueryString+soeId+"&AUID="+auId+"&InfoType="+infoType;
			logger.info("GD:: getContactInfo => url : " + usersUrl);
			response = doRequest(usersUrl, GET);
		} catch (Exception e) {
			logger.error("Exception in getContactInfo", e);
		}
		return response; 
	}
	
	public Map<String, Object> getGlobalDirectoryConfig() {
		try {
			if (null != QMACacheFactory.getCache().getConfigById("globalDirectoryConfig")){
				Config globalDirectoryConfig = QMACacheFactory.getCache().getConfigById("globalDirectoryConfig");
				if (null != globalDirectoryConfig && null != globalDirectoryConfig.getGlobalDirectoryConfig()){
					return globalDirectoryConfig.getGlobalDirectoryConfig();
				}
			}			
		}catch(Exception ex) {
			logger.error("Error while fetching config",ex);
		}
		return Collections.emptyMap(); //<-- sonar fix null pointer
	}
	
	public String getNameFromApiResponse(String apiResponse) {
	    JSONObject object = convertStringToJson(apiResponse.trim());
	    if (null != object.get(RESPONSE)) {
		JSONObject responseObject = (JSONObject) object.get(RESPONSE);
		if (null != responseObject.get(PEOPLE) && !responseObject.get(PEOPLE).equals("")) {
		    JSONObject peopleObject = (JSONObject) responseObject.get(PEOPLE);
		    if (null != peopleObject.get(PERSON) && !peopleObject.get(PERSON).equals("")) {
			JSONObject personObject = (JSONObject) peopleObject.get(PERSON);
			return personObject.getString("Name");
		    }
		}
	    }
	    return null;
}


}

