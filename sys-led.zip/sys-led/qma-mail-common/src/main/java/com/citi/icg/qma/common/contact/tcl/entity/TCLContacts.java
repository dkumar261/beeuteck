package com.citi.icg.qma.common.contact.tcl.entity;

public class TCLContacts {

	private String totalPages;
	private String totalRows;
	private TCLContactData[] data;
	private Fields[] fields;

	public TCLContacts() {
		super();
		// Auto-generated constructor stub
	}

	public String getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(String totalPages) {
		this.totalPages = totalPages;
	}

	public String getTotalRows() {
		return totalRows;
	}

	public void setTotalRows(String totalRows) {
		this.totalRows = totalRows;
	}

	public TCLContactData[] getData() {
		return data;
	}

	public void setData(TCLContactData[] data) {
		this.data = data;
	}

	public Fields[] getFields() {
		return fields;
	}

	public void setFields(Fields[] fields) {
		this.fields = fields;
	}

	

	
	
}
