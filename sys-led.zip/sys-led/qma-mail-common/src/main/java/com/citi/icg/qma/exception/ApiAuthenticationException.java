package com.citi.icg.qma.exception;

public class ApiAuthenticationException extends Exception {

	private static final long serialVersionUID = 8758883443922087500L;
	
	public ApiAuthenticationException(String message) {
		super(message);
	}	
}
