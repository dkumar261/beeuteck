/**
 * 
 */
package com.citi.icg.qma.common.server.util;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.util.EncryptionDecryptionUtil;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.KeyValue;
import com.citi.icg.qma.common.server.dao.MailBoxDLMapping;
import com.citi.icg.qma.common.server.dao.MailBoxDLMapping.ModifiedBy;
import com.citi.icg.qma.common.server.dao.persistence.MongoDB;

import dev.morphia.Datastore;
import dev.morphia.query.Query;

/**
 * 
 *
 */
public class DedicatedReaderUtility {
	
	
	
	private static final Logger logger = LoggerFactory.getLogger(DedicatedReaderUtility.class);
	private static DedicatedReaderUtility instance = null;
	private final Datastore dataStore;
	
	private static final String DB_DEDICATED_MAIL_BOX_CONFIG_KEY = "dedicatedMailBoxConfig";
	private static final String DB_DMS_EXCH_SERVER_CONFIG_KEY = "msExchangeServerConfiguration";
	private static final String DB_MAILBOX_DEFAULT_EXCHANGE_CONFIG = "mailBoxDefaultExchangeConfig";
	
	public static final String DEDICATED_DL_READER_SCHEDULER_MAILBOX_NAME = "dedicatedDLReaderScheduler";
	public static final String DEDICATED_PERSONAL_READER_SCHEDULER_MAILBOX_NAME = "dedicatedPersoanlReaderScheduler";
	public static final String DEDICATED_DL_READER_SCHEDULER_MAILBOX_NAME_ECS = "dedicatedDLReaderSchedulerEcs";
	public static final String READER_CLUSTER_DEDICATED = "ReaderClusterDedicated";
	public static final String READER_CLUSTER_PERSONAL = "ReaderClusterPersonal";
	public static final String READER_CLUSTER_NODE_NAME = "readerClusterNodeName";
	public static final String MAILBOX_TYPE_PERSONAL = "personal";
	private static final String DB_ID_KEY = "_id";
	
	private DedicatedReaderUtility(){
		dataStore = MongoDB.instance().getDataStore();
	}
	
	public static synchronized DedicatedReaderUtility getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		if (instance == null) {
			instance = new DedicatedReaderUtility();
		}
		return instance;
	}
	
	/**
	 * This method will laod dedicated mailbox config from database.
	 * @return Map<String, Object> 
	 */
	public Map<String, Object> loadDedicatedMailBoxConfigFromDB() {
		Map<String, Object> configMap = null;
		try {
			logger.info("Loading 'dedicatedMailBoxConfig' configuration from database.");
			Query<Config> query = dataStore.createQuery(Config.class);
			@SuppressWarnings("deprecation")
			List<Config> configDataList = query.asList();
			for (Config config : configDataList) {
				if (config != null && DB_DEDICATED_MAIL_BOX_CONFIG_KEY.equalsIgnoreCase(config.getId())) {
					configMap = config.getDedicatedMailBoxConfig();
					break;
				}
			}
		} catch (Exception e) {
			logger.error("Exception in DedicatedReaderUtility#loadDedicatedMailBoxConfigFromDB() :", e );
		}
		return configMap;
	}
	
	/**
	 * This method will load the ms exchange configuration from database.
	 * @return Map<String, String>
	 */
	public Map<String, String> getMsExchConfig() {
		Map<String, String> keyValueMap = null;
		try {
			logger.info("Loading 'msExchangeServerConfiguration' configuration from database.");
			Query<Config> query = dataStore.createQuery(Config.class);
			@SuppressWarnings("deprecation")
			List<Config> configDataList = query.asList();
			for (Config config : configDataList) {
				if (config != null && DB_DMS_EXCH_SERVER_CONFIG_KEY.equalsIgnoreCase(config.getId())
						&& null != config.getMsExchangeServerConfigList() && !config.getMsExchangeServerConfigList().isEmpty()) {
					List<KeyValue> keyValues = config.getMsExchangeServerConfigList();
					keyValueMap = keyValues.stream().collect(Collectors.toMap(KeyValue::getKey,KeyValue::getValue));
					break;
				}
			}
		} catch (Exception e) {
			logger.error("Exception in DedicatedReaderUtility#getMsExchConfig() :", e );
		}
		return keyValueMap;
	}
	
	/**
	 * This is utility method, gets the long value from the provided input Map
	 * @param map
	 * @param key
	 * @return long
	 */
	public long getLongValueFromMap(Map<String, Object> map, String key) {
		if( null != map && StringUtils.isNotEmpty(key) && null != map.get(key) ){
			return (Long) map.get(key);
		}
		return 0;
	}

	/**
	 * This method gets the default value from the db
	 * @param key
	 * @return Object
	 */
	public Object getDefaultValueForMailBox(String key) {
		Map<String,Object> dedicatedConfig = loadDedicatedMailBoxConfigFromDB();
		if( null!= dedicatedConfig) {
			Map<String,Object> mailBoxDefaultExchangeConfig = (Map<String, Object>) dedicatedConfig.get("mailBoxDefaultExchangeConfig");
			if(null != mailBoxDefaultExchangeConfig) {
				return mailBoxDefaultExchangeConfig.get(key);
			}
		}
		return null;
	}
	
	/**
	 * This method returns the default exchange configurations for mailBox
	 * @param key
	 * @return
	 */
	public Object getDefaultExchangeConfigValueForMailBox(String key) {
		Map<String, Object> exchangeConfig = getDefaultExchangeConfig();
		return exchangeConfig.get(key);
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> getDefaultExchangeConfig() {
		Map<String,Object> dedicatedConfig = loadDedicatedMailBoxConfigFromDB();
		return (Map<String,Object>) dedicatedConfig.get(DB_MAILBOX_DEFAULT_EXCHANGE_CONFIG);
	}
	
	/**
	 * This method will provide mapping details for provided account
	 * @param mailBoxName
	 * @return MailBoxDLMapping
	 */
	public MailBoxDLMapping getMappingById(String mailBoxName) {
		MailBoxDLMapping mapping = null;
		try {
			if(StringUtils.isNotBlank(mailBoxName)){
				Query<MailBoxDLMapping> query = dataStore.createQuery(MailBoxDLMapping.class).filter(DB_ID_KEY, mailBoxName);
				mapping = query.first();
				if( null == mapping ) {
					logger.warn("Mailbox mapping not found for provided mailbox.");
				}
			} else {
				logger.info("'mailBoxName' provided is either 'null' or 'empty'.");
			}
			
		} catch (Exception e) {
			logger.error("Excetpion while retrieveing account mapping from database in DedicatedReaderUtility#getMappingById() : ", e);
		}
		return mapping;
	}
	
	/**
	 * This method extracts the login secret from the encrypted keys.
	 * @param mapping
	 * @return String
	 */
	public String getSecret(MailBoxDLMapping mapping) {
		String secret = "";
		try {
			if( StringUtils.isNotBlank(mapping.getLoginSecretEnc()) && StringUtils.isNotBlank(mapping.getLoginSecretEncIV()) ) {
				EncryptionDecryptionUtil util = new EncryptionDecryptionUtil();
				secret = util.getDecryptedPassword(mapping.getLoginSecretEnc(), mapping.getLoginSecretEncIV());
			} else {
				logger.warn("ENC and ENCIV strings are not updated for id : {} in the MailBoxMapping Collection.", mapping.getId());
			}
		} catch (Exception e) {
			logger.error("Exception while getting login secret for {} in DedicatedReaderUtility#getSecret(): ", mapping.getId(), e);
		}
		return secret;
	}
	
	/**
	 * This method updates mailbox mapping details in database.
	 * @param mapping
	 */
	public void updateMailBoxMapping(MailBoxDLMapping mapping) {
		try {
			if (null != mapping) {
				Date d = new Date();
				mapping.setModDate(d);
				mapping.setModBy(ModifiedBy.MAILBOX_OWNER);
				dataStore.save(mapping);
			}
		} catch (Exception e) {
			logger.error("Exception in DedicatedReaderUtility#updateMailBoxMapping() : ", e);
		}
	}
	
	
	/**
	 * This method gets the login secret in encoded format
	 * @param encodedSecret
	 * @return String[]
	 */
	public String[] getEncryptedLoginSecret(String encodedSecret) {
		String[] loginSecret = {"",""};
		try {
			if (StringUtils.isNotBlank(encodedSecret)) {
				byte[] decodeExchPassword = Base64.getDecoder().decode(encodedSecret);
				String decodeExchPasswordStr = new String(decodeExchPassword, StandardCharsets.UTF_8);
				String[] encyptedPwd = EncryptionDecryptionUtil.getInstance().encryptInputString(decodeExchPasswordStr);

				if (null != encyptedPwd && encyptedPwd.length == 2) {
					loginSecret[0] = encyptedPwd[0];
					loginSecret[1] = encyptedPwd[1];
				}
			} else {
				logger.info("Secret sent from UI is either null or empty.");
			}
		} catch (Exception e) {
			logger.error("Exception while getting encrypted login secret : ", e);
		}
		return loginSecret;
	}

	/**
	 * This method will get the decrypted version of login secret
	 * @param loginSecretEnc
	 * @param loginSecretEncIV
	 * @return String
	 */
	public String getDecryptedLoginSecret(String loginSecretEnc, String loginSecretEncIV) {
		String loginSecret = "";
		try {
			if(StringUtils.isNotBlank(loginSecretEnc) && StringUtils.isNotBlank(loginSecretEncIV)) {
				loginSecret = EncryptionDecryptionUtil.getInstance().getDecryptedPassword(loginSecretEnc, loginSecretEncIV);
			}
		} catch (Exception e) {
			logger.error("Exception while getting decrypted login secret : ", e);
		}
		return loginSecret;
	}
}
