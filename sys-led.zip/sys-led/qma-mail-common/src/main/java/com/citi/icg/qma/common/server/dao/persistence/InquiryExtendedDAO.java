/**
 * 
 */
package com.citi.icg.qma.common.server.dao.persistence;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

//import javax.servlet.http.HttpServletRequest;
import jakarta.ws.rs.core.Response;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.DataConversionUtil;
import com.citi.icg.qma.common.core.util.NLPConstants;
import com.citi.icg.qma.common.core.util.QueryConstants;
import com.citi.icg.qma.common.server.cache.ConversationCache;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.Conversation;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.CustomClientCategoryDetails;
import com.citi.icg.qma.common.server.dao.CustomClientCriteriaRuleBean;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.GroupRole;
import com.citi.icg.qma.common.server.dao.Inquiry;
import com.citi.icg.qma.common.server.dao.InquiryClientPriority;
import com.citi.icg.qma.common.server.dao.User;
import com.citi.icg.qma.common.server.dao.UserActivities;
import com.citi.icg.qma.common.server.dao.Workflow;
import com.citi.icg.qma.common.server.dao.WorkflowAudit;
import com.citi.icg.qma.common.server.util.CustomClientCategoryEnum;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.common.server.util.SmartSearchUtil;
import com.citi.icg.qma.common.transferobject.ConversationTO;
import com.citi.icg.qma.common.transferobject.DraftTO;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.AggregationOptions;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.Cursor;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.ReadPreference;

import dev.morphia.query.Query;
import dev.morphia.query.UpdateOperations;

/**
 * 
 *
 */
public class InquiryExtendedDAO extends MongoMorphiaDAO {


	

	private static final String SOLR_SEARCH_TEXT = "solrSearchText";

	private static final String ADVANCE_SEARCH_DATA = "advanceSearchData";

	private static final String POTENTIAL_ESCALATIONS = "Potential Escalations";

	private static final String POTENTIAL_ESCALATION = "Potential Escalation";
	
	private static final String PENDING_APPROVAL = "Pending Approval";

	private static final String MOD_DATE = "modDate";

	private static final String GTE = "$gte";

	private static final String ELEM_MATCH = "$elemMatch";

	private static final String WORKFLOWS = "workflows";

	private static final String AGE_BAND_TO_DATE = "ageBandToDate";

	private static final String AGE_BAND_FROM_DATE = "ageBandFromDate";

	private static final String AUTO_ASSIGNMENT_RULE = "autoAssignmentRule";

	private static final String CUSTOM = "custom";

	private static final String CATEGORY_NAME = "categoryName";

	private static final String OTHER = "Other";

	private static final String PRIORITY = "Priority";

	private static final String SUPERCHARGE = "Supercharge";

	private static final String PLATINUM = "Platinum";

	private static final String ASSIGNED_GROUP_ID = "assignedGroupId";

	private static final String CLIENT_PRIORITY_FROM_DATE = "clientPriorityFromDate";

	private static final String SYSTEM = "system";

	private static final String TAKE_OWNERSHIP_UNSUCCESSFUL = "Take ownership unsuccessful";

	private static final Logger inqExtLogger = LoggerFactory.getLogger(InquiryExtendedDAO.class);
	
	private static final InquiryDAO inquiryDao = new InquiryDAO();
	private static final UserActivitiesDAO user_Activities_Dao = new UserActivitiesDAO();
	private static final HashMap<String, String> userLatestTokenHolder = new HashMap<>();
	
	private static final String MARK_AS_READ_YES = "Y";
	private static final String CONV_IDS_KEY = "convIds";
	private static final String INQUIRY_IDS_KEY = "inquiryIds";
	private static final String READ_FLAG = "readFlag";
	public static final String READ_BY = "readBy";
	
	private static final String CONVERSATION_KEY = "Conversation";
	private static final String INQUIRY_KEY = "Inquiry";
	private static final String ID_KEY = "_id";
	private static final String ADD_TO_SET_KEY = "$addToSet";
	private static final String PULL_KEY = "$pull";
	
	private static final String MESSAGE = "message";
	private static final String SUCCESS = "Success";
	public static final String SUBJECT = "subject";
	public static final String INQUIRY_DIRECTION_IN = "IN";
	private static final String ACTION_ACCEPT = "Approve";
	private static final String ACTION_REJECT = "Reject";
	
	private static final String GROUP_IDS_KEY = "groupIds";
	private static final String INQ_GRP_ID_KEY = "inqGrpId";
	private static final String ACCEPTED_NOMINATE_OWNERSHIP = "Accepted - NOMINATE_OWNERSHIP";
	private static final String INQUIRY_STATUS_OPEN = "Open";
	private static final String ACCEPT_NOMINATION = "Accept Nomination";
	private static final String APPROVALS = "Approvals";
	private static final String PENDING_NOMINATE_OWNERSHIP = "Pending - NOMINATE_OWNERSHIP";
	private static final String OWNERSHIP_NOMINATION = "Ownership Nomination";
	private static final String REJECT_NOMINATION = "Reject Nomination";
	private static final String RESOLVED = "Resolved";
	private static final String REJECTED_NOMINATE_OWNERSHIP = "Rejected - NOMINATE_OWNERSHIP";
	private static final String NOMINATE_OWNERSHIP = "NOMINATE_OWNERSHIP";
	private static final HashMap<String, Long> inquiryNominationBypassMap = new HashMap<>();
	private static final String PEER_REVIEWER = "Peer Reviewer";
	private static final String ADMIN = "Group Admin";
	private static UserDAO userDao = new UserDAO();
	
	private static InquiryExtendedDAO instance = null;
	
	public static synchronized InquiryExtendedDAO getInstance()//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
	{
		if (instance == null) {
			instance = new InquiryExtendedDAO();
		}
		return instance;
	}
	
	/**
	 * This method will mark inquiry read/unread for first conversation read on row click
	 * @param conversationTO
	 * @param soeId
	 */
	public void markInquiryReadUnreadBasedOnConversation(ConversationTO conversationTO, String soeId) {
		try {
			if (null != conversationTO.getConversationList() && !conversationTO.getConversationList().isEmpty()
					&& StringUtils.isNotEmpty(soeId)) {
				updateInquiryAndConvForReadUnread(conversationTO, soeId);
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#markInquiryReadUnread()", e);
		}
	}

	/**
	 * This method will mark inquiry read/unread depending on conversation read/unread
	 * @param conversationTO
	 * @param soeId
	 * @throws CommunicatorException
	 */
	private void updateInquiryAndConvForReadUnread(ConversationTO conversationTO, String soeId) throws CommunicatorException {
		int count = 0;
		for (Conversation conv : conversationTO.getConversationList()) {
			//On click of inquiry in grid, by default we fetch first conversation, which should be marked read. 
			if( conversationTO.getConversationList().size() == 1 || count == 0 ) {
				//On click of row, mark first conversation is read 
				updateConversationReadByUser(conv,soeId, true);
			} else if( ! checkIfConvReadByLoggedInUser(soeId, conv) ) {
				updateInquiryUnreadByUser(conversationTO, soeId);
				//Break Loop even if single conversation is unread
				break;
			}
			count++;
		}
	}

	/**
	 * This method will mark inquiry unread by user 
	 * @param conversationTO
	 * @param soeId
	 */
	private void updateInquiryUnreadByUser(ConversationTO conversationTO, String soeId) {
		
		Inquiry inq = conversationTO.getInquiry();
		
		BasicDBObject updateReadBy = new BasicDBObject();
		updateReadBy.put(PULL_KEY, new BasicDBObject(READ_BY, soeId));
		updateInquiryReadBy(inq, updateReadBy /*,soeId*/);
	}

	/**
	 * This method checks if conversation is read by logged in user
	 * @param soeId
	 * @param conv
	 * @return boolean
	 */
	private boolean checkIfConvReadByLoggedInUser(String soeId, Conversation conv) {
		boolean isRead = false;
		if (null != conv.getReadBy() && conv.getReadBy().size() > 0) {
			for (String readBy : conv.getReadBy()) {
				if (StringUtils.isNotEmpty(readBy) && readBy.equalsIgnoreCase(soeId.trim())) {
					isRead = true;
					break;
				}
			}
		}
		return isRead;
	}

	/**
	 * This method marks selected conversation read
	 * @param conversationTO
	 * @param convId
	 * @param soeId
	 * @param isMarkAsRead
	 * @param inqGroupId
	 */
	public void markConversationRead(ConversationTO conversationTO, Long convId, String soeId, boolean isMarkAsRead,List<Long> inqGroupId) {
		try {
			if (null != conversationTO.getConversationList() && !conversationTO.getConversationList().isEmpty()
					&& StringUtils.isNotEmpty(soeId) && convId != null ) {
				updateConversationsReadUnread(conversationTO, soeId,isMarkAsRead,inqGroupId);
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#markConversationRead()", e);
		}
		
	}

	/**
	 * This method will update conversation read
	 * @param conversationTO
	 * @param soeId
	 * @param isMarkAsRead
	 * @param inqGroupId
	 * @throws CommunicatorException
	 */
	private void updateConversationsReadUnread(ConversationTO conversationTO, String soeId, boolean isMarkAsRead,List<Long> inqGroupId)
			throws CommunicatorException {
		for(Conversation conv : conversationTO.getConversationList()) {
			List<String> readBy = conv.getReadBy();
			if(null == readBy){
				readBy = new ArrayList<>();
				conv.setReadBy(readBy);
			}
			if((isMarkAsRead && !readBy.contains(soeId.trim())) || !isMarkAsRead ) {
				updateConversationReadByUser(conv, soeId, isMarkAsRead);
				
				//Get all inquiry conversations
				ConversationTO convTOInq = getAllInquiryConversations(soeId,conv.getInquiryId(), inqGroupId,false,null);
				if(convTOInq!=null && null!= convTOInq.getConversationList() 
						&& !convTOInq.getConversationList().isEmpty()) {
					//Check and update inquiry as well once individual conversation is read by user.
					updateInquiryReadUnreadBasedOnAllConversation(convTOInq, soeId);
				}
			}
		}
	}
	
	
	/**
	 * This method will update inquiry read/unread based on all conversation
	 * @param conversationTO
	 * @param soeId
	 */
	private void updateInquiryReadUnreadBasedOnAllConversation(ConversationTO conversationTO, String soeId) {
		
		Inquiry inq = conversationTO.getInquiry();
		
		if( inq != null ) {
			
			List<String> inqReadBy = inq.getReadBy();
			
			if( null == inqReadBy ) {
				inqReadBy = new ArrayList<>();
			}
			
				
			BasicDBObject updateReadBy = new BasicDBObject();

			if( checkIfAllConversationsAreReadForInquiry(conversationTO, soeId)) {
				inqReadBy.add(soeId.trim());
				updateReadBy.put(ADD_TO_SET_KEY, new BasicDBObject(READ_BY, soeId));
				inqExtLogger.info("marking as READ for user[{}] for inquiry[{}]", soeId, inq.getId());
			} else {
				inqReadBy.remove(soeId.trim());
				updateReadBy.put(PULL_KEY, new BasicDBObject(READ_BY, soeId));
				inqExtLogger.info("marking as UN-READ for user[{}] for inquiry[{}]", soeId, inq.getId());
			}
			
			updateInquiryReadBy(inq, updateReadBy /*,soeId*/);
		}
	}

	/**
	 * This method updates inquiry readBy in database
	 * @param inq
	 * @param inqReadBy
	 */
	private void updateInquiryReadBy(Inquiry inq, BasicDBObject inqReadBy /*, String userId*/) {
		try {
			if(null != inq.getId() && null != inqReadBy) {
				DBObject findInquiry = new BasicDBObject(ID_KEY, inq.getId());
				DBCollection inquiryCollection = MongoDB.instance().getDB().getCollection(INQUIRY_KEY);
				inquiryCollection.update(findInquiry, inqReadBy);
				/*inquiryDao.saveInquiriesToPublish(inquiryIds, "Conversation Read/Unread", userId);*/
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateInquiryReadBy()", e);
		}
	}

	
	/**
	 * This method identifies whether all inquiry conversations are read by logged in users
	 * @param conversationTO
	 * @param soeId
	 * @return boolean
	 */
	private boolean checkIfAllConversationsAreReadForInquiry(ConversationTO conversationTO, String soeId) {
		boolean isAllConvReadByUser = true;
		if(null!=conversationTO && conversationTO.getConversationList().size() > 0) {
			for(Conversation conv : conversationTO.getConversationList()) {
				if( null != conv.getReadBy() && !conv.getReadBy().isEmpty() && !conv.getReadBy().contains(soeId.trim())) {
					isAllConvReadByUser = false;
					break;
				}
			}
		}		
		return isAllConvReadByUser;
	}
	
	
	/**
	 * This method updates conversation read by logged in user
	 * @param conv
	 * @param soeId
	 */
	private void updateConversationReadByUser(Conversation conv, String soeId, boolean isMarkAsRead ) {
		
		List<String> readBy = conv.getReadBy();
		if(null == readBy) {
			readBy = new ArrayList<>();
		} 

		if( isMarkAsRead && ! readBy.contains(soeId.trim()) ) {
			BasicDBObject addReadBy = new BasicDBObject();
			addReadBy.put(ADD_TO_SET_KEY, new BasicDBObject(READ_BY, soeId));
			updateConversation(conv, addReadBy);
			inqExtLogger.info("marking as READ for user[{}] for conv[{}]", soeId, conv.getId());
		} else if( !isMarkAsRead && readBy.contains(soeId.trim()) ) {
			BasicDBObject removeReadBy = new BasicDBObject();
			removeReadBy.put(PULL_KEY, new BasicDBObject(READ_BY, soeId));
			updateConversation(conv, removeReadBy);
			inqExtLogger.info("marking as UN-READ for user[{}] for conv[{}]", soeId, conv.getId());
		}
	}


	/**
	 * This method updates conversations in database
	 * @param conv
	 * @param soeId
	 * @param readBy
	 */
	private void updateConversation(Conversation conv, BasicDBObject readBy) {
		try {
			DBObject findQueryObj = new BasicDBObject(ID_KEY, conv.getId());
			DBCollection conversationCollection = MongoDB.instance().getDB().getCollection(CONVERSATION_KEY);
			conversationCollection.update(findQueryObj, readBy);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateConversation() " , e);
		}
	}
	
	public ConversationTO getAllInquiryConversations(String soeId,Long inquiryId, List<Long> selectInqAssignedGroupId, boolean isAllConvContent, BasicDBObject inputJsonObj) throws CommunicatorException {
		return getAllInquiryConversations(soeId,inquiryId,selectInqAssignedGroupId,isAllConvContent,inputJsonObj,null);
	}
	
	public ConversationTO getAllInquiryConversations(String soeId,Long inquiryId, List<Long> selectInqAssignedGroupId, boolean isAllConvContent, BasicDBObject inputJsonObj,List<Long> selectConvIds) throws CommunicatorException {

		ConversationTO conversationTO = new ConversationTO();
		try {
			conversationTO = inquiryDao.getAllInquiryExtConversationsWithPaging(soeId, inquiryId, selectInqAssignedGroupId,isAllConvContent,inputJsonObj,selectConvIds);
		}
		catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#getAllInquiryConversations() for soeId = "+soeId+" , InquiryId= " + inquiryId, e);
		}
		return conversationTO;
	}
	public ConversationTO getAllInquiryConversationsForServerSidePaging(String soeId,Long inquiryId, List<Long> selectInqAssignedGroupId,BasicDBObject inputJsonObject) throws CommunicatorException {

		ConversationTO conversationTO = new ConversationTO();
		try {
			conversationTO = inquiryDao.getAllInquiryExtConversationsWithPaging(soeId, inquiryId, selectInqAssignedGroupId,true,inputJsonObject);
		}
		catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#getAllInquiryConversationsForServerSidePaging() for soeId = "+soeId+" , InquiryId= " + inquiryId, e);
		}
		return conversationTO;
	}
	/**
	 * This method is used to save draft for scheduled for later
	 * @param request
	 * @param soeId
	 * @param startTime
	 * @return
	 */
	public Response scheduleForLater(String request, String soeId) {
		DraftTO draftResponse = new DraftTO();
		try {
			String inqData = request.substring(0, request.indexOf(":::editorData:"));
			String content = request.substring(request.indexOf(":::editorData:") + 14, request.length());
			BasicDBObject inputJsonObj = BasicDBObject.parse(inqData);
			boolean dupRequest = isDuplicateRequest(soeId, inputJsonObj);
			if (dupRequest)
			{
				String json = "Duplicate request is generated and rejected.";
				return Response.status(501).entity(json).build();
			}
			draftResponse = inquiryDao.saveDraft(inputJsonObj, content, soeId);
			return Response.status(200).entity(draftResponse).build();
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#scheduleForLater() soeId = "+ soeId ,e);
			return Response.status(501).entity("Exception in InquiryExtendedDAO#scheduleForLater for soeId = "+soeId+ "Exception="+e).build();
		}		
	}

	private boolean isDuplicateRequest(String soeId, BasicDBObject inputJsonObj) {
		String uiToken = inputJsonObj.getString("token");
		String holderToken = userLatestTokenHolder.get(soeId);
		if (!uiToken.equals(holderToken)) {
			userLatestTokenHolder.put(soeId, uiToken);
			return false;
		} else {
			return true;
		}
	}

	/**
	 * This method mark conversation as read/unread
	 * @param request
	 * @param soeId
	 * @return boolean
	 */
	public boolean markConversationReadUnread(String request, String soeId) {
		boolean success = false;
		try {
			if(StringUtils.isNotEmpty(request) && StringUtils.isNotEmpty(soeId) ){
				BasicDBObject inputJson = BasicDBObject.parse(request);
				if(null != inputJson) {
					success = getConvDetailsAndMarkReadOrUnread(inputJson, soeId);
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#markConversationRead()"+ soeId ,e);
		}
		return success;
	}

	/**
	 * This method extracts data for marking inquiry read/unread
	 * @param inputJson
	 * @param soeId
	 * @return boolean
	 */
	@SuppressWarnings("deprecation")
	private boolean getConvDetailsAndMarkReadOrUnread(BasicDBObject inputJson, String soeId) {
		boolean success = false;
		try {
			String readFlag = "";
			BasicDBList inqIds = null;
			BasicDBList convIds =null;
			if(inputJson.containsField(READ_FLAG) && StringUtils.isNotEmpty(inputJson.getString(READ_FLAG))){
				readFlag = inputJson.getString(READ_FLAG);
			}
			
			List<Long> inqGroupId = GenericUtility.getIdListFromRequest(inputJson, INQ_GRP_ID_KEY);
			
			if(inputJson.containsField(INQUIRY_IDS_KEY) && StringUtils.isNotEmpty(inputJson.getString(INQUIRY_IDS_KEY)) &&
					inputJson.containsField(CONV_IDS_KEY) && StringUtils.isNotEmpty(inputJson.getString(CONV_IDS_KEY)) ){
				inqIds = DataConversionUtil.convertJsonToBasicDBList(inputJson.getString(INQUIRY_IDS_KEY));
				convIds = DataConversionUtil.convertJsonToBasicDBList(inputJson.getString(CONV_IDS_KEY));
			}

			success = updateConvReadUnread(readFlag, inqIds, convIds, soeId, inqGroupId);
		
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#getConvDetailsAndMarkReadOrUnread()"+ soeId ,e);
		}
		return success;
	}

	/**
	 * This method validates input parameters for marking conversation conversation read/unread.
	 * @param readFlag
	 * @param inqIds
	 * @param convIds
	 * @param soeId
	 * @param inqGroupId
	 * @return boolean
	 */
	public boolean updateConvReadUnread(String readFlag, BasicDBList inqIds, BasicDBList convIds, String soeId,List<Long> inqGroupId) {
		boolean success = false;
		try {
			if(StringUtils.isNotEmpty(readFlag) && null != inqIds && null!= convIds ){
				if(inqGroupId!=null && !inqGroupId.isEmpty()){
					extractInqConvIdAndUpdate(readFlag, convIds, soeId, inqGroupId);
					success = true;
				} else {
					success = false;
				}
			}
 		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#markConvReadUnread()" ,e);
		}
		return success;
		
	}

	/**
	 * This method extracts data for updating conversation as read/unread
	 * @param readFlag
	 * @param convIds
	 * @param inqGroupId
	 * @param soeId
	 */
	private void extractInqConvIdAndUpdate(String readFlag, BasicDBList convIds, String soeId, List<Long> inqGroupId) {
		
		for( int i = 0 ; i < convIds.size() ; i++ ) {
			long convId = GenericUtility.convertIdFromRequest(convIds.get(i));
			if(convId != 0){
				markConvReadUnread(convId, readFlag, soeId,inqGroupId);
			}
		}
	}

	/**
	 * This method forwards request to mark conversation as read/unread
	 * @param convId
	 * @param readFlag
	 * @param inqGroupId
	 * @param soeId
	 */
	private void markConvReadUnread(Long convId, String readFlag, String soeId,List<Long> inqGroupId) {
		try {
			boolean isMarkAsRead = false;
			if(MARK_AS_READ_YES.equalsIgnoreCase(readFlag)){
				isMarkAsRead = true;
			} 
			ConversationTO convTo = inquiryDao.getInquiryConversationById(convId);
			markConversationRead(convTo, convId, soeId, isMarkAsRead,inqGroupId);
		} catch (CommunicatorException e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#markConvReadUnread()" ,e);
		}
	}
	
	
	/**This method to take ownership
	 * @param request
	 * @param soeId
	 * @param servletRequest 
	 * @return
	 */
	public BasicDBObject takeOwnership(String request, String soeId, UserActivities userActivity) {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			boolean successStatus = inquiryDao.takeOwnership(soeId, inputJsonObj, userActivity);
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS_KEY);
			if(successStatus){
				boolean success = assignOwnerInTakeOwnership(soeId, inputJsonObj, inquiryIds, userActivity);
				if(success){
					response.put(SUCCESS, true);
					response.put(MESSAGE, "Ownership taken successfully");
				} else {
					response.put(SUCCESS, false);
					response.put(MESSAGE, TAKE_OWNERSHIP_UNSUCCESSFUL);
					inqExtLogger.info("assignOwnerInTakeOwnership unsuccessful");
				}
				//response.put(SUCCESS, true);
				//response.put(MESSAGE, "Ownership taken successfully");
			} else {
				response.put(SUCCESS, false);
				response.put(MESSAGE, TAKE_OWNERSHIP_UNSUCCESSFUL);
				inqExtLogger.info("takeOwnership nomination unsuccessful");
			}
			
			
		} catch (Exception e) {
			response.put(SUCCESS, false);
			response.put(MESSAGE, TAKE_OWNERSHIP_UNSUCCESSFUL);
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#takeOwnership()" ,e);
		}
		return response;
	}

	/**
	 * @param soeId
	 * @param inputJsonObj
	 * @param inquiryIds
	 * @param servletRequest 
	 */
	private boolean assignOwnerInTakeOwnership(String soeId, BasicDBObject inputJsonObj, List<Long> inquiryIds, UserActivities userActivityt) {
		boolean success = false;
		try {
		String assingedOwner = inputJsonObj.getString("assingedOwner");
		if (StringUtils.isEmpty(assingedOwner)){
			 	inqExtLogger.info("Invalid Input for assignToOwner -" + assingedOwner + " by " + soeId);
			 	throw new CommunicatorException("Invalid Data for assignOwnerInTakeOwnership, Empty UserId.");
		}

		Map<Long, Long> inquiryGroupMap=  inquiryDao.populateInquiryGrpMap(((List<String>) inputJsonObj.get(GROUP_IDS_KEY)));
		Long groupId = inquiryGroupMap.get(inquiryIds.get(0));
		String groupName = null;
		if(null != groupId){
			groupName = QMACacheFactory.getCache().getGroupIdToNameMap().get(groupId);
		} else {
			inqExtLogger.info("Invalid groupId "+ groupId);
		}
		if(StringUtils.isNotBlank(groupName)){
			inputJsonObj.put("groupName", groupName);
		} else {
			inqExtLogger.info("Invalid groupName "+ groupName);
		}
		inputJsonObj.put("assignToUserId", assingedOwner);
		success = inquiryDao.assignToOwner(soeId, inputJsonObj, userActivityt);
		
		} catch (CommunicatorException e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#assignOwnerInTakeOwnership()" ,e);
		}
		return success;
	}
	
	/**This method to nominate ownership
	 * @param request
	 * @param soeId
	 * @param startTime2 
	 * @param servletRequest 
	 * @return
	 */
	public BasicDBObject nominateOwnership(String request, String soeId, UserActivities userActivity, long startTime) {
		BasicDBObject response = new BasicDBObject();
		try {
			BasicDBObject inputJsonObj = BasicDBObject.parse(request);
			String inquiryAction = "nominateOwnership";
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS_KEY);
			
			String actionDetails = inquiryAction+ " by " +soeId+ " for InquiryId(s) : " + inquiryIds.toString();
			user_Activities_Dao.saveUserActivities(soeId, userActivity, System.currentTimeMillis() - startTime);
			
			@SuppressWarnings("unchecked")
			// C170665-3131 Nominate onwership not working when user doesnt have access to nominated group
			// Map<Long, List<Long>> nomineeInquiryGroupMap =  inquiryDao.populateInquiryGroupListMap((List<String>) inputJsonObj.get(GROUP_IDS_KEY));
			Map<Long, List<Long>> nomineeInquiryGroupMap =  inquiryDao.populateInquiryGroupListMap((List<String>) inputJsonObj.get("nominatedGroupId"));
			@SuppressWarnings("unchecked")
			// C170665-3131 Nominate onwership not working when user doesnt have access to nominated group
			// Map<Long, List<Long>> nominatingInquiryGroupMap =  inquiryDao.populateInquiryGroupListMap((List<String>) inputJsonObj.get("nominatingGroupId"));
			Map<Long, List<Long>> nominatingInquiryGroupMap =  inquiryDao.populateInquiryGroupListMap((List<String>) inputJsonObj.get(GROUP_IDS_KEY));
			String reason = inputJsonObj.getString("reason");
			//check if nominated workflow already exists
			
			createNominationWorkflow(inquiryIds, nomineeInquiryGroupMap, nominatingInquiryGroupMap, soeId, reason, userActivity);
			
			inquiryDao.saveInquiriesToPublish(inquiryIds, "Nominate Ownership", soeId);
			response.put(SUCCESS, true);
			response.put(MESSAGE, "Request for nomination sent successfully");
			
		} catch (Exception e) {
			response.put(SUCCESS, false);
			response.put(MESSAGE, "Request for nomination unsuccessful");
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#takeOwnership()" ,e);
		}
		return response;
	}
	
	/**
	 * @param inputJsonObj
	 * @param dbInquiry
	 * @param to
	 * @param fromGroup
	 * @param conversation
	 * @param workFlowList
	 */
	public void customClientCriteriaExecution(BasicDBObject inputJsonObj, Inquiry dbInquiry, String to,
			String fromGroup, Conversation conversation, List<Workflow> workFlowList) {
		try {
			String subject = inputJsonObj.getString(SUBJECT);
			List<String> toAddressListForCriteria = new ArrayList<>();
			toAddressListForCriteria.add(to);
			toAddressListForCriteria.add(inputJsonObj.getString("cc"));
			List<ConversationRecipient> allToCCIncomingRecipientList = conversation.getRecipients();
			Map<Long, List<CustomClientCategoryDetails>> customClientCriteriaMap = getCustomClientCriteriaMapForToFromEmailSubj(subject, fromGroup, toAddressListForCriteria, allToCCIncomingRecipientList);
			setCustomClientCategoryCriteria(workFlowList, null, dbInquiry, customClientCriteriaMap);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#customClientCriteriaExecution()" ,e);
		}
	}
	
	//it will set custom client criteria to workflow
			public void setCustomClientCategoryCriteria(List<Workflow> list, List<Workflow> allExtistingDBVersionList, Inquiry inquirySummaryDOBean, Map<Long, List<CustomClientCategoryDetails>> customClientCategoryCriteriaMap)
			{
				inqExtLogger.info("inside setCustomClientCategoryCriteria() method inputs : newVersionList = " + list +" inquirySummaryDOBean = " +inquirySummaryDOBean
						 +  " customClientCategoryCriteriaMap = " +customClientCategoryCriteriaMap.keySet());
				if(customClientCategoryCriteriaMap.isEmpty()){
					inqExtLogger.info("customClientCategoryCriteriaMap  is empty");
					return;
				}
				
				try
				{
					if (list != null && !list.isEmpty())
					{
						inqExtLogger.info("setCustomClientCategoryCriteria  is for new workflow");
						for (Workflow xmcInquiryVersion : list)
						{
							setCustomClientCriteriaToWorkflow(customClientCategoryCriteriaMap, xmcInquiryVersion);
							
						}
					}
					else if (allExtistingDBVersionList != null && !allExtistingDBVersionList.isEmpty())
					{
						inqExtLogger.info("setCustomClientCategoryCriteria  is for existing workflow");
						for (Workflow xmcInquiryVersion : allExtistingDBVersionList)
						{
							setCustomClientCriteriaToWorkflow(customClientCategoryCriteriaMap, xmcInquiryVersion);
							
						}
					}
				}
				catch (Exception e)
				{
					inqExtLogger.warn("Issue in setCustomClientCategoryCriteria: inquiryId="+inquirySummaryDOBean.getId() , e);
				}
			}
			
			//set custom client criteria map 
			
			public Map<Long, List<CustomClientCategoryDetails>> getCustomClientCriteriaMapForToFromEmailSubj(String subject, String fromAddress,List<String> toAddressListForCriteria, List<ConversationRecipient> recipientList)
			{
				Map<Long, List<CustomClientCategoryDetails>> groupRoutingMap = new HashMap<>();
				// Get the routing criteria map from the cache for all the groups
				try {
					Map<Long, List<CustomClientCriteriaRuleBean>> customClientCriteriaRuleBeanMap = QMACacheFactory.getCache().getDbCustomClientCriteriaList();
					inqExtLogger.debug("From Hazelcast customClientCriteriaRuleBeanMap:"+customClientCriteriaRuleBeanMap.size());
					
					if ( !recipientList.isEmpty())
					{
						for (ConversationRecipient xmcInquiryConvRecipients : recipientList)
						{
							matchCustomClientCriteria(subject, fromAddress, toAddressListForCriteria, groupRoutingMap,
									customClientCriteriaRuleBeanMap, xmcInquiryConvRecipients);

						}
					}
				} catch (Exception e) {
					inqExtLogger.error("Exception  in getCustomClientCriteriaMapForToFromEmailSubj ", e);
				}
				
				return groupRoutingMap;

			}
			
			/**
			 * @param customClientCategoryCriteriaMap
			 * @param xmcInquiryVersion
			 */
			private void setCustomClientCriteriaToWorkflow(Map<Long, List<CustomClientCategoryDetails>> customClientCategoryCriteriaMap, Workflow xmcInquiryVersion) {
				try {
					if(INQUIRY_DIRECTION_IN.equals(xmcInquiryVersion.getDirection()) && xmcInquiryVersion.getAssignedGroupId() != null)
					{
						for (Long groupId : customClientCategoryCriteriaMap.keySet())
						{
							executeCustomClientCriteriaRules(customClientCategoryCriteriaMap, xmcInquiryVersion, groupId);
						}
					}
				} catch (Exception e) {
					inqExtLogger.error("Exception in setCustomClientCriteriaToWorkflow with error "+e);
				}
			}
			
			/**
			 * @param subject
			 * @param fromAddress
			 * @param toAddressListForCriteria
			 * @param groupRoutingMap
			 * @param customClientCriteriaRuleBeanMap
			 * @param xmcInquiryConvRecipients
			 */
			private void matchCustomClientCriteria(String subject, String fromAddress, List<String> toAddressListForCriteria,
					Map<Long, List<CustomClientCategoryDetails>> groupRoutingMap,
					Map<Long, List<CustomClientCriteriaRuleBean>> customClientCriteriaRuleBeanMap,
					ConversationRecipient xmcInquiryConvRecipients) {
				Long groupId;
				try {
					if ((xmcInquiryConvRecipients.getToFrom() !=null && !"FROM".equalsIgnoreCase(xmcInquiryConvRecipients.getToFrom())) && xmcInquiryConvRecipients.getGroupId() != null)
					{
						ArrayList<CustomClientCriteriaRuleBean> routingCriteriaList = new ArrayList<>();
						groupId = xmcInquiryConvRecipients.getGroupId();
						// Lookup routingcirteriaId for groupId
						if (customClientCriteriaRuleBeanMap.get(groupId) != null)
						{
							//If group id matches add the record to routing criteria list.
							routingCriteriaList.addAll(customClientCriteriaRuleBeanMap.get(groupId));
						}

						if (!routingCriteriaList.isEmpty())
						{
							for (CustomClientCriteriaRuleBean routingCriteria : routingCriteriaList)
							{
								
								boolean fromRoutingBool = false;
								//boolean fromDisplayNameRoutingBool = false;
								boolean subjectRoutingBool = false;
								boolean toRoutingBool = false;
								if(!StringUtils.isBlank(routingCriteria.getFrom())){
									fromRoutingBool = matchRoutingCriteriaWithOperator(fromAddress, routingCriteria.getFromOperator(), routingCriteria.getFrom());
									//fromDisplayNameRoutingBool = matchRoutingCriteriaWithOperator(fromDisplayName, routingCriteria.getFromOperator(), routingCriteria.getFrom());	
								} else if(!StringUtils.isBlank(routingCriteria.getSubject())) {
									subjectRoutingBool = matchRoutingCriteriaWithOperator(subject, routingCriteria.getSubjectOperator(), routingCriteria.getSubject());
								} else if(!StringUtils.isBlank(routingCriteria.getTo())) {
									toRoutingBool = matchRoutingCriteriaWithToOperator(toAddressListForCriteria, routingCriteria.getToOperator(),routingCriteria.getTo());	
								}
								
								inqExtLogger.info(" subjectRoutingBool= " + subjectRoutingBool +" routingCriteriaSUB="+routingCriteria.getSubjectOperator()+" toRoutingBool= " + toRoutingBool+" routingCriteriaTO="+routingCriteria.getToOperator());
									
								if (fromRoutingBool || subjectRoutingBool || toRoutingBool)
								{
									
									prepareGroupCustomClientCriteriaMap(groupRoutingMap, xmcInquiryConvRecipients, routingCriteria);
								
								}
							}
						}
						else
						{
							groupRoutingMap.put(xmcInquiryConvRecipients.getGroupId(), null);
						}
					}
				} catch (Exception e) {
					inqExtLogger.error("Exception in matchCustomClientCriteria with exception"+ e);
				}
			}
			
			private void prepareGroupCustomClientCriteriaMap(Map<Long, List<CustomClientCategoryDetails>> groupCustomClientCriteriaMap, ConversationRecipient xmcInquiryConvRecipients, CustomClientCriteriaRuleBean customClientCriteriaRule)
			{
				List<CustomClientCategoryDetails> customClientCriteriaDataMap = new ArrayList<CustomClientCategoryDetails>();
				if (groupCustomClientCriteriaMap.keySet().contains(xmcInquiryConvRecipients.getGroupId()))
				{
					customClientCriteriaDataMap.addAll((Collection<? extends CustomClientCategoryDetails>) groupCustomClientCriteriaMap.get(xmcInquiryConvRecipients.getGroupId()));
				}
				
				if (customClientCriteriaRule != null)
				{
					CustomClientCategoryDetails customClientCategoryDetails = new CustomClientCategoryDetails();
					if (!StringUtils.isEmpty(customClientCriteriaRule.getCategoryName()))
					{
						customClientCategoryDetails.setCategoryName(customClientCriteriaRule.getCategoryName());
					}

					if (!StringUtils.isEmpty(customClientCriteriaRule.getColorCode()))
					{
						customClientCategoryDetails.setColorCode(customClientCriteriaRule.getColorCode());
					}
					customClientCriteriaDataMap.add(customClientCategoryDetails);
				}
				groupCustomClientCriteriaMap.put(xmcInquiryConvRecipients.getGroupId(), customClientCriteriaDataMap);
				inqExtLogger.info("prepareGroupCustomClientCriteriaMap ROUTING>>>>"+ groupCustomClientCriteriaMap);
			}
			
			/**
			 * @param customClientCategoryCriteriaMap
			 * @param xmcInquiryVersion
			 * @param groupId
			 */
			private void executeCustomClientCriteriaRules(
					Map<Long, List<CustomClientCategoryDetails>> customClientCategoryCriteriaMap, Workflow xmcInquiryVersion,
					Long groupId) {
				try {
					if (groupId != null	&& groupId.longValue() == xmcInquiryVersion.getAssignedGroupId().longValue() && customClientCategoryCriteriaMap.get(groupId) != null) 
					{
						
							inqExtLogger.info("customClientCategoryCriteriaMap key= " +groupId + " customClientCategoryCriteriaMap value= "+customClientCategoryCriteriaMap.get(groupId));
							
							List<CustomClientCategoryDetails> customClientCategoryDetailsList = new ArrayList<>();
							for(CustomClientCategoryDetails customClientCategoryDetails : customClientCategoryCriteriaMap.get(groupId) ){
								String categoryName = customClientCategoryDetails.getCategoryName();
								String colorCode = customClientCategoryDetails.getColorCode();
								stampCustomClientCriteriaToWorkflow(xmcInquiryVersion, customClientCategoryDetailsList,
										categoryName, colorCode);
							}
							if(!customClientCategoryDetailsList.isEmpty()){
								xmcInquiryVersion.setCustomClientCategory(customClientCategoryDetailsList);
							}
					}
				} catch (Exception e) {
					inqExtLogger.error("Exception in executeCustomClientCriteriaRules with exception "+e);
				}
			}
			
			/**
			 * @param xmcInquiryVersion
			 * @param customClientCategoryDetailsList
			 * @param categoryName
			 * @param colorCode
			 */
			private void stampCustomClientCriteriaToWorkflow(Workflow xmcInquiryVersion,
					List<CustomClientCategoryDetails> customClientCategoryDetailsList, String categoryName, String colorCode) {
				try {
					if (StringUtils.isNotEmpty(categoryName) && StringUtils.isNotEmpty(colorCode))
					{
						inqExtLogger.info("Inside of runCustomClientCategoryRule: categoryName value is:" + categoryName + " and colorcode is : "+colorCode+"  assigned GroupId is: " + xmcInquiryVersion.getAssignedGroupId() );
						CustomClientCategoryDetails customClientCategory = new CustomClientCategoryDetails();
						
						customClientCategory.setCategoryName(categoryName);
						customClientCategory.setColorCode(colorCode);
						customClientCategoryDetailsList.add(customClientCategory);
					}
				} catch (Exception e) {
					inqExtLogger.error("Exception in stampCustomClientCriteriaToWorkflow with exception "+e);
				}
			}
			
			// Method for checking various routing conditions
			private boolean matchRoutingCriteriaWithOperator(String matchCriteriaWithVal,String criteriaOperator,String criteriaValToMatch)
			{
				inqExtLogger.debug("START Match matchRoutingCriteriaWithOperator of inputs:textToMatch= {} criteriaOperator= {} criteriaField= {}", matchCriteriaWithVal, criteriaOperator, criteriaValToMatch);
				
				boolean criteriaMatched = false;
				try
				{
					if (StringUtils.isBlank(criteriaValToMatch))
					{
						criteriaMatched = true;
					}
					else
					{
						if (StringUtils.isBlank(matchCriteriaWithVal))
						{
							criteriaMatched = false;
							return criteriaMatched;
						}
						
						//Case insensitive match
						if (CustomClientCategoryEnum.STARTSWITH.getName().equals(criteriaOperator))
						{
							criteriaMatched = matchCriteriaWithVal.toUpperCase().startsWith(criteriaValToMatch.toUpperCase());
						}
						//Case insensitive match
						else if (CustomClientCategoryEnum.CONTAINS.getName().equals(criteriaOperator))
						{
							criteriaMatched = matchCriteriaWithVal.toUpperCase().contains(criteriaValToMatch.toUpperCase());
							
						}
						else if (CustomClientCategoryEnum.ENDSWITH.getName().equals(criteriaOperator))
						{
							criteriaMatched = matchCriteriaWithVal.toUpperCase().endsWith(criteriaValToMatch.toUpperCase());
						}
						//Case sensitive match
						else if (CustomClientCategoryEnum.EQUALS.getName().equals(criteriaOperator))
						{
							criteriaMatched = matchCriteriaWithVal.equalsIgnoreCase(criteriaValToMatch);
						}

					}
				
				}catch(Exception e)
				{
					inqExtLogger.error("matchRoutingCriteriaWithOperator has issue, plz look", e);
				}
				
				inqExtLogger.debug("END Match matchRoutingCriteriaWithOperator of inputs:textToMatch= {} criteriaOperator= {} criteriaField= {} criteriaMatched= {}", matchCriteriaWithVal, criteriaOperator, criteriaValToMatch, criteriaMatched);
				return criteriaMatched;
			}
			
			// Method for checking various routing TO conditions
			private boolean matchRoutingCriteriaWithToOperator(List<String> matchCriteriaWithVal,String criteriaOperator,String criteriaValToMatch)
			{
				boolean criteriaMatched = false;
				if (StringUtils.isBlank(criteriaValToMatch))
				{
					criteriaMatched = true;
				}
				else
				{
					//Case insensitive match
					if (CustomClientCategoryEnum.STARTSWITH.getName().equals(criteriaOperator))
					{	
						for(String torecipients:matchCriteriaWithVal){
							if(torecipients.toUpperCase().startsWith(criteriaValToMatch.toUpperCase())){
								criteriaMatched=true;
								break;
							}}
					}
					//Case insensitive match
					if (CustomClientCategoryEnum.ENDSWITH.getName().equals(criteriaOperator))
					{	
						for(String torecipients:matchCriteriaWithVal){
							if(torecipients.toUpperCase().endsWith(criteriaValToMatch.toUpperCase())){
								criteriaMatched=true;
								break;
							}}
					}
					//Case insensitive match
					else if (CustomClientCategoryEnum.CONTAINS.getName().equals(criteriaOperator))
					{
						for(String torecipients:matchCriteriaWithVal)
						{
							if(torecipients.toUpperCase().contains(criteriaValToMatch.toUpperCase())){						
								criteriaMatched=true;
								break;
							}
						}
					}
					//Case sensitive match
					else if (CustomClientCategoryEnum.EQUALS.getName().equals(criteriaOperator))
					{
						for(String torecipients:matchCriteriaWithVal){
							if(criteriaValToMatch.equalsIgnoreCase(torecipients)){
								criteriaMatched=true;
								break;
							}}
					}
				}
				inqExtLogger.debug("TO operator match result : inputs:textToMatch= {} criteriaOperator= {} criteriaField= {}", matchCriteriaWithVal, criteriaOperator, criteriaValToMatch);
				return criteriaMatched;
			}

	/** This method will create workflow for nominated groups
	 * @param inquiryIds
	 * @param nomineeInquiryGroupMap
	 * @param nominatingInquiryGroupMap
	 * @param servletRequest 
	 */
	private void createNominationWorkflow(List<Long> inquiryIds, Map<Long, List<Long>> nomineeInquiryGroupMap,
			Map<Long, List<Long>> nominatingInquiryGroupMap, String soeId, String reason, UserActivities userActivity) {
		try {
			QMACache qmaCache = QMACacheFactory.getCache();
			for (Long inqId: inquiryIds)
			{
				Inquiry inquiryObj = inquiryDao.getInquiryById(inqId);
				List<Long> nominatingGroupIds = nominatingInquiryGroupMap.get(inqId);
				List<Long> nominatedGroupIds = nomineeInquiryGroupMap.get(inqId);
				for(Long nominatingGroupId : nominatingGroupIds){
					Workflow nominatingWorkflow =  getNominatingWorkflow(inquiryObj, nominatingGroupId); 
					nominatingWorkflow.setNominatedTo(nominatedGroupIds);
					//set snooze for nominating group
					nominatingWorkflow.setSnoozeAction("Snooze");
					createWorkflowForNominatedGroup(inquiryObj, nominatingWorkflow, nominatedGroupIds, soeId, reason);
					resolveNominatingWorkflowsForApprovalBypass(inquiryObj, nominatingGroupId);
					updateConversationNominatedRecipientsList(inquiryObj, nominatedGroupIds,nominatingGroupIds, nominatingGroupId);
					updateWorkflowAuditForNomination(inquiryObj, nominatingGroupId, soeId, nominatedGroupIds, qmaCache);
					inquiryNominationBypassMap.remove(inquiryObj.getId().toString() + "-" + nominatingGroupId.toString());
				}

				inquiryDao.persist(inquiryObj);
				notifyNominatedUser(inquiryObj, nominatedGroupIds, reason, userActivity);
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#createNominationWorkflow()" ,e);
		}
	}

	private void resolveNominatingWorkflowsForApprovalBypass(Inquiry inquiryObj, Long nominatingGroupId) {
		if (inquiryNominationBypassMap
				.containsKey(inquiryObj.getId().toString() + "-" + nominatingGroupId.toString())) {
			List<Workflow> workflowList = new ArrayList<>();
			try {
				for (Workflow w : inquiryObj.getWorkflows()) {
					if (w.getAssignedGroupId().longValue() == nominatingGroupId.longValue()) {
						w.setStatus(RESOLVED);
						w.setHasNominatedOwnership(true);
					}
					workflowList.add(w);
				}
				inquiryObj.setWorkflows(workflowList);
			} catch (Exception e) {
				GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#getNominatingWorkflow()", e);
			}
		}
	}

	/**
	 * @param inquiryObj
	 * @param nominatedGroupIds
	 * @param soeId
	 */
	private void updateConversationRecipientsList(Inquiry inquiryObj, List<Long> nominatedGroupIds) {
		try {
			Conversation conversation = getLatestConversationForInquiry(inquiryObj);
			
			for(Long nominatedGroupId : nominatedGroupIds){
				ConversationRecipient existingRecipient = getExistingRecipientFromConversationRecipientsList(conversation, nominatedGroupId);
				if(null == existingRecipient){
					addNominatedGroupToConversationRecipient(conversation, nominatedGroupId);
				}
			}
			inquiryDao.persist(conversation);
			
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateConversationRecipientsList()" ,e);
		}
		
	}
	
	/**
	 * @param inquiryObj
	 * @param nominatedGroupIds
	 * @param soeId
	 */
	private void updateConversationNominatedRecipientsList(Inquiry inquiryObj, List<Long> nominatedGroupIds,
			List<Long> nominatingGroupIds, Long nominatingGroupId) {
		try {
			List<Conversation> convList = getAllConversationForInquiryGroup(inquiryObj,nominatingGroupIds,false);
			if( null != convList && !convList.isEmpty()) {
				for(Conversation conversation : convList){
					updateNomiatedRecipient(nominatedGroupIds, conversation, nominatingGroupIds, inquiryObj, nominatingGroupId);
				}
			} else {
				inqExtLogger.warn("No conversation found for nominatingGroupIds : {} for inquiry : {}", nominatingGroupIds, inquiryObj.getId());
			}
			
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateConversationRecipientsList()" ,e);
		}
		
	}

	/**
	 * This method updates nominated recipient in the converation
	 * @param nominatedGroupIds
	 * @param conversation
	 * @throws CommunicatorException
	 */
	private void updateNomiatedRecipient(List<Long> nominatedGroupIds, Conversation conversation, List<Long> nominatingGroupIds, Inquiry inquiryObj, Long nominatingGroupId) throws CommunicatorException {
		for(Long nominatedGroupId : nominatedGroupIds){
			ConversationRecipient existingRecipient = getExistingRecipientFromConversationNominatedRecipientsList(conversation, nominatedGroupId);
			if(null == existingRecipient){
				addNominatedGroupToConversationRecipient(conversation, nominatedGroupId);
			} else {
				inqExtLogger.info("Existing nominated recipient found for groupId: {} for conversation : {}", nominatedGroupId, conversation.getId());
			}
			
			if (inquiryNominationBypassMap
					.containsKey(inquiryObj.getId().toString() + "-" + nominatingGroupId.toString())
					&& inquiryNominationBypassMap
							.get(inquiryObj.getId().toString() + "-" + nominatingGroupId.toString())
							.equals(nominatedGroupId)) {
				updateConversationOnNominationAccept(nominatedGroupId, nominatingGroupIds, conversation);
			}
			inquiryDao.persist(conversation);
		}
	}

	/**
	 * @param inquiryObj
	 * @return
	 */
	private Conversation getLatestConversationForInquiry(Inquiry inquiryObj) {
		Query<Conversation> query;
		Conversation conversation = null;
		try {
			query = mongoDatastore.createQuery(Conversation.class);
			query.criteria("inquiryId").equal(inquiryObj.getId());
			query.order("-modDate");
			conversation = query.first();
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#getLatestConversationForInquiry()" ,e);
		}
		return conversation;
	}
	
	/**
	 * This method returns all the conversations qualifying provided group.
	 * @param inquiryObj
	 * @param groupIds
	 * @return List<Conversation>
	 */
	private List<Conversation> getAllConversationForInquiryGroup(Inquiry inquiryObj, List<Long> groupIds, boolean lookupInNominatedRecipient) {
		Query<Conversation> query;
		List<Conversation> convList = null;
		try {
			query = mongoDatastore.createQuery(Conversation.class);
			query.criteria("inquiryId").equal(inquiryObj.getId());
			if(lookupInNominatedRecipient){
				query.criteria("nominatedRecipients.groupId").in(groupIds);
			} else {
				query.criteria("recipients.groupId").in(groupIds);
			}
			query.order("-modDate");
			convList = query.asList();
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#getAllConversationForInquiryGroup()" ,e);
		}
		return convList;
	}

	/**
	 * @param conversation 
	 * @param nominatedGroupId
	 */
	private void addNominatedGroupToConversationRecipient(Conversation conversation, Long nominatedGroupId) {
		try {
			ConversationRecipient nominatedRecipient = new ConversationRecipient();
			Group group = QMACacheFactory.getCache().getAllGroupsMap().get(nominatedGroupId);
			if(null != group){
				nominatedRecipient.setGroupId(nominatedGroupId);
				nominatedRecipient.setDisplayName(group.getGroupName());
				nominatedRecipient.setEmailAddr(group.getGroupEmail());
				nominatedRecipient.setToFrom("TO");
				List<ConversationRecipient> dbNominatedRecipientList = conversation.getNominatedRecipients();
				if (dbNominatedRecipientList == null)
				{
					dbNominatedRecipientList = new ArrayList<>();
				}
				dbNominatedRecipientList.add(nominatedRecipient);
				conversation.setNominatedRecipients(dbNominatedRecipientList);
				
				//inquiryDao.persist(conversation);
			} else {
				inqExtLogger.info("invalid nominated group while adding recipient");
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#addNominatedGroupToConversationRecipient()" ,e);
		}
	}
	
	/**
	 * @param conversation
	 * @param nominatedGroupId
	 * @return
	 */
	private ConversationRecipient getExistingRecipientFromConversationNominatedRecipientsList(Conversation conversation, Long nominatedGroupId) {
		ConversationRecipient existingRecipient = null;
		try {
			if(null == conversation || null == conversation.getNominatedRecipients() || conversation.getNominatedRecipients().isEmpty()){
				return existingRecipient;
			}
			for(ConversationRecipient recipient : conversation.getNominatedRecipients()){
				if(null != recipient && null != recipient.getGroupId() && recipient.getGroupId().longValue() == nominatedGroupId){
					existingRecipient = recipient;
					break;
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#getExistingRecipientFromConversationRecipientsList()" ,e);
		}
		return existingRecipient;
	}
	
	/**
	 * @param conversation
	 * @param nominatedGroupId
	 * @return
	 */
	private ConversationRecipient getExistingRecipientFromConversationRecipientsList(Conversation conversation, Long nominatedGroupId) {
		ConversationRecipient existingRecipient = null;
		try {
			for(ConversationRecipient recipient : conversation.getRecipients()){
				if(null != recipient && null != recipient.getGroupId() && recipient.getGroupId().longValue() == nominatedGroupId 
						&& ("TO".equalsIgnoreCase(recipient.getToFrom()) || "CC".equalsIgnoreCase(recipient.getToFrom()))){
					existingRecipient = recipient;
					break;
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#getExistingRecipientFromConversationRecipientsList()" ,e);
		}
		return existingRecipient;
	}
	
	

	/** This method will update workflow audit for naminating groupids action
	 * @param inquiryObj
	 */
	private void updateWorkflowAuditForNomination(Inquiry inquiryObj, Long nominatingGroupId, String soeId, List<Long> nominatedGroupIds, QMACache qmaCache) {
		
		try {
			String nominatingGroupName = qmaCache.getGroupIdToNameMap().get(nominatingGroupId);
			List<String> nominatedGroupNames = nominatedGroupIds.stream().map(qmaCache.getGroupIdToNameMap()::get).collect(Collectors.toList());
			WorkflowAudit workflowAudit = new WorkflowAudit();
			workflowAudit.setAction(OWNERSHIP_NOMINATION);
			workflowAudit.setActionDetails("Ownership nominated by GroupName: "+ nominatingGroupName + " to groupName(s): "+nominatedGroupNames.toString());
			workflowAudit.setGroupId(nominatingGroupId);
			updateWorkflowAuditOnAction(inquiryObj, nominatingGroupId, soeId, workflowAudit);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateWorkflowAuditForNomination()" ,e);
		}
		
	}

	/**
	 * @param inquiryObj
	 * @param nominatingGroupId
	 * @param soeId
	 * @param workflowAudit
	 * @param userName
	 */
	private void updateWorkflowAuditOnAction(Inquiry inquiryObj, Long nominatingGroupId, String soeId,
			WorkflowAudit workflowAudit) {
		try {
			if (null != nominatingGroupId)
			{
				workflowAudit.setGroupName(QMACacheFactory.getCache().getGroupIdToNameMap().get(nominatingGroupId));
			}
			User user = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase());
			String userName = "";
			if (null != user)
			{
				userName = user.getName();
			}
			workflowAudit.setModDate(new Date());
			workflowAudit.setModBy(userName);
			workflowAudit.setUserId(userName);
			
			List<WorkflowAudit> dbWorkflowAuditList = inquiryObj.getWorkflowAudit();
			if (dbWorkflowAuditList == null)
			{
				dbWorkflowAuditList = new ArrayList<>();
			}
			dbWorkflowAuditList.add(workflowAudit);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateWorkflowAuditOnAction()" ,e);
		}
	}

	/** This method will create new nominated workflow
	 * @param inquiryObj
	 * @param workflow
	 * @param groupIds
	 */
	private void createWorkflowForNominatedGroup(Inquiry inquiryObj, Workflow nominatingWorkflow, List<Long> nominatedGroupIds, String soeId, String nominatingReason) {
		
		try {
			ObjectMapper mapper = new ObjectMapper();
			Date crtDate = new Date();
			for(Long nominatedGroupId : nominatedGroupIds){

				createAndUpdateNominatedWorkflow(inquiryObj, nominatingWorkflow, soeId, mapper, crtDate,
						nominatedGroupId, nominatingReason);
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#createWorkflowForNominatedGroup()" ,e);
		}
		
	}

	/**
	 * @param inquiryObj
	 * @param nominatingWorkflow
	 * @param soeId
	 * @param mapper
	 * @param crtDate
	 * @param nominatedGroupId
	 */
	private void createAndUpdateNominatedWorkflow(Inquiry inquiryObj, Workflow nominatingWorkflow, String soeId,
			ObjectMapper mapper, Date crtDate, Long nominatedGroupId, String nominatingReason) {
		try {
			Workflow nominatedWorkflow = getNominatedWorkflow(inquiryObj, nominatedGroupId);
			if(null != nominatedWorkflow){
				updateExistingNominatedWorkflow(nominatingWorkflow, soeId, crtDate, nominatedWorkflow);
			} else {
				Workflow workflow = createNominatedWorkflow(nominatingWorkflow, soeId, mapper, crtDate,
						nominatedGroupId, nominatingReason, inquiryObj);
				inquiryObj.getWorkflows().add(workflow);
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#createAndUpdateNominatedWorkflow()" ,e);
		}
	}

	private Workflow createNominatedWorkflow(Workflow nominatingWorkflow, String soeId, ObjectMapper mapper,
			Date crtDate, Long nominatedGroupId, String nominatingReason, Inquiry inquiryObj){
		Workflow workflow = null;
		try {
			String json = mapper.writeValueAsString(nominatingWorkflow);
			workflow = mapper.readValue(json, Workflow.class);
			workflow.setAssignedGroupId(nominatedGroupId);
			if (null != nominatedGroupId)
			{
				workflow.setAssignedGroupName(QMACacheFactory.getCache().getGroupIdToNameMap().get(nominatedGroupId));
				
			}
			List<Long> list = new ArrayList<>();
			list.add(nominatingWorkflow.getAssignedGroupId());
			workflow.setNominatedBy(list);
			workflow.setAssignedUserId("");
			workflow.setAssignedUserName("");
			
			/*workflow.setDirection(NOMINATE_OWNERSHIP);
			workflow.setWorkflowStatus(PENDING_NOMINATE_OWNERSHIP);
			workflow.setHasNominatedOwnership(true);*/
			
			
			// C170665-4633 Start
			Long nominatingGroupId = nominatingWorkflow.getAssignedGroupId();
			User user = QMACacheFactory.getCache().getUserInfoMap().get(soeId.toUpperCase());
			if (user == null) {
				user = userDao.getUserById(soeId);
			}
			Set<Long> userGroupsList = userDao.getUserGroupsList(user);

			boolean nominating = false;
			boolean nominated = false;

			if (CollectionUtils.isNotEmpty(userGroupsList) && userGroupsList.contains(nominatingGroupId) && userGroupsList.contains(nominatedGroupId)) {
				for (GroupRole groupRole : user.getGroupRoles()) {
					if (groupRole.getGroupId().equals(nominatingGroupId)
							&& (groupRole.getRole().equals(PEER_REVIEWER) || groupRole.getRole().equals(ADMIN))) {
						nominating = true;
					}
					if (groupRole.getGroupId().equals(nominatedGroupId)
							&& (groupRole.getRole().equals(PEER_REVIEWER) || groupRole.getRole().equals(ADMIN))) {
						nominated = true;
					}
					if (nominating && nominated) {
						break;
					}
				}
			}

			if (nominating && nominated) {
				workflow.setStatus(INQUIRY_STATUS_OPEN);
				workflow.setWorkflowStatus(ACCEPTED_NOMINATE_OWNERSHIP);
				workflow.setDirection(INQUIRY_DIRECTION_IN);
				workflow.setHasNominatedOwnership(false);

				inquiryNominationBypassMap.put(inquiryObj.getId().toString() + "-" + nominatingGroupId.toString(), nominatedGroupId);
			} else {
				workflow.setWorkflowStatus(PENDING_NOMINATE_OWNERSHIP);
				workflow.setDirection(NOMINATE_OWNERSHIP);
				workflow.setHasNominatedOwnership(true);
			}

			// C170665-4633 End
			
			workflow.setNominatingReason(nominatingReason);
			workflow.setOriginDate(crtDate);
			workflow.setCrtDate(crtDate);
			workflow.setModDate(crtDate);
			workflow.setCrtBy(soeId);
			workflow.setModBy(soeId);
			workflow.setCustomClientCategory(null);
			workflow.setSnoozeAction(null);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#createNominatedWorkflow()" ,e);
		} 
		return workflow;
	}

	private void updateExistingNominatedWorkflow(Workflow nominatingWorkflow, String soeId, Date crtDate,
			Workflow nominatedWorkflow) {
		try {
			nominatedWorkflow.setModDate(crtDate);
			nominatedWorkflow.setModBy(soeId);
			List<Long> list = nominatedWorkflow.getNominatedBy();
			if(list != null && !list.isEmpty()){
				list.add(nominatingWorkflow.getAssignedGroupId());
			} else {
				list = new ArrayList<>();
			}
			nominatedWorkflow.setNominatedBy(list);
			nominatedWorkflow.setSnoozeAction(null);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateExistingNominatedWorkflow()" ,e);
		}
	}
	
	/**
	 * @param inquiryObj
	 * @param nominatedGroupId
	 * @return
	 */
	private Workflow getNominatedWorkflow(Inquiry inquiryObj, Long nominatedGroupId) {
		Workflow nominatedWorkflow = null;
		try {
			for(Workflow w : inquiryObj.getWorkflows()){
				if(w.getAssignedGroupId().longValue() == nominatedGroupId.longValue() && NOMINATE_OWNERSHIP.equals(w.getDirection())){
					nominatedWorkflow = w;
					break;
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#getNominatedWorkflowIfExist()" ,e);
		}
		return nominatedWorkflow;
		
	}

	
	/**
	 * @param inquiryObj
	 * @param nominatedGroupId
	 * @return
	 */
	private Workflow getInWorkflow(Inquiry inquiryObj, Long nominatedGroupId) {
		Workflow inWorkflow = null;
		try {
			for(Workflow w : inquiryObj.getWorkflows()){
				if(w.getAssignedGroupId().longValue() == nominatedGroupId.longValue() && INQUIRY_DIRECTION_IN.equals(w.getDirection())){
					inWorkflow = w;
					break;
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#isInWorkflowExist()" ,e);
		}
		return inWorkflow;
		
	}

	/**This method will notify nominated users for inquiries 
	 * @param inquiryObj
	 * @param servletRequest 
	 * @param soeId
	 * @param nominatedGroupId
	 * @throws CommunicatorException
	 */
	private void notifyNominatedUser(Inquiry inquiryObj, List<Long> nominatedGroupIds, String reason, UserActivities userActivity) {
		try {
			QMACache qmaCache =  QMACacheFactory.getCache();
			for(Long nominatedGroupId : nominatedGroupIds){
				List<String> userList = qmaCache.getGroupIdToUserListMap().get(nominatedGroupId);
				
				for(String userId : userList){
					notifyNominatedActiveUser(inquiryObj, reason, userActivity, userId);
				}
			}
			if (Objects.nonNull(inquiryObj)) {
				ConversationCache.getInstance().removeEntriesWithKeySetIteration(inquiryObj.getId());
			}
			
		} catch (Exception e) {
			 GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#notifyNominatedUser()" ,e);
		}
	}

	private void notifyNominatedActiveUser(Inquiry inquiryObj, String reason, UserActivities userActivity,
			String userId) {
		userActivity.setResponseTimeInMills(System.currentTimeMillis());
		try {
			if(StringUtils.isNotEmpty(userId)){
				User user = QMACacheFactory.getCache().getUserInfoMap().get(userId.toUpperCase());
				if(null != user && user.getActive()){
					UserNotificationDAO.getInstance().addUserNotification(inquiryObj.getId(),reason,userId, APPROVALS, userActivity);
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#notifyNominatedActiveUser()" ,e);
		}
	}

	/** This method will copy original workflow and create new workflow for nominated group
	 * @param inquiryObj
	 * @param groupId
	 */
	private Workflow getNominatingWorkflow(Inquiry inquiryObj, Long groupId) {
		List<Workflow> workflowList = new ArrayList<>();
		Workflow workflow = new Workflow();
		try {
			for(Workflow w : inquiryObj.getWorkflows()){
				if(w.getAssignedGroupId().longValue() == groupId.longValue() && INQUIRY_DIRECTION_IN.equals(w.getDirection())){
					workflow = w;
				}
				workflowList.add(w);
			}
			inquiryObj.setWorkflows(workflowList);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#getNominatingWorkflow()" ,e);
		}
		return workflow;
		
	}
	
	/** This method will update nominating and nominated workflow on Approve/Reject action
	 * @param soeId
	 * @param inqObj
	 * @param groupId
	 * @param action
	 * @param servletRequest 
	 */
	public void updateNominatedOwnershipWorkflow(String soeId, Inquiry inqObj, Long groupId, String action, String nominationRejectionReason, UserActivities userActivity, QMACache cache) {
		
		try {
			if (ACTION_REJECT.equalsIgnoreCase(action)){
				rejectNomination(soeId, inqObj, groupId, nominationRejectionReason, userActivity, cache);
			} else if (ACTION_ACCEPT.equalsIgnoreCase(action)) {
				acceptNomination(soeId, inqObj, groupId, userActivity, cache);
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateNominatedOwnershipWorkflow()" ,e);
		}
		
	}
	//QMA-471 Starts
	public void updateNominatedOwnershipWorkflow(Inquiry inqObj, Long groupId, String action, String nominationRejectionReason) {
		try {
			Workflow nominatedWorkflow = null;
			for(Workflow w : inqObj.getWorkflows()){
				if(w.getAssignedGroupId().longValue() == groupId.longValue() && w.isNominatedOwnerChanged()){
					nominatedWorkflow = w;
				}
			}
			if (ACTION_REJECT.equalsIgnoreCase(action) && null != nominatedWorkflow){
					nominatedWorkflow.setNominationRejectionReason(nominationRejectionReason);
					nominatedWorkflow.setNominatedOwnerChanged(false);

			} else if (ACTION_ACCEPT.equalsIgnoreCase(action) && null != nominatedWorkflow) {
					nominatedWorkflow.setStatus(RESOLVED);
					nominatedWorkflow.setNominatedOwnerChanged(false);
					nominatedWorkflow.setModDate(new Date());
			}
			inquiryDao.persist(inqObj);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateNominatedOwnershipWorkflow()" ,e);
		}
	}
	//QMA-471 Ends

	/** This method will accept nomination
	 * @param inqObj
	 * @param groupId
	 * @param servletRequest 
	 */
	private void acceptNomination(String soeId, Inquiry inqObj, Long groupId, UserActivities userActivity, QMACache cache) {
		try {
			Workflow acceptingWorkflow;
			List<Long> nominatedByGroupIds = null;
			//check if workflow already present then update existing workflow and remove nominated workflow
			Workflow existingInWorkflow = getInWorkflow(inqObj, groupId);
			acceptingWorkflow = updateAcceptingWorkflow(soeId, inqObj, groupId);
			
			if(null != existingInWorkflow && null != acceptingWorkflow){
				existingInWorkflow.setStatus(INQUIRY_STATUS_OPEN);
				existingInWorkflow.setWorkflowStatus(ACCEPTED_NOMINATE_OWNERSHIP);
				existingInWorkflow.setDirection(INQUIRY_DIRECTION_IN);
				existingInWorkflow.setHasNominatedOwnership(false);
				existingInWorkflow.setModBy(soeId);
				existingInWorkflow.setModDate(new Date());
				existingInWorkflow.setOwnershipAcceptedTime(new Date()); // C153176-5977 | Populate with current time when nomination is accepted.
				if(null != acceptingWorkflow.getNominatedTo()){
					existingInWorkflow.setNominatedTo(acceptingWorkflow.getNominatedTo());
				}
				removeRulesFlagAutoAssignment(existingInWorkflow, soeId);
				inqObj.getWorkflows().remove(acceptingWorkflow);
			}
			
			if(acceptingWorkflow != null ){
				nominatedByGroupIds = acceptingWorkflow.getNominatedBy();
			}
			if(nominatedByGroupIds != null && !nominatedByGroupIds.isEmpty()){
				updateNominatedRecipientOnAccept(inqObj, groupId, nominatedByGroupIds);
				for(Long nominatedByGroupId : nominatedByGroupIds){
					updateNominatingWorkflowOnAccept(inqObj, nominatedByGroupId, groupId, soeId);
					updateNominateToOnAction(nominatedByGroupId, groupId, inqObj);	
				}
				
			}
			updateWorkflowAuditOnAcceptNomination(inqObj, groupId, soeId, cache);
			
			// Check for all workflow AutoassignMent and return flag to set at inq levell and conversation level
			if(null != existingInWorkflow && null != acceptingWorkflow){
				boolean autoAssigned = inquiryDao.removeAutoAssignmentNonInquiryFlag(inqObj.getWorkflows(), groupId, soeId, inqObj.getId());
				if(!autoAssigned) {
					inqObj.setAutoAssignmentAvailable(false);
				}
				//Revoke from AutoAssignInquiry collection
				inquiryDao.revokeAutoAssign(inqObj.getId());
			}
			updatingInboxItems(inqObj, groupId);
			inqObj.setModDate(new Date());
			inquiryDao.persist(inqObj);
			//inquiryDao.persist(conversation);
			//add entry to inquiryClientPriority on accept
			stampInquiryClientPriority(inqObj, groupId);
			
			List<Long> nominatedGroupIds = new ArrayList<>();
			nominatedGroupIds.add(groupId);
			nominatedGroupIds.addAll(nominatedByGroupIds);
			String groupName = "";
			if(groupId != null){
				groupName = QMACacheFactory.getCache().getGroupIdToNameMap().get(groupId);
			}
			String reason = groupName +" has accepted the nomination";
			notifyNominatedUser(inqObj, nominatedGroupIds, reason, userActivity);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#acceptNomination()" ,e);
		}
		
	}

	//QMA-471 Starts
	private void updatingInboxItems(Inquiry inquiryObj, Long nominatedGroupId) {
		try {
			for(Workflow w : inquiryObj.getWorkflows()){
				if(w.getStatus().equals(INQUIRY_STATUS_OPEN) && INQUIRY_DIRECTION_IN.equals(w.getDirection()) && w.getWorkflowStatus() == null){
					w.setNominatedOwnerChanged(true);
					List<Long> nominatedById = new ArrayList<>();
					nominatedById.add(nominatedGroupId);
					w.setNominatedBy(nominatedById);
				}
			}

		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#getNominatedWorkflowIfExist()" ,e);
		}
	}
	//QMA-471 Ends
	
	/**
	 * @param inqObj
	 * @param groupId
	 * @param nominatedByGroupId
	 */
	private void updateNominatedRecipientOnAccept(Inquiry inqObj, Long nominatedGroupId, List<Long> nominatingGroupId) {
		try {
			List<Conversation> convList = getAllConversationForInquiryGroup(inqObj,nominatingGroupId,false);
			if(null != convList && !convList.isEmpty()) {
				for(Conversation conversation : convList){
					updateConversationOnNominationAccept(nominatedGroupId, nominatingGroupId, conversation);
					inquiryDao.persist(conversation);
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateNominatedRecipientOnAccept()" ,e);
		}
	}

	/**
	 * This method updates all qualifies conversations on nomination accept
	 * @param nominatedGroupId
	 * @param conversation
	 * @throws CommunicatorException
	 */
	private void updateConversationOnNominationAccept(Long nominatedGroupId, List<Long> nominatingGroupId,Conversation conversation) throws CommunicatorException{
		ConversationRecipient existingNominatedRecipientToBeUpdated = getExistingRecipientFromConversationNominatedRecipientsList(conversation,nominatedGroupId);
		if( null != existingNominatedRecipientToBeUpdated ){
			ConversationRecipient existingNominatedRecipientInToCCList =  getExistingRecipientFromConversationRecipientsList(conversation,nominatedGroupId);
			if( null == existingNominatedRecipientInToCCList ){
				conversation.getRecipients().add(existingNominatedRecipientToBeUpdated);
			} else {
				inqExtLogger.info("Nominated recipient group :{} already exists in the conversation : {}", nominatedGroupId, conversation.getId());
			}
			conversation.getNominatedRecipients().remove(existingNominatedRecipientToBeUpdated);
			updatedNominatedRecipient(conversation, nominatingGroupId);
			//inquiryDao.persist(conversation);
		 } else {
			 inqExtLogger.warn("Could not find existing 'nominatedRecipient' for groupId : {} for conversation : {}", nominatedGroupId, conversation.getId());
		 }
	}
	
	/**
	 * This method updates 
	 * @param conversation
	 * @param nominatedGroupId
	 */
	private void updatedNominatedRecipient(Conversation conversation ,List<Long> nominatingGroupId) {
		Long nominatingGrpId = null != nominatingGroupId && !nominatingGroupId.isEmpty() ? nominatingGroupId.get(0) : null ;
		if(null != nominatingGrpId) {
			ConversationRecipient nominatingRecipient = getExistingRecipientFromConversationRecipientsList(conversation,nominatingGrpId);
			if (nominatingRecipient != null) {
				conversation.getNominatedRecipients().add(nominatingRecipient);
				conversation.getRecipients().remove(nominatingRecipient);
			} else {
				inqExtLogger.warn("Nominating recipient not found for groupId : {} and conversation : {} ", nominatingGrpId, conversation.getId());
			}
		}
	}

	/** This method will update workflow audit on Accept
	 * @param inquiryObj
	 */
	private void updateWorkflowAuditOnAcceptNomination(Inquiry inquiryObj, Long groupId, String soeId, QMACache cache) {
		String groupName = "";
		try {
			if(groupId != null){
				groupName = cache.getGroupIdToNameMap().get(groupId);
			}
			WorkflowAudit workflowAudit = new WorkflowAudit();
			workflowAudit.setAction(ACCEPT_NOMINATION);
			workflowAudit.setActionDetails("Ownership nomination accepted by GroupName: "+ groupName);
			workflowAudit.setGroupId(groupId);
			updateWorkflowAuditOnAction(inquiryObj, groupId, soeId, workflowAudit);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateWorkflowAuditOnAcceptNomination()" ,e);
		}
		
	}
	
	/**
	 * @param soeId
	 * @param inqObj
	 * @param groupId
	 * @param nominatedByGroupId
	 * @return
	 */
	private Workflow updateAcceptingWorkflow(String soeId, Inquiry inqObj, Long groupId) {
		
		Workflow acceptingWorkflow = null;
		
		try {
			Workflow nominatedWorkflow = getNominatedWorkflow(inqObj, groupId);
			if(null != nominatedWorkflow){
				nominatedWorkflow.setStatus(INQUIRY_STATUS_OPEN);
				nominatedWorkflow.setWorkflowStatus(ACCEPTED_NOMINATE_OWNERSHIP);
				nominatedWorkflow.setDirection(INQUIRY_DIRECTION_IN);
				nominatedWorkflow.setHasNominatedOwnership(false);
				nominatedWorkflow.setModBy(soeId);
				nominatedWorkflow.setModDate(new Date());
				nominatedWorkflow.setOwnershipAcceptedTime(new Date()); // C153176-5977 | Populate with current time when nomination is accepted.
				removeNominatedTo(groupId, nominatedWorkflow);
				acceptingWorkflow = nominatedWorkflow;
			}
			
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateAcceptingWorkflow()" ,e);
		}
		return acceptingWorkflow;
	}
	/**
	 * This method will remove non-inquiries flag from workflow when it get nominated and ruleType is autoAssignmentRule
	 * @param nominatedWorkflow
	 * @param soeId 
	 */
	private void removeRulesFlagAutoAssignment(Workflow nominatedWorkflow, String soeId) {
		try{
			if(null != nominatedWorkflow.getRulesFlag() && null != nominatedWorkflow.getRulesFlag().getRuleType()
					&& AUTO_ASSIGNMENT_RULE.equalsIgnoreCase(nominatedWorkflow.getRulesFlag().getRuleType())) {
				nominatedWorkflow.setRulesFlag(null);
				nominatedWorkflow.setAutoAssigned(NLPConstants.REVOKED);
				nominatedWorkflow.setAutoAssignedAction(NLPConstants.REVOKE_MANUAL+" "+soeId);
			}
		}catch(Exception ex) {
			inqExtLogger.error("Exception while removing rulesFlag:", ex);
		}
	}
	/**
	 * @param inqObj
	 * @param nominatedByGroupId
	 */
	private void updateNominatingWorkflowOnAccept(Inquiry inqObj, Long nominatedByGroupId, Long groupId, String soeId) {
		try {
			for(Workflow w : inqObj.getWorkflows()){
				if(w.getAssignedGroupId().longValue() == nominatedByGroupId.longValue()){
					
					w.setStatus(RESOLVED);
					w.setHasNominatedOwnership(true);
					w.setModBy(soeId);
					w.setModDate(new Date());
					w.setSnoozeAction(null);
					removeNominatedTo(groupId, w);
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateNominatingWorkflowOnAccept()" ,e);
		}
	}

	/**
	 * @param groupId
	 * @param w
	 */
	private void removeNominatedTo(Long groupId, Workflow w) {
		try {
			List<Long> nominatedTo = w.getNominatedTo();
			if(nominatedTo != null && !nominatedTo.isEmpty()){
				nominatedTo.remove(groupId);
				w.setNominatedTo(nominatedTo);
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#removeNominatedTo()" ,e);
		}
	}

	/** This method will reject nomination
	 * @param inqObj
	 * @param groupId
	 * @param servletRequest 
	 */
	private void rejectNomination(String soeId, Inquiry inqObj, Long groupId, String nominationRejectionReason, UserActivities userActivity, QMACache cache) {
		
		try {
			Workflow rejectingWorkflow;
			rejectingWorkflow = getRejectingWorkflow(soeId, inqObj, groupId); //updateRejectingWorkflow(soeId, inqObj, groupId);
			List<Long> nominatedByGroupIds = null;
			if(rejectingWorkflow != null){
				nominatedByGroupIds = rejectingWorkflow.getNominatedBy();
			}
			if(nominatedByGroupIds != null && !nominatedByGroupIds.isEmpty()){
				for(Long nominatedByGroupId : nominatedByGroupIds){
					updateNominatingWorkflowOnReject(inqObj, nominatedByGroupId, groupId, nominationRejectionReason);
					updateNominateToOnAction(nominatedByGroupId, groupId, inqObj);
				}
			}
			/**/
			inqObj.getWorkflows().remove(rejectingWorkflow);
			updateWorkflowAuditOnDeleteWorkflow(inqObj, groupId, soeId, cache);
			/**/
			//updateWorkflowAuditOnRejectNomination(inqObj, groupId, soeId);
			removeNominatedRecipientFromConversation(inqObj, groupId);
			inqObj.setModDate(new Date());
			inquiryDao.persist(inqObj);

			List<Long> nominatedGroupIds = new ArrayList<>();
			nominatedGroupIds.add(groupId);
			nominatedGroupIds.addAll(nominatedByGroupIds);

			String groupName = "";
			if(groupId != null){
				groupName = QMACacheFactory.getCache().getGroupIdToNameMap().get(groupId);
			}
			String reason = groupName +" has rejected the nomination";
			notifyNominatedUser(inqObj, nominatedGroupIds, reason, userActivity);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#rejectNomination()" ,e);
		}
	}
	
	/**
	 * @param inqObj
	 * @param groupId
	 * @param soeId
	 */
	private void removeNominatedRecipientFromConversation(Inquiry inqObj, Long groupId) {
		 try {
			List<Long> groupIDs = new ArrayList<>();
			groupIDs.add(groupId);
			List<Conversation> convList = getAllConversationForInquiryGroup(inqObj,groupIDs,true);
			if(null != convList && !convList.isEmpty()){
				for(Conversation conversation : convList){
					removeNominatedRecipient(groupId, conversation);
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#removeRecipientFromConversation()" ,e);
		}
		 
	}

	/**
	 * This method removes nominated recipients from the conversation on reject.
	 * @param groupId
	 * @param conversation
	 * @throws CommunicatorException
	 */
	private void removeNominatedRecipient(Long groupId, Conversation conversation) throws CommunicatorException {
		ConversationRecipient recipientToBeRemoved = getExistingRecipientFromConversationNominatedRecipientsList(conversation,groupId);
		if(null != recipientToBeRemoved){
			conversation.getNominatedRecipients().remove(recipientToBeRemoved); 
			inquiryDao.persist(conversation);
		}
	}

	/** This method will update nominateTo list on accept/reject action
	 * @param nominatedByGroupId
	 * @param groupId
	 * @param inqObj
	 */
	private void updateNominateToOnAction(Long nominatedByGroupId, Long groupId, Inquiry inqObj) {

		try {
			for (Workflow w : inqObj.getWorkflows()){
				if(w.getNominatedBy() != null && w.getNominatedBy().contains(nominatedByGroupId) /*&& NOMINATE_OWNERSHIP.equals(w.getDirection())*/){
					removeNominatedTo(groupId, w);
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateNominateToOnAction()" ,e);
		}
		
	}

	/** This method will update workflow audit on rejection
	 * @param inquiryObj
	 */
	private void updateWorkflowAuditOnRejectNomination(Inquiry inquiryObj, Long groupId, String soeId) {
		
		try {
			WorkflowAudit workflowAudit = new WorkflowAudit();
			workflowAudit.setAction(REJECT_NOMINATION);
			workflowAudit.setActionDetails("Ownership nomination rejected by GroupId: "+ groupId);
			workflowAudit.setGroupId(groupId);
			updateWorkflowAuditOnAction(inquiryObj, groupId, soeId, workflowAudit);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateWorkflowAuditOnRejectNomination()" ,e);
		}
		
	}
	
	/** This method will update workflow audit on deletion
	 * @param inquiryObj
	 */
	private void updateWorkflowAuditOnDeleteWorkflow(Inquiry inquiryObj, Long groupId, String soeId, QMACache cache) {
		String groupName = "";
		try {
			if(groupId != null){
				groupName = cache.getGroupIdToNameMap().get(groupId);
			}
			WorkflowAudit workflowAudit = new WorkflowAudit();
			workflowAudit.setAction(REJECT_NOMINATION);
			workflowAudit.setActionDetails("Ownership nomination rejected by GroupName: "+ groupName + " and rejecting workflow gets deleted");
			workflowAudit.setGroupId(groupId);
			updateWorkflowAuditOnAction(inquiryObj, groupId, soeId, workflowAudit);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateWorkflowAuditOnRejectNomination()" ,e);
		}
		
	}

	/**
	 * @param inqObj
	 * @param nominatedByGroupId
	 */
	private void updateNominatingWorkflowOnReject(Inquiry inqObj, Long nominatedByGroupId, Long groupId, String nominationRejectionReason) {
		try {
			for(Workflow w : inqObj.getWorkflows()){
				if(w.getAssignedGroupId().longValue() == nominatedByGroupId.longValue() && INQUIRY_DIRECTION_IN.equalsIgnoreCase(w.getDirection())){
					w.setNominationRejectionReason(nominationRejectionReason);
					w.setSnoozeAction(null);
					w.setModDate(new Date());
					removeNominatedTo(groupId, w);
					break;
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateRejectingWorkflow()" ,e);
		}
	}

	/**
	 * @param soeId
	 * @param inqObj
	 * @param groupId
	 * @param nominatedByGroupId
	 * @return
	 */
	private Workflow updateRejectingWorkflow(String soeId, Inquiry inqObj, Long groupId) {
		Workflow rejectingWorkflow = null;
		
		try {
			for(Workflow w : inqObj.getWorkflows()){
				if(w.getAssignedGroupId().longValue() == groupId.longValue() && NOMINATE_OWNERSHIP.equalsIgnoreCase(w.getDirection())){
					w.setStatus(RESOLVED);
					w.setWorkflowStatus(REJECTED_NOMINATE_OWNERSHIP);
					w.setDirection(INQUIRY_DIRECTION_IN);
					w.setModBy(soeId);
					w.setModDate(new Date());
					removeNominatedTo(groupId, w);
					rejectingWorkflow = w;
					break;
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateRejectingWorkflow()" ,e);
		}
		return rejectingWorkflow;
	}
	
	/**
	 * @param soeId
	 * @param inqObj
	 * @param groupId
	 * @param nominatedByGroupId
	 * @return
	 */
	private Workflow getRejectingWorkflow(String soeId, Inquiry inqObj, Long groupId) {
		Workflow rejectingWorkflow = null;
		
		try {
			for(Workflow w : inqObj.getWorkflows()){
				if(w.getAssignedGroupId().longValue() == groupId.longValue() && NOMINATE_OWNERSHIP.equalsIgnoreCase(w.getDirection())){
					removeNominatedTo(groupId, w);
					rejectingWorkflow = w;
					break;
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateRejectingWorkflow()" ,e);
		}
		return rejectingWorkflow;
	}

	/**
	 * This function marks all conversations read/unread
	 * @param soeId
	 * @param inputJsonObj
	 */
	public void updateAllConversationReadUnread(String soeId, BasicDBObject inputJsonObj) {
		
		try {
			List<Long> inquiryIds = GenericUtility.getIdListFromRequest(inputJsonObj, INQUIRY_IDS_KEY);
			
			@SuppressWarnings("unchecked")
			Map<Long, List<Long>> inquiryGroupMap =  inquiryDao.populateInquiryGroupListMap((List<String>) inputJsonObj.get(GROUP_IDS_KEY));
			
			String readFlag = inputJsonObj.getString(READ_FLAG);
			if(inquiryIds !=null && !inquiryIds.isEmpty() && !StringUtils.isEmpty(readFlag) && inquiryGroupMap != null ) {
				boolean markAsReadFlag = MARK_AS_READ_YES.equalsIgnoreCase(readFlag);
				for( Long inqId : inquiryIds) {
					processInquiryGroupMap(soeId, inquiryGroupMap, markAsReadFlag, inqId);
				}
			}
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#updateAllConversationReadUnread()" ,e);
		}
	}

	/**
	 * This method processes inquiry and group map.
	 * @param soeId
	 * @param inquiryGroupMap
	 * @param markAsReadFlag
	 * @param inqId
	 * @throws CommunicatorException
	 */
	private void processInquiryGroupMap(String soeId, Map<Long, List<Long>> inquiryGroupMap, boolean markAsReadFlag,
			Long inqId) throws CommunicatorException {
		List<Long> groupIds = inquiryGroupMap.get(inqId);
		if( groupIds != null && !groupIds.isEmpty() ) {
			for(Long grpId : groupIds){
				List<Long> inqGroupId = new ArrayList<>();
				inqGroupId.add(grpId);
				updateAllConversations(soeId, inqGroupId, inqId, markAsReadFlag);
			}
		}
	}

	/**
	 * This method extracts individual conversation to mark read/unread
	 * @param soeId
	 * @param inqGroupId
	 * @param inqId
	 * @param markAsReadFlag
	 * @throws CommunicatorException
	 */
	private void updateAllConversations(String soeId, List<Long> inqGroupId, Long inqId, boolean markAsReadFlag) 
			throws CommunicatorException {
		//Get all inquiry conversations
		if( null!= inqGroupId && !inqGroupId.isEmpty() ) {
			
			ConversationTO convTO = getAllInquiryConversations(soeId,inqId, inqGroupId,false,null);
			
			if(convTO!=null && null!= convTO.getConversationList() 
					&& !convTO.getConversationList().isEmpty()) {
				
				BasicDBObject updateReadBy = new BasicDBObject();
				
				if( markAsReadFlag) {
					updateReadBy.put(ADD_TO_SET_KEY, new BasicDBObject(READ_BY, soeId));
				} else {
					updateReadBy.put(PULL_KEY, new BasicDBObject(READ_BY, soeId));
				}
				
				updateConvReadUnread(soeId, markAsReadFlag, convTO, updateReadBy);
			}
		}
	}

	/**
	 * This conversation marks conversation read/unread
	 * @param soeId
	 * @param markAsReadFlag
	 * @param convTO
	 * @param updateReadBy
	 */
	private void updateConvReadUnread(String soeId, boolean markAsReadFlag, ConversationTO convTO,
			BasicDBObject updateReadBy) {
		for(Conversation conv : convTO.getConversationList()){
			List<String> readBy = conv.getReadBy();
			
			if(readBy == null ) {
				readBy = new ArrayList<>();
			}
			
			if( (markAsReadFlag && !readBy.contains(soeId)) || (!markAsReadFlag && readBy.contains(soeId))){
				updateConversation(conv, updateReadBy);
			} 
		}
	}
	
	/**
	 * @param soeid
	 * @return
	 * @throws CommunicatorException
	 */
	Set<Long> getAssignedGroupdIdFromDashboardSetting(String soeid) throws CommunicatorException {
		
		Set<Long> userGroupsList = new HashSet<>();
		try {
			if(StringUtils.isNotEmpty(soeid)){
				User user = QMACacheFactory.getCache().getUserInfoMap().get(soeid.toUpperCase());
				if(user==null){
					user = userDao.getUserById(soeid);
				}
				if(null != user && null != user.getDashboardSettings()) {
					Map<String, Object> dashboardSettings = user.getDashboardSettings();
					if(null != dashboardSettings && !dashboardSettings.isEmpty() && null != dashboardSettings.get("assignedGroups")){
						BasicDBList assignedGroupIds = (BasicDBList) dashboardSettings.get("assignedGroups");
						for(int i=0; i<assignedGroupIds.size();i++){
							String groupName = ((BasicDBObject)assignedGroupIds.get(i)).getString("groupName");
							addGroupIdTOUserGroupList(userGroupsList, groupName);

						}
					}
				}
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception while getting assigned group ids from dashboard setting in getAssignedGroupdIdFromDashboardSetting", e);
		}
		return userGroupsList;
	}

	/**
	 * @param userGroupsList
	 * @param groupName
	 */
	private void addGroupIdTOUserGroupList(Set<Long> userGroupsList, String groupName) {
		try {
			if(StringUtils.isNotBlank(groupName)){
				String inputGroupName = groupName.trim();
				Long groupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(inputGroupName.toUpperCase());
				if(null != groupId){
					userGroupsList.add(groupId);
				}
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception while adding assigned group ids to userGroupList in addGroupIdTOUserGroupList", e);
		}
	}
	
	public boolean markInqConvReadUnread(String request, String soeId, BasicDBObject inputJsonObj) {
		boolean success = false;
		try {
			success = inquiryDao.markInquiryReadUnRead(soeId, inputJsonObj);
			if(success){
				updateAllConversationReadUnread(soeId, inputJsonObj);

			}
		} catch (CommunicatorException e) {
			inqExtLogger.error("Exception in markInqConvReadUnread ", e);
		}
		return success;
	}
	
	public boolean executeInqCovReadUnread(Long inquiryId, List<Long> selectInqAssignedGroupId,String request, String soeId, BasicDBObject inputJsonObj) {
		boolean success = false;
		try {
			BasicDBObject input = new BasicDBObject();
			List<Long> inquiryIds = new ArrayList<>();
			List<String> groupIds = new ArrayList<>();
			StringBuilder  grpIds = new StringBuilder();
			for(Long grpId : selectInqAssignedGroupId){
				grpIds.append(grpId.toString()).append(',');
			}
			grpIds = grpIds.deleteCharAt(grpIds.length()-1);
			groupIds.add(inquiryId+":"+grpIds);
			inquiryIds.add(inquiryId);
			input.put("inquiryIds",inquiryIds);
			input.put("readFlag", "Y");
			input.put("groupIds", groupIds);
			success = markInqConvReadUnread(request, soeId, input);
		} catch (Exception e) {
			inqExtLogger.error("Exception in executeInqCovReadUnread ", e);
		}
		return success;
	}

	/** this method will return inquiryList and groupList
	 * @param soeId
	 * @param inputJsonObj
	 * @param isRetriveAll
	 * @param bw
	 * @return
	 * @throws CommunicatorException
	 */
	public BasicDBObject getClientPriorityGridViewData(String soeId, BasicDBObject inputJsonObj, boolean isRetriveAll,
			BufferedWriter bw) throws CommunicatorException {
		BasicDBObject inquiryGroupList = new BasicDBObject();
		try {
			inqExtLogger.info("getClientPriorityGridViewData for soeId : "+soeId);
			String categoryName = inputJsonObj.getString(CATEGORY_NAME);
			String categoryType = SYSTEM;
			Set<Long> assignedGroupId = null;
			if(null != inputJsonObj.get("groupName")){
				String groupName = inputJsonObj.getString("groupName");
				long groupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
				categoryType = CUSTOM;
				assignedGroupId = new HashSet<>();
				assignedGroupId.add(groupId);
			}
			if(SYSTEM.equalsIgnoreCase(categoryType)){
				assignedGroupId = getAssignedGroupdIdFromDashboardSetting(soeId);
				if(null != assignedGroupId && assignedGroupId.isEmpty()) {
					assignedGroupId = userDao.getUserGroupsList(soeId);
				}
			}
			
			inquiryGroupList = getIntesityHeatMapInquiryIds(assignedGroupId,categoryName, categoryType);
			inputJsonObj.put("categoryType", categoryType);
			
		} catch (Exception e) {
			inqExtLogger.error("Exception in getClientPriorityGridViewData ", e);
			throw new CommunicatorException(e.toString());
		}
		
		return inquiryGroupList;
	}

	/** prepare inquiryList and groupList from collection
	 * @param assignedGroupId
	 * @param categoryName
	 * @param categoryType
	 * @return
	 */
	private BasicDBObject getIntesityHeatMapInquiryIds(Set<Long> assignedGroupId, String categoryName, String categoryType) {
		Set<Long> inquiryList = new HashSet<>();
		Set<Long> groupList = new HashSet<>();
		
		try {
			QMACache qmaCache = QMACacheFactory.getCache();
			Date clientPriorityFromDate = null;
			if(null != qmaCache.getConfigById(CLIENT_PRIORITY_FROM_DATE)
					&& null != qmaCache.getConfigById(CLIENT_PRIORITY_FROM_DATE).getClientPriorityFromDate())
			{
				clientPriorityFromDate = qmaCache.getConfigById(CLIENT_PRIORITY_FROM_DATE).getClientPriorityFromDate();
			}
			
			List<InquiryClientPriority> inquiryClientPriorityList = MongoDB.instance().getDataStore()
					.createQuery(InquiryClientPriority.class).field(ASSIGNED_GROUP_ID).in(assignedGroupId)
					.field("crtDate").greaterThanOrEq(clientPriorityFromDate)
					.find().toList();
			for(InquiryClientPriority inquiryClientPriority : inquiryClientPriorityList ){
				if(SYSTEM.equalsIgnoreCase(categoryType) && null != inquiryClientPriority.getClientPriority()){
					getSystemCategoryInquiryList(categoryName, inquiryList, groupList, inquiryClientPriority);
					
				} else {
					getCustomClientCategoryInquiryList(categoryName, inquiryList, groupList, inquiryClientPriority);
				}
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in getInquiryIds ", e);
		} 
		BasicDBObject inquiryGroupList = new BasicDBObject();
		inquiryGroupList.put("inquiryList", inquiryList);
		inquiryGroupList.put("groupList", groupList);
		return inquiryGroupList;
	}

	/** gets inquiryList and groupList for custom client category
	 * @param categoryName
	 * @param inquiryList
	 * @param groupList
	 * @param inquiryClientPriority
	 */
	private void getCustomClientCategoryInquiryList(String categoryName, Set<Long> inquiryList,
			Set<Long> groupList, InquiryClientPriority inquiryClientPriority) {
		try {
			List<CustomClientCategoryDetails> customClientCategoryList =  inquiryClientPriority.getCustomClientCategory();
			if(null != customClientCategoryList && !customClientCategoryList.isEmpty()){
				for(CustomClientCategoryDetails customCLientCategoryDetails : customClientCategoryList){
					setCustomClientCategoryInquiryGroupList(categoryName, inquiryList, groupList, inquiryClientPriority,
							customCLientCategoryDetails);
				}
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in getCustomClientCategoryInquiryList", e);
		}
	}

	/**
	 * @param categoryName
	 * @param inquiryList
	 * @param groupList
	 * @param inquiryClientPriority
	 * @param customCLientCategoryDetails
	 */
	private void setCustomClientCategoryInquiryGroupList(String categoryName, Set<Long> inquiryList,
			Set<Long> groupList, InquiryClientPriority inquiryClientPriority,
			CustomClientCategoryDetails customCLientCategoryDetails) {
		try {
			if(null != customCLientCategoryDetails && categoryName.equalsIgnoreCase(customCLientCategoryDetails.getCategoryName())){
				inquiryList.add(inquiryClientPriority.getInquiryId());
				groupList.add(inquiryClientPriority.getAssignedGroupId());
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in setCustomClientCategoryInquiryGroupList", e);
		}
	}

	/** get inquiryList and groupList for system category
	 * @param categoryName
	 * @param inquiryList
	 * @param groupList
	 * @param inquiryClientPriority
	 */
	private void getSystemCategoryInquiryList(String categoryName, Set<Long> inquiryList,
			Set<Long> groupList, InquiryClientPriority inquiryClientPriority) {
		try {
			if(PLATINUM.equalsIgnoreCase(categoryName)){
				if(SUPERCHARGE.equalsIgnoreCase(inquiryClientPriority.getClientPriority()) ||  categoryName.equalsIgnoreCase(inquiryClientPriority.getClientPriority())){
					inquiryList.add(inquiryClientPriority.getInquiryId());
					groupList.add(inquiryClientPriority.getAssignedGroupId());
				}
			} else if(PRIORITY.equalsIgnoreCase(categoryName)){
				if(categoryName.equalsIgnoreCase(inquiryClientPriority.getClientPriority())){
					inquiryList.add(inquiryClientPriority.getInquiryId());
					groupList.add(inquiryClientPriority.getAssignedGroupId());
				}
			} else if(OTHER.equalsIgnoreCase(categoryName) && !SUPERCHARGE.equalsIgnoreCase(inquiryClientPriority.getClientPriority()) 
					&& !PLATINUM.equalsIgnoreCase(inquiryClientPriority.getClientPriority()) && !PRIORITY.equalsIgnoreCase(inquiryClientPriority.getClientPriority())
					&& !StringUtils.isBlank(inquiryClientPriority.getGpNum()) && !StringUtils.isBlank(inquiryClientPriority.getGpName()) 
					&& !StringUtils.isBlank(inquiryClientPriority.getClientName())){
				inquiryList.add(inquiryClientPriority.getInquiryId());
				groupList.add(inquiryClientPriority.getAssignedGroupId());
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in getSystemCategoryInquiryList", e);
		}
	}
	
	/**
	 * @param soeId
	 * @param inputJsonObj
	 * @param isRetrieveAll
	 * @param bw
	 * @return
	 * @throws CommunicatorException
	 */
	@SuppressWarnings("unchecked")
	DBObject getIntensityHeatMapData(String soeId, BasicDBObject inputJsonObj, boolean isRetrieveAll, BufferedWriter bw) throws CommunicatorException
	{
		DBObject gridViewTO = null;
		try {
			inqExtLogger.info("getIntensityHeatMapData for soeId: "+soeId);

			String viewName = inputJsonObj.getString("viewName");
			
			gridViewTO = new BasicDBObject();

			BasicDBObject inquiryGroupList = InquiryExtendedDAO.getInstance().getClientPriorityGridViewData(soeId, inputJsonObj, isRetrieveAll, bw);
			Set<Long> inquiryList = null;
			Set<Long> groupList = null;
			if(null  != inquiryGroupList){
				inquiryList = (Set<Long>) inquiryGroupList.get("inquiryList");
				groupList = (Set<Long>) inquiryGroupList.get("groupList");
				
			}
			BasicDBObject inquiryIdSearchCriteria;
			if(null != inquiryList && !inquiryList.isEmpty()){
				inquiryIdSearchCriteria = new BasicDBObject("_id", new BasicDBObject("$in", inquiryList));
			} else {
				inqExtLogger.info("InquiryList is blank for soeId: "+soeId);
				String nodeType = inquiryDao.getViewNodeType(inputJsonObj);
				gridViewTO.put("columnConfig", inquiryDao.getCustomColumnsForDefaultViews(viewName, nodeType, soeId));
				return gridViewTO;
			}
			BasicDBObject versionMatchCriteria;
			if(null != groupList && !groupList.isEmpty()){
				versionMatchCriteria = new BasicDBObject("workflows", new BasicDBObject("$elemMatch", new BasicDBObject("status","Open")
						.append("direction","IN")
						.append("assignedGroupId", new BasicDBObject("$in",groupList))
						.append("rulesFlag", new BasicDBObject("$exists",false))
						));
				//Set<String> directionList = new HashSet<>();
				//directionList.add("IN");
				//directionList.add("OUT");
				//directionList.add("PENDINGAPPROVAL");
				//directionList.add("PND_REAGE");
				//directionList.add("NOMINATE_OWNERSHIP");
				//versionMatchCriteria.append("workflows.direction", new BasicDBObject("$in",directionList));
						
			} else {
				inqExtLogger.info("groupList is blank for soeId: "+soeId);
				String nodeType = inquiryDao.getViewNodeType(inputJsonObj);
				gridViewTO.put("columnConfig", inquiryDao.getCustomColumnsForDefaultViews(viewName,nodeType, soeId));
				return gridViewTO;
			}
			//versionMatchCriteria.append("workflows.status", "Open");//C170665-115
			if(null != inputJsonObj.get("categoryType") 
					&& CUSTOM.equalsIgnoreCase(inputJsonObj.getString("categoryType"))){
				versionMatchCriteria.append("workflows.customClientCategory.categoryName", inputJsonObj.getString(CATEGORY_NAME));
			} 

			if (inquiryDao.isGroupLevelGridView(soeId))
			{
				gridViewTO = inquiryDao.getGroupLevelGridViewData(gridViewTO, soeId, null, versionMatchCriteria,
						inquiryIdSearchCriteria, null, null, 0, "GLOBAL_GRID_VIEW", true, isRetrieveAll, inputJsonObj, bw);
				if(null != inputJsonObj && null != inputJsonObj.get("categoryType") && SYSTEM.equalsIgnoreCase(inputJsonObj.getString("categoryType"))) {
					modifyFinalUICriteriaForSystemCategory(gridViewTO, inputJsonObj, soeId);
				}
				gridViewTO.put("finalCriteria", GenericUtility.parseJsonInRelaxedMode((DBObject) gridViewTO.get("finalUICriteria")));
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in getIntensityHeatMapData for soeId: "+soeId, e);
			throw new CommunicatorException(e.toString());
		}
		
		return gridViewTO;

	}	
	
	/** this method return finalUICriteria for system category for web socket update
	 * @param gridViewTO
	 * @param inputJsonObj
	 * @param soeId
	 */
	private void modifyFinalUICriteriaForSystemCategory(DBObject gridViewTO, BasicDBObject inputJsonObj, String soeId) {
		try {
			if(null != gridViewTO && null != gridViewTO.get("finalUICriteria") && null != ((BasicDBObject) gridViewTO.get("finalUICriteria")).get("$and")) {
				BasicDBObject finalUICriteria = (BasicDBObject) gridViewTO.get("finalUICriteria");
				BasicDBList andCriteria = (BasicDBList) finalUICriteria.get("$and");
				if(null != andCriteria && null != andCriteria.get(0)) {
					((BasicDBObject)andCriteria.get(0)).append("workflows.clientCategory.categoryName", inputJsonObj.getString(CATEGORY_NAME));
				}
				gridViewTO.put("finalUICriteria", finalUICriteria);
				gridViewTO.put("finalCriteria", finalUICriteria.toString());
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in modifyFinalUICriteriaForSystemCategory for soeId: "+soeId, e);
		}
		
	}

	/**
	 * This method is used to stamp client priority into DB collection name-InquiryClientPriority
	 * @param inquiry
	 */
	private void stampInquiryClientPriority(Inquiry inquiry, long acceptingGroupId) {
		try{
			Long inquiryId = inquiry.getId();
			String clientPriority = null;
			String clientName = null;
			String gpNum = null;
			String gpName = null;
			
			boolean checkDefaultCategory = null != inquiry.getGpNum() && null != inquiry.getGpName() 
					&& null != inquiry.getClientName() && !"CITI".equalsIgnoreCase(inquiry.getClientName());
			inqExtLogger.info("client name : "+inquiry.getClientName() + " and checkDefaultCategory is : "+ checkDefaultCategory);
			if(checkDefaultCategory){
				clientPriority = "";
				if(null != inquiry.getClientPriority()){
					clientPriority = inquiry.getClientPriority();
					inqExtLogger.info("Client priority ["+clientPriority+ "] satamping for inquiry Id:["+inquiryId+"]");
				}
				clientName = inquiry.getClientName();
				gpNum = inquiry.getGpNum();
				gpName = inquiry.getGpName();
			}			
			for(Workflow workflowObj: inquiry.getWorkflows()){
				if(workflowObj.getAssignedGroupId()==acceptingGroupId && "IN".equalsIgnoreCase(workflowObj.getDirection())){
					//saveClientPriority(inquiryId, clientPriority, checkDefaultCategory, workflowObj, clientName, gpNum, gpName);
					saveClientPriorityForNewWorkflow(inquiryId, clientPriority, checkDefaultCategory, workflowObj, clientName, gpNum, gpName);
				}
				
			}
			
		}catch(Exception ex){
			inqExtLogger.error("Exception occured while stamping client priority. SaveInquiryCmd#stampInquiryClientPriority",ex);
		}
		
	}
	
	/**
	 * This method used to save client priority to DB with matching workflow
	 * @param inquiryId
	 * @param clientPriority
	 * @param checkDefaultCategory
	 * @param workflowObj
	 * @param gpName 
	 * @param gpNum 
	 * @param clientName 
	 */
	private void saveClientPriority(Long inquiryId, String clientPriority, boolean checkDefaultCategory, Workflow workflowObj, String clientName, String gpNum, String gpName) {
		boolean checkCustomCategory = false;
		if(null != workflowObj.getAssignedGroupId()){
			Long assignedGroupId = workflowObj.getAssignedGroupId();
			Query<InquiryClientPriority> query = MongoDB.instance().getDataStore().createQuery(InquiryClientPriority.class)
					.filter("inquiryId", inquiryId)
					.filter("assignedGroupId", assignedGroupId);
			InquiryClientPriority inquiryClientPriority = query.get();
			if(null != inquiryClientPriority){
				inqExtLogger.info("Updating stamped inquiryId:"+inquiryId+" assignedGroupId:"+assignedGroupId);
				UpdateOperations<InquiryClientPriority> updateOps = MongoDB.instance().getDataStore().createUpdateOperations(InquiryClientPriority.class);
				updateOps.set("clientPriority", clientPriority);
				if(checkDefaultCategory){
					updateOps.set("clientName", clientName);
					updateOps.set("gpNum", gpNum);
					updateOps.set("gpName", gpName);
				}
				//If condition will get executed only for custom client categories available in workflows
				//and else for either system or custom category if its getting updated
				/*if(null != workflowObj.getCustomClientCategory() && workflowObj.getCustomClientCategory().size() > 0){
					inquiryClientPriority.setCustomClientCategory(workflowObj.getCustomClientCategory());
					updateOps.set("customClientCategory", workflowObj.getCustomClientCategory());
				}*/
				MongoDB.instance().getDataStore().update(query, updateOps);
			}else{
				inquiryClientPriority = new InquiryClientPriority();
				inquiryClientPriority.setInquiryId(inquiryId);
				inquiryClientPriority.setAssignedGroupId(assignedGroupId);
				inquiryClientPriority.setClientPriority(clientPriority);
				inquiryClientPriority.setClientName(clientName);
				inquiryClientPriority.setGpNum(gpNum);
				inquiryClientPriority.setGpName(gpName);
				//If condition will get executed only for custom client categories 
				//and else for either system or custom category if its getting stamped for the first time.
				/*if(null != workflowObj.getCustomClientCategory() && workflowObj.getCustomClientCategory().size() > 0){
					inquiryClientPriority.setCustomClientCategory(workflowObj.getCustomClientCategory());
					checkCustomCategory = true;
				}*/
				inquiryClientPriority.setCrtDate(new Date());
				if(checkCustomCategory || checkDefaultCategory){
					MongoDB.instance().getDataStore().save(inquiryClientPriority);
				}
			}
		}
	}
	
	/**
	 * @param viewName
	 * @param finalCriteria
	 * @param logger 
	 * @return
	 */
	DBObject updateFinalCriteriaWithDateConfig(String viewName, DBObject finalCriteria) {
		try {
			Config config = null;
			QMACache qmaCache = QMACacheFactory.getCache();
			if(null != qmaCache.getConfigById("defaultViewPerformanceConfig")){
				config = qmaCache.getConfigById("defaultViewPerformanceConfig");
			}
			boolean performanceFlag = false;
			Map<String, Object> defaultViewPerformanceConfig = null;
			if(null != config && null !=  config.getDefaultViewPerformanceConfig() 
					&& null != config.getDefaultViewPerformanceConfig().get("performanceFlag") ){
				defaultViewPerformanceConfig = config.getDefaultViewPerformanceConfig();
				performanceFlag = (boolean) defaultViewPerformanceConfig.get("performanceFlag");
			}
			BasicDBList viewsConfig = null;
			if(performanceFlag && null != defaultViewPerformanceConfig.get("viewsConfig")){
				viewsConfig = (BasicDBList) defaultViewPerformanceConfig.get("viewsConfig");
			}
			int noOfMonths = 0;
			if(null != viewsConfig && !viewsConfig.isEmpty()){
				noOfMonths = MailboxModDateUtil.getNoOfMonthsForViews(viewName, viewsConfig, noOfMonths);
			}
			if(noOfMonths > 0 && null != finalCriteria){
				DBObject updatedFinalCriteria = BasicDBObject.parse(finalCriteria.toString());
				BasicDBList criteriaList = (BasicDBList) updatedFinalCriteria.get("$and");
				Calendar cal = Calendar.getInstance();
				cal.set(Calendar.DAY_OF_MONTH, 1);
				cal.set(Calendar.HOUR, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				cal.add(Calendar.MONTH, -noOfMonths);
				criteriaList.add(new BasicDBObject(MOD_DATE, new BasicDBObject(GTE,cal.getTime())));
				return updatedFinalCriteria;
			}
		} catch (Exception e) {
			inqExtLogger.warn("Issue while updating FinalCriteriaWithDateConfig for viewName: "+viewName,e);
		}
		return finalCriteria;
	}

	/**
	 * @param dbInquiry 
	 * @param workFlowList
	 * @param conversation
	 */
	void stampWorkflowAttachmentFlag(Inquiry dbInquiry, List<Workflow> workFlowList, Conversation conversation) {
		try {
			inqExtLogger.info("inside setWorkflowAttachmentFlag ");
			String attachmentFlag = "N";
			if(null != conversation.getAttachments() && conversation.getAttachments().size()>0) {
				attachmentFlag =   "Y";
			}
			if("N".equalsIgnoreCase(attachmentFlag)){
				//check for newly created workflow like in from out or out from in
				stampAttchFlagToAdditionalWorkflow(dbInquiry, workFlowList);
			} else{
				Set<Long> conversationGroupList = getConversationRecipientGroupList(conversation);
				if(null != conversationGroupList && !conversationGroupList.isEmpty()){
					setAttachmentFlagOnWorkflow(workFlowList, attachmentFlag, conversationGroupList);
				}
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in setWorkflowAttachmentFlag", e);
		}
	}

	/** this method stamp attachment flag to other newly added workflow with different direction
	 * @param dbInquiry
	 * @param workFlowList
	 */
	private void stampAttchFlagToAdditionalWorkflow(Inquiry dbInquiry, List<Workflow> workFlowList) {
		try {
			if(null != dbInquiry && "Y".equalsIgnoreCase(dbInquiry.getAttchFlag())){
				Set<Long> assignedGroupIdWithAttachement = getGroupIdWithAttachement(workFlowList);
				if(null != assignedGroupIdWithAttachement && !assignedGroupIdWithAttachement.isEmpty()){
					stampAttachmentFlagToNewlyCreatedWorkflow(workFlowList, assignedGroupIdWithAttachement);
				}
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in stampAttchFlagToAdditionalWorkflow", e);
		}
	}

	/** get attachment flag for existing workflow
	 * @param workFlowList
	 * @return
	 */
	private Set<Long> getGroupIdWithAttachement(List<Workflow> workFlowList) {
		Set<Long> assignedGroupIdWithAttachement = new HashSet<>();
		try {
			for(Workflow workflowObj : workFlowList){
				if(!assignedGroupIdWithAttachement.contains(workflowObj.getAssignedGroupId()) && null != workflowObj.getAttchFlag() && "Y".equalsIgnoreCase(workflowObj.getAttchFlag())){
					assignedGroupIdWithAttachement.add(workflowObj.getAssignedGroupId());
				}
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in getGroupIdWithAttachement", e);
		}
		return assignedGroupIdWithAttachement;
	}

	/** to stamp attach flag to workflow with different direction
	 * @param workFlowList
	 * @param assignedGroupIdWithAttachement
	 */
	private void stampAttachmentFlagToNewlyCreatedWorkflow(List<Workflow> workFlowList, Set<Long> assignedGroupIdWithAttachement) {
		try {
			for(Workflow workflowObj : workFlowList){
				if(null == workflowObj.getAttchFlag() && assignedGroupIdWithAttachement.contains(workflowObj.getAssignedGroupId())){
					workflowObj.setAttchFlag("Y");
				}
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in stampAttachmentFlagToNewlyCreatedWorkflow", e);
		}
	}

	/**
	 * @param workFlowList
	 * @param attachmentFlag
	 * @param conversationGroupList
	 */
	private void setAttachmentFlagOnWorkflow(List<Workflow> workFlowList, String attachmentFlag,
			Set<Long> conversationGroupList) {
		try {
			for(Workflow workflowObj : workFlowList){
				if(conversationGroupList.contains(workflowObj.getAssignedGroupId())){
					workflowObj.setAttchFlag(attachmentFlag);
				}
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in setAttachmentFlagOnWorkflow", e);
		}
	}
	/**
	 * @param conversation
	 * @return
	 */
	private Set<Long> getConversationRecipientGroupList(Conversation conversation) {
		Set<Long> conversationGroupList = null;
		try {
			List<ConversationRecipient> convRecipient = conversation.getRecipients();
			conversationGroupList = new HashSet<Long>();
			for(ConversationRecipient conRec : convRecipient){
				if(null != conRec && null != conRec.getGroupId() && !"".equalsIgnoreCase(conRec.getGroupId().toString())){
					conversationGroupList.add(conRec.getGroupId());
				}
			}
			
		} catch (Exception e) {
			inqExtLogger.error("Exception in getConversationRecipientGroupList", e);
		}
		return conversationGroupList;
	}
	
	/** This method stamps default and custom client category for new workflow only 
	 * @param inquiryId
	 * @param clientPriority
	 * @param checkDefaultCategory
	 * @param workflowObj
	 * @param clientName
	 * @param gpNum
	 * @param gpName
	 */
	private void saveClientPriorityForNewWorkflow(Long inquiryId, String clientPriority, boolean checkDefaultCategory, Workflow workflowObj, String clientName
			, String gpNum, String gpName) {
		
		if(null != workflowObj.getAssignedGroupId() && null != inquiryId){
			Long assignedGroupId = workflowObj.getAssignedGroupId();
			InquiryClientPriority inquiryClientPriority = new InquiryClientPriority();
			inquiryClientPriority.setInquiryId(inquiryId);
			inquiryClientPriority.setAssignedGroupId(assignedGroupId);
			
			if(checkDefaultCategory) {	//set system category
				inquiryClientPriority.setClientPriority(clientPriority);
				inquiryClientPriority.setClientName(clientName);
				inquiryClientPriority.setGpNum(gpNum);
				inquiryClientPriority.setGpName(gpName);
				inqExtLogger.info("setting default category for Inquiry: "+ inquiryId + " and groupId : "+assignedGroupId);
			}
			
			//If condition will get executed only for custom client categories 
			//and else for either system or custom category if its getting stamped for the first time.
			boolean checkCustomCategory = false;
			if(null != workflowObj.getCustomClientCategory() && workflowObj.getCustomClientCategory().size() > 0){
				inquiryClientPriority.setCustomClientCategory(workflowObj.getCustomClientCategory());
				checkCustomCategory = true;
				inqExtLogger.info("setting custom category for Inquiry: "+ inquiryId + " and groupId : "+assignedGroupId);
			}
			
			if(checkCustomCategory || checkDefaultCategory){
				inquiryClientPriority.setCrtDate(new Date());
				MongoDB.instance().getDataStore().save(inquiryClientPriority);
				inqExtLogger.info("stamping of category is saved for Inquiry: "+ inquiryId + " and groupId : "+assignedGroupId);
			}
		}
	}
	
	/**
	 * Method to update the conversation label NLP status from Conversation level NLP status.
	 * @param conversationTO
	 */
	public void updateNLPSuggestionToConversation(ConversationTO conversationTO) {
		try {
			if (null != conversationTO) {
				String suggestionStatus = conversationTO.getSuggestionStatus();
				boolean isSuggestionAvailable = conversationTO.isSuggestionAvailable();
				if (!conversationTO.getConversationList().isEmpty() && conversationTO.getConversationList().size() == 1) {
					conversationTO.getConversationList().stream().forEach(conv -> {
						conv.setSuggestionAvailable(isSuggestionAvailable);
						conv.setSuggestionStatus(suggestionStatus);
					});
				}
			}
		} catch (Exception e) {
			inqExtLogger.error("Error while updateNLPSuggestionToConversation : ", e);
		}
	}

	/**
	 * Method to mark inquiry as non-inquiry or inquiry. 
	 * 
	 * @param soeId
	 * @param inputJsonObj
	 * @param servletRequest
	 * @return
	 */
	public boolean markAsInquiryOrNonInquiry(String soeId, BasicDBObject inputJsonObj) {
		boolean bSucess = Boolean.FALSE;
		try {
			bSucess = inquiryDao.markAsInquiryOrNonInquiry(soeId, inputJsonObj);
		} catch (Exception e) {
			GenericUtility.logMethodGenericException(inqExtLogger, "InquiryExtendedDAO#markAsInquiryOrNonInquiry()"+ soeId ,e);
		}
		return bSucess;
	}
	
	
	
	/**
	 * @param soeId
	 * @param inputJsonObj
	 * @return
	 * @throws CommunicatorException
	 */
	public DBObject getGridViewTotalCount(String soeId, BasicDBObject inputJsonObj) {
		//String viewType = null;
		BasicDBObject result = new BasicDBObject();
		int totalCount = 0;
		try {
			inqExtLogger.info("inside getGridViewTotalCount for soeId : " + soeId);
			String viewName = inputJsonObj.getString("viewName");
			
			if ("Drafts".equalsIgnoreCase(viewName)) {
				DBObject boxCriteria = inquiryDao.getDraftQuery(soeId);
				if(null == boxCriteria){
					boxCriteria = new BasicDBObject("userId", soeId);
				}
				totalCount = inquiryDao.getViewDataCount("Draft", boxCriteria);
				result.put("totalRecords", totalCount);
				result.put("totalUnreadRecords", 0);
			} else {
				
				List<BasicDBObject> gridViewQuery = getGridViewQuery(soeId, inputJsonObj);
				if(null != gridViewQuery && !gridViewQuery.isEmpty()) {
					result = fetchTotalCount(gridViewQuery, soeId);
				} else {
					inqExtLogger.info("query is null for getGridViewQuery for soeId : "+ soeId);
				}
			}
			//result.put("viewType", viewType);
		} catch (Exception e) {
			inqExtLogger.error("Exception in getGridViewTotalCount for soeId : "+ soeId, e);
		}
		//result.put("totalRecords", totalCount);
		return result;		
	}

	/**
	 * @param soeId
	 * @param inputJsonObj
	 * @return
	 */
	private List<BasicDBObject> getGridViewQuery(String soeId, BasicDBObject inputJsonObj){
		try {
			String viewName = inputJsonObj.getString("viewName");
			String viewType = inputJsonObj.getString("viewType");
			String tagSearch = inputJsonObj.getString("tagSearch");
			boolean isTagSearch = tagSearch != null && tagSearch.equals("Y");
			String solrSearchText = null;
			BasicDBObject advanceSearchInput = null;
			List<BasicDBObject> finalGetGridViewQuery = null;
			//solr search
			if (null != inputJsonObj.get(SOLR_SEARCH_TEXT)) {
				solrSearchText = inputJsonObj.getString(SOLR_SEARCH_TEXT);
				if (solrSearchText != null && !solrSearchText.isEmpty()) {
					if (SmartSearchUtil.isSmartSearchEnabled()) {
						finalGetGridViewQuery = prepareInputForSmartSearch(soeId, inputJsonObj, viewName, finalGetGridViewQuery);
						if(null == finalGetGridViewQuery) {
							finalGetGridViewQuery = getSolrSearchQuery(inputJsonObj, soeId, viewName, solrSearchText);
						}
					} else {
						finalGetGridViewQuery = getSolrSearchQuery(inputJsonObj, soeId, viewName, solrSearchText);
					}
					viewType = "5";
				}
			}
			//advance solr search
			else if(null != inputJsonObj.get(ADVANCE_SEARCH_DATA)) {
				advanceSearchInput = (BasicDBObject) inputJsonObj.get(ADVANCE_SEARCH_DATA);
				if(null != advanceSearchInput) {
					finalGetGridViewQuery = getAdvanceSearchQuery(inputJsonObj, soeId, viewName, advanceSearchInput);
					viewType = "5";
				}
			}
			//intensity heatmap 
			else if("intensityHeatMap".equalsIgnoreCase(viewName)){
				finalGetGridViewQuery = getIntensityHeatMapQuery(inputJsonObj, soeId);
				
			}
			//dashboard grids
			else if(null != inputJsonObj.get("isChartView") && "Y".equalsIgnoreCase(inputJsonObj.getString("isChartView"))) {
				finalGetGridViewQuery = getChartViewQuery(inputJsonObj, soeId, viewName);
				viewType = "0";
			}
			
			//potential escalation
			else if(POTENTIAL_ESCALATIONS.equalsIgnoreCase(viewName)) {
				finalGetGridViewQuery = getPotentialEscalationQuery(inputJsonObj, soeId, viewName);
				
				viewType = "4";
			}
			//Tag view
			else if(isTagSearch) {
				finalGetGridViewQuery = getTagViewQuery(inputJsonObj, soeId, viewName);
				viewType = "4";
			}
			//my views
			else if("-1".equalsIgnoreCase(viewType)) {
				finalGetGridViewQuery = getMyViewQuery(viewName, soeId, inputJsonObj);
			}
			//combined view 
			else if("Inbox".equals(viewName) && SymphonyDAO.getInstance().isCombinedViewRequired(viewName, soeId)) {
				finalGetGridViewQuery = SymphonyDAO.getInstance().getCombinedViewQuery(viewName, soeId);	
			}
			//combined view 
			else if("ChatView".equals(viewName)) {
				finalGetGridViewQuery = SymphonyDAO.getInstance().getChatViewQuery(viewName, soeId);
			}
			//default view
			else {
				finalGetGridViewQuery = getDefaultViewsQuery(soeId, viewName, inputJsonObj);
			}
			finalGetGridViewQuery = applyGroupByForTotalCount(soeId, finalGetGridViewQuery, viewName);
			return finalGetGridViewQuery;
			
		} catch (Exception e) {
			inqExtLogger.error("Exception in getGridViewQuery for soeId : "+ soeId, e);
			return null;
		}
	}

	private List<BasicDBObject> prepareInputForSmartSearch(String soeId, BasicDBObject inputJsonObj, String viewName, List<BasicDBObject> finalGetGridViewQuery) {
		inqExtLogger.info("Smart search enabled..");
		inputJsonObj = SmartSearchUtil.getSmartSearchCriteria(inputJsonObj);
		if (null != inputJsonObj.get(ADVANCE_SEARCH_DATA)) {
			BasicDBObject advanceSearchInput = (BasicDBObject) inputJsonObj.get(ADVANCE_SEARCH_DATA);
			if (null != advanceSearchInput) {
                try {
                    finalGetGridViewQuery = getAdvanceSearchQuery(inputJsonObj, soeId, viewName, advanceSearchInput);
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException("Error in prepareInputForSmartSearch(): " + e.getMessage());
                }
            }
		}
		return finalGetGridViewQuery;
	}
	/**
	 * @param soeId
	 * @param finalGetGridViewQuery
	 * @param viewName 
	 * @return
	 */
	private List<BasicDBObject> applyGroupByForTotalCount(String soeId, List<BasicDBObject> finalGetGridViewQuery, String viewName) {
		List<BasicDBObject> finalGetGridViewQueryWithGroupBy = finalGetGridViewQuery;
		try {
			if(null != finalGetGridViewQueryWithGroupBy) {
				String query = finalGetGridViewQueryWithGroupBy.toString();
				if("OUTBOX".equalsIgnoreCase(viewName)|| "sent".equalsIgnoreCase(viewName)) {
					query = query.substring(0, query.length()-1)+","+QueryConstants.QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD_OUT+"]";
				}else if(PENDING_APPROVAL.equalsIgnoreCase(viewName)) {
					query = query.substring(0, query.length()-1)+","+QueryConstants.QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD_PENDING_APPROVAL+"]";
				}else if(POTENTIAL_ESCALATIONS.equalsIgnoreCase(viewName) || POTENTIAL_ESCALATION.equalsIgnoreCase(viewName)) {
					query = query.substring(0, query.length()-1)+","+QueryConstants.QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD_ESCALATION+"]";
				}else {
					query = query.substring(0, query.length()-1)+","+QueryConstants.QUERY_GROUPING_FILTER_FOR_COUNT_AND_READ_UNREAD+"]";
				}
				query = query.replaceAll("#SOEID#", soeId);
				finalGetGridViewQueryWithGroupBy = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(query));
			}
		}catch(Exception e) {
			finalGetGridViewQueryWithGroupBy = finalGetGridViewQuery;
			inqExtLogger.warn("Exception while applying group by for soeId:"+soeId,e);
		}
		return finalGetGridViewQueryWithGroupBy;
	}

	/**
	 * @param soeId
	 * @param viewName
	 * @return
	 */
	@SuppressWarnings({ "deprecation", "unchecked" })
	private List<BasicDBObject> getDefaultViewsQuery(String soeId, String viewName, BasicDBObject inputJsonObj) {
		List<BasicDBObject> finalQueryListObject = null;
		try {
			List<Long> groupIds = new ArrayList<>();
			DashboardDAO.getInstance().getAllAssignedGroups(soeId, groupIds);
			
			// C170665-42 | Get the list of assigned group select in dashboard setting.
			Set<Long> selGrpIds = inquiryDao.getAssignedGroupsfromDashboard(soeId, new HashSet<Long>(groupIds));
			inqExtLogger.info("GroupIds:"+selGrpIds.toString());
			String viewQuery = null;
			if(null != inputJsonObj.get("isPersonal") && "Y".equalsIgnoreCase(inputJsonObj.getString("isPersonal"))
					&& null != inputJsonObj.get("viewName")) {
				String personalFolderName = inputJsonObj.getString("viewName");
				selGrpIds = userDao.getUserGroupsList(soeId);
				viewName = "Personal Mail";
				viewQuery = DashboardDAO.getInstance().getViewQueryForBoxCount(viewName.trim(),soeId);
				if(personalFolderName.equalsIgnoreCase("Individual")) {
					personalFolderName = "Inbox";
				}
				viewQuery = viewQuery.replace("#personalFolderName#", personalFolderName);
			}else {
				viewQuery = DashboardDAO.getInstance().getViewQueryForBoxCount(viewName.trim(),soeId);
			}
			String finalQuery = viewQuery.replace(QueryConstants.GROUP_ID_EXP, selGrpIds.toString());
			Date dateCriteria =  MailboxModDateUtil.getModDateAsPerDateConfig(soeId, inputJsonObj, viewName,false);
			if(null != dateCriteria) {
				Long dateLong = dateCriteria.getTime();
				finalQuery = finalQuery.replaceAll("#MOD_DATE#", dateLong.toString());
			}
			inqExtLogger.info("view name : "+viewName +" and query : "+finalQuery);
			finalQueryListObject= DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(finalQuery));
			//if("RESOLVED".equalsIgnoreCase(viewName) || "OUTBOX".equalsIgnoreCase(viewName)) {
			//	DashboardDAO.getInstance().updateMailBoxStatQueryWithDateConfig(viewName, finalQueryListObject, inqExtLogger);
			//}
		} catch (Exception e) {
			inqExtLogger.error("Exception in getDefaultViewsQuery for soeId : "+soeId+" and viewName : "+viewName, e);
			finalQueryListObject = null;
		}
		return finalQueryListObject;
	}

	/**
	 * @param viewName
	 * @param soeId
	 * @return
	 */
	private List<BasicDBObject> getMyViewQuery(String viewName, String soeId, BasicDBObject inputJsonObj){
		
		try {
			BasicDBList viewCriteria = DashboardDAO.getInstance().getUserViewCriteria(viewName, soeId);
			
			if( null != viewCriteria && null != viewCriteria.get(0) && null != viewCriteria.get(1)){
				BasicDBObject queryCriteria = (BasicDBObject) viewCriteria.get(0);
				BasicDBObject viewCrit = new BasicDBObject(QueryConstants.MATCH_OPERATOR, (BasicDBObject) viewCriteria.get(1));
				inquiryDao.getBsonObjForUserCtrWithDateObj(viewCrit, "dd/MMM/yyyy");
				viewCriteria.remove(0);
				String testViewName = queryCriteria.getString("viewType");
				String viewQuery = DashboardDAO.getInstance().getViewQueryForBoxCount(testViewName,soeId);
				if(StringUtils.isNotEmpty(viewQuery)) {
					List<Long> groupIds = new ArrayList<>();
					DashboardDAO.getInstance().getAllAssignedGroups(soeId, groupIds);
					
					// C170665-42 | Get the list of assigned group select in dash board setting.
					Set<Long> selGroupIds = inquiryDao.getAssignedGroupsfromDashboard(soeId, new HashSet<>(groupIds));
					
					String finalQuery = viewQuery.replace(QueryConstants.GROUP_ID_EXP, selGroupIds.toString());
					Date dateCriteria =  MailboxModDateUtil.getModDateAsPerDateConfig(soeId, inputJsonObj, viewName,false);
					if(null != dateCriteria) {
						Long dateLong = dateCriteria.getTime();
						finalQuery = finalQuery.replaceAll("#MOD_DATE#", dateLong.toString());
					}
					@SuppressWarnings({ "unchecked", "deprecation" })
					List<BasicDBObject> query = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(finalQuery));
					query.add(viewCrit);
					return query;
				}
				
			}
		} catch (CommunicatorException e) {
			inqExtLogger.error("Exception in getMyViewQuery for soeId : "+soeId+" and my view : "+viewName, e);
		}
		return null;
	}
	

	/**
	 * @param inputJsonObj
	 * @param soeId
	 * @param viewName
	 * @return
	 */
	private List<BasicDBObject> getChartViewQuery(BasicDBObject inputJsonObj, String soeId, String viewName) {
		List<BasicDBObject> chartQuery = null;
		try {
			if("Open Inquiries By Assigned Group".equalsIgnoreCase(viewName)) {
				chartQuery = getOpenInquiriesByGroupQuery(inputJsonObj, soeId, viewName);
			}
			else if("Open Inquiries By Request Type".equalsIgnoreCase(viewName)) {
				chartQuery = getOpenInquiriesByRequestTypeQuery(inputJsonObj, soeId, viewName);
			}
			else if("Open Inquiries By Assigned Owners".equalsIgnoreCase(viewName)) {
				chartQuery = getOpenInquiriesByAssignedOwnerQuery(inputJsonObj, soeId, viewName);
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in getChartViewQuery for soeId : "+soeId, e);
			chartQuery = null;
		}
		return chartQuery;
	}

	/**
	 * @param inputJsonObj
	 * @param soeId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<BasicDBObject> getIntensityHeatMapQuery(BasicDBObject inputJsonObj, String soeId) {
		List<BasicDBObject> queryList = null;
		try {

			BasicDBObject inquiryGroupList = InquiryExtendedDAO.getInstance().getClientPriorityGridViewData(soeId, inputJsonObj, true, null);
			Set<Long> inquiryList = null;
			Set<Long> groupList = null;
			if(null  != inquiryGroupList && null != inquiryGroupList.get("inquiryList") && null != inquiryGroupList.get("groupList")){
				inquiryList = (Set<Long>) inquiryGroupList.get("inquiryList");
				groupList = (Set<Long>) inquiryGroupList.get("groupList");
			}
			BasicDBObject inquiryIdSearchCriteria = null;
			if(null != inquiryList && !inquiryList.isEmpty()){
				inquiryIdSearchCriteria = new BasicDBObject("_id", new BasicDBObject("$in", inquiryList));
			} else {
				inqExtLogger.info("InquiryList is blank for soeId: "+soeId);
			}
			BasicDBObject versionMatchCriteria = null;
			if(null != groupList && !groupList.isEmpty()){
				versionMatchCriteria =  new BasicDBObject("workflows", new BasicDBObject("$elemMatch", new BasicDBObject("status","Open")
						.append("direction","IN")
						.append("assignedGroupId", new BasicDBObject("$in",groupList))
						//.append("rulesFlag", new BasicDBObject("$exists",false))
						));
			} else {
				inqExtLogger.info("groupList is blank for soeId: "+soeId);
			}
			if(null != inputJsonObj.get("categoryType") 
					&& CUSTOM.equalsIgnoreCase(inputJsonObj.getString("categoryType")) && null != versionMatchCriteria){ //<-- sonar fix null pointer
				versionMatchCriteria.append("workflows.customClientCategory.categoryName", inputJsonObj.getString(CATEGORY_NAME));
			}
			//versionMatchCriteria.append("workflows.status", "Open");//[C170665-4252]
			BasicDBList topLevelCriteriaList = new BasicDBList();
			if(null != versionMatchCriteria) {
				topLevelCriteriaList.add(inquiryIdSearchCriteria);//inquiryIdSearchCriteria
			}
			if(null != inquiryIdSearchCriteria) {
				topLevelCriteriaList.add(versionMatchCriteria);//versionMatchCriteria
			}
			BasicDBObject topMatchCriteria = new BasicDBObject();
			topMatchCriteria.append("$match", new BasicDBObject("$and",topLevelCriteriaList));
			queryList = new ArrayList<>();
			queryList.add(topMatchCriteria);
			
			BasicDBObject unwind = new BasicDBObject("$unwind","$workflows");
			queryList.add(unwind);
			
			String versionMatch  ="  { 'workflows.status' : 'Open', 'workflows.direction' : 'IN' ,'workflows.assignedGroupId' : { '$in' : #GROUPIDGRID#},'workflows.rulesFlag' : { '$exists' : false}}";
			String groupListString = (groupList != null) ? groupList.toString() : null;
			versionMatch = versionMatch.replace("#GROUPIDGRID#", groupListString);
			BasicDBObject versionMatchDbObject = BasicDBObject.parse(versionMatch);
			BasicDBObject versionCriteria = new BasicDBObject();
			versionCriteria.append("$match", versionMatchDbObject);
			queryList.add(versionCriteria);
			
			String strGroupCriteriaLevel1 = "{'$group': {'_id': {'inquiryId': '$_id', 'assignedGroupId': '$workflows.assignedGroupId'}, 'doc': {'$first': '$$ROOT'}}}";
			String strGroupCriteriaLevel2 =	"{'$replaceRoot': {'newRoot': '$doc'}}";
			
			@SuppressWarnings("deprecation")
			BasicDBObject groupLevelCriteriaLevel1 = BasicDBObject.parse(strGroupCriteriaLevel1);
			queryList.add(groupLevelCriteriaLevel1);
			@SuppressWarnings("deprecation")
			BasicDBObject groupLevelCriteriaLevel2 = BasicDBObject.parse(strGroupCriteriaLevel2);
			queryList.add(groupLevelCriteriaLevel2);
			
		} catch (Exception e) {
			inqExtLogger.error("Exception in getIntensityHeatMapData for soeId: "+soeId, e);
			queryList = null;
		}
		
		return queryList;


		
		
	}

	/**
	 * @param inputJsonObj
	 * @param soeId
	 * @param viewName
	 * @return
	 */
	@SuppressWarnings({ "deprecation", "unchecked" })
	private List<BasicDBObject> getPotentialEscalationQuery(BasicDBObject inputJsonObj, String soeId, String viewName) {
		List<BasicDBObject> queryList = null;
		try {
			BasicDBObject versionCretiria = null;
			String strVersionCriteria = null;
			String viewFilter = null;
			if(null != inputJsonObj.get("viewFilter")) {
				viewFilter = inputJsonObj.getString("viewFilter");
				strVersionCriteria = getPotentialEscalationViewFilterCriteria(viewFilter);
			} else {
				strVersionCriteria = "{'$match': {'$or': [{'workflows.isConvCountEscalation': 'Y'}, {'workflows.isSubjectEscalation': 'Y'}, {'workflows.responseTimeEscalationFlag': 'Y'}, {'workflows.isClientChaseEscalation': 'Y'}, {'workflows.ispendingApprovalEscalation': 'Y'}, {'workflows.isManualEscalation': 'Y'}]}}";
			}
			versionCretiria = BasicDBObject.parse(strVersionCriteria);
			String query = QueryConstants.POTENTIAL_ESCALATION_QUERY_FOR_MAILBOX_STATS;
			Set<Long> userGroupsList = userDao.getUserGroupsList(soeId);
			
			// C170665-42 | Get the list of assigned group select in dash board setting.
			userGroupsList = inquiryDao.getAssignedGroupsfromDashboard(soeId, userGroupsList);
			
			query = query.replace(QueryConstants.GROUP_ID_EXP, userGroupsList.toString());
			Date dateCriteria =  MailboxModDateUtil.getModDateAsPerDateConfig(soeId, inputJsonObj, viewName,false);
			if(null != dateCriteria) {
				Long dateLong = dateCriteria.getTime();
				query = query.replaceAll("#MOD_DATE#", dateLong.toString());
			}
			queryList = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(query));
			if(null != versionCretiria) {
				queryList.add(versionCretiria);
			}
		} catch (CommunicatorException e) {
			inqExtLogger.error("Exception in getPotentialEscalationQuery for soeId : "+soeId, e);
			queryList = null;
		}
		return queryList;
	}


	private String getPotentialEscalationViewFilterCriteria(String viewFilter) {
		String viewFilterCriteria = "{'$match': {'workflows."+viewFilter+"': 'Y'}}";
		
		return viewFilterCriteria;
	}

	/**
	 * @param inputJsonObj
	 * @param soeId
	 * @param viewName
	 * @return
	 */
	private List<BasicDBObject> getOpenInquiriesByRequestTypeQuery(BasicDBObject inputJsonObj, String soeId,
			String viewName) {
		try {
			String groupId = inputJsonObj.getString("groupId");
			String requestType = inputJsonObj.getString("requestType");
			if (groupId == null)
			{
				inqExtLogger.info("groupId not found in cache for groupName -" + groupId);
			}
			if (groupId != null)
			{
				String query = QueryConstants.OPEN_INQUIRIES_BY_REQUEST_TYPE;
				query = query.replaceAll("#GROUPID#", groupId);
				if("Unassigned".equalsIgnoreCase(requestType)){
					query= query.replace("'#REQUESTTYPE#'", "{'$exists': false}");
				}else {
					query = query.replaceAll("#REQUESTTYPE#", requestType);
				}
				@SuppressWarnings({ "deprecation", "unchecked" })
				List<BasicDBObject> queryList = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(query));
				return queryList;
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in getOpenInquiriesByRequestTypeQuery for soeId : "+soeId, e);
		}
		return null;
	}
	
	/**
	 * @param inputJsonObj
	 * @param soeId
	 * @param viewName
	 * @return
	 */
	private List<BasicDBObject> getOpenInquiriesByAssignedOwnerQuery(BasicDBObject inputJsonObj, String soeId,
			String viewName) {
		try {
			String groupId = inputJsonObj.getString("groupId");
			Set<Long> userGroupsList = new HashSet<Long>();
			if("All".equalsIgnoreCase(inputJsonObj.getString("groupId"))){
					userGroupsList = InquiryExtendedDAO.getInstance().getAssignedGroupdIdFromDashboardSetting(soeId);
					if(null == userGroupsList || userGroupsList.isEmpty()){
						// get user groups
						userGroupsList = userDao.getUserGroupsList(soeId);
					}
				}
			
			String assignedOwnerId = inputJsonObj.getString("assignedOwnerId");
			
			if (groupId == null)
			{
				inqExtLogger.info("groupId not found in cache for groupName -" + groupId);
			}
			if (groupId != null)
			{
				String query = QueryConstants.OPEN_INQUIRIES_BY_ASSIGNED_OWNER;
				if("Unassigned".equalsIgnoreCase(assignedOwnerId)){
					query = QueryConstants.OPEN_INQUIRIES_BY_UNASSIGNED_OWNER;
					Map<String, Long> dateByAgeBandMap = GenericUtility.getDateByAgeBand(inputJsonObj);
					String unAssignedAndAgeBandCriteria = "";
					if(null != dateByAgeBandMap.get(AGE_BAND_FROM_DATE)) {
						long ageBandFromDate = dateByAgeBandMap.get(AGE_BAND_FROM_DATE);
						unAssignedAndAgeBandCriteria = unAssignedAndAgeBandCriteria+", 'workflows.crtDate':{'$lte':{'$date':"+ageBandFromDate+"}}";
					}
					if(null != dateByAgeBandMap.get(AGE_BAND_TO_DATE)) {
						long ageBandToDate = dateByAgeBandMap.get(AGE_BAND_TO_DATE);
						unAssignedAndAgeBandCriteria = unAssignedAndAgeBandCriteria+", 'workflows.crtDate':{'$gt':{'$date':"+ageBandToDate+"}}";
					}
					query = query.replace("#dateByAgeBand#", unAssignedAndAgeBandCriteria);
				}else {
					query = query.replaceAll("#ASSIGNEDOWNERID#", assignedOwnerId);
				}
				query = query.replaceAll("#GROUPID#", userGroupsList.toString());
				@SuppressWarnings({ "deprecation", "unchecked" })
				List<BasicDBObject> queryList = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(query));
				return queryList;
			}
		} catch (CommunicatorException e) {
			inqExtLogger.error("Exception in getOpenInquiriesByAssignedOwnerQuery for soeId : "+soeId, e);
		}
		return null;
	}

	/**
	 * @param inputJsonObj
	 * @param soeId
	 * @param viewName
	 * @return
	 */
	private List<BasicDBObject> getOpenInquiriesByGroupQuery(BasicDBObject inputJsonObj, String soeId, String viewName) {
		try {
			String groupId = inputJsonObj.getString("groupId");
			if (groupId == null)
			{
				inqExtLogger.info("groupId not found in cache for groupName -" + groupId);
			}
			if (groupId != null)
			{
				String query = QueryConstants.OPEN_INQUIRIES_BY_GROUP;
				query = query.replaceAll("#GROUPID#", groupId);
				@SuppressWarnings({ "unchecked", "deprecation" })
				List<BasicDBObject> queryList = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(query));
				return queryList;
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in getOpenInquiriesByGroupQuery for soeId : "+soeId, e);
		}
		return null;
	}

	/**
	 * @param inputJsonObj
	 * @param soeId
	 * @param viewName
	 * @param advanceSearchInput
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "deprecation" })
	private List<BasicDBObject> getAdvanceSearchQuery(BasicDBObject inputJsonObj, String soeId, String viewName,
			BasicDBObject advanceSearchInput) throws UnsupportedEncodingException {
		List<BasicDBObject> queryList = null;
		try {
			HashMap<String, List<String>> solrQueryMap = inquiryDao.createSolrQuery(inputJsonObj, soeId);
			List<String> solrSearchTexts = solrQueryMap.get("solrQuery");
			DBObject solrCriteria = new BasicDBObject();
			if(null != solrSearchTexts && !solrSearchTexts.isEmpty())
			{
				solrCriteria = inquiryDao.callSolrSearchCriteria(solrSearchTexts, soeId, inputJsonObj);
			}
			Set<Long> userGroupsList = userDao.getUserGroupsList(soeId);
			DBObject assignedGroupCriteria = null;
			DBObject advanceSearchCriteria = null;
			advanceSearchCriteria = inquiryDao.createPreSolrMongoDBObjectForAdvanceSearch(advanceSearchInput, viewName);
			
			BasicDBObject advancedSearchDateQuery = null;
			if(null != advanceSearchInput && null != advanceSearchInput.get("startDt") && null != advanceSearchInput.get("endDt")) {
				advancedSearchDateQuery = inquiryDao.getAdvancedSearchDateQuery(inputJsonObj, new BasicDBObject());
			}
			
			List<Long> advSearchGroupIds = null;
			if(null != advanceSearchInput && null != advanceSearchInput.get("assignedGroupIdList")) {//<-- sonar fix null pointer
				advSearchGroupIds = (List<Long>) advanceSearchInput.get("assignedGroupIdList");
			}
			
			BasicDBList topCriteria = new BasicDBList();
			BasicDBList versionCriteriaWithoutSolr = new BasicDBList();
			//advance + solr search need more work for streamline getGridViewData query 
			if(null != solrCriteria) {
				assignedGroupCriteria = new BasicDBObject("workflows.assignedGroupId", new BasicDBObject("$in", userGroupsList));
				topCriteria.add(assignedGroupCriteria);
				topCriteria.add(solrCriteria);
				DBObject advanceSearchCopy = null;
				String json = advanceSearchCriteria.toString();
				advanceSearchCopy = BasicDBObject.parse(json);
				versionCriteriaWithoutSolr = (BasicDBList) advanceSearchCopy.get("$and");
				if(null == advSearchGroupIds || advSearchGroupIds.isEmpty()){
					assignedGroupCriteria = new BasicDBObject("workflows.assignedGroupId", new BasicDBObject("$in", userGroupsList));
					versionCriteriaWithoutSolr.add(assignedGroupCriteria);
				}
				if(null != advancedSearchDateQuery) {
					//topCriteria.add(advancedSearchDateQuery);
					versionCriteriaWithoutSolr.add(advancedSearchDateQuery);
				}
			}
			//only advance search
			else if(null != advanceSearchCriteria) {
				String json = advanceSearchCriteria.toString();
				DBObject advanceSearchCopy = null;
				advanceSearchCopy = BasicDBObject.parse(json);
				topCriteria = (BasicDBList) advanceSearchCriteria.get("$and");
				versionCriteriaWithoutSolr = (BasicDBList) advanceSearchCopy.get("$and");
				if(null == advSearchGroupIds || advSearchGroupIds.isEmpty()){
					assignedGroupCriteria = new BasicDBObject("workflows.assignedGroupId", new BasicDBObject("$in", userGroupsList));
					topCriteria.add(assignedGroupCriteria);
					versionCriteriaWithoutSolr.add(assignedGroupCriteria);
				}
				if(null != advancedSearchDateQuery) {
					topCriteria.add(advancedSearchDateQuery);
					versionCriteriaWithoutSolr.add(advancedSearchDateQuery);
				}
			}
			
			BasicDBObject topMatchCriteria = new BasicDBObject();
			topMatchCriteria.append("$match", new BasicDBObject("$and",topCriteria));
			queryList = new ArrayList<>();
			queryList.add(topMatchCriteria);
			
			BasicDBObject unwind = new BasicDBObject("$unwind","$workflows");
			queryList.add(unwind);
			
			BasicDBObject versionCriteria = new BasicDBObject();
			versionCriteria.append("$match", new BasicDBObject("$and",versionCriteriaWithoutSolr));
			queryList.add(versionCriteria);
	
		} catch (CommunicatorException e) {
			inqExtLogger.error("Exception in getAdvanceSearchQuery for soeId : "+soeId, e);
			queryList = null;
		}
		return queryList;
	}

	/**
	 * @param totalCount
	 * @param tagQuery
	 * @return
	 */
	private  BasicDBObject fetchTotalCount(List<BasicDBObject> finalQuery, String soeId) {
		BasicDBObject result = new BasicDBObject();
		int totalCount = 0;
		int totalReadCount = 0;
		DBCollection col = MongoDB.instance().getDB().getCollection("Inquiry");
		AggregationOptions options = AggregationOptions.builder().allowDiskUse(true).build();
		Cursor cur = col.aggregate(finalQuery, options, ReadPreference.secondary());
		while (cur.hasNext()) {
			BasicDBObject outputResult = (BasicDBObject) cur.next();
			totalCount = null!=outputResult && null!=outputResult.get("TOTAL_COUNT") ? outputResult.getInt("TOTAL_COUNT") : 0;
			totalReadCount = null!=outputResult && null!=outputResult.get("TOTAL_READ_COUNT") ? outputResult.getInt("TOTAL_READ_COUNT") : 0;
		}
		result.put("totalRecords", totalCount);
		result.put("totalUnreadRecords", totalCount-totalReadCount);
		inqExtLogger.info("InquiryExtendedDAO fetchTotalCount",result);
		return result;
	}
	/**
	 * @param inputJsonObj
	 * @param soeId
	 * @param viewName
	 * @return
	 */
	private List<BasicDBObject> getTagViewQuery(BasicDBObject inputJsonObj, String soeId, String viewName) {
		try {
			String groupName = inputJsonObj.getString("groupName");
			Long groupId = null;
			if (!StringUtils.isBlank(groupName))
			{
				groupId = QMACacheFactory.getCache().getGroupCodeToIdMap().get(groupName.toUpperCase());
			}
			else
			{
				inqExtLogger.info("Invalid Input for getTagViewQuery - by " + soeId + " for group name " + groupName);
			}

			if (groupId == null)
			{
				inqExtLogger.info("groupId not found in cache for groupName -" + groupName);
			}
			// Load data specific the group data
			if (groupId != null)
			{
				String query = QueryConstants.TAG_VIEW_QUERY;
				query = query.replaceAll("#GROUPID#", groupId.toString());
				query = query.replace("#TAGNAME#", viewName);
				@SuppressWarnings({ "deprecation", "unchecked" })
				List<BasicDBObject> queryList = DataConversionUtil.createAggregatePipelines(DataConversionUtil.prepareAggregatePipelineStrQuery(query));
				return queryList;
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in getTagViewQuery for soeId : "+soeId);
		}
		return null;
	}
	/**
	 * @param inputJsonObj
	 * @param soeId
	 * @param viewName
	 * @param solrSearchText
	 * @return
	 */
	private List<BasicDBObject> getSolrSearchQuery(BasicDBObject inputJsonObj, String soeId, String viewName, String solrSearchText) {
		List<BasicDBObject> queryList = null;
		try {
			HashMap<String, List<String>> solrQueryMap = inquiryDao.createSolrQuery(inputJsonObj, soeId);
			List<String> solrSearchTexts = solrQueryMap.get("solrQuery");
			DBObject solrCriteria = inquiryDao.callSolrSearchCriteria(solrSearchTexts, soeId, inputJsonObj);
			Set<Long> userGroupsList = userDao.getUserGroupsList(soeId);
			if (solrCriteria == null)
			{
				return null;
			}
			BasicDBObject assignedGroupCriteria = new BasicDBObject("workflows.assignedGroupId", new BasicDBObject("$in", userGroupsList)); 
			BasicDBList topCriteria = new BasicDBList();
			topCriteria.add(assignedGroupCriteria);
			topCriteria.add(solrCriteria);
			BasicDBObject topMatchCriteria = new BasicDBObject();
			topMatchCriteria.append("$match", new BasicDBObject("$and", topCriteria));
			queryList = new ArrayList<>();
			queryList.add(topMatchCriteria);
			BasicDBObject unwind = new BasicDBObject("$unwind","$workflows");
			queryList.add(unwind);
			BasicDBObject versionCriteria = new BasicDBObject();
			versionCriteria.append("$match", assignedGroupCriteria);
			queryList.add(versionCriteria);
			
		} catch (Exception e) {
			inqExtLogger.error("Exception in getSolrSearchQuery for soeId : "+soeId, e);
			queryList = null;
		}
		return queryList;
	}
	
	public void removeNominationFieldFromWorkflow(DBObject workflowObj, DBObject unsetFieldObject,
			Long inquiryId, Long groupId, String soeId) {
		inqExtLogger.info("Inside removeNominationFieldFromWorkflow for inquiryId: "+inquiryId+" :group: "+groupId+" soeId: "+soeId );
		try {
			if(null != workflowObj && null != unsetFieldObject) {
				workflowObj.put("workflows.$.hasNominatedOwnership", false);
				unsetFieldObject.put("workflows.$.nominatedBy", null);
				unsetFieldObject.put("workflows.$.nominatedTo", null);
				unsetFieldObject.put("workflows.$.nominatingReason", null);
				unsetFieldObject.put("workflows.$.nominationRejectionReason", null);
				unsetFieldObject.put("workflows.$.snoozeAction", null);
				unsetFieldObject.put("workflows.$.ownershipAcceptedTime", null);
			}
		} catch (Exception e) {
			inqExtLogger.error("Exception in removeNominationFieldFromWorkflow for soeId : "+soeId, e);
		}
		
		
	}

	/**
	 * This method will update the preview text only in TO
	 * @param conversation
	 * @param inquiry
	 * @param groupId
	 * @param isPersonal
	 */
	public void updateConversationContentPreviewInTO(Conversation conversation, Inquiry inquiry, Long groupId, boolean isPersonal) {
		updateConversationContentPreview(conversation,inquiry,groupId,false,isPersonal);
	}

	/**
	 * This method will update the preview text in TO as well as in DB
	 * @param conversation
	 * @param inquiry
	 * @param groupId
	 * @param isPersonal
	 */
	public void updateConversationContentPreviewInDB(Conversation conversation, Inquiry inquiry,Long groupId, boolean isPersonal) {
		updateConversationContentPreview(conversation,inquiry,groupId,true, isPersonal);
	}

	/**
	 * This method will extract and update the preview text.
	 * @param conversation
	 * @param inquiry
	 * @param groupId
	 * @param saveToDb
	 * @param isPersonal
	 */
	private void updateConversationContentPreview(Conversation conversation, Inquiry inquiry, Long groupId,boolean saveToDb, boolean isPersonal) {
		try {
			if(null!= conversation && StringUtils.isNotEmpty(GenericUtility.checkAndFetchConvContent(conversation)) && null != inquiry) {
				int noOfWords = (Integer) getAIMLProcessingConfig("noOfWordsToExtract");
				String contentExtractionEndPoint = (String) getAIMLProcessingConfig("previewTextExtractionEndPoint");

				int previewTextCharLength = (Integer) getAIMLProcessingConfig("previewTextCharLength");
				String latestContent = getLatestConversationContents(GenericUtility.checkAndFetchConvContent(conversation),noOfWords,contentExtractionEndPoint);
				inqExtLogger.info("Latest content extracted for inq : {} and conv : {} is : {}", inquiry.getId(),conversation.getId(),latestContent);
				if(StringUtils.isNotEmpty(latestContent)) {
					BasicDBObject result = BasicDBObject.parse(latestContent);
					if(null!= result && result.containsField("return_code") && result.getString("return_code").equalsIgnoreCase("200")) {
						String previewText = result.getString("result");
						if(StringUtils.isNotEmpty(previewText) && previewText.length() >= previewTextCharLength && !isPersonal && previewTextCharLength > 0) {
							previewText = previewText.substring(0,previewTextCharLength);
						}
						inqExtLogger.info("Setting '{}' as preview text for inq : {} conv : {}",conversation.getInquiryId(), conversation.getId());
						conversation.setConversationPreviewText(previewText);
						updateInquiryTO(inquiry,previewText,groupId, isPersonal);
						if(saveToDb) {
							updateConversationInDB(conversation,previewText);
							updateInquiryInDB(inquiry,previewText);
						}
					} else {
						inqExtLogger.info("Failed to extract preview text for inq : {}, conv : {} ",conversation.getInquiryId(), conversation.getId());
						conversation.setConversationPreviewText("");
						updateInquiryTO(inquiry,"",groupId, isPersonal);
					}
				} else {
					inqExtLogger.warn("Failed to extract latest conversation content");
					conversation.setConversationPreviewText("");
					updateInquiryTO(inquiry,"",groupId, isPersonal);
				}
			} else {
				inqExtLogger.warn("No conversation or content found for updating latest conversation contents for conv {}, inq {}, userGroupId : {}.", (null == conversation ? conversation: conversation.getId()), (null == inquiry ? inquiry : inquiry.getId()),groupId);//<-- sonar fix null pointer
			}
		} catch (Exception e) {
			inqExtLogger.warn("Exception while updating latest conversation content :",e);
			if(null != conversation) {
				conversation.setConversationPreviewText("");
			}
			updateInquiryTO(inquiry,"",groupId, isPersonal);
		}
	}


	/**
	 * This method updates preview text in the workflow
	 * @param inquiry
	 * @param previewText
	 * @param groupId
	 * @param isPersonal
	 */
	private void updateInquiryTO(Inquiry inquiry, String previewText, Long groupId, boolean isPersonal) {
		if(null != inquiry && null!= inquiry.getWorkflows() && !inquiry.getWorkflows().isEmpty() && null!= groupId) {
			for (Workflow workflow : inquiry.getWorkflows()) {
				//No check of workflow parameters are made as this is currently used only for personal.
				//If needs to be used for team/shared, need to use isPersonal param for workflow update
				if (null != workflow && null!= workflow.getAssignedGroupId() && workflow.getAssignedGroupId().equals(groupId)) {
					workflow.setLatestConversationPreviewText(previewText);
				}
			}
		} else {
			inqExtLogger.warn("No workflow found for Inquiry : {} to update preview text :",(null == inquiry ? inquiry : inquiry.getId()));//<-- sonar fix null pointer
		}
	}

	/**
	 * This method will get the aiml config
	 * @param key
	 * @return
	 */
	private Object getAIMLProcessingConfig(String key) {
		Object value = null;
		if(StringUtils.isNotEmpty(key)){
			Config aimlProcessingConfig = QMACacheFactory.getCache().getConfigById("aimlProcessingConfig");
			if(null!=aimlProcessingConfig && null != aimlProcessingConfig.getAimlProcessingConfig()) {
				Map<String, Object> aimlProcessingConfigMap = aimlProcessingConfig.getAimlProcessingConfig();
				if(aimlProcessingConfigMap.containsKey(key) && null != aimlProcessingConfigMap.get(key)) {
					value = aimlProcessingConfigMap.get(key);
				} else {
					inqExtLogger.warn("Provided key {} not found in the aiml processing config.", key);
				}
			} else {
				inqExtLogger.warn("AIML processing config not found in the cache.");
			}
		} else {
			inqExtLogger.warn("Provided key {} can not be null or empty to lookup in aiml processing config",key);
		}
		return value;
	}

	/**
	 * This method update conversation preview text in database.
	 * @param conversation
	 * @param previewText
	 */
	private void updateConversationInDB(Conversation conversation,String previewText) {
		try {
			Query<Conversation> query = MongoDB.instance().getDataStore().createQuery(Conversation.class)
					.filter("_id", conversation.getId());
			Conversation conv = query.first();
			if(null != conv) {
				UpdateOperations<Conversation> updateOps = MongoDB.instance().getDataStore().createUpdateOperations(Conversation.class);
				updateOps.set("conversationPreviewText", previewText);
				MongoDB.instance().getDataStore().update(query, updateOps);
			}
		} catch (Exception e) {
			inqExtLogger.warn("Exception while updating conversation preview text in db for conv : {} and inq : {} :",conversation.getId(),conversation.getInquiryId(), e);
		}
	}

	/**
	 * This method updates conversation preview text in the inquiry workflow in DB
	 * @param inquiry
	 * @param previewText
	 */
	private void updateInquiryInDB(Inquiry inquiry,String previewText) {
		try {
			Query<Inquiry> query = MongoDB.instance().getDataStore().createQuery(Inquiry.class)
					.filter("_id", inquiry.getId());
			Inquiry inq = query.first();
			if(null != inq) {
				UpdateOperations<Inquiry> updateOps = MongoDB.instance().getDataStore().createUpdateOperations(Inquiry.class);
				updateOps.set("workflows", inquiry.getWorkflows());
				MongoDB.instance().getDataStore().update(query, updateOps);
			}
		} catch (Exception e) {
			inqExtLogger.warn("Exception while updating Inquiry workflows in db for preview text for inquiry : {} :",inquiry.getId(), e);
		}
	}

	/**
	 * This method gets the conversation preview text by calling endpoint
	 * @param content
	 * @param noOfWords
	 * @param endPoint
	 * @return
	 * @throws Exception
	 */
	private String getLatestConversationContents(String content, int noOfWords,String endPoint) throws Exception {
		String result = null;
		HttpClient httpClient = HttpClientBuilder.create().build();
		if( httpClient != null ) {
			HttpPost postRequest = new HttpPost(endPoint);
			StringEntity input = buildStringEntity(content,noOfWords);
			postRequest.setEntity(input);
			postRequest.setHeader(new BasicHeader("Content-Type","application/json"));
			HttpResponse response = null;
			try {
				response = httpClient.execute(postRequest);
			} catch (IOException e) {
				inqExtLogger.warn("Request is not successful, status code :{}", (null != response && null != response.getStatusLine() ) ?
						response.getStatusLine().getStatusCode() : "N/A");
				throw e;
			}

			if (null != response && null != response.getStatusLine() && response.getStatusLine().getStatusCode() != 200) {
				inqExtLogger.warn("Request is not successful, status code :{}", response.getStatusLine().getStatusCode());
			} else {
				HttpEntity entity = response.getEntity();
				result = extractResponse(entity);
			}
		}
		return  result;
	}

	/**
	 * This method adds input parameters to the request
	 * @param content
	 * @param noOfWords
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	private StringEntity buildStringEntity(String content, int noOfWords) throws UnsupportedEncodingException {

		BasicDBObject inputParams= new BasicDBObject();

		inputParams.put("email_content",content);

		inputParams.put("number_of_words",noOfWords);

		return new StringEntity(inputParams.toJson());
	}

	/**
	 * This method extracts preview text from the response
	 * @param entity
	 * @return
	 * @throws Exception
	 */
	private String extractResponse( HttpEntity entity) throws Exception {
		StringBuilder content = new StringBuilder();
		if (entity != null) {
			byte[] buffer = new byte[1024];
			InputStream inputStream = null;
			try {
				inputStream = entity.getContent();
			} catch (UnsupportedOperationException | IOException e) {
				inqExtLogger.error("Exception while extracting response",e);
				throw new Exception(e.getCause());
			}
			try(BufferedInputStream bis = new BufferedInputStream(inputStream)){
				int bytesRead = 0;
				while ((bytesRead = bis.read(buffer)) != -1) {
					String chunk = new String(buffer, 0, bytesRead);
					content.append(chunk);
				}
			} catch (Exception e) {
				inqExtLogger.error(" Error in InquiryExtendedDAO#extractResponse() :", e);
				throw new Exception(e.getMessage());
			}
		} else {
			inqExtLogger.warn("Received either 'null' or 'empty' response from aiml-service.");
		}
		return content.toString();
	}
}
