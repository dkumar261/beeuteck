package com.citi.icg.qma.common.server.dao;

import java.util.List;

import com.google.gson.annotations.SerializedName;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;

@Entity(value = "ManagementHeirarchy", noClassnameStored = true)
public class ManagementHeirarchtColl
{
	@Id
	@SerializedName("_id")
	private Long id;
	private List<String> organisation;
	private List<UserDetail> firstLevelHeirarchy;
	private List<UserDetail> secondLevelHeirarchy;
	private List<String> gfcid;
	/**
	 * @return the id
	 */
	public Long getId()
	{
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Long id)
	{
		this.id = id;
	}
	/**
	 * @return the organisation
	 */
	public List<String> getOrganisation()
	{
		return organisation;
	}
	/**
	 * @param organisation the organisation to set
	 */
	public void setOrganisation(List<String> organisation)
	{
		this.organisation = organisation;
	}
	/**
	 * @return the firstLevelHeirarchy
	 */
	public List<UserDetail> getFirstLevelHeirarchy()
	{
		return firstLevelHeirarchy;
	}
	/**
	 * @param firstLevelHeirarchy the firstLevelHeirarchy to set
	 */
	public void setFirstLevelHeirarchy(List<UserDetail> firstLevelHeirarchy)
	{
		this.firstLevelHeirarchy = firstLevelHeirarchy;
	}
	/**
	 * @return the secondLevelHeirarchy
	 */
	public List<UserDetail> getSecondLevelHeirarchy()
	{
		return secondLevelHeirarchy;
	}
	/**
	 * @param secondLevelHeirarchy the secondLevelHeirarchy to set
	 */
	public void setSecondLevelHeirarchy(List<UserDetail> secondLevelHeirarchy)
	{
		this.secondLevelHeirarchy = secondLevelHeirarchy;
	}
	
	/**
	 * @return the gfcid
	 */
	public List<String> getGfcid()
	{
		return gfcid;
	}
	/**
	 * @param gfcid the gfcid to set
	 */
	public void setGfcid(List<String> gfcid)
	{
		this.gfcid = gfcid;
	}
	/**
	 * @param id
	 * @param organisation
	 * @param firstLevelHeirarchy
	 * @param secondLevelHeirarchy
	 * @param thirdLevelHeirarchy
	 * @param gfcid
	 */
	public ManagementHeirarchtColl(Long id, List<String> organisation, List<UserDetail> firstLevelHeirarchy, List<UserDetail> secondLevelHeirarchy,	List<String> gfcid)
	{
		super();
		this.id = id;
		this.organisation = organisation;
		this.firstLevelHeirarchy = firstLevelHeirarchy;
		this.secondLevelHeirarchy = secondLevelHeirarchy;
		this.gfcid = gfcid;
	}
	
	public ManagementHeirarchtColl()
	{
		
	}
	
}
