package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

import dev.morphia.annotations.Embedded;

@Embedded
public class HrHierarchy implements Serializable
{
	private static final long serialVersionUID = 6674132568363506360L;

	// User details.
	HrHierarchyUserDetail user;
	int maxLevelCount;

	// User manager details till level 9th.
	HrHierarchyUserDetail level1;
	HrHierarchyUserDetail level2;
	HrHierarchyUserDetail level3;
	HrHierarchyUserDetail level4;
	HrHierarchyUserDetail level5;
	HrHierarchyUserDetail level6;
	HrHierarchyUserDetail level7;
	HrHierarchyUserDetail level8;
	HrHierarchyUserDetail level9;
	HrHierarchyUserDetail level10;
	HrHierarchyUserDetail level11;
	HrHierarchyUserDetail level12;
	HrHierarchyUserDetail level13;
	HrHierarchyUserDetail level14;
	HrHierarchyUserDetail level15;

	public HrHierarchy()
	{
		super();
	}

	/**
	 * @return the user
	 */
	public HrHierarchyUserDetail getUser()
	{
		return user;
	}

	/**
	 * @param user
	 *            the user to set
	 */
	public void setUser(HrHierarchyUserDetail user)
	{
		this.user = user;
	}

	/**
	 * @return the level1
	 */
	public HrHierarchyUserDetail getLevel1()
	{
		return level1;
	}

	/**
	 * @param level1
	 *            the level1 to set
	 */
	public void setLevel1(HrHierarchyUserDetail level1)
	{
		this.level1 = level1;
	}

	/**
	 * @return the level2
	 */
	public HrHierarchyUserDetail getLevel2()
	{
		return level2;
	}

	/**
	 * @param level2
	 *            the level2 to set
	 */
	public void setLevel2(HrHierarchyUserDetail level2)
	{
		this.level2 = level2;
	}

	/**
	 * @return the level3
	 */
	public HrHierarchyUserDetail getLevel3()
	{
		return level3;
	}

	/**
	 * @param level3
	 *            the level3 to set
	 */
	public void setLevel3(HrHierarchyUserDetail level3)
	{
		this.level3 = level3;
	}

	/**
	 * @return the level4
	 */
	public HrHierarchyUserDetail getLevel4()
	{
		return level4;
	}

	/**
	 * @param level4
	 *            the level4 to set
	 */
	public void setLevel4(HrHierarchyUserDetail level4)
	{
		this.level4 = level4;
	}

	/**
	 * @return the level5
	 */
	public HrHierarchyUserDetail getLevel5()
	{
		return level5;
	}

	/**
	 * @param level5
	 *            the level5 to set
	 */
	public void setLevel5(HrHierarchyUserDetail level5)
	{
		this.level5 = level5;
	}

	/**
	 * @return the level6
	 */
	public HrHierarchyUserDetail getLevel6()
	{
		return level6;
	}

	/**
	 * @param level6
	 *            the level6 to set
	 */
	public void setLevel6(HrHierarchyUserDetail level6)
	{
		this.level6 = level6;
	}

	/**
	 * @return the level7
	 */
	public HrHierarchyUserDetail getLevel7()
	{
		return level7;
	}

	/**
	 * @param level7
	 *            the level7 to set
	 */
	public void setLevel7(HrHierarchyUserDetail level7)
	{
		this.level7 = level7;
	}

	/**
	 * @return the level8
	 */
	public HrHierarchyUserDetail getLevel8()
	{
		return level8;
	}

	/**
	 * @param level8
	 *            the level8 to set
	 */
	public void setLevel8(HrHierarchyUserDetail level8)
	{
		this.level8 = level8;
	}

	/**
	 * @return the level9
	 */
	public HrHierarchyUserDetail getLevel9()
	{
		return level9;
	}

	/**
	 * @param level9
	 *            the level9 to set
	 */
	public void setLevel9(HrHierarchyUserDetail level9)
	{
		this.level9 = level9;
	}

	

	/**
	 * @return the maxLevelCount
	 */
	public int getMaxLevelCount()
	{
		return maxLevelCount;
	}

	/**
	 * @param maxLevelCount the maxLevelCount to set
	 */
	public void setMaxLevelCount(int maxLevelCount)
	{
		this.maxLevelCount = maxLevelCount;
	}

	/**
	 * @return the level10
	 */
	public HrHierarchyUserDetail getLevel10()
	{
		return level10;
	}

	/**
	 * @param level10 the level10 to set
	 */
	public void setLevel10(HrHierarchyUserDetail level10)
	{
		this.level10 = level10;
	}

	/**
	 * @return the level11
	 */
	public HrHierarchyUserDetail getLevel11()
	{
		return level11;
	}

	/**
	 * @param level11 the level11 to set
	 */
	public void setLevel11(HrHierarchyUserDetail level11)
	{
		this.level11 = level11;
	}

	/**
	 * @return the level12
	 */
	public HrHierarchyUserDetail getLevel12()
	{
		return level12;
	}

	/**
	 * @param level12 the level12 to set
	 */
	public void setLevel12(HrHierarchyUserDetail level12)
	{
		this.level12 = level12;
	}

	/**
	 * @return the level13
	 */
	public HrHierarchyUserDetail getLevel13()
	{
		return level13;
	}

	/**
	 * @param level13 the level13 to set
	 */
	public void setLevel13(HrHierarchyUserDetail level13)
	{
		this.level13 = level13;
	}

	/**
	 * @return the level14
	 */
	public HrHierarchyUserDetail getLevel14()
	{
		return level14;
	}

	/**
	 * @param level14 the level14 to set
	 */
	public void setLevel14(HrHierarchyUserDetail level14)
	{
		this.level14 = level14;
	}

	/**
	 * @return the level15
	 */
	public HrHierarchyUserDetail getLevel15()
	{
		return level15;
	}

	/**
	 * @param level15 the level15 to set
	 */
	public void setLevel15(HrHierarchyUserDetail level15)
	{
		this.level15 = level15;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return "HrHierarchy [user=" + user + ", maxLevelCount=" + maxLevelCount + ", level1=" + level1 + ", level2=" + level2 + ", level3=" + level3 + ", level4=" + level4 + ", level5=" + level5
				+ ", level6=" + level6 + ", level7=" + level7 + ", level8=" + level8 + ", level9=" + level9 + ", level10=" + level10 + ", level11=" + level11 + ", level12=" + level12 + ", level13="
				+ level13 + ", level14=" + level14 + ", level15=" + level15 + "]";
	}
	
	
}