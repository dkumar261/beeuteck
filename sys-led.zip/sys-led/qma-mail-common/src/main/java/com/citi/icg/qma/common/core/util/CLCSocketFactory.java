package com.citi.icg.qma.common.core.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

import com.citi.icg.qma.common.server.util.GenericUtility;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.hazelcast.cache.client.QMACache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;

public final class CLCSocketFactory {
	
	private static final String TEMP_CLC_CERT_FILE_PKCS12 = "tempClcCertFile.pkcs12";

	private static SSLConnectionSocketFactory socketFactory = null;
	
	private static final Logger subLogger = LoggerFactory.getLogger(CLCSocketFactory.class);
	
	
	private static final String CERT_CONF_KEY = "certConf";
	private static final String CERT_FILENAME_KEY = "certFileName";
	private static final String CERT_PASSWORD_KEY = "certPassword";
	private static final String TRUST_STORE_PASSWORD_KEY = "trustStorePassword";
	private static final String CERT_LOCATION = "conf/";
	private static final String SSL_TRUST_STORE_KEY = "javax.net.ssl.trustStore";
	private static final String CONFIG_CLC_CONFIGURATION_KEY = "clcConfiguration";
	
	private CLCSocketFactory(){
		
	}
	
	/**
	 * This method provides singleton instance of SSLConnectionSocketFactory
	 * @return
	 */
	public static synchronized SSLConnectionSocketFactory getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		
				if (socketFactory == null) {
					try {
						String certFileName = CERT_LOCATION + getCLCCertConfig(CERT_FILENAME_KEY);
						String certPassword = getCLCCertConfig(CERT_PASSWORD_KEY);
						String trustStorePassword = getCLCCertConfig(TRUST_STORE_PASSWORD_KEY);
						
						String xmcEnvironment = System.getProperty(AppserverConstants.ENV_PARAM_KEY);
						
						if(StringUtils.isNotEmpty(certFileName) && StringUtils.isNotEmpty(certPassword)) {
							subLogger.info("CLC :: ENV : {}, CLC CERT FILE : {}, CLC CERT ALIAS : {} TRUST STORE ALIAS : {}",xmcEnvironment,certFileName,certPassword, trustStorePassword );

							String trustStoreFilePath = System.getProperty(SSL_TRUST_STORE_KEY);
							if(StringUtils.isNotBlank(trustStoreFilePath) && GenericUtility.isValidCertificatePath(trustStoreFilePath)){
							File trustStoreFile =  new File(trustStoreFilePath);
							
							File file = new File(Thread.currentThread().getContextClassLoader().getResource(certFileName).getFile());
							subLogger.info("cert file       : [{}]", file.getAbsolutePath());
							subLogger.info("trustStore file : [{}]", trustStoreFile.getAbsolutePath());
							SSLContextBuilder sslContextBuilder = SSLContextBuilder
					                .create()
					                .loadKeyMaterial(file, certPassword.toCharArray(), certPassword.toCharArray())
					                .loadTrustMaterial(trustStoreFile, trustStorePassword.toCharArray());
							
							socketFactory = new SSLConnectionSocketFactory(sslContextBuilder.build());
							
							subLogger.info("CLC :: Environment is :{} using SSL enabled HttpClient.",xmcEnvironment);
							}else{
								subLogger.info("CLC :: Environment is :{} No valid Trust Store Configuration",xmcEnvironment);
							}
						} else {
							subLogger.info("CLC :: Environment is :{} Not able to identify certificate paramteres from database.",xmcEnvironment);
						} 
					} catch (Exception e) {
						subLogger.error("CLC :: Error while creating http client in CLCOperationsDAO#getHttpClientSSLEnabled() : ",e);
					}
				}
			
		return socketFactory;
	}
	
	public static synchronized SSLConnectionSocketFactory getInstanceForScheduler() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		
				if (socketFactory == null) {
					try {
						String certFileName = CERT_LOCATION + getCLCCertConfig(CERT_FILENAME_KEY);
						String certPassword = getCLCCertConfig(CERT_PASSWORD_KEY);
						String trustStorePassword = getCLCCertConfig(TRUST_STORE_PASSWORD_KEY);
						
						String xmcEnvironment = System.getProperty(AppserverConstants.ENV_PARAM_KEY);
						
						if(StringUtils.isNotEmpty(certFileName) && StringUtils.isNotEmpty(certPassword)) {
							subLogger.info("CLC :: ENV : {}, CLC CERT FILE : {}, CLC CERT ALIAS : {} TRUST STORE ALIAS : {}",xmcEnvironment,certFileName,certPassword, trustStorePassword);
							String trustStoreFilePath = System.getProperty(SSL_TRUST_STORE_KEY);
							if(StringUtils.isNotBlank(trustStoreFilePath) && GenericUtility.isValidCertificatePath(trustStoreFilePath)){
							File trustStoreFile =  new File(trustStoreFilePath);
							
							File file = new File(TEMP_CLC_CERT_FILE_PKCS12);
							try(OutputStream outputStream = new FileOutputStream(file)){
								InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(certFileName);
								IOUtils.copy(is, outputStream);
								is.close();
							}catch (Exception e) {   
							   subLogger.error("Exception while reading file from classpath",e);
							} 
							subLogger.info("cert file       : [{}]", file.getAbsolutePath());
							subLogger.info("trustStore file : [{}]", trustStoreFile.getAbsolutePath());
							SSLContextBuilder sslContextBuilder = SSLContextBuilder
					                .create()
					                .loadKeyMaterial(file, certPassword.toCharArray(), certPassword.toCharArray())
					                .loadTrustMaterial(trustStoreFile, trustStorePassword.toCharArray());
							
							socketFactory = new SSLConnectionSocketFactory(sslContextBuilder.build());
							file.delete();
							subLogger.info("CLC :: Environment is :{} using SSL enabled HttpClient.",xmcEnvironment);
							}else{
								subLogger.info("CLC :: Environment is :{} No Trust Store Configuration",xmcEnvironment);
							}
						} else {
							subLogger.info("CLC :: Environment is :{} Not able to identify certificate paramteres from database.",xmcEnvironment);
						} 
					} catch (Exception e) {
						subLogger.error("CLC :: Error while creating http client in CLCOperationsDAO#getHttpClientSSLEnabled() : ",e);
					}
				}
			
		return socketFactory;
	}
	/**
	 * 
	 * This method retrieves certificate configuration params
	 * @param key
	 * @return
	 */
	private static String getCLCCertConfig(String key) {
		String value = "";
		Map<String, String> certConfig = (Map<String, String>) getCLCConfigForKey(CERT_CONF_KEY);
		if(certConfig!=null && !certConfig.isEmpty() && certConfig.containsKey(key)){
			value = certConfig.get(key);
		}
		return value;
	}
	
	/**
	 * This function provide value from CLC config for requested key
	 * @param key
	 * @return Object
	 */
	private static Object getCLCConfigForKey(String key) {
		Object value = null;
		Map<String, Object> clcConfig = null;
		try {
			QMACache qmaCache = QMACacheFactory.getCache();
			if(null != qmaCache.getConfigById(CONFIG_CLC_CONFIGURATION_KEY)) {
				clcConfig = qmaCache.getConfigById(CONFIG_CLC_CONFIGURATION_KEY).getClcConfiguration();
			}
			if( clcConfig != null && !StringUtils.isEmpty(key) ) {
				value = clcConfig.get(key);
			}
		} catch (Exception e) {
			subLogger.error("Error while retrieving value from CLC config :" , e );
		}
		return value;
	}

}
