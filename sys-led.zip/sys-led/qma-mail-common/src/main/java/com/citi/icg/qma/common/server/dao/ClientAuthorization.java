/**
 * 
 */
package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.List;

import dev.morphia.annotations.Embedded;

/**
 * 
 *
 */
@Embedded
public class ClientAuthorization implements Serializable {
	private String clientId; 
	private String clientSecretKey;
	private String qmaHandshakePwd; 
	private String clientSecretIV;
	private List<String> authorizedAPI;
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getClientSecretKey() {
		return clientSecretKey;
	}
	public void setClientSecretKey(String clientSecretKey) {
		this.clientSecretKey = clientSecretKey;
	}
	public String getQmaHandshakePwd() {
		return qmaHandshakePwd;
	}
	public void setQmaHandshakePwd(String qmaHandshakePwd) {
		this.qmaHandshakePwd = qmaHandshakePwd;
	}
	public String getClientSecretIV() {
		return clientSecretIV;
	}
	public void setClientSecretIV(String clientSecretIV) {
		this.clientSecretIV = clientSecretIV;
	}
	public List<String> getAuthorizedAPI() {
		return authorizedAPI;
	}
	public void setAuthorizedAPI(List<String> authorizedAPI) {
		this.authorizedAPI = authorizedAPI;
	}
}
