package com.citi.icg.qma.exception;

public class QMAMessageException extends Exception {

	private static final long serialVersionUID = -5095048295029561957L;

	/**
	 * @param message
	 * @param cause
	 */
	public QMAMessageException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public QMAMessageException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public QMAMessageException(Throwable cause) {
		super(cause);
	}
	
	
	

}
