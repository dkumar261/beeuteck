package com.citi.icg.qma.common.transferobject;

import com.citi.icg.qma.dao.ProcessingStatus;

import java.util.Date;

public class MessageReplayTO {
    private String guid;
    private String messageId;
    private String mailboxName;
    private Date createDate;
    private Date modDate;
    private ProcessingStatus processingStatus;

    private String gridFSFilename;
    private String gridFSId;

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getMailboxName() {
        return mailboxName;
    }

    public void setMailboxName(String mailboxName) {
        this.mailboxName = mailboxName;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getModDate() {
        return modDate;
    }

    public void setModDate(Date modDate) {
        this.modDate = modDate;
    }

    public ProcessingStatus getProcessingStatus() {
        return processingStatus;
    }

    public void setProcessingStatus(ProcessingStatus processingStatus) {
        this.processingStatus = processingStatus;
    }

    public String getGridFSFilename() {
        return gridFSFilename;
    }

    public void setGridFSFilename(String gridFSFilename) {
        this.gridFSFilename = gridFSFilename;
    }

    public String getGridFSId() {
        return gridFSId;
    }

    public void setGridFSId(String gridFSId) {
        this.gridFSId = gridFSId;
    }

}

