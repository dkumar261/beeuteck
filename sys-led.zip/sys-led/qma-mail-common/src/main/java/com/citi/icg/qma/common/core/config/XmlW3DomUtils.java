package com.citi.icg.qma.common.core.config;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XmlW3DomUtils
{
	private static final String PATH_SEP = "/";
	private static final Pattern INDEX = Pattern.compile("(.+)\\[([0-9]+)\\]$");

	private XmlW3DomUtils(){
		//As this class is Util, so added making private constructor.
		//Sonar Fix -- Utility classes should not have public constructors 
	}
	
	/**
	 * return text of an node. aggregates all child text/cdata nodes.
	 */
	public static String getNodeText(Node node)
	{
		short nodeType = node.getNodeType();
		if (nodeType == Node.TEXT_NODE || nodeType == Node.CDATA_SECTION_NODE)
		{
			return StringUtils.trim(node.getTextContent());
		}
		StringBuilder builder = new StringBuilder();
		NodeList nodeList = node.getChildNodes();
		for (int i = 0; i < nodeList.getLength(); i++)
		{
			Node n = nodeList.item(i);
			if (n.getNodeType() == Node.ELEMENT_NODE)
			{
				return null;
			}
			if (n.getNodeType() == Node.TEXT_NODE || n.getNodeType() == Node.CDATA_SECTION_NODE)
			{
				builder.append(n.getTextContent());
			}
		}
		return builder.toString().trim();
	}

	public static Element getChildByTagName(Node node, String childTagName)
	{
		synchronized (node)
		{
			if (node.getNodeType() != Node.ELEMENT_NODE)
			{
				return null;
			}
			NodeList childs = node.getChildNodes();
			if (childs == null || childs.getLength() == 0)
			{
				return null;
			}
			for (int i = 0; i < childs.getLength(); i++)
			{
				Node n = childs.item(i);
				if (n != null && n.getNodeType() == Node.ELEMENT_NODE)
				{
					Element tag = (Element) n;
					if (tag.getTagName().equals(childTagName))
					{
						return tag;
					}
				}
			}
			return null;
		}
	}

	public static List<Element> getChildElements(Element element)
	{
		List<Element> childs = new ArrayList<>();
		NodeList nodeList = element.getChildNodes();
		for (int i = 0; i < nodeList.getLength(); i++)
		{
			Node n = nodeList.item(i);
			if (Node.ELEMENT_NODE == n.getNodeType())
			{
				childs.add((Element) n);
			}
		}
		return childs;
	}

	public static Node selectSingleNode(Document document, String selector)
	{
		Element node = document.getDocumentElement();
		String[] toks = selector.split(PATH_SEP);
		if (toks.length <= 2 || !node.getNodeName().equals(toks[1]))
		{
			// the selector path is not starting from with root "/"
			return null;
		}
		for (int i = 2; i < toks.length; i++)
		{
			String nodeName = toks[i];
			int index = 0;
			Matcher m = INDEX.matcher(nodeName);
			if (m.matches())
			{
				nodeName = m.group(1);
				index = Integer.parseInt(m.group(2)) - 1;
			}
			NodeList nodeList = node.getElementsByTagName(nodeName);
			if (nodeList == null || nodeList.getLength() <= index)
			{
				return null;
			}
			node = (Element) nodeList.item(index);
		}
		return node;
	}

	public static String getUniqXPath(Node element)
	{
		StringBuilder builder = new StringBuilder();
		Node current = element;
		while (current != null && current.getNodeType() != Node.DOCUMENT_NODE)
		{
			String tagName = current.getNodeName();
			Node parentNode = current.getParentNode();
			if (parentNode == current)
			{
				break;
			}
			if (parentNode != null && parentNode.getNodeType() == Node.ELEMENT_NODE)
			{
				Element parent = (Element) parentNode;
				NodeList nodeList = parent.getElementsByTagName(tagName);
				if (nodeList.getLength() > 1)
				{
					for (int i = 0; i < nodeList.getLength(); i++)
					{
						if (current.equals(nodeList.item(i)))
						{
							tagName = tagName + "[" + (i + 1) + "]";
							break;
						}
					}
				}
			}
			builder.insert(0, PATH_SEP + tagName);
			current = parentNode;
		}
		return builder.toString();
	}

	public static Map<String, String> getPropertiesValue(Element element)
	{
		Map<String, String> properties = new LinkedHashMap<>();
		NodeList nodeList = element.getChildNodes();
		for (int i = 0; i < nodeList.getLength(); i++)
		{
			Node n = nodeList.item(i);
			if (Node.ELEMENT_NODE != n.getNodeType())
			{
				continue;
			}
			Element nodeElem = (Element) n;
			String key = nodeElem.getTagName();
			if (PROPERTY_TAG.equals(key))
			{
				key = nodeElem.getAttribute(PROPERTY_NAME_ATTR);
			}
			properties.put(key, getNodeText(n));
		}
		return properties;
	}

	public static final String PROPERTY_TAG = "property";
	public static final String PROPERTY_NAME_ATTR = "name";

}
