package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class CustomColumnsView implements Serializable{
	
	private static final long serialVersionUID = 3472962577082494132L;
	private String viewName;
	private List<Map<String, Object>> columnConfig;
	public String getViewName() {
		return viewName;
	}
	public void setViewName(String viewName) {
		this.viewName = viewName;
	}
	public List<Map<String, Object>> getColumnConfig() {
		return columnConfig;
	}
	public void setColumnConfig(List<Map<String, Object>> columnConfig) {
		this.columnConfig = columnConfig;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((viewName == null) ? 0 : viewName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomColumnsView other = (CustomColumnsView) obj;
		if (viewName == null) {
			if (other.viewName != null)
				return false;
		} else if (!viewName.equals(other.viewName))
			return false;
		return true;
	}
	
}
