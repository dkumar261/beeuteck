package com.citi.icg.qma.common.server.dao.persistence;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jakarta.mail.Address;
import jakarta.mail.Message;
import jakarta.mail.Message.RecipientType;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.AddressException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.subscriber.mails.MongoExtInquiryDAO;
import com.citi.icg.qma.common.core.subscriber.mails.entity.Envelope;
import com.citi.icg.qma.common.core.util.QmaMailConstants;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.ConversationRecipient;
import com.citi.icg.qma.common.server.dao.Group;
import com.citi.icg.qma.common.server.dao.IncomingToCcDLAliasMapping;
import com.citi.icg.qma.common.server.dao.MailBoxDLMapping;
import com.citi.icg.qma.common.server.dao.MailBoxDLMapping.MailBoxMappingType;
import com.citi.icg.qma.common.server.util.GenericUtility;
import com.citi.icg.qma.hazelcast.cache.client.QMACache;

/**
 * 
 *
 */
public class ProcessorCommonDAO {
	
	
	private static final Logger logger = LoggerFactory.getLogger(ProcessorCommonDAO.class);
	
	private static ProcessorCommonDAO instance = null;
	
	private static final String DB_BCC_MAIL_BOX_CONFIG_KEY = "bccMailBoxConfig";
	private static final String DB_IS_NEW_BCC_CONFIG_ENABLED_KEY = "isNewBCCConfigEnabled";
	private static final String BCC_PROCESSING_LOG_PREFIX = "### BCC PROCESSING : ";
	public static final String STRING_TO = "TO";
	public static final String STRING_CC = "CC";
	
	private ProcessorCommonDAO(){}
	
	public static synchronized ProcessorCommonDAO getInstance() {//<-- sonar fix added synchronized at method level, for Double-checked locking should not be used
		if (instance == null) {
			instance = new ProcessorCommonDAO();
		}
		return instance;
	}
	
	/**
	 * This method validates if new BCC processing is enabled and a message needs new BCC processing or not
	 * @param messageId
	 * @param msg
	 * @param mailBox
	 * @return boolean
	 */
	public boolean checkIfNeedToBeReProcessedForBCCRecipient(String messageId,MimeMessage msg, String mailBox, QMACache cache) {
		boolean isNewBccProcessingRequired = false;
		Config dbBccMailBoxConfig = cache.getConfigById(DB_BCC_MAIL_BOX_CONFIG_KEY) ;
		Map <String, Object> bccMailBoxConfig = dbBccMailBoxConfig.getBccMailBoxConfig();
		try {
			if( null != cache && null != dbBccMailBoxConfig 
					&& null != bccMailBoxConfig){
				
				boolean isNewBCCConfigEnabled = (boolean) bccMailBoxConfig.get(DB_IS_NEW_BCC_CONFIG_ENABLED_KEY);
				
				if(isNewBCCConfigEnabled){
					isNewBccProcessingRequired = checkAllRecipientsForBCC(msg, mailBox, cache);
				} else {
					logger.info(BCC_PROCESSING_LOG_PREFIX + "New bcc processing is disabled or not configured.");
				}
			} else {
				logger.info(BCC_PROCESSING_LOG_PREFIX + "'bccMailBoxConfig' not found in database.");
			}
		} catch (Exception e) {
			logger.error(BCC_PROCESSING_LOG_PREFIX + "Exception in checkIfNewBccProcessingIsRequired() for message : {} " + e, messageId);
		}
		return isNewBccProcessingRequired;
	}
	
	/**
	 * This method identifies whether the mailbox is configured as dedicated mailbox or not.
	 * @param messageId
	 * @param inputMailBox
	 * @return boolean
	 */
	public boolean checkIfMailBoxConfiguredAsDedicatedMailBox(String messageId, String inputMailBox, QMACache cache) {
		boolean isMailBoxConfiguredForBCC = false;
		if(StringUtils.isNotEmpty(inputMailBox)) {
		    Map <String, MailBoxDLMapping> mailBoxDLMappingMap = cache.getMailBoxDLMappingMap();
			String mailBox = sanitizeMailBoxName(inputMailBox);
			logger.info("Mailbox Found as :{}", mailBox);
			if(null != cache && null != mailBoxDLMappingMap &&
				null != mailBoxDLMappingMap.get(mailBox.toUpperCase()) &&
				null != mailBoxDLMappingMap.get(mailBox.toUpperCase()).getMappingType() &&
				!mailBoxDLMappingMap.get(mailBox.toUpperCase()).getMappingType().equals(MailBoxMappingType.SHARED) ) {
				isMailBoxConfiguredForBCC = true;
				logger.info("MailBox : {} is a DEDICATED mailbox and it's mapped DL is :{}",mailBox,
					mailBoxDLMappingMap.get(mailBox.toUpperCase()).getMappedDL());
			} else {
				logger.info("MailBox : {} is a SHARED mailbox", mailBox);
			}
		} else {
			logger.info("No mailbox found for message {}", messageId);
		}
		return isMailBoxConfiguredForBCC;
	}


	/**
	 * This method sanitizes the mailBox name
	 * @param inputMailBox
	 * @return String
	 */
	public String sanitizeMailBoxName(String inputMailBox) {
		String mailBox = inputMailBox;
		if(mailBox.contains("@")){
			mailBox = mailBox.substring(0, mailBox.indexOf('@'));
		}
		return mailBox;
	}	
	
	/**
	 * This method validates all To/CC recipients from the email for processing.
	 * @param msg
	 * @param mailBox
	 * @return boolean
	 * @throws MessagingException
	 */
	private boolean checkAllRecipientsForBCC(MimeMessage msg, String mailBox, QMACache cache) throws MessagingException {
	
		List<String> recipientToList = new ArrayList<>();
		List<String> recipientCcList = new ArrayList<>();
		Set<Long> toCcValidGroupIdsSet = getValidToCcGroupIdSet(msg,mailBox,recipientToList,recipientCcList, cache);
		boolean isBccProcessingRequired = toCcValidGroupIdsSet == null || toCcValidGroupIdsSet.isEmpty();
		if(isBccProcessingRequired) {
			logger.info(BCC_PROCESSING_LOG_PREFIX + "All TO/CC recipietns and group DL list is empty. BCC processing is required.");
		} else {
			logger.info(BCC_PROCESSING_LOG_PREFIX + "TO/CC/Group DL list is non-empty. Need recipient reconciliation to validate BCC processing.");
			isBccProcessingRequired = reconcileRecipientsWithMailBoxMapping(toCcValidGroupIdsSet,msg.getMessageID(),mailBox,recipientToList, recipientCcList, cache);
		}
		return isBccProcessingRequired;
	}
	

	/**
	 * This method gets the valid TO/CC id list from the recipients
	 * @param message
	 * @param mailBox
	 * @param recipientToList
	 * @param recipientCcList
	 * @return Set<Long> 
	 * @throws MessagingException
	 */
	private Set<Long> getValidToCcGroupIdSet(MimeMessage message, String mailBox,
			List<String> recipientToList, List<String> recipientCcList, QMACache cache) throws MessagingException {
		Set<Long> toCcValidGroupIdsSet = new HashSet<>();
		try {
			
			Envelope toRecipientsEnvolope = new Envelope();
			Address[] a = message.getRecipients(Message.RecipientType.TO);
			if (a != null) {
				processAddresses(toRecipientsEnvolope,a, Message.RecipientType.TO);
			}
			Envelope ccRecipientsEnvolope = new Envelope();
			a = message.getRecipients(Message.RecipientType.CC);
			if (a != null) {
				processAddresses( ccRecipientsEnvolope, a, Message.RecipientType.CC);
			}
					
			recipientToList.addAll(toRecipientsEnvolope.getToReceipents());
			List<String> addressToList = toRecipientsEnvolope.getToReceipentsAddresses();
			
			identifyValidGroupIdFromRecipients(toCcValidGroupIdsSet, recipientToList, addressToList, STRING_TO, cache);
			
			recipientCcList.addAll(ccRecipientsEnvolope.getCcReceipents());
			List<String> addressCcList = ccRecipientsEnvolope.getCcReceipentsAddresses();
			
			identifyValidGroupIdFromRecipients(toCcValidGroupIdsSet, recipientCcList, addressCcList, STRING_CC, cache);
			
			
			/* TODO : Save the identified 'toCcValidGroupIdsSet' in the message snapshot. 
			 * So that later processor will make use of same instead of finding again.*/
			
		} catch (Exception e) {
			logger.info(BCC_PROCESSING_LOG_PREFIX + "Exception in getValidToCcGroupIdSet() for message : {} and mailbox : {}",e,
					message.getMessageID(), mailBox);
		}
		return toCcValidGroupIdsSet;
	}
	
	/**
	 * This method reconciles recipients with mapped mailbox mapping DL
	 * @param toCcValidGroupIdsSet
	 * @param messageId
	 * @param mailBox
	 * @param recipientToList
	 * @param recipientCcList
	 * @return boolean
	 */
	private boolean reconcileRecipientsWithMailBoxMapping(Set<Long> toCcValidGroupIdsSet,String messageId, String mailBox,
			List<String> recipientToList, List<String> recipientCcList, QMACache cache) {
		boolean isBccProcessingRequired = false;
		try {
			
			logger.warn(BCC_PROCESSING_LOG_PREFIX + "Mailbox identified as : {}",mailBox);
			
			if( StringUtils.isNotEmpty(mailBox) ) {
				if( !toCcValidGroupIdsSet.isEmpty()) {
					isBccProcessingRequired = validateMailBoxMapping(toCcValidGroupIdsSet, messageId, mailBox, cache);
				}  else if( (!recipientToList.isEmpty() || !recipientCcList.isEmpty()) && toCcValidGroupIdsSet.isEmpty() ){
					/* 'toCcValidGroupIdsSet' will be empty in case if  QMA on-boarded DL does not exists in the To/CC recipients.
					 * But there could the case where in QMA DL is only in BCC and there are non-QMA DL's in TO/CC
					 * This block will cover that case.*/
					logger.info("TO/CC recipients are non-empty but contains non-QMA DL's as 'toCcValidGroupIdsSet' is empty. BCC processing is required.");
					isBccProcessingRequired = true;
				}
			}
		} catch (Exception e) {
			logger.info(BCC_PROCESSING_LOG_PREFIX + " Exception in reconcileRecipientsWithMailBoxMapping()", e);
		}
		return isBccProcessingRequired;
	}

	/**
	 * This method validates mailBox mapping for the provided mailbox
	 * @param toCcValidGroupIdsSet
	 * @param messageId
	 * @param mailBox
	 * @return boolean
	 */
	private boolean validateMailBoxMapping(Set<Long> toCcValidGroupIdsSet, String messageId, String mailBox, QMACache cache ) {
		boolean isBccProcessingRequired = false;
		Map <String, MailBoxDLMapping> mailBoxDLMappingMap = cache.getMailBoxDLMappingMap();
		if(null != cache && null != mailBoxDLMappingMap &&
				null != mailBoxDLMappingMap.get(mailBox.toUpperCase()) &&
				null != mailBoxDLMappingMap.get(mailBox.toUpperCase()).getMappedDL()) {
				//TODO : add group id check here.
				logger.info(BCC_PROCESSING_LOG_PREFIX + "Mailbox-DL mapping found for message [{}] and mailBox is {}.", messageId, mailBox);
				isBccProcessingRequired = validateToCcRecipientForBccDL(toCcValidGroupIdsSet,mailBox, messageId, cache);
			} else {
				logger.info(BCC_PROCESSING_LOG_PREFIX + "Mailbox-DL mapping NOT found. No BCC processing required.");
			}
		return isBccProcessingRequired;
	}
	
	/**
	 * This method validate all TO/CC recipients to find out if current mailBox mapped DL is in the recipients or not.
	 * @param toCcValidGroupIdsSet
	 * @param processorTO
	 * @param existingMessageSnapshot
	 * @return boolean
	 */
	private boolean validateToCcRecipientForBccDL(Set<Long> toCcValidGroupIdsSet,String mailBox, String messageID, QMACache cache) {
		boolean isBccProcessingRequired = false;
		String groupCode = cache.getMailBoxDLMappingMap().get(mailBox.toUpperCase()).getMappedDL();
		if(StringUtils.isNotEmpty(groupCode)) {
			Long groupID = cache.getGroupCodeToIdMap().get(groupCode.toUpperCase());
			if( null != groupID ){
				if(toCcValidGroupIdsSet.contains(groupID)) {
					logger.info(BCC_PROCESSING_LOG_PREFIX + "DL mapped to current message mailBox is in the TO/CC recipients. No BCC processing is required.");
				} else {
					isBccProcessingRequired = true;
					logger.info(BCC_PROCESSING_LOG_PREFIX + "DL mapped[{}] to current message[{}] mailBox {{}} is NOT in the TO/CC recipients. BCC processing is required.",
							groupCode,messageID,mailBox);
				}
			}
		}
		return isBccProcessingRequired;
	}
	
	
	public void identifyValidGroupIdFromRecipients(Set<Long> groupIdsSet, List<String> groupList, 
			List<String> addressList, String recipientCategory, QMACache cache)
			throws CommunicatorException
	{
		logger.info("***Start finding GroupId's for email received");
		LinkedHashSet<ConversationRecipient> recipientDOList = new LinkedHashSet<ConversationRecipient>();
		int parentDLCount;
		if (groupList != null)
		{
			List<IncomingToCcDLAliasMapping> toCCGrpAliasList = cache.getIncomingToCcDLAliasMapping();//TODO cache-list
			Map<String, List<String>> parentToChildEmailMap= cache.getParentToChildDLsListMap(); //TODO cache-map
			Map<String, Group> emailWithDomainToGroupMap = cache.getEmailWithDomaintoGroupMap(); //TODO cache-map

			for (int i = 0; i < groupList.size(); i++) {
				parentDLCount = 0;
				replaceToCcDLWithStaticDataAliasMapping(groupList, addressList, recipientCategory, toCCGrpAliasList, i);

				String groupAliasReceived = groupList.get(i);
				String addressWithDomain = addressList.get(i);

				List<String> ignoreDLListForProcessing = cache.getIgnoreEmailListForProcessing(); //TODO cache-list

				if (ignoreDLListForProcessing != null && ignoreDLListForProcessing.contains(addressWithDomain.toUpperCase())) {
					logger.warn("This is case of ignore EmailListForProcessing, email address is: " + addressWithDomain);
					continue;

				}

				logger.info("Group Alias Received(Name) from email is: " + groupAliasReceived + ",   and email address of that alias is: " + addressWithDomain);
				// Don't Put check for Blank Ever As The Input from exchange server is different in different cases. It is taken care in below code.

				if (groupAliasReceived != null) {

					groupAliasReceived = groupAliasReceived.toUpperCase();
					if (groupAliasReceived.startsWith("'") && groupAliasReceived.endsWith("'")) {
						try {
							groupAliasReceived = groupAliasReceived.substring(1, groupAliasReceived.length() - 1);
						} catch (Exception e) {
							logger.info("Exception in parsing groupAliasReceived: " + groupAliasReceived, e);
						}
					}
					if (groupAliasReceived.contains("@")) {
						try {
							groupAliasReceived = groupAliasReceived.substring(0, groupAliasReceived.indexOf('@'));
						} catch (Exception e) {
							logger.info("Exception in parsing groupAliasReceived: " + groupAliasReceived, e);
						}
					}

					if (GenericUtility.isCitiDomainEmail(addressWithDomain)) {
						logger.info(" If block isCitiDomainEmail  - addressWithDomain: " + addressWithDomain);

						Long groupId = MongoExtInquiryDAO.getInternalGroupIdForReceivedGroupAlias(groupAliasReceived, cache);

						String addressWithoutDomain = GenericUtility.getValidEmailWithoutDomain(addressWithDomain);

						if (addressWithoutDomain == null) { 
							// TO skip null issues, as from UI now BCC is enabled and causing it to be null
							addressWithoutDomain = "";
						}

						if (groupId == null) {
							if (StringUtils.isBlank(addressWithDomain)) {
								logger.warn("Email Address is null, This should never be the case. Please look into it");
								continue;
							}

							groupId = MongoExtInquiryDAO.getInternalGroupIdForReceivedGroupEmail(addressWithoutDomain.toUpperCase(), cache);
							logger.info("Group Id after email lookup is: " + groupId);
						}

						ConversationRecipient inquiryConversationRecipient = createConvRecipient(groupList, recipientCategory, i, addressWithDomain, groupId, cache);
						if (null != groupId && !groupIdsSet.contains(groupId)) {
							groupIdsSet.add(groupId);
							recipientDOList.add(inquiryConversationRecipient);
						}

						if (null == groupId) {
							groupId = findGroupIdUsingCIMSandManualEmails(addressWithoutDomain.toUpperCase(), recipientCategory, recipientDOList, groupIdsSet, cache);

							if (groupId != null) {
								logger.info("MATCHED CASE :: findGroupIdUsingCIMSandManualEmails for Email " + addressList.get(i) + " , groupId found is:" + groupId);
							}
						}

						try {
							if (null == groupId)
							{
								if (null != parentToChildEmailMap) {
									// child are all active Groups in QMA in Group table.
									List<String> childEmailListOfParent = addressWithDomain==null?null:parentToChildEmailMap.get(addressWithDomain.toUpperCase());

									if (childEmailListOfParent == null) {
										logger.info("ParentDLAlias lookup addressWithoutDomain" + addressWithoutDomain.toUpperCase());
										childEmailListOfParent = addressWithoutDomain==null?null:parentToChildEmailMap.get(addressWithoutDomain.toUpperCase());
									}


									if (null != childEmailListOfParent) {
										for (String qmaGroupEmail : childEmailListOfParent) {
											Group qmaGroup = qmaGroupEmail==null?null:emailWithDomainToGroupMap.get(qmaGroupEmail);
											if (qmaGroup != null) {
												groupIdsSet.add(qmaGroup.id);
												ConversationRecipient memberRecipient = new ConversationRecipient();
												createInqRecipient(memberRecipient, qmaGroup.id, qmaGroup.getGroupEmail(), recipientCategory, qmaGroup.getGroupName(), cache);
												recipientDOList.add(memberRecipient);
												recipientDOList.add(inquiryConversationRecipient);

												parentDLCount++;
											}
										}
									}
								}
							}
						} catch (Exception e) {
							logger.info("Catch block of cacheDAO.getParentToChildDLsListMap", e);
						}

						logger.info("Final data for receipient email address: " + addressWithDomain + " groupId is - " + groupId + " , parentDL count - " + parentDLCount);

						if (groupId == null && parentDLCount == 0) { // if group is not found in both ext tables, means it is an email address of individual user
							recipientDOList.add(inquiryConversationRecipient);
						}
					} else {
						logger.info(" else block non isCitiDomainEmail  - addressWithDomain: " + addressWithDomain);
						ConversationRecipient inquiryConversationRecipient = createConvRecipient(groupList, recipientCategory, i, addressWithDomain, null, cache);
						recipientDOList.add(inquiryConversationRecipient);
					}
				}
			}
		}
		logger.info("###Ended finding GroupId's for email received");
	}
	
	private Long findGroupIdUsingCIMSandManualEmails(String emailAddressReceived, String recipientCategory, Set<ConversationRecipient> recipientDOList, Set<Long> groupIdSet, QMACache cache) 
	{
		logger.info("inside findGroupIdUsingCIMSandManualEmails ");
		Long groupId = null;
		try
		{
			
			List<Group> dbGroupListFromcache = cache.getGroupList(); //TODO cache-list
			Map<Long, List<String>> groupIdToCIMSEmailList = cache.getGroupIdToCIMSEmailList(); //TODO cache-map
			Map<Long, List<String>> groupIdToManualGroupEmailList = cache.getGroupIdToManualEmailList(); //TODO cache-map

			if (!StringUtils.isBlank(emailAddressReceived) && dbGroupListFromcache != null && !dbGroupListFromcache.isEmpty())
			{
				logger.debug("start of for loop in findGroupIdUsingCIMSandManualEmails");
				
				long foreachTimeTotal = 0;
				long subEmailListTimeTotal = 0;
				long ifBlockTimeTotal = 0;
				long foreachTime = System.currentTimeMillis();
				for (Group grp : dbGroupListFromcache)
				{   
					foreachTimeTotal += (System.currentTimeMillis() -  foreachTime);
					
					Long subEmailListTime = System.currentTimeMillis();
					List<String> cimsEmailList = grp.id==null?null:groupIdToCIMSEmailList.get(grp.id); // This list is also in uppercase with @ data
					List<String> manualEmailList = grp.id==null?null: groupIdToManualGroupEmailList.get(grp.id); //// This list is also in uppercase with @ data
					subEmailListTimeTotal += (System.currentTimeMillis() - subEmailListTime);
					
					
					long ifBlockTime=System.currentTimeMillis();
					// Don't consider inactive groups
					// 1. Match incoming email with AllGroupEmails, If Matched, create receipient and abort.
					if (grp.getActive() && cimsEmailList != null && cimsEmailList.contains(emailAddressReceived))
					{
						groupId = grp.getId();
						logger.info("Group Matched in AllGroupEmailsFromCIMS for Email " + emailAddressReceived + " , recipientCategory: " + recipientCategory + " , Group Id: " + groupId
								+ " , Group Name:" + grp.getGroupName());
						groupIdSet.add(groupId);
						// Create and Add Recipient
						ConversationRecipient memberRecipient = new ConversationRecipient();
						createInqRecipient(memberRecipient, groupId, grp.getGroupEmail(), recipientCategory, grp.getGroupName(), cache);
						recipientDOList.add(memberRecipient);

						break;

					}
					// 2. Else Match incoming email with ManualGroupEmails, If Matched, create receipient and abort.
					else if (grp.getActive() && manualEmailList != null && manualEmailList.contains(emailAddressReceived))
					{
						groupId = grp.getId();
						logger.info("Group Matched in ManualGroupEmails for Email " + emailAddressReceived + " ,recipientCategory: " + recipientCategory + " ,Group Id: " + groupId + " ,Group Name:"
								+ grp.getGroupName());
						groupIdSet.add(groupId);
						// Create and Add Recipient
						ConversationRecipient memberRecipient = new ConversationRecipient();
						createInqRecipient(memberRecipient, groupId, grp.getGroupEmail(), recipientCategory, grp.getGroupName(), cache);
						recipientDOList.add(memberRecipient);
						break;
					}
					ifBlockTimeTotal += (System.currentTimeMillis()-ifBlockTime);
					foreachTime = System.currentTimeMillis();
					
				}
				String LogTimeMessage="findGroupIdUsingCIMSandManualEmails foreachTimeTotal="+foreachTimeTotal+" | subEmailListTimeTotal="+subEmailListTimeTotal+" | ifBlockTimeTotal="+ifBlockTimeTotal;
				logger.info(LogTimeMessage);
				/*MessageEventPublisher.info(processorTO.getMessageId())
				 .setComponentName(ComponentEvent.COMPONENT_PROCESSOR)
				 .setBlock(this.getClass().getSimpleName())
				 .setEventName("COMPLETION_OF_FINDGROUPUSINGCIMS").setDetails(LogTimeMessage)
				 .publish();*/
				logger.info("end of for loop in findGroupIdUsingCIMSandManualEmails");
			}
		}
		catch (Exception e)
		{
			logger.warn("Exception in findGroupIdUsingCIMSandManualEmails:", e);
		}

		return groupId;
	}
	
	public void replaceToCcDLWithStaticDataAliasMapping(List<String> emailRecipientNameList, List<String> emailRecipientAddrList, String recipientCategory,
			List<IncomingToCcDLAliasMapping> xscDLAliasList, int index)

	{
		try
		{
			boolean toCc = QmaMailConstants.STRING_TO.equals(recipientCategory) || QmaMailConstants.STRING_CC.equals(recipientCategory);
			boolean isListNotNull = null != xscDLAliasList && null != emailRecipientNameList && null != emailRecipientAddrList;
			if (toCc && isListNotNull)
			{
				String groupAliasReceived = "";
				// [C153176-1488] Handling single quotes
				if (emailRecipientNameList.get(index) != null)
				{
					groupAliasReceived = emailRecipientNameList.get(index);
					groupAliasReceived = groupAliasReceived.indexOf('\'') == 0 ? groupAliasReceived.substring(1, groupAliasReceived.length() - 1) : groupAliasReceived;
				}
				String groupEmailReceived = "";
				if (emailRecipientAddrList.get(index) != null)
				{
					groupEmailReceived = emailRecipientAddrList.get(index);
					groupEmailReceived = groupEmailReceived.indexOf('\'') == 0 ? groupEmailReceived.substring(1, groupEmailReceived.length() - 1) : groupEmailReceived;
				}
				for (IncomingToCcDLAliasMapping toCCGrpAlias : xscDLAliasList)
				{
					replaceWithListStaticData(emailRecipientNameList, emailRecipientAddrList, index, groupAliasReceived, groupEmailReceived, toCCGrpAlias);
				}
			}

		}
		catch (Exception ex)
		{
			logger.error("Exception while replacing the : replaceToCcDLWithStaticDataAliasMapping from static data " + ex);
		}
	}
	
	private void replaceWithListStaticData(List<String> emailRecipientNameList, List<String> emailRecipientAddrList, int index, String groupAliasReceived, String groupEmailReceived,
			IncomingToCcDLAliasMapping toCCGrpAlias)
	{
		if (groupEmailReceived.equalsIgnoreCase(toCCGrpAlias.getEmail()) || groupAliasReceived.equalsIgnoreCase(toCCGrpAlias.getName()))
		{
			emailRecipientNameList.set(index, toCCGrpAlias.getXscDlName());
			emailRecipientAddrList.set(index, toCCGrpAlias.getXscDLEmail());
			logger.info("Group Alias after replacing with static data toCcDLAliasMapping name: " + groupAliasReceived + ", email of that alias after replacing with toCcDLAliasMapping email: "
					+ emailRecipientAddrList.get(index));
		}
	}
	
	private ConversationRecipient createConvRecipient(List<String> groupList, String recipientCategory, int i, String address, Long groupId, QMACache cache)
	{
		ConversationRecipient inquiryConversationRecipient = new ConversationRecipient();
		String userName = groupList.get(i) == null ? "External User" : groupList.get(i);
		createInqRecipient(inquiryConversationRecipient, groupId, address, recipientCategory, userName, cache);

		return inquiryConversationRecipient;
	}
	
	private void createInqRecipient(ConversationRecipient inquiryConversationRecipient, Long groupId, String groupEmail, String recipientCategory, String userName, QMACache cache)
	{

		try
		{
			inquiryConversationRecipient.setGroupId(groupId);

			inquiryConversationRecipient.setUserId(groupEmail);
			inquiryConversationRecipient.setToFrom(recipientCategory != null ? recipientCategory.toUpperCase() : null);
			inquiryConversationRecipient.setEmailAddr(groupEmail);
			////MongoGroupMappingCache cache = MongoGroupMappingCache.getInstance();
			////String groupCode = cache.getGroupIdToNameMap().get(groupId);
			//// will get only groupId field from rest api
			String groupCode =groupId==null ? null: null != cache ? cache.getGroupIdToNameMap().get(groupId) : null;//TODO cache-map

			if (groupCode != null)
			{
				inquiryConversationRecipient.setDisplayName(groupCode);
			}
			else
			{
				inquiryConversationRecipient.setDisplayName(userName);
			}
		}
		catch (Exception e)
		{
			logger.error("createInqRecipient has issues, plz look into it", e);
		}

	}


	public void processAddresses(Envelope envelope,Address[] a, RecipientType recipientType) throws CommunicatorException {

		
		String strPersonal;
		for (int j = 0; j < a.length; j++)
		{
			if (a[j] instanceof InternetAddress ia)
			{

				try
				{
					InternetAddress[] groupAddress = ia.getGroup(true);
					if (groupAddress != null && groupAddress.length > 0)
					{
						processAddresses(envelope, groupAddress, recipientType);
					}
					else
					{
						if (Message.RecipientType.TO.equals(recipientType))
						{
							strPersonal = ia.getPersonal();
							if(null == strPersonal)
								strPersonal = "";
							strPersonal = strPersonal.replaceAll("\\r|\n", "");
							
							String address = ia.getAddress().replaceAll("`", "");
							
							if (address.startsWith("'") && address.endsWith("'"))
							{
								logger.debug("address has apostrophe in beginning and in end, now removing it:" + address);
								address = address.replaceAll("'", "");
							}
							address = address.replaceAll("", "").trim(); 
							
							envelope.addToReceipent(strPersonal);
							envelope.addToReceipentAddresses(address);
						}
						else if (Message.RecipientType.CC.equals(recipientType))
						{
							strPersonal = ia.getPersonal();

							if(null == strPersonal)
								strPersonal = "";

							strPersonal = strPersonal.replaceAll("\\r|\n", "");
							
							String address = ia.getAddress().replaceAll("`", "");
							

							if (address.startsWith("'") && address.endsWith("'"))
							{
								logger.debug("address has apostrophe in beginning and in end, now removing it:" + address);
								address = address.replaceAll("'", "");
								
							}
							address = address.replaceAll("", "").trim(); 

							envelope.addCcReceipent(strPersonal);
							envelope.addCcReceipentAddresses(address);
						}
					}
				}
				catch (AddressException e)
				{
					logger.error(this + " Issue happened in method processAddresses ", e);
					throw new CommunicatorException(this + " Issue happened in method processAddresses ", e);
				}
			}
			else
			{
				envelope.addToReceipent(a[j].toString());
			}
		}
	}
}
