package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.citi.icg.qma.common.transferobject.Template;

import com.fasterxml.jackson.annotation.JsonProperty;
import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Transient;

@Entity(value = "Group", noClassnameStored = true)
public class Group extends BaseEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7091762238104184507L;

	// Sonar Fix -- Make fields a static final constant or non-public and provide
	// accessors if needed
	private Boolean active;// Should enable/disable group in our application
	private Boolean makerCheckerRqd;// It applies only outgoing/external emails. It also known as peer review
	private List<String> makerCheckerDomains;// ["gs.com", "jpc.com"] // if it is blank, then it is applied to all
												// external emails.., if value is there then only to those email
												// external emails.
	// TODO: IZ renamed descr to groupName - more descriptive.
	private String groupName;
	private String groupEmail; // Added, also Keep it with @ data // Sunil 11 Aug

	private List<RoutingCriteria> routes;// // Data Migration not needed as we will setup from scracth// 31st July:
											// SUNIL
	// Added to audit the rule criteria
	private List<EmailAlias> parentDLAliases;
	private List<String> recipients;// External Email Contacts for the group+ It will be used for client address
									// book
	// In discussion (TBD)
	private List<String> requestTypes;
	// In discussion (TBD)

	// Commenting below as now it is in User document, Later we will delete it. :
	// Sunil 31st July
	// public List<String> userList; //Relationship should be setup in User entity.
//
	private String disclaimer; // New field used for mailsender
	private Boolean predictiveRecipients;// Should turn on predictiveRecipients in TO/CC Box (Compose/Response Inquiry
											// Flow)

	private Boolean attachmentBasedMakerChecker;
	private List<String> tags;
	// Management Heirarchy addition
	private ManagementHeirarchy heirarchyData;

	private List<FavoriteContact> favorites; // list of shared top contacts at group level .

	private List<String> allGroupEmailsFromCIMS;// All emails received from CIMS webservice

	private List<String> manualGroupEmails;// List of Manual Email Address to be configured by IT Admin

	private Boolean isEmailSharingBlocked;// [C153176-426] Ability to block adding external clients to 'Top Contacts',

	private List<KeyValue> autoResponseDetails; // [C153176-545] - Used for managing automatic response templates
	private List<String> userAssignmentExclusionList;// C153176-731 - Group Admin Screen enhancement to allow exclusion
														// from round robin assignment

	// [C153176-777] - Add admin functionality for RootCause addition & updates to
	// any group
	private List<String> rootCauseList;
	private Boolean isRootCauseMandatory;

	// [C153176-793] - Add 'Processing Region' as a drop-down in Group Admin screen
	private List<String> processingRegionList;
	private Boolean isProcessingRegionMandatory;

	// QMA-1442 START - Enhancement for adding more info in the auto response template
	private Boolean includeAssignedUserInfo;
	private Boolean includeUserContactInfo;
	private Boolean includeManagerContactInfo;
	// QMA-1442 END

	private Boolean autoReplyEnable;
	private Boolean isInquirySourceMandatory;
	private Boolean isInqReferenceIdReq;
	private Boolean isRootCauseMandatoryWOReply;
	private Boolean enableXstreamIntegration;
	private Boolean isGfidMandatory; // [C153176-1030] - Make GFPID/GFCID mandatory with group preference
	private Boolean isUINotificationPopupEnabled;
	private Boolean isTagMandatory; // [C153176-1035] - Make Tag mandatory to resolve
	// [C153176-1014] - Add Escalation functionality
	private Integer convCountThresholdForEscalation;
	private Integer responseTimeThresholdForEscalation;
	private Integer paResponseTimeThresholdForEscalation;
	private Boolean excludeMyGroupWhileReplyAll;
	private Boolean enableInquirySubStatus; //[C170665-1719] DCC Requirement: Add Case status field
	// C153176-5630 | Enable/disable client contact list visibility for group
	// members
	private Boolean hideClientList;
	private List<String> escKeywords;

	private GroupHolidayDetails holidayAndShiftDetails;
	private String country;
	private String timeZone;
	private String managerSoeId;
	private String gocCode;
	private String gocName;
	private String msL5;
	private String msL6;
	private String msL7;

	private HrHierarchy hrHierarchy;

	// [C153176-1684] - Ability for admins to set subject Escalation key words on an
	// individual basis
	private List<String> subjectEscalationList;

	private List<HighlevelRequestType> requestTypeMappings;
	// Added to create Templates for user. Made private & provided get/set methods
	// as per best practices.
	private List<Template> templates;

	private List<CustomClientCriteria> customClientCategory;
	private String previousDayBoxCount;

	private String recordCode;
	// C153176-5633 Restore button implementation for the rules screen
	private List<RoutingCriteria> backupRoutes;
	private Date backupRouteDate;

	// C153176-6148 | Group configuration : Re-age need supervisor approval
	private Boolean supervisiorApprovalForReage;

	private String groupType;
	private String personalMailboxId; // User SOEID in CITI
	private List<ExchangeFolder> exchFolders;
	private String exchFolderHierarchySyncState;
	private String exchEmailSyncState;

	// C170665-10 : Request Type and Root Cause Linking
	private Map<String, List<String>> requestTypeRootCauseMapping; // Map of Request type and list of root cause
	private Boolean requestTypeRootCauseFilter; // Preference flag to enable or disable request type - root cause
												// mapping filter.
 
	private boolean enableAutoAssignment;

	private String psL5;
	private String psL6;
	private String psL7;
	
	private Map<String, List<HierarchyUserDetail>> smartCategoryMetaData;
	private List<EmailAlias> parentDLAliasAudit;
	private List<String> allGroupEmailsFromCIMSAudit;// All emails received from CIMS webservice
	
	private boolean isGroupManagerAboveL7;
	private String lob;
	private boolean enableAutoReplySuggestion;
	private boolean enableCustodySuggestion;
	//Added for enable/disable group in MIS reporting
	private MisReportConfig misReportConfig;
	
	//C170665-3791 introducing this flag for assign group belongs to this type (eg. Taskize)
	@Transient
	private String streamId;

	private boolean enableIntentSuggestion;
	
	// C170665-4031 - Allow "Automated Response" for a DL to be more customizable by User
	private boolean isCustomizedAutoResponseEnabled;
	private String customAutoResponseOptions;
	@Transient
	private List<String> customKeywordsForAutoResponse;
	
	private boolean includeMyGroupInCC;
	@JsonProperty(value = "isAutoResponseEnabledForInternalDomain" )
	private boolean isAutoResponseEnabledForInternalDomain;


	public Group() {
		super();
	}

	public Group(Boolean active, Boolean makerCheckerRqd, String groupName, String groupEmail,
			List<RoutingCriteria> routes, List<EmailAlias> parentDLAliases, List<String> requestTypes,
			Boolean isEmailSharingBlocked, List<HighlevelRequestType> requestTypeMappings) {
		super();
		this.setActive(active);
		this.makerCheckerRqd = makerCheckerRqd;
		this.setGroupName(groupName);
		this.setGroupEmail(groupEmail);
		this.setRoutes(routes);
		this.setParentDLAliases(parentDLAliases);
		this.setRequestTypes(requestTypes);
		this.setIsEmailSharingBlocked(isEmailSharingBlocked);
		this.setRequestTypeMappings(requestTypeMappings);
	}

	public boolean isAutoResponseEnabledForInternalDomain() {
		return isAutoResponseEnabledForInternalDomain;
	}

	public void setAutoResponseEnabledForInternalDomain(boolean isAutoResponseEnabledForInternalDomain) {
		this.isAutoResponseEnabledForInternalDomain = isAutoResponseEnabledForInternalDomain;
	}

	public Boolean getPredictiveRecipients() {
		return predictiveRecipients;
	}

	public void setPredictiveRecipients(Boolean predictiveRecipients) {
		this.predictiveRecipients = predictiveRecipients;
	}

	public Boolean getAttachmentBasedMakerChecker() {
		return attachmentBasedMakerChecker;
	}

	public void setAttachmentBasedMakerChecker(Boolean attachmentBasedMakerChecker) {
		this.attachmentBasedMakerChecker = attachmentBasedMakerChecker;
	}

	public List<String> getTags() {
		return tags;
	}

	public void setTags(List<String> tags) {
		this.tags = tags;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Boolean getMakerCheckerRqd() {
		return makerCheckerRqd;
	}

	public void setMakerCheckerRqd(Boolean makerCheckerRqd) {
		this.makerCheckerRqd = makerCheckerRqd;
	}

	public List<String> getMakerCheckerDomains() {
		return makerCheckerDomains;
	}

	public void setMakerCheckerDomains(List<String> makerCheckerDomains) {
		this.makerCheckerDomains = makerCheckerDomains;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupEmail() {
		return groupEmail;
	}

	public void setGroupEmail(String groupEmail) {
		this.groupEmail = groupEmail;
	}

	public List<RoutingCriteria> getRoutes() {
		return routes;
	}

	public void setRoutes(List<RoutingCriteria> routes) {
		this.routes = routes;
	}

	public List<EmailAlias> getParentDLAliases() {
		return parentDLAliases;
	}

	public void setParentDLAliases(List<EmailAlias> parentDLAliases) {
		this.parentDLAliases = parentDLAliases;
	}

	public String getDisclaimer() {
		return disclaimer;
	}

	public void setDisclaimer(String disclaimer) {
		this.disclaimer = disclaimer;
	}

	public List<String> getRequestTypes() {
		return requestTypes;
	}

	public void setRequestTypes(List<String> requestTypes) {
		this.requestTypes = requestTypes;
	}

	public List<String> getRecipients() {
		return recipients;
	}

	public void setRecipients(List<String> recipients) {
		this.recipients = recipients;
	}

	public ManagementHeirarchy getHeirarchyData() {
		return heirarchyData;
	}

	public void setHeirarchyData(ManagementHeirarchy heirarchyData) {
		this.heirarchyData = heirarchyData;
	}

	public List<FavoriteContact> getFavorites() {
		return favorites;
	}

	public void setFavorites(List<FavoriteContact> favorites) {
		this.favorites = favorites;
	}

	public List<String> getAllGroupEmailsFromCIMS() {
		return allGroupEmailsFromCIMS;
	}

	public void setAllGroupEmailsFromCIMS(List<String> allGroupEmailsFromCIMS) {
		this.allGroupEmailsFromCIMS = allGroupEmailsFromCIMS;
	}

	public List<String> getManualGroupEmails() {
		return manualGroupEmails;
	}

	public void setManualGroupEmails(List<String> manualGroupEmails) {
		this.manualGroupEmails = manualGroupEmails;
	}

	public Boolean getIsEmailSharingBlocked() {
		return isEmailSharingBlocked;
	}

	public void setIsEmailSharingBlocked(Boolean isEmailSharingBlocked) {
		this.isEmailSharingBlocked = isEmailSharingBlocked;
	}

	public List<KeyValue> getAutoResponseDetails() {
		return autoResponseDetails;
	}

	public void setAutoResponseDetails(List<KeyValue> autoResponseDetails) {
		this.autoResponseDetails = autoResponseDetails;
	}

	public List<String> getUserAssignmentExclusionList() {
		return userAssignmentExclusionList;
	}

	public void setUserAssignmentExclusionList(List<String> userAssignmentExclusionList) {
		this.userAssignmentExclusionList = userAssignmentExclusionList;
	}

	public List<String> getRootCauseList() {
		return rootCauseList;
	}

	public void setRootCauseList(List<String> rootCauseList) {
		this.rootCauseList = rootCauseList;
	}

	public Boolean getIsRootCauseMandatory() {
		return isRootCauseMandatory;
	}

	public void setIsRootCauseMandatory(Boolean isRootCauseMandatory) {
		this.isRootCauseMandatory = isRootCauseMandatory;
	}

	public List<String> getProcessingRegionList() {
		return processingRegionList;
	}

	public void setProcessingRegionList(List<String> processingRegionList) {
		this.processingRegionList = processingRegionList;
	}

	public Boolean getIsProcessingRegionMandatory() {
		return isProcessingRegionMandatory;
	}

	public void setIsProcessingRegionMandatory(Boolean isProcessingRegionMandatory) {
		this.isProcessingRegionMandatory = isProcessingRegionMandatory;
	}

	public Boolean getAutoReplyEnable() {
		return autoReplyEnable;
	}

	public void setAutoReplyEnable(Boolean autoReplyEnable) {
		this.autoReplyEnable = autoReplyEnable;
	}

	public Boolean getIsInquirySourceMandatory() {
		return isInquirySourceMandatory;
	}

	public void setIsInqSourceMandatory(Boolean isInquirySourceMandatory) {
		this.isInquirySourceMandatory = isInquirySourceMandatory;
	}

	public Boolean getIsInqReferenceIdReq() {
		return isInqReferenceIdReq;
	}

	public void setIsInqReferenceIdReq(Boolean isInqReferenceIdReq) {
		this.isInqReferenceIdReq = isInqReferenceIdReq;
	}

	public Boolean getIsRootCauseMandatoryWOReply() {
		return isRootCauseMandatoryWOReply;
	}

	public void setIsRootCauseMandatoryWOReply(Boolean isRootCauseMandatoryWOReply) {
		this.isRootCauseMandatoryWOReply = isRootCauseMandatoryWOReply;
	}

	public Boolean getEnableXstreamIntegration() {
		return enableXstreamIntegration;
	}

	public void setEnableXstreamIntegration(Boolean enableXstreamIntegration) {
		this.enableXstreamIntegration = enableXstreamIntegration;
	}

	public Boolean getIsGfidMandatory() {
		return isGfidMandatory;
	}

	public void setIsGfidMandatory(Boolean isGfidMandatory) {
		this.isGfidMandatory = isGfidMandatory;
	}

	public Boolean getIsUINotificationPopupEnabled () {
		return isUINotificationPopupEnabled ;
	}

	public void setIsUINotificationPopupEnabled (Boolean isUINotificationPopupEnabled ) {
		this.isUINotificationPopupEnabled  = isUINotificationPopupEnabled ;
	}

	/* [C153176-1035] - Option to make Tag mandatory for resolve */
	public Boolean getIsTagMandatory() {
		return isTagMandatory;
	}

	public void setIsTagMandatory(Boolean isTagMandatory) {
		this.isTagMandatory = isTagMandatory;
	}

	public Integer getConvCountThresholdForEscalation() {
		return convCountThresholdForEscalation;
	}

	public void setConvCountThresholdForEscalation(Integer convCountThresholdForEscalation) {
		this.convCountThresholdForEscalation = convCountThresholdForEscalation;
	}

	public Integer getResponseTimeThresholdForEscalation() {
		return responseTimeThresholdForEscalation;
	}

	public void setResponseTimeThresholdForEscalation(Integer responseTimeThresholdForEscalation) {
		this.responseTimeThresholdForEscalation = responseTimeThresholdForEscalation;
	}

	public Boolean getExcludeMyGroupWhileReplyAll() {
		return excludeMyGroupWhileReplyAll;
	}

	public void setExcludeMyGroupWhileReplyAll(Boolean excludeMyGroupWhileReplyAll) {
		this.excludeMyGroupWhileReplyAll = excludeMyGroupWhileReplyAll;
	}

	public Integer getPaResponseTimeThresholdForEscalation() {
		return paResponseTimeThresholdForEscalation;
	}

	public void setPaResponseTimeThresholdForEscalation(Integer paResponseTimeThresholdForEscalation) {
		this.paResponseTimeThresholdForEscalation = paResponseTimeThresholdForEscalation;
	}

	/**
	 * @return the escKeywords
	 */
	public List<String> getEscKeywords() {
		return escKeywords;
	}

	/**
	 * @param escKeywords the escKeywords to set
	 */
	public void setEscKeywords(List<String> escKeywords) {
		this.escKeywords = escKeywords;
	}

	/**
	 * @return the holidayDetails
	 */
	public GroupHolidayDetails getHolidayAndShiftDetails() {
		return holidayAndShiftDetails;
	}

	/**
	 * @param holidayDetails the holidayDetails to set
	 */
	public void setHolidayAndShiftDetails(GroupHolidayDetails holidayDetails) {
		this.holidayAndShiftDetails = holidayDetails;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return timeZone;
	}

	/**
	 * @param timeZone the timeZone to set
	 */
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	/**
	 * @return the templates
	 */
	public List<Template> getTemplates() {
		return templates;
	}

	/**
	 * @param templates the templates to set
	 */
	public void setTemplates(List<Template> templates) {
		if (null != templates) {
			templates.sort(Comparator.comparing(Template::getTemplateName));
		}
		this.templates = templates;
	}

	/**
	 * @return the hrHierarchy
	 */
	public HrHierarchy getHrHierarchy() {
		return hrHierarchy;
	}

	public void setHrHierarchy(HrHierarchy hrHierarchy) {
		this.hrHierarchy = hrHierarchy;
	}

	public List<String> getSubjectEscalationList() {
		return subjectEscalationList;
	}

	public void setSubjectEscalationList(List<String> subjectEscalationList) {
		this.subjectEscalationList = subjectEscalationList;
	}

	public List<HighlevelRequestType> getRequestTypeMappings() {
		return requestTypeMappings;
	}

	public void setRequestTypeMappings(List<HighlevelRequestType> requestTypeMappings) {
		this.requestTypeMappings = requestTypeMappings;
	}

	public void setCustomClientCategory(List<CustomClientCriteria> customClientCategory) {
		this.customClientCategory = customClientCategory;
	}

	public List<CustomClientCriteria> getCustomClientCategory() {
		return customClientCategory;
	}

	public String getPreviousDayBoxCount() {
		return previousDayBoxCount;
	}

	public void setPreviousDayBoxCount(String previousDayBoxCount) {
		this.previousDayBoxCount = previousDayBoxCount;
	}

	public String getRecordCode() {
		return recordCode;
	}

	public void setRecordCode(String recordCode) {
		this.recordCode = recordCode;
	}

	public void setIsInquirySourceMandatory(Boolean isInquirySourceMandatory) {
		this.isInquirySourceMandatory = isInquirySourceMandatory;
	}

	public String getManagerSoeId() {
		return managerSoeId;
	}

	public void setManagerSoeId(String managerSoeId) {
		this.managerSoeId = managerSoeId;
	}

	public String getGocCode() {
		return gocCode;
	}

	public void setGocCode(String gocCode) {
		this.gocCode = gocCode;
	}

	public String getGocName() {
		return gocName;
	}

	public void setGocName(String gocName) {
		this.gocName = gocName;
	}

	public String getMsL5() {
		return msL5;
	}

	public void setMsL5(String msL5) {
		this.msL5 = msL5;
	}

	public String getMsL6() {
		return msL6;
	}

	public void setMsL6(String msL6) {
		this.msL6 = msL6;
	}

	public String getMsL7() {
		return msL7;
	}

	public void setMsL7(String msL7) {
		this.msL7 = msL7;
	}

	public Boolean getHideClientList() {
		return hideClientList;
	}

	public void setHideClientList(Boolean hideClientList) {
		this.hideClientList = hideClientList;
	}

	public List<RoutingCriteria> getBackupRoutes() {
		return backupRoutes;
	}

	public void setBackupRoutes(List<RoutingCriteria> backupRoutes) {
		this.backupRoutes = backupRoutes;
	}

	public Date getBackupRouteDate() {
		return backupRouteDate;
	}

	public void setBackupRouteDate(Date backupRouteDate) {
		this.backupRouteDate = backupRouteDate;
	}

	public Boolean getSupervisiorApprovalForReage() {
		return supervisiorApprovalForReage;
	}

	public void setSupervisiorApprovalForReage(Boolean supervisiorApprovalForReage) {
		this.supervisiorApprovalForReage = supervisiorApprovalForReage;
	}

	public String getPersonalMailboxId() {
		return personalMailboxId;
	}

	public void setPersonalMailboxId(String personalMailboxId) {
		this.personalMailboxId = personalMailboxId;
	}

	public List<ExchangeFolder> getExchFolders() {
		return exchFolders;
	}

	public void setExchFolders(List<ExchangeFolder> exchFolders) {
		this.exchFolders = exchFolders;
	}

	public String getExchFolderHierarchySyncState() {
		return exchFolderHierarchySyncState;
	}

	public void setExchFolderHierarchySyncState(String exchFolderHierarchySyncState) {
		this.exchFolderHierarchySyncState = exchFolderHierarchySyncState;
	}

	public String getExchEmailSyncState() {
		return exchEmailSyncState;
	}

	public void setExchEmailSyncState(String exchEmailSyncState) {
		this.exchEmailSyncState = exchEmailSyncState;
	}

	public Map<String, List<String>> getRequestTypeRootCauseMapping() {
		return requestTypeRootCauseMapping;
	}

	public void setRequestTypeRootCauseMapping(Map<String, List<String>> requestTypeRootCauseMapping) {
		this.requestTypeRootCauseMapping = requestTypeRootCauseMapping;
	}

	public Boolean getRequestTypeRootCauseFilter() {
		return requestTypeRootCauseFilter;
	}

	public void setRequestTypeRootCauseFilter(Boolean requestTypeRootCauseFilter) {
		this.requestTypeRootCauseFilter = requestTypeRootCauseFilter;
	}

	public String getGroupType() {
		return groupType;
	}

	public void setGroupType(String groupType) {
		this.groupType = groupType;
	}

	public boolean isEnableAutoAssignment() {
		return enableAutoAssignment;
	}

	public void setEnableAutoAssignment(boolean enableAutoAssignment) {
		this.enableAutoAssignment = enableAutoAssignment;
	}

	public Map<String, List<HierarchyUserDetail>> getSmartCategoryMetaData() {
		return smartCategoryMetaData;
	}

	public void setSmartCategoryMetaData(Map<String, List<HierarchyUserDetail>> smartCategoryMetaData) {
		this.smartCategoryMetaData = smartCategoryMetaData;
	}

	public String getPsL5() {
		return psL5;
	}

	public void setPsL5(String psL5) {
		this.psL5 = psL5;
	}

	public String getPsL6() {
		return psL6;
	}

	public void setPsL6(String psL6) {
		this.psL6 = psL6;
	}

	public String getPsL7() {
		return psL7;
	}

	public void setPsL7(String psL7) {
		this.psL7 = psL7;
	}

	public Boolean getEnableInquirySubStatus() {
		return enableInquirySubStatus;
	}

	public void setEnableInquirySubStatus(Boolean enableInquirySubStatus) {
		this.enableInquirySubStatus = enableInquirySubStatus;
	}

	public List<EmailAlias> getParentDLAliasAudit() {
		return parentDLAliasAudit;
	}

	public void setParentDLAliasAudit(List<EmailAlias> parentDLAliasAudit) {
		this.parentDLAliasAudit = parentDLAliasAudit;
	}

	public List<String> getAllGroupEmailsFromCIMSAudit() {
		return allGroupEmailsFromCIMSAudit;
	}

	public void setAllGroupEmailsFromCIMSAudit(List<String> allGroupEmailsFromCIMSAudit) {
		this.allGroupEmailsFromCIMSAudit = allGroupEmailsFromCIMSAudit;
	}

	public boolean isGroupManagerAboveL7() {
		return isGroupManagerAboveL7;
	}

	public void setGroupManagerAboveL7(boolean isGroupManagerAboveL7) {
		this.isGroupManagerAboveL7 = isGroupManagerAboveL7;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public boolean isEnableAutoReplySuggestion() {
		return enableAutoReplySuggestion;
	}

	public void setEnableAutoReplySuggestion(boolean enableAutoReplySuggestion) {
		this.enableAutoReplySuggestion = enableAutoReplySuggestion;
	}

	public boolean isEnableCustodySuggestion() {
		return enableCustodySuggestion;
	}

	public void setEnableCustodySuggestion(boolean enableCustodySuggestion) {
		this.enableCustodySuggestion = enableCustodySuggestion;
	}
	public MisReportConfig getMisReportConfig() {
		return misReportConfig;
	}

	public void setMisReportConfig(MisReportConfig misReportConfig) {
		this.misReportConfig = misReportConfig;
	}

	public String getStreamId() {
		return streamId;
	}

	public void setStreamId(String streamId) {
		this.streamId = streamId;
	}
	
	public boolean isEnableIntentSuggestion() {
		return enableIntentSuggestion;
	}

	public void setEnableIntentSuggestion(boolean enableIntentSuggestion) {
		this.enableIntentSuggestion = enableIntentSuggestion;
	}
	
	public boolean isCustomizedAutoResponseEnabled() {
		return isCustomizedAutoResponseEnabled;
	}

	public void setCustomizedAutoResponseEnabled(boolean isCustomizedAutoResponseEnabled) {
		this.isCustomizedAutoResponseEnabled = isCustomizedAutoResponseEnabled;
	}

	public List<String> getCustomKeywordsForAutoResponse() {
		return customKeywordsForAutoResponse;
	}

	public void setCustomKeywordsForAutoResponse(List<String> customKeywordsForAutoResponse) {
		this.customKeywordsForAutoResponse = customKeywordsForAutoResponse;
	}

	public String getCustomAutoResponseOptions() {
		return customAutoResponseOptions;
	}

	public void setCustomAutoResponseOptions(String customAutoResponseOptions) {
		this.customAutoResponseOptions = customAutoResponseOptions;

	}
	
	public boolean isIncludeMyGroupInCC() {
		return includeMyGroupInCC;
	}

	public void setIncludeMyGroupInCC(boolean includeMyGroupInCC) {
		this.includeMyGroupInCC = includeMyGroupInCC;
	}

	public Boolean getIncludeAssignedUserInfo() {
		return includeAssignedUserInfo;
	}

	public void setIncludeAssignedUserInfo(Boolean includeAssignedUserInfo) {
		this.includeAssignedUserInfo = includeAssignedUserInfo;
	}

	public Boolean getIncludeUserContactInfo() {
		return includeUserContactInfo;
	}

	public void setIncludeUserContactInfo(Boolean includeUserContactInfo) {
		this.includeUserContactInfo = includeUserContactInfo;
	}

	public Boolean getIncludeManagerContactInfo() {
		return includeManagerContactInfo;
	}

	public void setIncludeManagerContactInfo(Boolean includeManagerContactInfo) {
		this.includeManagerContactInfo = includeManagerContactInfo;
	}
}
