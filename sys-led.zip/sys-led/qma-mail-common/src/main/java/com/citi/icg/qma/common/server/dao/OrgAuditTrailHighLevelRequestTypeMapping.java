package com.citi.icg.qma.common.server.dao;

import java.io.Serializable;

public class OrgAuditTrailHighLevelRequestTypeMapping implements Serializable {
	
	private static final long serialVersionUID = 3327861477355855658L;
	private String requestType;
	private String highlevelRequestType;
	private String statusIndicator;
	public OrgAuditTrailHighLevelRequestTypeMapping() {
		super();
	}

	public OrgAuditTrailHighLevelRequestTypeMapping(String requestType, String highlevelRequestType) {
		super();
		this.requestType = requestType;
		this.highlevelRequestType = highlevelRequestType;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getHighlevelRequestType() {
		return highlevelRequestType;
	}

	public void setHighlevelRequestType(String highlevelRequestType) {
		this.highlevelRequestType = highlevelRequestType;
	}

	public String getStatusIndicator() {
		return statusIndicator;
	}

	public void setStatusIndicator(String statusIndicator) {
		this.statusIndicator = statusIndicator;
	}
	
}
