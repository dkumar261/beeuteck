package com.citi.icg.qma.common.contact.tcl.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class TCLFamilyDetailDiffblueTest {
  /**
  * Methods under test: 
  * 
  * <ul>
  *   <li>default or parameterless constructor of {@link TCLFamilyDetail}
  *   <li>{@link TCLFamilyDetail#setFamilyName(String)}
  *   <li>{@link TCLFamilyDetail#setFamilyNumber(int)}
  *   <li>{@link TCLFamilyDetail#getFamilyName()}
  *   <li>{@link TCLFamilyDetail#getFamilyNumber()}
  * </ul>
  */
  @Test
  @SuppressWarnings("all")
  void testConstructor() {
    // Arrange and Act
    TCLFamilyDetail actualTclFamilyDetail = new TCLFamilyDetail();
    actualTclFamilyDetail.setFamilyName("Family Name");
    actualTclFamilyDetail.setFamilyNumber(10);

    // Assert
    assertEquals("Family Name", actualTclFamilyDetail.getFamilyName());
    assertEquals(10, actualTclFamilyDetail.getFamilyNumber());
  }
}

