package com.citi.icg.qma.common.contact.tcl.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class FieldsDiffblueTest {
  /**
  * Methods under test: 
  * 
  * <ul>
  *   <li>default or parameterless constructor of {@link Fields}
  *   <li>{@link Fields#setAlias(String)}
  *   <li>{@link Fields#setColName(String)}
  *   <li>{@link Fields#setColType(String)}
  *   <li>{@link Fields#setHidden(String)}
  *   <li>{@link Fields#setId(Long)}
  *   <li>{@link Fields#setName(String)}
  *   <li>{@link Fields#setOrder(Long)}
  *   <li>{@link Fields#getAlias()}
  *   <li>{@link Fields#getColName()}
  *   <li>{@link Fields#getColType()}
  *   <li>{@link Fields#getHidden()}
  *   <li>{@link Fields#getId()}
  *   <li>{@link Fields#getName()}
  *   <li>{@link Fields#getOrder()}
  * </ul>
  */
  @Test
  @SuppressWarnings("all")
  void testConstructor() {
    // Arrange and Act
    Fields actualFields = new Fields();
    actualFields.setAlias("Alias");
    actualFields.setColName("Col Name");
    actualFields.setColType("Col Type");
    actualFields.setHidden("Hidden");
    actualFields.setId(123L);
    actualFields.setName("Name");
    actualFields.setOrder(1L);

    // Assert
    assertEquals("Alias", actualFields.getAlias());
    assertEquals("Col Name", actualFields.getColName());
    assertEquals("Col Type", actualFields.getColType());
    assertEquals("Hidden", actualFields.getHidden());
    assertEquals(123L, actualFields.getId().longValue());
    assertEquals("Name", actualFields.getName());
    assertEquals(1L, actualFields.getOrder().longValue());
  }
}

