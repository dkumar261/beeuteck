package com.citi.icg.qma.common.contact.tcl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import com.citi.icg.qma.common.contact.exception.UnauthorizedException;
import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.mongodb.BasicDBObject;
import org.junit.jupiter.api.Test;

class TCLContactDetailsDiffblueTest {

  /**
   * Method under test: {@link TCLContactDetails#getSearchObj(String, String, String)}
   */
  @Test
  @SuppressWarnings("all")
  void testGetSearchObj() {
    // Arrange, Act and Assert
    assertEquals(3, (new TCLContactDetails()).getSearchObj("Field", "42", "Condition").size());
    assertEquals(3, (new TCLContactDetails()).getSearchObj("Field", "42", "").size());
  }
}

