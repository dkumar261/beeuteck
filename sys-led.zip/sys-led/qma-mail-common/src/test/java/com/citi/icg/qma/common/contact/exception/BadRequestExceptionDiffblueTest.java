package com.citi.icg.qma.common.contact.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import org.junit.jupiter.api.Test;

class BadRequestExceptionDiffblueTest {
  /**
  * Method under test: {@link BadRequestException#BadRequestException(String)}
  */
  @Test
  @SuppressWarnings("all")
  void testConstructor() {
    // Arrange and Act
    BadRequestException actualBadRequestException = new BadRequestException("An error occurred");

    // Assert
    assertNull(actualBadRequestException.getCause());
    assertEquals(0, actualBadRequestException.getSuppressed().length);
    assertEquals("An error occurred", actualBadRequestException.getMessage());
    assertEquals("An error occurred", actualBadRequestException.getLocalizedMessage());
  }
}

