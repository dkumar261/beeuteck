package com.citi.icg.qma.common.core.config;

import static org.junit.jupiter.api.Assertions.assertThrows;
import com.citi.icg.qma.common.core.exception.CommunicatorException;
import java.io.UnsupportedEncodingException;
import org.junit.jupiter.api.Test;

class AssertDiffblueTest {
  /**
   * Method under test: {@link Assert#notNull(Object, String)}
   */
  @Test
  @SuppressWarnings("all")
  void testNotNull() throws CommunicatorException {
    // Arrange, Act and Assert
    assertThrows(CommunicatorException.class, () -> Assert.notNull(null, "foo"));
  }

  /**
   * Method under test: {@link Assert#notNullOrBlank(String, String)}
   */
  @Test
  @SuppressWarnings("all")
  void testNotNullOrBlank() throws CommunicatorException {
    // Arrange, Act and Assert
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrBlank(null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrBlank("", "Name"));
  }

  /**
   * Method under test: {@link Assert#notNullOrEmpty(byte[], String)}
   */
  @Test
  @SuppressWarnings("all")
  void testNotNullOrEmpty() throws CommunicatorException {
    // Arrange, Act and Assert
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty((byte[]) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty(new byte[]{}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty((double[]) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty(new double[]{}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty((float[]) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty(new float[]{}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty((int[]) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty(new int[]{}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty((long[]) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty(new long[]{}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty((Object[]) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty(new Object[]{}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty((short[]) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.notNullOrEmpty(new short[]{}, "Name"));
  }

  /**
   * Method under test: {@link Assert#positiveInteger(int, String)}
   */
  @Test
  @SuppressWarnings("all")
  void testPositiveInteger() throws CommunicatorException {
    // Arrange, Act and Assert
    assertThrows(CommunicatorException.class, () -> Assert.positiveInteger(0, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.positiveInteger((Integer) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.positiveInteger((Integer) 0, "Name"));
  }

  /**
   * Method under test: {@link Assert#nonNegativeInteger(int, String)}
   */
  @Test
  @SuppressWarnings("all")
  void testNonNegativeInteger() throws CommunicatorException {
    // Arrange, Act and Assert
    assertThrows(CommunicatorException.class, () -> Assert.nonNegativeInteger(-1, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.nonNegativeInteger((Integer) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.nonNegativeInteger( -1, "Name"));
  }

  /**
   * Method under test: {@link Assert#positiveNumber(double, String)}
   */
  @Test
  @SuppressWarnings("all")
  void testPositiveNumber() throws CommunicatorException {
    // Arrange, Act and Assert
    assertThrows(CommunicatorException.class, () -> Assert.positiveNumber(0.0d, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.positiveNumber((Number) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.positiveNumber(Integer.valueOf(0), "Name"));
  }

  /**
  * Method under test: {@link Assert#inRange(long, long, long, String)}
  */
  @Test
  @SuppressWarnings("all")
  void testInRange() throws CommunicatorException {
    // Arrange, Act and Assert
    assertThrows(CommunicatorException.class, () -> Assert.inRange(42L, 1L, 1L, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.inRange(0L, 1L, 1L, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.inRange(42, 1, 3, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.inRange((Integer) null, 1, 1, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.inRange(0, 1, 3, "Name"));
  }

  /**
   * Method under test: {@link Assert#withinBounds(int, byte[], String)}
   */
  @Test
  @SuppressWarnings("all")
  void testWithinBounds() throws CommunicatorException, UnsupportedEncodingException {
    // Arrange, Act and Assert
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(42, "AAAAAAAA".getBytes("UTF-8"), "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(0, (byte[]) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(-1, "AAAAAAAA".getBytes("UTF-8"), "Name"));
    assertThrows(CommunicatorException.class,
        () -> Assert.withinBounds(42, new double[]{10.0d, 10.0d, 10.0d, 10.0d}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(0, (double[]) null, "foo"));
    assertThrows(CommunicatorException.class,
        () -> Assert.withinBounds(-1, new double[]{10.0d, 10.0d, 10.0d, 10.0d}, "Name"));
    assertThrows(CommunicatorException.class,
        () -> Assert.withinBounds(42, new float[]{10.0f, 10.0f, 10.0f, 10.0f}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(0, (float[]) null, "foo"));
    assertThrows(CommunicatorException.class,
        () -> Assert.withinBounds(-1, new float[]{10.0f, 10.0f, 10.0f, 10.0f}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(42, new int[]{1, 1, 1, 1}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(0, (int[]) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(-1, new int[]{1, 1, 1, 1}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(42, new long[]{1L, 1L, 1L, 1L}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(0, (long[]) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(-1, new long[]{1L, 1L, 1L, 1L}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(42, new Object[]{"Array"}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(0, (Object[]) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(-1, new Object[]{"Array"}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(42, new Object[]{}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(42, new short[]{1, 1, 1, 1}, "Name"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(0, (short[]) null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.withinBounds(-1, new short[]{1, 1, 1, 1}, "Name"));
  }

  /**
   * Method under test: {@link Assert#instanceOf(Object, Class, String)}
   */
  @Test
  @SuppressWarnings("all")
  void testInstanceOf() throws CommunicatorException {
    // Arrange, Act and Assert
    assertThrows(CommunicatorException.class, () -> Assert.instanceOf(null, null, "foo"));
    assertThrows(CommunicatorException.class, () -> Assert.instanceOf("Value", null, "Name"));
  }
}

