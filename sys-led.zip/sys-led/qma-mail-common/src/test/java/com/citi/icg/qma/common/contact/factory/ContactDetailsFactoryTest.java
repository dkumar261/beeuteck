package com.citi.icg.qma.common.contact.factory;

import com.citi.icg.qma.common.contact.exception.BadRequestException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ContactDetailsFactoryTest {

    @Test

    void testGetInstance() throws BadRequestException {

        // Arrange

        ContactDetailsFactory contactDetailsFactory = new ContactDetailsFactory();
        String source = "tcl";

        // Act
        ContactDetails actualInstance = contactDetailsFactory.getInstance(source);

        // Assert

        assertNotNull(actualInstance);

    }

}

