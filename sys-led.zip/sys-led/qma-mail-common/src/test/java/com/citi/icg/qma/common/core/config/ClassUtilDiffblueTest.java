package com.citi.icg.qma.common.core.config;

import static org.junit.jupiter.api.Assertions.assertThrows;
import com.citi.icg.qma.common.core.exception.CommunicatorException;
import org.junit.jupiter.api.Test;

class ClassUtilDiffblueTest {
  /**
   * Method under test: {@link ClassUtil#getInstanceFromName(String)}
   */
  @Test
  @SuppressWarnings("all")
  void testGetInstanceFromName() throws CommunicatorException {
    // Arrange, Act and Assert
    assertThrows(CommunicatorException.class, () -> ClassUtil.getInstanceFromName("Class Name"));
    assertThrows(CommunicatorException.class, () -> ClassUtil.getInstanceFromName("]"));
    assertThrows(CommunicatorException.class, () -> ClassUtil.getInstanceFromName(""));
    assertThrows(CommunicatorException.class, () -> ClassUtil.getInstanceFromName("Error loading class name []"));
    assertThrows(CommunicatorException.class, () -> ClassUtil.getInstanceFromName("Class Name", Object.class));
    assertThrows(CommunicatorException.class, () -> ClassUtil.getInstanceFromName("]", Object.class));
    assertThrows(CommunicatorException.class, () -> ClassUtil.getInstanceFromName("", Object.class));
  }

  /**
  * Method under test: {@link ClassUtil#getClass(String)}
  */
  @Test
  @SuppressWarnings("all")
  void testGetClass() throws CommunicatorException {
    // Arrange, Act and Assert
    assertThrows(CommunicatorException.class, () -> ClassUtil.getClass("Class Name"));
    assertThrows(CommunicatorException.class, () -> ClassUtil.getClass("Error loading class name ["));
    assertThrows(CommunicatorException.class, () -> ClassUtil.getClass("]"));
    assertThrows(CommunicatorException.class, () -> ClassUtil.getClass(""));
    assertThrows(CommunicatorException.class, () -> ClassUtil.getClass("Error loading class name []"));
  }
}

