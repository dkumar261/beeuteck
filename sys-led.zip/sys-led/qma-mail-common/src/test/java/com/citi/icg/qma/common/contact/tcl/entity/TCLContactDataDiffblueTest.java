package com.citi.icg.qma.common.contact.tcl.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class TCLContactDataDiffblueTest {
  /**
  * Methods under test: 
  * 
  * <ul>
  *   <li>default or parameterless constructor of {@link TCLContactData}
  *   <li>{@link TCLContactData#setCobDate(String)}
  *   <li>{@link TCLContactData#setCrtdBy(String)}
  *   <li>{@link TCLContactData#setCrtdTs(String)}
  *   <li>{@link TCLContactData#setCustId(String)}
  *   <li>{@link TCLContactData#setCustName(String)}
  *   <li>{@link TCLContactData#setEmail(String)}
  *   <li>{@link TCLContactData#setProductFamily(String)}
  *   <li>{@link TCLContactData#setTaxId(String)}
  *   <li>{@link TCLContactData#getCobDate()}
  *   <li>{@link TCLContactData#getCrtdBy()}
  *   <li>{@link TCLContactData#getCrtdTs()}
  *   <li>{@link TCLContactData#getCustId()}
  *   <li>{@link TCLContactData#getCustName()}
  *   <li>{@link TCLContactData#getEmail()}
  *   <li>{@link TCLContactData#getProductFamily()}
  *   <li>{@link TCLContactData#getTaxId()}
  * </ul>
  */
  @Test
  @SuppressWarnings("all")
  void testConstructor() {
    // Arrange and Act
    TCLContactData actualTclContactData = new TCLContactData();
    actualTclContactData.setCobDate("2020-03-01");
    actualTclContactData.setCrtdBy("Crtd By");
    actualTclContactData.setCrtdTs("Crtd Ts");
    actualTclContactData.setCustId("42");
    actualTclContactData.setCustName("Cust Name");
    actualTclContactData.setEmail("jane.doe@example.org");
    actualTclContactData.setProductFamily("Product Family");
    actualTclContactData.setTaxId("42");

    // Assert
    assertEquals("2020-03-01", actualTclContactData.getCobDate());
    assertEquals("Crtd By", actualTclContactData.getCrtdBy());
    assertEquals("Crtd Ts", actualTclContactData.getCrtdTs());
    assertEquals("42", actualTclContactData.getCustId());
    assertEquals("Cust Name", actualTclContactData.getCustName());
    assertEquals("jane.doe@example.org", actualTclContactData.getEmail());
    assertEquals("Product Family", actualTclContactData.getProductFamily());
    assertEquals("42", actualTclContactData.getTaxId());
  }
}

