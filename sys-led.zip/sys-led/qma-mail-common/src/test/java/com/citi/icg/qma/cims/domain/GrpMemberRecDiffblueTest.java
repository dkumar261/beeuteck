package com.citi.icg.qma.cims.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class GrpMemberRecDiffblueTest {
  /**
  * Methods under test: 
  * 
  * <ul>
  *   <li>default or parameterless constructor of {@link GrpMemberRec}
  *   <li>{@link GrpMemberRec#setDisplayName(String)}
  *   <li>{@link GrpMemberRec#setDistinguishedName(String)}
  *   <li>{@link GrpMemberRec#setDomain(String)}
  *   <li>{@link GrpMemberRec#setGroupScope(String)}
  *   <li>{@link GrpMemberRec#setGroupSecType(String)}
  *   <li>{@link GrpMemberRec#setGuid(String)}
  *   <li>{@link GrpMemberRec#setObjectType(String)}
  *   <li>{@link GrpMemberRec#setSamAccountName(String)}
  *   <li>{@link GrpMemberRec#getDisplayName()}
  *   <li>{@link GrpMemberRec#getDistinguishedName()}
  *   <li>{@link GrpMemberRec#getDomain()}
  *   <li>{@link GrpMemberRec#getGroupScope()}
  *   <li>{@link GrpMemberRec#getGroupSecType()}
  *   <li>{@link GrpMemberRec#getGuid()}
  *   <li>{@link GrpMemberRec#getObjectType()}
  *   <li>{@link GrpMemberRec#getSamAccountName()}
  * </ul>
  */
  @Test
  @SuppressWarnings("all")
  void testConstructor() {
    // Arrange and Act
    GrpMemberRec actualGrpMemberRec = new GrpMemberRec();
    actualGrpMemberRec.setDisplayName("Display Name");
    actualGrpMemberRec.setDistinguishedName("Distinguished Name");
    actualGrpMemberRec.setDomain("Domain");
    actualGrpMemberRec.setGroupScope("Group Scope");
    actualGrpMemberRec.setGroupSecType("Group Sec Type");
    actualGrpMemberRec.setGuid("1234");
    actualGrpMemberRec.setObjectType("Object Type");
    actualGrpMemberRec.setSamAccountName("Dr Jane Doe");

    // Assert
    assertEquals("Display Name", actualGrpMemberRec.getDisplayName());
    assertEquals("Distinguished Name", actualGrpMemberRec.getDistinguishedName());
    assertEquals("Domain", actualGrpMemberRec.getDomain());
    assertEquals("Group Scope", actualGrpMemberRec.getGroupScope());
    assertEquals("Group Sec Type", actualGrpMemberRec.getGroupSecType());
    assertEquals("1234", actualGrpMemberRec.getGuid());
    assertEquals("Object Type", actualGrpMemberRec.getObjectType());
    assertEquals("Dr Jane Doe", actualGrpMemberRec.getSamAccountName());
  }
}

