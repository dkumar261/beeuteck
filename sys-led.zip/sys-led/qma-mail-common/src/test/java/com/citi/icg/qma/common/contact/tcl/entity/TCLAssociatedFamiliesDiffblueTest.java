package com.citi.icg.qma.common.contact.tcl.entity;

import static org.junit.jupiter.api.Assertions.assertSame;
import org.junit.jupiter.api.Test;

class TCLAssociatedFamiliesDiffblueTest {
  /**
  * Methods under test: 
  * 
  * <ul>
  *   <li>default or parameterless constructor of {@link TCLAssociatedFamilies}
  *   <li>{@link TCLAssociatedFamilies#setFamilyDetail(TCLFamilyDetail)}
  *   <li>{@link TCLAssociatedFamilies#getFamilyDetail()}
  * </ul>
  */
  @Test
  @SuppressWarnings("all")
  void testConstructor() {
    // Arrange and Act
    TCLAssociatedFamilies actualTclAssociatedFamilies = new TCLAssociatedFamilies();
    TCLFamilyDetail tclFamilyDetail = new TCLFamilyDetail();
    tclFamilyDetail.setFamilyName("Family Name");
    tclFamilyDetail.setFamilyNumber(10);
    actualTclAssociatedFamilies.setFamilyDetail(tclFamilyDetail);

    // Assert
    assertSame(tclFamilyDetail, actualTclAssociatedFamilies.getFamilyDetail());
  }
}

