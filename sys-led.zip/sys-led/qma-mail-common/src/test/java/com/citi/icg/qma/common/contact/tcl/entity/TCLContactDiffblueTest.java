package com.citi.icg.qma.common.contact.tcl.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class TCLContactDiffblueTest {
  /**
  * Methods under test: 
  * 
  * <ul>
  *   <li>default or parameterless constructor of {@link TCLContact}
  *   <li>{@link TCLContact#setCorrentistaInd(String)}
  *   <li>{@link TCLContact#setCustomerContactDetails(TCLCustomerContactDetails[])}
  *   <li>{@link TCLContact#setCustomerName(String)}
  *   <li>{@link TCLContact#setDateTime(String)}
  *   <li>{@link TCLContact#setSourceSystem(String)}
  *   <li>{@link TCLContact#setTaxid(String)}
  *   <li>{@link TCLContact#getCorrentistaInd()}
  *   <li>{@link TCLContact#getCustomerName()}
  *   <li>{@link TCLContact#getDateTime()}
  *   <li>{@link TCLContact#getSourceSystem()}
  *   <li>{@link TCLContact#getTaxid()}
  * </ul>
  */
  @Test
  @SuppressWarnings("all")
  void testConstructor() {
    // Arrange and Act
    TCLContact actualTclContact = new TCLContact();
    actualTclContact.setCorrentistaInd("Correntista Ind");
    TCLAssociatedFamilies tclAssociatedFamilies = new TCLAssociatedFamilies();
    tclAssociatedFamilies.setFamilyDetail(new TCLFamilyDetail());
    TCLCustomerContactDetails tclCustomerContactDetails = new TCLCustomerContactDetails();
    tclCustomerContactDetails.setAssociatedFamilies(new TCLAssociatedFamilies[]{tclAssociatedFamilies});
    tclCustomerContactDetails.setEmail("jane.doe@example.org");
    actualTclContact.setCustomerContactDetails(new TCLCustomerContactDetails[]{tclCustomerContactDetails});
    actualTclContact.setCustomerName("Customer Name");
    actualTclContact.setDateTime("2020-03-01");
    actualTclContact.setSourceSystem("Source System");
    actualTclContact.setTaxid("Taxid");

    // Assert
    assertEquals("Correntista Ind", actualTclContact.getCorrentistaInd());
    assertEquals("Customer Name", actualTclContact.getCustomerName());
    assertEquals("2020-03-01", actualTclContact.getDateTime());
    assertEquals("Source System", actualTclContact.getSourceSystem());
    assertEquals("Taxid", actualTclContact.getTaxid());
  }
}

