package com.citi.icg.qma.common.contact.tcl.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class TCLCustomerContactDetailsDiffblueTest {
  /**
  * Methods under test: 
  * 
  * <ul>
  *   <li>default or parameterless constructor of {@link TCLCustomerContactDetails}
  *   <li>{@link TCLCustomerContactDetails#setAssociatedFamilies(TCLAssociatedFamilies[])}
  *   <li>{@link TCLCustomerContactDetails#setEmail(String)}
  *   <li>{@link TCLCustomerContactDetails#getEmail()}
  * </ul>
  */
  @Test
  @SuppressWarnings("all")
  void testConstructor() {
    // Arrange and Act
    TCLCustomerContactDetails actualTclCustomerContactDetails = new TCLCustomerContactDetails();
    TCLFamilyDetail tclFamilyDetail = new TCLFamilyDetail();
    tclFamilyDetail.setFamilyName("Family Name");
    tclFamilyDetail.setFamilyNumber(10);
    TCLAssociatedFamilies tclAssociatedFamilies = new TCLAssociatedFamilies();
    tclAssociatedFamilies.setFamilyDetail(tclFamilyDetail);
    actualTclCustomerContactDetails.setAssociatedFamilies(new TCLAssociatedFamilies[]{tclAssociatedFamilies});
    actualTclCustomerContactDetails.setEmail("jane.doe@example.org");

    // Assert
    assertEquals("jane.doe@example.org", actualTclCustomerContactDetails.getEmail());
  }
}

