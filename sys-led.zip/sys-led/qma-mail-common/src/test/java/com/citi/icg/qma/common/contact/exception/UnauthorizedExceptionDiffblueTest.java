package com.citi.icg.qma.common.contact.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import org.junit.jupiter.api.Test;

class UnauthorizedExceptionDiffblueTest {
  /**
  * Method under test: {@link UnauthorizedException#UnauthorizedException(String)}
  */
  @Test
  @SuppressWarnings("all")
  void testConstructor() {
    // Arrange and Act
    UnauthorizedException actualUnauthorizedException = new UnauthorizedException("An error occurred");

    // Assert
    assertNull(actualUnauthorizedException.getCause());
    assertEquals(0, actualUnauthorizedException.getSuppressed().length);
    assertEquals("An error occurred", actualUnauthorizedException.getMessage());
    assertEquals("An error occurred", actualUnauthorizedException.getLocalizedMessage());
  }
}

