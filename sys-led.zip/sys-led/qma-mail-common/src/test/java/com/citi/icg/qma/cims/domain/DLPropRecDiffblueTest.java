package com.citi.icg.qma.cims.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class DLPropRecDiffblueTest {
  /**
  * Methods under test: 
  * 
  * <ul>
  *   <li>default or parameterless constructor of {@link DLPropRec}
  *   <li>{@link DLPropRec#setDescription(String)}
  *   <li>{@link DLPropRec#setDomainLong(String)}
  *   <li>{@link DLPropRec#setDomainShort(String)}
  *   <li>{@link DLPropRec#setEmail(String)}
  *   <li>{@link DLPropRec#setGuid(String)}
  *   <li>{@link DLPropRec#setSamAccountName(String)}
  *   <li>{@link DLPropRec#getDescription()}
  *   <li>{@link DLPropRec#getDomainLong()}
  *   <li>{@link DLPropRec#getDomainShort()}
  *   <li>{@link DLPropRec#getEmail()}
  *   <li>{@link DLPropRec#getGuid()}
  *   <li>{@link DLPropRec#getSamAccountName()}
  * </ul>
  */
  @Test
  @SuppressWarnings("all")
  void testConstructor() {
    // Arrange and Act
    DLPropRec actualDlPropRec = new DLPropRec();
    actualDlPropRec.setDescription("The characteristics of someone or something");
    actualDlPropRec.setDomainLong("Domain Long");
    actualDlPropRec.setDomainShort("Domain Short");
    actualDlPropRec.setEmail("jane.doe@example.org");
    actualDlPropRec.setGuid("1234");
    actualDlPropRec.setSamAccountName("Dr Jane Doe");

    // Assert
    assertEquals("The characteristics of someone or something", actualDlPropRec.getDescription());
    assertEquals("Domain Long", actualDlPropRec.getDomainLong());
    assertEquals("Domain Short", actualDlPropRec.getDomainShort());
    assertEquals("jane.doe@example.org", actualDlPropRec.getEmail());
    assertEquals("1234", actualDlPropRec.getGuid());
    assertEquals("Dr Jane Doe", actualDlPropRec.getSamAccountName());
  }
}

