package com.citi.icg.qma.common.contact.tcl.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class TCLContactsDiffblueTest {
  /**
  * Methods under test: 
  * 
  * <ul>
  *   <li>default or parameterless constructor of {@link TCLContacts}
  *   <li>{@link TCLContacts#setData(TCLContactData[])}
  *   <li>{@link TCLContacts#setFields(Fields[])}
  *   <li>{@link TCLContacts#setTotalPages(String)}
  *   <li>{@link TCLContacts#setTotalRows(String)}
  *   <li>{@link TCLContacts#getTotalPages()}
  *   <li>{@link TCLContacts#getTotalRows()}
  * </ul>
  */
  @Test
  @SuppressWarnings("all")
  void testConstructor() {
    // Arrange and Act
    TCLContacts actualTclContacts = new TCLContacts();
    TCLContactData tclContactData = new TCLContactData();
    tclContactData.setCobDate("2020-03-01");
    tclContactData.setCrtdBy("Crtd By");
    tclContactData.setCrtdTs("Crtd Ts");
    tclContactData.setCustId("42");
    tclContactData.setCustName("Cust Name");
    tclContactData.setEmail("jane.doe@example.org");
    tclContactData.setProductFamily("Product Family");
    tclContactData.setTaxId("42");
    actualTclContacts.setData(new TCLContactData[]{tclContactData});
    Fields fields = new Fields();
    fields.setAlias("Alias");
    fields.setColName("Col Name");
    fields.setColType("Col Type");
    fields.setHidden("Hidden");
    fields.setId(123L);
    fields.setName("Name");
    fields.setOrder(1L);
    actualTclContacts.setFields(new Fields[]{fields});
    actualTclContacts.setTotalPages("Total Pages");
    actualTclContacts.setTotalRows("Total Rows");

    // Assert
    assertEquals("Total Pages", actualTclContacts.getTotalPages());
    assertEquals("Total Rows", actualTclContacts.getTotalRows());
  }
}

