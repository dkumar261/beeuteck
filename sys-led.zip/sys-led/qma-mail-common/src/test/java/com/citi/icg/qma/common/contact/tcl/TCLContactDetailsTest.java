package com.citi.icg.qma.common.contact.tcl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.mockito.MockedStatic;

import com.citi.icg.qma.common.contact.exception.UnauthorizedException;
import com.citi.icg.qma.common.core.exception.CommunicatorException;
import com.citi.icg.qma.common.core.util.CLCSocketFactory;
import com.citi.icg.qma.common.server.dao.Config;
import com.citi.icg.qma.common.server.dao.persistence.QMAContact;
import com.citi.icg.qma.hazelcast.cache.client.HazelcastCache;
import com.citi.icg.qma.hazelcast.cache.client.QMACacheFactory;
import com.mongodb.BasicDBObject;

class TCLContactDetailsTest {
    /**
     * Method under test: {@link TCLContactDetails#getSearchContactDetails(String, BasicDBObject, BasicDBObject)}
     */
    
    void testGetSearchContactDetails() throws UnauthorizedException, CommunicatorException {
        TCLContactDetails tclContactDetails = new TCLContactDetails();
        String soeid = "000";
        BasicDBObject inputJsonObj = mock(BasicDBObject.class);
        BasicDBObject outputBuilderObj = mock(BasicDBObject.class);
        Config configData = mock(Config.class);
        Map<String, Object> tclConfig = new HashMap<>();
        Map<String, Object> requestParams = new HashMap<>();
        requestParams.put("report_type_id", "testReportType");
        requestParams.put("page_size", "testPageSize");
        requestParams.put("page_index", 0L);
        requestParams.put("userType", "testUserType");
        requestParams.put("serviceId", "testServiceId");
        requestParams.put("advanceSearchId", "testAdvancedSearchId");

        tclConfig.put("requestParams", requestParams);
        tclConfig.put("tcl-contact-url-new", "http://test.com?test=test%test%test");

        Map<String, Object> clcConfig = new HashMap<>();
        Map<String, String> certConfig = new HashMap<>();
        certConfig.put("certFileName", "testCertFile");
        Config clcConfigData = mock(Config.class);
        clcConfig.put("certConf", certConfig);




        HazelcastCache qmaCache = mock(HazelcastCache.class);
        CloseableHttpClient httpClient = mock(CloseableHttpClient.class);
        HttpClientBuilder builder = mock(HttpClientBuilder.class);
        SSLConnectionSocketFactory socketFactory = mock(SSLConnectionSocketFactory.class);
        CloseableHttpResponse response = mock(CloseableHttpResponse.class);
        StatusLine statusLine = mock(StatusLine.class);
        HttpEntity entity = mock(HttpEntity.class);
        String content = "{\"totalPages\" : \"1\", \"totalRows\": \"1\", " +
                "\"data\": [{\"cobDate\": \"testCobDate\", \"custId\": \"testCustId\"," +
                "\"custName\": \"testCustName\", " +
                "\"taxId\": \"testTaxId\", \"productFamily\": \"testProductFamily\", " +
                "\"email\": \"testEmail\", \"crtdBy\": \"testCrtdBy\", " +
                "\"crtdTs\": \"testCrtdTs\"}], " +
                "\"fields\":[{\"name\": \"testName\", \"id\": 1, \"order\": 1, \"hidden\": \"testHidden\", " +
                "\"alias\": \"testalias\", \"colName\": \"testColName\", \"colType\": \"testColType\"}]}";
        InputStream is = new ByteArrayInputStream(content.getBytes());


        try(MockedStatic mockedStatic1 = mockStatic(HttpClients.class)) {
            MockedStatic mockedStatic2 = mockStatic(CLCSocketFactory.class);
            mockedStatic2.when(CLCSocketFactory::getInstance).thenReturn(socketFactory);
            mockedStatic1.when(HttpClients::custom).thenReturn(builder);
            when(builder.setSSLSocketFactory(socketFactory)).thenReturn(builder);
            when(builder.disableCookieManagement()).thenReturn(builder);
            when(builder.build()).thenReturn(httpClient);


            try (MockedStatic mockedStatic = mockStatic(QMACacheFactory.class)) {
                mockedStatic.when(QMACacheFactory::getCache).thenReturn(qmaCache);
                when(qmaCache.getConfigById("TCLConfiguration")).thenReturn(configData);
                when(configData.getTCLConfiguration()).thenReturn(tclConfig);
                when(inputJsonObj.getString("taxId")).thenReturn("testTaxId");
                when(inputJsonObj.getString("email")).thenReturn("testEmail");
                when(inputJsonObj.getString("productFamily")).thenReturn("testProductFamily");
                when(inputJsonObj.getString("condition")).thenReturn("testEndsWith");
                when(qmaCache.getConfigById("clcConfiguration")).thenReturn(clcConfigData);
                when(clcConfigData.getClcConfiguration()).thenReturn(clcConfig);
                when(httpClient.execute(any())).thenReturn(response);
                when(response.getStatusLine()).thenReturn(statusLine);
                when(statusLine.getStatusCode()).thenReturn(HttpStatus.SC_OK);
                when(response.getEntity()).thenReturn(entity);
                when(entity.getContentLength()).thenReturn(1L);
                when(entity.getContent()).thenReturn(is);




                List<QMAContact> actualSearchContactDetails = tclContactDetails.getSearchContactDetails(soeid, inputJsonObj, outputBuilderObj);


                assertEquals(1, actualSearchContactDetails.size());
            } catch (ClientProtocolException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }


}
