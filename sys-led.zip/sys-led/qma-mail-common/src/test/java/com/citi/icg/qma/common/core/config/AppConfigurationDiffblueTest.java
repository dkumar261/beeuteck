package com.citi.icg.qma.common.core.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.apache.commons.configuration.HierarchicalConfiguration;
import org.apache.commons.configuration.resolver.DefaultEntityResolver;
import org.apache.commons.logging.impl.NoOpLog;
import org.junit.jupiter.api.Test;

class AppConfigurationDiffblueTest {
  /**
   * Method under test: {@link AppConfiguration#getApplicationConfigDir()}
   */
  @Test
  @SuppressWarnings("all")
  void testGetApplicationConfigDir() {
    // Arrange, Act and Assert
    assertNull(AppConfiguration.getApplicationConfigDir());
  }

  /**
  * Method under test: default or parameterless constructor of {@link AppConfiguration}
  */
  @Test
  @SuppressWarnings("all")
  void testConstructor() {
    // Arrange and Act
    AppConfiguration actualAppConfiguration = new AppConfiguration();

    // Assert
    assertNull(actualAppConfiguration.getApplicationName());
    assertTrue(actualAppConfiguration.isEmpty());
    assertTrue(actualAppConfiguration.isDelimiterParsingDisabled());
    assertFalse(actualAppConfiguration.isAutoSave());
    assertNull(actualAppConfiguration.getURL());
    assertSame(actualAppConfiguration.getRootNode(), actualAppConfiguration.getRoot());
    //assertTrue(actualAppConfiguration.getLogger() instanceof NoOpLog);
    assertEquals(',', actualAppConfiguration.getListDelimiter());
    assertTrue(actualAppConfiguration.getEntityResolver() instanceof DefaultEntityResolver);
  }
}

