import { Component, inject, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { HelloWorld } from "./helloworld/helloworld";
import { Dog } from './Dog';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, HelloWorld, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit, OnChanges {


  title = 'hello-world';
  public columnChooserSelectedColumns: string = 'DC sample';
  outPutValue: string = '';

  dogId!: number;
  dogName!: string;
  dogAge!: string;


  dogs!: Dog[];

  http = inject(HttpClient);
  testPC() {
    this.columnChooserSelectedColumns="Value is changes on click event";
  }
  dogObj: any = {
    "name": "Dogu",
    "age": 10
  }

  constructor() {
    console.log("This is constructor calling ");
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log("This is ngOnChanges calling ");
  }
  ngOnInit(): void {
    console.log("This is ngOnInit calling ");
  }
  sentRequest() {
    this.http.get("http://localhost:8088/dog").subscribe((result: any) => {
      this.dogs = result;
      console.log(this.dogs);

    });
  }

  postData() {
    this.dogObj.name = this.dogName;
    this.dogObj.age = this.dogAge;
    this.http.post("http://localhost:8088/savedog", this.dogObj).subscribe((result: any) => { });
  }

  getDogById() {

    let name: "";
    this.http.get("http://localhost:8088/dog/" + this.dogId).subscribe((result: any) => {
      this.dogs = result;
      console.log(this.dogs);

    });
  }

  recieve(event: string) {

    debugger
    this.outPutValue = event;
  }
}
