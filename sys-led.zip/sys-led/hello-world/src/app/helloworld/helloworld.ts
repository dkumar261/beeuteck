import { Component, Input, Output, EventEmitter } from "@angular/core";

@Component({

  selector: 'hello-world',
  standalone: true,
  imports: [],
  templateUrl: './helloworld.html'
})

export class HelloWorld {
  @Input() message: string='';

  @Input() selectedValue: string='';

  @Output() greeting = new EventEmitter<string>();

  sendToOutput(outPutValue:string){
    debugger
    this.greeting.emit(outPutValue);
  }
}