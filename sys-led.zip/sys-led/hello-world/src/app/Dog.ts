export interface  Dog{
    name:String;
    age:number;
}